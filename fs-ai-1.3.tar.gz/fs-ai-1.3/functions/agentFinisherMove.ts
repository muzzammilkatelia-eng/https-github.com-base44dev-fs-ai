import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { player_profile, scout_summary, club_context, risk_tolerance = 0.5 } = await req.json();

        if (!player_profile || !scout_summary || !club_context) {
            return Response.json({ error: 'Player profile, scout summary, and club context required' }, { status: 400 });
        }

        const decision = calculateFinisherMove(player_profile, scout_summary, club_context, risk_tolerance);

        return Response.json(decision);

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});

function calculateFinisherMove(player, scout, club, riskTolerance) {
    // 1. Decide if this club is worth a move
    const upside = (scout.ceiling + scout.fit) / 2;
    const safety = (scout.floor + (100 - scout.risk)) / 2;

    // Simple risk gate
    const safeEnough = (scout.risk / 100) <= riskTolerance;

    // 2. Fee logic
    const baseFee = player.estimated_value;
    const ceilingBoost = scout.ceiling > 70 ? (scout.ceiling - 70) * 0.5 : 0;
    const fitBoost = scout.fit > 70 ? (scout.fit - 70) * 0.3 : 0;
    const riskDiscount = scout.risk > 40 ? (scout.risk - 40) * 0.4 : 0;

    let recommendedFee = Math.max(0, baseFee + ceilingBoost + fitBoost - riskDiscount);

    // Respect club budget
    if (recommendedFee > club.transfer_budget) {
        recommendedFee = club.transfer_budget * 0.95;
    }

    const negotiationFloorFee = recommendedFee * 0.85;

    // 3. Wage logic
    const wageAnchor = Math.max(player.wage_current, player.wage_target);
    const ratingFactor = scout.final_rating / 100;
    const roleFactor = club.role_importance === "key piece" ? 1.1 : 1.0;

    let recommendedWage = wageAnchor * (1 + 0.25 * ratingFactor) * roleFactor;

    if (recommendedWage > club.wage_ceiling) {
        recommendedWage = club.wage_ceiling * 0.98;
    }

    const negotiationFloorWage = recommendedWage * 0.9;

    // 4. Move type decision
    let moveType, headline;

    if (!safeEnough) {
        moveType = "wait";
        headline = "High upside but risk too high for this move now.";
    } else if (scout.fit < 65) {
        moveType = "wait";
        headline = "Player profile strong but club fit is not ideal.";
    } else if (["contender", "elite"].includes(club.project_level) && scout.final_rating >= 78) {
        moveType = "push_move";
        headline = "This is a strategic step up. Push the move.";
    } else if (scout.final_rating < 70) {
        moveType = "stay";
        headline = "Better to consolidate and wait for a stronger spot.";
    } else {
        moveType = "monitor";
        headline = "Keep dialogue open, but do not force the move.";
    }

    const notes = [
        `Upside score: ${upside.toFixed(1)}`,
        `Safety score: ${safety.toFixed(1)}`,
        `Recommended fee: £${recommendedFee.toFixed(2)}M`,
        `Recommended wage: £${recommendedWage.toFixed(0)}K per week`,
        `Club project: ${club.project_level}`,
        `Role importance: ${club.role_importance}`
    ];

    return {
        move_type: moveType,
        target_club: club.club_name,
        recommended_fee: parseFloat(recommendedFee.toFixed(2)),
        recommended_wage: parseFloat(recommendedWage.toFixed(0)),
        negotiation_floor_fee: parseFloat(negotiationFloorFee.toFixed(2)),
        negotiation_floor_wage: parseFloat(negotiationFloorWage.toFixed(0)),
        headline,
        notes,
        analysis: {
            upside: parseFloat(upside.toFixed(1)),
            safety: parseFloat(safety.toFixed(1)),
            safe_enough: safeEnough,
            risk_tolerance: riskTolerance
        }
    };
}