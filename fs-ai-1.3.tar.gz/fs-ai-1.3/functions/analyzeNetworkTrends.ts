import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // 1. Fetch recent shared findings
        const findings = await base44.entities.ScoutFinding.filter({ 
            is_shared: true 
        });

        // 2. Analyze patterns with LLM
        const prompt = `Analyze these ${findings.length} scouting findings to identify emerging trends, patterns, and anomalies.
        
        Focus on:
        1. Regions producing high volumes of specific talent types (e.g. "Increase in technical wingers from Colombia")
        2. Undervalued markets or leagues gaining traction
        3. Tactical shifts in player profiles being scouted
        4. Collective blind spots or missed opportunities

        Findings data:
        ${JSON.stringify(findings.slice(0, 50).map(f => ({
            region: f.region,
            position: f.position,
            type: f.finding_type,
            summary: f.summary,
            age: f.player_age
        })))}

        Return a JSON object with:
        {
            "trends": [
                { "title": "Trend Title", "description": "Description", "confidence": 0-100, "regions": [] }
            ],
            "emerging_hotspots": ["Region 1", "Region 2"],
            "recommended_focus_areas": ["Focus 1", "Focus 2"]
        }`;

        const analysis = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: "object",
                properties: {
                    trends: { 
                        type: "array", 
                        items: { 
                            type: "object",
                            properties: {
                                title: { type: "string" },
                                description: { type: "string" },
                                confidence: { type: "number" },
                                regions: { type: "array", items: { type: "string" } }
                            }
                        } 
                    },
                    emerging_hotspots: { type: "array", items: { type: "string" } },
                    recommended_focus_areas: { type: "array", items: { type: "string" } }
                }
            }
        });

        return Response.json(analysis);

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});