import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

export async function analyzeNetworkTrends(base44) {
    // 1. Fetch recent findings
    const findings = await base44.entities.ScoutFinding.filter({}, '-created_date', 50);

    // 2. Aggregate data for LLM
    const findingSummaries = findings.map(f => 
        `[${f.finding_type}] ${f.player_name} (${f.position}, ${f.age}y) in ${f.region}: ${f.summary}. Priority: ${f.priority}`
    ).join('\n');

    // 3. AI Analysis
    const prompt = `
    Analyze these recent scouting findings to identify emerging patterns and collaborative opportunities.
    
    Findings:
    ${findingSummaries}

    Identify:
    1. Trending Regions (where talent is emerging)
    2. Player Archetype Trends (e.g. "Tall, ball-playing CBs in Brazil")
    3. Suggested Collaborative Missions (2-3 specific missions to assign to the network)

    Return JSON:
    {
        "trends": [
            { "title": "Trend Title", "description": "Description", "impact": "High/Med/Low" }
        ],
        "missions": [
            { "title": "Mission Name", "objective": "Objective", "target_region": "Region", "target_profile": "Profile" }
        ]
    }
    `;

    const analysis = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
            type: "object",
            properties: {
                trends: { 
                    type: "array", 
                    items: { 
                        type: "object", 
                        properties: {
                            title: { type: "string" },
                            description: { type: "string" },
                            impact: { type: "string" }
                        }
                    } 
                },
                missions: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            title: { type: "string" },
                            objective: { type: "string" },
                            target_region: { type: "string" },
                            target_profile: { type: "string" }
                        }
                    }
                }
            }
        }
    });

    return analysis;
}

export async function updateScoutReputation(base44) {
    // Simple reputation algorithm based on findings count and upvotes
    // In a real system, this would be more complex (accuracy verification, etc.)
    
    const scouts = await base44.entities.Scout.list();
    const findings = await base44.entities.ScoutFinding.list();
    
    const updates = [];

    for (const scout of scouts) {
        const scoutFindings = findings.filter(f => f.scout_id === scout.id);
        const reportCount = scoutFindings.length;
        const totalUpvotes = scoutFindings.reduce((sum, f) => sum + (f.upvotes || 0), 0);
        
        // Calculate new accuracy/reputation score (0-100)
        // Base score 50 + (reports * 2) + (upvotes * 5), capped at 99
        let newScore = 50 + (reportCount * 2) + (totalUpvotes * 5);
        if (newScore > 99) newScore = 99;

        updates.push({
            id: scout.id,
            data: {
                performance_metrics: {
                    ...scout.performance_metrics,
                    reports_submitted: reportCount,
                    accuracy_rating: newScore
                }
            }
        });
    }

    // Apply updates
    // Note: Doing this sequentially for safety in this demo, batch update would be better
    for (const update of updates) {
        await base44.entities.Scout.update(update.id, update.data);
    }

    return { updated_count: updates.length };
}

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const { action } = await req.json();

        if (action === 'analyze_trends') {
            const result = await analyzeNetworkTrends(base44);
            return Response.json(result);
        }

        if (action === 'update_reputation') {
            const result = await updateScoutReputation(base44);
            return Response.json(result);
        }
        
        return Response.json({ error: 'Invalid action' }, { status: 400 });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});