import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { documentType } = await req.json();
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('googledrive');

        // Fetch documents based on type
        let documents = [];
        let folderName = 'FS-AI Backups';

        switch (documentType) {
            case 'scouting_reports':
                documents = await base44.asServiceRole.entities.ScoutingReport.list('-created_date', 1000);
                folderName = 'FS-AI Scouting Reports';
                break;
            case 'contracts':
                documents = await base44.asServiceRole.entities.Contract.list('-created_date', 1000);
                folderName = 'FS-AI Contracts';
                break;
            case 'secure_documents':
                documents = await base44.asServiceRole.entities.SecureDocument.list('-created_date', 1000);
                folderName = 'FS-AI Secure Documents';
                break;
            case 'all':
                const reports = await base44.asServiceRole.entities.ScoutingReport.list('-created_date', 1000);
                const contracts = await base44.asServiceRole.entities.Contract.list('-created_date', 1000);
                documents = [...reports, ...contracts];
                folderName = 'FS-AI All Documents';
                break;
        }

        // Create folder in Google Drive
        const folderMetadata = {
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder'
        };

        const folderResponse = await fetch('https://www.googleapis.com/drive/v3/files', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(folderMetadata)
        });

        const folder = await folderResponse.json();
        const folderId = folder.id;

        // Upload documents
        const uploadedFiles = [];
        for (const doc of documents) {
            const fileName = `${doc.player_name || doc.title || doc.id}_${new Date(doc.created_date).toISOString().split('T')[0]}.json`;
            
            const fileMetadata = {
                name: fileName,
                parents: [folderId]
            };

            const fileContent = JSON.stringify(doc, null, 2);
            const boundary = '-------boundary';
            const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(fileMetadata)}\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${fileContent}\r\n--${boundary}--`;

            const uploadResponse = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': `multipart/related; boundary=${boundary}`
                },
                body: body
            });

            const uploadedFile = await uploadResponse.json();
            uploadedFiles.push(uploadedFile);
        }

        return Response.json({
            success: true,
            folder_id: folderId,
            folder_name: folderName,
            files_uploaded: uploadedFiles.length,
            files: uploadedFiles
        });

    } catch (error) {
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});