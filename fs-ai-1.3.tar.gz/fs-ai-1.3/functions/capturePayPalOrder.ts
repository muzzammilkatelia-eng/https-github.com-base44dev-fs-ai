import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const PAYPAL_CLIENT_ID = Deno.env.get('PAYPAL_CLIENT_ID');
const PAYPAL_SECRET = Deno.env.get('PAYPAL_SECRET');
const PAYPAL_API_BASE = 'https://api-m.sandbox.paypal.com';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { orderId } = await req.json();

        if (!orderId) {
            return Response.json({ error: 'Order ID required' }, { status: 400 });
        }

        // Get PayPal access token
        const authResponse = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Basic ${btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`)}`
            },
            body: 'grant_type=client_credentials'
        });

        const authData = await authResponse.json();
        const accessToken = authData.access_token;

        // Capture PayPal order
        const captureResponse = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders/${orderId}/capture`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            }
        });

        const captureData = await captureResponse.json();

        if (!captureResponse.ok) {
            return Response.json({ 
                error: 'Failed to capture payment', 
                details: captureData 
            }, { status: 500 });
        }

        // Update user subscription status
        const subscriptionStart = new Date();
        const subscriptionEnd = new Date();
        subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1);

        await base44.asServiceRole.entities.User.update(user.id, {
            subscription_tier: 'premium',
            subscription_status: 'active',
            subscription_start_date: subscriptionStart.toISOString(),
            subscription_end_date: subscriptionEnd.toISOString(),
            payment_method: 'paypal',
            paypal_order_id: orderId
        });

        // Create sale record
        await base44.asServiceRole.entities.Sale.create({
            product_type: 'Elite Club',
            customer_name: user.full_name,
            customer_email: user.email,
            amount: 99,
            payment_method: 'PayPal',
            subscription_period: 'monthly',
            status: 'completed',
            slack_notified: false
        });

        return Response.json({
            success: true,
            captureId: captureData.purchase_units?.[0]?.payments?.captures?.[0]?.id,
            status: captureData.status
        });

    } catch (error) {
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});