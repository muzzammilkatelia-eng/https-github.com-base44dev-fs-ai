/**
 * Checks if a new scouting report or projection matches alert criteria
 * Triggers notifications if matches are found
 */

export default async function checkAndTriggerAlerts({ base44, params }) {
    const { playerData, dataType } = params; // dataType: 'scouting_report' or 'projection'

    try {
        // Get all active alert criteria
        const allCriteria = await base44.asServiceRole.entities.AlertCriteria.filter({
            active: true
        });

        const matchingCriteria = [];

        // Check each criteria
        for (const criteria of allCriteria) {
            // Check if this criteria applies to this data type
            if (criteria.trigger_type !== 'both' && criteria.trigger_type !== dataType) {
                continue;
            }

            let matches = true;

            // Check position
            if (criteria.criteria?.positions && criteria.criteria.positions.length > 0) {
                if (!criteria.criteria.positions.includes(playerData.position)) {
                    matches = false;
                }
            }

            // Check age range
            if (criteria.criteria?.min_age && playerData.age < criteria.criteria.min_age) {
                matches = false;
            }
            if (criteria.criteria?.max_age && playerData.age > criteria.criteria.max_age) {
                matches = false;
            }

            // Check recommendations (for scouting reports)
            if (dataType === 'scouting_report' && criteria.criteria?.recommendations && criteria.criteria.recommendations.length > 0) {
                if (!criteria.criteria.recommendations.includes(playerData.recommendation)) {
                    matches = false;
                }
            }

            // Check trajectories (for projections)
            if (dataType === 'projection' && criteria.criteria?.trajectories && criteria.criteria.trajectories.length > 0) {
                if (!criteria.criteria.trajectories.includes(playerData.trajectory)) {
                    matches = false;
                }
            }

            // Check potential rating (for projections)
            if (dataType === 'projection' && criteria.criteria?.min_potential_rating) {
                if (playerData.potential_rating < criteria.criteria.min_potential_rating) {
                    matches = false;
                }
            }

            if (matches) {
                matchingCriteria.push(criteria);
            }
        }

        // Create alerts and send notifications
        const createdAlerts = [];

        for (const criteria of matchingCriteria) {
            // Create in-app alert
            const alert = await base44.asServiceRole.entities.Alert.create({
                player_name: playerData.name,
                alert_type: dataType,
                criteria_name: criteria.name,
                player_details: {
                    age: playerData.age,
                    position: playerData.position,
                    recommendation: playerData.recommendation,
                    trajectory: playerData.trajectory,
                    potential_rating: playerData.potential_rating
                },
                read: false,
                notified_slack: false
            });

            createdAlerts.push(alert);

            // Send Slack notification if enabled
            if (criteria.notify_slack) {
                try {
                    const slackToken = await base44.asServiceRole.connectors.getAccessToken('slack');
                    
                    const message = {
                        channel: criteria.slack_channel || '#scouting',
                        text: `🎯 *New Target Alert: ${criteria.name}*`,
                        blocks: [
                            {
                                type: 'header',
                                text: {
                                    type: 'plain_text',
                                    text: `🎯 New Target Alert: ${criteria.name}`
                                }
                            },
                            {
                                type: 'section',
                                fields: [
                                    {
                                        type: 'mrkdwn',
                                        text: `*Player:*\n${playerData.name}`
                                    },
                                    {
                                        type: 'mrkdwn',
                                        text: `*Age:*\n${playerData.age} years`
                                    },
                                    {
                                        type: 'mrkdwn',
                                        text: `*Position:*\n${playerData.position}`
                                    },
                                    {
                                        type: 'mrkdwn',
                                        text: dataType === 'scouting_report' 
                                            ? `*Recommendation:*\n${playerData.recommendation}`
                                            : `*Trajectory:*\n${playerData.trajectory}`
                                    }
                                ]
                            }
                        ]
                    };

                    if (dataType === 'projection' && playerData.potential_rating) {
                        message.blocks.push({
                            type: 'section',
                            text: {
                                type: 'mrkdwn',
                                text: `*Peak Potential:* ${playerData.potential_rating} | *Years to Peak:* ${playerData.years_to_peak}`
                            }
                        });
                    }

                    await fetch('https://slack.com/api/chat.postMessage', {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${slackToken}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(message)
                    });

                    await base44.asServiceRole.entities.Alert.update(alert.id, {
                        notified_slack: true
                    });
                } catch (slackError) {
                    console.error('Slack notification failed:', slackError);
                }
            }
        }

        return {
            success: true,
            alertsCreated: createdAlerts.length,
            alerts: createdAlerts
        };

    } catch (error) {
        console.error('Alert checking error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}