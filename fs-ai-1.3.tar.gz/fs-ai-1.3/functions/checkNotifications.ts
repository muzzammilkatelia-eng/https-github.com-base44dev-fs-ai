import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const notifications = [];

        // 1. Check for talent matches (saved criteria in AI Talent Scout)
        const alerts = await base44.asServiceRole.entities.UserAlert.filter({ 
            user_email: user.email,
            enabled: true 
        });
        
        const savedPlayers = await base44.asServiceRole.entities.SavedPlayer.filter({ 
            user_email: user.email 
        });

        // 2. Check for price drops or contract expiry on watch list
        for (const savedPlayer of savedPlayers) {
            try {
                const players = await base44.asServiceRole.entities.Player.filter({ 
                    id: savedPlayer.player_id 
                });
                const player = players[0];
                
                if (!player) continue;

                // Check contract expiry (within 6 months)
                if (player.contract_expiry) {
                    const expiryDate = new Date(player.contract_expiry);
                    const sixMonthsFromNow = new Date();
                    sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6);
                    
                    if (expiryDate <= sixMonthsFromNow) {
                        const existing = await base44.asServiceRole.entities.Notification.filter({
                            user_email: user.email,
                            type: 'contract_expiry',
                            'metadata.player_id': savedPlayer.player_id
                        });
                        
                        if (existing.length === 0) {
                            notifications.push({
                                user_email: user.email,
                                type: 'contract_expiry',
                                title: 'Contract Expiring Soon',
                                message: `${player.name}'s contract expires on ${new Date(player.contract_expiry).toLocaleDateString()}`,
                                priority: 'high',
                                action_url: `/PlayerProfileDetail?id=${player.id}`,
                                metadata: {
                                    player_id: player.id,
                                    player_name: player.name,
                                    expiry_date: player.contract_expiry
                                }
                            });
                        }
                    }
                }

                // Check for significant price drops (if metadata has previous value)
                if (savedPlayer.metadata?.last_market_value && player.market_value) {
                    const priceDrop = ((savedPlayer.metadata.last_market_value - player.market_value) / savedPlayer.metadata.last_market_value) * 100;
                    
                    if (priceDrop > 15) { // 15% drop
                        const existing = await base44.asServiceRole.entities.Notification.filter({
                            user_email: user.email,
                            type: 'price_drop',
                            'metadata.player_id': savedPlayer.player_id
                        });
                        
                        if (existing.length === 0) {
                            notifications.push({
                                user_email: user.email,
                                type: 'price_drop',
                                title: 'Significant Price Drop',
                                message: `${player.name}'s market value dropped ${priceDrop.toFixed(1)}% to €${player.market_value}M`,
                                priority: 'medium',
                                action_url: `/PlayerProfileDetail?id=${player.id}`,
                                metadata: {
                                    player_id: player.id,
                                    player_name: player.name,
                                    old_value: savedPlayer.metadata.last_market_value,
                                    new_value: player.market_value,
                                    drop_percentage: priceDrop
                                }
                            });
                        }

                        // Update saved player with new value
                        await base44.asServiceRole.entities.SavedPlayer.update(savedPlayer.id, {
                            metadata: {
                                ...savedPlayer.metadata,
                                last_market_value: player.market_value
                            }
                        });
                    }
                }
            } catch (error) {
                console.error('Error checking player:', error);
            }
        }

        // 3. Check subscription status for payment reminders
        if (user.subscription_end_date) {
            const endDate = new Date(user.subscription_end_date);
            const daysUntilExpiry = Math.floor((endDate - new Date()) / (1000 * 60 * 60 * 24));
            
            if (daysUntilExpiry <= 3 && daysUntilExpiry > 0) {
                const existing = await base44.asServiceRole.entities.Notification.filter({
                    user_email: user.email,
                    type: 'payment_reminder'
                });
                
                // Only send one reminder
                if (existing.length === 0) {
                    notifications.push({
                        user_email: user.email,
                        type: 'payment_reminder',
                        title: 'Subscription Renewal Soon',
                        message: `Your subscription will renew in ${daysUntilExpiry} day${daysUntilExpiry !== 1 ? 's' : ''}`,
                        priority: 'medium',
                        action_url: '/Subscription',
                        metadata: {
                            days_until_renewal: daysUntilExpiry,
                            renewal_date: user.subscription_end_date
                        }
                    });
                }
            }
        }

        // Create all notifications
        if (notifications.length > 0) {
            await Promise.all(
                notifications.map(n => base44.asServiceRole.entities.Notification.create(n))
            );
        }

        return Response.json({ 
            success: true, 
            notifications_created: notifications.length,
            notifications 
        });
    } catch (error) {
        console.error('Error checking notifications:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});