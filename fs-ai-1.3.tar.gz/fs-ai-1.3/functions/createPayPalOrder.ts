import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const PAYPAL_CLIENT_ID = Deno.env.get('PAYPAL_CLIENT_ID');
const PAYPAL_SECRET = Deno.env.get('PAYPAL_SECRET');
const PAYPAL_API_BASE = 'https://api-m.sandbox.paypal.com'; // Use sandbox for testing

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Get PayPal access token
        const authResponse = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Basic ${btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`)}`
            },
            body: 'grant_type=client_credentials'
        });

        const authData = await authResponse.json();
        const accessToken = authData.access_token;

        // Create PayPal order
        const orderResponse = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({
                intent: 'CAPTURE',
                purchase_units: [{
                    amount: {
                        currency_code: 'GBP',
                        value: '99.00'
                    },
                    description: 'FS-AI Premium Subscription (Monthly)',
                    custom_id: user.email
                }],
                application_context: {
                    brand_name: 'FS-AI Football Scout Intelligence',
                    landing_page: 'BILLING',
                    user_action: 'PAY_NOW',
                    return_url: `${req.headers.get('origin')}/Subscription?success=true`,
                    cancel_url: `${req.headers.get('origin')}/Subscription?cancelled=true`
                }
            })
        });

        const orderData = await orderResponse.json();

        if (!orderResponse.ok) {
            return Response.json({ 
                error: 'Failed to create PayPal order', 
                details: orderData 
            }, { status: 500 });
        }

        return Response.json({
            orderId: orderData.id,
            approvalUrl: orderData.links.find(link => link.rel === 'approve')?.href
        });

    } catch (error) {
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});