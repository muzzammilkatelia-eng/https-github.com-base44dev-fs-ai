import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { playerId, playerName, season } = await req.json();
        const apiKey = Deno.env.get('API_FOOTBALL_KEY');
        
        if (!apiKey) {
            return Response.json({ error: 'API key not configured' }, { status: 500 });
        }

        const currentSeason = season || new Date().getFullYear();
        const headers = {
            'x-rapidapi-key': apiKey,
            'x-rapidapi-host': 'api-football-v1.p.rapidapi.com'
        };

        // Search for player if no ID provided
        let searchPlayerId = playerId;
        if (!searchPlayerId && playerName) {
            const searchResponse = await fetch(
                `https://api-football-v1.p.rapidapi.com/v3/players?search=${encodeURIComponent(playerName)}`,
                { headers }
            );
            const searchData = await searchResponse.json();
            
            if (searchData.response && searchData.response.length > 0) {
                searchPlayerId = searchData.response[0].player.id;
            }
        }

        if (!searchPlayerId) {
            return Response.json({ error: 'Player not found' }, { status: 404 });
        }

        // Fetch player statistics for current season
        const statsResponse = await fetch(
            `https://api-football-v1.p.rapidapi.com/v3/players?id=${searchPlayerId}&season=${currentSeason}`,
            { headers }
        );
        const statsData = await statsResponse.json();

        // Fetch player transfers
        const transfersResponse = await fetch(
            `https://api-football-v1.p.rapidapi.com/v3/transfers?player=${searchPlayerId}`,
            { headers }
        );
        const transfersData = await transfersResponse.json();

        // Fetch injury history (sidelined)
        const injuriesResponse = await fetch(
            `https://api-football-v1.p.rapidapi.com/v3/sidelined?player=${searchPlayerId}`,
            { headers }
        );
        const injuriesData = await injuriesResponse.json();

        // Get historical stats for past 3 seasons
        const historicalStats = [];
        for (let i = 1; i <= 3; i++) {
            const pastSeason = currentSeason - i;
            try {
                const histResponse = await fetch(
                    `https://api-football-v1.p.rapidapi.com/v3/players?id=${searchPlayerId}&season=${pastSeason}`,
                    { headers }
                );
                const histData = await histResponse.json();
                if (histData.response && histData.response.length > 0) {
                    historicalStats.push({
                        season: pastSeason,
                        data: histData.response[0]
                    });
                }
            } catch (error) {
                console.error(`Error fetching season ${pastSeason}:`, error);
            }
        }

        return Response.json({
            success: true,
            data: {
                current_season: statsData.response?.[0] || null,
                transfers: transfersData.response || [],
                injuries: injuriesData.response || [],
                historical_stats: historicalStats,
                api_player_id: searchPlayerId
            }
        });

    } catch (error) {
        console.error('Enrichment error:', error);
        return Response.json({ 
            error: error.message,
            success: false 
        }, { status: 500 });
    }
});