import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { reportId } = await req.json();

        if (!reportId) {
            return Response.json({ error: 'Report ID required' }, { status: 400 });
        }

        // Fetch the report
        const reports = await base44.entities.ScoutingReport.filter({ id: reportId });
        const report = reports[0];

        if (!report) {
            return Response.json({ error: 'Report not found' }, { status: 404 });
        }

        // Get Google Drive access token
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('googledrive');

        // Create Google Doc content
        const docContent = {
            title: `Scouting Report - ${report.player_name}`,
        };

        // Create the Google Doc
        const createResponse = await fetch('https://docs.googleapis.com/v1/documents', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(docContent),
        });

        if (!createResponse.ok) {
            throw new Error('Failed to create Google Doc');
        }

        const doc = await createResponse.json();
        const documentId = doc.documentId;

        // Format report content
        const requests = [
            {
                insertText: {
                    location: { index: 1 },
                    text: `Scouting Report\n\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Player: ${report.player_name}\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Age: ${report.player_age || 'N/A'}\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Position: ${report.position || 'N/A'}\n\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Modules Activated: ${report.modules_activated?.join(', ') || 'N/A'}\n\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Overall Verdict:\n${report.overall_verdict || 'N/A'}\n\n`
                }
            },
            {
                insertText: {
                    location: { index: 1 },
                    text: `Recommendation: ${report.recommendation || 'N/A'}\n\n`
                }
            }
        ];

        // Add module-specific analyses if available
        if (report.calafat_analysis) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nCalafat Analysis:\n- Ceiling Score: ${report.calafat_analysis.ceiling_score}/100\n- Risk Score: ${report.calafat_analysis.risk_score}/100\n- Development Curve: ${report.calafat_analysis.development_curve}\n\n`
                }
            });
        }

        if (report.brighton_analysis) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nBrighton Analysis:\n- Hidden Gem Score: ${report.brighton_analysis.hidden_gem_score}/100\n- Market Value Trajectory: ${report.brighton_analysis.market_value_trajectory}\n- ROI Score: ${report.brighton_analysis.roi_score}/100\n\n`
                }
            });
        }

        if (report.portuguese_analysis) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nPortuguese Analysis:\n- Flip Potential: ${report.portuguese_analysis.flip_potential}/100\n- Adaptation Score: ${report.portuguese_analysis.adaptation_score}/100\n- Versatility Index: ${report.portuguese_analysis.versatility_index}/100\n\n`
                }
            });
        }

        if (report.dortmund_analysis) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nDortmund Analysis:\n- Readiness Score: ${report.dortmund_analysis.readiness_score}/100\n- Acceleration Curve: ${report.dortmund_analysis.acceleration_curve}\n- Resilience Index: ${report.dortmund_analysis.resilience_index}/100\n\n`
                }
            });
        }

        if (report.ajax_analysis) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nAjax Analysis:\n- Technical Purity: ${report.ajax_analysis.technical_purity}/100\n- Positional IQ: ${report.ajax_analysis.positional_iq}/100\n- Academy Fit: ${report.ajax_analysis.academy_fit}/100\n\n`
                }
            });
        }

        if (report.notes) {
            requests.push({
                insertText: {
                    location: { index: 1 },
                    text: `\nNotes:\n${report.notes}\n`
                }
            });
        }

        // Add content to the document
        const updateResponse = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ requests: requests.reverse() }),
        });

        if (!updateResponse.ok) {
            throw new Error('Failed to update Google Doc');
        }

        return Response.json({
            success: true,
            documentId,
            documentUrl: `https://docs.google.com/document/d/${documentId}/edit`
        });

    } catch (error) {
        console.error('Export error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});