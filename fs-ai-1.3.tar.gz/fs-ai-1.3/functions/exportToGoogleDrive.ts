import { base44 } from "@/api/base44ServerClient";

export default async function exportToGoogleDrive(request) {
    const { reportId, reportData } = request.body;
    
    try {
        // Get Google Drive access token for the current user
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('googledrive');
        
        if (!accessToken) {
            return {
                success: false,
                error: "Google Drive not connected. Please authorize access first."
            };
        }

        // Fetch report data if only ID provided
        let report = reportData;
        if (reportId && !reportData) {
            report = await base44.asServiceRole.entities.ScoutingReport.get(reportId);
        }

        if (!report) {
            return { success: false, error: "Report not found" };
        }

        // Format report as rich text document content
        const documentContent = formatReportContent(report);

        // Create Google Doc
        const createDocResponse = await fetch('https://docs.googleapis.com/v1/documents', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: `FS-AI Scout Report - ${report.player_name} (${new Date().toLocaleDateString()})`
            })
        });

        const docData = await createDocResponse.json();
        const documentId = docData.documentId;

        // Insert content into the document
        await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                requests: documentContent
            })
        });

        return {
            success: true,
            documentId: documentId,
            documentUrl: `https://docs.google.com/document/d/${documentId}/edit`,
            message: "Report exported to Google Drive successfully"
        };

    } catch (error) {
        console.error("Google Drive export error:", error);
        return {
            success: false,
            error: error.message || "Failed to export to Google Drive"
        };
    }
}

function formatReportContent(report) {
    const requests = [];
    let index = 1;

    // Helper to add text with style
    const addText = (text, style = {}) => {
        requests.push({
            insertText: {
                location: { index },
                text: text
            }
        });
        
        if (Object.keys(style).length > 0) {
            requests.push({
                updateTextStyle: {
                    range: {
                        startIndex: index,
                        endIndex: index + text.length
                    },
                    textStyle: style,
                    fields: Object.keys(style).join(',')
                }
            });
        }
        
        index += text.length;
    };

    // Title
    addText(`FS-AI SCOUTING REPORT\n\n`, {
        bold: true,
        fontSize: { magnitude: 20, unit: 'PT' },
        foregroundColor: { color: { rgbColor: { red: 0, green: 0.71, blue: 0.83 } } }
    });

    // Player Info
    addText(`Player: ${report.player_name}\n`, { bold: true, fontSize: { magnitude: 14, unit: 'PT' } });
    addText(`Age: ${report.player_age} | Position: ${report.position}\n`, { fontSize: { magnitude: 11, unit: 'PT' } });
    addText(`Report Date: ${new Date(report.created_date).toLocaleDateString()}\n\n`, { 
        fontSize: { magnitude: 10, unit: 'PT' },
        foregroundColor: { color: { rgbColor: { red: 0.5, green: 0.5, blue: 0.5 } } }
    });

    // Recommendation
    addText(`RECOMMENDATION: ${report.recommendation}\n\n`, {
        bold: true,
        fontSize: { magnitude: 12, unit: 'PT' },
        foregroundColor: { color: { rgbColor: { 
            red: report.recommendation === "Strong Recommend" ? 0.04 : 0.94,
            green: report.recommendation === "Strong Recommend" ? 0.73 : 0.73,
            blue: report.recommendation === "Strong Recommend" ? 0.51 : 0.51
        }}}
    });

    // Overall Verdict
    addText(`FS-AI VERDICT\n`, { bold: true, fontSize: { magnitude: 12, unit: 'PT' } });
    addText(`${report.overall_verdict}\n\n`, { fontSize: { magnitude: 11, unit: 'PT' } });

    // Module Analyses
    const moduleConfigs = {
        calafat_analysis: { name: "CALAFAT MODE (Elite Talent Identifier)", fields: ['ceiling_score', 'risk_score', 'development_curve'] },
        brighton_analysis: { name: "BRIGHTON MODE (Market Inefficiency)", fields: ['hidden_gem_score', 'roi_score', 'market_value_trajectory'] },
        portuguese_analysis: { name: "PORTUGUESE PIPELINE", fields: ['flip_potential', 'adaptation_score', 'versatility_index'] },
        dortmund_analysis: { name: "DORTMUND MODE (Youth Acceleration)", fields: ['readiness_score', 'resilience_index', 'acceleration_curve'] },
        ajax_analysis: { name: "AJAX MODE (Technical DNA)", fields: ['technical_purity', 'positional_iq', 'academy_fit'] }
    };

    Object.entries(moduleConfigs).forEach(([key, config]) => {
        if (report[key]) {
            addText(`\n${config.name}\n`, { bold: true, fontSize: { magnitude: 11, unit: 'PT' } });
            
            config.fields.forEach(field => {
                if (report[key][field] !== undefined) {
                    const label = field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    const value = report[key][field];
                    addText(`  • ${label}: ${value}\n`, { fontSize: { magnitude: 10, unit: 'PT' } });
                }
            });
        }
    });

    // Additional Notes
    if (report.notes) {
        addText(`\n\nADDITIONAL NOTES\n`, { bold: true, fontSize: { magnitude: 11, unit: 'PT' } });
        addText(`${report.notes}\n`, { fontSize: { magnitude: 10, unit: 'PT' } });
    }

    // Footer
    addText(`\n\n---\nGenerated by FS-AI © 2025 | Football Scout Intelligence Platform`, {
        fontSize: { magnitude: 8, unit: 'PT' },
        foregroundColor: { color: { rgbColor: { red: 0.6, green: 0.6, blue: 0.6 } } }
    });

    return { requests };
}