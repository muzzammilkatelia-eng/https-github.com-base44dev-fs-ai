/**
 * Exports app data to Google Sheets
 * Requires Google Sheets OAuth connection
 */

export default async function exportToGoogleSheets({ base44, params }) {
    const { entityType, title } = params;

    try {
        // Get Google Sheets access token
        let sheetsToken;
        try {
            sheetsToken = await base44.asServiceRole.connectors.getAccessToken('googlesheets');
        } catch (error) {
            return {
                success: false,
                error: 'Google Sheets not connected. Please authorize Google Sheets integration first.'
            };
        }

        // Fetch data based on entity type
        let data = [];
        let headers = [];
        
        switch (entityType) {
            case 'ScoutingReport':
                data = await base44.asServiceRole.entities.ScoutingReport.list('-created_date', 100);
                headers = ['Player Name', 'Age', 'Position', 'Recommendation', 'Modules', 'Overall Verdict', 'Date'];
                data = data.map(r => [
                    r.player_name,
                    r.player_age,
                    r.position,
                    r.recommendation,
                    r.modules_activated?.join(', ') || '',
                    r.overall_verdict,
                    new Date(r.created_date).toLocaleDateString()
                ]);
                break;
                
            case 'Player':
                data = await base44.asServiceRole.entities.Player.list('-created_date', 100);
                headers = ['Name', 'Age', 'Position', 'Club', 'League', 'Nationality', 'Market Value', 'Contract Expiry', 'Date'];
                data = data.map(p => [
                    p.name,
                    p.age,
                    p.position,
                    p.current_club || '',
                    p.league || '',
                    p.nationality || '',
                    p.market_value || '',
                    p.contract_expiry || '',
                    new Date(p.created_date).toLocaleDateString()
                ]);
                break;
                
            case 'MatchSimulation':
                data = await base44.asServiceRole.entities.MatchSimulation.list('-created_date', 100);
                headers = ['Home Team', 'Away Team', 'Score', 'Home Formation', 'Away Formation', 'Date'];
                data = data.map(m => [
                    m.home_team,
                    m.away_team,
                    m.final_score,
                    m.home_formation,
                    m.away_formation,
                    new Date(m.created_date).toLocaleDateString()
                ]);
                break;
                
            case 'Sale':
                data = await base44.asServiceRole.entities.Sale.list('-created_date', 100);
                headers = ['Customer', 'Email', 'Product', 'Amount', 'Status', 'Period', 'Date'];
                data = data.map(s => [
                    s.customer_name || '',
                    s.customer_email,
                    s.product_type,
                    `£${s.amount}`,
                    s.status,
                    s.subscription_period,
                    new Date(s.created_date).toLocaleDateString()
                ]);
                break;
                
            default:
                return {
                    success: false,
                    error: 'Invalid entity type'
                };
        }

        // Create new spreadsheet
        const createResponse = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${sheetsToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                properties: {
                    title: title || `FS-AI ${entityType} Export - ${new Date().toLocaleDateString()}`
                }
            })
        });

        const spreadsheet = await createResponse.json();
        
        if (!spreadsheet.spreadsheetId) {
            throw new Error('Failed to create spreadsheet');
        }

        const spreadsheetId = spreadsheet.spreadsheetId;
        const sheetId = spreadsheet.sheets[0].properties.sheetId;

        // Prepare data with headers
        const values = [headers, ...data];

        // Update with data
        const updateResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:append?valueInputOption=RAW`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${sheetsToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    values: values
                })
            }
        );

        const updateResult = await updateResponse.json();

        // Format headers (bold)
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${sheetsToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                requests: [
                    {
                        repeatCell: {
                            range: {
                                sheetId: sheetId,
                                startRowIndex: 0,
                                endRowIndex: 1
                            },
                            cell: {
                                userEnteredFormat: {
                                    textFormat: {
                                        bold: true
                                    },
                                    backgroundColor: {
                                        red: 0.2,
                                        green: 0.7,
                                        blue: 0.9
                                    }
                                }
                            },
                            fields: 'userEnteredFormat(textFormat,backgroundColor)'
                        }
                    },
                    {
                        autoResizeDimensions: {
                            dimensions: {
                                sheetId: sheetId,
                                dimension: 'COLUMNS',
                                startIndex: 0,
                                endIndex: headers.length
                            }
                        }
                    }
                ]
            })
        });

        return {
            success: true,
            spreadsheetId: spreadsheetId,
            spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
            rowCount: data.length
        };

    } catch (error) {
        console.error('Google Sheets export error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}