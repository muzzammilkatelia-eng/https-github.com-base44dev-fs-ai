/**
 * Fetch data from AllSportsAPI
 * Provides real-time football data including fixtures, livescores, standings, players, etc.
 */

export default async function fetchAllSportsData({ base44, params }) {
    const { method, methodParams = {} } = params;
    
    // Get API key from secrets
    const apiKey = process.env.ALLSPORTS_API_KEY;
    
    if (!apiKey) {
        return {
            success: false,
            error: 'AllSportsAPI key not configured. Add ALLSPORTS_API_KEY to secrets.'
        };
    }

    try {
        // Build query parameters
        const queryParams = new URLSearchParams({
            met: method,
            APIkey: apiKey,
            ...methodParams
        });

        const url = `https://allsportsapi.com/api/football/?${queryParams.toString()}`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (data.success === 1) {
            return {
                success: true,
                data: data.result,
                method: method
            };
        } else {
            return {
                success: false,
                error: 'API request failed',
                data: data
            };
        }

    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}