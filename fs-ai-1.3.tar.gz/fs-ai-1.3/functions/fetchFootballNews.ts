import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const { region, league, categories = ['transfers', 'injuries', 'results'], limit = 25 } = payload || {};

    const now = new Date();
    const sinceHours = 12; // last 12 hours
    const prompt = `Aggregate LIVE football news from reputable sources (BBC Sport, Sky Sports, The Athletic, official club sites, UEFA/FIFA, Transfermarkt, Opta):\n
Return top ${limit} items from the last ${sinceHours} hours. Include transfer updates, injury news, and league results.\n
Filters (optional):\n- Region: ${region || 'Any'}\n- League: ${league || 'Any'}\n- Categories: ${(categories || []).join(', ') || 'transfers, injuries, results'}\n- Current time: ${now.toISOString()}\n
For each item provide: title, summary, category (transfer|injury|result|other), source_name, url, published_at (ISO), region, league, teams (array), players (array). Prefer official sources where possible.`;

    const schema = {
      type: 'object',
      properties: {
        items: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              summary: { type: 'string' },
              category: { type: 'string' },
              source_name: { type: 'string' },
              url: { type: 'string' },
              published_at: { type: 'string' },
              region: { type: 'string' },
              league: { type: 'string' },
              teams: { type: 'array', items: { type: 'string' } },
              players: { type: 'array', items: { type: 'string' } }
            }
          }
        }
      },
      required: ['items']
    };

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: schema
    });

    // Optional: basic filtering client-side safety
    let items = Array.isArray(result.items) ? result.items : [];
    if (region) items = items.filter(i => (i.region || '').toLowerCase().includes(region.toLowerCase()));
    if (league) items = items.filter(i => (i.league || '').toLowerCase().includes(league.toLowerCase()));
    if (categories?.length) items = items.filter(i => categories.includes((i.category || '').toLowerCase()));

    return Response.json({ items });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});