/**
 * Fetch real-time football data from AllSportsAPI
 * Supports fixtures, livescores, players, teams, standings, and more
 */

export default async function fetchLiveFootballData({ base44, params, secrets }) {
    const { method, options = {} } = params;
    const apiKey = secrets.ALLSPORTS_API_KEY;

    if (!apiKey) {
        return { 
            success: false, 
            error: 'AllSportsAPI key not configured. Add it in Dashboard → Settings → Secrets' 
        };
    }

    try {
        const baseUrl = 'https://allsportsapi.com/api/football/';
        let url = `${baseUrl}?met=${method}&APIkey=${apiKey}`;

        // Add optional parameters based on method
        if (options.from) url += `&from=${options.from}`;
        if (options.to) url += `&to=${options.to}`;
        if (options.countryId) url += `&countryId=${options.countryId}`;
        if (options.leagueId) url += `&leagueId=${options.leagueId}`;
        if (options.matchId) url += `&matchId=${options.matchId}`;
        if (options.teamId) url += `&teamId=${options.teamId}`;
        if (options.playerId) url += `&playerId=${options.playerId}`;
        if (options.playerName) url += `&playerName=${encodeURIComponent(options.playerName)}`;
        if (options.firstTeamId) url += `&firstTeamId=${options.firstTeamId}`;
        if (options.secondTeamId) url += `&secondTeamId=${options.secondTeamId}`;
        if (options.timezone) url += `&timezone=${options.timezone}`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }

        const data = await response.json();

        if (data.success === 1) {
            return {
                success: true,
                data: data.result,
                method: method
            };
        } else {
            return {
                success: false,
                error: 'API returned unsuccessful response',
                data: data
            };
        }

    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}