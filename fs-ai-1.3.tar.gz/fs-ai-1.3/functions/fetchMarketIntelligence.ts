/**
 * Fetches real-time transfer market intelligence
 * Used for globe heatmap updates and market trend analysis
 */

export default async function fetchMarketIntelligence({ base44, params }) {
    const { regions, includeTopPlayers } = params;

    try {
        const regionsText = regions?.join(', ') || 'Brazil, Argentina, France, Netherlands, Nigeria, Portugal, Belgium, Spain, Germany, Japan';

        const prompt = `Access Transfermarkt, BBC Sport, Sky Sports, and transfer news sources for REAL-TIME transfer market intelligence as of December 23, 2025.

For each major football region (${regionsText}), provide:

1. **Region Data:**
   - Region name and country
   - Exact coordinates (lat/lng)
   - Number of high-potential players currently monitored
   - Average market value of top prospects
   - Regional risk level for transfers

2. **Market Metrics:**
   - Total market value of available talent (€M)
   - Average age of prospects
   - Transfer activity (number of deals last 30 days)
   - Value delta % (undervalued vs market perception)
   - Market trajectory with specific indicators

3. **Top 3-4 Players Per Region:**
   - Full name (REAL current players)
   - Current club and league
   - Position
   - Age and date of birth
   - Current market value (€M) from Transfermarkt
   - Contract expiry date
   - Recent performance (goals/assists in last 10 games OR defensive stats)
   - Transfer interest level and rumored clubs
   - 3-4 performance tags (e.g., "15 goals in 18 games", "€25M valuation")

4. **Intelligence:**
   - Recent major transfers in region
   - Development pathway recommendations
   - Current risk factors with examples
   - Emerging talent trends

Use ONLY verified, current data from December 2025. Include real player names and accurate statistics.`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt: prompt,
            add_context_from_internet: true,
            response_json_schema: {
                type: "object",
                properties: {
                    timestamp: { type: "string" },
                    market_summary: { type: "string" },
                    total_market_value: { type: "number" },
                    regions: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                region: { type: "string" },
                                country: { type: "string" },
                                lat: { type: "number" },
                                lng: { type: "number" },
                                player_count: { type: "number" },
                                avg_market_value: { type: "number" },
                                risk_level: { type: "string" },
                                transfer_activity: { type: "number" },
                                value_delta: { type: "number" },
                                trajectory: { type: "string" },
                                top_players: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            name: { type: "string" },
                                            club: { type: "string" },
                                            league: { type: "string" },
                                            position: { type: "string" },
                                            age: { type: "number" },
                                            date_of_birth: { type: "string" },
                                            market_value: { type: "number" },
                                            contract_expiry: { type: "string" },
                                            recent_performance: { type: "string" },
                                            transfer_interest: { type: "string" },
                                            tags: { type: "array", items: { type: "string" } }
                                        }
                                    }
                                },
                                recent_transfers: { type: "string" },
                                pathway: { type: "string" },
                                risk_factors: { type: "string" },
                                trends: { type: "string" }
                            }
                        }
                    }
                }
            }
        });

        // Transform to match globe format
        const hotspots = response.regions.map(region => ({
            region: region.region,
            country: region.country,
            lat: region.lat,
            lng: region.lng,
            count: region.player_count,
            avgScore: Math.min(95, 50 + (region.avg_market_value || 0) * 2),
            riskLevel: region.risk_level,
            valueDelta: region.value_delta,
            trajectory: region.trajectory,
            topPlayers: region.top_players.map(player => ({
                name: player.name,
                position: player.position,
                age: player.age,
                score: Math.min(100, 60 + (player.market_value || 0)),
                market_value: player.market_value,
                contract_expiry: player.contract_expiry,
                recent_performance: player.recent_performance,
                tags: player.tags
            })),
            pathway: region.pathway,
            riskFactors: region.risk_factors
        }));

        return {
            success: true,
            data: {
                hotspots,
                market_summary: response.market_summary,
                timestamp: response.timestamp
            }
        };
    } catch (error) {
        console.error('Market intelligence fetch error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}