import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { action, params } = await req.json();

        const API_KEY = Deno.env.get('API_FOOTBALL_KEY');
        
        if (!API_KEY) {
            return Response.json({ error: 'API_FOOTBALL_KEY not configured' }, { status: 500 });
        }

        let result;

        switch (action) {
            case 'latest_matches':
                result = await fetchLatestMatches(API_KEY);
                break;
            
            case 'match_by_id':
                result = await fetchMatchById(API_KEY, params.matchId);
                break;
            
            case 'latest_player_updates':
                result = await fetchLatestPlayerUpdates(API_KEY);
                break;
            
            case 'team_news':
                result = await fetchTeamNews(API_KEY, params.teamName);
                break;
            
            case 'league_table':
                result = await fetchLeagueTable(API_KEY, params.leagueId);
                break;
            
            case 'fixtures':
                result = await fetchFixtures(API_KEY, params.leagueId);
                break;
            
            default:
                return Response.json({ error: 'Invalid action' }, { status: 400 });
        }

        return Response.json({ success: true, data: result });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});

async function fetchLatestMatches(apiKey) {
    const today = new Date().toISOString().split('T')[0];
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/fixtures?date=${today}`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch latest matches');
    }

    const data = await response.json();
    return data.response || [];
}

async function fetchMatchById(apiKey, matchId) {
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/fixtures?id=${matchId}`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch match');
    }

    const data = await response.json();
    return data.response?.[0] || null;
}

async function fetchLatestPlayerUpdates(apiKey) {
    // Fetch top player stats from major leagues
    const season = new Date().getFullYear();
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/players/topscorers?league=39&season=${season}`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch player updates');
    }

    const data = await response.json();
    return data.response || [];
}

async function fetchTeamNews(apiKey, teamId) {
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/teams?id=${teamId}`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch team news');
    }

    const data = await response.json();
    return data.response?.[0] || null;
}

async function fetchLeagueTable(apiKey, leagueId) {
    const season = new Date().getFullYear();
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/standings?league=${leagueId}&season=${season}`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch league table');
    }

    const data = await response.json();
    return data.response || [];
}

async function fetchFixtures(apiKey, leagueId) {
    const season = new Date().getFullYear();
    const response = await fetch(
        `https://api-football-v1.p.rapidapi.com/v3/fixtures?league=${leagueId}&season=${season}&next=10`,
        {
            headers: {
                'X-RapidAPI-Key': apiKey,
                'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
            }
        }
    );

    if (!response.ok) {
        throw new Error('Failed to fetch fixtures');
    }

    const data = await response.json();
    return data.response || [];
}