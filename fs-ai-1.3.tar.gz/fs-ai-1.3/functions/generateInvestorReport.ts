import { base44 } from '@base44/sdk/server';
import moment from 'moment';

export default async function generateInvestorReport(params, context) {
    const { frequency } = params;
    
    try {
        // Get all active investor contacts with matching frequency
        const contacts = await base44.asServiceRole.entities.InvestorContact.filter({
            active: true,
            report_frequency: frequency || 'monthly'
        });

        if (contacts.length === 0) {
            return { success: true, message: 'No active contacts for this frequency' };
        }

        // Fetch data for metrics
        const [scouts, users, sales, reports, messages] = await Promise.all([
            base44.asServiceRole.entities.Scout.list(),
            base44.asServiceRole.entities.User.list(),
            base44.asServiceRole.entities.Sale.list(),
            base44.asServiceRole.entities.ScoutingReport.list(),
            base44.asServiceRole.entities.ScoutMessage.list()
        ]);

        // Calculate metrics
        const totalUsers = scouts.length + users.length;
        const activeScouts = scouts.filter(s => s.status === 'Active').length;
        
        // Calculate MRR
        const monthlyRevenue = sales.reduce((sum, sale) => {
            const amount = sale.amount || 0;
            const monthlyAmount = sale.subscription_period === 'annual' ? amount / 12 : amount;
            return sum + monthlyAmount;
        }, 0);
        
        const currentMonth = moment().format('MMM YYYY');
        const reportsThisMonth = reports.filter(r => 
            moment(r.created_date).format('MMM YYYY') === currentMonth
        ).length;
        
        const messagesThisMonth = messages.filter(m => 
            moment(m.created_date).format('MMM YYYY') === currentMonth
        ).length;

        // Calculate growth rate
        const lastMonth = moment().subtract(1, 'month').format('MMM YYYY');
        const usersLastMonth = [...scouts, ...users].filter(u => 
            moment(u.created_date).format('MMM YYYY') <= lastMonth
        ).length;
        const growthRate = usersLastMonth > 0 ? 
            (((totalUsers - usersLastMonth) / usersLastMonth) * 100).toFixed(1) : 0;

        const conversionRate = scouts.length > 0 ? 
            ((activeScouts / scouts.length) * 100).toFixed(1) : 0;

        // Generate report content
        const reportContent = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px; margin-bottom: 30px; }
        .metric-card { background: #f8f9fa; border-left: 4px solid #667eea; padding: 20px; margin-bottom: 20px; border-radius: 5px; }
        .metric-title { font-size: 14px; color: #666; margin-bottom: 5px; }
        .metric-value { font-size: 32px; font-weight: bold; color: #333; margin-bottom: 10px; }
        .metric-description { font-size: 14px; color: #666; }
        .section { margin-bottom: 30px; }
        .footer { text-align: center; color: #666; font-size: 12px; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FS-AI Investor Report</h1>
        <p>${moment().format('MMMM YYYY')} - ${frequency === 'quarterly' ? 'Quarterly' : 'Monthly'} Update</p>
    </div>

    <div class="section">
        <h2>📈 User Growth</h2>
        <div class="metric-card">
            <div class="metric-title">Total Users</div>
            <div class="metric-value">${totalUsers.toLocaleString()}</div>
            <div class="metric-description">Scouts and Clubs combined</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Growth Rate (MoM)</div>
            <div class="metric-value">${growthRate}%</div>
            <div class="metric-description">Month-over-month user growth</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Active Scouts</div>
            <div class="metric-value">${activeScouts}</div>
            <div class="metric-description">Actively scouting on the platform</div>
        </div>
    </div>

    <div class="section">
        <h2>💰 Revenue Metrics</h2>
        <div class="metric-card">
            <div class="metric-title">Monthly Recurring Revenue</div>
            <div class="metric-value">£${Math.round(monthlyRevenue).toLocaleString()}</div>
            <div class="metric-description">Current MRR</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Annual Run Rate</div>
            <div class="metric-value">£${Math.round(monthlyRevenue * 12).toLocaleString()}</div>
            <div class="metric-description">Projected ARR</div>
        </div>
    </div>

    <div class="section">
        <h2>⚡ Engagement Metrics</h2>
        <div class="metric-card">
            <div class="metric-title">Reports Generated This Month</div>
            <div class="metric-value">${reportsThisMonth}</div>
            <div class="metric-description">Scouting reports created</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Messages Sent This Month</div>
            <div class="metric-value">${messagesThisMonth}</div>
            <div class="metric-description">Platform communications</div>
        </div>
    </div>

    <div class="section">
        <h2>🤝 Partnership Metrics</h2>
        <div class="metric-card">
            <div class="metric-title">Total Scout Network</div>
            <div class="metric-value">${scouts.length}</div>
            <div class="metric-description">Scouts in the pipeline</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Conversion Rate</div>
            <div class="metric-value">${conversionRate}%</div>
            <div class="metric-description">Scout activation rate</div>
        </div>
    </div>

    <div class="footer">
        <p><strong>FS-AI Football Scout Intelligence</strong></p>
        <p>Powered by Minimax Sustainable AI Ltd</p>
        <p>This is an automated report. For questions, contact director@minimax-sustainable-ai.com</p>
    </div>
</body>
</html>
        `;

        // Send emails to all contacts
        const emailPromises = contacts.map(contact => 
            base44.integrations.Core.SendEmail({
                to: contact.email,
                subject: `FS-AI ${frequency === 'quarterly' ? 'Quarterly' : 'Monthly'} Investor Report - ${moment().format('MMMM YYYY')}`,
                body: reportContent
            }).then(() => 
                base44.asServiceRole.entities.InvestorContact.update(contact.id, {
                    last_report_sent: new Date().toISOString()
                })
            )
        );

        await Promise.all(emailPromises);

        return {
            success: true,
            reportsSent: contacts.length,
            recipients: contacts.map(c => c.email)
        };
    } catch (error) {
        console.error('Failed to generate investor report:', error);
        return { success: false, error: error.message };
    }
}