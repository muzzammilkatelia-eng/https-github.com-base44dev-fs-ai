import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json().catch(() => ({}));
    const regions = payload.regions || [];
    const horizon = typeof payload.horizon_months === 'number' ? payload.horizon_months : 6;

    // Fetch previous forecasts for trend continuity (last 3)
    let previous = [];
    try {
      previous = await base44.asServiceRole.entities.MarketForecast.list('-created_date', 3);
    } catch (_) {
      previous = [];
    }

    const prevSummary = previous.map((f, i) => (
      `#${i + 1} (${f.time_horizon_months}m): ${f.forecast_summary}`
    )).join('\n');

    const prompt = `You are an elite football market analyst. Using CURRENT information from reputable sources (Transfermarkt, FIFA, UEFA, top football media), produce a 6–12 month forecast for global player value trends and talent hotspots.\n\nContext to consider:\n- Today: ${new Date().toISOString()}\n- Requested regions (optional): ${regions.join(', ') || 'Global'}\n- Previous internal summaries (for continuity):\n${prevSummary || 'None'}\n\nTasks:\n1) Identify emerging REGION-LEVEL HOTSPOTS with expected value growth %, confidence, risk level, top positions, and reasoning.\n2) List specific UNDERVALUE TARGETS (players) with current vs fair value, undervaluation %, interested clubs (if any), and rationale.\n3) Summarize MARKET RISKS and a short METHODOLOGY.\n4) Be specific and based on current events, form, transfer rumors, and economic conditions.\n`;

    const schema = {
      type: 'object',
      properties: {
        forecast_summary: { type: 'string' },
        time_horizon_months: { type: 'number' },
        emerging_hotspots: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              region: { type: 'string' },
              country: { type: 'string' },
              expected_value_growth_pct: { type: 'number' },
              confidence: { type: 'number' },
              risk_level: { type: 'string' },
              top_positions: { type: 'array', items: { type: 'string' } },
              trend_reason: { type: 'string' }
            }
          }
        },
        undervalued_players: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              position: { type: 'string' },
              age: { type: 'number' },
              current_value_eur_m: { type: 'number' },
              fair_value_eur_m: { type: 'number' },
              undervaluation_pct: { type: 'number' },
              clubs_interested: { type: 'array', items: { type: 'string' } },
              rationale: { type: 'string' }
            }
          }
        },
        market_risks: { type: 'array', items: { type: 'string' } },
        methodology: { type: 'string' },
        timestamp: { type: 'string' }
      },
      required: ['forecast_summary', 'emerging_hotspots', 'undervalued_players']
    };

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: schema
    });

    const forecast = {
      forecast_summary: result.forecast_summary || 'Market forecast generated.',
      time_horizon_months: horizon,
      regions,
      emerging_hotspots: result.emerging_hotspots || [],
      undervalued_players: result.undervalued_players || [],
      market_risks: result.market_risks || [],
      methodology: result.methodology || 'LLM synthesis with live context',
      timestamp: result.timestamp || new Date().toISOString()
    };

    // Save forecast for historical tracking
    const saved = await base44.entities.MarketForecast.create(forecast);

    return Response.json({ success: true, forecast, saved_id: saved.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});