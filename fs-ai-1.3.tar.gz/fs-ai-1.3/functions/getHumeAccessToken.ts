import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const HUME_API_KEY = Deno.env.get("HUME_API_KEY");
        const HUME_CONFIG_ID = Deno.env.get("HUME_CONFIG_ID");

        if (!HUME_API_KEY) {
            return Response.json({ error: 'HUME_API_KEY not configured' }, { status: 500 });
        }

        // Get access token from Hume API
        const response = await fetch('https://api.hume.ai/oauth2-cc/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                grant_type: 'client_credentials',
                client_id: HUME_API_KEY.split(':')[0],
                client_secret: HUME_API_KEY.split(':')[1],
            }),
        });

        if (!response.ok) {
            const error = await response.text();
            return Response.json({ error: 'Failed to get Hume access token', details: error }, { status: 500 });
        }

        const data = await response.json();

        return Response.json({
            access_token: data.access_token,
            config_id: HUME_CONFIG_ID || null
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});