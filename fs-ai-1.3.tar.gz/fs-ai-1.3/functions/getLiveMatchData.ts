import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { matchId } = await req.json();

        // Simulate live match data (in production, fetch from API Football or similar)
        const minute = Math.floor(Math.random() * 90) + 1;
        const events = generateMatchEvents(minute);
        const stats = generateLiveStats(minute);
        const insights = generateTacticalInsights(stats, events);
        const momentum = calculateMomentum(events);

        return Response.json({
            matchId,
            minute,
            events,
            stats,
            insights,
            momentum,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});

function generateMatchEvents(minute) {
    const eventTypes = ['goal', 'shot', 'corner', 'foul', 'yellow_card', 'substitution', 'offside'];
    const teams = ['Home', 'Away'];
    const events = [];

    // Generate 0-3 events per update
    const numEvents = Math.floor(Math.random() * 4);
    
    for (let i = 0; i < numEvents; i++) {
        const type = eventTypes[Math.floor(Math.random() * eventTypes.length)];
        const team = teams[Math.floor(Math.random() * teams.length)];
        const player = `Player ${Math.floor(Math.random() * 11) + 1}`;
        
        events.push({
            type,
            team,
            player,
            minute: Math.max(1, minute - Math.floor(Math.random() * 3)),
            impact: Math.random() * 10
        });
    }

    return events;
}

function generateLiveStats(minute) {
    const progress = minute / 90;
    
    return {
        possession: {
            home: 45 + Math.random() * 10,
            away: 45 + Math.random() * 10
        },
        shots: {
            home: Math.floor(progress * 15 + Math.random() * 5),
            away: Math.floor(progress * 12 + Math.random() * 5)
        },
        shotsOnTarget: {
            home: Math.floor(progress * 7 + Math.random() * 3),
            away: Math.floor(progress * 6 + Math.random() * 3)
        },
        corners: {
            home: Math.floor(progress * 6 + Math.random() * 2),
            away: Math.floor(progress * 5 + Math.random() * 2)
        },
        fouls: {
            home: Math.floor(progress * 10 + Math.random() * 3),
            away: Math.floor(progress * 8 + Math.random() * 3)
        },
        xG: {
            home: (progress * 1.5 + Math.random() * 0.5).toFixed(2),
            away: (progress * 1.2 + Math.random() * 0.5).toFixed(2)
        }
    };
}

function generateTacticalInsights(stats, events) {
    const insights = [];
    
    // Possession analysis
    if (stats.possession.home > 60) {
        insights.push({
            type: 'tactical',
            message: 'Home team dominating possession, controlling the tempo',
            severity: 'info'
        });
    }
    
    // Shot efficiency
    const homeEfficiency = stats.shotsOnTarget.home / stats.shots.home;
    if (homeEfficiency > 0.6) {
        insights.push({
            type: 'performance',
            message: 'Home team showing clinical finishing - high shot accuracy',
            severity: 'success'
        });
    }
    
    // xG analysis
    if (parseFloat(stats.xG.home) > 2.0) {
        insights.push({
            type: 'tactical',
            message: 'Home team creating high-quality chances - defense under pressure',
            severity: 'warning'
        });
    }
    
    // Event-based insights
    const recentGoals = events.filter(e => e.type === 'goal');
    if (recentGoals.length > 0) {
        insights.push({
            type: 'event',
            message: `GOAL! ${recentGoals[0].team} team scores - momentum shift detected`,
            severity: 'critical'
        });
    }
    
    return insights;
}

function calculateMomentum(events) {
    let homeMomentum = 50;
    let awayMomentum = 50;
    
    events.forEach(event => {
        const impact = event.impact;
        
        if (event.team === 'Home') {
            if (event.type === 'goal') {
                homeMomentum += impact * 2;
                awayMomentum -= impact;
            } else if (event.type === 'shot') {
                homeMomentum += impact * 0.5;
            }
        } else {
            if (event.type === 'goal') {
                awayMomentum += impact * 2;
                homeMomentum -= impact;
            } else if (event.type === 'shot') {
                awayMomentum += impact * 0.5;
            }
        }
    });
    
    // Normalize to 0-100
    const total = homeMomentum + awayMomentum;
    return {
        home: Math.round((homeMomentum / total) * 100),
        away: Math.round((awayMomentum / total) * 100)
    };
}