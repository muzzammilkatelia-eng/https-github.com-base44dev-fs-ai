import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        const user = await base44.auth.me();
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { databaseId } = await req.json();

        if (!databaseId) {
            return Response.json({ 
                error: 'Database ID required. Please provide your Notion database ID.' 
            }, { status: 400 });
        }

        // Get Notion access token
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('notion');

        // Query the database
        const response = await fetch(
            `https://api.notion.com/v1/databases/${databaseId}/query`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Notion-Version': '2022-06-28',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    page_size: 100
                })
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Notion API error: ${errorData.message || response.statusText}`);
        }

        const data = await response.json();

        // Process the results to extract checklist items
        const tasks = data.results.map(page => {
            const properties = page.properties;
            
            // Extract common property types
            const getName = (prop) => {
                if (prop.title) return prop.title[0]?.plain_text || 'Untitled';
                if (prop.rich_text) return prop.rich_text[0]?.plain_text || '';
                return '';
            };

            const getCheckbox = (prop) => prop?.checkbox || false;
            
            const getSelect = (prop) => prop?.select?.name || '';
            
            const getPerson = (prop) => {
                if (prop?.people && prop.people.length > 0) {
                    return prop.people[0].name || prop.people[0].id;
                }
                return null;
            };

            return {
                id: page.id,
                name: getName(properties.Name || properties.Task || properties.Title),
                completed: getCheckbox(properties.Completed || properties.Done || properties.Status),
                assignee: getPerson(properties.Assignee || properties.Owner),
                category: getSelect(properties.Category || properties.Type),
                created: page.created_time,
                updated: page.last_edited_time
            };
        });

        // Calculate progress
        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(t => t.completed).length;
        const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

        // Group by category
        const byCategory = {};
        tasks.forEach(task => {
            const cat = task.category || 'Uncategorized';
            if (!byCategory[cat]) {
                byCategory[cat] = { tasks: [], completed: 0, total: 0 };
            }
            byCategory[cat].tasks.push(task);
            byCategory[cat].total++;
            if (task.completed) byCategory[cat].completed++;
        });

        return Response.json({
            success: true,
            tasks,
            totalTasks,
            completedTasks,
            progressPercentage,
            byCategory
        });

    } catch (error) {
        console.error('Notion onboarding error:', error);
        return Response.json({ 
            success: false,
            error: error.message 
        }, { status: 500 });
    }
});