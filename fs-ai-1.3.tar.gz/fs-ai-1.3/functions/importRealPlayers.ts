/**
 * Import real football players from API-Football
 * Call this function to populate your Player entity with real player data
 */

export default async function importRealPlayers({ base44, params, secrets }) {
    const API_KEY = secrets.API_FOOTBALL_KEY;
    const { league_id = 39, season = 2024, team_id } = params; // Default: Premier League 2024
    
    try {
        // Fetch teams from league if no specific team
        let teams = [];
        if (team_id) {
            teams = [{ team: { id: team_id } }];
        } else {
            const teamsResponse = await fetch(
                `https://v3.football.api-sports.io/teams?league=${league_id}&season=${season}`,
                {
                    headers: {
                        'x-rapidapi-key': API_KEY,
                        'x-rapidapi-host': 'v3.football.api-sports.io'
                    }
                }
            );
            const teamsData = await teamsResponse.json();
            teams = teamsData.response?.slice(0, 5) || []; // Limit to 5 teams
        }

        let importedCount = 0;
        const errors = [];

        for (const teamData of teams) {
            try {
                // Fetch squad for each team
                const squadResponse = await fetch(
                    `https://v3.football.api-sports.io/players/squads?team=${teamData.team.id}`,
                    {
                        headers: {
                            'x-rapidapi-key': API_KEY,
                            'x-rapidapi-host': 'v3.football.api-sports.io'
                        }
                    }
                );
                const squadData = await squadResponse.json();
                const players = squadData.response?.[0]?.players || [];

                // Import each player
                for (const player of players.slice(0, 10)) { // Limit to 10 players per team
                    try {
                        // Check if player already exists
                        const existing = await base44.asServiceRole.entities.Player.filter({
                            name: player.name
                        });
                        
                        if (existing.length > 0) continue;

                        // Map position
                        const positionMap = {
                            'Goalkeeper': 'Goalkeeper',
                            'Defender': 'Centre-Back',
                            'Midfielder': 'Central Midfielder',
                            'Attacker': 'Striker'
                        };

                        await base44.asServiceRole.entities.Player.create({
                            name: player.name,
                            age: player.age || 25,
                            position: positionMap[player.position] || 'Central Midfielder',
                            current_club: teamData.team.name,
                            league: 'Premier League',
                            nationality: 'Unknown',
                            market_value: (player.number || 20) * 2, // Estimate based on squad number
                            physical_attributes: {
                                height: 180,
                                weight: 75,
                                pace: 70,
                                strength: 70,
                                stamina: 75
                            },
                            playing_style: {
                                preferred_foot: 'Right',
                                work_rate: 'Medium'
                            },
                            watch_status: 'Watching',
                            notes: `Imported from ${teamData.team.name} - Squad #${player.number || 'N/A'}`
                        });
                        
                        importedCount++;
                    } catch (err) {
                        errors.push(`Failed to import ${player.name}: ${err.message}`);
                    }
                }
            } catch (err) {
                errors.push(`Failed to fetch squad for team ${teamData.team.id}: ${err.message}`);
            }
        }

        return {
            success: true,
            imported_count: importedCount,
            errors: errors,
            message: `Successfully imported ${importedCount} players`
        };

    } catch (error) {
        return {
            success: false,
            error: error.message,
            message: 'Failed to import players from API-Football'
        };
    }
}