import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const SNAPSHOT_TYPES = [
  'league_overview',
  'fixtures',
  'standings',
  'transfers',
  'rankings',
  'player_stats',
  'team_stats',
  'hot_players',
  'awards',
  'streaks',
  'other'
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await req.json().catch(() => ({}));
    const {
      source = 'footballdatabase.eu',
      region = null,
      league = null,
      season = null,
      tag = null,
      gender = null,
      raw_text = null,
      snapshots = null
    } = payload || {};

    let parsedSnapshots = Array.isArray(snapshots) ? snapshots : [];

    if (!parsedSnapshots.length && raw_text) {
      const prompt = `You are a strict data parser. Parse the provided football text into multiple structured snapshots.

Return an object with an array 'snapshots'. Each snapshot must include:
- snapshot_type (one of: ${SNAPSHOT_TYPES.join(', ')})
- region (string, inherit '${region || ''}' if not explicit)
- league (string, inherit '${league || ''}' if not explicit)
- season (string, inherit '${season || ''}' if not explicit)
- gender ("male"|"female", inherit '${gender || ''}' if not explicit)
- title (short string)
- timestamp (ISO if found, else now)
- data (structured fields from the section; keep keys concise, arrays where appropriate)

Group sections such as: standings table, fixtures, official transfers, rankings (scorers/assists), player/club stats, streaks, league overview. Avoid hallucinations; only extract from text.

TEXT START\n${raw_text}\nTEXT END`;

      const schema = {
        type: 'object',
        properties: {
          snapshots: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                snapshot_type: { type: 'string' },
                region: { type: 'string' },
                league: { type: 'string' },
                season: { type: 'string' },
                gender: { type: 'string' },
                title: { type: 'string' },
                timestamp: { type: 'string' },
                data: { type: 'object' }
              },
              required: ['snapshot_type', 'data']
            }
          }
        },
        required: ['snapshots']
      };

      const res = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: schema
      });

      parsedSnapshots = Array.isArray(res.snapshots) ? res.snapshots : [];
    }

    if (!parsedSnapshots.length) {
      return Response.json({ error: 'No snapshots provided or parsed' }, { status: 400 });
    }

    // Normalize and validate
    const nowIso = new Date().toISOString();
    const records = parsedSnapshots.map((s) => {
      const safeType = SNAPSHOT_TYPES.includes(s.snapshot_type) ? s.snapshot_type : 'other';
      return {
        source,
        tag: tag || s.tag || undefined,
        region: s.region || region || undefined,
        league: s.league || league || undefined,
        season: s.season || season || undefined,
        gender: s.gender || gender || undefined,
        snapshot_type: safeType,
        data: s.data || {},
        timestamp: s.timestamp || nowIso
      };
    });

    // Persist in bulk
    const inserted = await base44.asServiceRole.entities.ExternalFootballSnapshot.bulkCreate(records);

    return Response.json({ success: true, count: inserted.length || records.length, ids: inserted.map?.(r => r.id).filter(Boolean) || [] });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});