import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// One-click ingestion of the user's pasted global FDB dataset
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const TAG = 'fdb_global_2025_12_30';
    const SOURCE = 'footballdatabase.eu';

    // Deduplicate by tag+source
    const existing = await base44.asServiceRole.entities.ExternalFootballSnapshot.filter({ tag: TAG, source: SOURCE }, '-created_date', 1);
    if (Array.isArray(existing) && existing.length > 0) {
      return Response.json({ success: true, alreadyIngested: true, count: existing.length });
    }

    // Raw text provided by user
    const raw_text = `627 869 Numbe of players in the database of footballdatabase.eu, covering the whole world of football. You can find on this page information on football players in our database and also those who are at the top at the moment. You can also find past players who have made football what it is now or also not well known players who haven't made history but contributed to football locally. There are also 28 849 managers in our database. Search for a player or a manager 2025* best worldwide scorersLast updated on 30/12/2025 at 04:46 Players Goals Kylian Mbappé 66 Harry Kane 60 Erling Haaland 57 Victor Osimhen 46 Vangelis Pavlidis 45 Cristiano Ronaldo 40 Roger Guedes 39 Ollie Pearce 36 Serhou Guirassy 36 Paulinho 34 Ivan Toney 34 Lautaro Martínez 34 Viktor Gyökeres 34 Guilherme Bissoli 33 Marcos Leonardo 32

This ranking is based on official matches played during the whole year, all competitions included, like international ones for example, at every level, among all competitions covered by footballdatabase.eu. 2025* best worldwide passersLast updated on 30/12/2025 at 04:46 Players Assists Michael Olise 25 Xherdan Shaqiri 25 Alexis Vega 24 Akram Afif 23 Lamine Yamal 23 Rayan Cherki 23 Riyad Mahrez 23 Salem Al Dawsari 22 Bradley Barcola 21 Raphinha 19 Manor Solomon 19 Ivan Perisic 18 Joshua Kimmich 18 Luis Suárez 17 Luke Molyneux 17 Best players of the last 12 months per positionLast updated on 23/12/2025 goalkeeper photo David Raya David Raya 87 photo Gianluigi Donnarumma Gianluigi Donnarumma 100 photo Agustin Rossi Agustin Rossi 77 4.Mile Svilar65 5.Thibaut Courtois64 6.Emiliano Martinez55 7.Anatoliy Trubin54 8.Diogo Costa53 9.Yann Sommer53 10.Lukas Hornicek50 Full back photo Nuno Mendes Nuno Mendes 80 photo Achraf Hakimi Achraf Hakimi 100 photo Jurrien Timber Jurrien Timber 60 4.Pedro Porro60 5.Daniel Muñoz58 6.Reece James55 7.Daniel Svensson53 8.Jules Koundé51 9.Marc Cucurella51 10.Konrad Laimer49 Central defender photo Ezri Konsa Ezri Konsa 87 photo Willian Pacho Willian Pacho 100 photo Gabriel Gabriel 80
Léo Pereira77 5.Josko Gvardiol75
Marquinhos74 7.William Saliba73 8.Virgil van Dijk72 9.Gianluca Mancini71 10.Evan Ndicka71 Central midfielder photo Mikel Merino Mikel Merino 89 photo Vitinha Vitinha 100 photo Fabián Ruiz Fabián Ruiz 80 4.Declan Rice78 5.Bruno Fernandes78
Pedri73 7.Tijjani Reijnders70 8.Ismael Saibari69 9.Martin Ödegaard68 10.João Neves67 offensive midfielder photo Raphinha Raphinha 96 photo Lamine Yamal Lamine Yamal 100 photo Michael Olise Michael Olise 94 4.Bradley Barcola85 5.Morgan Rogers82 6.Christos Tzolis81 7.Mohamed Salah79 8.Luis Díaz78
Vinícius Júnior72 10.Giorgian De Arrascaeta69 forward photo Erling Haaland Erling Haaland 99 photo Kylian Mbappé Kylian Mbappé 100 photo Harry Kane Harry Kane 96 4.Ousmane Dembélé78 5.Lautaro Martínez75 6.Julián Álvarez72 7.Khvicha Kvaratskhelia71 8.Vangelis Pavlidis70 9.Serhou Guirassy68 10.Désiré Doué60 Current serial scorersLast updated on 29/12/2025 at 21:29 Players Club Goals Consecutive games Lucas Schnepp Sarreguemines 23 13 D. Calvert-Lewin Leeds United 7 6 Rodrigo De Olivera Olancho 8 5 Chamsedin Kouranfal Pagny 7 4 Romano Postema Emmen 6 4 Julian Rijkhoff Almere City 5 4 Boubacar Konté Dila Gori 4 4 Vasilios Mantzis Kalamata FC 4 4 Michele Sego Hajduk Split 4 4 Mark Sifneos Kavala 4 4 Moses Usor LASK Linz 4 4 Nikola Vlasic Torino 4 4 Data Sichinava Sioni Bolnissi 6 3 Latest awards Reward Players Year MLS Best XI Lionel Messi Anders Dreyer Denis Bouanga Cristian Roldan Evander S. Berhalter Kai Wagner Jakob Glesnes Alex Freeman T. Blackmon Dayne St. Clair 2025 MLS Defender of the Year T. Blackmon 2025 MLS Comeback Player of the Year Nick Hagglund 2025 MLS Newcomer of the Year Anders Dreyer 2025 MLS Rookie of the Year Alex Freeman 2025 MLS Golden Boot Lionel Messi 2025 MLS Coach of the Year Bradley Carnell 2025 MLS Goalkeeper of the Year Dayne St. Clair 2025 MLS MVP Lionel Messi 2025 Golden Boy Désiré Doué 2025 Happy birthday Player Age Donato 63 years Randall Azofeifa 41 years Berti Vogts 79 years Domenico Criscito 39 years Sasa Ilic 48 years Pascal Baills 61 years Boubacar Barry Copa 46 years John van't Schip 62 years Scott Chipperfield 50 years Francis Benali 57 years Boris Pankratov 43 years Noel Whelan 51 years Oumar Dieng 53 years Ricardo 54 years Marcelo Díaz 39 years Latest videos D. Agustien December 08, 2025 by Luki_071
Radamel Falcao November 24, 2025 by Luki_071

Bojan Krkic November 24, 2025 by Luki_071

Danijel Subasic November 24, 2025 by Luki_071

Valère Germain November 24, 2025 by Luki_071

Rony Lopes November 24, 2025 by Luki_071

Most represented countries Countries Players France 81 628 Brazil 30 954 England 27 389 Germany 24 012 Italy 20 641 Spain 19 985 Argentina 15 485 Belgium 12 660 Russia 12 175 Norway 9 918 Netherlands 9 593 Peru 9 385 Sweden 9 167 Scotland 9 094 Ukraine 8 592 Latest players added Players Clubs Seung-ik No Paju Frontier Kasamu Kuradate Unknown Giovanni Stellitano Unknown Muaz Coskundag Unknown Vasilije Lekic Unknown Nicholas Bonaddio Pascoe Vale FC Alex Walter South Hobart Kylian Seka IFK Norrköping Vincent Johansson FBK Karlstad Yannick Roche Unknown Elies Agueni Unknown Kaiss Benahmed Unknown Hamza Boutfadin Vasalunds Naime Bouallegue Unknown Fathi Ben Mohamed Unknown logo footballdatabase.eu <<<< footballers bames and data add to the global market and data base`;

    // Invoke the general ingestion pipeline
    const invokeRes = await base44.asServiceRole.functions.invoke('ingestExternalSnapshots', {
      source: SOURCE,
      tag: TAG,
      raw_text,
      region: 'Global',
      league: null,
      season: '2025'
    });

    const data = invokeRes?.data || invokeRes; // normalize
    return Response.json({ success: true, ...data });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});