import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { prompt, response_json_schema, model = "gemini-1.5-flash", temperature = 0.7 } = await req.json();

    const apiKey = Deno.env.get("GOOGLE_API_KEY");
    if (!apiKey) {
        return Response.json({ error: "GOOGLE_API_KEY not set" }, { status: 500 });
    }

    // Direct REST API call to Gemini
    const apiVersion = "v1beta"; // or v1
    const modelName = model;
    const url = `https://generativelanguage.googleapis.com/${apiVersion}/models/${modelName}:generateContent?key=${apiKey}`;

    let generationConfig = {
        temperature: temperature,
    };

    if (response_json_schema) {
        generationConfig.responseMimeType = "application/json";
    }

    let finalPrompt = prompt;
    if (response_json_schema) {
        finalPrompt += `\n\nPlease output ONLY valid JSON matching this schema:\n${JSON.stringify(response_json_schema, null, 2)}`;
    }

    const requestBody = {
        contents: [{ parts: [{ text: finalPrompt }] }],
        generationConfig: generationConfig
    };

    const apiResponse = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(requestBody)
    });

    if (!apiResponse.ok) {
        const errorText = await apiResponse.text();
        console.error("Gemini API Error:", errorText);
        return Response.json({ error: `Gemini API Error: ${apiResponse.status} ${apiResponse.statusText}`, details: errorText }, { status: 500 });
    }

    const result = await apiResponse.json();
    
    // Extract text from response
    // Response structure: candidates[0].content.parts[0].text
    let text = result.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!text) {
        return Response.json({ error: "No content generated from Gemini", raw_response: result }, { status: 500 });
    }

    let data = text;
    if (response_json_schema) {
        // Clean up markdown code blocks if present (Gemini sometimes adds them even with JSON mode)
        text = text.replace(/```json/g, '').replace(/```/g, '').trim();
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error("Failed to parse Gemini JSON:", text);
            return Response.json({ error: "Failed to parse JSON response from Gemini", raw: text }, { status: 500 });
        }
    } else {
        data = { text };
    }

    return Response.json(data);

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});