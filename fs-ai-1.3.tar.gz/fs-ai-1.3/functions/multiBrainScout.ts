import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { player_profile, context } = await req.json();

        if (!player_profile || !player_profile.name) {
            return Response.json({ error: 'Player profile required' }, { status: 400 });
        }

        // Parallel execution of all four brain analyses
        const [deepView, creativeView, riskView, summaryView] = await Promise.all([
            analyzeDeepPattern(base44, player_profile, context),
            analyzeCreativeProjection(base44, player_profile, context),
            analyzeRiskScreen(base44, player_profile, context),
            analyzeSummaryDecision(base44, player_profile, context)
        ]);

        // Aggregate all views into final report
        const finalReport = aggregateViews(deepView, creativeView, riskView, summaryView);

        return Response.json({
            views: {
                deep: deepView,
                creative: creativeView,
                risk: riskView,
                summary: summaryView
            },
            final: finalReport
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});

// Brain 1: Smart Deep Brain (5.1 GPT archetype) - Pattern recognition and tactical understanding
async function analyzeDeepPattern(base44, player_profile, context) {
    const prompt = `You are a deep tactical analyst focused on pattern recognition and game understanding.

Player Profile:
${JSON.stringify(player_profile, null, 2)}

Context:
${JSON.stringify(context, null, 2)}

Provide a DEEP TACTICAL ANALYSIS focusing on:
1. How they read game structure and patterns
2. Their role within team systems
3. Decision-making intelligence and timing
4. Tactical flexibility and positional awareness

Be analytical, pattern-focused, and tactical in your assessment.`;

    const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
            type: "object",
            properties: {
                rating: { type: "number", minimum: 0, maximum: 10 },
                summary: { type: "string" },
                notes: { type: "array", items: { type: "string" } },
                tactical_iq: { type: "number", minimum: 0, maximum: 10 },
                pattern_recognition: { type: "string" }
            }
        }
    });

    return {
        label: "deep_pattern",
        ...response
    };
}

// Brain 2: Creative Vision Brain (Gemini style) - Creative upside and projection
async function analyzeCreativeProjection(base44, player_profile, context) {
    const prompt = `You are a creative scout who spots unusual potential and future roles.

Player Profile:
${JSON.stringify(player_profile, null, 2)}

Context:
${JSON.stringify(context, null, 2)}

Provide a CREATIVE PROJECTION focusing on:
1. Unusual positional fits or role adaptations
2. Future potential in different systems
3. Ceiling assessment and growth trajectory
4. Unique qualities that others might miss

Think creatively about what this player could become.`;

    const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
            type: "object",
            properties: {
                rating: { type: "number", minimum: 0, maximum: 10 },
                summary: { type: "string" },
                notes: { type: "array", items: { type: "string" } },
                ceiling: { type: "number", minimum: 0, maximum: 10 },
                future_roles: { type: "array", items: { type: "string" } }
            }
        }
    });

    return {
        label: "creative_projection",
        ...response
    };
}

// Brain 3: Cautious Risk Brain (Claude style) - Risk assessment and floor analysis
async function analyzeRiskScreen(base44, player_profile, context) {
    const prompt = `You are a cautious risk analyst focused on identifying concerns and floor assessment.

Player Profile:
${JSON.stringify(player_profile, null, 2)}

Context:
${JSON.stringify(context, null, 2)}

Provide a RISK ASSESSMENT focusing on:
1. Red flags and amber warnings
2. Mentality and consistency concerns
3. Floor performance level
4. Adaptation risks and weaknesses

Be thorough in identifying potential issues. It's better to be cautious.`;

    const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
            type: "object",
            properties: {
                rating: { type: "number", minimum: 0, maximum: 10 },
                summary: { type: "string" },
                notes: { type: "array", items: { type: "string" } },
                risk_level: { type: "string", enum: ["low", "medium", "high"] },
                red_flags: { type: "array", items: { type: "string" } },
                floor_rating: { type: "number", minimum: 0, maximum: 10 }
            }
        }
    });

    return {
        label: "risk_screen",
        ...response
    };
}

// Brain 4: Sharp Summary Brain (ChatGPT style) - Clear, concise decision
async function analyzeSummaryDecision(base44, player_profile, context) {
    const prompt = `You are a decisive scout who provides clear, actionable summaries.

Player Profile:
${JSON.stringify(player_profile, null, 2)}

Context:
${JSON.stringify(context, null, 2)}

Provide a SHARP SUMMARY focusing on:
1. Three key strengths
2. Three key concerns
3. Clear decision: Sign, Monitor, or Pass
4. One-sentence headline

Be concise and actionable. No fluff.`;

    const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
            type: "object",
            properties: {
                rating: { type: "number", minimum: 0, maximum: 10 },
                summary: { type: "string" },
                notes: { type: "array", items: { type: "string" } },
                decision: { type: "string", enum: ["sign", "monitor", "pass"] },
                headline: { type: "string" },
                key_strengths: { type: "array", items: { type: "string" } },
                key_concerns: { type: "array", items: { type: "string" } }
            }
        }
    });

    return {
        label: "summary_decision",
        ...response
    };
}

// Aggregate all views into final consensus
function aggregateViews(deepView, creativeView, riskView, summaryView) {
    const avgRating = (
        deepView.rating + 
        creativeView.rating + 
        riskView.rating + 
        summaryView.rating
    ) / 4;

    const ratings = [deepView.rating, creativeView.rating, riskView.rating, summaryView.rating];
    const variance = Math.sqrt(
        ratings.reduce((sum, r) => sum + Math.pow(r - avgRating, 2), 0) / ratings.length
    );
    
    const confidence = Math.max(0, Math.min(1, 1 - (variance / 5)));

    // Determine consensus decision
    let decision = summaryView.decision;
    if (riskView.risk_level === "high" && avgRating < 7) {
        decision = "pass";
    } else if (avgRating >= 8 && creativeView.ceiling >= 9) {
        decision = "sign";
    } else if (avgRating >= 6) {
        decision = "monitor";
    }

    return {
        decision,
        confidence: parseFloat(confidence.toFixed(2)),
        average_rating: parseFloat(avgRating.toFixed(1)),
        variance: parseFloat(variance.toFixed(2)),
        headline: summaryView.headline,
        consensus: generateConsensus(deepView, creativeView, riskView, summaryView, avgRating)
    };
}

function generateConsensus(deepView, creativeView, riskView, summaryView, avgRating) {
    const points = [];
    
    if (deepView.tactical_iq >= 8) points.push("High tactical intelligence");
    if (creativeView.ceiling >= 9) points.push("Elite ceiling potential");
    if (riskView.risk_level === "low") points.push("Low risk profile");
    if (riskView.risk_level === "high") points.push("Significant risk factors");
    if (avgRating >= 8) points.push("Strong consensus rating");
    if (avgRating < 6) points.push("Below target threshold");

    return points.join(" • ");
}