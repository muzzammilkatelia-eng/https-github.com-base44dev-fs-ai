export default async function notifyDocumentApproval({ documentId, documentType }, { base44 }) {
    try {
        // Fetch the document details
        let document;
        let title;
        let approvedBy;
        
        if (documentType === 'collaborative_report') {
            const reports = await base44.asServiceRole.entities.CollaborativeReport.list();
            document = reports.find(r => r.id === documentId);
            title = document?.title || 'Untitled Report';
            approvedBy = document?.last_edited_by || 'Unknown';
        } else if (documentType === 'secure_document') {
            const docs = await base44.asServiceRole.entities.SecureDocument.list();
            document = docs.find(d => d.id === documentId);
            title = document?.title || 'Untitled Document';
            approvedBy = document?.created_by || 'Unknown';
        } else {
            return { success: false, error: 'Invalid document type' };
        }

        if (!document) {
            return { success: false, error: 'Document not found' };
        }

        // Get Slack access token
        const slackToken = await base44.asServiceRole.connectors.getAccessToken('slack');
        
        if (!slackToken) {
            return { 
                success: false, 
                error: 'Slack not connected. Please authorize Slack integration first.' 
            };
        }

        // Prepare message
        const message = {
            channel: '#announcements',
            text: `📢 Document Approved: ${title}`,
            blocks: [
                {
                    type: 'header',
                    text: {
                        type: 'plain_text',
                        text: '✅ Document Approved',
                        emoji: true
                    }
                },
                {
                    type: 'section',
                    fields: [
                        {
                            type: 'mrkdwn',
                            text: `*Document:*\n${title}`
                        },
                        {
                            type: 'mrkdwn',
                            text: `*Type:*\n${documentType === 'collaborative_report' ? 'Collaborative Report' : 'Secure Document'}`
                        },
                        {
                            type: 'mrkdwn',
                            text: `*Approved By:*\n${approvedBy}`
                        },
                        {
                            type: 'mrkdwn',
                            text: `*Date:*\n${new Date().toLocaleDateString()}`
                        }
                    ]
                }
            ]
        };

        if (documentType === 'collaborative_report' && document.player_name) {
            message.blocks.push({
                type: 'section',
                fields: [
                    {
                        type: 'mrkdwn',
                        text: `*Player:*\n${document.player_name}`
                    }
                ]
            });
        }

        // Send to Slack
        const response = await fetch('https://slack.com/api/chat.postMessage', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${slackToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(message)
        });

        const result = await response.json();

        if (!result.ok) {
            return { 
                success: false, 
                error: result.error || 'Failed to send Slack notification' 
            };
        }

        return { 
            success: true, 
            message: 'Announcement posted to Slack #announcements channel',
            slackMessageTs: result.ts
        };

    } catch (error) {
        console.error('Slack notification error:', error);
        return { 
            success: false, 
            error: error.message || 'Failed to send notification' 
        };
    }
}