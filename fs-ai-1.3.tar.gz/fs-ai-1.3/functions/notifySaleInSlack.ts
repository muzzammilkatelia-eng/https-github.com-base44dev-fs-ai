import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { saleId } = await req.json();
        const slackWebhookUrl = Deno.env.get('SLACK_WEBHOOK_URL');

        if (!slackWebhookUrl) {
            return Response.json({ 
                error: 'SLACK_WEBHOOK_URL not configured' 
            }, { status: 400 });
        }

        // Fetch sale details
        const sales = await base44.asServiceRole.entities.Sale.filter({ id: saleId });
        
        if (!sales || sales.length === 0) {
            return Response.json({
                success: false,
                error: 'Sale not found'
            }, { status: 404 });
        }

        const sale = sales[0];

        // Format sale message
        const emoji = sale.status === 'completed' ? '🎉' : '💰';
        
        const message = {
            text: `${emoji} New Sale Alert!`,
            blocks: [
                {
                    type: "header",
                    text: {
                        type: "plain_text",
                        text: `${emoji} New ${sale.product_type} Sale!`,
                        emoji: true
                    }
                },
                {
                    type: "section",
                    fields: [
                        {
                            type: "mrkdwn",
                            text: `*Customer:*\n${sale.customer_name || sale.customer_email}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*Amount:*\n£${sale.amount}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*Product:*\n${sale.product_type}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*Status:*\n${sale.status.toUpperCase()}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*Billing:*\n${sale.subscription_period}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*Payment:*\n${sale.payment_method}`
                        }
                    ]
                },
                {
                    type: "context",
                    elements: [
                        {
                            type: "mrkdwn",
                            text: `Sale ID: ${sale.id} | ${new Date(sale.created_date).toLocaleString()}`
                        }
                    ]
                }
            ]
        };

        if (sale.notes) {
            message.blocks.push({
                type: "section",
                text: {
                    type: "mrkdwn",
                    text: `*Notes:*\n${sale.notes}`
                }
            });
        }

        // Send to Slack via webhook
        const response = await fetch(slackWebhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(message)
        });

        if (!response.ok) {
            throw new Error(`Slack webhook failed: ${response.statusText}`);
        }

        // Update sale record
        await base44.asServiceRole.entities.Sale.update(saleId, {
            slack_notified: true
        });

        return Response.json({
            success: true,
            message: 'Slack notification sent successfully'
        });

    } catch (error) {
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});