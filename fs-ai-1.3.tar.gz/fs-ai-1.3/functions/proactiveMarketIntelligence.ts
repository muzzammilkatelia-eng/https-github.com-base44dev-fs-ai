import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // 1. Fetch live data concurrently
        const [marketRes, newsRes] = await Promise.all([
            base44.functions.invoke('fetchMarketIntelligence', { regions: [], includeTopPlayers: true }),
            base44.functions.invoke('fetchFootballNews', { categories: ['transfers'], limit: 15 })
        ]);

        const marketData = marketRes?.data?.data || {}; // fetchMarketIntelligence returns { data: { hotspots... } }
        const newsData = newsRes?.data?.items || [];

        // 2. Synthesize Intelligence & Alerts
        const prompt = `
        You are FS-AI's Chief Market Analyst. Synthesize a Proactive Market Briefing and generate Alerts based on the following live data.

        MARKET INTELLIGENCE SUMMARY:
        ${marketData.market_summary || 'No summary available.'}

        HOTSPOTS & TRENDS:
        ${(marketData.hotspots || []).slice(0, 5).map(h => 
            `- ${h.region}: ${h.trajectory} (Risk: ${h.riskLevel}, Value Delta: ${h.valueDelta}%)`
        ).join('\n')}

        LATEST NEWS HEADLINES:
        ${newsData.slice(0, 8).map(n => `- ${n.title}: ${n.summary}`).join('\n')}

        TASK 1: Generate a "Market Briefing" (max 100 words).
        - Summarize the biggest opportunity and the biggest risk in the current market.
        - Mention one key emerging trend.

        TASK 2: Identify specific "Proactive Alerts".
        - Identify 2-3 specific undervaluation opportunities or significant market shifts.
        - Identify 1 high-priority transfer news item that requires immediate attention.
        - For each, provide a title, type (price_drop, talent_match, transfer_news), priority, and message.

        TASK 3: Generate a "Quick Action" recommendation.
        - One concrete action the user should take (e.g., "Scout [Player] in [Region]", "Review [Region] Defenders").
        `;

        const schema = {
            type: "object",
            properties: {
                briefing: { type: "string" },
                quick_action: { type: "string" },
                alerts: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            title: { type: "string" },
                            type: { type: "string", enum: ["price_drop", "talent_match", "transfer_news", "market_trend"] },
                            priority: { type: "string", enum: ["medium", "high", "urgent"] },
                            message: { type: "string" }
                        },
                        required: ["title", "type", "priority", "message"]
                    }
                }
            },
            required: ["briefing", "alerts", "quick_action"]
        };

        const analysis = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: schema
        });

        // 3. Create Notifications for Alerts
        if (analysis.alerts && analysis.alerts.length > 0) {
            // Filter for high/urgent priority to notify
            const highPriorityAlerts = analysis.alerts.filter(a => ['high', 'urgent'].includes(a.priority));
            
            // We create notifications asynchronously
            await Promise.all(highPriorityAlerts.map(alert => 
                base44.entities.Notification.create({
                    user_email: user.email,
                    type: alert.type === 'market_trend' ? 'price_drop' : alert.type, // Map to existing enum if needed
                    title: alert.title,
                    message: alert.message,
                    priority: alert.priority,
                    read: false,
                    metadata: { source: 'proactive_ai' }
                })
            ));
        }

        return Response.json({
            briefing: analysis.briefing,
            quick_action: analysis.quick_action,
            alerts: analysis.alerts,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Proactive Intelligence Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});