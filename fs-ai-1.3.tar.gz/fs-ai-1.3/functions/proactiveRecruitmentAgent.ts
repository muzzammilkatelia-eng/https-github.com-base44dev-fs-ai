import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Fetch active AI scouting criteria
        const criteria = await base44.asServiceRole.entities.AIScoutingCriteria.filter({ active: true });
        
        if (criteria.length === 0) {
            return Response.json({ 
                message: 'No active scouting criteria',
                shortlisted: [],
                reports: []
            });
        }

        // Fetch all players from database
        const players = await base44.asServiceRole.entities.Player.list('-updated_date', 500);

        const results = [];

        for (const criterion of criteria) {
            // Filter players based on criteria
            const matchedPlayers = players.filter(player => {
                const filters = criterion.filters || {};
                
                // Age filter
                if (filters.min_age && player.age < filters.min_age) return false;
                if (filters.max_age && player.age > filters.max_age) return false;
                
                // Position filter
                if (filters.positions?.length > 0 && !filters.positions.includes(player.position)) return false;
                
                // Market value filter
                if (filters.max_valuation && player.market_value > filters.max_valuation) return false;
                
                // Region filter
                if (filters.regions?.length > 0 && !filters.regions.includes(player.nationality)) return false;
                
                return true;
            });

            // Generate AI reports for top matches
            for (const player of matchedPlayers.slice(0, 5)) {
                const report = await base44.asServiceRole.integrations.Core.InvokeLLM({
                    prompt: `You are an elite football recruitment analyst. Generate a concise recruitment report for this player.

**Player Profile:**
Name: ${player.name}
Age: ${player.age}
Position: ${player.position}
Club: ${player.current_club || 'Unknown'}
Market Value: €${player.market_value}M
Nationality: ${player.nationality}

**Recruitment Criteria:**
${criterion.name}
Type: ${criterion.criteria_type}
Priority: ${criterion.priority_level}

**Required Analysis:**
1. **Match Score (0-100)**: How well does this player fit the criteria?
2. **Key Strengths**: Top 3 strengths relevant to the role
3. **Concerns**: Any potential issues or risks
4. **Recruitment Verdict**: Immediate target, Monitor, or Pass
5. **One-Line Summary**: Single sentence verdict

Return JSON with: match_score, strengths (array), concerns (array), verdict, summary`,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            match_score: { type: "number" },
                            strengths: { type: "array", items: { type: "string" } },
                            concerns: { type: "array", items: { type: "string" } },
                            verdict: { type: "string" },
                            summary: { type: "string" }
                        }
                    }
                });

                // Create scouting task if auto-assign is enabled and match is good
                if (criterion.auto_assign && report.match_score >= 70 && criterion.default_assignee) {
                    await base44.asServiceRole.entities.ScoutingTask.create({
                        player_name: player.name,
                        assigned_to: criterion.default_assignee,
                        task_type: 'Deep Dive',
                        priority: criterion.priority_level,
                        status: 'Pending',
                        source: 'AI Flag',
                        criteria_met: [criterion.name],
                        player_data: {
                            age: player.age,
                            position: player.position,
                            current_valuation: player.market_value,
                            region: player.nationality
                        },
                        notes: `AI Recruitment Agent Match\n\nCriteria: ${criterion.name}\nMatch Score: ${report.match_score}/100\n\nSummary: ${report.summary}\n\nStrengths:\n${report.strengths.map(s => `• ${s}`).join('\n')}\n\nConcerns:\n${report.concerns.map(c => `• ${c}`).join('\n')}`
                    });
                }

                // Create alert if notification is enabled
                if (criterion.notification_enabled && report.match_score >= 75) {
                    await base44.asServiceRole.entities.Alert.create({
                        player_name: player.name,
                        alert_type: 'scouting_report',
                        criteria_name: criterion.name,
                        player_details: {
                            age: player.age,
                            position: player.position,
                            club: player.current_club,
                            market_value: player.market_value,
                            match_score: report.match_score,
                            verdict: report.verdict,
                            summary: report.summary
                        },
                        read: false,
                        notified_slack: false
                    });
                }

                results.push({
                    player_name: player.name,
                    player_id: player.id,
                    criterion: criterion.name,
                    match_score: report.match_score,
                    verdict: report.verdict,
                    summary: report.summary,
                    strengths: report.strengths,
                    concerns: report.concerns,
                    task_created: criterion.auto_assign && report.match_score >= 70,
                    alert_created: criterion.notification_enabled && report.match_score >= 75
                });
            }
        }

        // Sort by match score
        results.sort((a, b) => b.match_score - a.match_score);

        return Response.json({
            success: true,
            timestamp: new Date().toISOString(),
            criteria_processed: criteria.length,
            players_analyzed: results.length,
            shortlist: results.filter(r => r.match_score >= 75),
            all_results: results
        });

    } catch (error) {
        console.error('Proactive recruitment agent error:', error);
        return Response.json({ 
            error: error.message,
            stack: error.stack 
        }, { status: 500 });
    }
});