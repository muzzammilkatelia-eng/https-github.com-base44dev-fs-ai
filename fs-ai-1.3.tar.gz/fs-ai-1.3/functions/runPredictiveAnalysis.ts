/**
 * AI Predictive Market Analysis
 * Identifies rising stars, hidden gems, and investment risks
 */

export default async function runPredictiveAnalysis({ base44, params }) {
    try {
        const players = await base44.asServiceRole.entities.Player.list('-updated_date', 200);
        const reports = await base44.asServiceRole.entities.ScoutingReport.list('-created_date', 100);
        const projections = await base44.asServiceRole.entities.PlayerProjection.list('-created_date', 100);

        const playerData = players.slice(0, 50).map(player => {
            const playerReports = reports.filter(r => 
                r.player_name?.toLowerCase() === player.name?.toLowerCase()
            ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            return {
                name: player.name,
                age: player.age,
                position: player.position,
                current_club: player.current_club,
                league: player.league,
                market_value: player.market_value,
                injury_score: player.injury_prone_score,
                latest_rating: playerReports[0]?.overall_rating,
                reports_count: playerReports.length,
                trajectory: projection?.potential_trajectory,
                peak_rating: projection?.peak_potential_rating,
                years_to_peak: projection?.years_to_peak,
                risk_factors: projection?.risk_factors
            };
        });

        const prompt = `You are an elite football market intelligence AI. Analyze this player database and provide predictive insights:

PLAYER DATABASE (${playerData.length} players):
${playerData.map(p => `
- ${p.name} (${p.position}, ${p.age}y, ${p.current_club})
  Current Value: €${p.market_value || 'N/A'}M
  AI Rating: ${p.latest_rating || 'N/A'}/10
  Trajectory: ${p.trajectory || 'Unknown'}
  Peak Potential: ${p.peak_rating || 'N/A'}/10 in ${p.years_to_peak || 'N/A'} years
  Injury Risk: ${p.injury_score || 'N/A'}/100
  Reports: ${p.reports_count}
`).join('\n')}

Provide comprehensive predictive insights:

1. **Rising Stars** (5-8 players): Players likely to increase significantly in value (50%+ growth) in 1-2 years
   - Include current value, predicted value, growth %, and specific reasoning
   - Focus on young players (18-24) with elite trajectories

2. **Hidden Gems** (5-8 players): Currently undervalued players with high potential
   - Must have low current value (≤€10M) but high ratings or potential
   - Explain why they're undervalued and what makes them special

3. **Investment Risks** (3-5 players): Overvalued or declining players to avoid
   - High current value but declining trajectory, injury concerns, or age issues
   - Explain the specific risk factors

For each category, rank by confidence level and opportunity score.`;

        const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
            prompt: prompt,
            response_json_schema: {
                type: "object",
                properties: {
                    rising_stars: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                player_name: { type: "string" },
                                age: { type: "number" },
                                position: { type: "string" },
                                current_value: { type: "number" },
                                predicted_value_1yr: { type: "number" },
                                predicted_value_2yr: { type: "number" },
                                growth_percentage: { type: "number" },
                                confidence_level: { type: "string", enum: ["Very High", "High", "Medium"] },
                                reasoning: { type: "string" },
                                key_factors: { type: "array", items: { type: "string" } }
                            }
                        }
                    },
                    hidden_gems: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                player_name: { type: "string" },
                                age: { type: "number" },
                                position: { type: "string" },
                                current_value: { type: "number" },
                                fair_value: { type: "number" },
                                opportunity_score: { type: "number" },
                                why_undervalued: { type: "string" },
                                upside_potential: { type: "string" },
                                recommended_action: { type: "string" }
                            }
                        }
                    },
                    investment_risks: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                player_name: { type: "string" },
                                age: { type: "number" },
                                position: { type: "string" },
                                current_value: { type: "number" },
                                risk_level: { type: "string", enum: ["High", "Very High", "Critical"] },
                                risk_factors: { type: "array", items: { type: "string" } },
                                warning: { type: "string" }
                            }
                        }
                    }
                }
            }
        });

        return {
            success: true,
            insights: analysis,
            players_analyzed: playerData.length
        };

    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}