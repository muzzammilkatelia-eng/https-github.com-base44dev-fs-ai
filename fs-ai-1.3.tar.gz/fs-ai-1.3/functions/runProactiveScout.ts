/**
 * Proactive AI Scouting Agent
 * Monitors players based on criteria, generates reports, and creates alerts
 */

export default async function runProactiveScout({ base44, params }) {
    const { criteria_id, auto_generate_reports = true } = params;

    try {
        // Fetch criteria
        const criteria = criteria_id 
            ? await base44.asServiceRole.entities.AIScoutingCriteria.get(criteria_id)
            : (await base44.asServiceRole.entities.AIScoutingCriteria.filter({ active: true }))[0];

        if (!criteria) {
            return { success: false, message: 'No active criteria found' };
        }

        // Fetch all players
        const allPlayers = await base44.asServiceRole.entities.Player.list('-updated_date', 200);
        
        // Filter players based on criteria
        const matchingPlayers = allPlayers.filter(player => {
            const filters = criteria.filters || {};
            
            // Age filter
            if (filters.min_age && player.age < filters.min_age) return false;
            if (filters.max_age && player.age > filters.max_age) return false;
            
            // Position filter
            if (filters.positions?.length > 0 && !filters.positions.includes(player.position)) return false;
            
            // Market value filter
            if (filters.max_valuation && player.market_value > filters.max_valuation) return false;
            
            return true;
        });

        const scoutedPlayers = [];
        const createdReports = [];
        const createdTasks = [];

        // AI analysis of each matching player
        for (const player of matchingPlayers.slice(0, 10)) { // Limit to 10 per run
            try {
                // Check if player already has recent reports
                const existingReports = await base44.asServiceRole.entities.ScoutingReport.filter({
                    player_name: player.name
                });
                
                const recentReport = existingReports.find(r => {
                    const reportDate = new Date(r.created_date);
                    const daysSince = (Date.now() - reportDate.getTime()) / (1000 * 60 * 60 * 24);
                    return daysSince < 7;
                });

                if (recentReport) continue; // Skip if scouted recently

                // AI evaluation
                const prompt = `Evaluate this player for potential signing:

Player: ${player.name}
Age: ${player.age}
Position: ${player.position}
Current Club: ${player.current_club}
Market Value: €${player.market_value}M
Physical: ${JSON.stringify(player.physical_attributes)}
Playing Style: ${JSON.stringify(player.playing_style)}
Injury Risk: ${player.injury_prone_score}/100

Scouting Criteria: ${criteria.name}
Target Profile: ${JSON.stringify(criteria.filters)}

Provide:
1. Overall assessment (0-10 rating)
2. Is this player worth pursuing? (yes/no)
3. Key strengths (3-5 points)
4. Areas for improvement (3-5 points)
5. Estimated potential rating at peak
6. Recommended action (Immediate Contact, Monitor, Deep Dive, Pass)
7. Brief scouting note (2-3 sentences)`;

                const aiResponse = await base44.asServiceRole.integrations.Core.InvokeLLM({
                    prompt: prompt,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            overall_rating: { type: "number" },
                            worth_pursuing: { type: "boolean" },
                            strengths: { type: "array", items: { type: "string" } },
                            weaknesses: { type: "array", items: { type: "string" } },
                            potential_rating: { type: "number" },
                            recommended_action: { type: "string" },
                            scouting_note: { type: "string" }
                        }
                    }
                });

                scoutedPlayers.push({
                    player: player.name,
                    rating: aiResponse.overall_rating,
                    action: aiResponse.recommended_action
                });

                // Generate scouting report if player is promising
                if (auto_generate_reports && aiResponse.worth_pursuing && aiResponse.overall_rating >= 7) {
                    const report = await base44.asServiceRole.entities.ScoutingReport.create({
                        player_name: player.name,
                        scout_name: 'AI Proactive Agent',
                        match_attended: `AI Analysis - ${criteria.name}`,
                        overall_rating: aiResponse.overall_rating,
                        technical_rating: Math.min(10, aiResponse.overall_rating + 0.5),
                        physical_rating: Math.min(10, aiResponse.overall_rating),
                        mental_rating: Math.min(10, aiResponse.overall_rating - 0.5),
                        tactical_rating: Math.min(10, aiResponse.overall_rating),
                        strengths: aiResponse.strengths.join(', '),
                        weaknesses: aiResponse.weaknesses.join(', '),
                        overall_verdict: aiResponse.scouting_note,
                        recommendation: aiResponse.recommended_action === 'Immediate Contact' ? 'Immediate Signing' : 'Monitor Closely',
                        tags: [criteria.name, 'AI Generated', 'Proactive Scout']
                    });
                    createdReports.push(report);
                }

                // Create task if action required
                if (aiResponse.recommended_action !== 'Pass') {
                    const taskType = aiResponse.recommended_action === 'Immediate Contact' ? 'Initial Assessment' :
                                   aiResponse.recommended_action === 'Deep Dive' ? 'Deep Dive' : 'Initial Assessment';
                    
                    const task = await base44.asServiceRole.entities.ScoutingTask.create({
                        player_name: player.name,
                        task_type: taskType,
                        priority: aiResponse.overall_rating >= 8 ? 'High' : 'Medium',
                        status: 'Pending',
                        source: 'AI Flag',
                        criteria_met: [criteria.name],
                        assigned_to: criteria.default_assignee || 'unassigned',
                        player_data: {
                            age: player.age,
                            position: player.position,
                            current_valuation: player.market_value,
                            potential_rating: aiResponse.potential_rating,
                            region: player.league
                        },
                        notes: aiResponse.scouting_note
                    });
                    createdTasks.push(task);
                }

                // Create alert for high-potential players
                if (aiResponse.overall_rating >= 8) {
                    await base44.asServiceRole.entities.Alert.create({
                        player_name: player.name,
                        alert_type: 'scouting_report',
                        criteria_name: criteria.name,
                        player_details: {
                            age: player.age,
                            position: player.position,
                            rating: aiResponse.overall_rating,
                            action: aiResponse.recommended_action
                        },
                        read: false
                    });
                }

            } catch (error) {
                console.error(`Failed to scout ${player.name}:`, error);
            }
        }

        return {
            success: true,
            criteria_used: criteria.name,
            players_analyzed: scoutedPlayers.length,
            reports_generated: createdReports.length,
            tasks_created: createdTasks.length,
            scouted_players: scoutedPlayers,
            message: `Analyzed ${scoutedPlayers.length} players, created ${createdReports.length} reports and ${createdTasks.length} tasks`
        };

    } catch (error) {
        return {
            success: false,
            error: error.message,
            message: 'Proactive scout agent failed'
        };
    }
}