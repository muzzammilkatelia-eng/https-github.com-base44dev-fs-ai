import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { applyHonourGuard } from './safeguarding_layer.js';

/**
 * FOOTBALL SCOUT AI – CODE OF HONOUR
 *
 * 1. Safeguarding-first:
 *    - Any data relating to a child, vulnerable person, or safeguarding context
 *      is treated as strictly confidential and non-transferable.
 * ... (See safeguarding_layer.js for full code)
 */

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const { user_text, context } = await req.json();

        // Critical distress keywords (UK safeguarding tier 3 indicators)
        const criticalKeywords = [
            'kill myself', 'end it all', 'suicide', 'self harm', 'hurt myself',
            'want to die', 'no point living', 'better off dead', 'abuse',
            'being hurt', 'unsafe', 'scared', 'threatened'
        ];

        // Moderate concern indicators
        const concernKeywords = [
            'depressed', 'anxiety', 'panic', 'hopeless', 'alone', 'isolated',
            'worthless', 'struggling', 'can\'t cope', 'overwhelmed'
        ];

        const lowerText = user_text.toLowerCase();
        
        // Check for critical triggers
        const criticalMatch = criticalKeywords.some(keyword => lowerText.includes(keyword));
        const concernMatch = concernKeywords.some(keyword => lowerText.includes(keyword));

        // APPLY SAFEGUARDING GUARD
        // We redact any PII from the context before any processing that might log or expose it
        // Note: The 'user_text' is required for analysis, but we treat it as strictly confidential
        const guardResult = applyHonourGuard({
            tags: ['safeguarding'],
            payload: context || {},
            intent: 'internal' 
        });
        const safeContext = { payload: guardResult.payload };

        // Sentiment analysis via LLM
        // We pass the user_text (essential for function) but ensure context is cleaned
        const sentimentAnalysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
            prompt: `You are a safeguarding AI trained in UK NSPCC and social care protocols.

Analyze this user message for emotional distress indicators:

"${user_text}"

Assess:
1. **Emotional tone**: Critical distress, moderate concern, neutral, or positive
2. **Risk level**: Immediate (requires urgent intervention), Elevated (needs support), Low (no concern)
3. **Safeguarding trigger**: Does this indicate potential harm to self or others?
4. **Recommended action**: Halt and support, gentle check-in, continue normally

Return JSON only.`,
            response_json_schema: {
                type: "object",
                properties: {
                    emotional_tone: { type: "string" },
                    risk_level: { type: "string" },
                    safeguarding_trigger: { type: "boolean" },
                    recommended_action: { type: "string" },
                    concern_summary: { type: "string" }
                }
            }
        });

        // Determine safeguarding response
        let safeguardingMode = false;
        let responseLevel = 'NORMAL';

        if (criticalMatch || sentimentAnalysis.risk_level === 'Immediate') {
            safeguardingMode = true;
            responseLevel = 'CRITICAL';
        } else if (concernMatch || sentimentAnalysis.risk_level === 'Elevated') {
            safeguardingMode = true;
            responseLevel = 'MODERATE';
        }

        // Log incident if safeguarding triggered
        if (safeguardingMode) {
            const user = await base44.auth.isAuthenticated() ? await base44.auth.me() : null;
            
            await base44.asServiceRole.entities.SafeguardingIncident.create({
                user_email: user?.email || 'anonymous',
                incident_type: responseLevel,
                user_message: user_text,
                context: safeContext.payload, // Store redacted context only
                emotional_tone: sentimentAnalysis.emotional_tone,
                risk_level: sentimentAnalysis.risk_level,
                ai_assessment: sentimentAnalysis.concern_summary,
                action_taken: sentimentAnalysis.recommended_action,
                timestamp: new Date().toISOString()
            });

            // Notify admin via Slack if critical
            if (responseLevel === 'CRITICAL' && Deno.env.get('SLACK_WEBHOOK_URL')) {
                await fetch(Deno.env.get('SLACK_WEBHOOK_URL'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        text: `🚨 CRITICAL SAFEGUARDING ALERT`,
                        blocks: [{
                            type: "section",
                            text: {
                                type: "mrkdwn",
                                text: `*Critical Safeguarding Incident Detected*\n\n*User:* ${user?.email || 'Anonymous'}\n*Risk Level:* ${sentimentAnalysis.risk_level}\n*Concern:* ${sentimentAnalysis.concern_summary}\n\nImmediate review required.`
                            }
                        }]
                    })
                });
            }
        }

        return Response.json({
            safeguarding_mode: safeguardingMode,
            response_level: responseLevel,
            action: sentimentAnalysis.recommended_action,
            supportive_response: safeguardingMode ? getSupportiveResponse(responseLevel) : null,
            emotional_assessment: sentimentAnalysis,
            allow_continue: !safeguardingMode || responseLevel === 'MODERATE'
        });

    } catch (error) {
        console.error('Safeguarding monitor error:', error);
        return Response.json({ 
            error: error.message,
            safeguarding_mode: false,
            allow_continue: true
        }, { status: 500 });
    }
});

function getSupportiveResponse(level) {
    if (level === 'CRITICAL') {
        return {
            message: "I hear you, and I'm concerned for your wellbeing. What you're going through sounds really difficult.\n\nPlease reach out to someone who can help right now:\n\n🇬🇧 **Samaritans (UK):** 116 123 (24/7, free)\n🇬🇧 **PAPYRUS (Under 35s):** 0800 068 4141\n🌍 **Crisis Text Line:** Text SHOUT to 85258\n\nYou don't have to face this alone. These services are confidential and here to support you.",
            tone: "Reassuring and urgent",
            halt_interaction: true
        };
    } else if (level === 'MODERATE') {
        return {
            message: "I notice you might be going through a difficult time. It's okay to not be okay.\n\nIf you'd like to talk to someone:\n\n🇬🇧 **Samaritans:** 116 123\n🇬🇧 **Mind Infoline:** 0300 123 3393\n\nWould you like to continue, or would you prefer to take a break?",
            tone: "Gentle and supportive",
            halt_interaction: false
        };
    }
    
    return null;
}