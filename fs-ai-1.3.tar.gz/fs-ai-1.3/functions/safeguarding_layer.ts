// codeOfHonour.ts (Base44-safe)

export const NON_TRANSFERABLE_FIELDS = [
  "fullName",
  "dateOfBirth",
  "schoolName",
  "homeAddress",
  "contactNumber",
  "parentGuardianName",
  "safeguardingNotes",
  "incidentDetails",
];

export const SAFEGUARDING_TAGS = [
  "safeguarding",
  "child_protection",
  "welfare_concern",
];

export const CODE_OF_HONOUR = {
  stateless: true,
  allowExternal: false,
  allowThirdParty: false,
  allowAnalyticsExport: false,
};

// isSafeguarding.ts
export function isSafeguarding(tags = []) {
  return tags.some((t) => SAFEGUARDING_TAGS.includes(t));
}

// applyHonourGuard.ts
export function applyHonourGuard(ctx) {
  const safeguarding = isSafeguarding(ctx.tags);

  if (!safeguarding) {
    return { allowed: true, payload: ctx.payload };
  }

  // External use is forbidden
  if (ctx.intent === "external" || !CODE_OF_HONOUR.allowExternal) {
    return {
      allowed: false,
      reason:
        "CODE_OF_HONOUR_VIOLATION: Safeguarding data cannot leave the system.",
    };
  }

  // Redact sensitive fields
  const redacted = { ...ctx.payload };
  for (const field of NON_TRANSFERABLE_FIELDS) {
    if (field in redacted) {
      redacted[field] = "[REDACTED_SAFEGUARDING]";
    }
  }

  return {
    allowed: true,
    payload: redacted,
  };
}