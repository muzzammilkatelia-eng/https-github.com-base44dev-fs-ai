import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Minimal seed data for women's leagues
    const players = [
      { name: 'Sam Kerr', age: 32, position: 'Striker', gender: 'female', current_club: 'Chelsea', league: 'WSL', nationality: 'Australia' },
      { name: 'Alexia Putellas', age: 31, position: 'Attacking Midfielder', gender: 'female', current_club: 'Barcelona Femení', league: 'Liga F', nationality: 'Spain' },
      { name: 'Sophia Smith', age: 25, position: 'Winger', gender: 'female', current_club: 'Portland Thorns', league: 'NWSL', nationality: 'USA' },
      { name: 'Alexandra Popp', age: 34, position: 'Striker', gender: 'female', current_club: 'Wolfsburg', league: 'Frauen-Bundesliga', nationality: 'Germany' },
      { name: 'Aitana Bonmatí', age: 27, position: 'Central Midfielder', gender: 'female', current_club: 'Barcelona Femení', league: 'Liga F', nationality: 'Spain' }
    ];

    const snapshots = [
      { source: 'official', region: 'England', league: 'WSL', season: '2025/26', gender: 'female', snapshot_type: 'league_overview', data: { title: 'WSL Overview', teams: 12 } },
      { source: 'official', region: 'USA', league: 'NWSL', season: '2025', gender: 'female', snapshot_type: 'standings', data: { table: [] } },
      { source: 'official', region: 'Spain', league: 'Liga F', season: '2025/26', gender: 'female', snapshot_type: 'rankings', data: { top_scorers: [], top_passers: [] } },
      { source: 'official', region: 'Germany', league: 'Frauen-Bundesliga', season: '2025/26', gender: 'female', snapshot_type: 'fixtures', data: { items: [] } },
      { source: 'official', region: 'Europe', league: 'UWCL', season: '2025/26', gender: 'female', snapshot_type: 'hot_players', data: { players: [] } }
    ];

    const createdPlayers = await base44.asServiceRole.entities.Player.bulkCreate(players);
    const createdSnapshots = await base44.asServiceRole.entities.ExternalFootballSnapshot.bulkCreate(snapshots);

    return Response.json({ success: true, players: createdPlayers.length, snapshots: createdSnapshots.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});