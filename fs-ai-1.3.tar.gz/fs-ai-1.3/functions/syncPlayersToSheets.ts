export default async function syncPlayersToSheets(payload, context) {
    const { base44 } = context;
    
    try {
        // Get all players from database
        const players = await base44.asServiceRole.entities.Player.list();
        
        // Get Google Sheets access token
        const { access_token } = await base44.asServiceRole.connectors.getAccessToken('googlesheets');
        
        // Prepare data for sheets
        const headers = [
            'Name', 'Age', 'Position', 'Club', 'League', 'Nationality',
            'Market Value (€M)', 'FS-AI Score', 'Investment Grade', 
            'Archetype', 'Watch Status', 'Contract Expiry', 'Last Updated'
        ];
        
        const rows = players.map(p => [
            p.name || '',
            p.age || '',
            p.position || '',
            p.current_club || '',
            p.league || '',
            p.nationality || '',
            p.market_value || '',
            p.fsai_proprietary_score || '',
            p.fsai_investment_grade || '',
            p.fsai_archetype_primary || '',
            p.watch_status || '',
            p.contract_expiry || '',
            new Date(p.updated_date).toISOString()
        ]);
        
        const sheetData = [headers, ...rows];
        
        // Get or create spreadsheet
        const spreadsheetId = payload.spreadsheet_id;
        
        if (!spreadsheetId) {
            // Create new spreadsheet
            const createResponse = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${access_token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    properties: {
                        title: `FS-AI Player Database - ${new Date().toISOString().split('T')[0]}`
                    },
                    sheets: [{
                        properties: {
                            title: 'Players',
                            gridProperties: {
                                frozenRowCount: 1
                            }
                        }
                    }]
                })
            });
            
            const newSpreadsheet = await createResponse.json();
            const newSheetId = newSpreadsheet.spreadsheetId;
            
            // Update with data
            await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${newSheetId}/values/Players!A1:M${sheetData.length}?valueInputOption=RAW`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${access_token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    values: sheetData
                })
            });
            
            return {
                success: true,
                spreadsheet_id: newSheetId,
                spreadsheet_url: newSpreadsheet.spreadsheetUrl,
                rows_synced: players.length,
                message: 'New spreadsheet created and synced successfully'
            };
        } else {
            // Update existing spreadsheet
            // Clear existing data first
            await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Players!A1:M1000:clear`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${access_token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            // Write new data
            await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Players!A1:M${sheetData.length}?valueInputOption=RAW`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${access_token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    values: sheetData
                })
            });
            
            return {
                success: true,
                spreadsheet_id: spreadsheetId,
                rows_synced: players.length,
                message: 'Spreadsheet updated successfully'
            };
        }
        
    } catch (error) {
        console.error('Sheets sync failed:', error);
        return {
            success: false,
            error: error.message
        };
    }
}