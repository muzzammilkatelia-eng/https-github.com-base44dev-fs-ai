export default async function syncScoutingReportsToSheets(payload, context) {
    const { base44 } = context;
    
    try {
        // Get all scouting reports
        const reports = await base44.asServiceRole.entities.ScoutingReport.list();
        
        // Get Google Sheets access token
        const { access_token } = await base44.asServiceRole.connectors.getAccessToken('googlesheets');
        
        // Prepare data
        const headers = [
            'Player Name', 'Position', 'League', 'Age', 'Scout', 
            'Overall Rating', 'Technical', 'Physical', 'Mental', 'Tactical',
            'Recommendation', 'Scouted Date', 'Report ID'
        ];
        
        const rows = reports.map(r => [
            r.player_name || '',
            r.position || '',
            r.league || '',
            r.age || '',
            r.created_by || '',
            r.overall_rating || '',
            r.technical_rating || '',
            r.physical_rating || '',
            r.mental_rating || '',
            r.tactical_rating || '',
            r.recommendation || '',
            new Date(r.created_date).toISOString(),
            r.id || ''
        ]);
        
        const sheetData = [headers, ...rows];
        
        const spreadsheetId = payload.spreadsheet_id;
        
        if (!spreadsheetId) {
            return {
                success: false,
                error: 'spreadsheet_id required for scouting reports sync'
            };
        }
        
        // Create or update "Scouting Reports" sheet
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Scouting Reports!A1:M1000:clear`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${access_token}`,
                'Content-Type': 'application/json'
            }
        });
        
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Scouting Reports!A1:M${sheetData.length}?valueInputOption=RAW`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${access_token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                values: sheetData
            })
        });
        
        return {
            success: true,
            spreadsheet_id: spreadsheetId,
            rows_synced: reports.length,
            message: 'Scouting reports synced successfully'
        };
        
    } catch (error) {
        console.error('Reports sync failed:', error);
        return {
            success: false,
            error: error.message
        };
    }
}