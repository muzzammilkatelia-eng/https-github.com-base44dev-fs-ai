export default async function syncWyscoutDatabase(payload, context) {
    const { base44 } = context;
    const { integration_id, sync_options } = payload;

    try {
        const integration = await base44.asServiceRole.entities.ExternalIntegration.list();
        const wyscout = integration.find(i => i.id === integration_id);

        if (!wyscout || !wyscout.api_key_configured) {
            return {
                success: false,
                error: 'Wyscout integration not configured'
            };
        }

        const apiKey = wyscout.config?.api_key;
        const apiUrl = wyscout.api_endpoint || 'https://apirest.wyscout.com/v3';

        if (!apiKey) {
            return {
                success: false,
                error: 'API key not configured. Add to integration config.api_key'
            };
        }

        const syncResults = {
            areas: 0,
            competitions: 0,
            seasons: 0,
            teams: 0,
            players: 0,
            matches: 0,
            errors: []
        };

        // Sync Areas (Countries/Regions)
        if (sync_options?.areas) {
            try {
                const areasData = await fetchWyscout(`${apiUrl}/areas`, apiKey);
                syncResults.areas = areasData.areas?.length || 0;
                // Store in DataFeed for now (can be moved to dedicated entity)
                for (const area of areasData.areas || []) {
                    await base44.asServiceRole.entities.DataFeed.create({
                        player_name: 'System',
                        source: 'Wyscout',
                        data_type: 'Statistics',
                        data: {
                            type: 'area',
                            ...area
                        }
                    });
                }
            } catch (error) {
                syncResults.errors.push({ entity: 'areas', error: error.message });
            }
        }

        // Sync Competitions
        if (sync_options?.competitions) {
            try {
                const competitionsData = await fetchWyscout(`${apiUrl}/competitions`, apiKey);
                syncResults.competitions = competitionsData.competitions?.length || 0;
                
                for (const competition of competitionsData.competitions || []) {
                    await base44.asServiceRole.entities.DataFeed.create({
                        player_name: 'System',
                        source: 'Wyscout',
                        data_type: 'Statistics',
                        data: {
                            type: 'competition',
                            ...competition
                        }
                    });
                }
            } catch (error) {
                syncResults.errors.push({ entity: 'competitions', error: error.message });
            }
        }

        // Sync Teams
        if (sync_options?.teams) {
            try {
                const teamsData = await fetchWyscout(`${apiUrl}/teams`, apiKey, {
                    compId: sync_options.competition_ids
                });
                syncResults.teams = teamsData.teams?.length || 0;
                
                for (const team of teamsData.teams || []) {
                    await base44.asServiceRole.entities.DataFeed.create({
                        player_name: 'System',
                        source: 'Wyscout',
                        data_type: 'Statistics',
                        data: {
                            type: 'team',
                            ...team
                        }
                    });
                }
            } catch (error) {
                syncResults.errors.push({ entity: 'teams', error: error.message });
            }
        }

        // Sync Players (Enhanced)
        if (sync_options?.players) {
            try {
                const playersData = await fetchWyscout(`${apiUrl}/players`, apiKey, {
                    compSeasonId: sync_options.season_ids,
                    ageMin: sync_options.age_min,
                    ageMax: sync_options.age_max
                });
                
                for (const player of playersData.players || []) {
                    try {
                        const playerData = {
                            name: `${player.firstName} ${player.lastName}`,
                            age: calculateAge(player.birthDate),
                            position: mapWyscoutPosition(player.role?.name),
                            current_club: player.currentTeam?.name,
                            league: player.currentTeam?.competition?.name,
                            nationality: player.passportArea?.name,
                            market_value: player.marketValue,
                            physical_attributes: {
                                height: player.height,
                                weight: player.weight,
                                pace: null,
                                strength: null,
                                stamina: null
                            },
                            playing_style: {
                                preferred_foot: player.foot,
                                work_rate: 'Medium'
                            }
                        };

                        const existing = await base44.asServiceRole.entities.Player.filter({
                            name: playerData.name
                        });

                        if (existing.length === 0) {
                            await base44.asServiceRole.entities.Player.create(playerData);
                        } else {
                            await base44.asServiceRole.entities.Player.update(existing[0].id, playerData);
                        }
                        
                        syncResults.players++;
                    } catch (error) {
                        syncResults.errors.push({ 
                            entity: 'player', 
                            name: player.firstName + ' ' + player.lastName,
                            error: error.message 
                        });
                    }
                }
            } catch (error) {
                syncResults.errors.push({ entity: 'players', error: error.message });
            }
        }

        // Sync Matches
        if (sync_options?.matches) {
            try {
                const matchesData = await fetchWyscout(`${apiUrl}/matches`, apiKey, {
                    seasonId: sync_options.season_ids,
                    status: 'Played'
                });
                syncResults.matches = matchesData.matches?.length || 0;
                
                for (const match of matchesData.matches || []) {
                    await base44.asServiceRole.entities.DataFeed.create({
                        player_name: 'System',
                        source: 'Wyscout',
                        data_type: 'Statistics',
                        data: {
                            type: 'match',
                            ...match
                        }
                    });
                }
            } catch (error) {
                syncResults.errors.push({ entity: 'matches', error: error.message });
            }
        }

        // Update integration status
        await base44.asServiceRole.entities.ExternalIntegration.update(integration_id, {
            status: 'Active',
            last_sync: new Date().toISOString(),
            last_sync_count: syncResults.players + syncResults.teams + syncResults.competitions,
            players_synced: (wyscout.players_synced || 0) + syncResults.players
        });

        return {
            success: true,
            results: syncResults,
            message: `Synced ${syncResults.players} players, ${syncResults.teams} teams, ${syncResults.competitions} competitions`
        };

    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

async function fetchWyscout(url, apiKey, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const fullUrl = queryString ? `${url}?${queryString}` : url;
    
    const response = await fetch(fullUrl, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
        }
    });

    if (!response.ok) {
        throw new Error(`Wyscout API error: ${response.status} ${response.statusText}`);
    }

    return await response.json();
}

function calculateAge(birthDate) {
    if (!birthDate) return null;
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    return age;
}

function mapWyscoutPosition(wyscoutRole) {
    const mapping = {
        'Goalkeeper': 'Goalkeeper',
        'Defender': 'Centre-Back',
        'Full-back': 'Full-Back',
        'Midfielder': 'Central Midfielder',
        'Winger': 'Winger',
        'Forward': 'Striker',
        'Attacking Midfielder': 'Attacking Midfielder',
        'Defensive Midfielder': 'Defensive Midfielder'
    };
    return mapping[wyscoutRole] || 'Central Midfielder';
}