import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { isSafeguarding } from "./safeguarding_layer.js";

const PAYPAL_CONFIG = {
  email: "founder@al-isa-institute.com", // your verified PayPal
  label: "Support Football Scout AI",
  currency: "GBP",
  defaultAmount: 10.0,
};

function generatePayPalLink(amount) {
  const amt = amount || PAYPAL_CONFIG.defaultAmount;
  return `https://www.paypal.com/paypalme/${encodeURIComponent(
    PAYPAL_CONFIG.email.split("@")[0],
  )}/${amt}`;
}

export function triggerPayment(ctx) {
  if (isSafeguarding(ctx.tags)) {
    return {
      error:
        "CODE_OF_HONOUR_BLOCK: Payments cannot be triggered in safeguarding context.",
    };
  }

  return {
    link: generatePayPalLink(ctx.amount),
    message: "Payment link generated successfully.",
  };
}

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Ensure user is authenticated for payments
        const user = await base44.auth.me();
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json();
        // body: { tags: string[], amount: number }

        const result = triggerPayment(body);

        if (result.error) {
            return Response.json({ error: result.error }, { status: 403 }); // Forbidden
        }

        return Response.json(result);

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});