import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { player_name, club_context, market_info, mode = 'full' } = await req.json();

        if (!player_name) {
            return Response.json({ error: 'player_name required' }, { status: 400 });
        }

        // Default club context if not provided
        const clubProfile = club_context || {
            name: "Default Club",
            style: {
                pressing_intensity: 75,
                build_up_speed: 70,
                possession_focus: 65,
                transition_speed: 80
            },
            role_requirements: {},
            dna: {
                mentality: 75,
                work_rate: 80,
                adaptability: 70
            },
            wage_ceiling: 150000,
            transfer_budget: 50000000
        };

        const marketData = market_info || {
            estimated_value: 20000000,
            current_wage: 50000,
            target_wage: 80000
        };

        // STEP 1: Search Layer - Get Player Data
        let playerProfile;
        try {
            const players = await base44.entities.Player.filter({ name: player_name });
            if (players.length === 0) {
                return Response.json({ 
                    error: 'Player not found',
                    suggestion: 'Try creating the player first or check spelling'
                }, { status: 404 });
            }
            playerProfile = players[0];
        } catch (error) {
            return Response.json({ 
                error: 'Failed to fetch player data',
                details: error.message
            }, { status: 500 });
        }

        // STEP 2: Multi-Brain Scouting Analysis
        let multiBrainAnalysis = null;
        if (mode === 'full' || mode === 'scout') {
            try {
                const multiBrainResult = await base44.functions.invoke('multiBrainScout', {
                    player_profile: {
                        name: playerProfile.name,
                        age: playerProfile.age,
                        position: playerProfile.position,
                        metrics: playerProfile.physical_attributes || {}
                    },
                    context: {
                        club_style: clubProfile.style,
                        role: playerProfile.position
                    }
                });
                multiBrainAnalysis = multiBrainResult.data;
            } catch (error) {
                console.error('Multi-brain analysis failed:', error);
                multiBrainAnalysis = { error: 'Analysis unavailable' };
            }
        }

        // STEP 3: Rating Engine - Calculate Scout Summary
        const scoutSummary = calculateScoutSummary(playerProfile, clubProfile, multiBrainAnalysis);

        // STEP 4: Agent Finisher - Make Move Decision
        let agentDecision = null;
        if (mode === 'full' || mode === 'agent') {
            try {
                const finisherResult = await base44.asServiceRole.functions.invoke('agentFinisherMove', {
                    player_profile: {
                        name: playerProfile.name,
                        age: playerProfile.age,
                        position: playerProfile.position,
                        current_value: marketData.estimated_value,
                        current_wage: marketData.current_wage
                    },
                    scout_summary: {
                        ceiling: scoutSummary.ceiling,
                        floor: scoutSummary.floor,
                        fit: scoutSummary.fit,
                        risk: scoutSummary.risk,
                        final_rating: scoutSummary.final_rating
                    },
                    club_context: {
                        name: clubProfile.name,
                        transfer_budget: clubProfile.transfer_budget,
                        wage_ceiling: clubProfile.wage_ceiling,
                        style: clubProfile.style
                    },
                    target_wage: marketData.target_wage
                });
                agentDecision = finisherResult.data;
            } catch (error) {
                console.error('Agent finisher failed:', error);
                agentDecision = { error: 'Decision unavailable' };
            }
        }

        // STEP 5: Unified Output
        const unifiedReport = {
            timestamp: new Date().toISOString(),
            mode,
            player: {
                name: playerProfile.name,
                age: playerProfile.age,
                position: playerProfile.position,
                club: playerProfile.current_club,
                league: playerProfile.league,
                market_value: playerProfile.market_value
            },
            club: clubProfile,
            scout_summary: scoutSummary,
            multi_brain_analysis: multiBrainAnalysis,
            agent_decision: agentDecision,
            recommendations: generateRecommendations(scoutSummary, agentDecision),
            next_steps: generateNextSteps(scoutSummary, agentDecision)
        };

        return Response.json(unifiedReport);

    } catch (error) {
        console.error('Unified orchestrator error:', error);
        return Response.json({ 
            error: 'Orchestration failed',
            details: error.message
        }, { status: 500 });
    }
});

function calculateScoutSummary(player, club, multiBrainAnalysis) {
    // Extract metrics
    const physical = player.physical_attributes || {};
    const style = player.playing_style || {};
    const injuryScore = player.injury_prone_score || 50;

    // Use multi-brain ratings if available
    const brainRatings = multiBrainAnalysis?.views || {};
    const avgBrainRating = multiBrainAnalysis?.final?.average_rating || 70;

    // Ceiling calculation (potential)
    const technicalPotential = physical.pace || 70;
    const tacticalIQ = brainRatings.deep?.tactical_iq || 70;
    const creativeVision = brainRatings.creative?.ceiling || 70;
    
    const ceiling = (
        technicalPotential * 0.30 +
        tacticalIQ * 0.25 +
        creativeVision * 0.25 +
        avgBrainRating * 0.20
    );

    // Floor calculation (consistency)
    const physicalReliability = (100 - injuryScore);
    const mentalStrength = style.work_rate === 'High' ? 80 : style.work_rate === 'Medium' ? 65 : 50;
    const riskAssessment = brainRatings.risk?.floor || 65;

    const floor = (
        physicalReliability * 0.35 +
        mentalStrength * 0.35 +
        riskAssessment * 0.30
    );

    // Fit calculation
    const positionMatch = matchPosition(player.position, club.role_requirements);
    const styleMatch = matchStyle(style, club.style);
    
    const fit = (
        positionMatch * 0.50 +
        styleMatch * 0.50
    );

    // Risk calculation (lower is better)
    const injuryRisk = injuryScore;
    const ageRisk = calculateAgeRisk(player.age);
    const adaptationRisk = brainRatings.risk?.risk_level === 'high' ? 80 : 
                          brainRatings.risk?.risk_level === 'medium' ? 50 : 30;

    const risk = (
        injuryRisk * 0.40 +
        ageRisk * 0.30 +
        adaptationRisk * 0.30
    );

    // Final rating
    const final_rating = (
        ceiling * 0.35 +
        floor * 0.25 +
        fit * 0.25 +
        (100 - risk) * 0.15
    );

    return {
        ceiling: Math.round(ceiling * 10) / 10,
        floor: Math.round(floor * 10) / 10,
        fit: Math.round(fit * 10) / 10,
        risk: Math.round(risk * 10) / 10,
        final_rating: Math.round(final_rating * 10) / 10,
        confidence: multiBrainAnalysis?.final?.confidence || 0.75
    };
}

function matchPosition(position, requirements) {
    // Simple position matching - can be expanded
    if (!requirements || Object.keys(requirements).length === 0) return 75;
    
    const positionScore = requirements[position] || 60;
    return Math.min(100, positionScore);
}

function matchStyle(playerStyle, clubStyle) {
    if (!playerStyle || !clubStyle) return 70;

    const workRateMatch = playerStyle.work_rate === 'High' ? 
        (clubStyle.pressing_intensity || 70) : 
        (100 - (clubStyle.pressing_intensity || 70));

    return Math.min(100, workRateMatch);
}

function calculateAgeRisk(age) {
    if (age < 20) return 40; // Young, high potential variability
    if (age < 24) return 20; // Prime development
    if (age < 28) return 10; // Peak years
    if (age < 31) return 30; // Decline beginning
    return 60; // Significant decline risk
}

function generateRecommendations(summary, decision) {
    const recommendations = [];

    if (summary.ceiling > 80) {
        recommendations.push("High ceiling player - monitor closely for breakthrough");
    }

    if (summary.risk > 60) {
        recommendations.push("Risk assessment: Consider thorough medical and psychological evaluation");
    }

    if (summary.fit < 65) {
        recommendations.push("Tactical fit concerns - may require adaptation period");
    }

    if (decision?.move_type === 'push_move') {
        recommendations.push("Strategic opportunity - recommend immediate action");
    }

    if (summary.floor > 70 && summary.ceiling > 75) {
        recommendations.push("High floor + high ceiling = excellent investment profile");
    }

    return recommendations.length > 0 ? recommendations : ["Standard monitoring recommended"];
}

function generateNextSteps(summary, decision) {
    const steps = [];

    if (decision?.move_type === 'push_move') {
        steps.push("Initiate formal negotiations with club and agent");
        steps.push("Schedule medical examination");
        steps.push("Prepare contract proposal");
    } else if (decision?.move_type === 'monitor') {
        steps.push("Continue tracking performance metrics");
        steps.push("Maintain agent relationship");
        steps.push("Re-evaluate in 3-6 months");
    } else if (decision?.move_type === 'wait') {
        steps.push("Hold position - do not initiate contact");
        steps.push("Monitor from distance");
        steps.push("Wait for market conditions to improve");
    } else {
        steps.push("Complete detailed scouting report");
        steps.push("Present to technical director");
        steps.push("Await management decision");
    }

    return steps;
}