import { base44 } from "@/api/base44ServerClient";

export default async function uploadToDrive(request) {
    const { file, fileName, folderId } = request.body;
    
    try {
        // Get Google Drive access token for the current user
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('googledrive');
        
        if (!accessToken) {
            return {
                success: false,
                error: "Google Drive not connected. Please authorize access in Settings."
            };
        }

        // Determine file metadata
        const fileMetadata = {
            name: fileName || `FS-AI-Upload-${Date.now()}`,
            mimeType: file.type || 'application/octet-stream'
        };

        if (folderId) {
            fileMetadata.parents = [folderId];
        }

        // Upload file to Google Drive
        const form = new FormData();
        form.append('metadata', JSON.stringify(fileMetadata), { contentType: 'application/json' });
        form.append('file', file);

        const uploadResponse = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`
            },
            body: form
        });

        if (!uploadResponse.ok) {
            const error = await uploadResponse.json();
            throw new Error(error.error?.message || 'Upload failed');
        }

        const fileData = await uploadResponse.json();

        // Get shareable link
        const fileId = fileData.id;
        
        // Set permissions to allow anyone with link to view (optional)
        await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}/permissions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                role: 'reader',
                type: 'anyone'
            })
        });

        // Get file details with webViewLink
        const detailsResponse = await fetch(
            `https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,webViewLink,webContentLink,mimeType,size`,
            {
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                }
            }
        );

        const details = await detailsResponse.json();

        return {
            success: true,
            fileId: fileId,
            fileName: details.name,
            webViewLink: details.webViewLink,
            webContentLink: details.webContentLink,
            size: details.size,
            mimeType: details.mimeType,
            message: "File uploaded to Google Drive successfully"
        };

    } catch (error) {
        console.error("Google Drive upload error:", error);
        return {
            success: false,
            error: error.message || "Failed to upload to Google Drive"
        };
    }
}