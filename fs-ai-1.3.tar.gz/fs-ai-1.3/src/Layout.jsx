import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "./utils";
import {
  Target,
  FileText,
  LayoutDashboard,
  LogOut,
  Globe2,
  Sparkles,
  DollarSign,
  TrendingUp,
  Users,
  Search,
  BarChart3,
  Settings,
  Menu,
  X,
  Activity,
  Briefcase,
  Newspaper,
  Shield } from
"lucide-react";
import { base44 } from "@/api/base44Client";
import GlobalSearch from "./components/search/GlobalSearch";
import OnboardingTour from "./components/onboarding/OnboardingTour";
import TourTrigger from "./components/onboarding/TourTrigger";
import NotificationBell from "./components/notifications/NotificationBell";
import GlobalVoiceAssistant from "./components/voice/GlobalVoiceAssistant";
import GlobalChatbot from "./components/chat/GlobalChatbot";
import InstallPrompt from "./components/pwa/InstallPrompt";
import PushNotifications from "./components/pwa/PushNotifications";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = React.useState(null);
  const [showSearch, setShowSearch] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});

    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js').
      then((reg) => console.log('Service Worker registered')).
      catch((err) => console.log('Service Worker registration failed:', err));
    }
  }, []);

  React.useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowSearch(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const navItems = [
  { name: "Dashboard", icon: LayoutDashboard, page: "Home" },
  { name: "Live Match", icon: Activity, page: "LiveMatchAnalysis" },
  { name: "Awareness", icon: BarChart3, page: "FootballAwarenessEngine" },
  { name: "AI Analysis", icon: Sparkles, page: "AIPlayerAnalysis" },
  { name: "Recruitment", icon: Target, page: "RecruitmentHub" },
  { name: "Youth Scout", icon: Sparkles, page: "YouthAcademyScout" },
  { name: "Scout Hub", icon: Target, page: "ScoutingDashboard" },
  { name: "Network", icon: Users, page: "ScoutingNetworkHub" },
  { name: "Market AI", icon: TrendingUp, page: "AITransferMarket" },
  { name: "Agent Finisher", icon: Briefcase, page: "AgentFinisher" },
  { name: "Intelligence", icon: Sparkles, page: "IntelligenceEngine" },
  { name: "Analytics", icon: BarChart3, page: "PlayerAnalyticsDashboard" },
  { name: "Database", icon: LayoutDashboard, page: "DatabaseExplorer" },
  { name: "Globe", icon: Globe2, page: "Globe" },
  { name: "Player Map", icon: Globe2, page: "PlayerMapExplorer" },
  { name: "Compare", icon: Users, page: "PlayerComparison" },
  { name: "Rotation", icon: Users, page: "RotationPlanner" },
  { name: "Strategy", icon: Target, page: "TeamStrategy" },
  { name: "Scout Network", icon: Users, page: "ScoutNetwork" },
  { name: "Workflow", icon: Target, page: "ScoutingWorkflow" },
  { name: "News", icon: Newspaper, page: "News" },
  { name: "Subscription", icon: Sparkles, page: "Subscription" },
  { name: "FIFA Regs", icon: Shield, page: "FIFARegulations" }];

  const investorNavItems = [
  { name: "Investors", icon: TrendingUp, page: "InvestorDashboard" }];

  const isAdmin = user?.role === 'admin';


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
              <style>{`
                  :root {
                      --primary: #0F172A;
                      --secondary: #06B6D4;
                      --accent: #F59E0B;
                      --success: #10B981;
                  }
              `}</style>

              {/* VR/Meta Quest Compatibility */}
              <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
              <meta name="theme-color" content="#0F172A" />

              {/* Global Chatbot */}
              <GlobalChatbot />

              {/* PWA Install Prompt */}
              <InstallPrompt />

              {/* Top Navigation */}
            <nav className="border-b border-cyan-500/20 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-16">
                        <div className="flex items-center gap-3">
                            <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/0453bcb66_LOGOFS-AI.jpg"
                alt="FS-AI Logo"
                className="w-12 h-12 rounded-lg object-cover shadow-lg" />

                            <div>
                                <h1 className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                                    FS–AI
                                </h1>
                                <p className="text-xs text-slate-500">Football Scout Intelligence</p>
                            </div>
                        </div>

                        {/* Desktop Navigation */}
                        <div className="hidden lg:flex items-center gap-6 overflow-x-auto scrollbar-hide">
                            {navItems.map((item) =>
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                currentPageName === item.page ?
                "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" :
                "text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50"}`
                }>

                                    <item.icon className="w-4 h-4" />
                                    <span className="text-sm font-medium whitespace-nowrap">{item.name}</span>
                                </Link>
              )}
                            {isAdmin &&
              <>
                                    <Link
                  to={createPageUrl('Sales')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  currentPageName === 'Sales' ?
                  "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" :
                  "text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50"}`
                  }>

                                        <DollarSign className="w-4 h-4" />
                                        <span className="text-sm font-medium">Sales</span>
                                    </Link>
                                    {investorNavItems.map((item) =>
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  currentPageName === item.page ?
                  "bg-purple-500/20 text-purple-400 border border-purple-500/30" :
                  "text-slate-400 hover:text-purple-400 hover:bg-slate-800/50"}`
                  }>

                                            <item.icon className="w-4 h-4" />
                                            <span className="text-sm font-medium">{item.name}</span>
                                        </Link>
                )}
                                </>
              }
                        </div>

                        <div className="flex items-center gap-2">
                            {user && <GlobalVoiceAssistant />}
                            {user && <PushNotifications />}
                            {user && <NotificationBell />}
                            {user && <TourTrigger />}
                            {user &&
              <>
                                    <button
                  onClick={handleLogout}
                  className="hidden lg:flex items-center gap-2 px-4 py-2 text-slate-400 hover:text-red-400 transition-colors">

                                        <LogOut className="w-4 h-4" />
                                        <span className="text-sm">Logout</span>
                                    </button>

                                    {/* Mobile Menu */}
                                    <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                                        <SheetTrigger asChild>
                                            <Button variant="ghost" size="icon" className="lg:hidden text-slate-400">
                                                <Menu className="w-5 h-5" />
                                            </Button>
                                        </SheetTrigger>
                                        <SheetContent side="right" className="bg-slate-950 border-slate-800 w-[280px] overflow-y-auto">
                                            <SheetHeader>
                                                <SheetTitle className="text-white">Navigation</SheetTitle>
                                            </SheetHeader>
                                            <div className="mt-6 space-y-2 pb-8">
                                                {navItems.map((item) =>
                      <Link
                        key={item.page}
                        to={createPageUrl(item.page)}
                        onClick={() => setMobileMenuOpen(false)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                        currentPageName === item.page ?
                        "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" :
                        "text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50"}`
                        }>

                                                        <item.icon className="w-5 h-5" />
                                                        <span className="font-medium">{item.name}</span>
                                                    </Link>
                      )}
                                                {isAdmin &&
                      <>
                                                        <Link
                          to={createPageUrl('Sales')}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                          currentPageName === 'Sales' ?
                          "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" :
                          "text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50"}`
                          }>

                                                            <DollarSign className="w-5 h-5" />
                                                            <span className="font-medium">Sales</span>
                                                        </Link>
                                                        {investorNavItems.map((item) =>
                        <Link
                          key={item.page}
                          to={createPageUrl(item.page)}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                          currentPageName === item.page ?
                          "bg-purple-500/20 text-purple-400 border border-purple-500/30" :
                          "text-slate-400 hover:text-purple-400 hover:bg-slate-800/50"}`
                          }>

                                                                <item.icon className="w-5 h-5" />
                                                                <span className="font-medium">{item.name}</span>
                                                            </Link>
                        )}
                                                    </>
                      }
                                                <button
                        onClick={() => {
                          handleLogout();
                          setMobileMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-slate-800/50 rounded-lg transition-all">

                                                    <LogOut className="w-5 h-5" />
                                                    <span className="font-medium">Logout</span>
                                                </button>
                                            </div>
                                        </SheetContent>
                                    </Sheet>
                                </>
              }
                        </div>
                        </div>
                </div>
            </nav>

            {/* Main Content */}
            <main className="relative">
                <OnboardingTour />
                {children}
            </main>

            {/* Footer */}
            {currentPageName !== 'TacticalConsole' &&
      <footer className="border-t border-cyan-500/20 bg-slate-950/80 backdrop-blur-xl mt-20">
                <div className="max-w-7xl mx-auto px-6 py-12">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                        {/* Company Info */}
                        <div>
                            <h4 className="text-white font-semibold mb-4">Minimax Sustainable AI Ltd</h4>
                            <p className="text-slate-400 text-sm mb-2">Kingston Upon Hull, HU5 2TQ<br />United Kingdom</p>
                            <p className="text-slate-400 text-sm mb-2">Company No: 16864182<br />VAT: To be added</p>
                            <p className="text-slate-400 text-sm">Contact: director@minimax-sustainable-ai.com</p>
                        </div>

                        {/* Legal */}
                        <div>
                        <h4 className="text-white font-semibold mb-4">Legal</h4>
                        <div className="flex flex-col gap-2">
                            <Link to={createPageUrl('TermsOfService')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Terms of Service</Link>
                            <Link to={createPageUrl('ScoutTermsOfUse')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Scout Terms of Use</Link>
                            <Link to={createPageUrl('LegalResources')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Legal Resources</Link>
                            <Link to={createPageUrl('PrivacyPolicy')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Privacy Policy</Link>
                            <Link to={createPageUrl('Cookies')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Cookies Policy</Link>
                            <Link to={createPageUrl('DataProcessing')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Data Processing Agreement</Link>
                            <Link to={createPageUrl('Safeguarding')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Safeguarding Standards</Link>
                            <Link to={createPageUrl('CompanySafeguardingStatement')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Company Safeguarding Statement</Link>
                            <Link to={createPageUrl('SafeguardingBadge')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Safeguarding Badge</Link>
                            <Link to={createPageUrl('ApacheLicense')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors"></Link>
                        </div>
                        </div>

                        {/* Platforms */}
                        <div>
                            <h4 className="text-white font-semibold mb-4">Platforms</h4>
                            <div className="flex flex-col gap-2">
                                <a href="https://fs-ai.base44.app" className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">FS‑AI (Football Scout AI)</a>
                                <a href="https://al-isa-institute.co.uk" className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Al‑Isa Institute</a>
                                <a href="https://kaydenai.app" className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Kayden AI</a>
                                <a href="https://al-isa-hr-hub.uk" className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">HR Hub</a>
                                <a href="#" className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Halal Trader AI</a>
                            </div>
                        </div>

                        {/* Compliance */}
                        <div>
                            <h4 className="text-white font-semibold mb-4">Compliance</h4>
                            <div className="flex flex-col gap-2">
                                <Link to={createPageUrl('GDPRCompliance')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">GDPR Compliance</Link>
                                <Link to={createPageUrl('SecurityStandards')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Security Standards</Link>
                                <Link to={createPageUrl('AIGovernance')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">AI Governance</Link>
                                <Link to={createPageUrl('EthicalAI')} className="text-slate-400 text-sm hover:text-cyan-400 transition-colors">Ethical AI Framework</Link>
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-slate-800 pt-6">
                        <div className="text-center mb-4">
                            <p className="text-slate-500 text-sm mb-2">
                                FS–AI © {new Date().getFullYear()} · Elite Multi-Archetype Scouting Intelligence
                            </p>
                            <p className="text-slate-600 text-xs mb-3">
                                © Minimax Sustainable AI Ltd — All Rights Reserved.
                            </p>
                            <div className="flex items-center justify-center gap-4 text-xs text-slate-600 mb-2">
                                <span>™ FS-AI is a trademark of Minimax Sustainable AI Ltd</span>
                                <span>•</span>
                                <Link to={createPageUrl('ApacheLicense')} className="hover:text-cyan-400 transition-colors">
                                    Apache License 2.0
                                </Link>
                            </div>
                            <p className="text-slate-700 text-xs">
                                UK Patents Pending • International Copyright Protected
                            </p>
                        </div>

                        <div className="bg-slate-800/30 rounded-lg p-3 text-center">
                            <p className="text-slate-500 text-xs">
                                VR/Meta Quest Compatible • WebXR Ready • Immersive Football Intelligence
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
      }
        </div>);

}