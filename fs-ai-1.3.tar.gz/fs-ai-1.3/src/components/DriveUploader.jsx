import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, Loader2, FolderUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function DriveUploader({ file, fileName, label = "Save to Drive", variant = "outline", onSuccess }) {
    const [isUploading, setIsUploading] = useState(false);

    const handleUpload = async () => {
        setIsUploading(true);
        toast.loading('Uploading to Google Drive...', { id: 'drive-upload' });

        try {
            const result = await base44.functions.uploadToDrive({
                file: file,
                fileName: fileName
            });

            if (result.success) {
                toast.success(`Uploaded successfully! File ID: ${result.fileId}`, { id: 'drive-upload' });
                if (result.webViewLink) {
                    window.open(result.webViewLink, '_blank');
                }
                if (onSuccess) onSuccess(result);
            } else {
                toast.error(result.error || 'Upload failed', { id: 'drive-upload' });
            }
        } catch (error) {
            console.error('Drive upload error:', error);
            toast.error('Upload failed. Enable backend functions and authorize Google Drive first.', { id: 'drive-upload' });
        } finally {
            setIsUploading(false);
        }
    };

    return (
        <Button
            onClick={handleUpload}
            disabled={isUploading || !file}
            variant={variant}
            className="gap-2"
        >
            {isUploading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
                <FolderUp className="w-4 h-4" />
            )}
            {label}
        </Button>
    );
}