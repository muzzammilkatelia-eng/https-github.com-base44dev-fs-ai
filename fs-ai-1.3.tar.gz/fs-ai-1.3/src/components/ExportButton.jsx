import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function ExportButton({ entityType, title, label = "Export to Sheets", variant = "outline" }) {
    const [isExporting, setIsExporting] = useState(false);

    const handleExport = async () => {
        setIsExporting(true);
        toast.loading('Exporting to Google Sheets...', { id: 'export' });

        try {
            const result = await base44.functions.exportToGoogleSheets({
                entityType,
                title
            });

            if (result.success) {
                toast.success(`Exported ${result.rowCount} records successfully!`, { id: 'export' });
                window.open(result.spreadsheetUrl, '_blank');
            } else {
                toast.error(result.error || 'Export failed', { id: 'export' });
            }
        } catch (error) {
            console.error('Export error:', error);
            toast.error('Export failed. Enable backend functions first.', { id: 'export' });
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <Button
            onClick={handleExport}
            disabled={isExporting}
            variant={variant}
            className="gap-2"
        >
            {isExporting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
                <Download className="w-4 h-4" />
            )}
            {label}
        </Button>
    );
}