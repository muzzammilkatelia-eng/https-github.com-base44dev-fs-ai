import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lock, Sparkles, Check } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PremiumGate({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        base44.auth.me()
            .then(setUser)
            .catch(() => {})
            .finally(() => setLoading(false));
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
            </div>
        );
    }

    const isPremium = user?.subscription_tier === 'premium' && user?.subscription_status === 'active';
    const isAdmin = user?.role === 'admin';

    // Check for free trial (2 days from account creation)
    const isInFreeTrial = () => {
        if (!user?.created_date) return false;
        const createdAt = new Date(user.created_date);
        const now = new Date();
        const twoDaysMs = 2 * 24 * 60 * 60 * 1000;
        return (now - createdAt) < twoDaysMs;
    };

    const inTrial = isInFreeTrial();
    const trialDaysRemaining = () => {
        if (!user?.created_date) return 0;
        const createdAt = new Date(user.created_date);
        const now = new Date();
        const twoDaysMs = 2 * 24 * 60 * 60 * 1000;
        const remaining = twoDaysMs - (now - createdAt);
        return Math.max(0, Math.ceil(remaining / (24 * 60 * 60 * 1000)));
    };

    // Admins, premium users, or users in free trial have access
    if (isAdmin || isPremium || inTrial) {
        return (
            <>
                {inTrial && !isPremium && !isAdmin && (
                    <div className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 border-b border-amber-500/30 px-4 py-2 text-center">
                        <span className="text-amber-400 text-sm font-medium">
                            🎉 Free Trial Active - {trialDaysRemaining()} day{trialDaysRemaining() !== 1 ? 's' : ''} remaining
                        </span>
                        <span className="text-slate-400 text-sm ml-2">
                            Subscribe now to keep full access after your trial ends
                        </span>
                    </div>
                )}
                {children}
            </>
        );
    }

    // Show upgrade prompt
    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    <Card className="bg-gradient-to-br from-purple-500/20 to-blue-500/20 border-purple-500/30">
                        <CardHeader className="text-center">
                            <div className="mx-auto mb-4 w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center">
                                <Lock className="w-8 h-8 text-purple-400" />
                            </div>
                            <CardTitle className="text-3xl font-bold text-white mb-2">
                                Premium Feature
                            </CardTitle>
                            <p className="text-slate-300">
                                Unlock advanced scouting tools and AI-powered insights
                            </p>
                        </CardHeader>
                        <CardContent>
                            <div className="bg-slate-900/50 rounded-lg p-6 mb-6">
                                <div className="flex items-baseline justify-center mb-4">
                                    <span className="text-5xl font-bold text-white">£99</span>
                                    <span className="text-slate-400 ml-2">/month</span>
                                </div>
                                <Badge className="bg-emerald-500/20 text-emerald-400 mx-auto block w-fit">
                                    Premium Subscription
                                </Badge>
                            </div>

                            <div className="space-y-3 mb-6">
                                <h3 className="text-white font-semibold mb-3">Premium Features Include:</h3>
                                <div className="grid md:grid-cols-2 gap-3">
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Advanced Player Comparison</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">AI Team Builder</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Player Development Tracking</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Match Analysis Tools</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">AI Recruitment Agent</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Workflow Automation</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Agent Communications Hub</span>
                                    </div>
                                    <div className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                                        <span className="text-slate-300 text-sm">Advanced Analytics Dashboard</span>
                                    </div>
                                </div>
                            </div>

                            <div className="flex flex-col gap-3">
                                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mb-2">
                                    <p className="text-amber-400 text-sm font-medium text-center">
                                        🎁 New users get a FREE 2-day full trial!
                                    </p>
                                </div>
                                <Button 
                                    className="w-full bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500"
                                    onClick={() => window.open('https://pay.gocardless.com/BRT00048926VJAS', '_blank')}
                                >
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Subscribe Now - £99/month
                                </Button>
                                <p className="text-slate-500 text-xs text-center">
                                    Secure payment via GoCardless
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h4 className="text-white font-semibold mb-3">Free Tier Access</h4>
                            <p className="text-slate-400 text-sm mb-3">
                                You currently have access to these features:
                            </p>
                            <div className="space-y-2">
                                <div className="flex items-center gap-2 text-slate-300 text-sm">
                                    <Check className="w-4 h-4 text-cyan-400" />
                                    Dashboard Overview
                                </div>
                                <div className="flex items-center gap-2 text-slate-300 text-sm">
                                    <Check className="w-4 h-4 text-cyan-400" />
                                    Unified Scouting Hub
                                </div>
                                <div className="flex items-center gap-2 text-slate-300 text-sm">
                                    <Check className="w-4 h-4 text-cyan-400" />
                                    Interactive Talent Globe
                                </div>
                                <div className="flex items-center gap-2 text-slate-300 text-sm">
                                    <Check className="w-4 h-4 text-cyan-400" />
                                    5 Console Queries/Month
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>
    );
}