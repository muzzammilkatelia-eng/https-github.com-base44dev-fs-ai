import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Mail, Send, TrendingUp, AlertTriangle, CheckCircle,
    Sparkles, Loader2, MessageSquare, BarChart3, Clock,
    User, DollarSign
} from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function CommunicationDetails({ communication, onClose }) {
    const [agentResponse, setAgentResponse] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const queryClient = useQueryClient();

    const analyzeSentimentMutation = useMutation({
        mutationFn: async (response) => {
            setIsAnalyzing(true);

            const prompt = `You are an expert negotiation analyst for football transfers. Analyze this agent's response and extract actionable insights.

Original Message Subject: ${communication.subject}
Original Message: ${communication.message_content}

Agent's Response:
"${response}"

Analyze:
1. Overall sentiment (Very Positive, Positive, Neutral, Negative, Very Negative)
2. Interest level (Very High, High, Medium, Low, Very Low)
3. Identify potential deal breakers
4. Key concerns raised by the agent
5. Specific negotiation points mentioned
6. Recommended next steps for the club

Be specific and actionable in your analysis.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        sentiment: { 
                            type: "string",
                            enum: ["Very Positive", "Positive", "Neutral", "Negative", "Very Negative"]
                        },
                        interest_level: { 
                            type: "string",
                            enum: ["Very High", "High", "Medium", "Low", "Very Low"]
                        },
                        deal_breakers: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        key_concerns: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        negotiation_points: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        recommended_next_steps: { 
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (analysis) => {
            updateCommMutation.mutate({
                agent_response: agentResponse,
                response_received: true,
                response_date: new Date().toISOString(),
                status: 'Responded',
                ai_sentiment_analysis: analysis
            });
            setIsAnalyzing(false);
        },
        onError: () => {
            toast.error('Failed to analyze response');
            setIsAnalyzing(false);
        }
    });

    const updateCommMutation = useMutation({
        mutationFn: (data) => base44.entities.AgentCommunication.update(communication.id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agent-communications'] });
            toast.success('Communication updated');
        }
    });

    const handleRecordResponse = () => {
        if (!agentResponse.trim()) {
            toast.error('Please enter agent response');
            return;
        }
        analyzeSentimentMutation.mutate(agentResponse);
    };

    const getSentimentColor = (sentiment) => {
        const colors = {
            'Very Positive': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Positive': 'bg-green-500/20 text-green-400 border-green-500/30',
            'Neutral': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Negative': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
            'Very Negative': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[sentiment] || '';
    };

    const getInterestColor = (level) => {
        const colors = {
            'Very High': 'text-emerald-400',
            'High': 'text-green-400',
            'Medium': 'text-amber-400',
            'Low': 'text-orange-400',
            'Very Low': 'text-red-400'
        };
        return colors[level] || '';
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-2">{communication.player_name}</h2>
                    <div className="flex items-center gap-2 flex-wrap">
                        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                            {communication.communication_type}
                        </Badge>
                        <Badge className={
                            communication.status === 'Sent' || communication.status === 'Awaiting Response' 
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                            : communication.status === 'Responded'
                            ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                            : communication.status === 'Closed'
                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                            : 'bg-slate-500/20 text-slate-400 border-slate-500/30'
                        }>
                            {communication.status}
                        </Badge>
                        {communication.ai_sentiment_analysis && (
                            <Badge className={getSentimentColor(communication.ai_sentiment_analysis.sentiment)}>
                                {communication.ai_sentiment_analysis.sentiment}
                            </Badge>
                        )}
                    </div>
                </div>
            </div>

            <Tabs defaultValue="message" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    <TabsTrigger value="message">Message</TabsTrigger>
                    <TabsTrigger value="response">Response</TabsTrigger>
                    <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
                    <TabsTrigger value="details">Details</TabsTrigger>
                </TabsList>

                {/* Original Message */}
                <TabsContent value="message" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm flex items-center gap-2">
                                <Mail className="w-4 h-4 text-purple-400" />
                                Outgoing Message
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <p className="text-slate-400 text-xs mb-1">To</p>
                                <p className="text-white">{communication.agent_name} ({communication.agent_email})</p>
                            </div>
                            <div>
                                <p className="text-slate-400 text-xs mb-1">Subject</p>
                                <p className="text-white font-semibold">{communication.subject}</p>
                            </div>
                            <div>
                                <p className="text-slate-400 text-xs mb-1">Message</p>
                                <div className="bg-slate-900/50 rounded-lg p-4">
                                    <p className="text-slate-300 whitespace-pre-wrap">{communication.message_content}</p>
                                </div>
                            </div>
                            {communication.proposal_details && (
                                <div className="border-t border-slate-700 pt-4">
                                    <p className="text-slate-400 text-xs mb-3">Proposal Details</p>
                                    <div className="grid grid-cols-2 gap-3">
                                        {communication.proposal_details.transfer_fee && (
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Transfer Fee</p>
                                                <p className="text-emerald-400 font-semibold">{communication.proposal_details.transfer_fee}</p>
                                            </div>
                                        )}
                                        {communication.proposal_details.contract_length && (
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Contract</p>
                                                <p className="text-cyan-400 font-semibold">{communication.proposal_details.contract_length}</p>
                                            </div>
                                        )}
                                        {communication.proposal_details.salary && (
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Salary</p>
                                                <p className="text-amber-400 font-semibold">{communication.proposal_details.salary}</p>
                                            </div>
                                        )}
                                        {communication.proposal_details.bonuses && (
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Bonuses</p>
                                                <p className="text-purple-400 font-semibold">{communication.proposal_details.bonuses}</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Response Recording */}
                <TabsContent value="response" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm flex items-center gap-2">
                                <MessageSquare className="w-4 h-4 text-cyan-400" />
                                Agent Response
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {communication.response_received ? (
                                <div>
                                    <div className="flex items-center justify-between mb-3">
                                        <Badge className="bg-cyan-500/20 text-cyan-400">Response Received</Badge>
                                        <p className="text-slate-500 text-xs">
                                            {new Date(communication.response_date).toLocaleString()}
                                        </p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <p className="text-slate-300 whitespace-pre-wrap">{communication.agent_response}</p>
                                    </div>
                                </div>
                            ) : (
                                <div>
                                    <p className="text-slate-400 text-sm mb-3">
                                        Record the agent's response to enable AI sentiment analysis
                                    </p>
                                    <Textarea
                                        value={agentResponse}
                                        onChange={(e) => setAgentResponse(e.target.value)}
                                        placeholder="Paste or type agent's response here..."
                                        className="bg-slate-900 border-slate-700 text-white min-h-[200px]"
                                    />
                                    <Button
                                        onClick={handleRecordResponse}
                                        disabled={!agentResponse.trim() || isAnalyzing}
                                        className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-600"
                                    >
                                        {isAnalyzing ? (
                                            <>
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                Analyzing Response...
                                            </>
                                        ) : (
                                            <>
                                                <Sparkles className="w-4 h-4 mr-2" />
                                                Record & Analyze Response
                                            </>
                                        )}
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* AI Analysis */}
                <TabsContent value="analysis" className="space-y-4">
                    {communication.ai_sentiment_analysis ? (
                        <>
                            {/* Sentiment & Interest */}
                            <div className="grid grid-cols-2 gap-4">
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-6">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="text-slate-400 text-sm mb-1">Sentiment</p>
                                                <p className="text-2xl font-bold text-white">
                                                    {communication.ai_sentiment_analysis.sentiment}
                                                </p>
                                            </div>
                                            <TrendingUp className={`w-8 h-8 ${
                                                communication.ai_sentiment_analysis.sentiment.includes('Positive') 
                                                ? 'text-emerald-400' 
                                                : 'text-slate-400'
                                            }`} />
                                        </div>
                                    </CardContent>
                                </Card>

                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-6">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="text-slate-400 text-sm mb-1">Interest Level</p>
                                                <p className={`text-2xl font-bold ${getInterestColor(communication.ai_sentiment_analysis.interest_level)}`}>
                                                    {communication.ai_sentiment_analysis.interest_level}
                                                </p>
                                            </div>
                                            <BarChart3 className="w-8 h-8 text-cyan-400" />
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Deal Breakers */}
                            {communication.ai_sentiment_analysis.deal_breakers?.length > 0 && (
                                <Card className="bg-red-500/10 border-red-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-red-400 text-sm flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4" />
                                            Potential Deal Breakers
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-2">
                                            {communication.ai_sentiment_analysis.deal_breakers.map((item, idx) => (
                                                <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-red-400">⚠</span>
                                                    {item}
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Key Concerns */}
                            {communication.ai_sentiment_analysis.key_concerns?.length > 0 && (
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white text-sm">Key Concerns</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-2">
                                            {communication.ai_sentiment_analysis.key_concerns.map((item, idx) => (
                                                <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400">•</span>
                                                    {item}
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Negotiation Points */}
                            {communication.ai_sentiment_analysis.negotiation_points?.length > 0 && (
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white text-sm">Negotiation Points</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-2">
                                            {communication.ai_sentiment_analysis.negotiation_points.map((item, idx) => (
                                                <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-cyan-400">→</span>
                                                    {item}
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Recommended Next Steps */}
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-emerald-400 text-sm flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" />
                                        Recommended Next Steps
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ol className="space-y-2">
                                        {communication.ai_sentiment_analysis.recommended_next_steps?.map((item, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400 font-bold">{idx + 1}.</span>
                                                {item}
                                            </li>
                                        ))}
                                    </ol>
                                </CardContent>
                            </Card>
                        </>
                    ) : (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardContent className="pt-6 text-center py-12">
                                <Sparkles className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                                <p className="text-slate-400">
                                    No AI analysis available yet. Record agent response to enable sentiment analysis.
                                </p>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                {/* Details */}
                <TabsContent value="details" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm">Communication Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Created</p>
                                    <p className="text-white text-sm">{new Date(communication.created_date).toLocaleString()}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Priority</p>
                                    <Badge className={
                                        communication.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                        communication.priority === 'High' ? 'bg-orange-500/20 text-orange-400' :
                                        'bg-blue-500/20 text-blue-400'
                                    }>
                                        {communication.priority}
                                    </Badge>
                                </div>
                                {communication.follow_up_date && (
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            Follow-up Date
                                        </p>
                                        <p className="text-amber-400 text-sm">{new Date(communication.follow_up_date).toLocaleDateString()}</p>
                                    </div>
                                )}
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Created By</p>
                                    <p className="text-white text-sm">{communication.created_by}</p>
                                </div>
                            </div>

                            {communication.agent_phone && (
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Agent Phone</p>
                                    <p className="text-white">{communication.agent_phone}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex gap-3 justify-end pt-4 border-t border-slate-700">
                <Button 
                    variant="outline" 
                    onClick={onClose}
                    className="bg-slate-800 border-slate-700 text-white"
                >
                    Close
                </Button>
            </div>
        </div>
    );
}