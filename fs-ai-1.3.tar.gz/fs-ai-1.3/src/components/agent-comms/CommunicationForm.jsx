import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Loader2, Sparkles, Search, Link as LinkIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import toast from 'react-hot-toast';

export default function CommunicationForm({ onClose, linkedPlayer }) {
    const [formData, setFormData] = useState({
        player_name: linkedPlayer?.player_name || linkedPlayer?.name || '',
        agent_name: '',
        agent_email: '',
        agent_phone: '',
        communication_type: 'Initial Contact',
        subject: '',
        message_content: '',
        priority: 'Medium',
        follow_up_date: '',
        proposal_details: {
            transfer_fee: '',
            contract_length: '',
            salary: '',
            bonuses: ''
        }
    });

    const [isGenerating, setIsGenerating] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');

    const queryClient = useQueryClient();

    // Fetch player's scouting report for AI context
    const { data: scoutingReport } = useQuery({
        queryKey: ['player-report-for-comm', formData.player_name],
        queryFn: async () => {
            if (!formData.player_name) return null;
            const reports = await base44.entities.ScoutingReport.filter(
                { player_name: formData.player_name },
                '-created_date',
                1
            );
            return reports[0];
        },
        enabled: !!formData.player_name
    });

    // Search for players
    const { data: playerSearch = [] } = useQuery({
        queryKey: ['player-search', searchQuery],
        queryFn: async () => {
            if (!searchQuery || searchQuery.length < 2) return [];
            const reports = await base44.entities.ScoutingReport.filter(
                {},
                '-created_date',
                50
            );
            return reports.filter(r => 
                r.player_name.toLowerCase().includes(searchQuery.toLowerCase())
            );
        },
        enabled: searchQuery.length >= 2
    });

    const generateDraftMutation = useMutation({
        mutationFn: async () => {
            setIsGenerating(true);
            
            const playerContext = scoutingReport ? `
Player Profile:
- Name: ${scoutingReport.player_name}
- Age: ${scoutingReport.player_age}
- Position: ${scoutingReport.position}
- Current Club: ${scoutingReport.current_club}
- Technical Rating: ${scoutingReport.technical_rating}/100
- Physical Rating: ${scoutingReport.physical_rating}/100
- Tactical Rating: ${scoutingReport.tactical_rating}/100
- Mental Rating: ${scoutingReport.mental_rating}/100
- Recommendation: ${scoutingReport.recommendation}
- Key Strengths: ${scoutingReport.strengths || 'Not specified'}
- Weaknesses: ${scoutingReport.weaknesses || 'Not specified'}
` : `Player: ${formData.player_name}`;

            const proposalContext = formData.communication_type === 'Proposal' ? `
Proposal Details:
- Transfer Fee: ${formData.proposal_details.transfer_fee || 'To be discussed'}
- Contract Length: ${formData.proposal_details.contract_length || 'To be discussed'}
- Salary: ${formData.proposal_details.salary || 'To be discussed'}
- Bonuses: ${formData.proposal_details.bonuses || 'To be discussed'}
` : '';

            const prompt = `You are a professional football club director writing to a player agent. Generate a ${formData.communication_type.toLowerCase()} message.

${playerContext}

${proposalContext}

Communication Type: ${formData.communication_type}

Requirements:
- Professional and respectful tone
- Clear and concise
- Highlight player's strengths based on scouting report
- Express genuine interest
- Provide clear next steps
${formData.communication_type === 'Proposal' ? '- Include specific proposal details' : ''}
${formData.communication_type === 'Initial Contact' ? '- Request meeting or further discussion' : ''}

Generate:
1. A compelling subject line
2. A professional message body (250-400 words)

Format as JSON with "subject" and "message" fields.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        subject: { type: "string" },
                        message: { type: "string" }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setFormData({
                ...formData,
                subject: data.subject,
                message_content: data.message
            });
            toast.success('Draft generated!');
            setIsGenerating(false);
        },
        onError: () => {
            toast.error('Failed to generate draft');
            setIsGenerating(false);
        }
    });

    const createCommMutation = useMutation({
        mutationFn: (data) => base44.entities.AgentCommunication.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agent-communications'] });
            toast.success('Communication saved');
            onClose();
        },
        onError: () => {
            toast.error('Failed to save communication');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        createCommMutation.mutate({
            ...formData,
            status: 'Draft'
        });
    };

    const handleSendNow = () => {
        createCommMutation.mutate({
            ...formData,
            status: 'Sent'
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            {linkedPlayer && (
                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <LinkIcon className="w-4 h-4 text-purple-400" />
                        <span className="text-purple-400 font-semibold text-sm">Linked to Player</span>
                    </div>
                    <p className="text-white">{linkedPlayer.player_name || linkedPlayer.name}</p>
                </div>
            )}

            {/* Player Selection */}
            <div>
                <Label className="text-slate-400">Player Name *</Label>
                <div className="relative">
                    <Input
                        value={formData.player_name}
                        onChange={(e) => {
                            setFormData({...formData, player_name: e.target.value});
                            setSearchQuery(e.target.value);
                        }}
                        className="bg-slate-800 border-slate-700 text-white"
                        placeholder="Search for player..."
                        required
                        disabled={!!linkedPlayer}
                    />
                    {playerSearch.length > 0 && !linkedPlayer && (
                        <div className="absolute z-10 w-full mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                            {playerSearch.map((player, idx) => (
                                <div
                                    key={idx}
                                    onClick={() => {
                                        setFormData({...formData, player_name: player.player_name});
                                        setSearchQuery('');
                                    }}
                                    className="p-3 hover:bg-slate-700 cursor-pointer"
                                >
                                    <p className="text-white font-semibold">{player.player_name}</p>
                                    <p className="text-slate-400 text-sm">{player.position} • {player.current_club}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Agent Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <Label className="text-slate-400">Agent Name *</Label>
                    <Input
                        value={formData.agent_name}
                        onChange={(e) => setFormData({...formData, agent_name: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white"
                        required
                    />
                </div>
                <div>
                    <Label className="text-slate-400">Agent Email *</Label>
                    <Input
                        type="email"
                        value={formData.agent_email}
                        onChange={(e) => setFormData({...formData, agent_email: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white"
                        required
                    />
                </div>
                <div>
                    <Label className="text-slate-400">Agent Phone</Label>
                    <Input
                        value={formData.agent_phone}
                        onChange={(e) => setFormData({...formData, agent_phone: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                </div>
            </div>

            {/* Communication Type & Priority */}
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-slate-400">Communication Type</Label>
                    <Select value={formData.communication_type} onValueChange={(v) => setFormData({...formData, communication_type: v})}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Initial Contact">Initial Contact</SelectItem>
                            <SelectItem value="Proposal">Proposal</SelectItem>
                            <SelectItem value="Follow-up">Follow-up</SelectItem>
                            <SelectItem value="Negotiation">Negotiation</SelectItem>
                            <SelectItem value="Contract Discussion">Contract Discussion</SelectItem>
                            <SelectItem value="Meeting Request">Meeting Request</SelectItem>
                            <SelectItem value="General Inquiry">General Inquiry</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label className="text-slate-400">Priority</Label>
                    <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            {/* Proposal Details - Only show if type is Proposal */}
            {formData.communication_type === 'Proposal' && (
                <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-white text-sm">Proposal Details</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400 text-sm">Transfer Fee</Label>
                                <Input
                                    value={formData.proposal_details.transfer_fee}
                                    onChange={(e) => setFormData({
                                        ...formData, 
                                        proposal_details: {...formData.proposal_details, transfer_fee: e.target.value}
                                    })}
                                    className="bg-slate-700 border-slate-600 text-white"
                                    placeholder="e.g., €15M"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400 text-sm">Contract Length</Label>
                                <Input
                                    value={formData.proposal_details.contract_length}
                                    onChange={(e) => setFormData({
                                        ...formData, 
                                        proposal_details: {...formData.proposal_details, contract_length: e.target.value}
                                    })}
                                    className="bg-slate-700 border-slate-600 text-white"
                                    placeholder="e.g., 4 years"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400 text-sm">Salary</Label>
                                <Input
                                    value={formData.proposal_details.salary}
                                    onChange={(e) => setFormData({
                                        ...formData, 
                                        proposal_details: {...formData.proposal_details, salary: e.target.value}
                                    })}
                                    className="bg-slate-700 border-slate-600 text-white"
                                    placeholder="e.g., £80k/week"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400 text-sm">Bonuses</Label>
                                <Input
                                    value={formData.proposal_details.bonuses}
                                    onChange={(e) => setFormData({
                                        ...formData, 
                                        proposal_details: {...formData.proposal_details, bonuses: e.target.value}
                                    })}
                                    className="bg-slate-700 border-slate-600 text-white"
                                    placeholder="e.g., Performance bonuses"
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* AI Draft Generation */}
            <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        <span className="text-white font-semibold">AI Draft Generator</span>
                    </div>
                    <Button
                        type="button"
                        onClick={() => generateDraftMutation.mutate()}
                        disabled={!formData.player_name || !formData.agent_name || isGenerating}
                        className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {isGenerating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Generating...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate Draft
                            </>
                        )}
                    </Button>
                </div>
                <p className="text-slate-400 text-sm">
                    AI will analyze the player's scouting report and generate a professional message
                </p>
            </div>

            {/* Subject */}
            <div>
                <Label className="text-slate-400">Subject *</Label>
                <Input
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="Interest in [Player Name]"
                    required
                />
            </div>

            {/* Message */}
            <div>
                <Label className="text-slate-400">Message *</Label>
                <Textarea
                    value={formData.message_content}
                    onChange={(e) => setFormData({...formData, message_content: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white min-h-[250px]"
                    placeholder="Write your message to the agent..."
                    required
                />
            </div>

            {/* Follow-up Date */}
            <div>
                <Label className="text-slate-400">Follow-up Date</Label>
                <Input
                    type="date"
                    value={formData.follow_up_date}
                    onChange={(e) => setFormData({...formData, follow_up_date: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                />
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-end pt-4 border-t border-slate-700">
                <Button 
                    type="button"
                    variant="outline" 
                    onClick={onClose}
                    className="bg-slate-800 border-slate-700 text-white"
                >
                    Cancel
                </Button>
                <Button 
                    type="submit"
                    disabled={createCommMutation.isPending}
                    className="bg-slate-700 hover:bg-slate-600 text-white"
                >
                    Save as Draft
                </Button>
                <Button 
                    type="button"
                    onClick={handleSendNow}
                    disabled={createCommMutation.isPending}
                    className="bg-gradient-to-r from-purple-500 to-pink-600"
                >
                    {createCommMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : null}
                    Send Now
                </Button>
            </div>
        </form>
    );
}