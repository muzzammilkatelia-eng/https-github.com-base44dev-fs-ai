import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, BarChart3 } from 'lucide-react';

export default function SentimentDashboard({ communications }) {
    const analyzed = communications.filter(c => c.ai_sentiment_analysis);

    const sentimentCounts = {
        'Very Positive': analyzed.filter(c => c.ai_sentiment_analysis.sentiment === 'Very Positive').length,
        'Positive': analyzed.filter(c => c.ai_sentiment_analysis.sentiment === 'Positive').length,
        'Neutral': analyzed.filter(c => c.ai_sentiment_analysis.sentiment === 'Neutral').length,
        'Negative': analyzed.filter(c => c.ai_sentiment_analysis.sentiment === 'Negative').length,
        'Very Negative': analyzed.filter(c => c.ai_sentiment_analysis.sentiment === 'Very Negative').length
    };

    const interestCounts = {
        'Very High': analyzed.filter(c => c.ai_sentiment_analysis.interest_level === 'Very High').length,
        'High': analyzed.filter(c => c.ai_sentiment_analysis.interest_level === 'High').length,
        'Medium': analyzed.filter(c => c.ai_sentiment_analysis.interest_level === 'Medium').length,
        'Low': analyzed.filter(c => c.ai_sentiment_analysis.interest_level === 'Low').length,
        'Very Low': analyzed.filter(c => c.ai_sentiment_analysis.interest_level === 'Very Low').length
    };

    const totalPositive = sentimentCounts['Very Positive'] + sentimentCounts['Positive'];
    const totalNegative = sentimentCounts['Negative'] + sentimentCounts['Very Negative'];

    // Collect all deal breakers
    const allDealBreakers = analyzed
        .flatMap(c => c.ai_sentiment_analysis.deal_breakers || [])
        .filter(Boolean);
    
    const dealBreakerFrequency = {};
    allDealBreakers.forEach(breaker => {
        dealBreakerFrequency[breaker] = (dealBreakerFrequency[breaker] || 0) + 1;
    });

    const topDealBreakers = Object.entries(dealBreakerFrequency)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);

    return (
        <div className="space-y-6">
            {/* Overview Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Analyzed</p>
                                <p className="text-3xl font-bold text-white">{analyzed.length}</p>
                            </div>
                            <BarChart3 className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Positive</p>
                                <p className="text-3xl font-bold text-emerald-400">{totalPositive}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Negative</p>
                                <p className="text-3xl font-bold text-red-400">{totalNegative}</p>
                            </div>
                            <TrendingDown className="w-8 h-8 text-red-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Success Rate</p>
                                <p className="text-3xl font-bold text-purple-400">
                                    {analyzed.length > 0 ? Math.round((totalPositive / analyzed.length) * 100) : 0}%
                                </p>
                            </div>
                            <CheckCircle className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Sentiment Breakdown */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Sentiment Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {Object.entries(sentimentCounts).map(([sentiment, count]) => (
                            <div key={sentiment} className="flex items-center justify-between">
                                <div className="flex items-center gap-3 flex-1">
                                    <span className="text-slate-400 w-32">{sentiment}</span>
                                    <div className="flex-1 bg-slate-800 rounded-full h-4 overflow-hidden">
                                        <div 
                                            className={`h-full ${
                                                sentiment.includes('Positive') ? 'bg-emerald-500' :
                                                sentiment === 'Neutral' ? 'bg-slate-500' :
                                                'bg-red-500'
                                            }`}
                                            style={{ width: `${analyzed.length > 0 ? (count / analyzed.length) * 100 : 0}%` }}
                                        />
                                    </div>
                                </div>
                                <span className="text-white font-semibold w-12 text-right">{count}</span>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Interest Level Breakdown */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Interest Level Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {Object.entries(interestCounts).map(([level, count]) => (
                            <div key={level} className="flex items-center justify-between">
                                <div className="flex items-center gap-3 flex-1">
                                    <span className="text-slate-400 w-32">{level}</span>
                                    <div className="flex-1 bg-slate-800 rounded-full h-4 overflow-hidden">
                                        <div 
                                            className="h-full bg-gradient-to-r from-cyan-500 to-purple-500"
                                            style={{ width: `${analyzed.length > 0 ? (count / analyzed.length) * 100 : 0}%` }}
                                        />
                                    </div>
                                </div>
                                <span className="text-white font-semibold w-12 text-right">{count}</span>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Top Deal Breakers */}
            {topDealBreakers.length > 0 && (
                <Card className="bg-red-500/10 border-red-500/30">
                    <CardHeader>
                        <CardTitle className="text-red-400 flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5" />
                            Most Common Deal Breakers
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {topDealBreakers.map(([breaker, count], idx) => (
                                <div key={idx} className="flex items-center justify-between bg-slate-900/50 rounded-lg p-3">
                                    <p className="text-slate-300 flex-1">{breaker}</p>
                                    <Badge className="bg-red-500/20 text-red-400">
                                        {count} {count === 1 ? 'time' : 'times'}
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}