import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Loader2, TrendingUp, Zap, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIAnomalyDetector() {
    const [anomalies, setAnomalies] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-anomaly'],
        queryFn: () => base44.entities.Player.list('-updated_date', 50)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports-anomaly'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 30)
    });

    const detectAnomalies = async () => {
        setLoading(true);
        toast.loading('AI scanning for anomalies...', { id: 'anomaly' });

        try {
            const playerSummaries = players.slice(0, 30).map(p => ({
                name: p.name,
                age: p.age,
                position: p.position,
                club: p.current_club,
                market_value: p.market_value,
                potential: p.fsai_proprietary_score || 70,
                recent_form: p.career_history?.[0] || null
            }));

            const reportSummaries = reports.slice(0, 20).map(r => ({
                player: r.player_name,
                recommendation: r.recommendation,
                verdict: r.overall_verdict
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football analytics AI. Detect ANOMALIES - players significantly outperforming their market value or reputation.

PLAYER DATA:
${JSON.stringify(playerSummaries, null, 2)}

RECENT SCOUT REPORTS:
${JSON.stringify(reportSummaries, null, 2)}

Identify players who are:
1. **Undervalued Gems** - Performance/potential far exceeds market value
2. **Breakout Candidates** - About to significantly improve
3. **Hidden Talents** - Low reputation but high actual ability

For each anomaly found, provide:
- player_name: string
- anomaly_type: "Undervalued" | "Breakout" | "Hidden Talent"
- current_value: number (millions)
- estimated_true_value: number (millions)
- value_gap_percent: number
- reasoning: string (2-3 sentences)
- urgency: "Immediate" | "Short-term" | "Monitor"

Return JSON with key "anomalies" containing array of 5-8 players.`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        anomalies: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    anomaly_type: { type: 'string' },
                                    current_value: { type: 'number' },
                                    estimated_true_value: { type: 'number' },
                                    value_gap_percent: { type: 'number' },
                                    reasoning: { type: 'string' },
                                    urgency: { type: 'string' }
                                }
                            }
                        }
                    }
                }
            });

            setAnomalies(result.anomalies || []);
            toast.success('Anomaly detection complete!', { id: 'anomaly' });
        } catch (error) {
            toast.error('Detection failed', { id: 'anomaly' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const typeColors = {
        'Undervalued': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Breakout': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
        'Hidden Talent': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
    };

    const urgencyColors = {
        'Immediate': 'bg-red-500/20 text-red-400',
        'Short-term': 'bg-amber-500/20 text-amber-400',
        'Monitor': 'bg-blue-500/20 text-blue-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    AI Anomaly Detector
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!anomalies ? (
                    <div className="text-center py-8">
                        <Zap className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Detect players outperforming their market value or reputation
                        </p>
                        <Button
                            onClick={detectAnomalies}
                            disabled={loading}
                            className="bg-gradient-to-r from-amber-500 to-red-600"
                        >
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Scanning...</>
                            ) : (
                                <><AlertTriangle className="w-4 h-4 mr-2" /> Detect Anomalies</>
                            )}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {anomalies.map((anomaly, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                            >
                                <div className="flex items-start justify-between mb-2">
                                    <div>
                                        <h4 className="text-white font-bold flex items-center gap-2">
                                            <Star className="w-4 h-4 text-amber-400" />
                                            {anomaly.player_name}
                                        </h4>
                                        <div className="flex items-center gap-2 mt-1">
                                            <Badge className={typeColors[anomaly.anomaly_type]}>
                                                {anomaly.anomaly_type}
                                            </Badge>
                                            <Badge className={urgencyColors[anomaly.urgency]}>
                                                {anomaly.urgency}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-emerald-400 font-bold text-lg flex items-center gap-1">
                                            <TrendingUp className="w-4 h-4" />
                                            +{anomaly.value_gap_percent}%
                                        </div>
                                        <p className="text-slate-400 text-xs">Value Gap</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 mb-2 text-sm">
                                    <span className="text-slate-400">
                                        Current: <span className="text-white">€{anomaly.current_value}M</span>
                                    </span>
                                    <span className="text-slate-400">→</span>
                                    <span className="text-slate-400">
                                        True Value: <span className="text-emerald-400 font-bold">€{anomaly.estimated_true_value}M</span>
                                    </span>
                                </div>
                                <p className="text-slate-300 text-sm">{anomaly.reasoning}</p>
                            </motion.div>
                        ))}
                        <Button onClick={detectAnomalies} variant="outline" className="w-full border-slate-700">
                            Re-scan
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}