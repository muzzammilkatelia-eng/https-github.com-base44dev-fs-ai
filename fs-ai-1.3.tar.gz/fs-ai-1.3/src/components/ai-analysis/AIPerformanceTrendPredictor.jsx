import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Loader2, LineChart, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIPerformanceTrendPredictor({ player }) {
    const [prediction, setPrediction] = useState(null);
    const [loading, setLoading] = useState(false);

    const predictTrend = async () => {
        setLoading(true);
        toast.loading('AI predicting trends...', { id: 'ai-predict' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football analytics expert. Analyze and predict the performance trends for:

**Player:** ${player.name}
**Age:** ${player.age}
**Position:** ${player.position}
**Current Club:** ${player.current_club || 'N/A'}
**Market Value:** €${player.market_value}M

**Career Trajectory:**
${player.career_history?.slice(0, 5).map(h => 
    `${h.season}: ${h.club} - ${h.appearances} apps, ${h.goals} goals, ${h.assists} assists`
).join('\n') || 'Limited data'}

**Physical Profile:**
- Height: ${player.physical_attributes?.height}cm
- Pace: ${player.physical_attributes?.pace}/100
- Stamina: ${player.physical_attributes?.stamina}/100
- Strength: ${player.physical_attributes?.strength}/100

**Injury Risk:** ${player.injury_prone_score || 'N/A'}/100

Provide a structured prediction with:
1. **Short-term Outlook (6-12 months)** - Expected performance level
2. **Medium-term Outlook (1-3 years)** - Peak potential and development path
3. **Long-term Outlook (3+ years)** - Career trajectory and sustainability
4. **Key Factors** - What will influence their trajectory (positive & negative)
5. **Risk Assessment** - Injury concerns, form drops, adaptation challenges
6. **Confidence Level** - High/Medium/Low with reasoning

Return as JSON with these exact keys: short_term, medium_term, long_term, key_factors (array), risk_assessment, confidence_level, confidence_reasoning`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        short_term: { type: 'string' },
                        medium_term: { type: 'string' },
                        long_term: { type: 'string' },
                        key_factors: { type: 'array', items: { type: 'string' } },
                        risk_assessment: { type: 'string' },
                        confidence_level: { type: 'string' },
                        confidence_reasoning: { type: 'string' }
                    }
                }
            });

            setPrediction(result);
            toast.success('Prediction complete!', { id: 'ai-predict' });
        } catch (error) {
            toast.error('Prediction failed', { id: 'ai-predict' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const confidenceColors = {
        High: 'bg-emerald-500/20 text-emerald-400',
        Medium: 'bg-amber-500/20 text-amber-400',
        Low: 'bg-red-500/20 text-red-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <TrendingUp className="w-5 h-5 text-purple-400" />
                    AI Performance Trend Predictor
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {!prediction ? (
                    <div className="text-center py-8">
                        <LineChart className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Predict future performance trends for {player.name}
                        </p>
                        <Button
                            onClick={predictTrend}
                            disabled={loading}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <TrendingUp className="w-4 h-4 mr-2" />
                                    Predict Trends
                                </>
                            )}
                        </Button>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-white font-semibold">Performance Prediction</h3>
                            <Badge className={confidenceColors[prediction.confidence_level] || confidenceColors.Medium}>
                                {prediction.confidence_level} Confidence
                            </Badge>
                        </div>

                        <div className="space-y-4">
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-cyan-400 font-semibold mb-2">📊 Short-term (6-12 months)</h4>
                                <p className="text-slate-300 text-sm">{prediction.short_term}</p>
                            </div>

                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-blue-400 font-semibold mb-2">📈 Medium-term (1-3 years)</h4>
                                <p className="text-slate-300 text-sm">{prediction.medium_term}</p>
                            </div>

                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-purple-400 font-semibold mb-2">🎯 Long-term (3+ years)</h4>
                                <p className="text-slate-300 text-sm">{prediction.long_term}</p>
                            </div>

                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                <h4 className="text-emerald-400 font-semibold mb-2">🔑 Key Factors</h4>
                                <ul className="space-y-1">
                                    {prediction.key_factors?.map((factor, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm">• {factor}</li>
                                    ))}
                                </ul>
                            </div>

                            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                                <h4 className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4" />
                                    Risk Assessment
                                </h4>
                                <p className="text-slate-300 text-sm">{prediction.risk_assessment}</p>
                            </div>

                            {prediction.confidence_reasoning && (
                                <div className="bg-slate-800/30 rounded-lg p-3">
                                    <p className="text-slate-400 text-xs italic">{prediction.confidence_reasoning}</p>
                                </div>
                            )}
                        </div>

                        <Button
                            onClick={predictTrend}
                            variant="outline"
                            className="w-full border-slate-700"
                        >
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Re-analyze
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}