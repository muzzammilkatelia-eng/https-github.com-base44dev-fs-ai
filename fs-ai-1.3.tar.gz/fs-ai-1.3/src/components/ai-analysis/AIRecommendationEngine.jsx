import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Loader2, Target, TrendingUp, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIRecommendationEngine({ player }) {
    const [recommendations, setRecommendations] = useState(null);
    const [loading, setLoading] = useState(false);

    const generateRecommendations = async () => {
        setLoading(true);
        toast.loading('AI generating recommendations...', { id: 'ai-recommend' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football director and development coach. Provide comprehensive recommendations for:

**Player:** ${player.name}
**Age:** ${player.age}
**Position:** ${player.position}
**Current Club:** ${player.current_club || 'N/A'}
**Market Value:** €${player.market_value}M
**Contract Expiry:** ${player.contract_expiry || 'N/A'}

**Physical Profile:**
${player.physical_attributes ? JSON.stringify(player.physical_attributes, null, 2) : 'N/A'}

**Playing Style:**
${player.playing_style ? JSON.stringify(player.playing_style, null, 2) : 'N/A'}

**Career Stats (Recent):**
${player.career_history?.slice(0, 3).map(h => 
    `${h.season}: ${h.appearances} apps, ${h.goals}G, ${h.assists}A`
).join('\n') || 'Limited data'}

Provide THREE types of recommendations in JSON format:

1. **Development Plan** - How to maximize this player's potential
   - training_priorities: array of 4-5 specific training focuses
   - tactical_development: string with tactical improvements
   - physical_program: string with physical development needs
   - timeline: string (e.g., "6-12 months")

2. **Transfer Assessment** - Should we sign/sell this player?
   - action: "Sign" | "Monitor" | "Sell" | "Loan Out"
   - reasoning: string explaining the decision
   - ideal_fee: string (e.g., "€15-20M")
   - alternative_targets: array of 2-3 similar player names if action is sell

3. **Club Fit Analysis** - Best clubs/leagues for this player
   - ideal_clubs: array of 3-4 club names with reasoning
   - ideal_league: string
   - playing_time_outlook: string
   - adaptation_challenges: array of 2-3 potential challenges

Return as JSON with exact structure above.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        development_plan: {
                            type: 'object',
                            properties: {
                                training_priorities: { type: 'array', items: { type: 'string' } },
                                tactical_development: { type: 'string' },
                                physical_program: { type: 'string' },
                                timeline: { type: 'string' }
                            }
                        },
                        transfer_assessment: {
                            type: 'object',
                            properties: {
                                action: { type: 'string' },
                                reasoning: { type: 'string' },
                                ideal_fee: { type: 'string' },
                                alternative_targets: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        club_fit_analysis: {
                            type: 'object',
                            properties: {
                                ideal_clubs: { type: 'array', items: { type: 'string' } },
                                ideal_league: { type: 'string' },
                                playing_time_outlook: { type: 'string' },
                                adaptation_challenges: { type: 'array', items: { type: 'string' } }
                            }
                        }
                    }
                }
            });

            setRecommendations(result);
            toast.success('Recommendations generated!', { id: 'ai-recommend' });
        } catch (error) {
            toast.error('Failed to generate', { id: 'ai-recommend' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const actionColors = {
        Sign: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        Monitor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        Sell: 'bg-red-500/20 text-red-400 border-red-500/30',
        'Loan Out': 'bg-amber-500/20 text-amber-400 border-amber-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                    AI Recommendation Engine
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {!recommendations ? (
                    <div className="text-center py-8">
                        <Target className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Get AI-powered development plans and transfer recommendations for {player.name}
                        </p>
                        <Button
                            onClick={generateRecommendations}
                            disabled={loading}
                            className="bg-gradient-to-r from-amber-500 to-orange-600"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Recommendations
                                </>
                            )}
                        </Button>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <Tabs defaultValue="development" className="space-y-4">
                            <TabsList className="bg-slate-800 w-full grid grid-cols-3">
                                <TabsTrigger value="development">Development</TabsTrigger>
                                <TabsTrigger value="transfer">Transfer</TabsTrigger>
                                <TabsTrigger value="fit">Club Fit</TabsTrigger>
                            </TabsList>

                            <TabsContent value="development" className="space-y-4">
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-cyan-400 font-semibold mb-3 flex items-center gap-2">
                                        <Target className="w-4 h-4" />
                                        Training Priorities
                                    </h4>
                                    <ul className="space-y-2">
                                        {recommendations.development_plan?.training_priorities?.map((priority, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-cyan-400 font-bold">{idx + 1}.</span>
                                                {priority}
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-blue-400 font-semibold mb-2">Tactical Development</h4>
                                    <p className="text-slate-300 text-sm">{recommendations.development_plan?.tactical_development}</p>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-purple-400 font-semibold mb-2">Physical Program</h4>
                                    <p className="text-slate-300 text-sm">{recommendations.development_plan?.physical_program}</p>
                                </div>

                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    Timeline: {recommendations.development_plan?.timeline}
                                </Badge>
                            </TabsContent>

                            <TabsContent value="transfer" className="space-y-4">
                                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                                    <div className="flex items-center justify-between mb-3">
                                        <h4 className="text-white font-bold text-lg">Transfer Recommendation</h4>
                                        <Badge className={actionColors[recommendations.transfer_assessment?.action]}>
                                            {recommendations.transfer_assessment?.action}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-300 text-sm mb-3">{recommendations.transfer_assessment?.reasoning}</p>
                                    <div className="flex items-center gap-2 text-cyan-400 font-semibold">
                                        <TrendingUp className="w-4 h-4" />
                                        Ideal Fee: {recommendations.transfer_assessment?.ideal_fee}
                                    </div>
                                </div>

                                {recommendations.transfer_assessment?.alternative_targets?.length > 0 && (
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h4 className="text-amber-400 font-semibold mb-3">Alternative Targets</h4>
                                        <div className="space-y-2">
                                            {recommendations.transfer_assessment.alternative_targets.map((target, idx) => (
                                                <Badge key={idx} variant="outline" className="mr-2">
                                                    {target}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="fit" className="space-y-4">
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-cyan-400 font-semibold mb-3 flex items-center gap-2">
                                        <Users className="w-4 h-4" />
                                        Ideal Clubs
                                    </h4>
                                    <div className="space-y-2">
                                        {recommendations.club_fit_analysis?.ideal_clubs?.map((club, idx) => (
                                            <div key={idx} className="bg-slate-900/50 rounded p-2">
                                                <p className="text-white text-sm">{club}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-blue-400 font-semibold mb-2">Ideal League</h4>
                                    <p className="text-slate-300 text-sm">{recommendations.club_fit_analysis?.ideal_league}</p>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-emerald-400 font-semibold mb-2">Playing Time Outlook</h4>
                                    <p className="text-slate-300 text-sm">{recommendations.club_fit_analysis?.playing_time_outlook}</p>
                                </div>

                                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                    <h4 className="text-amber-400 font-semibold mb-2">Adaptation Challenges</h4>
                                    <ul className="space-y-1">
                                        {recommendations.club_fit_analysis?.adaptation_challenges?.map((challenge, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm">• {challenge}</li>
                                        ))}
                                    </ul>
                                </div>
                            </TabsContent>
                        </Tabs>

                        <Button
                            onClick={generateRecommendations}
                            variant="outline"
                            className="w-full border-slate-700 mt-4"
                        >
                            <Sparkles className="w-4 h-4 mr-2" />
                            Regenerate Recommendations
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}