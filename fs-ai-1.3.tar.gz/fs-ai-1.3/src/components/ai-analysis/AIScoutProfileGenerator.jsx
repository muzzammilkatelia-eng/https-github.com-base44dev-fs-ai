import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Loader2, Target, TrendingUp, CheckCircle, AlertTriangle, Clipboard } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIScoutProfileGenerator({ player }) {
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: reports = [] } = useQuery({
        queryKey: ['reports-profile', player?.id],
        queryFn: () => base44.entities.ScoutingReport.filter({ player_name: player?.name }),
        enabled: !!player
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['findings-profile', player?.id],
        queryFn: () => base44.entities.ScoutFinding.filter({ player_name: player?.name }),
        enabled: !!player
    });

    const generateProfile = async () => {
        setLoading(true);
        toast.loading('Generating comprehensive scout profile...', { id: 'profile' });

        try {
            const reportSummaries = reports.map(r => ({
                modules: r.modules_activated,
                recommendation: r.recommendation,
                verdict: r.overall_verdict,
                calafat: r.calafat_analysis,
                brighton: r.brighton_analysis
            }));

            const findingSummaries = findings.map(f => ({
                type: f.finding_type,
                priority: f.priority,
                summary: f.summary,
                strengths: f.key_strengths,
                development: f.areas_for_development,
                recommendation: f.recommendation
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a senior football scout. Generate a COMPREHENSIVE SCOUT PROFILE consolidating all intelligence.

PLAYER DATA:
Name: ${player.name}
Age: ${player.age}
Position: ${player.position}
Club: ${player.current_club}
Market Value: €${player.market_value}M
Contract Expiry: ${player.contract_expiry || 'Unknown'}

PHYSICAL: ${JSON.stringify(player.physical_attributes || {})}
PLAYING STYLE: ${JSON.stringify(player.playing_style || {})}
CAREER: ${JSON.stringify(player.career_history?.slice(0, 3) || [])}

SCOUTING REPORTS (${reports.length}):
${JSON.stringify(reportSummaries, null, 2)}

SCOUT FINDINGS (${findings.length}):
${JSON.stringify(findingSummaries, null, 2)}

Generate a comprehensive scout profile with:

1. **Executive Summary** (2-3 sentences capturing essence of player)

2. **Strengths Analysis** 
   - top_strengths: array of 5 key strengths with brief explanation each
   
3. **Development Areas**
   - areas: array of 3-4 areas needing improvement with specific training recommendations

4. **Tactical Profile**
   - best_role: string (specific role like "Inverted Winger", "Box-to-Box Midfielder")
   - ideal_formation: string
   - tactical_instructions: array of 3-4 specific instructions

5. **Risk Assessment**
   - injury_risk: "Low" | "Medium" | "High"
   - adaptation_risk: "Low" | "Medium" | "High"  
   - key_risks: array of 2-3 specific risks

6. **Recommended Next Steps**
   - immediate_actions: array of 2-3 actions to take now
   - timeline: string
   - priority_level: "Critical" | "High" | "Medium" | "Low"

7. **Final Verdict**
   - verdict: string (one sentence recommendation)
   - confidence: number (0-100)

Return as JSON.`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        executive_summary: { type: 'string' },
                        strengths_analysis: {
                            type: 'object',
                            properties: {
                                top_strengths: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        development_areas: {
                            type: 'object',
                            properties: {
                                areas: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        tactical_profile: {
                            type: 'object',
                            properties: {
                                best_role: { type: 'string' },
                                ideal_formation: { type: 'string' },
                                tactical_instructions: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        risk_assessment: {
                            type: 'object',
                            properties: {
                                injury_risk: { type: 'string' },
                                adaptation_risk: { type: 'string' },
                                key_risks: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        recommended_next_steps: {
                            type: 'object',
                            properties: {
                                immediate_actions: { type: 'array', items: { type: 'string' } },
                                timeline: { type: 'string' },
                                priority_level: { type: 'string' }
                            }
                        },
                        final_verdict: {
                            type: 'object',
                            properties: {
                                verdict: { type: 'string' },
                                confidence: { type: 'number' }
                            }
                        }
                    }
                }
            });

            setProfile(result);
            toast.success('Scout profile generated!', { id: 'profile' });
        } catch (error) {
            toast.error('Generation failed', { id: 'profile' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const copyToClipboard = () => {
        const text = `SCOUT PROFILE: ${player.name}\n\n${profile.executive_summary}\n\nStrengths:\n${profile.strengths_analysis?.top_strengths?.join('\n')}\n\nVerdict: ${profile.final_verdict?.verdict}`;
        navigator.clipboard.writeText(text);
        toast.success('Copied to clipboard!');
    };

    const riskColors = {
        Low: 'bg-emerald-500/20 text-emerald-400',
        Medium: 'bg-amber-500/20 text-amber-400',
        High: 'bg-red-500/20 text-red-400'
    };

    const priorityColors = {
        Critical: 'bg-red-500/20 text-red-400',
        High: 'bg-orange-500/20 text-orange-400',
        Medium: 'bg-blue-500/20 text-blue-400',
        Low: 'bg-slate-500/20 text-slate-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <FileText className="w-5 h-5 text-cyan-400" />
                    AI Scout Profile Generator
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!profile ? (
                    <div className="text-center py-8">
                        <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-2">
                            Generate a comprehensive scout profile for {player.name}
                        </p>
                        <p className="text-slate-500 text-sm mb-4">
                            Consolidates {reports.length} reports and {findings.length} findings
                        </p>
                        <Button
                            onClick={generateProfile}
                            disabled={loading}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                            ) : (
                                <><FileText className="w-4 h-4 mr-2" /> Generate Scout Profile</>
                            )}
                        </Button>
                    </div>
                ) : (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                        {/* Executive Summary */}
                        <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-cyan-400 font-semibold">Executive Summary</h4>
                                <Button size="sm" variant="ghost" onClick={copyToClipboard}>
                                    <Clipboard className="w-4 h-4" />
                                </Button>
                            </div>
                            <p className="text-white">{profile.executive_summary}</p>
                        </div>

                        <Tabs defaultValue="strengths" className="space-y-4">
                            <TabsList className="bg-slate-800 w-full grid grid-cols-4">
                                <TabsTrigger value="strengths">Strengths</TabsTrigger>
                                <TabsTrigger value="tactical">Tactical</TabsTrigger>
                                <TabsTrigger value="risks">Risks</TabsTrigger>
                                <TabsTrigger value="actions">Actions</TabsTrigger>
                            </TabsList>

                            <TabsContent value="strengths" className="space-y-3">
                                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                    <h4 className="text-emerald-400 font-semibold mb-3 flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" /> Key Strengths
                                    </h4>
                                    <ul className="space-y-2">
                                        {profile.strengths_analysis?.top_strengths?.map((s, i) => (
                                            <li key={i} className="text-slate-300 text-sm">• {s}</li>
                                        ))}
                                    </ul>
                                </div>
                                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                    <h4 className="text-amber-400 font-semibold mb-3">Development Areas</h4>
                                    <ul className="space-y-2">
                                        {profile.development_areas?.areas?.map((a, i) => (
                                            <li key={i} className="text-slate-300 text-sm">• {a}</li>
                                        ))}
                                    </ul>
                                </div>
                            </TabsContent>

                            <TabsContent value="tactical" className="space-y-3">
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Best Role</p>
                                        <p className="text-white font-semibold">{profile.tactical_profile?.best_role}</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Ideal Formation</p>
                                        <p className="text-white font-semibold">{profile.tactical_profile?.ideal_formation}</p>
                                    </div>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-purple-400 font-semibold mb-2">Tactical Instructions</h4>
                                    <ul className="space-y-1">
                                        {profile.tactical_profile?.tactical_instructions?.map((t, i) => (
                                            <li key={i} className="text-slate-300 text-sm">• {t}</li>
                                        ))}
                                    </ul>
                                </div>
                            </TabsContent>

                            <TabsContent value="risks" className="space-y-3">
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Injury Risk</p>
                                        <Badge className={riskColors[profile.risk_assessment?.injury_risk]}>
                                            {profile.risk_assessment?.injury_risk}
                                        </Badge>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Adaptation Risk</p>
                                        <Badge className={riskColors[profile.risk_assessment?.adaptation_risk]}>
                                            {profile.risk_assessment?.adaptation_risk}
                                        </Badge>
                                    </div>
                                </div>
                                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                                    <h4 className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4" /> Key Risks
                                    </h4>
                                    <ul className="space-y-1">
                                        {profile.risk_assessment?.key_risks?.map((r, i) => (
                                            <li key={i} className="text-slate-300 text-sm">• {r}</li>
                                        ))}
                                    </ul>
                                </div>
                            </TabsContent>

                            <TabsContent value="actions" className="space-y-3">
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge className={priorityColors[profile.recommended_next_steps?.priority_level]}>
                                        {profile.recommended_next_steps?.priority_level} Priority
                                    </Badge>
                                    <span className="text-slate-400 text-sm">{profile.recommended_next_steps?.timeline}</span>
                                </div>
                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                    <h4 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
                                        <Target className="w-4 h-4" /> Immediate Actions
                                    </h4>
                                    <ul className="space-y-2">
                                        {profile.recommended_next_steps?.immediate_actions?.map((a, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-cyan-400 font-bold">{i + 1}.</span> {a}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </TabsContent>
                        </Tabs>

                        {/* Final Verdict */}
                        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h4 className="text-purple-400 font-semibold mb-1">Final Verdict</h4>
                                    <p className="text-white">{profile.final_verdict?.verdict}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-3xl font-bold text-purple-400">{profile.final_verdict?.confidence}%</p>
                                    <p className="text-slate-500 text-xs">Confidence</p>
                                </div>
                            </div>
                        </div>

                        <Button onClick={generateProfile} variant="outline" className="w-full border-slate-700">
                            Regenerate Profile
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}