import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, FileText, TrendingUp, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import toast from 'react-hot-toast';

export default function AIScoutingReportGenerator({ player }) {
    const [report, setReport] = useState(null);
    const [loading, setLoading] = useState(false);

    const generateReport = async () => {
        setLoading(true);
        toast.loading('AI analyzing player...', { id: 'ai-report' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football scout. Generate a comprehensive scouting report for the following player:

**Player Information:**
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Club: ${player.current_club || 'N/A'}
- Nationality: ${player.nationality || 'N/A'}
- Market Value: €${player.market_value}M
- Contract Expiry: ${player.contract_expiry || 'N/A'}

**Physical Attributes:**
${player.physical_attributes ? JSON.stringify(player.physical_attributes, null, 2) : 'Not available'}

**Playing Style:**
${player.playing_style ? JSON.stringify(player.playing_style, null, 2) : 'Not available'}

**Career History:**
${player.career_history ? player.career_history.slice(0, 3).map(h => `${h.season}: ${h.club} - ${h.appearances} apps, ${h.goals} goals`).join('\n') : 'Not available'}

**Awards & Honours:**
${player.awards_honours?.slice(0, 5).map(a => `- ${a.award_name} (${a.year})`).join('\n') || 'None listed'}

**Injury History:**
${player.injury_history?.length > 0 ? `${player.injury_history.length} injuries recorded (Injury Risk Score: ${player.injury_prone_score || 'N/A'})` : 'Clean injury record'}

Generate a professional scouting report with the following sections:
1. **Executive Summary** - 2-3 sentences overview
2. **Technical Analysis** - Skills, technique, tactical intelligence
3. **Physical Assessment** - Pace, strength, stamina, athleticism
4. **Mental & Character** - Work rate, leadership, decision-making
5. **Strengths** - Top 3-4 key strengths
6. **Areas for Development** - 2-3 weaknesses or growth areas
7. **Market Value Assessment** - Is the current valuation fair?
8. **Recommendation** - Sign/Monitor/Pass with reasoning

Be detailed, professional, and data-driven.`,
                add_context_from_internet: false
            });

            setReport(result);
            toast.success('AI report generated!', { id: 'ai-report' });
        } catch (error) {
            toast.error('Failed to generate report', { id: 'ai-report' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const saveReport = async () => {
        if (!report) return;

        toast.loading('Saving report...', { id: 'save-report' });
        
        try {
            await base44.entities.ScoutingReport.create({
                player_name: player.name,
                player_age: player.age,
                position: player.position,
                modules_activated: ['AI Analysis'],
                overall_verdict: report.substring(0, 500),
                recommendation: 'Recommend',
                notes: `AI-Generated Report\n\n${report}`
            });
            toast.success('Report saved!', { id: 'save-report' });
        } catch (error) {
            toast.error('Failed to save report', { id: 'save-report' });
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    AI Scouting Report Generator
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {!report ? (
                    <div className="text-center py-8">
                        <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Generate a comprehensive AI-powered scouting report for {player.name}
                        </p>
                        <Button
                            onClick={generateReport}
                            disabled={loading}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate AI Report
                                </>
                            )}
                        </Button>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <ReactMarkdown className="prose prose-invert prose-sm max-w-none">
                                {report}
                            </ReactMarkdown>
                        </div>
                        <div className="flex gap-3">
                            <Button
                                onClick={saveReport}
                                className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            >
                                <FileText className="w-4 h-4 mr-2" />
                                Save Report
                            </Button>
                            <Button
                                onClick={generateReport}
                                variant="outline"
                                className="border-slate-700"
                            >
                                <Sparkles className="w-4 h-4 mr-2" />
                                Regenerate
                            </Button>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}