import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Swords, Loader2, AlertCircle, Users, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AITransferConflictPredictor() {
    const [predictions, setPredictions] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-conflict'],
        queryFn: () => base44.entities.Player.list('-market_value', 40)
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['findings-conflict'],
        queryFn: () => base44.entities.ScoutFinding.list('-created_date', 30)
    });

    const predictConflicts = async () => {
        setLoading(true);
        toast.loading('AI predicting transfer conflicts...', { id: 'conflict' });

        try {
            const highValuePlayers = players.filter(p => p.market_value > 20).slice(0, 20);
            const playerData = highValuePlayers.map(p => ({
                name: p.name,
                age: p.age,
                position: p.position,
                club: p.current_club,
                value: p.market_value,
                contract_expiry: p.contract_expiry,
                transfer_status: p.transfer_status
            }));

            const interestSignals = findings.filter(f => 
                f.finding_type === 'Transfer Intelligence' || f.priority === 'Critical'
            ).slice(0, 15).map(f => ({
                player: f.player_name,
                type: f.finding_type,
                summary: f.summary,
                interested_clubs: f.market_intelligence?.interested_clubs || []
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a transfer market intelligence analyst. Predict potential BIDDING WARS and TRANSFER CONFLICTS.

HIGH-VALUE PLAYERS:
${JSON.stringify(playerData, null, 2)}

TRANSFER INTELLIGENCE SIGNALS:
${JSON.stringify(interestSignals, null, 2)}

Identify players likely to trigger bidding wars. For each, provide:
- player_name: string
- conflict_probability: number (0-100)
- likely_bidders: array of 3-5 club names
- trigger_factors: array of 2-3 reasons why conflict is likely
- expected_final_fee: string (e.g., "€80-100M")
- timeline: string (e.g., "Summer 2025")
- recommendation: string (action advice for scouts)

Return JSON with "conflicts" array containing 4-6 most likely bidding wars.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        conflicts: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    conflict_probability: { type: 'number' },
                                    likely_bidders: { type: 'array', items: { type: 'string' } },
                                    trigger_factors: { type: 'array', items: { type: 'string' } },
                                    expected_final_fee: { type: 'string' },
                                    timeline: { type: 'string' },
                                    recommendation: { type: 'string' }
                                }
                            }
                        }
                    }
                }
            });

            setPredictions(result.conflicts || []);
            toast.success('Conflict predictions ready!', { id: 'conflict' });
        } catch (error) {
            toast.error('Prediction failed', { id: 'conflict' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const getProbabilityColor = (prob) => {
        if (prob >= 80) return 'text-red-400';
        if (prob >= 60) return 'text-amber-400';
        return 'text-blue-400';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <Swords className="w-5 h-5 text-red-400" />
                    AI Transfer Conflict Predictor
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!predictions ? (
                    <div className="text-center py-8">
                        <Swords className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Predict bidding wars and transfer conflicts for high-value targets
                        </p>
                        <Button
                            onClick={predictConflicts}
                            disabled={loading}
                            className="bg-gradient-to-r from-red-500 to-orange-600"
                        >
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                            ) : (
                                <><Swords className="w-4 h-4 mr-2" /> Predict Conflicts</>
                            )}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {predictions.map((conflict, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-gradient-to-r from-red-500/5 to-orange-500/5 rounded-lg p-4 border border-red-500/20"
                            >
                                <div className="flex items-start justify-between mb-3">
                                    <div>
                                        <h4 className="text-white font-bold text-lg">{conflict.player_name}</h4>
                                        <p className="text-slate-400 text-sm">{conflict.timeline}</p>
                                    </div>
                                    <div className="text-right">
                                        <div className={`font-bold text-2xl ${getProbabilityColor(conflict.conflict_probability)}`}>
                                            {conflict.conflict_probability}%
                                        </div>
                                        <p className="text-slate-500 text-xs">Conflict Probability</p>
                                    </div>
                                </div>

                                <div className="mb-3">
                                    <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                        <Users className="w-3 h-3" /> Likely Bidders
                                    </p>
                                    <div className="flex flex-wrap gap-1">
                                        {conflict.likely_bidders?.map((club, i) => (
                                            <Badge key={i} variant="outline" className="text-xs border-slate-600">
                                                {club}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div className="mb-3">
                                    <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                        <AlertCircle className="w-3 h-3" /> Trigger Factors
                                    </p>
                                    <ul className="text-slate-300 text-sm space-y-1">
                                        {conflict.trigger_factors?.map((factor, i) => (
                                            <li key={i}>• {factor}</li>
                                        ))}
                                    </ul>
                                </div>

                                <div className="flex items-center justify-between pt-2 border-t border-slate-700">
                                    <div className="flex items-center gap-1 text-emerald-400">
                                        <TrendingUp className="w-4 h-4" />
                                        <span className="font-semibold">{conflict.expected_final_fee}</span>
                                    </div>
                                    <p className="text-slate-400 text-xs max-w-[60%] text-right">{conflict.recommendation}</p>
                                </div>
                            </motion.div>
                        ))}
                        <Button onClick={predictConflicts} variant="outline" className="w-full border-slate-700">
                            Re-analyze
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}