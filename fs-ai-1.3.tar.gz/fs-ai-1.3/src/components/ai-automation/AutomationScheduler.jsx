import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Clock, Calendar, Zap, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AutomationScheduler({ criteria, onUpdate }) {
    const [schedule, setSchedule] = useState({
        enabled: false,
        frequency: 'daily',
        time: '09:00',
        days: ['monday', 'wednesday', 'friday']
    });

    const handleSave = () => {
        toast.success('Automation schedule saved!');
        onUpdate({ ...criteria, automation_schedule: schedule });
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 text-cyan-400" />
                    Automation Schedule
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg">
                    <div>
                        <p className="text-white font-semibold">Enable Scheduled Automation</p>
                        <p className="text-slate-400 text-sm">Run AI agent automatically on schedule</p>
                    </div>
                    <Switch
                        checked={schedule.enabled}
                        onCheckedChange={(checked) => setSchedule(prev => ({ ...prev, enabled: checked }))}
                    />
                </div>

                {schedule.enabled && (
                    <>
                        <div>
                            <label className="text-white font-semibold mb-3 block">Frequency</label>
                            <Select 
                                value={schedule.frequency} 
                                onValueChange={(value) => setSchedule(prev => ({ ...prev, frequency: value }))}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="hourly">Every Hour</SelectItem>
                                    <SelectItem value="daily">Daily</SelectItem>
                                    <SelectItem value="weekly">Weekly</SelectItem>
                                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {schedule.frequency === 'weekly' && (
                            <div>
                                <label className="text-white font-semibold mb-3 block">Days of Week</label>
                                <div className="grid grid-cols-2 gap-2">
                                    {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map(day => (
                                        <label key={day} className="flex items-center gap-2 p-3 bg-slate-800/50 rounded cursor-pointer hover:bg-slate-800">
                                            <input
                                                type="checkbox"
                                                checked={schedule.days.includes(day)}
                                                onChange={(e) => {
                                                    if (e.target.checked) {
                                                        setSchedule(prev => ({ ...prev, days: [...prev.days, day] }));
                                                    } else {
                                                        setSchedule(prev => ({ ...prev, days: prev.days.filter(d => d !== day) }));
                                                    }
                                                }}
                                                className="rounded"
                                            />
                                            <span className="text-slate-300 capitalize">{day}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <div className="flex items-start gap-2">
                                <Calendar className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                <div>
                                    <p className="text-cyan-400 font-semibold text-sm mb-1">Automation Schedule</p>
                                    <p className="text-slate-300 text-sm">
                                        AI agent will run <span className="font-semibold">{schedule.frequency}</span>
                                        {schedule.frequency === 'weekly' && schedule.days.length > 0 && (
                                            <> on <span className="font-semibold">{schedule.days.map(d => d.slice(0,3)).join(', ')}</span></>
                                        )}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </>
                )}

                {!schedule.enabled && (
                    <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-8 text-center">
                        <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">
                            Enable scheduled automation to run AI scouting automatically
                        </p>
                    </div>
                )}

                <Button onClick={handleSave} className="w-full">
                    <Zap className="w-4 h-4 mr-2" />
                    Save Schedule
                </Button>
            </CardContent>
        </Card>
    );
}