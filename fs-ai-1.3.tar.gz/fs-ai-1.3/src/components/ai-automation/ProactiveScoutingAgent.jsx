import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Target, CheckCircle2, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ProactiveScoutingAgent({ criteria, players }) {
    const queryClient = useQueryClient();
    const [scanning, setScanning] = useState(false);
    const [results, setResults] = useState(null);

    const runAutomation = async () => {
        setScanning(true);
        toast.loading('AI Agent scanning players...', { id: 'scan' });

        try {
            // Filter players based on criteria
            const matchingPlayers = players.filter(player => {
                let matches = true;

                if (criteria.filters?.min_potential_rating && player.fsai_proprietary_score) {
                    matches = matches && player.fsai_proprietary_score >= criteria.filters.min_potential_rating;
                }

                if (criteria.filters?.max_age) {
                    matches = matches && player.age <= criteria.filters.max_age;
                }

                if (criteria.filters?.min_age) {
                    matches = matches && player.age >= criteria.filters.min_age;
                }

                if (criteria.filters?.positions?.length > 0) {
                    matches = matches && criteria.filters.positions.includes(player.position);
                }

                if (criteria.filters?.max_valuation && player.market_value) {
                    matches = matches && player.market_value <= criteria.filters.max_valuation;
                }

                if (criteria.filters?.regions?.length > 0 && player.nationality) {
                    matches = matches && criteria.filters.regions.includes(player.nationality);
                }

                return matches;
            });

            if (matchingPlayers.length === 0) {
                toast.error('No players match the criteria', { id: 'scan' });
                setScanning(false);
                return;
            }

            // Generate reports for matching players
            const reportsGenerated = [];
            const tasksCreated = [];
            const alertsCreated = [];

            for (const player of matchingPlayers.slice(0, 10)) { // Limit to 10 to avoid overwhelming
                // Generate AI scouting report
                const reportPrompt = `Generate a comprehensive scouting report for ${player.name}, a ${player.age}-year-old ${player.position} playing for ${player.current_club}.

PLAYER PROFILE:
- Position: ${player.position}
- Age: ${player.age}
- Current Club: ${player.current_club}
- Nationality: ${player.nationality}
- Market Value: €${player.market_value}M
${player.fsai_proprietary_score ? `- FS-AI Score: ${player.fsai_proprietary_score}/100` : ''}

CRITERIA MATCH: ${criteria.name}
CRITERIA TYPE: ${criteria.criteria_type}

Provide detailed analysis of strengths, weaknesses, potential, and recommendation.`;

                const reportData = await base44.integrations.Core.InvokeLLM({
                    prompt: reportPrompt,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            overall_verdict: { type: "string" },
                            strengths: { type: "array", items: { type: "string" } },
                            weaknesses: { type: "array", items: { type: "string" } },
                            potential_rating: { type: "number" },
                            recommendation: { 
                                type: "string",
                                enum: ["Strong Recommend", "Recommend", "Monitor", "Pass"]
                            },
                            key_attributes: {
                                type: "object",
                                properties: {
                                    technical: { type: "number" },
                                    physical: { type: "number" },
                                    mental: { type: "number" },
                                    tactical: { type: "number" }
                                }
                            }
                        }
                    }
                });

                const report = await base44.entities.ScoutingReport.create({
                    player_name: player.name,
                    player_age: player.age,
                    position: player.position,
                    modules_activated: ['AI Automation'],
                    overall_verdict: reportData.overall_verdict,
                    recommendation: reportData.recommendation,
                    notes: `Auto-generated by AI Agent: ${criteria.name}`
                });

                reportsGenerated.push(report);

                // Create task if auto-assign is enabled
                if (criteria.auto_assign && criteria.default_assignee) {
                    const task = await base44.entities.ScoutingTask.create({
                        player_name: player.name,
                        assigned_to: criteria.default_assignee,
                        task_type: 'Initial Assessment',
                        priority: criteria.priority_level || 'Medium',
                        status: 'Pending',
                        source: 'AI Flag',
                        criteria_met: [criteria.name],
                        player_data: {
                            age: player.age,
                            position: player.position,
                            current_valuation: player.market_value,
                            potential_rating: reportData.potential_rating
                        }
                    });

                    tasksCreated.push(task);
                }

                // Create alert if enabled
                if (criteria.notification_enabled) {
                    const alert = await base44.entities.Alert.create({
                        player_name: player.name,
                        alert_type: 'scouting_report',
                        criteria_name: criteria.name,
                        player_details: {
                            age: player.age,
                            position: player.position,
                            recommendation: reportData.recommendation,
                            potential_rating: reportData.potential_rating
                        }
                    });

                    alertsCreated.push(alert);
                }
            }

            setResults({
                playersScanned: players.length,
                matchingPlayers: matchingPlayers.length,
                reportsGenerated: reportsGenerated.length,
                tasksCreated: tasksCreated.length,
                alertsCreated: alertsCreated.length,
                topPlayers: matchingPlayers.slice(0, 5).map(p => ({
                    name: p.name,
                    position: p.position,
                    age: p.age,
                    score: p.fsai_proprietary_score
                }))
            });

            queryClient.invalidateQueries({ queryKey: ['reports'] });
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['alerts'] });

            toast.success(`Generated ${reportsGenerated.length} reports, ${tasksCreated.length} tasks, ${alertsCreated.length} alerts!`, { id: 'scan' });
        } catch (error) {
            console.error('Automation failed:', error);
            toast.error('AI automation failed', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    return (
        <Card className="bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border-purple-500/30">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    Proactive AI Scouting Agent
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Automatically scan {players.length} players against "{criteria.name}" criteria
                </p>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="bg-slate-900/50 rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Criteria Type</span>
                        <Badge className="bg-cyan-500/20 text-cyan-400">{criteria.criteria_type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Priority Level</span>
                        <Badge className="bg-amber-500/20 text-amber-400">{criteria.priority_level}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Auto-Assign Tasks</span>
                        {criteria.auto_assign ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        ) : (
                            <AlertTriangle className="w-5 h-5 text-slate-600" />
                        )}
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="text-slate-400 text-sm">Notifications</span>
                        {criteria.notification_enabled ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        ) : (
                            <AlertTriangle className="w-5 h-5 text-slate-600" />
                        )}
                    </div>
                </div>

                {results && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 space-y-3"
                    >
                        <div className="flex items-center gap-2 mb-3">
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                            <span className="text-emerald-400 font-semibold">Automation Complete</span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-3">
                            <div className="bg-slate-900/50 rounded p-3">
                                <p className="text-slate-400 text-xs mb-1">Players Scanned</p>
                                <p className="text-white text-2xl font-bold">{results.playersScanned}</p>
                            </div>
                            <div className="bg-slate-900/50 rounded p-3">
                                <p className="text-slate-400 text-xs mb-1">Matches Found</p>
                                <p className="text-cyan-400 text-2xl font-bold">{results.matchingPlayers}</p>
                            </div>
                            <div className="bg-slate-900/50 rounded p-3">
                                <p className="text-slate-400 text-xs mb-1">Reports Generated</p>
                                <p className="text-purple-400 text-2xl font-bold">{results.reportsGenerated}</p>
                            </div>
                            <div className="bg-slate-900/50 rounded p-3">
                                <p className="text-slate-400 text-xs mb-1">Tasks Created</p>
                                <p className="text-amber-400 text-2xl font-bold">{results.tasksCreated}</p>
                            </div>
                        </div>

                        {results.topPlayers.length > 0 && (
                            <div>
                                <p className="text-white font-semibold mb-2 text-sm">Top Prospects Found:</p>
                                <div className="space-y-1">
                                    {results.topPlayers.map((player, idx) => (
                                        <div key={idx} className="flex items-center justify-between text-sm">
                                            <span className="text-slate-300">{player.name}</span>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    {player.position}, {player.age}y
                                                </Badge>
                                                {player.score && (
                                                    <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                                                        {player.score}
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </motion.div>
                )}

                <Button
                    onClick={runAutomation}
                    disabled={scanning || !criteria.active}
                    className="w-full bg-gradient-to-r from-purple-500 to-cyan-600 hover:from-purple-400 hover:to-cyan-500"
                    size="lg"
                >
                    {scanning ? (
                        <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            AI Agent Scanning...
                        </>
                    ) : (
                        <>
                            <Target className="w-5 h-5 mr-2" />
                            Run Proactive Scouting
                        </>
                    )}
                </Button>

                {!criteria.active && (
                    <p className="text-amber-400 text-xs text-center">
                        This criteria is inactive. Activate it to run automation.
                    </p>
                )}
            </CardContent>
        </Card>
    );
}