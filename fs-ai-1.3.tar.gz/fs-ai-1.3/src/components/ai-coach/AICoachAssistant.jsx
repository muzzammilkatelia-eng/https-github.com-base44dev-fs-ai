import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, Activity, Zap, Target, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AICoachAssistant({ playerData, gpsMetrics }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzePerformance = async () => {
        if (!playerData && !gpsMetrics) {
            toast.error('No performance data available');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('AI Coach analyzing performance data...', { id: 'ai-coach' });

        try {
            const prompt = `You are an elite football performance coach analyzing player data to provide personalized training recommendations.

**Player Data:**
${playerData ? `
- Name: ${playerData.name}
- Position: ${playerData.position}
- Age: ${playerData.age}
- Current Club: ${playerData.current_club}
` : ''}

**Latest Performance Metrics:**
${gpsMetrics ? `
- Distance: ${gpsMetrics.distance} km
- Top Speed: ${gpsMetrics.topSpeed} km/h
- Sprints: ${gpsMetrics.sprints}
- High Intensity Runs: ${gpsMetrics.highIntensityRuns}
- Heart Rate: ${gpsMetrics.heartRate} bpm (Avg: ${gpsMetrics.heartRateAvg})
- Player Load: ${gpsMetrics.playerLoad} AU
- Stress Index: ${gpsMetrics.stressIndex}
- Fatigue Score: ${gpsMetrics.fatigueScore}
- Metabolic Power: ${gpsMetrics.metabolicPower} W/kg
- Asymmetry Index: ${gpsMetrics.asymmetryIndex}%
- Explosive Actions: ${gpsMetrics.explosiveActions}
- Workload: ${gpsMetrics.workload} AU
- Recovery Status: ${gpsMetrics.recoveryStatus}
` : 'No GPS data available'}

Provide a comprehensive coaching analysis including:
1. Overall Performance Assessment (score 1-10)
2. Key Strengths identified from the data
3. Areas of Concern (injury risk, overtraining, asymmetry issues)
4. Specific Training Recommendations (what to focus on)
5. Recovery Protocols needed
6. Load Management advice
7. Short-term goals (next 7 days)
8. Long-term development priorities`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_score: { type: "number" },
                        assessment: { type: "string" },
                        strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        concerns: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    issue: { type: "string" },
                                    severity: { type: "string" },
                                    recommendation: { type: "string" }
                                }
                            }
                        },
                        training_recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    focus_area: { type: "string" },
                                    exercises: { type: "array", items: { type: "string" } },
                                    duration: { type: "string" },
                                    intensity: { type: "string" }
                                }
                            }
                        },
                        recovery_protocol: { type: "string" },
                        load_management: { type: "string" },
                        short_term_goals: { type: "array", items: { type: "string" } },
                        long_term_priorities: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis(response);
            toast.success('AI Coach analysis complete', { id: 'ai-coach' });
        } catch (error) {
            console.error('AI Coach error:', error);
            toast.error('Failed to analyze performance', { id: 'ai-coach' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getSeverityColor = (severity) => {
        const colors = {
            'Critical': 'bg-red-500/20 text-red-400 border-red-500/30',
            'High': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
            'Moderate': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        };
        return colors[severity] || colors['Moderate'];
    };

    return (
        <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-400" />
                        AI Performance Coach
                    </CardTitle>
                    <Button
                        onClick={analyzePerformance}
                        disabled={isAnalyzing}
                        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Brain className="w-4 h-4 mr-2" />
                                Analyze Performance
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-12">
                        <Brain className="w-16 h-16 text-purple-400/50 mx-auto mb-4" />
                        <p className="text-slate-400">Click "Analyze Performance" to get AI coaching insights</p>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Overall Assessment */}
                        <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-4 border border-purple-500/30">
                            <div className="flex items-center justify-between mb-2">
                                <h3 className="text-white font-semibold flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-purple-400" />
                                    Overall Performance
                                </h3>
                                <Badge className="bg-purple-500/20 text-purple-300 text-lg">
                                    {analysis.overall_score}/10
                                </Badge>
                            </div>
                            <p className="text-slate-300 text-sm">{analysis.assessment}</p>
                        </div>

                        {/* Strengths */}
                        <div>
                            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-emerald-400" />
                                Key Strengths
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                {analysis.strengths.map((strength, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 rounded-lg p-3 border border-emerald-500/30">
                                        <p className="text-emerald-300 text-sm">{strength}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Concerns */}
                        {analysis.concerns.length > 0 && (
                            <div>
                                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                                    Areas of Concern
                                </h3>
                                <div className="space-y-2">
                                    {analysis.concerns.map((concern, idx) => (
                                        <div key={idx} className={`rounded-lg p-3 border ${getSeverityColor(concern.severity)}`}>
                                            <div className="flex items-start justify-between mb-1">
                                                <p className="font-semibold text-sm">{concern.issue}</p>
                                                <Badge variant="outline" className="text-xs">
                                                    {concern.severity}
                                                </Badge>
                                            </div>
                                            <p className="text-xs opacity-90">{concern.recommendation}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Training Recommendations */}
                        <div>
                            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                <Activity className="w-4 h-4 text-cyan-400" />
                                Training Program
                            </h3>
                            <div className="space-y-3">
                                {analysis.training_recommendations.map((rec, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/30">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4 className="text-cyan-300 font-semibold">{rec.focus_area}</h4>
                                            <div className="flex gap-2">
                                                <Badge variant="outline" className="text-xs">{rec.duration}</Badge>
                                                <Badge className="bg-cyan-500/20 text-cyan-300 text-xs">{rec.intensity}</Badge>
                                            </div>
                                        </div>
                                        <ul className="space-y-1">
                                            {rec.exercises.map((exercise, eidx) => (
                                                <li key={eidx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-cyan-400 mt-1">•</span>
                                                    {exercise}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Recovery & Load Management */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                    <Zap className="w-4 h-4 text-amber-400" />
                                    Recovery Protocol
                                </h4>
                                <p className="text-slate-300 text-sm">{analysis.recovery_protocol}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                    <Target className="w-4 h-4 text-purple-400" />
                                    Load Management
                                </h4>
                                <p className="text-slate-300 text-sm">{analysis.load_management}</p>
                            </div>
                        </div>

                        {/* Goals */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <h4 className="text-white font-semibold mb-2">Short-term Goals (7 days)</h4>
                                <ul className="space-y-1">
                                    {analysis.short_term_goals.map((goal, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-cyan-400 mt-1">→</span>
                                            {goal}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div>
                                <h4 className="text-white font-semibold mb-2">Long-term Priorities</h4>
                                <ul className="space-y-1">
                                    {analysis.long_term_priorities.map((priority, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-purple-400 mt-1">→</span>
                                            {priority}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}