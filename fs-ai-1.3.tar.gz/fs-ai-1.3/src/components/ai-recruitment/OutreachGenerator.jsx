import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Mail, Sparkles, Copy, Check } from 'lucide-react';
import toast from 'react-hot-toast';

export default function OutreachGenerator() {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [outreachType, setOutreachType] = useState('initial');
    const [generatedMessage, setGeneratedMessage] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [copied, setCopied] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date')
    });

    const generateOutreach = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setIsGenerating(true);
        try {
            const player = players.find(p => p.id === selectedPlayer);
            const playerReports = reports.filter(r => r.player_name === player.name);

            const prompt = `
You are a professional football recruitment specialist crafting a personalized outreach message.

PLAYER PROFILE:
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Club: ${player.current_club || 'Unknown'}
- Market Value: €${player.market_value || 'N/A'}M
- Contract Expiry: ${player.contract_expiry || 'Unknown'}
- Nationality: ${player.nationality || 'Unknown'}

${player.agent_details ? `
AGENT DETAILS:
- Agent: ${player.agent_details.agent_name || 'Unknown'}
- Agency: ${player.agent_details.agency || 'Unknown'}
` : ''}

SCOUTING INTELLIGENCE:
${playerReports.slice(0, 3).map(r => `
- Recommendation: ${r.recommendation}
- Overall Verdict: ${r.overall_verdict || 'N/A'}
- Scout Notes: ${r.notes?.substring(0, 200) || 'N/A'}
- Modules: ${r.modules_activated?.join(', ') || 'N/A'}
`).join('\n')}

${player.playing_style ? `
PLAYING STYLE:
- Work Rate: ${player.playing_style.work_rate || 'N/A'}
- Preferred Foot: ${player.playing_style.preferred_foot || 'N/A'}
` : ''}

OUTREACH TYPE: ${outreachType === 'initial' ? 'Initial Contact' : outreachType === 'follow_up' ? 'Follow-up' : 'Formal Proposal'}

Generate a highly personalized, professional outreach message that:
1. Shows genuine knowledge of the player's abilities and achievements
2. Highlights specific aspects from scouting reports (strengths, playing style)
3. Explains why they'd be a perfect fit for our project
4. Is warm, respectful, and professional
5. Includes a clear call-to-action
6. Addresses the agent if details are available

Keep it 150-250 words. Be specific and personalized - avoid generic language.
            `;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt
            });

            setGeneratedMessage(result);
            toast.success('Outreach message generated');
        } catch (error) {
            toast.error('Failed to generate message');
            console.error(error);
        } finally {
            setIsGenerating(false);
        }
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(generatedMessage);
        setCopied(true);
        toast.success('Copied to clipboard');
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Mail className="w-5 h-5 text-purple-400" />
                    AI Outreach Generator
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Generate personalized recruitment messages based on player profiles
                </p>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label className="text-slate-400">Select Player</Label>
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                <SelectValue placeholder="Choose player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} - {p.position} ({p.age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div>
                        <Label className="text-slate-400">Message Type</Label>
                        <Select value={outreachType} onValueChange={setOutreachType}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="initial">Initial Contact</SelectItem>
                                <SelectItem value="follow_up">Follow-up</SelectItem>
                                <SelectItem value="proposal">Formal Proposal</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <Button
                    onClick={generateOutreach}
                    disabled={isGenerating || !selectedPlayer}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                >
                    {isGenerating ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating...
                        </>
                    ) : (
                        <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Generate Personalized Message
                        </>
                    )}
                </Button>

                {generatedMessage && (
                    <div className="space-y-3">
                        <div className="flex justify-between items-center">
                            <Label className="text-slate-400">Generated Message</Label>
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={copyToClipboard}
                                className="bg-slate-800 border-slate-700"
                            >
                                {copied ? (
                                    <>
                                        <Check className="w-3 h-3 mr-1" />
                                        Copied
                                    </>
                                ) : (
                                    <>
                                        <Copy className="w-3 h-3 mr-1" />
                                        Copy
                                    </>
                                )}
                            </Button>
                        </div>
                        <Textarea
                            value={generatedMessage}
                            onChange={(e) => setGeneratedMessage(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white min-h-[200px]"
                        />
                        <Badge className="bg-green-500/20 text-green-400">
                            Ready to send via Agent Communications
                        </Badge>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}