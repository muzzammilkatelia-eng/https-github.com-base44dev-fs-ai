import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function SuccessPrediction() {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [jobRequirements, setJobRequirements] = useState('');
    const [prediction, setPrediction] = useState(null);
    const [isPredicting, setIsPredicting] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date')
    });

    const { data: communications = [] } = useQuery({
        queryKey: ['agent-communications'],
        queryFn: () => base44.entities.AgentCommunication.list('-created_date')
    });

    const predictSuccess = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setIsPredicting(true);
        try {
            const player = players.find(p => p.id === selectedPlayer);
            const playerReports = reports.filter(r => r.player_name === player.name);
            const playerComms = communications.filter(c => c.player_name === player.name);

            const prompt = `
You are an AI recruitment analyst predicting acquisition success and skill alignment to role requirements.

JOB REQUIREMENTS:
${jobRequirements || 'Not provided'}

PLAYER PROFILE:
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Club: ${player.current_club || 'Unknown'}
- Market Value: €${player.market_value || 'N/A'}M
- Contract Expiry: ${player.contract_expiry || 'Unknown'}
- Transfer Status: ${player.transfer_status || 'Unknown'}
- Watch Status: ${player.watch_status || 'Unknown'}

${player.release_clause ? `RELEASE CLAUSE: ${player.release_clause.exists ? `€${player.release_clause.amount}M` : 'No clause'}` : ''}

SCOUTING DATA (${playerReports.length} reports):
${playerReports.slice(0, 3).map(r => `- ${r.recommendation} | Verdict: ${r.overall_verdict || 'N/A'} | Modules: ${r.modules_activated?.join(', ') || 'Unknown'}`).join('\n')}

AGENT COMMUNICATION HISTORY (${playerComms.length} interactions):
${playerComms.slice(0, 3).map(c => `- ${c.status} | ${c.communication_type} | Response: ${c.response_received ? 'Yes' : 'No'}${c.ai_sentiment_analysis ? ` | Sentiment: ${c.ai_sentiment_analysis.sentiment} | Interest: ${c.ai_sentiment_analysis.interest_level}` : ''}`).join('\n')}

Analyze:
1) Success probability with key factor breakdown
2) Skill alignment to JOB REQUIREMENTS with:
   - alignment_score (0-100)
   - direct_matches (string[])
   - transferable_matches ({source_skill, mapped_to, rationale}[])
   - gaps ({skill, severity: 'low'|'medium'|'high', impact, training_recommendations: string[]}[])
3) Suggested training/development plan if gaps exist

Respond in the JSON schema provided.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                                             overall_probability: { type: "number", minimum: 0, maximum: 100 },
                                             confidence_level: { type: "string", enum: ["Low", "Medium", "High", "Very High"] },
                                             likelihood_category: { type: "string", enum: ["Unlikely", "Possible", "Likely", "Very Likely", "Almost Certain"] },
                                             key_factors: {
                                                 type: "object",
                                                 properties: {
                                                     scouting_quality: { type: "number", minimum: 0, maximum: 100 },
                                                     contract_situation: { type: "number", minimum: 0, maximum: 100 },
                                                     agent_engagement: { type: "number", minimum: 0, maximum: 100 },
                                                     market_feasibility: { type: "number", minimum: 0, maximum: 100 },
                                                     player_interest: { type: "number", minimum: 0, maximum: 100 }
                                                 }
                                             },
                                             skill_alignment: {
                                                 type: "object",
                                                 properties: {
                                                     alignment_score: { type: "number", minimum: 0, maximum: 100 },
                                                     direct_matches: { type: "array", items: { type: "string" } },
                                                     transferable_matches: {
                                                         type: "array",
                                                         items: {
                                                             type: "object",
                                                             properties: {
                                                                 source_skill: { type: "string" },
                                                                 mapped_to: { type: "string" },
                                                                 rationale: { type: "string" }
                                                             }
                                                         }
                                                     },
                                                     gaps: {
                                                         type: "array",
                                                         items: {
                                                             type: "object",
                                                             properties: {
                                                                 skill: { type: "string" },
                                                                 severity: { type: "string", enum: ["low", "medium", "high"] },
                                                                 impact: { type: "string" },
                                                                 training_recommendations: { type: "array", items: { type: "string" } }
                                                             }
                                                         }
                                                     }
                                                 }
                                             },
                                             positive_indicators: { type: "array", items: { type: "string" } },
                                             risk_factors: { type: "array", items: { type: "string" } },
                                             recommended_actions: { type: "array", items: { type: "string" } },
                                             suggested_training: { type: "array", items: { type: "string" } },
                                             timeline_estimate: { type: "string" },
                                             competitive_pressure: { type: "string" }
                                         }
                }
            });

            setPrediction(result);
            toast.success('Prediction generated');
        } catch (error) {
            toast.error('Failed to generate prediction');
            console.error(error);
        } finally {
            setIsPredicting(false);
        }
    };

    const getSuccessColor = (probability) => {
        if (probability >= 75) return 'text-green-400';
        if (probability >= 50) return 'text-yellow-400';
        if (probability >= 25) return 'text-orange-400';
        return 'text-red-400';
    };

    const getSuccessIcon = (probability) => {
        if (probability >= 75) return <CheckCircle className="w-8 h-8 text-green-400" />;
        if (probability >= 50) return <TrendingUp className="w-8 h-8 text-yellow-400" />;
        if (probability >= 25) return <AlertTriangle className="w-8 h-8 text-orange-400" />;
        return <XCircle className="w-8 h-8 text-red-400" />;
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                    AI Success Prediction
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Predict acquisition probability using scouting & engagement data
                </p>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <Label className="text-slate-400">Select Player</Label>
                    <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue placeholder="Choose player to analyze..." />
                        </SelectTrigger>
                        <SelectContent>
                            {players.map(p => (
                                <SelectItem key={p.id} value={p.id}>
                                    {p.name} - {p.position} ({p.current_club || 'Free Agent'})
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label className="text-slate-400">Job Requirements (skills & responsibilities)</Label>
                    <Textarea
                        placeholder="e.g., High press winger: off-ball pressing intensity, progressive carries, defensive duels; set-piece contribution a plus"
                        value={jobRequirements}
                        onChange={(e) => setJobRequirements(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                        rows={3}
                    />
                </div>

                <Button
                    onClick={predictSuccess}
                    disabled={isPredicting || !selectedPlayer}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600"
                >
                    {isPredicting ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing...
                        </>
                    ) : (
                        <>
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Predict Acquisition Success
                        </>
                    )}
                </Button>

                {prediction && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Overall Probability */}
                        <div className="bg-slate-800/50 rounded-lg p-6 text-center border border-slate-700">
                            <div className="flex justify-center mb-3">
                                {getSuccessIcon(prediction.overall_probability)}
                            </div>
                            <div className={`text-5xl font-bold ${getSuccessColor(prediction.overall_probability)}`}>
                                {Math.round(prediction.overall_probability)}%
                            </div>
                            <p className="text-slate-400 text-sm mt-2">Acquisition Success Probability</p>
                            <div className="flex justify-center gap-2 mt-3">
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {prediction.likelihood_category}
                                </Badge>
                                <Badge className="bg-blue-500/20 text-blue-400">
                                    {prediction.confidence_level} Confidence
                                </Badge>
                            </div>
                        </div>

                        {/* Key Factors */}
                        <div className="space-y-3">
                            <h4 className="text-white font-semibold text-sm">Key Factor Analysis</h4>
                            {Object.entries(prediction.key_factors || {}).map(([key, value]) => (
                                <div key={key}>
                                    <div className="flex justify-between text-sm mb-1">
                                        <span className="text-slate-400 capitalize">{key.replace(/_/g, ' ')}</span>
                                        <span className="text-white font-medium">{value}%</span>
                                    </div>
                                    <Progress value={value} className="h-2" />
                                </div>
                            ))}
                        </div>

                                                {/* Skill Alignment */}
                                                {prediction.skill_alignment && (
                                                    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                                        <div className="flex items-center justify-between">
                                                            <h4 className="text-white font-semibold text-sm">Skill Alignment</h4>
                                                            <span className="text-cyan-400 font-medium">{Math.round(prediction.skill_alignment.alignment_score || 0)}%</span>
                                                        </div>
                                                        <Progress value={prediction.skill_alignment.alignment_score || 0} className="h-2 mt-2" />
                                                        {prediction.skill_alignment.direct_matches?.length > 0 && (
                                                            <div className="mt-3">
                                                                <span className="text-green-400 text-sm font-medium">Direct matches:</span>
                                                                <div className="mt-1 flex flex-wrap gap-1">
                                                                    {prediction.skill_alignment.direct_matches.map((s, i) => (
                                                                        <Badge key={i} className="bg-green-500/20 text-green-400 border-green-500/30">{s}</Badge>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        )}
                                                        {prediction.skill_alignment.transferable_matches?.length > 0 && (
                                                            <div className="mt-3">
                                                                <span className="text-amber-400 text-sm font-medium">Transferable skills:</span>
                                                                <ul className="mt-1 space-y-1 text-sm text-slate-300">
                                                                    {prediction.skill_alignment.transferable_matches.map((m, i) => (
                                                                        <li key={i}>• {m.source_skill} → {m.mapped_to} ({m.rationale})</li>
                                                                    ))}
                                                                </ul>
                                                            </div>
                                                        )}
                                                        {prediction.skill_alignment.gaps?.length > 0 && (
                                                            <div className="mt-3">
                                                                <span className="text-red-400 text-sm font-medium">Skill gaps:</span>
                                                                <ul className="mt-1 space-y-1 text-sm text-slate-300">
                                                                    {prediction.skill_alignment.gaps.map((g, i) => (
                                                                        <li key={i}>• {g.skill} — {g.severity} impact. {g.training_recommendations?.length ? ('Training: ' + g.training_recommendations.join(', ')) : ''}</li>
                                                                    ))}
                                                                </ul>
                                                            </div>
                                                        )}
                                                        {prediction.suggested_training?.length > 0 && (
                                                            <div className="mt-3 bg-cyan-500/10 border border-cyan-500/30 rounded p-3">
                                                                <span className="text-cyan-400 text-sm font-medium">Suggested development plan:</span>
                                                                <ul className="mt-1 space-y-1 text-sm text-slate-300">
                                                                    {prediction.suggested_training.map((t, i) => (
                                                                        <li key={i}>• {t}</li>
                                                                    ))}
                                                                </ul>
                                                            </div>
                                                        )}
                                                    </div>
                                                )}

                                                 {/* Positive Indicators */}
                        {prediction.positive_indicators?.length > 0 && (
                            <div>
                                <h4 className="text-green-400 font-semibold text-sm mb-2 flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4" />
                                    Positive Indicators
                                </h4>
                                <ul className="space-y-1">
                                    {prediction.positive_indicators.map((indicator, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm">• {indicator}</li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Risk Factors */}
                        {prediction.risk_factors?.length > 0 && (
                            <div>
                                <h4 className="text-amber-400 font-semibold text-sm mb-2 flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4" />
                                    Risk Factors
                                </h4>
                                <ul className="space-y-1">
                                    {prediction.risk_factors.map((risk, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm">• {risk}</li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Recommended Actions */}
                        {prediction.recommended_actions?.length > 0 && (
                            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                <h4 className="text-cyan-400 font-semibold text-sm mb-2">Recommended Next Steps</h4>
                                <ul className="space-y-1">
                                    {prediction.recommended_actions.map((action, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm">
                                            {idx + 1}. {action}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Additional Info */}
                        <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="bg-slate-800/50 rounded p-3">
                                <p className="text-slate-400">Timeline Estimate</p>
                                <p className="text-white font-medium">{prediction.timeline_estimate}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded p-3">
                                <p className="text-slate-400">Competition Level</p>
                                <p className="text-white font-medium">{prediction.competitive_pressure}</p>
                            </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}