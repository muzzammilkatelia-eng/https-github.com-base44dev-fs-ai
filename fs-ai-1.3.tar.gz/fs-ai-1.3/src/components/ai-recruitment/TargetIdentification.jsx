import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Target, TrendingUp, Star, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import toast from 'react-hot-toast';

export default function TargetIdentification() {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [targets, setTargets] = useState([]);
    const [jobRequirements, setJobRequirements] = useState('');
    const queryClient = useQueryClient();

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const analyzeTargets = async () => {
        setIsAnalyzing(true);
        try {
            const prompt = `
You are an elite football recruitment AI. Analyze scouting data to identify top acquisition targets, with a granular skill match to our job requirements.

JOB REQUIREMENTS:
${jobRequirements || 'Not provided'}

SCOUTING REPORTS DATA:
${reports.slice(0, 20).map(r => `
- Player: ${r.player_name}
- Position: ${r.position}
- Age: ${r.player_age || 'N/A'}
- Recommendation: ${r.recommendation}
- Overall Verdict: ${r.overall_verdict || 'N/A'}
- Notes: ${r.notes?.substring(0, 150) || 'N/A'}
- Modules Used: ${r.modules_activated?.join(', ') || 'N/A'}
`).join('\n')}

PLAYER DATABASE:
${players.slice(0, 30).map(p => `
- Name: ${p.name}
- Position: ${p.position}
- Age: ${p.age}
- Club: ${p.current_club || 'Unknown'}
- Market Value: €${p.market_value || 'N/A'}M
- Contract Expiry: ${p.contract_expiry || 'Unknown'}
- Watch Status: ${p.watch_status || 'Unknown'}
`).join('\n')}

Identify the TOP 5-8 player acquisition targets. For each target, provide:
1) Strategic value and tactical fit
2) Acquisition feasibility
3) Risk assessment and recommended approach
4) Skill Alignment to JOB REQUIREMENTS with:
   - alignment_score (0-100)
   - direct_matches: list of skills that match exactly
   - transferable_matches: list of {source_skill, mapped_to, rationale}
   - gaps: list of {skill, severity: 'low'|'medium'|'high', impact, training_recommendations: string[]}

Respond in the JSON schema provided.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        priority_targets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                                                     player_name: { type: "string" },
                                                                     position: { type: "string" },
                                                                     priority_level: { type: "string", enum: ["Critical", "High", "Medium"] },
                                                                     strategic_value: { type: "string" },
                                                                     acquisition_feasibility: { type: "string" },
                                                                     tactical_fit: { type: "string" },
                                                                     risk_factors: { type: "array", items: { type: "string" } },
                                                                     recommended_approach: { type: "string" },
                                                                     confidence_score: { type: "number" },
                                                                     skill_alignment: {
                                                                         type: "object",
                                                                         properties: {
                                                                             alignment_score: { type: "number", minimum: 0, maximum: 100 },
                                                                             direct_matches: { type: "array", items: { type: "string" } },
                                                                             transferable_matches: {
                                                                                 type: "array",
                                                                                 items: {
                                                                                     type: "object",
                                                                                     properties: {
                                                                                         source_skill: { type: "string" },
                                                                                         mapped_to: { type: "string" },
                                                                                         rationale: { type: "string" }
                                                                                     }
                                                                                 }
                                                                             },
                                                                             gaps: {
                                                                                 type: "array",
                                                                                 items: {
                                                                                     type: "object",
                                                                                     properties: {
                                                                                         skill: { type: "string" },
                                                                                         severity: { type: "string", enum: ["low", "medium", "high"] },
                                                                                         impact: { type: "string" },
                                                                                         training_recommendations: { type: "array", items: { type: "string" } }
                                                                                     }
                                                                                 }
                                                                             }
                                                                         }
                                                                     }
                                                                 }
                            }
                        }
                    }
                }
            });

            setTargets(result.priority_targets || []);
            toast.success(`Identified ${result.priority_targets?.length || 0} priority targets`);
        } catch (error) {
            toast.error('Failed to analyze targets');
            console.error(error);
        } finally {
            setIsAnalyzing(false);
        }
    };

    const priorityColors = {
        'Critical': 'bg-red-500/20 text-red-400 border-red-500/30',
        'High': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
        'Medium': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        AI Target Identification
                    </CardTitle>
                    <p className="text-slate-400 text-sm mt-1">
                        Analyze {reports.length} reports & {players.length} players
                    </p>
                </div>
                <Button
                    onClick={analyzeTargets}
                    disabled={isAnalyzing || reports.length === 0}
                    className="bg-gradient-to-r from-cyan-500 to-blue-600"
                >
                    {isAnalyzing ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing...
                        </>
                    ) : (
                        <>
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Identify Targets
                        </>
                    )}
                </Button>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <p className="text-slate-400 text-sm mb-1">Job Requirements (role, must-have and nice-to-have skills)</p>
                    <Textarea
                        placeholder="e.g., Left-back with high stamina, overlapping runs, 1v1 defending, crossing; leadership a plus"
                        value={jobRequirements}
                        onChange={(e) => setJobRequirements(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white"
                        rows={3}
                    />
                </div>
                {targets.length === 0 ? (
                    <div className="text-center py-8">
                        <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">
                            Click "Identify Targets" to analyze scouting data
                        </p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {targets.map((target, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-slate-800/50 rounded-lg p-4 border border-slate-700 hover:border-cyan-500/30 transition-all"
                            >
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <h4 className="text-white font-semibold text-lg">
                                            {target.player_name}
                                        </h4>
                                        <p className="text-slate-400 text-sm">{target.position}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge className={priorityColors[target.priority_level]}>
                                            {target.priority_level}
                                        </Badge>
                                        <div className="text-cyan-400 font-semibold">
                                            {Math.round(target.confidence_score * 100)}%
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-2 text-sm">
                                    <div>
                                        <span className="text-cyan-400 font-medium">Strategic Value: </span>
                                        <span className="text-slate-300">{target.strategic_value}</span>
                                    </div>
                                    <div>
                                        <span className="text-green-400 font-medium">Feasibility: </span>
                                        <span className="text-slate-300">{target.acquisition_feasibility}</span>
                                    </div>
                                    <div>
                                        <span className="text-purple-400 font-medium">Tactical Fit: </span>
                                        <span className="text-slate-300">{target.tactical_fit}</span>
                                    </div>
                                    {target.risk_factors?.length > 0 && (
                                        <div>
                                            <span className="text-amber-400 font-medium">Risks: </span>
                                            <span className="text-slate-400">{target.risk_factors.join(', ')}</span>
                                        </div>
                                    )}
                                    <div className="pt-2 border-t border-slate-700">
                                        <span className="text-slate-400 font-medium">Approach: </span>
                                        <span className="text-slate-300">{target.recommended_approach}</span>
                                    </div>
                                    {target.skill_alignment && (
                                        <div className="mt-3 bg-slate-900/40 border border-slate-700 rounded-lg p-3">
                                            <div className="flex items-center justify-between">
                                                <span className="text-slate-300 font-medium">Skill Alignment</span>
                                                <span className="text-cyan-400 font-semibold">{Math.round(target.skill_alignment.alignment_score || 0)}%</span>
                                            </div>
                                            <Progress value={target.skill_alignment.alignment_score || 0} className="h-2 mt-2" />
                                            {target.skill_alignment.direct_matches?.length > 0 && (
                                                <div className="mt-3">
                                                    <span className="text-green-400 text-sm font-medium">Direct matches:</span>
                                                    <div className="mt-1 flex flex-wrap gap-1">
                                                        {target.skill_alignment.direct_matches.map((s, i) => (
                                                            <Badge key={i} className="bg-green-500/20 text-green-400 border-green-500/30">{s}</Badge>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                            {target.skill_alignment.transferable_matches?.length > 0 && (
                                                <div className="mt-3">
                                                    <span className="text-amber-400 text-sm font-medium">Transferable skills:</span>
                                                    <ul className="mt-1 space-y-1 text-sm text-slate-300">
                                                        {target.skill_alignment.transferable_matches.map((m, i) => (
                                                            <li key={i}>• {m.source_skill} → {m.mapped_to} ({m.rationale})</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}
                                            {target.skill_alignment.gaps?.length > 0 && (
                                                <div className="mt-3">
                                                    <span className="text-red-400 text-sm font-medium">Skill gaps:</span>
                                                    <ul className="mt-1 space-y-1 text-sm text-slate-300">
                                                        {target.skill_alignment.gaps.map((g, i) => (
                                                            <li key={i}>• {g.skill} — {g.severity} impact. {g.training_recommendations?.length ? ('Training: ' + g.training_recommendations.join(', ')) : ''}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}