import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Target, TrendingUp, DollarSign, Star, MapPin, Loader2, Eye, Heart, GitCompare, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import PlayerComparisonView from './PlayerComparisonView';
import TeamSynergyAnalyzer from './TeamSynergyAnalyzer';

export default function AITalentScout() {
    const [criteria, setCriteria] = useState({
        position: '',
        minAge: '',
        maxAge: '',
        maxValue: '',
        minScore: '',
        targetRegion: '',
        league: '',
        archetype: '',
        contractExpiry: ''
    });
    const [recommendations, setRecommendations] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [compareList, setCompareList] = useState([]);
    const queryClient = useQueryClient();

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-fsai_proprietary_score', 100)
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: watchList = [] } = useQuery({
        queryKey: ['watchList', user?.email],
        queryFn: () => base44.entities.SavedPlayer.filter({ user_email: user.email }),
        enabled: !!user
    });

    const addToWatchListMutation = useMutation({
        mutationFn: (player) => base44.entities.SavedPlayer.create({
            user_email: user.email,
            player_name: player.name,
            player_id: player.id,
            folder: 'AI Scout',
            status: 'Watching',
            tags: ['ai-scouted']
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['watchList']);
            toast.success('Added to watch list');
        }
    });

    const isInWatchList = (playerId) => {
        return watchList.some(w => w.player_id === playerId);
    };

    const toggleCompare = (player) => {
        if (compareList.find(p => p.id === player.id)) {
            setCompareList(compareList.filter(p => p.id !== player.id));
        } else if (compareList.length < 4) {
            setCompareList([...compareList, player]);
        } else {
            toast.error('Maximum 4 players for comparison');
        }
    };

    const scoutTalent = async () => {
        setIsSearching(true);
        toast.loading('AI Scout analyzing player database...', { id: 'ai-scout' });

        try {
            // Filter players based on criteria
            let filteredPlayers = players.filter(p => {
                if (criteria.position && p.position !== criteria.position) return false;
                if (criteria.minAge && p.age < parseInt(criteria.minAge)) return false;
                if (criteria.maxAge && p.age > parseInt(criteria.maxAge)) return false;
                if (criteria.maxValue && p.market_value > parseFloat(criteria.maxValue)) return false;
                if (criteria.minScore && p.fsai_proprietary_score < parseFloat(criteria.minScore)) return false;
                if (criteria.league && p.league !== criteria.league) return false;
                if (criteria.archetype && p.fsai_archetype_primary !== criteria.archetype) return false;
                if (criteria.contractExpiry) {
                    const expiryYear = new Date(p.contract_expiry).getFullYear();
                    if (expiryYear > parseInt(criteria.contractExpiry)) return false;
                }
                return true;
            });

            const prompt = `You are an elite football scout AI analyzing player data to identify the best talent acquisitions.

**Scouting Criteria:**
- Position: ${criteria.position || 'Any'}
- Age Range: ${criteria.minAge || 'Any'} - ${criteria.maxAge || 'Any'}
- Max Market Value: €${criteria.maxValue || 'Unlimited'}M
- Minimum Score: ${criteria.minScore || 'Any'}
- Target Region: ${criteria.targetRegion || 'Global'}

**Candidate Players (Top ${Math.min(filteredPlayers.length, 20)}):**
${filteredPlayers.slice(0, 20).map(p => `
- ${p.name} (${p.age}yo, ${p.position})
  - Club: ${p.current_club || 'N/A'}
  - Value: €${p.market_value}M
  - Score: ${p.fsai_proprietary_score || 'N/A'}
  - Nationality: ${p.nationality || 'N/A'}
`).join('\n')}

Provide scouting recommendations including:
1. Top 5 recommended targets with detailed analysis
2. Hidden gems (undervalued players with high potential)
3. Immediate impact signings (ready for first team)
4. Long-term prospects (future stars)
5. Transfer strategy and timing advice
6. Budget allocation recommendations`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        summary: { type: "string" },
                        top_targets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    age: { type: "number" },
                                    current_club: { type: "string" },
                                    market_value: { type: "number" },
                                    recommendation_score: { type: "number" },
                                    key_strengths: { type: "array", items: { type: "string" } },
                                    tactical_fit: { type: "string" },
                                    transfer_feasibility: { type: "string" },
                                    roi_potential: { type: "string" }
                                }
                            }
                        },
                        hidden_gems: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    reason: { type: "string" },
                                    value_projection: { type: "string" }
                                }
                            }
                        },
                        immediate_impact: { type: "array", items: { type: "string" } },
                        long_term_prospects: { type: "array", items: { type: "string" } },
                        transfer_strategy: { type: "string" },
                        budget_allocation: { type: "string" }
                    }
                }
            });

            setRecommendations(response);
            toast.success(`Found ${response.top_targets.length} recommended targets`, { id: 'ai-scout' });
        } catch (error) {
            console.error('AI Scout error:', error);
            toast.error('Failed to analyze talent', { id: 'ai-scout' });
        } finally {
            setIsSearching(false);
        }
    };

    const getPlayerLink = (playerName) => {
        const player = players.find(p => p.name === playerName);
        return player ? `${createPageUrl('PlayerProfileDetail')}?id=${player.id}` : '#';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/80 backdrop-blur-xl border-cyan-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        AI Talent Scout
                    </CardTitle>
                </CardHeader>
                <CardContent>
                {/* Comparison View */}
                <PlayerComparisonView 
                    players={compareList} 
                    onRemovePlayer={(id) => setCompareList(compareList.filter(p => p.id !== id))}
                />

                <Tabs defaultValue="scout" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
                        <TabsTrigger value="scout">Scout Players</TabsTrigger>
                        <TabsTrigger value="watchlist">Watch List ({watchList.length})</TabsTrigger>
                        <TabsTrigger value="synergy">Team Synergy</TabsTrigger>
                    </TabsList>

                    <TabsContent value="scout" className="space-y-6">
                        {/* Search Criteria */}
                        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                            <h3 className="text-white font-semibold mb-4">Advanced Filters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Select value={criteria.position} onValueChange={(val) => setCriteria({...criteria, position: val})}>
                            <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                                <SelectValue placeholder="Position" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value={null}>Any Position</SelectItem>
                                <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                <SelectItem value="Full-Back">Full-Back</SelectItem>
                                <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                <SelectItem value="Winger">Winger</SelectItem>
                                <SelectItem value="Striker">Striker</SelectItem>
                            </SelectContent>
                        </Select>
                        <Input
                            type="number"
                            placeholder="Min Age"
                            value={criteria.minAge}
                            onChange={(e) => setCriteria({...criteria, minAge: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            type="number"
                            placeholder="Max Age"
                            value={criteria.maxAge}
                            onChange={(e) => setCriteria({...criteria, maxAge: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            type="number"
                            placeholder="Max Value (€M)"
                            value={criteria.maxValue}
                            onChange={(e) => setCriteria({...criteria, maxValue: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            type="number"
                            placeholder="Min Score"
                            value={criteria.minScore}
                            onChange={(e) => setCriteria({...criteria, minScore: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            placeholder="Target Region"
                            value={criteria.targetRegion}
                            onChange={(e) => setCriteria({...criteria, targetRegion: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            placeholder="League"
                            value={criteria.league}
                            onChange={(e) => setCriteria({...criteria, league: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            placeholder="Archetype"
                            value={criteria.archetype}
                            onChange={(e) => setCriteria({...criteria, archetype: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            type="number"
                            placeholder="Contract Expires By (Year)"
                            value={criteria.contractExpiry}
                            onChange={(e) => setCriteria({...criteria, contractExpiry: e.target.value})}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                            </div>
                            <Button
                                onClick={scoutTalent}
                                disabled={isSearching}
                                className="w-full mt-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                            >
                                {isSearching ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Scouting...
                                    </>
                                ) : (
                                    <>
                                        <Search className="w-4 h-4 mr-2" />
                                        Scout Talent
                                    </>
                                )}
                            </Button>
                        </div>

                        {/* Results */}
                        {!recommendations ? (
                            <div className="text-center py-12">
                                <Target className="w-16 h-16 text-cyan-400/50 mx-auto mb-4" />
                                <p className="text-slate-400">Set criteria and click "Scout Talent" to discover players</p>
                            </div>
                        ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Summary */}
                        <div className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 rounded-lg p-4 border border-cyan-500/30">
                            <p className="text-slate-300">{recommendations.summary}</p>
                        </div>

                        {/* Top Targets */}
                        <div>
                            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                <Star className="w-4 h-4 text-amber-400" />
                                Top Recommended Targets
                            </h3>
                            <div className="space-y-3">
                                {recommendations.top_targets.map((target, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/30 hover:border-cyan-500/50 transition-all">
                                        <div className="flex items-start justify-between mb-3">
                                            <div>
                                                <h4 className="text-white font-bold text-lg">{target.player_name}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <Badge variant="outline" className="text-xs">{target.position}</Badge>
                                                    <Badge variant="outline" className="text-xs">{target.age}yo</Badge>
                                                    <Badge className="bg-cyan-500/20 text-cyan-300 text-xs">{target.current_club}</Badge>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <Badge className="bg-amber-500/20 text-amber-400">
                                                        {target.recommendation_score}/10
                                                    </Badge>
                                                    <Button 
                                                        size="sm" 
                                                        variant="ghost" 
                                                        onClick={() => {
                                                            const player = players.find(p => p.name === target.player_name);
                                                            if (player) toggleCompare(player);
                                                        }}
                                                        className={`${compareList.find(p => p.name === target.player_name) ? 'text-cyan-400' : 'text-slate-400'}`}
                                                    >
                                                        <GitCompare className="w-4 h-4" />
                                                    </Button>
                                                    <Button 
                                                        size="sm" 
                                                        variant="ghost"
                                                        onClick={() => {
                                                            const player = players.find(p => p.name === target.player_name);
                                                            if (player && !isInWatchList(player.id)) {
                                                                addToWatchListMutation.mutate(player);
                                                            }
                                                        }}
                                                        disabled={isInWatchList(players.find(p => p.name === target.player_name)?.id)}
                                                        className={`${isInWatchList(players.find(p => p.name === target.player_name)?.id) ? 'text-red-400' : 'text-slate-400'}`}
                                                    >
                                                        <Heart className={`w-4 h-4 ${isInWatchList(players.find(p => p.name === target.player_name)?.id) ? 'fill-red-400' : ''}`} />
                                                    </Button>
                                                    <Link to={getPlayerLink(target.player_name)}>
                                                        <Button size="sm" variant="ghost" className="text-cyan-400 hover:text-cyan-300">
                                                            <Eye className="w-4 h-4" />
                                                        </Button>
                                                    </Link>
                                                </div>
                                                <p className="text-emerald-400 font-bold">€{target.market_value}M</p>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-400 text-xs mb-1">Key Strengths</p>
                                                <div className="flex flex-wrap gap-1">
                                                    {target.key_strengths.map((strength, sidx) => (
                                                        <Badge key={sidx} variant="outline" className="text-xs">
                                                            {strength}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-400 text-xs mb-1">Transfer Feasibility</p>
                                                <p className="text-white text-xs">{target.transfer_feasibility}</p>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                            <div>
                                                <p className="text-slate-400 mb-1">Tactical Fit</p>
                                                <p className="text-slate-300">{target.tactical_fit}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 mb-1">ROI Potential</p>
                                                <p className="text-emerald-400 font-semibold">{target.roi_potential}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Hidden Gems */}
                        {recommendations.hidden_gems.length > 0 && (
                            <div>
                                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                                    Hidden Gems
                                </h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {recommendations.hidden_gems.map((gem, idx) => (
                                        <div key={idx} className="bg-emerald-500/10 rounded-lg p-3 border border-emerald-500/30">
                                            <p className="text-white font-semibold mb-1">{gem.player_name}</p>
                                            <p className="text-slate-300 text-sm mb-2">{gem.reason}</p>
                                            <p className="text-emerald-400 text-xs font-semibold">{gem.value_projection}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Strategy & Budget */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                    <MapPin className="w-4 h-4 text-cyan-400" />
                                    Transfer Strategy
                                </h4>
                                <p className="text-slate-300 text-sm">{recommendations.transfer_strategy}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                    <DollarSign className="w-4 h-4 text-emerald-400" />
                                    Budget Allocation
                                </h4>
                                <p className="text-slate-300 text-sm">{recommendations.budget_allocation}</p>
                            </div>
                        </div>
                        </motion.div>
                        )}
                    </TabsContent>

                    <TabsContent value="watchlist">
                        <div className="space-y-3">
                            {watchList.length === 0 ? (
                                <div className="text-center py-12">
                                    <Heart className="w-16 h-16 text-red-400/50 mx-auto mb-4" />
                                    <p className="text-slate-400">No players in watch list yet</p>
                                </div>
                            ) : (
                                watchList.map((item) => {
                                    const player = players.find(p => p.id === item.player_id);
                                    if (!player) return null;
                                    return (
                                        <div key={item.id} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700 flex items-center justify-between">
                                            <div>
                                                <h4 className="text-white font-bold">{item.player_name}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <Badge variant="outline" className="text-xs">{player.position}</Badge>
                                                    <Badge className="bg-cyan-500/20 text-cyan-300 text-xs">{player.current_club}</Badge>
                                                    <p className="text-emerald-400 text-sm font-bold">€{player.market_value}M</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Button 
                                                    size="sm" 
                                                    variant="ghost"
                                                    onClick={() => toggleCompare(player)}
                                                    className={`${compareList.find(p => p.id === player.id) ? 'text-cyan-400' : 'text-slate-400'}`}
                                                >
                                                    <GitCompare className="w-4 h-4" />
                                                </Button>
                                                <Link to={`${createPageUrl('PlayerProfileDetail')}?id=${player.id}`}>
                                                    <Button size="sm" variant="ghost" className="text-cyan-400">
                                                        <Eye className="w-4 h-4" />
                                                    </Button>
                                                </Link>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="synergy">
                        <TeamSynergyAnalyzer selectedPlayers={compareList} />
                    </TabsContent>
                </Tabs>
                </CardContent>
            </Card>
        </div>
    );
}