import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, Star, Clock, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { differenceInMonths, parseISO } from 'date-fns';

export default function AlertSystem({ players, projections }) {
    const [alerts, setAlerts] = useState([]);

    useEffect(() => {
        generateAlerts();
    }, [players, projections]);

    const generateAlerts = () => {
        const newAlerts = [];

        // Wonderkid alerts
        const wonderkids = projections.filter(p => 
            p.potential_trajectory?.includes('Elite') && 
            players.find(pl => pl.name === p.player_name && pl.age <= 21)
        );
        wonderkids.forEach(wk => {
            const player = players.find(p => p.name === wk.player_name);
            if (player) {
                newAlerts.push({
                    type: 'wonderkid',
                    priority: 'critical',
                    title: `Wonderkid Alert: ${wk.player_name}`,
                    description: `${player.age}y ${player.position} showing Elite potential trajectory`,
                    player_name: wk.player_name,
                    data: { projection: wk, player }
                });
            }
        });

        // Contract expiry alerts
        players.forEach(player => {
            if (player.contract_expiry) {
                try {
                    const monthsRemaining = differenceInMonths(parseISO(player.contract_expiry), new Date());
                    if (monthsRemaining <= 12 && monthsRemaining >= 0) {
                        newAlerts.push({
                            type: 'contract',
                            priority: monthsRemaining <= 6 ? 'critical' : 'high',
                            title: `Contract Expiring: ${player.name}`,
                            description: `Contract expires in ${monthsRemaining} months - potential free transfer`,
                            player_name: player.name,
                            data: { player, monthsRemaining }
                        });
                    }
                } catch (e) {
                    // Invalid date, skip
                }
            }
        });

        // Rapid improvers (high FS-AI scores with young age)
        const rapidImprovers = players.filter(p => 
            p.fsai_proprietary_score >= 80 && 
            p.age <= 23 &&
            p.fsai_analysis?.dimensions?.find(d => d.dimension === 'Development Velocity')?.score >= 8
        );
        rapidImprovers.forEach(player => {
            newAlerts.push({
                type: 'rapid_improver',
                priority: 'high',
                title: `Rapid Development: ${player.name}`,
                description: `${player.age}y showing exceptional development velocity`,
                player_name: player.name,
                data: { player }
            });
        });

        // Value opportunities (high score, low market value)
        const valueGems = players.filter(p => 
            p.fsai_proprietary_score >= 75 && 
            p.market_value && 
            p.market_value < 10
        );
        valueGems.forEach(player => {
            newAlerts.push({
                type: 'value',
                priority: 'medium',
                title: `Value Opportunity: ${player.name}`,
                description: `High FS-AI score (${player.fsai_proprietary_score}) but only €${player.market_value}M`,
                player_name: player.name,
                data: { player }
            });
        });

        setAlerts(newAlerts.sort((a, b) => {
            const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
            return priorityOrder[a.priority] - priorityOrder[b.priority];
        }));
    };

    const getAlertIcon = (type) => {
        switch (type) {
            case 'wonderkid': return <Star className="w-5 h-5" />;
            case 'contract': return <Clock className="w-5 h-5" />;
            case 'rapid_improver': return <TrendingUp className="w-5 h-5" />;
            case 'value': return <AlertTriangle className="w-5 h-5" />;
            default: return <Bell className="w-5 h-5" />;
        }
    };

    const getAlertColor = (type, priority) => {
        if (priority === 'critical') return 'from-red-500/20 to-orange-500/20 border-red-500/30';
        if (type === 'wonderkid') return 'from-purple-500/20 to-pink-500/20 border-purple-500/30';
        if (type === 'contract') return 'from-amber-500/20 to-orange-500/20 border-amber-500/30';
        if (type === 'rapid_improver') return 'from-emerald-500/20 to-cyan-500/20 border-emerald-500/30';
        return 'from-cyan-500/20 to-blue-500/20 border-cyan-500/30';
    };

    const getPriorityBadge = (priority) => {
        const colors = {
            critical: 'bg-red-500/20 text-red-400',
            high: 'bg-orange-500/20 text-orange-400',
            medium: 'bg-amber-500/20 text-amber-400',
            low: 'bg-slate-500/20 text-slate-400'
        };
        return colors[priority] || colors.low;
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Bell className="w-5 h-5 text-amber-400" />
                            Active Alerts ({alerts.length})
                        </CardTitle>
                        <div className="flex gap-2">
                            <Badge className="bg-red-500/20 text-red-400">
                                {alerts.filter(a => a.priority === 'critical').length} Critical
                            </Badge>
                            <Badge className="bg-orange-500/20 text-orange-400">
                                {alerts.filter(a => a.priority === 'high').length} High
                            </Badge>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        AI monitoring for wonderkids, contract expiries, rapid development, and value opportunities
                    </p>
                </CardContent>
            </Card>

            <div className="space-y-4">
                {alerts.map((alert, idx) => (
                    <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className={`bg-gradient-to-r ${getAlertColor(alert.type, alert.priority)} border`}>
                            <CardContent className="pt-6">
                                <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-start gap-3">
                                        <div className={`p-2 rounded-lg ${
                                            alert.priority === 'critical' ? 'bg-red-500/20 text-red-400' :
                                            alert.type === 'wonderkid' ? 'bg-purple-500/20 text-purple-400' :
                                            alert.type === 'contract' ? 'bg-amber-500/20 text-amber-400' :
                                            alert.type === 'rapid_improver' ? 'bg-emerald-500/20 text-emerald-400' :
                                            'bg-cyan-500/20 text-cyan-400'
                                        }`}>
                                            {getAlertIcon(alert.type)}
                                        </div>
                                        <div className="flex-1">
                                            <h4 className="text-white font-semibold mb-1">{alert.title}</h4>
                                            <p className="text-slate-300 text-sm mb-2">{alert.description}</p>
                                            <div className="flex items-center gap-2">
                                                <Badge className={getPriorityBadge(alert.priority)}>
                                                    {alert.priority.toUpperCase()}
                                                </Badge>
                                                <Badge className="bg-slate-700 text-slate-300">
                                                    {alert.type.replace('_', ' ')}
                                                </Badge>
                                            </div>
                                        </div>
                                    </div>
                                    <Button size="sm" variant="outline">
                                        View Details
                                    </Button>
                                </div>

                                {alert.data.player && (
                                    <div className="bg-slate-900/50 rounded-lg p-3 mt-3">
                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                            <div>
                                                <p className="text-slate-500 text-xs">Age</p>
                                                <p className="text-white">{alert.data.player.age}y</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs">Position</p>
                                                <p className="text-white">{alert.data.player.position}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs">League</p>
                                                <p className="text-white">{alert.data.player.league || 'N/A'}</p>
                                            </div>
                                            {alert.data.player.fsai_proprietary_score && (
                                                <div>
                                                    <p className="text-slate-500 text-xs">FS-AI Score</p>
                                                    <p className="text-purple-400 font-bold">
                                                        {alert.data.player.fsai_proprietary_score}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {alerts.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Bell className="w-16 h-16 text-slate-600 mx-auto mb-4 opacity-50" />
                        <h3 className="text-white text-xl font-semibold mb-2">No Active Alerts</h3>
                        <p className="text-slate-400">
                            AI is monitoring your database for opportunities
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}