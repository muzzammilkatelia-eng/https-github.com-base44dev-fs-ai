import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Loader2, FileText, Sparkles, Download } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AutoReports({ players, projections }) {
    const [searchQuery, setSearchQuery] = useState('');
    const [generatingFor, setGeneratingFor] = useState(null);
    const [reports, setReports] = useState({});

    const generateReport = async (player) => {
        setGeneratingFor(player.id);
        toast.loading('Generating AI scout report...', { id: 'report' });

        try {
            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            const prompt = `Generate a comprehensive scout report for this player:

PLAYER: ${player.name}
Age: ${player.age}
Position: ${player.position}
Club: ${player.current_club} | League: ${player.league}
FS-AI Score: ${player.fsai_proprietary_score}
Grade: ${player.fsai_investment_grade || 'N/A'}
Market Value: €${player.market_value}M
Contract: ${player.contract_expiry || 'N/A'}

FS-AI ANALYSIS:
${player.fsai_analysis ? JSON.stringify(player.fsai_analysis) : 'N/A'}

PROJECTION:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak: ${projection.peak_potential_rating}
- Years to Peak: ${projection.years_to_peak}
` : 'No projection available'}

PLAYING STYLE:
${JSON.stringify(player.playing_style || {})}

Create a detailed scout report including:
1. Executive Summary
2. Technical Profile
3. Physical Attributes
4. Mental & Tactical Intelligence
5. Strengths (top 5)
6. Weaknesses (areas to improve)
7. Best Tactical Fit (which systems/archetypes)
8. Market Value Assessment
9. Transfer Recommendation
10. Risk Factors`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        report_date: { type: "string" },
                        executive_summary: { type: "string" },
                        overall_grade: { type: "string" },
                        technical_profile: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                summary: { type: "string" },
                                standout_skills: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        },
                        physical_attributes: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                summary: { type: "string" }
                            }
                        },
                        mental_tactical: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                summary: { type: "string" }
                            }
                        },
                        strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        weaknesses: {
                            type: "array",
                            items: { type: "string" }
                        },
                        tactical_fit: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    archetype: { type: "string" },
                                    fit_score: { type: "number" },
                                    role: { type: "string" }
                                }
                            }
                        },
                        market_assessment: {
                            type: "object",
                            properties: {
                                current_value: { type: "string" },
                                fair_value: { type: "string" },
                                verdict: { type: "string" }
                            }
                        },
                        transfer_recommendation: { type: "string" },
                        risk_factors: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setReports(prev => ({ ...prev, [player.id]: response }));
            toast.success('Report generated!', { id: 'report' });
        } catch (error) {
            console.error('Report generation failed:', error);
            toast.error('Failed to generate report', { id: 'report' });
        } finally {
            setGeneratingFor(null);
        }
    };

    const filteredPlayers = players.filter(p => 
        p.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.position?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.league?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-cyan-400" />
                        Auto-Generate Scout Reports
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Input
                        placeholder="Search players..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
                {filteredPlayers.slice(0, 20).map((player) => (
                    <Card key={player.id} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <h4 className="text-white font-semibold mb-1">{player.name}</h4>
                                    <div className="flex items-center gap-2">
                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                            {player.position}
                                        </Badge>
                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                            {player.age}y
                                        </Badge>
                                    </div>
                                    <p className="text-slate-400 text-xs mt-1">{player.league}</p>
                                </div>
                                {player.fsai_proprietary_score && (
                                    <div className="text-right">
                                        <p className="text-cyan-400 text-xl font-bold">
                                            {player.fsai_proprietary_score}
                                        </p>
                                        <p className="text-slate-500 text-xs">FS-AI</p>
                                    </div>
                                )}
                            </div>

                            {reports[player.id] ? (
                                <div className="space-y-3">
                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                                        <p className="text-emerald-400 text-xs mb-1">Report Ready</p>
                                        <p className="text-slate-300 text-sm">
                                            {reports[player.id].executive_summary?.substring(0, 100)}...
                                        </p>
                                    </div>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        className="w-full"
                                        onClick={() => {
                                            // Could open modal or navigate to full report
                                            toast.success('Full report view coming soon');
                                        }}
                                    >
                                        <Download className="w-4 h-4 mr-2" />
                                        View Full Report
                                    </Button>
                                </div>
                            ) : (
                                <Button
                                    onClick={() => generateReport(player)}
                                    disabled={generatingFor === player.id}
                                    size="sm"
                                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                                >
                                    {generatingFor === player.id ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Generating...
                                        </>
                                    ) : (
                                        <>
                                            <Sparkles className="w-4 h-4 mr-2" />
                                            Generate Report
                                        </>
                                    )}
                                </Button>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>

            {Object.keys(reports).length > 0 && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8"
                >
                    <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Generated Reports ({Object.keys(reports).length})</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {Object.entries(reports).map(([playerId, report]) => (
                                <div key={playerId} className="mb-6 pb-6 border-b border-slate-700 last:border-0">
                                    <h3 className="text-white text-lg font-semibold mb-3">{report.player_name}</h3>
                                    
                                    <div className="space-y-4">
                                        <div>
                                            <p className="text-slate-400 text-sm mb-1">Executive Summary:</p>
                                            <p className="text-slate-300 text-sm">{report.executive_summary}</p>
                                        </div>

                                        <div className="grid md:grid-cols-3 gap-3">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs">Technical</p>
                                                <p className="text-purple-400 text-2xl font-bold">
                                                    {report.technical_profile?.rating}/10
                                                </p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs">Physical</p>
                                                <p className="text-amber-400 text-2xl font-bold">
                                                    {report.physical_attributes?.rating}/10
                                                </p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs">Mental</p>
                                                <p className="text-emerald-400 text-2xl font-bold">
                                                    {report.mental_tactical?.rating}/10
                                                </p>
                                            </div>
                                        </div>

                                        <div className="grid md:grid-cols-2 gap-3">
                                            <div>
                                                <p className="text-emerald-400 text-sm font-semibold mb-2">Strengths:</p>
                                                <ul className="space-y-1">
                                                    {report.strengths?.map((s, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-emerald-400">✓</span>
                                                            {s}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <p className="text-amber-400 text-sm font-semibold mb-2">Weaknesses:</p>
                                                <ul className="space-y-1">
                                                    {report.weaknesses?.map((w, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-amber-400">•</span>
                                                            {w}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>

                                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
                                            <p className="text-cyan-400 text-sm font-semibold mb-1">
                                                Transfer Recommendation:
                                            </p>
                                            <p className="text-white text-sm">{report.transfer_recommendation}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}