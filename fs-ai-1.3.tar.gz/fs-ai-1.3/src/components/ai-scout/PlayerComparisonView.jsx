import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { X, TrendingUp, Target, DollarSign, Award } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PlayerComparisonView({ players, onRemovePlayer }) {
    if (players.length === 0) return null;

    const metrics = [
        { key: 'age', label: 'Age', format: (v) => `${v}yo` },
        { key: 'market_value', label: 'Market Value', format: (v) => `€${v}M` },
        { key: 'fsai_proprietary_score', label: 'FS-AI Score', format: (v) => v || 'N/A' },
        { key: 'current_club', label: 'Current Club', format: (v) => v || 'N/A' },
        { key: 'nationality', label: 'Nationality', format: (v) => v || 'N/A' },
        { key: 'contract_expiry', label: 'Contract Expiry', format: (v) => v || 'N/A' }
    ];

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/30 mb-6"
        >
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Target className="w-4 h-4 text-cyan-400" />
                Player Comparison ({players.length})
            </h3>
            
            <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${Math.min(players.length, 4)}, 1fr)` }}>
                {players.map((player) => (
                    <Card key={player.id} className="bg-slate-900/50 border-slate-700">
                        <CardContent className="pt-4">
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <h4 className="text-white font-bold">{player.name}</h4>
                                    <Badge variant="outline" className="text-xs mt-1">
                                        {player.position}
                                    </Badge>
                                </div>
                                <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => onRemovePlayer(player.id)}
                                    className="text-red-400 hover:text-red-300"
                                >
                                    <X className="w-4 h-4" />
                                </Button>
                            </div>

                            <div className="space-y-2">
                                {metrics.map((metric) => (
                                    <div key={metric.key} className="text-xs">
                                        <p className="text-slate-400">{metric.label}</p>
                                        <p className="text-white font-semibold">
                                            {metric.format(player[metric.key])}
                                        </p>
                                    </div>
                                ))}
                            </div>

                            {player.fsai_score_breakdown && (
                                <div className="mt-3 pt-3 border-t border-slate-700">
                                    <p className="text-slate-400 text-xs mb-2">Key Attributes</p>
                                    <div className="flex flex-wrap gap-1">
                                        {Object.entries(player.fsai_score_breakdown).slice(0, 3).map(([key, value]) => (
                                            <Badge key={key} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                {key}: {value}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>
        </motion.div>
    );
}