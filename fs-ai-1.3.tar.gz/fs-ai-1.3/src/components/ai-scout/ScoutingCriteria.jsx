import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Settings, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ScoutingCriteria({ criteria }) {
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        criteria_type: 'High Potential',
        active: true,
        filters: {
            min_fsai_score: 70,
            max_age: 25,
            positions: [],
            leagues: [],
            min_potential: 75
        }
    });

    const queryClient = useQueryClient();

    const createCriteriaMutation = useMutation({
        mutationFn: (data) => base44.entities.AIScoutingCriteria.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ai-scouting-criteria'] });
            setShowForm(false);
            resetForm();
            toast.success('Criteria created!');
        }
    });

    const deleteCriteriaMutation = useMutation({
        mutationFn: (id) => base44.entities.AIScoutingCriteria.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ai-scouting-criteria'] });
            toast.success('Criteria deleted');
        }
    });

    const toggleActiveMutation = useMutation({
        mutationFn: ({ id, active }) => base44.entities.AIScoutingCriteria.update(id, { active }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ai-scouting-criteria'] });
        }
    });

    const resetForm = () => {
        setFormData({
            name: '',
            criteria_type: 'High Potential',
            active: true,
            filters: {
                min_fsai_score: 70,
                max_age: 25,
                positions: [],
                leagues: [],
                min_potential: 75
            }
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        createCriteriaMutation.mutate(formData);
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Settings className="w-5 h-5 text-purple-400" />
                            Scouting Criteria ({criteria.length})
                        </CardTitle>
                        <Dialog open={showForm} onOpenChange={setShowForm}>
                            <DialogTrigger asChild>
                                <Button className="bg-gradient-to-r from-purple-500 to-pink-600">
                                    <Plus className="w-4 h-4 mr-2" />
                                    New Criteria
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                                <DialogHeader>
                                    <DialogTitle>Create Scouting Criteria</DialogTitle>
                                </DialogHeader>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <Label>Criteria Name</Label>
                                        <Input
                                            value={formData.name}
                                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                                            placeholder="e.g., Elite Young Wingers"
                                            className="bg-slate-800 border-slate-700"
                                            required
                                        />
                                    </div>

                                    <div>
                                        <Label>Type</Label>
                                        <Select 
                                            value={formData.criteria_type} 
                                            onValueChange={(v) => setFormData({...formData, criteria_type: v})}
                                        >
                                            <SelectTrigger className="bg-slate-800 border-slate-700">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="High Potential">High Potential</SelectItem>
                                                <SelectItem value="Undervalued">Undervalued</SelectItem>
                                                <SelectItem value="Contract Expiry">Contract Expiry</SelectItem>
                                                <SelectItem value="Position Specific">Position Specific</SelectItem>
                                                <SelectItem value="Custom">Custom</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <Label>Min FS-AI Score</Label>
                                            <Input
                                                type="number"
                                                value={formData.filters.min_fsai_score}
                                                onChange={(e) => setFormData({
                                                    ...formData, 
                                                    filters: {...formData.filters, min_fsai_score: parseInt(e.target.value)}
                                                })}
                                                className="bg-slate-800 border-slate-700"
                                            />
                                        </div>
                                        <div>
                                            <Label>Max Age</Label>
                                            <Input
                                                type="number"
                                                value={formData.filters.max_age}
                                                onChange={(e) => setFormData({
                                                    ...formData, 
                                                    filters: {...formData.filters, max_age: parseInt(e.target.value)}
                                                })}
                                                className="bg-slate-800 border-slate-700"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label>Target Leagues (comma-separated)</Label>
                                        <Input
                                            value={formData.filters.leagues?.join(', ')}
                                            onChange={(e) => setFormData({
                                                ...formData,
                                                filters: {
                                                    ...formData.filters,
                                                    leagues: e.target.value.split(',').map(l => l.trim()).filter(Boolean)
                                                }
                                            })}
                                            placeholder="e.g., Premier League, La Liga"
                                            className="bg-slate-800 border-slate-700"
                                        />
                                    </div>

                                    <div className="flex items-center gap-3">
                                        <Switch
                                            checked={formData.active}
                                            onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                                        />
                                        <Label>Active</Label>
                                    </div>

                                    <Button type="submit" className="w-full bg-gradient-to-r from-purple-500 to-pink-600">
                                        Create Criteria
                                    </Button>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        Define custom criteria to automatically identify players matching your scouting strategy
                    </p>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
                {criteria.map((criterion) => (
                    <Card key={criterion.id} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <h4 className="text-white font-semibold">{criterion.name}</h4>
                                        {criterion.active ? (
                                            <Badge className="bg-emerald-500/20 text-emerald-400">Active</Badge>
                                        ) : (
                                            <Badge className="bg-slate-500/20 text-slate-400">Inactive</Badge>
                                        )}
                                    </div>
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {criterion.criteria_type}
                                    </Badge>
                                </div>
                                <div className="flex gap-2">
                                    <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => toggleActiveMutation.mutate({ 
                                            id: criterion.id, 
                                            active: !criterion.active 
                                        })}
                                    >
                                        <Switch checked={criterion.active} />
                                    </Button>
                                    <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => deleteCriteriaMutation.mutate(criterion.id)}
                                        className="text-red-400 hover:text-red-300"
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>

                            <div className="bg-slate-800/50 rounded-lg p-3 space-y-2 text-sm">
                                {criterion.filters?.min_fsai_score && (
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Min FS-AI:</span>
                                        <span className="text-white">{criterion.filters.min_fsai_score}</span>
                                    </div>
                                )}
                                {criterion.filters?.max_age && (
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Max Age:</span>
                                        <span className="text-white">{criterion.filters.max_age}</span>
                                    </div>
                                )}
                                {criterion.filters?.leagues && criterion.filters.leagues.length > 0 && (
                                    <div>
                                        <span className="text-slate-400 text-xs">Leagues:</span>
                                        <div className="flex flex-wrap gap-1 mt-1">
                                            {criterion.filters.leagues.map((league, idx) => (
                                                <Badge key={idx} className="bg-slate-700 text-slate-300 text-xs">
                                                    {league}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {criteria.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Settings className="w-16 h-16 text-slate-600 mx-auto mb-4 opacity-50" />
                        <h3 className="text-white text-xl font-semibold mb-2">No Criteria Defined</h3>
                        <p className="text-slate-400">Create custom scouting criteria to automate talent discovery</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}