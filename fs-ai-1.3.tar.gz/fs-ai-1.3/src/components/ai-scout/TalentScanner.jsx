import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Brain, Star, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TalentScanner({ players, projections, criteria }) {
    const [scanning, setScanning] = useState(false);
    const [discoveries, setDiscoveries] = useState(null);

    const scanForTalent = async () => {
        setScanning(true);
        toast.loading('AI scanning database...', { id: 'scan' });

        try {
            const prompt = `You are the FS-AI Talent Scout. Scan the database for emerging talent.

AVAILABLE PLAYERS (${players.length}):
${players.slice(0, 100).map(p => `
- ${p.name} (${p.age}y, ${p.position}) | FS-AI: ${p.fsai_proprietary_score} | ${p.league}
  Grade: ${p.fsai_investment_grade || 'N/A'} | Market Value: €${p.market_value}M
  Contract: ${p.contract_expiry || 'N/A'}
`).join('\n')}

PROJECTIONS:
${projections.slice(0, 50).map(p => `
- ${p.player_name} | Trajectory: ${p.potential_trajectory} | Peak: ${p.peak_potential_rating}
`).join('\n')}

ACTIVE CRITERIA (${criteria.length}):
${criteria.map(c => `- ${c.name}: ${JSON.stringify(c.filters)}`).join('\n')}

IDENTIFY TOP 20 EMERGING TALENTS:
1. Wonderkids (U21 with elite potential)
2. Rapid Improvers (showing fast development)
3. Value Gems (undervalued, high potential)
4. Contract Expiry (expiring within 12 months)
5. Hidden Talents (overlooked high performers)

For each player provide:
- Category
- Why they're flagged
- Urgency level (Critical/High/Medium)
- Recommended action`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        scan_date: { type: "string" },
                        total_scanned: { type: "number" },
                        discoveries: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    category: { type: "string" },
                                    fsai_score: { type: "number" },
                                    reason_flagged: { type: "string" },
                                    urgency: { type: "string" },
                                    recommended_action: { type: "string" },
                                    key_attributes: {
                                        type: "array",
                                        items: { type: "string" }
                                    }
                                }
                            }
                        },
                        summary: { type: "string" }
                    }
                }
            });

            setDiscoveries(response);
            toast.success(`Found ${response.discoveries?.length} talents!`, { id: 'scan' });
        } catch (error) {
            console.error('Scan failed:', error);
            toast.error('Scan failed', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    const getCategoryColor = (category) => {
        if (category?.includes('Wonderkid')) return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
        if (category?.includes('Rapid')) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (category?.includes('Value')) return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        if (category?.includes('Contract')) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-pink-500/20 text-pink-400 border-pink-500/30';
    };

    const getUrgencyColor = (urgency) => {
        if (urgency?.includes('Critical')) return 'bg-red-500/20 text-red-400';
        if (urgency?.includes('High')) return 'bg-orange-500/20 text-orange-400';
        return 'bg-slate-500/20 text-slate-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Brain className="w-5 h-5 text-purple-400" />
                            AI Talent Scanner
                        </CardTitle>
                        <Button
                            onClick={scanForTalent}
                            disabled={scanning}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                            {scanning ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Scanning...
                                </>
                            ) : (
                                <>
                                    <Brain className="w-4 h-4 mr-2" />
                                    Run Scan
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm">
                        AI will analyze {players.length} players across all databases to identify emerging talents, wonderkids, 
                        value opportunities, and urgent contract situations.
                    </p>
                </CardContent>
            </Card>

            {discoveries && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <h3 className="text-white font-semibold">Scan Summary</h3>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {discoveries.discoveries?.length} Discovered
                                </Badge>
                            </div>
                            <p className="text-slate-300 text-sm">{discoveries.summary}</p>
                        </CardContent>
                    </Card>

                    <div className="grid gap-4">
                        {discoveries.discoveries?.map((talent, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800 hover:border-purple-500/50 transition-colors">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h4 className="text-white text-lg font-semibold">{talent.player_name}</h4>
                                                    <Badge className="bg-slate-700 text-slate-300">
                                                        {talent.position}
                                                    </Badge>
                                                    <Badge className="bg-slate-700 text-slate-300">
                                                        {talent.age}y
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center gap-2 mb-3">
                                                    <Badge className={getCategoryColor(talent.category)}>
                                                        {talent.category}
                                                    </Badge>
                                                    <Badge className={getUrgencyColor(talent.urgency)}>
                                                        {talent.urgency} Urgency
                                                    </Badge>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-purple-400 text-2xl font-bold">
                                                    {talent.fsai_score}
                                                </p>
                                                <p className="text-slate-500 text-xs">FS-AI</p>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-3 mb-3">
                                            <p className="text-slate-400 text-xs mb-1">Why Flagged:</p>
                                            <p className="text-white text-sm">{talent.reason_flagged}</p>
                                        </div>

                                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 mb-3">
                                            <p className="text-cyan-400 text-xs mb-1">Recommended Action:</p>
                                            <p className="text-slate-300 text-sm">{talent.recommended_action}</p>
                                        </div>

                                        {talent.key_attributes && talent.key_attributes.length > 0 && (
                                            <div className="flex flex-wrap gap-2">
                                                {talent.key_attributes.map((attr, i) => (
                                                    <Badge key={i} className="bg-purple-500/20 text-purple-400">
                                                        {attr}
                                                    </Badge>
                                                ))}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            )}

            {!discoveries && !scanning && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Brain className="w-16 h-16 text-purple-400 mx-auto mb-4 opacity-50" />
                        <h3 className="text-white text-xl font-semibold mb-2">Ready to Scan</h3>
                        <p className="text-slate-400">
                            Click "Run Scan" to let AI identify emerging talents across your database
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}