import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Loader2, TrendingUp, Target, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function TeamSynergyAnalyzer({ selectedPlayers }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzeSynergy = async () => {
        if (selectedPlayers.length < 2) {
            toast.error('Select at least 2 players to analyze synergy');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing team synergy...', { id: 'synergy' });

        try {
            const prompt = `You are an elite football tactical analyst evaluating team synergy and player combinations.

**Selected Players:**
${selectedPlayers.map(p => `
- ${p.name} (${p.age}yo, ${p.position})
  - Club: ${p.current_club}
  - Score: ${p.fsai_proprietary_score || 'N/A'}
  - Archetype: ${p.fsai_archetype_primary || 'N/A'}
`).join('\n')}

Analyze the team synergy including:
1. Overall Synergy Score (0-100)
2. Tactical Compatibility Analysis
3. Position Balance Assessment
4. Age Profile Evaluation
5. Playing Style Cohesion
6. Recommended Formation
7. Potential Weaknesses
8. Optimal Player Combinations
9. Transfer Priority Ranking`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        synergy_score: { type: "number" },
                        tactical_compatibility: { type: "string" },
                        position_balance: { type: "string" },
                        age_profile: { type: "string" },
                        style_cohesion: { type: "string" },
                        recommended_formation: { type: "string" },
                        weaknesses: { type: "array", items: { type: "string" } },
                        optimal_combos: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    players: { type: "array", items: { type: "string" } },
                                    reason: { type: "string" },
                                    synergy: { type: "number" }
                                }
                            }
                        },
                        priority_ranking: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player: { type: "string" },
                                    priority: { type: "string" },
                                    reason: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Synergy analysis complete', { id: 'synergy' });
        } catch (error) {
            console.error('Synergy analysis error:', error);
            toast.error('Failed to analyze synergy', { id: 'synergy' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getSynergyColor = (score) => {
        if (score >= 80) return 'bg-emerald-500/20 text-emerald-400';
        if (score >= 60) return 'bg-cyan-500/20 text-cyan-400';
        if (score >= 40) return 'bg-amber-500/20 text-amber-400';
        return 'bg-red-500/20 text-red-400';
    };

    return (
        <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-400" />
                        Team Synergy Analysis
                    </CardTitle>
                    <Button
                        onClick={analyzeSynergy}
                        disabled={isAnalyzing || selectedPlayers.length < 2}
                        className="bg-gradient-to-r from-purple-600 to-pink-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Zap className="w-4 h-4 mr-2" />
                                Analyze Synergy
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-8">
                        <Users className="w-12 h-12 text-purple-400/50 mx-auto mb-3" />
                        <p className="text-slate-400 text-sm">
                            {selectedPlayers.length < 2 
                                ? 'Select at least 2 players to analyze team synergy'
                                : 'Click "Analyze Synergy" to evaluate player combinations'}
                        </p>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Synergy Score */}
                        <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-4 border border-purple-500/30">
                            <div className="flex items-center justify-between">
                                <h3 className="text-white font-semibold">Overall Synergy</h3>
                                <Badge className={`${getSynergyColor(analysis.synergy_score)} text-lg`}>
                                    {analysis.synergy_score}/100
                                </Badge>
                            </div>
                        </div>

                        {/* Analysis Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                <p className="text-slate-400 text-xs mb-1">Tactical Compatibility</p>
                                <p className="text-white text-sm">{analysis.tactical_compatibility}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                <p className="text-slate-400 text-xs mb-1">Position Balance</p>
                                <p className="text-white text-sm">{analysis.position_balance}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                <p className="text-slate-400 text-xs mb-1">Age Profile</p>
                                <p className="text-white text-sm">{analysis.age_profile}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                <p className="text-slate-400 text-xs mb-1">Style Cohesion</p>
                                <p className="text-white text-sm">{analysis.style_cohesion}</p>
                            </div>
                        </div>

                        {/* Recommended Formation */}
                        <div className="bg-cyan-500/10 rounded-lg p-3 border border-cyan-500/30">
                            <p className="text-cyan-400 text-xs font-semibold mb-1">Recommended Formation</p>
                            <p className="text-white font-bold">{analysis.recommended_formation}</p>
                        </div>

                        {/* Optimal Combinations */}
                        <div>
                            <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <Target className="w-4 h-4 text-emerald-400" />
                                Optimal Combinations
                            </h4>
                            <div className="space-y-2">
                                {analysis.optimal_combos.map((combo, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 border border-emerald-500/30">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex flex-wrap gap-1">
                                                {combo.players.map((player, pidx) => (
                                                    <Badge key={pidx} variant="outline" className="text-xs">
                                                        {player}
                                                    </Badge>
                                                ))}
                                            </div>
                                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                                {combo.synergy}/100
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{combo.reason}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Priority Ranking */}
                        <div>
                            <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4 text-amber-400" />
                                Transfer Priority
                            </h4>
                            <div className="space-y-2">
                                {analysis.priority_ranking.map((item, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700 flex items-start justify-between">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className="text-white font-semibold">{idx + 1}.</span>
                                                <span className="text-white font-semibold">{item.player}</span>
                                                <Badge className="bg-amber-500/20 text-amber-400 text-xs">
                                                    {item.priority}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-300 text-xs">{item.reason}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Weaknesses */}
                        {analysis.weaknesses.length > 0 && (
                            <div className="bg-red-500/10 rounded-lg p-3 border border-red-500/30">
                                <p className="text-red-400 font-semibold text-sm mb-2">Potential Weaknesses</p>
                                <ul className="space-y-1">
                                    {analysis.weaknesses.map((weakness, idx) => (
                                        <li key={idx} className="text-slate-300 text-xs flex items-start gap-2">
                                            <span className="text-red-400 mt-1">•</span>
                                            {weakness}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}