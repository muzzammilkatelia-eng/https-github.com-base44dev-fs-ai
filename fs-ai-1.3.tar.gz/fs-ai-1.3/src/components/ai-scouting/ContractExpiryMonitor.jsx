import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Calendar, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function ContractExpiryMonitor({ players }) {
    const navigate = useNavigate();

    const expiringPlayers = players.filter(p => {
        if (!p.contract_expiry) return false;
        const expiryDate = new Date(p.contract_expiry);
        const now = new Date();
        const monthsUntilExpiry = (expiryDate - now) / (1000 * 60 * 60 * 24 * 30);
        return monthsUntilExpiry <= 12 && monthsUntilExpiry > 0;
    }).sort((a, b) => new Date(a.contract_expiry) - new Date(b.contract_expiry));

    const getUrgencyLevel = (expiryDate) => {
        const months = (new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24 * 30);
        if (months <= 3) return { level: 'Critical', color: 'bg-red-500/20 text-red-400 border-red-500/30' };
        if (months <= 6) return { level: 'High', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' };
        if (months <= 9) return { level: 'Medium', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' };
        return { level: 'Low', color: 'bg-slate-500/20 text-slate-400 border-slate-500/30' };
    };

    const getOpportunityType = (player) => {
        const months = (new Date(player.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30);
        const hasHighScore = player.fsai_proprietary_score >= 75;
        const isYoung = player.age <= 26;

        if (months <= 6 && hasHighScore && isYoung) return 'Premium Free Transfer';
        if (months <= 6 && hasHighScore) return 'Quality Free Agent';
        if (months <= 6) return 'Free Transfer';
        if (hasHighScore) return 'Pre-Contract Eligible';
        return 'Monitoring';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-orange-400" />
                        Contract Expiry Monitor
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm mb-4">
                        Tracking {expiringPlayers.length} players with contracts expiring within 12 months. 
                        Prioritize negotiations or prepare free transfer approaches.
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-slate-800/50 rounded-lg p-3">
                            <p className="text-slate-400 text-xs mb-1">≤3 Months</p>
                            <p className="text-red-400 text-2xl font-bold">
                                {expiringPlayers.filter(p => {
                                    const months = (new Date(p.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30);
                                    return months <= 3;
                                }).length}
                            </p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3">
                            <p className="text-slate-400 text-xs mb-1">≤6 Months</p>
                            <p className="text-orange-400 text-2xl font-bold">
                                {expiringPlayers.filter(p => {
                                    const months = (new Date(p.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30);
                                    return months <= 6;
                                }).length}
                            </p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3">
                            <p className="text-slate-400 text-xs mb-1">≤12 Months</p>
                            <p className="text-amber-400 text-2xl font-bold">
                                {expiringPlayers.length}
                            </p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3">
                            <p className="text-slate-400 text-xs mb-1">High Value</p>
                            <p className="text-emerald-400 text-2xl font-bold">
                                {expiringPlayers.filter(p => p.fsai_proprietary_score >= 75).length}
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="grid gap-4">
                {expiringPlayers.length === 0 ? (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="py-12">
                            <div className="text-center">
                                <Calendar className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                                <p className="text-slate-400">No contract expiry alerts in the next 12 months</p>
                            </div>
                        </CardContent>
                    </Card>
                ) : (
                    expiringPlayers.map((player, idx) => {
                        const urgency = getUrgencyLevel(player.contract_expiry);
                        const opportunity = getOpportunityType(player);
                        const monthsRemaining = Math.floor((new Date(player.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30));

                        return (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.03 }}
                            >
                                <Card className={`border-l-4 ${
                                    urgency.level === 'Critical' ? 'border-l-red-500' :
                                    urgency.level === 'High' ? 'border-l-orange-500' :
                                    urgency.level === 'Medium' ? 'border-l-amber-500' :
                                    'border-l-slate-500'
                                } bg-slate-900/50 border-slate-800`}>
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h3 className="text-white text-xl font-bold">{player.name}</h3>
                                                    <Badge className="bg-slate-700 text-slate-300">
                                                        {player.position}
                                                    </Badge>
                                                    <Badge className="bg-slate-700 text-slate-300">
                                                        {player.age}y
                                                    </Badge>
                                                    <Badge className={urgency.color}>
                                                        {urgency.level}
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center gap-4 text-sm text-slate-400 mb-2">
                                                    <span>{player.current_club || 'Unknown Club'}</span>
                                                    <span>•</span>
                                                    <span>{player.league || 'Unknown League'}</span>
                                                    {player.market_value && (
                                                        <>
                                                            <span>•</span>
                                                            <span className="text-emerald-400">€{player.market_value}M</span>
                                                        </>
                                                    )}
                                                </div>
                                                <Badge className="bg-purple-500/20 text-purple-400">
                                                    {opportunity}
                                                </Badge>
                                            </div>
                                            {player.fsai_proprietary_score && (
                                                <div className="text-right">
                                                    <p className="text-slate-400 text-xs mb-1">FS-AI</p>
                                                    <p className={`text-3xl font-bold ${
                                                        player.fsai_proprietary_score >= 85 ? 'text-emerald-400' :
                                                        player.fsai_proprietary_score >= 70 ? 'text-cyan-400' :
                                                        'text-amber-400'
                                                    }`}>
                                                        {player.fsai_proprietary_score}
                                                    </p>
                                                </div>
                                            )}
                                        </div>

                                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <Calendar className="w-4 h-4 text-orange-400" />
                                                    <p className="text-slate-400 text-xs font-semibold">Contract Expiry</p>
                                                </div>
                                                <p className="text-white font-semibold">
                                                    {new Date(player.contract_expiry).toLocaleDateString()}
                                                </p>
                                                <p className="text-orange-400 text-sm">{monthsRemaining} months remaining</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs font-semibold mb-1">Strategic Value</p>
                                                {monthsRemaining <= 6 ? (
                                                    <p className="text-emerald-400 text-sm">
                                                        Pre-contract negotiation eligible in {Math.max(0, 6 - monthsRemaining)} months
                                                    </p>
                                                ) : (
                                                    <p className="text-cyan-400 text-sm">
                                                        Monitor for negotiation leverage
                                                    </p>
                                                )}
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2 text-sm">
                                                {player.transfer_status && (
                                                    <Badge className={
                                                        player.transfer_status === 'Available' ? 'bg-emerald-500/20 text-emerald-400' :
                                                        player.transfer_status === 'Transfer Listed' ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {player.transfer_status}
                                                    </Badge>
                                                )}
                                                {player.release_clause?.exists && (
                                                    <Badge className="bg-amber-500/20 text-amber-400">
                                                        Release Clause: €{player.release_clause.amount}M
                                                    </Badge>
                                                )}
                                            </div>
                                            <Button
                                                onClick={() => navigate(createPageUrl('PlayerProfile') + `?id=${player.id}`)}
                                                size="sm"
                                                className="bg-orange-500 hover:bg-orange-600"
                                            >
                                                View Profile
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        );
                    })
                )}
            </div>
        </div>
    );
}