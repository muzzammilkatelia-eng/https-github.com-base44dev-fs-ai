import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, TrendingUp, FileText } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function EmergingTalentScanner({ players, criteria }) {
    const [scanning, setScanning] = useState(false);
    const [identifiedTalents, setIdentifiedTalents] = useState(null);
    const navigate = useNavigate();

    const scanForTalent = async () => {
        setScanning(true);
        toast.loading('AI scanning for emerging talents...', { id: 'scan' });

        try {
            const scoredPlayers = players.filter(p => p.fsai_proprietary_score);
            
            const prompt = `You are the FS-AI Proactive Talent Scanner. Identify emerging talents that scouts should prioritize.

AVAILABLE PLAYERS (${scoredPlayers.length} with FS-AI scores):
${scoredPlayers.slice(0, 100).map(p => `
- ${p.name} (${p.age}y, ${p.position})
  FS-AI: ${p.fsai_proprietary_score} | Grade: ${p.fsai_investment_grade || 'N/A'}
  League: ${p.league || 'Unknown'} | Value: €${p.market_value || 'N/A'}M
  Archetype: ${p.fsai_archetype_primary || 'Unknown'}
`).join('\n')}

ACTIVE SCOUTING CRITERIA (${criteria.length}):
${criteria.map(c => `
- ${c.name}: ${c.criteria_type}
  Filters: ${JSON.stringify(c.filters)}
`).join('\n')}

IDENTIFY TOP 20 EMERGING TALENTS based on:
1. Rapid FS-AI score improvement indicators (high scores in undervalued leagues)
2. High potential metrics (young age + high ceiling)
3. Niche tactical archetype matches (rare profiles)
4. Market inefficiency (undervalued relative to FS-AI score)
5. Active criteria matches

For each player, provide:
- Name & Position
- Emergence Reason (why they're emerging)
- Talent Type (e.g., "Hidden Gem", "Rapid Riser", "Tactical Fit", "Market Inefficiency")
- Priority Score (0-100)
- Quick Scout Summary (2-3 sentences)`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        identified_talents: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    emergence_reason: { type: "string" },
                                    talent_type: { type: "string" },
                                    priority_score: { type: "number" },
                                    scout_summary: { type: "string" },
                                    key_strengths: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    weaknesses: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    tactical_fit: { type: "string" },
                                    recommended_action: { type: "string" }
                                }
                            }
                        },
                        scan_summary: { type: "string" },
                        market_trends: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setIdentifiedTalents(response);
            toast.success(`Identified ${response.identified_talents?.length || 0} emerging talents!`, { id: 'scan' });
        } catch (error) {
            console.error('Scan failed:', error);
            toast.error('Failed to scan for talents', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    const getTalentTypeColor = (type) => {
        if (type?.toLowerCase().includes('gem')) return 'bg-purple-500/20 text-purple-400';
        if (type?.toLowerCase().includes('riser')) return 'bg-emerald-500/20 text-emerald-400';
        if (type?.toLowerCase().includes('tactical')) return 'bg-cyan-500/20 text-cyan-400';
        if (type?.toLowerCase().includes('inefficiency')) return 'bg-amber-500/20 text-amber-400';
        return 'bg-slate-500/20 text-slate-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-cyan-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-cyan-400" />
                            Proactive Talent Identification
                        </CardTitle>
                        <Button
                            onClick={scanForTalent}
                            disabled={scanning}
                            className="bg-gradient-to-r from-cyan-500 to-purple-600"
                        >
                            {scanning ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Scanning...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Scan Database
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm">
                        AI analyzes {players.length} players to identify emerging talents based on FS-AI scores, 
                        rapid improvement patterns, tactical archetype fits, and market inefficiencies.
                    </p>
                </CardContent>
            </Card>

            {identifiedTalents && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Scan Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 mb-4">{identifiedTalents.scan_summary}</p>
                            {identifiedTalents.market_trends && (
                                <div>
                                    <p className="text-slate-400 text-sm font-semibold mb-2">Market Trends:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {identifiedTalents.market_trends.map((trend, idx) => (
                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                                {trend}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    <div className="grid gap-4">
                        {identifiedTalents.identified_talents?.map((talent, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-colors">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h3 className="text-white text-xl font-bold">{talent.player_name}</h3>
                                                    <Badge className="bg-slate-700 text-slate-300">
                                                        {talent.position}
                                                    </Badge>
                                                    <Badge className={getTalentTypeColor(talent.talent_type)}>
                                                        {talent.talent_type}
                                                    </Badge>
                                                </div>
                                                <p className="text-cyan-400 text-sm font-medium mb-2">
                                                    {talent.emergence_reason}
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-slate-400 text-xs mb-1">Priority</p>
                                                <p className={`text-3xl font-bold ${
                                                    talent.priority_score >= 85 ? 'text-emerald-400' :
                                                    talent.priority_score >= 70 ? 'text-cyan-400' :
                                                    'text-amber-400'
                                                }`}>
                                                    {talent.priority_score}
                                                </p>
                                            </div>
                                        </div>

                                        <p className="text-slate-300 text-sm mb-4">{talent.scout_summary}</p>

                                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                                            <div>
                                                <p className="text-emerald-400 text-xs font-semibold mb-2">Strengths:</p>
                                                <ul className="space-y-1">
                                                    {talent.key_strengths?.map((strength, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-emerald-400">+</span>
                                                            {strength}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <p className="text-amber-400 text-xs font-semibold mb-2">Weaknesses:</p>
                                                <ul className="space-y-1">
                                                    {talent.weaknesses?.map((weakness, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-amber-400">-</span>
                                                            {weakness}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-3 mb-3">
                                            <p className="text-purple-400 text-xs font-semibold mb-1">Tactical Fit:</p>
                                            <p className="text-slate-300 text-sm">{talent.tactical_fit}</p>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg px-3 py-2">
                                                <p className="text-cyan-400 text-xs font-semibold mb-1">Recommended Action:</p>
                                                <p className="text-white text-sm">{talent.recommended_action}</p>
                                            </div>
                                            <Button
                                                onClick={() => {
                                                    const player = players.find(p => p.name === talent.player_name);
                                                    if (player) {
                                                        navigate(createPageUrl('PlayerProfile') + `?id=${player.id}`);
                                                    }
                                                }}
                                                size="sm"
                                                className="bg-purple-500 hover:bg-purple-600"
                                            >
                                                <FileText className="w-4 h-4 mr-2" />
                                                View Profile
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            )}

            {!identifiedTalents && !scanning && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <Sparkles className="w-16 h-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">AI Talent Scanner Ready</h3>
                            <p className="text-slate-400 mb-6">
                                Click "Scan Database" to let AI identify emerging talents, hidden gems, and market opportunities
                            </p>
                            <Button
                                onClick={scanForTalent}
                                className="bg-gradient-to-r from-cyan-500 to-purple-600"
                            >
                                <Sparkles className="w-4 h-4 mr-2" />
                                Start Scanning
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}