import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, Loader2, Target, AlertCircle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ProactiveScoutingAgent({ players }) {
    const queryClient = useQueryClient();
    const [scanning, setScanning] = useState(false);
    const [criteria, setCriteria] = useState([
        { 
            name: 'High Potential Young Players',
            league: 'any',
            minAge: 18,
            maxAge: 23,
            positions: ['Winger', 'Striker', 'Attacking Midfielder'],
            minPotential: 80,
            enabled: true
        }
    ]);

    const [newCriteria, setNewCriteria] = useState({
        name: '',
        league: 'any',
        minAge: 18,
        maxAge: 30,
        positions: [],
        minPotential: 70,
        contractExpiry: false,
        enabled: true
    });

    const runProactiveAgent = async () => {
        setScanning(true);
        toast.loading('AI Agent scanning for targets...', { id: 'scan' });

        try {
            const enabledCriteria = criteria.filter(c => c.enabled);
            
            for (const criterion of enabledCriteria) {
                const prompt = `You are an elite football scouting AI agent. Analyze the player database and identify potential targets matching these criteria:

CRITERIA: ${criterion.name}
- Leagues: ${criterion.league === 'any' ? 'All Leagues' : criterion.league}
- Age Range: ${criterion.minAge}-${criterion.maxAge} years
- Positions: ${criterion.positions.join(', ')}
- Minimum Potential: ${criterion.minPotential}/100
- Contract Expiry Focus: ${criterion.contractExpiry ? 'Yes' : 'No'}

AVAILABLE PLAYERS DATABASE:
${players.slice(0, 50).map(p => `- ${p.name}, ${p.age}y, ${p.position}, ${p.current_club}, ${p.league || 'Unknown League'}, Value: €${p.market_value}M`).join('\n')}

Generate a detailed scouting report for the TOP 3 BEST MATCHES from this database. For each player provide:
1. Match score (0-100) against criteria
2. Key strengths for this archetype
3. Development potential
4. Transfer feasibility
5. Recommended next actions

Be specific and realistic based on the actual player data provided.`;

                const response = await base44.integrations.Core.InvokeLLM({
                    prompt,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            criteria_name: { type: "string" },
                            identified_targets: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        player_name: { type: "string" },
                                        match_score: { type: "number" },
                                        key_strengths: { 
                                            type: "array",
                                            items: { type: "string" }
                                        },
                                        development_potential: { type: "string" },
                                        transfer_feasibility: { type: "string" },
                                        recommended_actions: {
                                            type: "array",
                                            items: { type: "string" }
                                        },
                                        priority: { type: "string", enum: ["Critical", "High", "Medium", "Low"] }
                                    }
                                }
                            },
                            summary: { type: "string" }
                        }
                    }
                });

                // Create scouting tasks for identified targets
                for (const target of response.identified_targets) {
                    await base44.entities.ScoutingTask.create({
                        player_name: target.player_name,
                        task_type: 'Initial Assessment',
                        priority: target.priority,
                        status: 'Pending',
                        source: 'AI Flag',
                        criteria_met: [criterion.name],
                        player_data: target,
                        notes: `AI Agent Match Score: ${target.match_score}/100\n\nKey Strengths:\n${target.key_strengths.join('\n')}\n\nRecommended Actions:\n${target.recommended_actions.join('\n')}`
                    });

                    // Create alert
                    await base44.entities.Alert.create({
                        player_name: target.player_name,
                        alert_type: 'scouting_report',
                        criteria_name: criterion.name,
                        player_details: target
                    });
                }
            }

            queryClient.invalidateQueries({ queryKey: ['scoutingTasks'] });
            queryClient.invalidateQueries({ queryKey: ['alerts'] });
            
            toast.success('AI Agent completed scan and generated reports!', { id: 'scan' });
        } catch (error) {
            console.error('Agent scan failed:', error);
            toast.error('Failed to run proactive agent', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    const addCriteria = () => {
        if (!newCriteria.name) {
            toast.error('Please enter a criteria name');
            return;
        }
        setCriteria([...criteria, { ...newCriteria }]);
        setNewCriteria({
            name: '',
            league: 'any',
            minAge: 18,
            maxAge: 30,
            positions: [],
            minPotential: 70,
            contractExpiry: false,
            enabled: true
        });
        toast.success('Criteria added');
    };

    const removeCriteria = (index) => {
        setCriteria(criteria.filter((_, i) => i !== index));
    };

    const toggleCriteria = (index) => {
        const updated = [...criteria];
        updated[index].enabled = !updated[index].enabled;
        setCriteria(updated);
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 via-cyan-500/10 to-blue-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-6 h-6 text-purple-400" />
                        AI Proactive Scouting Agent
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Automated talent identification based on defined scouting criteria
                    </p>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-slate-900/50 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                                <Target className="w-5 h-5 text-cyan-400" />
                                <span className="text-white font-semibold">Active Criteria</span>
                            </div>
                            <p className="text-3xl font-bold text-white">
                                {criteria.filter(c => c.enabled).length}
                            </p>
                        </div>

                        <div className="bg-slate-900/50 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                                <Sparkles className="w-5 h-5 text-purple-400" />
                                <span className="text-white font-semibold">Players Scanned</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{players.length}</p>
                        </div>

                        <div className="bg-slate-900/50 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                <span className="text-white font-semibold">Status</span>
                            </div>
                            <Badge className={scanning ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}>
                                {scanning ? 'Scanning...' : 'Ready'}
                            </Badge>
                        </div>
                    </div>

                    <Button
                        onClick={runProactiveAgent}
                        disabled={scanning || criteria.filter(c => c.enabled).length === 0}
                        className="w-full bg-gradient-to-r from-purple-500 to-cyan-600 hover:from-purple-400 hover:to-cyan-500"
                        size="lg"
                    >
                        {scanning ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                AI Agent Scanning...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-5 h-5 mr-2" />
                                Run Proactive Agent
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {/* Active Criteria */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Active Scouting Criteria</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                    <AnimatePresence>
                        {criteria.map((c, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className={`bg-slate-800/50 rounded-lg p-4 border ${c.enabled ? 'border-cyan-500/30' : 'border-slate-700'}`}
                            >
                                <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <h4 className="text-white font-semibold">{c.name}</h4>
                                            <Badge className={c.enabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-500/20 text-slate-400'}>
                                                {c.enabled ? 'Active' : 'Disabled'}
                                            </Badge>
                                        </div>
                                        <div className="grid md:grid-cols-3 gap-2 text-sm">
                                            <span className="text-slate-400">Age: {c.minAge}-{c.maxAge}</span>
                                            <span className="text-slate-400">Potential: {c.minPotential}+</span>
                                            <span className="text-slate-400">League: {c.league}</span>
                                        </div>
                                        <p className="text-slate-500 text-xs mt-2">
                                            Positions: {c.positions.join(', ')}
                                        </p>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button
                                            onClick={() => toggleCriteria(idx)}
                                            size="sm"
                                            variant="outline"
                                        >
                                            {c.enabled ? 'Disable' : 'Enable'}
                                        </Button>
                                        <Button
                                            onClick={() => removeCriteria(idx)}
                                            size="sm"
                                            variant="outline"
                                            className="text-red-400"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </CardContent>
            </Card>

            {/* Add New Criteria */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Plus className="w-5 h-5" />
                        Add New Scouting Criteria
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Input
                        placeholder="Criteria name (e.g., 'Emerging Strikers in La Liga')"
                        value={newCriteria.name}
                        onChange={(e) => setNewCriteria({ ...newCriteria, name: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                    />

                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Min Age</label>
                            <Input
                                type="number"
                                value={newCriteria.minAge}
                                onChange={(e) => setNewCriteria({ ...newCriteria, minAge: parseInt(e.target.value) })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Max Age</label>
                            <Input
                                type="number"
                                value={newCriteria.maxAge}
                                onChange={(e) => setNewCriteria({ ...newCriteria, maxAge: parseInt(e.target.value) })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Min Potential</label>
                            <Input
                                type="number"
                                value={newCriteria.minPotential}
                                onChange={(e) => setNewCriteria({ ...newCriteria, minPotential: parseInt(e.target.value) })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">League</label>
                            <Select value={newCriteria.league} onValueChange={(value) => setNewCriteria({ ...newCriteria, league: value })}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="any">Any League</SelectItem>
                                    <SelectItem value="Premier League">Premier League</SelectItem>
                                    <SelectItem value="La Liga">La Liga</SelectItem>
                                    <SelectItem value="Bundesliga">Bundesliga</SelectItem>
                                    <SelectItem value="Serie A">Serie A</SelectItem>
                                    <SelectItem value="Ligue 1">Ligue 1</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <Button onClick={addCriteria} className="w-full bg-cyan-500 hover:bg-cyan-600">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Criteria
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}