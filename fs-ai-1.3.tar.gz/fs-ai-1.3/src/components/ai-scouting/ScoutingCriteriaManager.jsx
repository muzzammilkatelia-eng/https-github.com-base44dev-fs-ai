import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Target, Edit, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ScoutingCriteriaManager({ criteria }) {
    const [showForm, setShowForm] = useState(false);
    const [editingCriteria, setEditingCriteria] = useState(null);
    const queryClient = useQueryClient();

    const [formData, setFormData] = useState({
        name: '',
        criteria_type: 'High Potential',
        filters: {
            min_potential_rating: 75,
            max_age: 23,
            positions: [],
            regions: [],
            trajectories: []
        },
        auto_assign: false,
        priority_level: 'Medium'
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.AIScoutingCriteria.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouting-criteria'] });
            setShowForm(false);
            resetForm();
            toast.success('Criteria created!');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.AIScoutingCriteria.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouting-criteria'] });
            toast.success('Criteria deleted');
        }
    });

    const resetForm = () => {
        setFormData({
            name: '',
            criteria_type: 'High Potential',
            filters: {
                min_potential_rating: 75,
                max_age: 23,
                positions: [],
                regions: [],
                trajectories: []
            },
            auto_assign: false,
            priority_level: 'Medium'
        });
        setEditingCriteria(null);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        createMutation.mutate(formData);
    };

    const POSITIONS = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];
    const REGIONS = ['Europe', 'South America', 'Africa', 'Asia', 'North America'];
    const TRAJECTORIES = ['Elite Tier Prospect', 'Top Tier Prospect', 'Solid Professional', 'Late Bloomer'];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Scouting Criteria Configuration
                        </CardTitle>
                        <Dialog open={showForm} onOpenChange={setShowForm}>
                            <DialogTrigger asChild>
                                <Button className="bg-gradient-to-r from-cyan-500 to-blue-600">
                                    <Plus className="w-4 h-4 mr-2" />
                                    New Criteria
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                                <DialogHeader>
                                    <DialogTitle>Create Scouting Criteria</DialogTitle>
                                </DialogHeader>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <Label>Criteria Name</Label>
                                        <Input
                                            value={formData.name}
                                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                                            placeholder="e.g., Young South American Talents"
                                            className="bg-slate-800 border-slate-700"
                                            required
                                        />
                                    </div>

                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <Label>Criteria Type</Label>
                                            <Select value={formData.criteria_type} onValueChange={(v) => setFormData({...formData, criteria_type: v})}>
                                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="High Potential">High Potential</SelectItem>
                                                    <SelectItem value="Undervalued">Undervalued</SelectItem>
                                                    <SelectItem value="Urgent">Urgent</SelectItem>
                                                    <SelectItem value="Position Specific">Position Specific</SelectItem>
                                                    <SelectItem value="Custom">Custom</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        <div>
                                            <Label>Priority Level</Label>
                                            <Select value={formData.priority_level} onValueChange={(v) => setFormData({...formData, priority_level: v})}>
                                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Critical">Critical</SelectItem>
                                                    <SelectItem value="High">High</SelectItem>
                                                    <SelectItem value="Medium">Medium</SelectItem>
                                                    <SelectItem value="Low">Low</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <Label>Min FS-AI Score</Label>
                                            <Input
                                                type="number"
                                                value={formData.filters.min_potential_rating}
                                                onChange={(e) => setFormData({
                                                    ...formData,
                                                    filters: {...formData.filters, min_potential_rating: parseInt(e.target.value)}
                                                })}
                                                className="bg-slate-800 border-slate-700"
                                            />
                                        </div>
                                        <div>
                                            <Label>Max Age</Label>
                                            <Input
                                                type="number"
                                                value={formData.filters.max_age}
                                                onChange={(e) => setFormData({
                                                    ...formData,
                                                    filters: {...formData.filters, max_age: parseInt(e.target.value)}
                                                })}
                                                className="bg-slate-800 border-slate-700"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label>Target Regions (Optional)</Label>
                                        <div className="flex flex-wrap gap-2 mt-2">
                                            {REGIONS.map(region => (
                                                <Badge
                                                    key={region}
                                                    onClick={() => {
                                                        const regions = formData.filters.regions || [];
                                                        setFormData({
                                                            ...formData,
                                                            filters: {
                                                                ...formData.filters,
                                                                regions: regions.includes(region) 
                                                                    ? regions.filter(r => r !== region)
                                                                    : [...regions, region]
                                                            }
                                                        });
                                                    }}
                                                    className={`cursor-pointer ${
                                                        formData.filters.regions?.includes(region)
                                                            ? 'bg-cyan-500/20 text-cyan-400'
                                                            : 'bg-slate-700 text-slate-300'
                                                    }`}
                                                >
                                                    {region}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>

                                    <Button type="submit" className="w-full bg-gradient-to-r from-cyan-500 to-blue-600">
                                        Create Criteria
                                    </Button>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm mb-4">
                        Define custom scouting criteria to automatically identify players matching your strategic needs
                    </p>
                </CardContent>
            </Card>

            <div className="grid gap-4">
                {criteria.length === 0 ? (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="py-12">
                            <div className="text-center">
                                <Target className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                                <p className="text-slate-400">No scouting criteria defined yet</p>
                            </div>
                        </CardContent>
                    </Card>
                ) : (
                    criteria.map((item, idx) => (
                        <motion.div
                            key={item.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.05 }}
                        >
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                <h3 className="text-white text-lg font-semibold">{item.name}</h3>
                                                <Badge className={
                                                    item.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-500/20 text-slate-400'
                                                }>
                                                    {item.active ? 'Active' : 'Inactive'}
                                                </Badge>
                                                <Badge className="bg-purple-500/20 text-purple-400">
                                                    {item.criteria_type}
                                                </Badge>
                                            </div>
                                            <div className="flex items-center gap-4 text-sm text-slate-400 mb-3">
                                                {item.filters?.min_potential_rating && (
                                                    <span>Min Score: {item.filters.min_potential_rating}</span>
                                                )}
                                                {item.filters?.max_age && (
                                                    <span>Max Age: {item.filters.max_age}</span>
                                                )}
                                                <Badge className={
                                                    item.priority_level === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                    item.priority_level === 'High' ? 'bg-orange-500/20 text-orange-400' :
                                                    'bg-slate-500/20 text-slate-400'
                                                }>
                                                    {item.priority_level}
                                                </Badge>
                                            </div>
                                            {item.filters?.regions && item.filters.regions.length > 0 && (
                                                <div className="flex flex-wrap gap-2">
                                                    {item.filters.regions.map((region, i) => (
                                                        <Badge key={i} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                            {region}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                        <Button
                                            onClick={() => deleteMutation.mutate(item.id)}
                                            variant="ghost"
                                            size="sm"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))
                )}
            </div>
        </div>
    );
}