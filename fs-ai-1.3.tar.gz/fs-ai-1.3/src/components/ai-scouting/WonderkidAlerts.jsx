import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Star, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function WonderkidAlerts({ players }) {
    const [analyzing, setAnalyzing] = useState(false);
    const [wonderkids, setWonderkids] = useState(null);
    const navigate = useNavigate();

    const identifyWonderkids = async () => {
        setAnalyzing(true);
        toast.loading('Identifying wonderkid candidates...', { id: 'wonderkids' });

        try {
            const youngPlayers = players.filter(p => p.age <= 21 && p.fsai_proprietary_score);

            const prompt = `You are the FS-AI Wonderkid Identifier. Analyze young players to find exceptional talents.

YOUNG PLAYERS (${youngPlayers.length} under 22 with FS-AI scores):
${youngPlayers.map(p => `
- ${p.name} (${p.age}y, ${p.position})
  FS-AI: ${p.fsai_proprietary_score} | Grade: ${p.fsai_investment_grade || 'N/A'}
  League: ${p.league || 'Unknown'} | Value: €${p.market_value || 'N/A'}M
  Archetype: ${p.fsai_archetype_primary || 'Unknown'}
`).join('\n')}

IDENTIFY TOP 15 WONDERKID CANDIDATES showing:
1. Exceptional FS-AI scores for their age
2. Rare tactical profiles or archetypes
3. Rapid development indicators
4. High ceiling potential
5. Value vs potential mismatch

For each wonderkid, provide:
- Name, Age, Position
- Wonderkid Rating (0-100)
- Standout Quality (what makes them special)
- Development Trajectory (predicted growth path)
- Peak Potential (predicted peak rating)
- Investment Case (why sign them now)
- Risk Factors
- Comparable Player (similar career path)`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        wonderkids: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    wonderkid_rating: { type: "number" },
                                    standout_quality: { type: "string" },
                                    development_trajectory: { type: "string" },
                                    peak_potential: { type: "string" },
                                    investment_case: { type: "string" },
                                    risk_factors: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    comparable_player: { type: "string" },
                                    urgency_level: { type: "string" }
                                }
                            }
                        },
                        analysis_summary: { type: "string" }
                    }
                }
            });

            setWonderkids(response);
            toast.success(`Found ${response.wonderkids?.length || 0} wonderkid candidates!`, { id: 'wonderkids' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to identify wonderkids', { id: 'wonderkids' });
        } finally {
            setAnalyzing(false);
        }
    };

    const getUrgencyColor = (urgency) => {
        if (urgency?.toLowerCase().includes('critical') || urgency?.toLowerCase().includes('immediate')) {
            return 'bg-red-500/20 text-red-400 border-red-500/30';
        }
        if (urgency?.toLowerCase().includes('high')) {
            return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
        }
        if (urgency?.toLowerCase().includes('medium')) {
            return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        }
        return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Star className="w-5 h-5 text-amber-400" />
                            Wonderkid Detection System
                        </CardTitle>
                        <Button
                            onClick={identifyWonderkids}
                            disabled={analyzing}
                            className="bg-gradient-to-r from-amber-500 to-orange-600"
                        >
                            {analyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Identify Wonderkids
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm">
                        AI analyzes young players (≤21 years) showing exceptional growth, rare profiles, and high ceiling potential.
                    </p>
                </CardContent>
            </Card>

            {wonderkids && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {wonderkids.analysis_summary && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <p className="text-slate-300">{wonderkids.analysis_summary}</p>
                            </CardContent>
                        </Card>
                    )}

                    <div className="grid gap-4">
                        {wonderkids.wonderkids?.map((kid, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-gradient-to-br from-amber-500/5 to-orange-500/5 border-amber-500/30 hover:border-amber-500/50 transition-colors">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                                                    <Star className="w-6 h-6 text-white" />
                                                </div>
                                                <div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <h3 className="text-white text-xl font-bold">{kid.player_name}</h3>
                                                        <Badge className="bg-slate-700 text-slate-300">
                                                            {kid.age}y
                                                        </Badge>
                                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                                            {kid.position}
                                                        </Badge>
                                                    </div>
                                                    <Badge className={getUrgencyColor(kid.urgency_level)}>
                                                        {kid.urgency_level} Urgency
                                                    </Badge>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-slate-400 text-xs mb-1">Wonderkid Rating</p>
                                                <p className={`text-4xl font-bold ${
                                                    kid.wonderkid_rating >= 90 ? 'text-emerald-400' :
                                                    kid.wonderkid_rating >= 80 ? 'text-amber-400' :
                                                    'text-cyan-400'
                                                }`}>
                                                    {kid.wonderkid_rating}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mb-4">
                                            <p className="text-amber-400 text-xs font-semibold mb-1">Standout Quality</p>
                                            <p className="text-white font-medium">{kid.standout_quality}</p>
                                        </div>

                                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-center gap-2 mb-2">
                                                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                                                    <p className="text-slate-400 text-xs font-semibold">Development Trajectory</p>
                                                </div>
                                                <p className="text-slate-300 text-sm">{kid.development_trajectory}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-purple-400 text-xs font-semibold mb-1">Peak Potential</p>
                                                <p className="text-white text-lg font-bold">{kid.peak_potential}</p>
                                            </div>
                                        </div>

                                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 mb-3">
                                            <p className="text-emerald-400 text-xs font-semibold mb-1">Investment Case</p>
                                            <p className="text-slate-300 text-sm">{kid.investment_case}</p>
                                        </div>

                                        {kid.risk_factors && kid.risk_factors.length > 0 && (
                                            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-3">
                                                <p className="text-red-400 text-xs font-semibold mb-2">Risk Factors</p>
                                                <ul className="space-y-1">
                                                    {kid.risk_factors.map((risk, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-red-400">!</span>
                                                            {risk}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}

                                        <div className="flex items-center justify-between">
                                            <div className="text-sm">
                                                <span className="text-slate-400">Similar to:</span>
                                                <span className="text-purple-400 font-semibold ml-2">{kid.comparable_player}</span>
                                            </div>
                                            <Button
                                                onClick={() => {
                                                    const player = players.find(p => p.name === kid.player_name);
                                                    if (player) {
                                                        navigate(createPageUrl('PlayerProfile') + `?id=${player.id}`);
                                                    }
                                                }}
                                                size="sm"
                                                className="bg-amber-500 hover:bg-amber-600"
                                            >
                                                View Profile
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            )}

            {!wonderkids && !analyzing && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <Star className="w-16 h-16 text-amber-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Wonderkid Detection Ready</h3>
                            <p className="text-slate-400 mb-6">
                                Analyze young players to identify future superstars with exceptional potential
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}