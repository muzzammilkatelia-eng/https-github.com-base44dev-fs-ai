import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { UserSearch, Loader2, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AutomatedProfiling() {
    const [playerName, setPlayerName] = useState('');
    const [profile, setProfile] = useState(null);

    const profileMutation = useMutation({
        mutationFn: async (name) => {
            const prompt = `You are an elite football data analyst. Create a comprehensive player profile by gathering public data for: ${name}

Research and compile:

1. **Basic Information**
   - Full name, date of birth, nationality, height, weight
   - Current club, contract expiry, jersey number
   - Preferred foot, position(s)

2. **Career Statistics**
   - Current season stats (appearances, goals, assists, minutes)
   - Career totals across all competitions
   - International caps and goals

3. **Market Information**
   - Current market value (Transfermarkt)
   - Transfer history and fees
   - Contract situation

4. **Performance Metrics**
   - Key statistical strengths
   - Positional heat map summary
   - Passing/shooting/defensive stats

5. **Playing Style**
   - Tactical role and characteristics
   - Strengths and weaknesses
   - Comparison to similar players

6. **Recent Form**
   - Last 5 games performance
   - Goals/assists trend
   - Any recent news or developments

Provide accurate, up-to-date information from reliable sources.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        basic_info: {
                            type: "object",
                            properties: {
                                full_name: { type: "string" },
                                date_of_birth: { type: "string" },
                                age: { type: "number" },
                                nationality: { type: "string" },
                                height: { type: "string" },
                                preferred_foot: { type: "string" },
                                position: { type: "string" },
                                current_club: { type: "string" },
                                jersey_number: { type: "number" }
                            }
                        },
                        statistics: {
                            type: "object",
                            properties: {
                                appearances_this_season: { type: "number" },
                                goals_this_season: { type: "number" },
                                assists_this_season: { type: "number" },
                                minutes_played: { type: "number" },
                                career_goals: { type: "number" },
                                career_assists: { type: "number" },
                                international_caps: { type: "number" }
                            }
                        },
                        market_info: {
                            type: "object",
                            properties: {
                                market_value: { type: "string" },
                                contract_expires: { type: "string" },
                                previous_clubs: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        },
                        playing_style: {
                            type: "object",
                            properties: {
                                description: { type: "string" },
                                strengths: {
                                    type: "array",
                                    items: { type: "string" }
                                },
                                weaknesses: {
                                    type: "array",
                                    items: { type: "string" }
                                },
                                similar_players: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        },
                        recent_form: {
                            type: "object",
                            properties: {
                                form_rating: { type: "string" },
                                recent_highlights: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setProfile(data);
            toast.success('Profile generated successfully');
        },
        onError: () => {
            toast.error('Failed to generate profile');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (playerName.trim()) {
            profileMutation.mutate(playerName);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <UserSearch className="w-5 h-5 text-emerald-400" />
                        Automated Player Profiling
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <Label className="text-slate-400">Player Name</Label>
                            <Input
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value)}
                                placeholder="e.g., Erling Haaland"
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                        </div>

                        <Button
                            type="submit"
                            disabled={!playerName.trim() || profileMutation.isPending}
                            className="w-full bg-gradient-to-r from-emerald-500 to-green-600"
                        >
                            {profileMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Gathering Data...
                                </>
                            ) : (
                                <>
                                    <UserSearch className="w-4 h-4 mr-2" />
                                    Generate Player Profile
                                </>
                            )}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            <AnimatePresence>
                {profile && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Basic Info */}
                        <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-white">{profile.basic_info.full_name}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Age</p>
                                        <p className="text-white font-semibold">{profile.basic_info.age}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Nationality</p>
                                        <p className="text-white font-semibold">{profile.basic_info.nationality}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Position</p>
                                        <Badge className="bg-emerald-500/20 text-emerald-400">{profile.basic_info.position}</Badge>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Current Club</p>
                                        <p className="text-white font-semibold">{profile.basic_info.current_club}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Statistics */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Season Statistics</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                                    <div className="text-center">
                                        <p className="text-3xl font-bold text-cyan-400">{profile.statistics.appearances_this_season}</p>
                                        <p className="text-slate-400 text-xs mt-1">Appearances</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-3xl font-bold text-emerald-400">{profile.statistics.goals_this_season}</p>
                                        <p className="text-slate-400 text-xs mt-1">Goals</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-3xl font-bold text-purple-400">{profile.statistics.assists_this_season}</p>
                                        <p className="text-slate-400 text-xs mt-1">Assists</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-3xl font-bold text-amber-400">{profile.statistics.minutes_played}</p>
                                        <p className="text-slate-400 text-xs mt-1">Minutes</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-3xl font-bold text-blue-400">{profile.statistics.international_caps}</p>
                                        <p className="text-slate-400 text-xs mt-1">Int. Caps</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Market Info */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Market Information</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Market Value</p>
                                        <p className="text-2xl font-bold text-emerald-400">{profile.market_info.market_value}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Contract Expires</p>
                                        <p className="text-white font-semibold">{profile.market_info.contract_expires}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Playing Style */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Playing Style</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <p className="text-slate-300 text-sm">{profile.playing_style.description}</p>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-emerald-400 text-xs font-semibold mb-2">Strengths</p>
                                        <ul className="space-y-1">
                                            {profile.playing_style.strengths.map((strength, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-emerald-400">✓</span>
                                                    {strength}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <p className="text-amber-400 text-xs font-semibold mb-2">Weaknesses</p>
                                        <ul className="space-y-1">
                                            {profile.playing_style.weaknesses.map((weakness, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400">⚠</span>
                                                    {weakness}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>

                                <div>
                                    <p className="text-cyan-400 text-xs font-semibold mb-2">Similar Players</p>
                                    <div className="flex flex-wrap gap-2">
                                        {profile.playing_style.similar_players.map((player, i) => (
                                            <Badge key={i} className="bg-cyan-500/20 text-cyan-400">
                                                {player}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Recent Form */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Recent Form</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Badge className="bg-purple-500/20 text-purple-400 mb-3">
                                    {profile.recent_form.form_rating}
                                </Badge>
                                <ul className="space-y-2">
                                    {profile.recent_form.recent_highlights.map((highlight, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-purple-400">•</span>
                                            {highlight}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}