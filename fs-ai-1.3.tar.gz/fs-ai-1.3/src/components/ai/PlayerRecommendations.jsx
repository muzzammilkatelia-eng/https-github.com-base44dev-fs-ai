import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Target, Loader2, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function PlayerRecommendations() {
    const [clubNeeds, setClubNeeds] = useState({
        positions: '',
        budget: '',
        ageRange: '',
        requirements: ''
    });
    const [recommendations, setRecommendations] = useState(null);

    const recommendMutation = useMutation({
        mutationFn: async (needs) => {
            const prompt = `You are an elite football recruitment AI. Based on the club's requirements, recommend suitable players:

CLUB REQUIREMENTS:
- Positions Needed: ${needs.positions || 'Any'}
- Budget: ${needs.budget || 'Not specified'}
- Age Range: ${needs.ageRange || 'Any'}
- Additional Requirements: ${needs.requirements || 'None'}

Analyze current scouting reports and market data to recommend 5-8 players that match these criteria.

For each player provide:
1. Player name, age, position, current club
2. Why they match the requirements
3. Estimated transfer fee
4. Key strengths (3-5 points)
5. Potential concerns
6. Match score (0-100) based on requirements
7. Availability status (Available/Difficult/Contract ends)

Prioritize realistic targets and value for money.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    current_club: { type: "string" },
                                    match_rationale: { type: "string" },
                                    estimated_fee: { type: "string" },
                                    key_strengths: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    concerns: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    match_score: { type: "number" },
                                    availability: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setRecommendations(data.recommendations);
            toast.success(`Found ${data.recommendations.length} player recommendations`);
        },
        onError: () => {
            toast.error('Failed to generate recommendations');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        recommendMutation.mutate(clubNeeds);
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        AI Player Recommendations
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400">Positions Needed</Label>
                                <Input
                                    value={clubNeeds.positions}
                                    onChange={(e) => setClubNeeds({...clubNeeds, positions: e.target.value})}
                                    placeholder="e.g., Striker, Centre-Back"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400">Budget Range</Label>
                                <Input
                                    value={clubNeeds.budget}
                                    onChange={(e) => setClubNeeds({...clubNeeds, budget: e.target.value})}
                                    placeholder="e.g., €5M - €15M"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-400">Age Range</Label>
                            <Input
                                value={clubNeeds.ageRange}
                                onChange={(e) => setClubNeeds({...clubNeeds, ageRange: e.target.value})}
                                placeholder="e.g., 18-23"
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                        </div>

                        <div>
                            <Label className="text-slate-400">Additional Requirements</Label>
                            <Textarea
                                value={clubNeeds.requirements}
                                onChange={(e) => setClubNeeds({...clubNeeds, requirements: e.target.value})}
                                placeholder="e.g., Good in the air, left-footed, Premier League experience..."
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                                rows={4}
                            />
                        </div>

                        <Button
                            type="submit"
                            disabled={recommendMutation.isPending}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {recommendMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Finding Players...
                                </>
                            ) : (
                                <>
                                    <Target className="w-4 h-4 mr-2" />
                                    Get AI Recommendations
                                </>
                            )}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            <AnimatePresence>
                {recommendations && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {recommendations
                            .sort((a, b) => b.match_score - a.match_score)
                            .map((player, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/30 transition-all">
                                    <CardHeader>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <CardTitle className="text-white text-lg">
                                                    {player.player_name}
                                                </CardTitle>
                                                <p className="text-slate-400 text-sm mt-1">
                                                    {player.age}y • {player.position} • {player.current_club}
                                                </p>
                                            </div>
                                            <div className="flex gap-2">
                                                <Badge className={
                                                    player.match_score >= 80 ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                                                    player.match_score >= 60 ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' :
                                                    'bg-amber-500/20 text-amber-400 border-amber-500/30'
                                                }>
                                                    {player.match_score}% Match
                                                </Badge>
                                            </div>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-slate-500 text-xs mb-1">Estimated Fee</p>
                                                <p className="text-emerald-400 font-semibold">{player.estimated_fee}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs mb-1">Availability</p>
                                                <Badge className={
                                                    player.availability === 'Available' ? 'bg-emerald-500/20 text-emerald-400' :
                                                    player.availability === 'Difficult' ? 'bg-red-500/20 text-red-400' :
                                                    'bg-amber-500/20 text-amber-400'
                                                }>
                                                    {player.availability}
                                                </Badge>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded p-3">
                                            <p className="text-cyan-400 text-xs font-semibold mb-1">Why This Player?</p>
                                            <p className="text-slate-300 text-sm">{player.match_rationale}</p>
                                        </div>

                                        <div>
                                            <p className="text-emerald-400 text-xs font-semibold mb-2">Key Strengths</p>
                                            <ul className="space-y-1">
                                                {player.key_strengths.map((strength, i) => (
                                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                        <span className="text-emerald-400">✓</span>
                                                        {strength}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        {player.concerns && player.concerns.length > 0 && (
                                            <div>
                                                <p className="text-amber-400 text-xs font-semibold mb-2">Potential Concerns</p>
                                                <ul className="space-y-1">
                                                    {player.concerns.map((concern, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-amber-400">⚠</span>
                                                            {concern}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}