import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ReportAnalyzer() {
    const [selectedReport, setSelectedReport] = useState(null);
    const [analysis, setAnalysis] = useState(null);

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const analyzeMutation = useMutation({
        mutationFn: async (report) => {
            const prompt = `You are an elite football scout analysis AI. Analyze this scouting report in detail:

PLAYER: ${report.player_name}
AGE: ${report.player_age}
POSITION: ${report.position}
CLUB: ${report.current_club}

SCOUT NOTES: ${report.notes || 'N/A'}

TECHNICAL RATING: ${report.technical_rating}/100
PHYSICAL RATING: ${report.physical_rating}/100
TACTICAL RATING: ${report.tactical_rating}/100
MENTAL RATING: ${report.mental_rating}/100

RECOMMENDATION: ${report.recommendation}

Provide a comprehensive AI analysis including:

1. **Key Strengths**: Top 3-5 standout attributes
2. **Areas for Development**: Main weaknesses to address
3. **Potential Rating**: Realistic ceiling (0-100)
4. **Playing Style**: Tactical profile and best role
5. **Market Value Estimate**: Current and potential future value
6. **Transfer Readiness**: Is the player ready for a move? 
7. **Risk Assessment**: Injury concerns, consistency issues, or red flags
8. **Comparison**: Similar players in world football
9. **Development Timeline**: How long until peak performance
10. **Recommendation Summary**: Clear buy/watch/pass advice

Be data-driven and realistic.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        key_strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        areas_for_development: {
                            type: "array",
                            items: { type: "string" }
                        },
                        potential_rating: { type: "number" },
                        playing_style: { type: "string" },
                        market_value_current: { type: "string" },
                        market_value_potential: { type: "string" },
                        transfer_readiness: { type: "string" },
                        risk_assessment: { type: "string" },
                        similar_players: {
                            type: "array",
                            items: { type: "string" }
                        },
                        development_timeline: { type: "string" },
                        final_recommendation: { type: "string" },
                        overall_verdict: {
                            type: "string",
                            enum: ["Strong Buy", "Buy", "Monitor", "Watch", "Pass"]
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setAnalysis(data);
            toast.success('Analysis complete');
        },
        onError: () => {
            toast.error('Analysis failed');
        }
    });

    const getVerdictColor = (verdict) => {
        const colors = {
            'Strong Buy': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Buy': 'bg-green-500/20 text-green-400 border-green-500/30',
            'Monitor': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Watch': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Pass': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[verdict] || '';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Report Analysis
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Select value={selectedReport?.id} onValueChange={(id) => {
                            const report = reports.find(r => r.id === id);
                            setSelectedReport(report);
                            setAnalysis(null);
                        }}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select a scouting report to analyze" />
                            </SelectTrigger>
                            <SelectContent>
                                {reports.map(report => (
                                    <SelectItem key={report.id} value={report.id}>
                                        {report.player_name} - {report.position} ({report.player_age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {selectedReport && (
                        <Button
                            onClick={() => analyzeMutation.mutate(selectedReport)}
                            disabled={analyzeMutation.isPending}
                            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600"
                        >
                            {analyzeMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing with AI...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate AI Analysis
                                </>
                            )}
                        </Button>
                    )}
                </CardContent>
            </Card>

            <AnimatePresence>
                {analysis && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Overall Verdict */}
                        <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                            <CardContent className="pt-6">
                                <div className="text-center">
                                    <Badge className={`${getVerdictColor(analysis.overall_verdict)} text-lg px-4 py-2`}>
                                        {analysis.overall_verdict}
                                    </Badge>
                                    <p className="text-slate-300 mt-3">{analysis.final_recommendation}</p>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Key Metrics */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-1">Potential Rating</p>
                                    <p className="text-3xl font-bold text-purple-400">{analysis.potential_rating}/100</p>
                                </CardContent>
                            </Card>
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-1">Current Value</p>
                                    <p className="text-2xl font-bold text-emerald-400">{analysis.market_value_current}</p>
                                </CardContent>
                            </Card>
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-1">Future Value</p>
                                    <p className="text-2xl font-bold text-cyan-400">{analysis.market_value_potential}</p>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Detailed Analysis */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                                        Key Strengths
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {analysis.key_strengths.map((strength, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400 mt-1">✓</span>
                                                {strength}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                                        Areas for Development
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {analysis.areas_for_development.map((area, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-amber-400 mt-1">⚠</span>
                                                {area}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </div>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Playing Style & Best Role</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.playing_style}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Transfer Readiness</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.transfer_readiness}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Risk Assessment</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.risk_assessment}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Similar Players</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {analysis.similar_players.map((player, idx) => (
                                        <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                            {player}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-purple-400" />
                                    Development Timeline
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.development_timeline}</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}