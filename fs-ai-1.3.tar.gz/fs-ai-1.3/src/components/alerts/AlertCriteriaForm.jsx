import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

export default function AlertCriteriaForm({ onSubmit, onCancel, existingCriteria }) {
    const [formData, setFormData] = useState(existingCriteria || {
        name: '',
        active: true,
        trigger_type: 'both',
        criteria: {
            positions: [],
            recommendations: [],
            trajectories: []
        },
        notify_slack: false,
        slack_channel: '#scouting'
    });

    const positions = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];
    const recommendations = ['Strong Recommend', 'Recommend', 'Monitor'];
    const trajectories = ['Elite Tier Prospect', 'Top Tier Prospect', 'Solid Professional', 'Late Bloomer'];

    const toggleArrayItem = (field, item) => {
        setFormData(prev => ({
            ...prev,
            criteria: {
                ...prev.criteria,
                [field]: prev.criteria[field]?.includes(item)
                    ? prev.criteria[field].filter(i => i !== item)
                    : [...(prev.criteria[field] || []), item]
            }
        }));
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white">
                    {existingCriteria ? 'Edit Alert Criteria' : 'New Alert Criteria'}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <Label className="text-slate-400">Alert Name *</Label>
                    <Input
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="e.g., Elite Young Midfielders"
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                    />
                </div>

                <div>
                    <Label className="text-slate-400">Trigger Type *</Label>
                    <Select value={formData.trigger_type} onValueChange={(v) => setFormData({...formData, trigger_type: v})}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="both">Scouting Reports & Projections</SelectItem>
                            <SelectItem value="scouting_report">Scouting Reports Only</SelectItem>
                            <SelectItem value="projection">Projections Only</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                <div>
                    <Label className="text-slate-400">Positions</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                        {positions.map(pos => (
                            <Badge
                                key={pos}
                                onClick={() => toggleArrayItem('positions', pos)}
                                className={`cursor-pointer ${
                                    formData.criteria?.positions?.includes(pos)
                                        ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                                        : 'bg-slate-800 text-slate-400 border-slate-700'
                                }`}
                            >
                                {pos}
                            </Badge>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <Label className="text-slate-400">Min Age</Label>
                        <Input
                            type="number"
                            value={formData.criteria?.min_age || ''}
                            onChange={(e) => setFormData({
                                ...formData,
                                criteria: {...formData.criteria, min_age: parseInt(e.target.value) || undefined}
                            })}
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-400">Max Age</Label>
                        <Input
                            type="number"
                            value={formData.criteria?.max_age || ''}
                            onChange={(e) => setFormData({
                                ...formData,
                                criteria: {...formData.criteria, max_age: parseInt(e.target.value) || undefined}
                            })}
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                    </div>
                </div>

                {(formData.trigger_type === 'scouting_report' || formData.trigger_type === 'both') && (
                    <div>
                        <Label className="text-slate-400">Recommendations</Label>
                        <div className="flex flex-wrap gap-2 mt-2">
                            {recommendations.map(rec => (
                                <Badge
                                    key={rec}
                                    onClick={() => toggleArrayItem('recommendations', rec)}
                                    className={`cursor-pointer ${
                                        formData.criteria?.recommendations?.includes(rec)
                                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                            : 'bg-slate-800 text-slate-400 border-slate-700'
                                    }`}
                                >
                                    {rec}
                                </Badge>
                            ))}
                        </div>
                    </div>
                )}

                {(formData.trigger_type === 'projection' || formData.trigger_type === 'both') && (
                    <>
                        <div>
                            <Label className="text-slate-400">Trajectories</Label>
                            <div className="flex flex-wrap gap-2 mt-2">
                                {trajectories.map(traj => (
                                    <Badge
                                        key={traj}
                                        onClick={() => toggleArrayItem('trajectories', traj)}
                                        className={`cursor-pointer ${
                                            formData.criteria?.trajectories?.includes(traj)
                                                ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                                                : 'bg-slate-800 text-slate-400 border-slate-700'
                                        }`}
                                    >
                                        {traj}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-400">Min Potential Rating</Label>
                            <Input
                                type="number"
                                min="50"
                                max="99"
                                value={formData.criteria?.min_potential_rating || ''}
                                onChange={(e) => setFormData({
                                    ...formData,
                                    criteria: {...formData.criteria, min_potential_rating: parseInt(e.target.value) || undefined}
                                })}
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                        </div>
                    </>
                )}

                <div className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                    <div>
                        <Label className="text-white">Slack Notifications</Label>
                        <p className="text-xs text-slate-500">Requires Slack connection</p>
                    </div>
                    <Switch
                        checked={formData.notify_slack}
                        onCheckedChange={(checked) => setFormData({...formData, notify_slack: checked})}
                    />
                </div>

                {formData.notify_slack && (
                    <div>
                        <Label className="text-slate-400">Slack Channel</Label>
                        <Input
                            value={formData.slack_channel}
                            onChange={(e) => setFormData({...formData, slack_channel: e.target.value})}
                            placeholder="#scouting"
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                    </div>
                )}

                <div className="flex gap-3 pt-4">
                    <Button
                        onClick={() => onSubmit(formData)}
                        disabled={!formData.name}
                        className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                    >
                        {existingCriteria ? 'Update' : 'Create'} Alert
                    </Button>
                    <Button onClick={onCancel} variant="outline" className="border-slate-700 text-slate-400">
                        Cancel
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}