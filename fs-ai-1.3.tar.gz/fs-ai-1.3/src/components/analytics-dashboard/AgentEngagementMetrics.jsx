import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Mail } from 'lucide-react';

export default function AgentEngagementMetrics({ communications }) {
    const sentComms = communications.filter(c => 
        c.status === 'Sent' || c.status === 'Awaiting Response' || c.status === 'Responded'
    );
    
    const responseRate = sentComms.length > 0 
        ? Math.round((communications.filter(c => c.response_received).length / sentComms.length) * 100)
        : 0;

    const sentimentBreakdown = {
        'Very Positive': 0,
        'Positive': 0,
        'Neutral': 0,
        'Negative': 0,
        'Very Negative': 0
    };

    const interestBreakdown = {
        'Very High': 0,
        'High': 0,
        'Medium': 0,
        'Low': 0,
        'Very Low': 0
    };

    communications.forEach(comm => {
        if (comm.ai_sentiment_analysis) {
            sentimentBreakdown[comm.ai_sentiment_analysis.sentiment]++;
            interestBreakdown[comm.ai_sentiment_analysis.interest_level]++;
        }
    });

    const commTypeCounts = {};
    communications.forEach(comm => {
        commTypeCounts[comm.communication_type] = (commTypeCounts[comm.communication_type] || 0) + 1;
    });

    // Agent responsiveness
    const agentResponses = {};
    communications.forEach(comm => {
        if (comm.response_received) {
            const agent = comm.agent_email;
            if (!agentResponses[agent]) {
                agentResponses[agent] = { name: comm.agent_name, total: 0, positive: 0 };
            }
            agentResponses[agent].total++;
            if (comm.ai_sentiment_analysis?.sentiment === 'Very Positive' || 
                comm.ai_sentiment_analysis?.sentiment === 'Positive') {
                agentResponses[agent].positive++;
            }
        }
    });

    const topAgents = Object.entries(agentResponses)
        .map(([email, data]) => ({ email, ...data }))
        .sort((a, b) => b.total - a.total)
        .slice(0, 5);

    return (
        <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Response Rate</p>
                                <p className="text-3xl font-bold text-emerald-400">{responseRate}%</p>
                            </div>
                            <Mail className="w-10 h-10 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Total Sent</p>
                                <p className="text-3xl font-bold text-cyan-400">{sentComms.length}</p>
                            </div>
                            <TrendingUp className="w-10 h-10 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Positive Sentiment</p>
                                <p className="text-3xl font-bold text-amber-400">
                                    {sentimentBreakdown['Very Positive'] + sentimentBreakdown['Positive']}
                                </p>
                            </div>
                            <TrendingUp className="w-10 h-10 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Sentiment & Interest */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Sentiment Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(sentimentBreakdown).map(([sentiment, count]) => (
                                <div key={sentiment} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3 flex-1">
                                        <span className="text-slate-400 w-32">{sentiment}</span>
                                        <div className="flex-1 bg-slate-800 rounded-full h-3 overflow-hidden">
                                            <div 
                                                className={`h-full ${
                                                    sentiment.includes('Positive') ? 'bg-emerald-500' :
                                                    sentiment === 'Neutral' ? 'bg-slate-500' :
                                                    'bg-red-500'
                                                }`}
                                                style={{ 
                                                    width: `${Object.values(sentimentBreakdown).reduce((a, b) => a + b, 0) > 0 
                                                        ? (count / Object.values(sentimentBreakdown).reduce((a, b) => a + b, 0)) * 100 
                                                        : 0}%` 
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <span className="text-white font-semibold w-12 text-right">{count}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Interest Level</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(interestBreakdown).map(([level, count]) => (
                                <div key={level} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3 flex-1">
                                        <span className="text-slate-400 w-32">{level}</span>
                                        <div className="flex-1 bg-slate-800 rounded-full h-3 overflow-hidden">
                                            <div 
                                                className="h-full bg-gradient-to-r from-cyan-500 to-purple-500"
                                                style={{ 
                                                    width: `${Object.values(interestBreakdown).reduce((a, b) => a + b, 0) > 0 
                                                        ? (count / Object.values(interestBreakdown).reduce((a, b) => a + b, 0)) * 100 
                                                        : 0}%` 
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <span className="text-white font-semibold w-12 text-right">{count}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Communication Types */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Communication Types</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {Object.entries(commTypeCounts).map(([type, count]) => (
                            <div key={type} className="bg-slate-800/50 rounded-lg p-4 text-center">
                                <p className="text-2xl font-bold text-purple-400 mb-1">{count}</p>
                                <p className="text-slate-400 text-xs">{type}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Top Responsive Agents */}
            {topAgents.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Most Responsive Agents</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {topAgents.map((agent, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                                            <span className="text-purple-400 font-bold text-sm">{idx + 1}</span>
                                        </div>
                                        <div>
                                            <p className="text-white text-sm">{agent.name}</p>
                                            <p className="text-slate-500 text-xs">{agent.email}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            {agent.total} responses
                                        </Badge>
                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                            {agent.positive} positive
                                        </Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}