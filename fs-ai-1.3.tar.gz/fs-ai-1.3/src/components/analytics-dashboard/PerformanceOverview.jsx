import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, Clock, Users } from 'lucide-react';

export default function PerformanceOverview({ scoutingReports, tasks, communications, projections }) {
    // Calculate weekly activity
    const now = new Date();
    const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const reportsLastWeek = scoutingReports.filter(r => new Date(r.created_date) > lastWeek).length;
    const tasksLastWeek = tasks.filter(t => new Date(t.created_date) > lastWeek).length;
    const commsLastWeek = communications.filter(c => new Date(c.created_date) > lastWeek).length;

    const reportsLastMonth = scoutingReports.filter(r => new Date(r.created_date) > lastMonth).length;
    const tasksLastMonth = tasks.filter(t => new Date(t.created_date) > lastMonth).length;
    const commsLastMonth = communications.filter(c => new Date(c.created_date) > lastMonth).length;

    // Top performing scouts
    const scoutActivity = {};
    scoutingReports.forEach(report => {
        const scout = report.created_by;
        if (!scoutActivity[scout]) {
            scoutActivity[scout] = { reports: 0, highQuality: 0 };
        }
        scoutActivity[scout].reports++;
        if (report.recommendation === 'Immediate Signing') {
            scoutActivity[scout].highQuality++;
        }
    });

    const topScouts = Object.entries(scoutActivity)
        .map(([email, data]) => ({ email, ...data }))
        .sort((a, b) => b.reports - a.reports)
        .slice(0, 5);

    // Position coverage
    const positionCoverage = {};
    scoutingReports.forEach(report => {
        const pos = report.position || 'Unknown';
        positionCoverage[pos] = (positionCoverage[pos] || 0) + 1;
    });

    const topPositions = Object.entries(positionCoverage)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6);

    // Recent high-priority targets
    const priorityTargets = scoutingReports
        .filter(r => r.recommendation === 'Immediate Signing')
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        .slice(0, 8);

    return (
        <div className="space-y-6">
            {/* Activity Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-sm">Last 7 Days</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Reports</span>
                            <Badge className="bg-cyan-500/20 text-cyan-400">{reportsLastWeek}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Tasks</span>
                            <Badge className="bg-purple-500/20 text-purple-400">{tasksLastWeek}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Agent Contacts</span>
                            <Badge className="bg-emerald-500/20 text-emerald-400">{commsLastWeek}</Badge>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-sm">Last 30 Days</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Reports</span>
                            <Badge className="bg-cyan-500/20 text-cyan-400">{reportsLastMonth}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Tasks</span>
                            <Badge className="bg-purple-500/20 text-purple-400">{tasksLastMonth}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Agent Contacts</span>
                            <Badge className="bg-emerald-500/20 text-emerald-400">{commsLastMonth}</Badge>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-sm">Weekly Avg</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Reports</span>
                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                {Math.round((reportsLastMonth / 4) * 10) / 10}
                            </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Tasks</span>
                            <Badge className="bg-purple-500/20 text-purple-400">
                                {Math.round((tasksLastMonth / 4) * 10) / 10}
                            </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400 text-sm">Agent Contacts</span>
                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                {Math.round((commsLastMonth / 4) * 10) / 10}
                            </Badge>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Top Scouts & Position Coverage */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-5 h-5 text-purple-400" />
                            Top Scouts
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {topScouts.map((scout, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                                            <span className="text-purple-400 font-bold text-sm">{idx + 1}</span>
                                        </div>
                                        <div>
                                            <p className="text-white text-sm">{scout.email.split('@')[0]}</p>
                                            <p className="text-slate-500 text-xs">{scout.reports} reports</p>
                                        </div>
                                    </div>
                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                        {scout.highQuality} priority
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Position Coverage
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {topPositions.map(([position, count], idx) => (
                                <div key={idx} className="flex items-center gap-3">
                                    <span className="text-slate-400 text-sm w-32">{position}</span>
                                    <div className="flex-1 bg-slate-800 rounded-full h-2 overflow-hidden">
                                        <div 
                                            className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                                            style={{ width: `${(count / scoutingReports.length) * 100}%` }}
                                        />
                                    </div>
                                    <span className="text-white font-semibold text-sm w-8 text-right">{count}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Priority Targets */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                        Priority Signing Targets
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {priorityTargets.map((player, idx) => (
                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border border-emerald-500/30">
                                <h4 className="text-white font-semibold mb-2">{player.player_name}</h4>
                                <div className="space-y-1 text-xs text-slate-400">
                                    <p>{player.position} • {player.player_age}y</p>
                                    <p>{player.current_club}</p>
                                </div>
                                <div className="mt-3 flex items-center justify-between">
                                    <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                        Priority
                                    </Badge>
                                    <span className="text-slate-500 text-xs">
                                        {new Date(player.created_date).toLocaleDateString()}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}