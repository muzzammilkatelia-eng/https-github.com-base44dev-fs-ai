import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, CheckCircle } from 'lucide-react';

export default function PlayerPipelineChart({ scoutingReports, tasks, communications }) {
    // Calculate pipeline stages
    const identified = scoutingReports.length;
    const underAssessment = tasks.filter(t => 
        t.status === 'In Progress' || t.status === 'Pending'
    ).length;
    const contacted = communications.filter(c => c.status === 'Sent' || c.status === 'Awaiting Response').length;
    const negotiating = communications.filter(c => c.status === 'Negotiating' || c.status === 'Responded').length;
    const completed = communications.filter(c => c.status === 'Closed').length;

    const pipelineStages = [
        { label: 'Identified', count: identified, icon: Target, color: 'cyan' },
        { label: 'Under Assessment', count: underAssessment, icon: TrendingUp, color: 'purple' },
        { label: 'Agent Contacted', count: contacted, icon: TrendingUp, color: 'amber' },
        { label: 'Negotiating', count: negotiating, icon: TrendingUp, color: 'emerald' },
        { label: 'Completed', count: completed, icon: CheckCircle, color: 'green' }
    ];

    // Recent pipeline additions
    const recentReports = scoutingReports
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        .slice(0, 10);

    const conversionRate = identified > 0 ? Math.round((completed / identified) * 100) : 0;
    const activeNegotiations = negotiating;

    return (
        <div className="space-y-6">
            {/* Pipeline Overview */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Recruitment Pipeline</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {pipelineStages.map((stage, idx) => {
                            const Icon = stage.icon;
                            const percentage = identified > 0 ? (stage.count / identified) * 100 : 0;
                            
                            return (
                                <div key={idx}>
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-3">
                                            <Icon className={`w-5 h-5 text-${stage.color}-400`} />
                                            <span className="text-slate-400">{stage.label}</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <span className="text-slate-500 text-sm">{Math.round(percentage)}%</span>
                                            <Badge className={`bg-${stage.color}-500/20 text-${stage.color}-400`}>
                                                {stage.count}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div className="bg-slate-800 rounded-full h-3 overflow-hidden">
                                        <div 
                                            className={`h-full bg-${stage.color}-500`}
                                            style={{ width: `${percentage}%` }}
                                        />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </CardContent>
            </Card>

            {/* Pipeline Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm mb-2">Conversion Rate</p>
                            <p className="text-4xl font-bold text-emerald-400">{conversionRate}%</p>
                            <p className="text-slate-500 text-xs mt-2">
                                {completed} completed of {identified} identified
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm mb-2">Active Negotiations</p>
                            <p className="text-4xl font-bold text-amber-400">{activeNegotiations}</p>
                            <p className="text-slate-500 text-xs mt-2">Currently in negotiation</p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm mb-2">Drop-off Rate</p>
                            <p className="text-4xl font-bold text-red-400">{100 - conversionRate}%</p>
                            <p className="text-slate-500 text-xs mt-2">Players not completed</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Recent Pipeline Additions */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Recent Pipeline Additions</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {recentReports.map((player, idx) => (
                            <div key={idx} className="bg-slate-800/50 rounded-lg p-3 flex items-center justify-between">
                                <div>
                                    <p className="text-white font-semibold text-sm">{player.player_name}</p>
                                    <p className="text-slate-400 text-xs">{player.position} • {player.current_club}</p>
                                </div>
                                <Badge className={
                                    player.recommendation === 'Immediate Signing' ? 'bg-emerald-500/20 text-emerald-400' :
                                    player.recommendation === 'Monitor Closely' ? 'bg-cyan-500/20 text-cyan-400' :
                                    'bg-slate-500/20 text-slate-400'
                                }>
                                    {player.recommendation}
                                </Badge>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}