import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function RecommendationBreakdown({ scoutingReports }) {
    const recommendations = {
        'Immediate Signing': scoutingReports.filter(r => r.recommendation === 'Immediate Signing').length,
        'Monitor Closely': scoutingReports.filter(r => r.recommendation === 'Monitor Closely').length,
        'Pass': scoutingReports.filter(r => r.recommendation === 'Pass').length,
        'Potential Loan': scoutingReports.filter(r => r.recommendation === 'Potential Loan').length
    };

    const total = Object.values(recommendations).reduce((sum, val) => sum + val, 0);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white">Recommendation Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    {Object.entries(recommendations).map(([recommendation, count]) => {
                        const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
                        
                        return (
                            <div key={recommendation}>
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-slate-400">{recommendation}</span>
                                    <div className="flex items-center gap-3">
                                        <span className="text-slate-500 text-sm">{percentage}%</span>
                                        <span className="text-white font-semibold">{count}</span>
                                    </div>
                                </div>
                                <div className="bg-slate-800 rounded-full h-3 overflow-hidden">
                                    <div 
                                        className={`h-full ${
                                            recommendation === 'Immediate Signing' ? 'bg-emerald-500' :
                                            recommendation === 'Monitor Closely' ? 'bg-cyan-500' :
                                            recommendation === 'Potential Loan' ? 'bg-amber-500' :
                                            'bg-slate-500'
                                        }`}
                                        style={{ width: `${percentage}%` }}
                                    />
                                </div>
                            </div>
                        );
                    })}
                </div>

                <div className="mt-6 pt-6 border-t border-slate-700">
                    <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                            <p className="text-slate-400 text-xs mb-1">High Priority</p>
                            <p className="text-2xl font-bold text-emerald-400">{recommendations['Immediate Signing']}</p>
                        </div>
                        <div>
                            <p className="text-slate-400 text-xs mb-1">Monitoring</p>
                            <p className="text-2xl font-bold text-cyan-400">{recommendations['Monitor Closely']}</p>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}