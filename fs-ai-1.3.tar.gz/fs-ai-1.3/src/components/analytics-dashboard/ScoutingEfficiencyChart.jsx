import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function ScoutingEfficiencyChart({ scoutingReports }) {
    // Calculate average ratings by position
    const positionData = {};
    
    scoutingReports.forEach(report => {
        const pos = report.position || 'Unknown';
        if (!positionData[pos]) {
            positionData[pos] = {
                count: 0,
                technical: 0,
                physical: 0,
                tactical: 0,
                mental: 0
            };
        }
        
        positionData[pos].count++;
        positionData[pos].technical += report.technical_rating || 0;
        positionData[pos].physical += report.physical_rating || 0;
        positionData[pos].tactical += report.tactical_rating || 0;
        positionData[pos].mental += report.mental_rating || 0;
    });

    const positionAverages = Object.entries(positionData)
        .map(([position, data]) => ({
            position,
            count: data.count,
            avgTechnical: Math.round(data.technical / data.count),
            avgPhysical: Math.round(data.physical / data.count),
            avgTactical: Math.round(data.tactical / data.count),
            avgMental: Math.round(data.mental / data.count),
            avgOverall: Math.round((data.technical + data.physical + data.tactical + data.mental) / (data.count * 4))
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 8);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white">Average Player Ratings by Position</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {positionAverages.map((data, idx) => (
                        <div key={idx} className="space-y-2">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <span className="text-white font-semibold w-24">{data.position}</span>
                                    <Badge className="bg-slate-700 text-slate-300">{data.count} players</Badge>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-slate-400 text-sm">Overall:</span>
                                    <Badge className={
                                        data.avgOverall >= 80 ? 'bg-emerald-500/20 text-emerald-400' :
                                        data.avgOverall >= 70 ? 'bg-cyan-500/20 text-cyan-400' :
                                        data.avgOverall >= 60 ? 'bg-amber-500/20 text-amber-400' :
                                        'bg-slate-500/20 text-slate-400'
                                    }>
                                        {data.avgOverall}
                                    </Badge>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-4 gap-2">
                                <div>
                                    <p className="text-slate-500 text-xs mb-1">Technical</p>
                                    <div className="bg-slate-800 rounded h-2 overflow-hidden">
                                        <div 
                                            className="h-full bg-cyan-500"
                                            style={{ width: `${data.avgTechnical}%` }}
                                        />
                                    </div>
                                    <p className="text-cyan-400 text-xs mt-1">{data.avgTechnical}</p>
                                </div>
                                <div>
                                    <p className="text-slate-500 text-xs mb-1">Physical</p>
                                    <div className="bg-slate-800 rounded h-2 overflow-hidden">
                                        <div 
                                            className="h-full bg-purple-500"
                                            style={{ width: `${data.avgPhysical}%` }}
                                        />
                                    </div>
                                    <p className="text-purple-400 text-xs mt-1">{data.avgPhysical}</p>
                                </div>
                                <div>
                                    <p className="text-slate-500 text-xs mb-1">Tactical</p>
                                    <div className="bg-slate-800 rounded h-2 overflow-hidden">
                                        <div 
                                            className="h-full bg-amber-500"
                                            style={{ width: `${data.avgTactical}%` }}
                                        />
                                    </div>
                                    <p className="text-amber-400 text-xs mt-1">{data.avgTactical}</p>
                                </div>
                                <div>
                                    <p className="text-slate-500 text-xs mb-1">Mental</p>
                                    <div className="bg-slate-800 rounded h-2 overflow-hidden">
                                        <div 
                                            className="h-full bg-emerald-500"
                                            style={{ width: `${data.avgMental}%` }}
                                        />
                                    </div>
                                    <p className="text-emerald-400 text-xs mt-1">{data.avgMental}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}