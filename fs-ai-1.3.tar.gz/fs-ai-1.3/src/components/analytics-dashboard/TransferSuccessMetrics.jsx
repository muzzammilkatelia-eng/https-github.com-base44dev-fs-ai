import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, TrendingUp, AlertCircle } from 'lucide-react';

export default function TransferSuccessMetrics({ tasks }) {
    const statusCounts = {
        'Pending': tasks.filter(t => t.status === 'Pending').length,
        'In Progress': tasks.filter(t => t.status === 'In Progress').length,
        'Completed': tasks.filter(t => t.status === 'Completed').length,
        'Blocked': tasks.filter(t => t.status === 'Blocked').length
    };

    const priorityCounts = {
        'Critical': tasks.filter(t => t.priority === 'Critical').length,
        'High': tasks.filter(t => t.priority === 'High').length,
        'Medium': tasks.filter(t => t.priority === 'Medium').length,
        'Low': tasks.filter(t => t.priority === 'Low').length
    };

    const taskTypes = {};
    tasks.forEach(task => {
        taskTypes[task.task_type] = (taskTypes[task.task_type] || 0) + 1;
    });

    const sourceCounts = {
        'AI Flag': tasks.filter(t => t.source === 'AI Flag').length,
        'Manual': tasks.filter(t => t.source === 'Manual').length,
        'Globe Hotspot': tasks.filter(t => t.source === 'Globe Hotspot').length,
        'Scout Report': tasks.filter(t => t.source === 'Scout Report').length
    };

    // Calculate completion time for completed tasks
    const completedTasks = tasks.filter(t => t.status === 'Completed' && t.completed_date);
    const avgCompletionTime = completedTasks.length > 0 
        ? Math.round(completedTasks.reduce((sum, task) => {
            const created = new Date(task.created_date);
            const completed = new Date(task.completed_date);
            const days = (completed - created) / (1000 * 60 * 60 * 24);
            return sum + days;
        }, 0) / completedTasks.length)
        : 0;

    return (
        <div className="space-y-6">
            {/* Status Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Pending</p>
                                <p className="text-3xl font-bold text-amber-400">{statusCounts['Pending']}</p>
                            </div>
                            <Clock className="w-10 h-10 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">In Progress</p>
                                <p className="text-3xl font-bold text-cyan-400">{statusCounts['In Progress']}</p>
                            </div>
                            <TrendingUp className="w-10 h-10 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Completed</p>
                                <p className="text-3xl font-bold text-emerald-400">{statusCounts['Completed']}</p>
                            </div>
                            <CheckCircle className="w-10 h-10 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Avg Completion</p>
                                <p className="text-3xl font-bold text-purple-400">{avgCompletionTime}d</p>
                            </div>
                            <Clock className="w-10 h-10 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Detailed Breakdowns */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Priority Distribution */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Priority Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(priorityCounts).map(([priority, count]) => (
                                <div key={priority} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3 flex-1">
                                        <span className="text-slate-400 w-24">{priority}</span>
                                        <div className="flex-1 bg-slate-800 rounded-full h-3 overflow-hidden">
                                            <div 
                                                className={`h-full ${
                                                    priority === 'Critical' ? 'bg-red-500' :
                                                    priority === 'High' ? 'bg-orange-500' :
                                                    priority === 'Medium' ? 'bg-blue-500' :
                                                    'bg-slate-500'
                                                }`}
                                                style={{ width: `${tasks.length > 0 ? (count / tasks.length) * 100 : 0}%` }}
                                            />
                                        </div>
                                    </div>
                                    <span className="text-white font-semibold w-12 text-right">{count}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Task Source */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Task Source</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(sourceCounts).map(([source, count]) => (
                                <div key={source} className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <span className="text-slate-400">{source}</span>
                                    </div>
                                    <Badge className={
                                        source === 'AI Flag' ? 'bg-purple-500/20 text-purple-400' :
                                        'bg-slate-700 text-slate-300'
                                    }>
                                        {count}
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Task Type Breakdown */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Task Type Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                        {Object.entries(taskTypes).map(([type, count]) => (
                            <div key={type} className="bg-slate-800/50 rounded-lg p-4 text-center">
                                <p className="text-2xl font-bold text-cyan-400 mb-1">{count}</p>
                                <p className="text-slate-400 text-xs">{type}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}