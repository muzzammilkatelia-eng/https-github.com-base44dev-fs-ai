import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Shield, TrendingUp, Sparkles, Loader2 } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import toast from 'react-hot-toast';

export default function AIRiskAssessment({ players, reports, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [assessment, setAssessment] = useState(null);

    const assessMutation = useMutation({
        mutationFn: async (playerId) => {
            const player = players.find(p => p.id === playerId);
            const playerReports = reports.filter(r => r.player_name === player.name);
            const playerProjection = projections.find(p => p.player_name === player.name);

            const prompt = `Perform comprehensive risk and potential assessment for football player:

**Player Profile:**
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Club: ${player.current_club}
- Market Value: €${player.market_value}M
- Nationality: ${player.nationality}

**Historical Data:**
- Scouting Reports: ${playerReports.length}
- Career Progression: ${player.career_history?.length || 0} seasons tracked
- Injury History: ${player.injury_history?.length || 0} incidents
- Disciplinary Record: Available

**Analysis Required:**
1. Overall Risk Score (0-100)
2. Risk Breakdown by Category:
   - Injury Risk
   - Performance Consistency Risk
   - Market Value Volatility
   - Career Trajectory Risk
   - Disciplinary Risk
3. Potential Score (0-100)
4. Investment Grade (A+, A, B+, B, C+, C, D)
5. Key Risk Factors (top 3)
6. Mitigation Strategies
7. Upside Potential Analysis
8. Recommended Action (Strong Buy, Buy, Hold, Monitor, Pass)

Return structured JSON analysis.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_risk_score: { type: "number" },
                        potential_score: { type: "number" },
                        investment_grade: { type: "string" },
                        risk_breakdown: {
                            type: "object",
                            properties: {
                                injury_risk: { type: "number" },
                                performance_risk: { type: "number" },
                                market_volatility: { type: "number" },
                                career_trajectory_risk: { type: "number" },
                                disciplinary_risk: { type: "number" }
                            }
                        },
                        key_risk_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        mitigation_strategies: {
                            type: "array",
                            items: { type: "string" }
                        },
                        upside_potential: { type: "string" },
                        recommended_action: { type: "string" }
                    }
                }
            });

            return { player, ...response };
        },
        onSuccess: (data) => {
            setAssessment(data);
            toast.success('AI assessment complete!');
        },
        onError: () => {
            toast.error('Failed to generate assessment');
        }
    });

    const handleAssess = () => {
        if (selectedPlayer) {
            assessMutation.mutate(selectedPlayer);
        }
    };

    const riskData = assessment ? [
        { name: 'Injury', value: assessment.risk_breakdown.injury_risk, color: '#ef4444' },
        { name: 'Performance', value: assessment.risk_breakdown.performance_risk, color: '#f59e0b' },
        { name: 'Market', value: assessment.risk_breakdown.market_volatility, color: '#3b82f6' },
        { name: 'Career', value: assessment.risk_breakdown.career_trajectory_risk, color: '#8b5cf6' },
        { name: 'Discipline', value: assessment.risk_breakdown.disciplinary_risk, color: '#06b6d4' }
    ] : [];

    const getRiskLevel = (score) => {
        if (score < 30) return { label: 'Low Risk', color: 'bg-emerald-500/20 text-emerald-400' };
        if (score < 60) return { label: 'Medium Risk', color: 'bg-amber-500/20 text-amber-400' };
        return { label: 'High Risk', color: 'bg-red-500/20 text-red-400' };
    };

    const getGradeColor = (grade) => {
        if (grade.startsWith('A')) return 'from-emerald-500 to-green-600';
        if (grade.startsWith('B')) return 'from-blue-500 to-cyan-600';
        if (grade.startsWith('C')) return 'from-amber-500 to-orange-600';
        return 'from-red-500 to-pink-600';
    };

    return (
        <div className="space-y-6">
            {/* Player Selection */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI-Powered Risk & Potential Assessment
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="flex-1 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select player for assessment..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.slice(0, 100).map(player => (
                                    <SelectItem key={player.id} value={player.id}>
                                        {player.name} - {player.position} ({player.current_club})
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={handleAssess}
                            disabled={!selectedPlayer || assessMutation.isPending}
                            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500"
                        >
                            {assessMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Run AI Assessment
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {assessment ? (
                <>
                    {/* Overview Cards */}
                    <div className="grid md:grid-cols-4 gap-4">
                        <Card className={`bg-gradient-to-br ${getGradeColor(assessment.investment_grade)} border-0`}>
                            <CardContent className="pt-6">
                                <Shield className="w-8 h-8 text-white mb-3" />
                                <p className="text-white/80 text-sm">Investment Grade</p>
                                <p className="text-4xl font-bold text-white">{assessment.investment_grade}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <AlertTriangle className="w-8 h-8 text-amber-400 mb-3" />
                                <p className="text-slate-400 text-sm">Overall Risk</p>
                                <p className="text-3xl font-bold text-white">{assessment.overall_risk_score}</p>
                                <Badge className={getRiskLevel(assessment.overall_risk_score).color}>
                                    {getRiskLevel(assessment.overall_risk_score).label}
                                </Badge>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <TrendingUp className="w-8 h-8 text-emerald-400 mb-3" />
                                <p className="text-slate-400 text-sm">Potential Score</p>
                                <p className="text-3xl font-bold text-white">{assessment.potential_score}</p>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    High Potential
                                </Badge>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <p className="text-slate-400 text-sm mb-3">Recommended Action</p>
                                <p className="text-xl font-bold text-white">{assessment.recommended_action}</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Risk Breakdown */}
                    <div className="grid lg:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Risk Distribution</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <PieChart>
                                        <Pie
                                            data={riskData}
                                            cx="50%"
                                            cy="50%"
                                            labelLine={false}
                                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                            outerRadius={80}
                                            fill="#8884d8"
                                            dataKey="value"
                                        >
                                            {riskData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <Tooltip />
                                    </PieChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Risk Factors</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {assessment.key_risk_factors.map((factor, index) => (
                                    <div key={index} className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-start gap-3">
                                            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                            <p className="text-slate-300 text-sm">{factor}</p>
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Mitigation & Upside */}
                    <div className="grid lg:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Mitigation Strategies</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                {assessment.mitigation_strategies.map((strategy, index) => (
                                    <div key={index} className="flex items-start gap-3 bg-slate-800/50 rounded-lg p-3">
                                        <Shield className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                                        <p className="text-slate-300 text-sm">{strategy}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-white">Upside Potential</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 leading-relaxed">{assessment.upside_potential}</p>
                            </CardContent>
                        </Card>
                    </div>
                </>
            ) : (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-24 text-center">
                        <Sparkles className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 text-lg">Select a player and run AI assessment</p>
                        <p className="text-slate-500 text-sm mt-2">
                            Get comprehensive risk analysis and potential evaluation powered by AI
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}