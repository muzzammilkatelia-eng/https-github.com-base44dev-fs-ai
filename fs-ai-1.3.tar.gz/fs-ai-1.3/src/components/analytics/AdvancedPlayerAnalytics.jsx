import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Activity, AlertTriangle, Target, Loader2, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function AdvancedPlayerAnalytics({ playerName: initialPlayer, onAnalysisComplete }) {
    const [playerName, setPlayerName] = useState(initialPlayer || '');
    const [activeTab, setActiveTab] = useState('trends');
    const [trendAnalysis, setTrendAnalysis] = useState(null);
    const [injuryPrediction, setInjuryPrediction] = useState(null);
    const [clutchAnalysis, setClutchAnalysis] = useState(null);

    const analyzeTrendsMutation = useMutation({
        mutationFn: async (player) => {
            const prompt = `You are an elite football performance analytics AI. Analyze the performance trends for: ${player}

Provide comprehensive trend analysis covering:
1. **Performance Trajectory**: Monthly/seasonal performance ratings (0-100) over the past 12-18 months
2. **Form Analysis**: Current form state (Peak/Good/Average/Declining)
3. **Statistical Trends**: Goals, assists, key metrics progression
4. **Consistency Rating**: How consistent the player's performance has been
5. **Momentum Indicators**: Whether player is improving or declining
6. **Peak Performance Period**: When they perform best (time of season, conditions)
7. **Prediction**: Expected performance trajectory for next 6 months

Include specific data points and trend indicators.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        current_form: { type: "string" },
                        consistency_rating: { type: "number" },
                        momentum: { type: "string" },
                        performance_data: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    month: { type: "string" },
                                    rating: { type: "number" },
                                    key_stat: { type: "string" }
                                }
                            }
                        },
                        peak_period: { type: "string" },
                        trend_summary: { type: "string" },
                        six_month_prediction: { type: "string" },
                        key_insights: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setTrendAnalysis(data);
            toast.success('Trend analysis complete');
            if (onAnalysisComplete) onAnalysisComplete({ trends: data });
        }
    });

    const predictInjuryMutation = useMutation({
        mutationFn: async (player) => {
            const prompt = `You are an elite sports medicine and performance AI. Analyze injury risk for: ${player}

Provide comprehensive injury prediction analysis:
1. **Injury Risk Score** (0-100): Overall injury risk level
2. **Historical Injury Pattern**: Past injuries and recovery times
3. **Workload Analysis**: Current workload vs. safe thresholds
4. **Risk Factors**: 
   - Physical stress indicators
   - Age-related factors
   - Playing style risks
   - Position-specific vulnerabilities
5. **High-Risk Areas**: Body parts most at risk
6. **Preventive Recommendations**: Training adjustments, rest periods, load management
7. **Recovery Capacity**: How well player recovers from high-intensity periods
8. **Optimal Workload**: Safe minutes/games per week

Be specific and data-driven.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        injury_risk_score: { type: "number" },
                        risk_level: { type: "string" },
                        injury_history: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    injury_type: { type: "string" },
                                    date: { type: "string" },
                                    days_out: { type: "number" }
                                }
                            }
                        },
                        current_workload: { type: "string" },
                        risk_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        high_risk_areas: {
                            type: "array",
                            items: { type: "string" }
                        },
                        preventive_measures: {
                            type: "array",
                            items: { type: "string" }
                        },
                        optimal_workload: { type: "string" },
                        recovery_capacity: { type: "string" }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setInjuryPrediction(data);
            toast.success('Injury prediction complete');
            if (onAnalysisComplete) onAnalysisComplete({ injury: data });
        }
    });

    const analyzeClutchMutation = useMutation({
        mutationFn: async (player) => {
            const prompt = `You are an elite football psychology and performance AI. Analyze clutch performance for: ${player}

Provide comprehensive clutch performance analysis:
1. **Clutch Rating** (0-100): Overall clutch performance score
2. **Big Game Performance**: Stats in high-stakes matches (finals, derbies, decisive games)
3. **Pressure Situations**:
   - Performance when team is losing
   - Performance in final 15 minutes of close games
   - Penalty/free-kick conversion under pressure
   - Key moments delivery
4. **Mental Strength Indicators**:
   - Composure rating
   - Decision-making under pressure
   - Leadership in critical moments
5. **Clutch Moments**: Specific examples of decisive contributions
6. **Reliability Score**: Consistency in high-pressure situations
7. **Comparison to Peers**: How they rank among similar players

Include specific examples and statistics.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        clutch_rating: { type: "number" },
                        big_game_performance: { type: "string" },
                        pressure_stats: {
                            type: "object",
                            properties: {
                                when_losing: { type: "string" },
                                final_minutes: { type: "string" },
                                set_pieces: { type: "string" }
                            }
                        },
                        mental_strength: {
                            type: "object",
                            properties: {
                                composure: { type: "number" },
                                decision_making: { type: "number" },
                                leadership: { type: "number" }
                            }
                        },
                        clutch_moments: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    match: { type: "string" },
                                    moment: { type: "string" },
                                    impact: { type: "string" }
                                }
                            }
                        },
                        reliability_score: { type: "number" },
                        peer_comparison: { type: "string" }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setClutchAnalysis(data);
            toast.success('Clutch analysis complete');
            if (onAnalysisComplete) onAnalysisComplete({ clutch: data });
        }
    });

    const runFullAnalysis = () => {
        if (!playerName) return;
        analyzeTrendsMutation.mutate(playerName);
        predictInjuryMutation.mutate(playerName);
        analyzeClutchMutation.mutate(playerName);
    };

    const getRiskColor = (score) => {
        if (score >= 70) return 'bg-red-500/20 text-red-400 border-red-500/30';
        if (score >= 40) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-purple-400" />
                        Advanced Player Analytics
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        AI-driven performance trends, injury prediction, and clutch analysis
                    </p>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-3">
                        <div className="flex-1">
                            <Label className="text-slate-400">Player Name</Label>
                            <Input
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value)}
                                placeholder="e.g., Mohamed Salah"
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                        </div>
                        <div className="flex items-end">
                            <Button
                                onClick={runFullAnalysis}
                                disabled={!playerName || analyzeTrendsMutation.isPending}
                                className="bg-gradient-to-r from-purple-500 to-indigo-600"
                            >
                                {analyzeTrendsMutation.isPending ? (
                                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
                                ) : (
                                    <><Zap className="w-4 h-4 mr-2" />Run Full Analysis</>
                                )}
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {(trendAnalysis || injuryPrediction || clutchAnalysis) && (
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                        <TabsTrigger value="trends" className="data-[state=active]:bg-cyan-500/20">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Performance Trends
                        </TabsTrigger>
                        <TabsTrigger value="injury" className="data-[state=active]:bg-red-500/20">
                            <AlertTriangle className="w-4 h-4 mr-2" />
                            Injury Prediction
                        </TabsTrigger>
                        <TabsTrigger value="clutch" className="data-[state=active]:bg-amber-500/20">
                            <Target className="w-4 h-4 mr-2" />
                            Clutch Performance
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="trends">
                        {trendAnalysis && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">{trendAnalysis.player_name} - Performance Trends</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid grid-cols-3 gap-4">
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <p className="text-slate-400 text-sm mb-1">Current Form</p>
                                                <p className="text-white text-2xl font-bold">{trendAnalysis.current_form}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <p className="text-slate-400 text-sm mb-1">Consistency</p>
                                                <p className="text-cyan-400 text-2xl font-bold">{trendAnalysis.consistency_rating}/100</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <p className="text-slate-400 text-sm mb-1">Momentum</p>
                                                <Badge className={
                                                    trendAnalysis.momentum.includes('Up') || trendAnalysis.momentum.includes('Improving') ? 
                                                    'bg-emerald-500/20 text-emerald-400' : 
                                                    trendAnalysis.momentum.includes('Down') || trendAnalysis.momentum.includes('Declining') ?
                                                    'bg-red-500/20 text-red-400' :
                                                    'bg-blue-500/20 text-blue-400'
                                                }>
                                                    {trendAnalysis.momentum}
                                                </Badge>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-4">Performance Over Time</h4>
                                            <ResponsiveContainer width="100%" height={300}>
                                                <LineChart data={trendAnalysis.performance_data}>
                                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                                    <XAxis dataKey="month" stroke="#94a3b8" />
                                                    <YAxis stroke="#94a3b8" domain={[0, 100]} />
                                                    <Tooltip 
                                                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                                        labelStyle={{ color: '#e2e8f0' }}
                                                    />
                                                    <Line 
                                                        type="monotone" 
                                                        dataKey="rating" 
                                                        stroke="#06b6d4" 
                                                        strokeWidth={3}
                                                        dot={{ fill: '#06b6d4', r: 5 }}
                                                    />
                                                </LineChart>
                                            </ResponsiveContainer>
                                        </div>

                                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                                            <h4 className="text-blue-400 font-semibold mb-2">Peak Performance Period</h4>
                                            <p className="text-slate-300 text-sm">{trendAnalysis.peak_period}</p>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-2">Trend Summary</h4>
                                            <p className="text-slate-300 text-sm">{trendAnalysis.trend_summary}</p>
                                        </div>

                                        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                            <h4 className="text-purple-400 font-semibold mb-2">6-Month Prediction</h4>
                                            <p className="text-slate-300 text-sm">{trendAnalysis.six_month_prediction}</p>
                                        </div>

                                        {trendAnalysis.key_insights && (
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-cyan-400 font-semibold mb-2">Key Insights</h4>
                                                <ul className="space-y-1">
                                                    {trendAnalysis.key_insights.map((insight, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <Activity className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                                                            {insight}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </TabsContent>

                    <TabsContent value="injury">
                        {injuryPrediction && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">{injuryPrediction.player_name} - Injury Risk Analysis</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="flex items-center justify-center">
                                            <div className="relative">
                                                <div className="w-40 h-40 rounded-full bg-slate-800 flex items-center justify-center">
                                                    <div className="text-center">
                                                        <p className="text-4xl font-bold" style={{
                                                            color: injuryPrediction.injury_risk_score >= 70 ? '#ef4444' :
                                                                   injuryPrediction.injury_risk_score >= 40 ? '#f59e0b' : '#10b981'
                                                        }}>
                                                            {injuryPrediction.injury_risk_score}
                                                        </p>
                                                        <p className="text-slate-400 text-sm">Risk Score</p>
                                                    </div>
                                                </div>
                                                <Badge className={`${getRiskColor(injuryPrediction.injury_risk_score)} absolute -bottom-2 left-1/2 transform -translate-x-1/2`}>
                                                    {injuryPrediction.risk_level}
                                                </Badge>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-3">Current Workload</h4>
                                            <p className="text-slate-300 text-sm">{injuryPrediction.current_workload}</p>
                                        </div>

                                        {injuryPrediction.injury_history && injuryPrediction.injury_history.length > 0 && (
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-red-400 font-semibold mb-3">Injury History</h4>
                                                <div className="space-y-2">
                                                    {injuryPrediction.injury_history.map((injury, i) => (
                                                        <div key={i} className="flex justify-between items-center text-sm">
                                                            <span className="text-slate-300">{injury.injury_type}</span>
                                                            <div className="flex gap-3">
                                                                <span className="text-slate-500">{injury.date}</span>
                                                                <Badge className="bg-red-500/20 text-red-400">{injury.days_out} days</Badge>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                                            <h4 className="text-red-400 font-semibold mb-2">Risk Factors</h4>
                                            <div className="flex flex-wrap gap-2">
                                                {injuryPrediction.risk_factors.map((factor, i) => (
                                                    <Badge key={i} className="bg-red-500/20 text-red-400">
                                                        ⚠️ {factor}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                            <h4 className="text-amber-400 font-semibold mb-2">High-Risk Areas</h4>
                                            <div className="flex flex-wrap gap-2">
                                                {injuryPrediction.high_risk_areas.map((area, i) => (
                                                    <Badge key={i} className="bg-amber-500/20 text-amber-400">
                                                        {area}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                            <h4 className="text-emerald-400 font-semibold mb-2">Preventive Measures</h4>
                                            <ul className="space-y-1">
                                                {injuryPrediction.preventive_measures.map((measure, i) => (
                                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                        <span className="text-emerald-400 mt-1">✓</span>
                                                        {measure}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-cyan-400 font-semibold mb-2">Optimal Workload</h4>
                                                <p className="text-slate-300 text-sm">{injuryPrediction.optimal_workload}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-purple-400 font-semibold mb-2">Recovery Capacity</h4>
                                                <p className="text-slate-300 text-sm">{injuryPrediction.recovery_capacity}</p>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </TabsContent>

                    <TabsContent value="clutch">
                        {clutchAnalysis && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">{clutchAnalysis.player_name} - Clutch Performance</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="flex items-center justify-center">
                                            <div className="relative">
                                                <div className="w-40 h-40 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20 flex items-center justify-center border-4 border-amber-500/30">
                                                    <div className="text-center">
                                                        <p className="text-4xl font-bold text-amber-400">{clutchAnalysis.clutch_rating}</p>
                                                        <p className="text-slate-400 text-sm">Clutch Rating</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-lg p-4">
                                            <h4 className="text-amber-400 font-semibold mb-2">Big Game Performance</h4>
                                            <p className="text-slate-300 text-sm">{clutchAnalysis.big_game_performance}</p>
                                        </div>

                                        <div className="grid grid-cols-3 gap-4">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-2">Composure</p>
                                                <div className="flex items-center gap-2">
                                                    <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                                                        <div 
                                                            className="h-full bg-gradient-to-r from-emerald-500 to-green-500"
                                                            style={{width: `${clutchAnalysis.mental_strength.composure}%`}}
                                                        />
                                                    </div>
                                                    <span className="text-emerald-400 text-sm font-semibold">{clutchAnalysis.mental_strength.composure}</span>
                                                </div>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-2">Decision Making</p>
                                                <div className="flex items-center gap-2">
                                                    <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                                                        <div 
                                                            className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                                                            style={{width: `${clutchAnalysis.mental_strength.decision_making}%`}}
                                                        />
                                                    </div>
                                                    <span className="text-cyan-400 text-sm font-semibold">{clutchAnalysis.mental_strength.decision_making}</span>
                                                </div>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-2">Leadership</p>
                                                <div className="flex items-center gap-2">
                                                    <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                                                        <div 
                                                            className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                                                            style={{width: `${clutchAnalysis.mental_strength.leadership}%`}}
                                                        />
                                                    </div>
                                                    <span className="text-purple-400 text-sm font-semibold">{clutchAnalysis.mental_strength.leadership}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-3">Pressure Situations</h4>
                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">When Team is Losing</p>
                                                    <p className="text-slate-300 text-sm">{clutchAnalysis.pressure_stats.when_losing}</p>
                                                </div>
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Final 15 Minutes</p>
                                                    <p className="text-slate-300 text-sm">{clutchAnalysis.pressure_stats.final_minutes}</p>
                                                </div>
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Set Pieces Under Pressure</p>
                                                    <p className="text-slate-300 text-sm">{clutchAnalysis.pressure_stats.set_pieces}</p>
                                                </div>
                                            </div>
                                        </div>

                                        {clutchAnalysis.clutch_moments && clutchAnalysis.clutch_moments.length > 0 && (
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-amber-400 font-semibold mb-3">Iconic Clutch Moments</h4>
                                                <div className="space-y-3">
                                                    {clutchAnalysis.clutch_moments.map((moment, i) => (
                                                        <div key={i} className="bg-slate-900/50 rounded-lg p-3">
                                                            <div className="flex justify-between items-start mb-2">
                                                                <h5 className="text-white font-semibold text-sm">{moment.match}</h5>
                                                                <Badge className="bg-amber-500/20 text-amber-400 text-xs">
                                                                    {moment.impact}
                                                                </Badge>
                                                            </div>
                                                            <p className="text-slate-300 text-sm">{moment.moment}</p>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                                <h4 className="text-emerald-400 font-semibold mb-2">Reliability Score</h4>
                                                <p className="text-white text-3xl font-bold">{clutchAnalysis.reliability_score}/100</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-cyan-400 font-semibold mb-2">Peer Comparison</h4>
                                                <p className="text-slate-300 text-sm">{clutchAnalysis.peer_comparison}</p>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </TabsContent>
                </Tabs>
            )}
        </div>
    );
}