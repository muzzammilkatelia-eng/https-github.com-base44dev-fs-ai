import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, TrendingUp, AlertTriangle, Sparkles, CheckCircle2, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AutomatedAlertSystem({ players, projections, reports, alerts }) {
    const [scanning, setScanning] = useState(false);
    const queryClient = useQueryClient();

    const markAsReadMutation = useMutation({
        mutationFn: (alertId) => base44.entities.Alert.update(alertId, { read: true }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alerts'] });
        }
    });

    const scanForAlerts = async () => {
        setScanning(true);
        toast.loading('Scanning for market shifts and milestones...', { id: 'scan' });

        try {
            // Market value shifts
            const valueAlerts = [];
            players.forEach(player => {
                const playerProjection = projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase());
                if (playerProjection && player.market_value) {
                    const expectedValue = playerProjection.peak_potential_rating * 10; // Rough estimate
                    const currentValue = player.market_value;
                    const deviation = Math.abs(expectedValue - currentValue) / expectedValue;
                    
                    if (deviation > 0.3) { // 30% deviation threshold
                        valueAlerts.push({
                            player_name: player.name,
                            alert_type: 'market_shift',
                            message: `${player.name}: Market value ${currentValue < expectedValue ? 'undervalued' : 'overvalued'} by ${Math.round(deviation * 100)}%`,
                            severity: deviation > 0.5 ? 'High' : 'Medium',
                            data: {
                                current_value: currentValue,
                                expected_value: expectedValue,
                                deviation_percent: Math.round(deviation * 100)
                            }
                        });
                    }
                }
            });

            // Development milestones
            const milestoneAlerts = [];
            reports.forEach(report => {
                if (report.overall_rating >= 8.5 && !alerts.some(a => 
                    a.player_name === report.player_name && a.alert_type === 'milestone' && a.read === false
                )) {
                    milestoneAlerts.push({
                        player_name: report.player_name,
                        alert_type: 'milestone',
                        message: `${report.player_name} reached exceptional rating of ${report.overall_rating}/10`,
                        severity: 'High',
                        data: {
                            rating: report.overall_rating,
                            report_date: report.created_date
                        }
                    });
                }
            });

            // Trajectory alerts
            const trajectoryAlerts = [];
            projections.forEach(projection => {
                if (projection.potential_trajectory === 'Elite Tier Prospect' && 
                    !alerts.some(a => a.player_name === projection.player_name && a.alert_type === 'trajectory')) {
                    trajectoryAlerts.push({
                        player_name: projection.player_name,
                        alert_type: 'trajectory',
                        message: `${projection.player_name} projected as Elite Tier Prospect - peak ${projection.peak_potential_rating}/10 in ${projection.years_to_peak}y`,
                        severity: 'Critical',
                        data: {
                            trajectory: projection.potential_trajectory,
                            peak_rating: projection.peak_potential_rating,
                            years_to_peak: projection.years_to_peak
                        }
                    });
                }
            });

            // Create alerts
            const allNewAlerts = [...valueAlerts, ...milestoneAlerts, ...trajectoryAlerts];
            
            for (const alert of allNewAlerts) {
                await base44.entities.Alert.create(alert);
            }

            queryClient.invalidateQueries({ queryKey: ['alerts'] });
            toast.success(`Generated ${allNewAlerts.length} new alerts!`, { id: 'scan' });
        } catch (error) {
            console.error('Alert scan failed:', error);
            toast.error('Failed to scan for alerts', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    const unreadAlerts = alerts.filter(a => !a.read);
    const marketShiftAlerts = alerts.filter(a => a.alert_type === 'market_shift');
    const milestoneAlerts = alerts.filter(a => a.alert_type === 'milestone');
    const trajectoryAlerts = alerts.filter(a => a.alert_type === 'trajectory');

    const getSeverityColor = (severity) => {
        switch (severity) {
            case 'Critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
            case 'High': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
            case 'Medium': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
            default: return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        }
    };

    return (
        <div className="space-y-6">
            {/* Alert Summary */}
            <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-red-500/10 to-red-600/10 border-red-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Unread Alerts</p>
                                <p className="text-4xl font-bold text-white">{unreadAlerts.length}</p>
                            </div>
                            <Bell className="w-8 h-8 text-red-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Market Shifts</p>
                                <p className="text-4xl font-bold text-white">{marketShiftAlerts.length}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Milestones</p>
                                <p className="text-4xl font-bold text-white">{milestoneAlerts.length}</p>
                            </div>
                            <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Elite Prospects</p>
                                <p className="text-4xl font-bold text-white">{trajectoryAlerts.length}</p>
                            </div>
                            <Sparkles className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Scan Button */}
            <Card className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-cyan-500/30">
                <CardContent className="py-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-white font-semibold mb-1">Automated Alert Scanner</h3>
                            <p className="text-slate-400 text-sm">
                                Scan {players.length} players for market value shifts, development milestones, and trajectory changes
                            </p>
                        </div>
                        <Button
                            onClick={scanForAlerts}
                            disabled={scanning}
                            className="bg-gradient-to-r from-cyan-500 to-purple-600"
                        >
                            {scanning ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Scanning...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Scan for Alerts
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Alerts List */}
            {alerts.length > 0 ? (
                <div className="space-y-3">
                    {alerts.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).map(alert => (
                        <motion.div
                            key={alert.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                        >
                            <Card className={`bg-slate-900/50 border-slate-800 ${!alert.read ? 'border-l-4 border-l-cyan-500' : ''}`}>
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                {alert.alert_type === 'market_shift' && <TrendingUp className="w-5 h-5 text-amber-400" />}
                                                {alert.alert_type === 'milestone' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                                                {alert.alert_type === 'trajectory' && <Sparkles className="w-5 h-5 text-purple-400" />}
                                                <h4 className="text-white font-semibold">{alert.player_name}</h4>
                                                <Badge className={getSeverityColor(alert.severity)}>
                                                    {alert.severity}
                                                </Badge>
                                                {!alert.read && (
                                                    <Badge className="bg-cyan-500/20 text-cyan-400">New</Badge>
                                                )}
                                            </div>
                                            <p className="text-slate-300 mb-2">{alert.message}</p>
                                            <p className="text-slate-500 text-xs">
                                                {new Date(alert.created_date).toLocaleString()}
                                            </p>
                                        </div>
                                        {!alert.read && (
                                            <Button
                                                onClick={() => markAsReadMutation.mutate(alert.id)}
                                                size="sm"
                                                variant="outline"
                                            >
                                                Mark Read
                                            </Button>
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            ) : (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16 text-center">
                        <AlertTriangle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No alerts yet. Click "Scan for Alerts" to generate insights.</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}