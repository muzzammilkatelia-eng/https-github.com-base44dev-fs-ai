import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, DollarSign, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ClientRoster({ commissions }) {
    const activeClients = commissions.filter(c => c.player_active);
    
    const calculatePotentialEarnings = (commission) => {
        // Estimate future earnings based on player trajectory
        const avgTransferFee = commission.initial_valuation * 2; // Conservative estimate
        const futureTransfers = 2; // Assume 2 more transfers in career
        const potentialTransferCommissions = (avgTransferFee * futureTransfers * commission.transfer_commission_rate) / 100;
        const gbpConversion = potentialTransferCommissions * 1000000 / 1.27;
        return commission.total_commission_earned + gbpConversion;
    };

    const sortedClients = activeClients
        .map(c => ({
            ...c,
            potentialEarnings: calculatePotentialEarnings(c)
        }))
        .sort((a, b) => b.potentialEarnings - a.potentialEarnings);

    const totalPotential = sortedClients.reduce((sum, c) => sum + c.potentialEarnings, 0);
    const totalEarned = sortedClients.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Active Clients</p>
                                <p className="text-3xl font-bold text-cyan-400">{activeClients.length}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Earned to Date</p>
                                <p className="text-3xl font-bold text-emerald-400">£{totalEarned.toLocaleString()}</p>
                            </div>
                            <DollarSign className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Projected Total</p>
                                <p className="text-3xl font-bold text-purple-400">£{totalPotential.toFixed(0).toLocaleString()}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Client Portfolio</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {sortedClients.map((client, idx) => {
                            const progressPercent = (client.total_commission_earned / client.potentialEarnings) * 100;
                            const careerStage = new Date().getFullYear() - new Date(client.signing_date).getFullYear();
                            
                            return (
                                <motion.div
                                    key={client.id}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className="bg-slate-800/50 rounded-lg p-4"
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <h4 className="text-white font-bold text-lg">{client.player_name}</h4>
                                            <div className="flex items-center gap-2 mt-1">
                                                <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                    Year {careerStage}
                                                </Badge>
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    €{client.initial_valuation}M signing
                                                </Badge>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-emerald-400 font-bold text-lg">
                                                £{client.total_commission_earned?.toLocaleString()}
                                            </p>
                                            <p className="text-slate-500 text-xs">earned</p>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center text-sm">
                                            <span className="text-slate-400">Career Earnings Progress</span>
                                            <span className="text-purple-400 font-semibold">
                                                £{client.potentialEarnings.toFixed(0).toLocaleString()} projected
                                            </span>
                                        </div>
                                        <Progress value={progressPercent} className="h-2" />
                                        <p className="text-slate-500 text-xs">{progressPercent.toFixed(0)}% of estimated career value</p>
                                    </div>

                                    {client.career_transfers && client.career_transfers.length > 0 && (
                                        <div className="mt-3 pt-3 border-t border-slate-700">
                                            <p className="text-slate-400 text-xs mb-2">Career Transfers:</p>
                                            {client.career_transfers.map((transfer, tidx) => (
                                                <div key={tidx} className="text-xs text-slate-500 mb-1">
                                                    {transfer.from_club} → {transfer.to_club} (€{transfer.transfer_fee}M)
                                                    <span className="text-emerald-400 ml-2">+£{transfer.commission_earned?.toLocaleString()}</span>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </motion.div>
                            );
                        })}

                        {sortedClients.length === 0 && (
                            <div className="text-center py-12">
                                <p className="text-slate-400">No active clients yet</p>
                                <p className="text-slate-500 text-sm mt-2">Register player signings to track your roster</p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}