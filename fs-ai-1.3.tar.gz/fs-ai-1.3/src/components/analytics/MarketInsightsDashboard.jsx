import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, TrendingDown, DollarSign, Sparkles } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function MarketInsightsDashboard({ players, projections }) {
    const [insights, setInsights] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const generateInsights = async () => {
        setAnalyzing(true);
        toast.loading('Analyzing market trends...', { id: 'insights' });

        try {
            const prompt = `You are an AI market analyst for football transfers. Analyze current market trends and provide strategic insights.

DATABASE OVERVIEW:
- Total Players: ${players.length}
- With Projections: ${projections.length}
- Avg Market Value: €${(players.reduce((sum, p) => sum + (p.market_value || 0), 0) / players.length).toFixed(1)}M

PLAYER BREAKDOWN BY AGE:
${Object.entries(players.reduce((acc, p) => {
    const ageGroup = p.age < 21 ? 'U21' : p.age < 24 ? '21-23' : p.age < 27 ? '24-26' : p.age < 30 ? '27-29' : '30+';
    acc[ageGroup] = (acc[ageGroup] || 0) + 1;
    return acc;
}, {})).map(([age, count]) => `- ${age}: ${count} players`).join('\n')}

PROJECTION TRAJECTORIES:
${Object.entries(projections.reduce((acc, p) => {
    acc[p.potential_trajectory] = (acc[p.potential_trajectory] || 0) + 1;
    return acc;
}, {})).map(([traj, count]) => `- ${traj}: ${count} players`).join('\n')}

TOP VALUE PLAYERS:
${players.sort((a, b) => (b.market_value || 0) - (a.market_value || 0)).slice(0, 10).map(p => 
    `- ${p.name}: €${p.market_value}M (${p.age}y, ${p.position})`
).join('\n')}

Provide comprehensive market intelligence:

1. **Market Trends**: Key patterns in player values and trajectories
2. **Opportunity Windows**: Best times to buy/sell in the next 12 months
3. **Position Analysis**: Which positions offer best value/potential
4. **Age Bracket Insights**: Optimal age groups for investment
5. **Risk Assessment**: Market volatility and stability indicators
6. **Hidden Value**: Undervalued segments to target
7. **Price Predictions**: Expected market movements (%, direction)`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        market_trends: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    trend: { type: "string" },
                                    impact: { type: "string" },
                                    confidence: { type: "number" }
                                }
                            }
                        },
                        opportunity_windows: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    period: { type: "string" },
                                    action: { type: "string" },
                                    rationale: { type: "string" }
                                }
                            }
                        },
                        position_analysis: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    value_rating: { type: "number" },
                                    potential_rating: { type: "number" },
                                    recommendation: { type: "string" }
                                }
                            }
                        },
                        age_bracket_insights: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age_group: { type: "string" },
                                    investment_score: { type: "number" },
                                    notes: { type: "string" }
                                }
                            }
                        },
                        risk_level: { type: "string" },
                        hidden_value_sectors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        price_predictions: {
                            type: "object",
                            properties: {
                                overall_direction: { type: "string" },
                                expected_change_percent: { type: "number" },
                                timeline: { type: "string" }
                            }
                        },
                        executive_summary: { type: "string" }
                    }
                }
            });

            setInsights(response);
            toast.success('Market analysis complete!', { id: 'insights' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze market', { id: 'insights' });
        } finally {
            setAnalyzing(false);
        }
    };

    const COLORS = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    return (
        <div className="space-y-6">
            {!insights ? (
                <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <TrendingUp className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                            <h3 className="text-white text-xl font-semibold mb-2">Market Intelligence Engine</h3>
                            <p className="text-slate-400 mb-6">
                                Generate AI-powered market insights and transfer trend analysis
                            </p>
                            <Button
                                onClick={generateInsights}
                                disabled={analyzing}
                                className="bg-gradient-to-r from-purple-500 to-cyan-600"
                            >
                                {analyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Generate Market Insights
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            ) : (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Executive Summary */}
                    <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">Market Intelligence Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{insights.executive_summary}</p>
                        </CardContent>
                    </Card>

                    {/* Price Predictions */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-emerald-400" />
                                Market Price Predictions
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-6">
                                <div className="flex-1 bg-slate-800/50 rounded-lg p-6">
                                    <p className="text-slate-400 text-sm mb-2">Overall Direction</p>
                                    <div className="flex items-center gap-3">
                                        {insights.price_predictions?.overall_direction?.toLowerCase().includes('up') ? (
                                            <TrendingUp className="w-8 h-8 text-emerald-400" />
                                        ) : (
                                            <TrendingDown className="w-8 h-8 text-red-400" />
                                        )}
                                        <p className="text-white text-2xl font-bold">{insights.price_predictions?.overall_direction}</p>
                                    </div>
                                </div>
                                <div className="flex-1 bg-slate-800/50 rounded-lg p-6">
                                    <p className="text-slate-400 text-sm mb-2">Expected Change</p>
                                    <p className={`text-4xl font-bold ${
                                        insights.price_predictions?.expected_change_percent > 0 ? 'text-emerald-400' : 'text-red-400'
                                    }`}>
                                        {insights.price_predictions?.expected_change_percent > 0 ? '+' : ''}
                                        {insights.price_predictions?.expected_change_percent}%
                                    </p>
                                </div>
                                <div className="flex-1 bg-slate-800/50 rounded-lg p-6">
                                    <p className="text-slate-400 text-sm mb-2">Timeline</p>
                                    <p className="text-white text-xl font-semibold">{insights.price_predictions?.timeline}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Market Trends */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Key Market Trends</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {insights.market_trends?.map((trend, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-2">
                                            <h5 className="text-white font-semibold">{trend.trend}</h5>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                                {trend.confidence}% confident
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{trend.impact}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Position Analysis Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Position Value Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={insights.position_analysis}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="position" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #475569',
                                            borderRadius: '8px'
                                        }}
                                    />
                                    <Legend />
                                    <Bar dataKey="value_rating" name="Value Rating" fill="#06b6d4" />
                                    <Bar dataKey="potential_rating" name="Potential Rating" fill="#8b5cf6" />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Opportunity Windows */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Strategic Opportunity Windows</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {insights.opportunity_windows?.map((window, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <div className="flex items-center gap-3 mb-2">
                                            <Badge className="bg-emerald-500/20 text-emerald-400">{window.period}</Badge>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">{window.action}</Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{window.rationale}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Age Bracket Insights */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Age Bracket Investment Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {insights.age_bracket_insights?.map((age, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <h5 className="text-white font-semibold">{age.age_group}</h5>
                                            <div className="text-right">
                                                <p className="text-2xl font-bold text-purple-400">{age.investment_score}</p>
                                                <p className="text-slate-400 text-xs">Score</p>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{age.notes}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Hidden Value Sectors */}
                    <Card className="bg-amber-500/10 border-amber-500/30">
                        <CardHeader>
                            <CardTitle className="text-amber-400">Hidden Value Opportunities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-wrap gap-3">
                                {insights.hidden_value_sectors?.map((sector, idx) => (
                                    <Badge key={idx} className="bg-amber-500/20 text-amber-400 text-sm px-4 py-2">
                                        {sector}
                                    </Badge>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Button onClick={() => setInsights(null)} variant="outline" className="w-full">
                        Generate New Analysis
                    </Button>
                </motion.div>
            )}
        </div>
    );
}