import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, TrendingUp, AlertCircle, Loader2, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import TransferSimulator from './TransferSimulator';

export default function MarketPredictions({ projections, reports }) {
    const [predictions, setPredictions] = useState(null);

    const generatePredictionsMutation = useMutation({
        mutationFn: async () => {
            const prompt = `You are an elite football market analyst with access to comprehensive scouting data. Analyze current market trends and provide detailed predictions:

AVAILABLE DATA:
- ${projections.length} player projections with potential ratings and trajectories
- ${reports.length} scouting reports with recommendations
- Current date: December 2025

Generate comprehensive market predictions including:

1. **Rising Markets** (3-4 regions/leagues):
   - Region/league name
   - Growth potential % (0-100)
   - Key factors driving growth
   - Recommended investment window

2. **Undervalued Positions** (3-4 positions):
   - Position name
   - Current avg market value (€M)
   - Predicted value in 12 months (€M)
   - Value increase %
   - Why undervalued

3. **Transfer Value Predictions** (4-5 specific predictions):
   - Player archetype (e.g., "Brazilian Winger, 19y")
   - Current estimated value (€M)
   - Predicted value in 12 months (€M)
   - Confidence level (High/Medium/Low)
   - Key factors

4. **Market Risks** (3-4 risk factors):
   - Risk name
   - Impact level (High/Medium/Low)
   - Affected segments
   - Mitigation strategy

5. **Investment Opportunities** (Top 3):
   - Opportunity description
   - ROI potential %
   - Timeline
   - Action required

Base predictions on realistic football market dynamics, transfer trends, and player development patterns.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        rising_markets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    region: { type: "string" },
                                    growth_potential: { type: "number" },
                                    factors: { type: "string" },
                                    investment_window: { type: "string" }
                                }
                            }
                        },
                        undervalued_positions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    current_value: { type: "number" },
                                    predicted_value: { type: "number" },
                                    increase_percent: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        transfer_predictions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    archetype: { type: "string" },
                                    current_value: { type: "number" },
                                    predicted_value: { type: "number" },
                                    confidence: { type: "string" },
                                    factors: { type: "string" }
                                }
                            }
                        },
                        market_risks: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    risk: { type: "string" },
                                    impact: { type: "string" },
                                    affected_segments: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        investment_opportunities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    description: { type: "string" },
                                    roi_potential: { type: "number" },
                                    timeline: { type: "string" },
                                    action: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setPredictions(data);
            toast.success('Market predictions generated');
        },
        onError: () => {
            toast.error('Failed to generate predictions');
        }
    });

    const getConfidenceColor = (confidence) => {
        const colors = {
            'High': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[confidence] || '';
    };

    const getImpactColor = (impact) => {
        const colors = {
            'High': 'bg-red-500/20 text-red-400 border-red-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[impact] || '';
    };

    return (
        <Tabs defaultValue="predictions">
            <TabsList className="grid w-full grid-cols-2 bg-slate-800 mb-6">
                <TabsTrigger value="predictions" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                    <Brain className="w-4 h-4 mr-2" />
                    Market Predictions
                </TabsTrigger>
                <TabsTrigger value="simulator" className="data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
                    <Zap className="w-4 h-4 mr-2" />
                    Transfer Simulator
                </TabsTrigger>
            </TabsList>

            <TabsContent value="predictions">
            {!predictions ? (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12">
                        <div className="text-center">
                            <Brain className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                            <h3 className="text-xl font-bold text-white mb-2">AI Market Intelligence</h3>
                            <p className="text-slate-400 mb-6">
                                Generate AI-powered predictions based on {projections.length} projections and {reports.length} scout reports
                            </p>
                            <Button
                                onClick={() => generatePredictionsMutation.mutate()}
                                disabled={generatePredictionsMutation.isPending}
                                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500"
                            >
                                {generatePredictionsMutation.isPending ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Brain className="w-4 h-4 mr-2" />
                                        Generate Predictions
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            ) : (
                <AnimatePresence>
                    <div className="space-y-6">
                        {/* Rising Markets */}
                        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-2">
                                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                                        Rising Markets
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {predictions.rising_markets?.map((market, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="text-white font-semibold">{market.region}</h4>
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        +{market.growth_potential}%
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm mb-2">{market.factors}</p>
                                                <p className="text-slate-500 text-xs">Window: {market.investment_window}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>

                        {/* Transfer Predictions */}
                        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Transfer Value Predictions</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {predictions.transfer_predictions?.map((pred, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="text-white font-semibold">{pred.archetype}</h4>
                                                    <Badge className={getConfidenceColor(pred.confidence)}>
                                                        {pred.confidence}
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center gap-4 mb-2">
                                                    <div>
                                                        <p className="text-slate-500 text-xs">Current</p>
                                                        <p className="text-white font-semibold">€{pred.current_value}M</p>
                                                    </div>
                                                    <span className="text-slate-600">→</span>
                                                    <div>
                                                        <p className="text-slate-500 text-xs">12 Months</p>
                                                        <p className="text-emerald-400 font-semibold">€{pred.predicted_value}M</p>
                                                    </div>
                                                    <Badge className="bg-purple-500/20 text-purple-400 ml-auto">
                                                        +{((pred.predicted_value - pred.current_value) / pred.current_value * 100).toFixed(0)}%
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">{pred.factors}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>

                        {/* Investment Opportunities & Risks */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white flex items-center gap-2">
                                            <TrendingUp className="w-5 h-5 text-cyan-400" />
                                            Investment Opportunities
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {predictions.investment_opportunities?.map((opp, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                    <div className="flex justify-between items-start mb-1">
                                                        <h5 className="text-white text-sm font-semibold">{opp.description}</h5>
                                                        <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                            {opp.roi_potential}% ROI
                                                        </Badge>
                                                    </div>
                                                    <p className="text-slate-400 text-xs mb-1">Timeline: {opp.timeline}</p>
                                                    <p className="text-slate-500 text-xs">{opp.action}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>

                            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white flex items-center gap-2">
                                            <AlertCircle className="w-5 h-5 text-red-400" />
                                            Market Risks
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {predictions.market_risks?.map((risk, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                    <div className="flex justify-between items-start mb-1">
                                                        <h5 className="text-white text-sm font-semibold">{risk.risk}</h5>
                                                        <Badge className={getImpactColor(risk.impact)}>
                                                            {risk.impact}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-slate-400 text-xs mb-1">Affects: {risk.affected_segments}</p>
                                                    <p className="text-slate-500 text-xs">{risk.mitigation}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        </div>

                        <div className="flex justify-end">
                            <Button
                                onClick={() => generatePredictionsMutation.mutate()}
                                disabled={generatePredictionsMutation.isPending}
                                className="bg-slate-800 hover:bg-slate-700"
                            >
                                <Brain className="w-4 h-4 mr-2" />
                                Regenerate Predictions
                            </Button>
                        </div>
                    </div>
                </AnimatePresence>
            )}
            </TabsContent>

            <TabsContent value="simulator">
                <TransferSimulator projections={projections} />
            </TabsContent>
        </Tabs>
    );
}