import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, DollarSign, Users, Target } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PerformanceMetrics({ commissions, timeRange }) {
    const totalEarnings = commissions.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);
    const activeClients = commissions.filter(c => c.player_active).length;
    const avgCommissionPerClient = activeClients > 0 ? totalEarnings / activeClients : 0;
    
    // Calculate growth based on time range
    const now = new Date();
    const getStartDate = () => {
        if (timeRange === 'weekly') return new Date(now - 7 * 24 * 60 * 60 * 1000);
        if (timeRange === 'monthly') return new Date(now - 30 * 24 * 60 * 60 * 1000);
        return new Date(now - 365 * 24 * 60 * 60 * 1000);
    };
    
    const startDate = getStartDate();
    const recentEarnings = commissions
        .filter(c => new Date(c.signing_date) >= startDate)
        .reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);
    
    const growthRate = totalEarnings > 0 ? ((recentEarnings / totalEarnings) * 100).toFixed(1) : 0;

    const metrics = [
        {
            label: 'Total Earnings',
            value: `£${totalEarnings.toLocaleString()}`,
            icon: DollarSign,
            color: 'text-emerald-400',
            bgColor: 'from-emerald-500/10 to-emerald-500/5',
            borderColor: 'border-emerald-500/30'
        },
        {
            label: 'Active Clients',
            value: activeClients,
            icon: Users,
            color: 'text-cyan-400',
            bgColor: 'from-cyan-500/10 to-cyan-500/5',
            borderColor: 'border-cyan-500/30'
        },
        {
            label: 'Avg per Client',
            value: `£${avgCommissionPerClient.toFixed(0)}`,
            icon: Target,
            color: 'text-purple-400',
            bgColor: 'from-purple-500/10 to-purple-500/5',
            borderColor: 'border-purple-500/30'
        },
        {
            label: 'Growth Rate',
            value: `${growthRate}%`,
            icon: TrendingUp,
            color: 'text-amber-400',
            bgColor: 'from-amber-500/10 to-amber-500/5',
            borderColor: 'border-amber-500/30'
        }
    ];

    return (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {metrics.map((metric, idx) => (
                <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                >
                    <Card className={`bg-gradient-to-br ${metric.bgColor} border ${metric.borderColor}`}>
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">{metric.label}</p>
                                    <p className={`text-3xl font-bold ${metric.color}`}>{metric.value}</p>
                                </div>
                                <metric.icon className={`w-10 h-10 ${metric.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
}