import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Search, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PerformanceTracker({ players, reports }) {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [timeRange, setTimeRange] = useState('6months');
    const [metricFilter, setMetricFilter] = useState('all');

    const filteredPlayers = players.filter(p =>
        p.name?.toLowerCase().includes(searchQuery.toLowerCase())
    ).slice(0, 50);

    const playerReports = selectedPlayer
        ? reports.filter(r => r.player_name === selectedPlayer.name)
        : [];

    // Generate performance timeline data
    const performanceTimeline = selectedPlayer ? [
        { month: 'Jan', score: 78, goals: 2, assists: 1 },
        { month: 'Feb', score: 80, goals: 3, assists: 2 },
        { month: 'Mar', score: 82, goals: 4, assists: 3 },
        { month: 'Apr', score: 85, goals: 5, assists: 4 },
        { month: 'May', score: 83, goals: 3, assists: 2 },
        { month: 'Jun', score: 87, goals: 6, assists: 5 }
    ] : [];

    // Radar chart data for player attributes
    const attributeData = selectedPlayer ? [
        { attribute: 'Technical', value: 85 },
        { attribute: 'Physical', value: 78 },
        { attribute: 'Mental', value: 82 },
        { attribute: 'Tactical', value: 80 },
        { attribute: 'Leadership', value: 75 }
    ] : [];

    return (
        <div className="space-y-6">
            {/* Search & Filters */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                                placeholder="Search players..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10 bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <Select value={timeRange} onValueChange={setTimeRange}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="1month">Last Month</SelectItem>
                                <SelectItem value="3months">Last 3 Months</SelectItem>
                                <SelectItem value="6months">Last 6 Months</SelectItem>
                                <SelectItem value="1year">Last Year</SelectItem>
                                <SelectItem value="all">All Time</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={metricFilter} onValueChange={setMetricFilter}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Metrics</SelectItem>
                                <SelectItem value="performance">Performance</SelectItem>
                                <SelectItem value="potential">Potential</SelectItem>
                                <SelectItem value="market">Market Value</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Player List */}
                <Card className="bg-slate-900/50 border-slate-800 lg:col-span-1">
                    <CardHeader>
                        <CardTitle className="text-white">Players ({filteredPlayers.length})</CardTitle>
                    </CardHeader>
                    <CardContent className="max-h-[600px] overflow-y-auto space-y-2">
                        {filteredPlayers.map((player) => (
                            <motion.div
                                key={player.id}
                                whileHover={{ scale: 1.02 }}
                                onClick={() => setSelectedPlayer(player)}
                                className={`p-3 rounded-lg cursor-pointer transition-all ${
                                    selectedPlayer?.id === player.id
                                        ? 'bg-cyan-500/20 border border-cyan-500/50'
                                        : 'bg-slate-800/50 hover:bg-slate-800'
                                }`}
                            >
                                <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                        <p className="text-white font-semibold">{player.name}</p>
                                        <p className="text-slate-400 text-xs">{player.position} • {player.age}y</p>
                                        <p className="text-slate-500 text-xs">{player.current_club}</p>
                                    </div>
                                    {player.fsai_proprietary_score && (
                                        <Badge className="bg-gradient-to-r from-cyan-500 to-blue-600">
                                            {player.fsai_proprietary_score}
                                        </Badge>
                                    )}
                                </div>
                            </motion.div>
                        ))}
                    </CardContent>
                </Card>

                {/* Performance Details */}
                <div className="lg:col-span-2 space-y-6">
                    {selectedPlayer ? (
                        <>
                            {/* Player Header */}
                            <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <h2 className="text-2xl font-bold text-white">{selectedPlayer.name}</h2>
                                            <p className="text-slate-300 mt-1">
                                                {selectedPlayer.position} • {selectedPlayer.age} years old
                                            </p>
                                            <p className="text-slate-400 text-sm">{selectedPlayer.current_club} • {selectedPlayer.league}</p>
                                        </div>
                                        <div className="text-right">
                                            {selectedPlayer.fsai_proprietary_score && (
                                                <div>
                                                    <p className="text-slate-400 text-xs">FS-AI Score</p>
                                                    <p className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                                                        {selectedPlayer.fsai_proprietary_score}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-3 gap-4 mt-6">
                                        <div className="bg-slate-900/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-xs">Market Value</p>
                                            <p className="text-white font-bold text-lg">
                                                €{selectedPlayer.market_value}M
                                            </p>
                                        </div>
                                        <div className="bg-slate-900/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-xs">Reports</p>
                                            <p className="text-white font-bold text-lg">{playerReports.length}</p>
                                        </div>
                                        <div className="bg-slate-900/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-xs">Nationality</p>
                                            <p className="text-white font-bold text-lg">{selectedPlayer.nationality}</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Performance Timeline */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-2">
                                        <Activity className="w-5 h-5 text-cyan-400" />
                                        Performance Timeline
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ResponsiveContainer width="100%" height={300}>
                                        <AreaChart data={performanceTimeline}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                            <XAxis dataKey="month" stroke="#94a3b8" />
                                            <YAxis stroke="#94a3b8" />
                                            <Tooltip
                                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                                labelStyle={{ color: '#e2e8f0' }}
                                            />
                                            <Area type="monotone" dataKey="score" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>

                            {/* Attribute Radar */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Attribute Analysis</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ResponsiveContainer width="100%" height={300}>
                                        <RadarChart data={attributeData}>
                                            <PolarGrid stroke="#334155" />
                                            <PolarAngleAxis dataKey="attribute" stroke="#94a3b8" />
                                            <PolarRadiusAxis stroke="#94a3b8" />
                                            <Radar dataKey="value" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.5} />
                                        </RadarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>

                            {/* Key Stats */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Key Performance Indicators</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center gap-2 mb-2">
                                                <TrendingUp className="w-4 h-4 text-emerald-400" />
                                                <p className="text-slate-400 text-xs">Goals/Game</p>
                                            </div>
                                            <p className="text-2xl font-bold text-white">0.42</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center gap-2 mb-2">
                                                <TrendingUp className="w-4 h-4 text-blue-400" />
                                                <p className="text-slate-400 text-xs">Assists/Game</p>
                                            </div>
                                            <p className="text-2xl font-bold text-white">0.28</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center gap-2 mb-2">
                                                <Activity className="w-4 h-4 text-purple-400" />
                                                <p className="text-slate-400 text-xs">Pass Success</p>
                                            </div>
                                            <p className="text-2xl font-bold text-white">87%</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center gap-2 mb-2">
                                                <TrendingDown className="w-4 h-4 text-amber-400" />
                                                <p className="text-slate-400 text-xs">Injury Risk</p>
                                            </div>
                                            <p className="text-2xl font-bold text-white">Low</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </>
                    ) : (
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="py-24 text-center">
                                <Activity className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                                <p className="text-slate-400 text-lg">Select a player to view performance details</p>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </div>
    );
}