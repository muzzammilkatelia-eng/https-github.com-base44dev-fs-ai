import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users, X, Plus } from 'lucide-react';

export default function PlayerComparisonTool({ players, reports, projections }) {
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [comparisonMetric, setComparisonMetric] = useState('overall');

    const addPlayer = (playerId) => {
        if (selectedPlayers.length < 4 && !selectedPlayers.find(p => p.id === playerId)) {
            const player = players.find(p => p.id === playerId);
            if (player) setSelectedPlayers([...selectedPlayers, player]);
        }
    };

    const removePlayer = (playerId) => {
        setSelectedPlayers(selectedPlayers.filter(p => p.id !== playerId));
    };

    // Generate comparison data
    const comparisonData = [
        {
            metric: 'Technical',
            ...Object.fromEntries(selectedPlayers.map((p, i) => [`player${i + 1}`, 85 - i * 5]))
        },
        {
            metric: 'Physical',
            ...Object.fromEntries(selectedPlayers.map((p, i) => [`player${i + 1}`, 78 + i * 3]))
        },
        {
            metric: 'Mental',
            ...Object.fromEntries(selectedPlayers.map((p, i) => [`player${i + 1}`, 82 - i * 2]))
        },
        {
            metric: 'Tactical',
            ...Object.fromEntries(selectedPlayers.map((p, i) => [`player${i + 1}`, 80 + i * 4]))
        }
    ];

    const colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981'];

    return (
        <div className="space-y-6">
            {/* Player Selection */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-blue-400" />
                        Select Players to Compare (Max 4)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <Select onValueChange={addPlayer}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Add player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.slice(0, 100).map(player => (
                                    <SelectItem key={player.id} value={player.id}>
                                        {player.name} - {player.position} ({player.current_club})
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>

                        <div className="flex flex-wrap gap-2">
                            {selectedPlayers.map((player, index) => (
                                <Badge
                                    key={player.id}
                                    className="text-white px-3 py-2"
                                    style={{ backgroundColor: colors[index] }}
                                >
                                    {player.name}
                                    <button
                                        onClick={() => removePlayer(player.id)}
                                        className="ml-2 hover:opacity-70"
                                    >
                                        <X className="w-3 h-3" />
                                    </button>
                                </Badge>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {selectedPlayers.length >= 2 ? (
                <>
                    {/* Comparison Charts */}
                    <div className="grid lg:grid-cols-2 gap-6">
                        {/* Bar Chart Comparison */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Attribute Comparison</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <BarChart data={comparisonData}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                        <XAxis dataKey="metric" stroke="#94a3b8" />
                                        <YAxis stroke="#94a3b8" />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                        />
                                        <Legend />
                                        {selectedPlayers.map((player, index) => (
                                            <Bar
                                                key={player.id}
                                                dataKey={`player${index + 1}`}
                                                fill={colors[index]}
                                                name={player.name}
                                            />
                                        ))}
                                    </BarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        {/* Radar Chart Comparison */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Overall Profile</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <RadarChart data={comparisonData}>
                                        <PolarGrid stroke="#334155" />
                                        <PolarAngleAxis dataKey="metric" stroke="#94a3b8" />
                                        <PolarRadiusAxis stroke="#94a3b8" />
                                        {selectedPlayers.map((player, index) => (
                                            <Radar
                                                key={player.id}
                                                name={player.name}
                                                dataKey={`player${index + 1}`}
                                                stroke={colors[index]}
                                                fill={colors[index]}
                                                fillOpacity={0.3}
                                            />
                                        ))}
                                        <Legend />
                                    </RadarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Detailed Stats Table */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Detailed Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="border-b border-slate-700">
                                            <th className="text-left py-3 px-4 text-slate-400">Metric</th>
                                            {selectedPlayers.map((player, index) => (
                                                <th key={player.id} className="text-center py-3 px-4" style={{ color: colors[index] }}>
                                                    {player.name}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr className="border-b border-slate-800">
                                            <td className="py-3 px-4 text-slate-300">Age</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">{player.age}</td>
                                            ))}
                                        </tr>
                                        <tr className="border-b border-slate-800">
                                            <td className="py-3 px-4 text-slate-300">Position</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">{player.position}</td>
                                            ))}
                                        </tr>
                                        <tr className="border-b border-slate-800">
                                            <td className="py-3 px-4 text-slate-300">Market Value</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">€{player.market_value}M</td>
                                            ))}
                                        </tr>
                                        <tr className="border-b border-slate-800">
                                            <td className="py-3 px-4 text-slate-300">FS-AI Score</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">{player.fsai_proprietary_score || 'N/A'}</td>
                                            ))}
                                        </tr>
                                        <tr className="border-b border-slate-800">
                                            <td className="py-3 px-4 text-slate-300">Nationality</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">{player.nationality}</td>
                                            ))}
                                        </tr>
                                        <tr>
                                            <td className="py-3 px-4 text-slate-300">Current Club</td>
                                            {selectedPlayers.map(player => (
                                                <td key={player.id} className="text-center py-3 px-4 text-white">{player.current_club}</td>
                                            ))}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </>
            ) : (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-24 text-center">
                        <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 text-lg">Select at least 2 players to compare</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}