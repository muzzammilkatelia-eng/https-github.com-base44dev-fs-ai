import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Activity, Target, Zap } from 'lucide-react';
import { LineChart, Line, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

export default function PlayerKPIDashboard({ players, reports, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const player = players.find(p => p.id === selectedPlayer);
    const playerReports = reports.filter(r => r.player_name?.toLowerCase() === player?.name?.toLowerCase()).sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    const projection = projections.find(p => p.player_name?.toLowerCase() === player?.name?.toLowerCase());

    // Calculate KPIs
    const calculateKPIs = () => {
        if (!player || playerReports.length === 0) return null;

        const latestReport = playerReports[playerReports.length - 1];
        const firstReport = playerReports[0];

        // Performance trend
        const ratingChange = latestReport.overall_rating - firstReport.overall_rating;
        const performanceTrend = ratingChange > 0.5 ? 'Improving' : ratingChange < -0.5 ? 'Declining' : 'Stable';

        // Consistency score
        const ratings = playerReports.map(r => r.overall_rating);
        const avgRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
        const variance = ratings.reduce((sum, r) => sum + Math.pow(r - avgRating, 2), 0) / ratings.length;
        const consistency = Math.max(0, 100 - variance * 20);

        // Development velocity
        const monthsSinceFirst = (new Date(latestReport.created_date) - new Date(firstReport.created_date)) / (1000 * 60 * 60 * 24 * 30);
        const developmentVelocity = monthsSinceFirst > 0 ? (ratingChange / monthsSinceFirst) * 12 : 0;

        return {
            performanceTrend,
            consistency: Math.round(consistency),
            developmentVelocity: developmentVelocity.toFixed(2),
            currentRating: latestReport.overall_rating,
            ratingChange: ratingChange.toFixed(1),
            reportsCount: playerReports.length,
            avgRating: avgRating.toFixed(1),
            peakRating: Math.max(...ratings)
        };
    };

    const kpis = calculateKPIs();

    // Performance timeline data
    const timelineData = playerReports.map(r => ({
        date: new Date(r.created_date).toLocaleDateString(),
        overall: r.overall_rating,
        technical: r.technical_rating,
        physical: r.physical_rating,
        mental: r.mental_rating
    }));

    // Latest radar data
    const radarData = playerReports.length > 0 ? [
        { attribute: 'Technical', value: playerReports[playerReports.length - 1].technical_rating },
        { attribute: 'Physical', value: playerReports[playerReports.length - 1].physical_rating },
        { attribute: 'Mental', value: playerReports[playerReports.length - 1].mental_rating },
        { attribute: 'Tactical', value: playerReports[playerReports.length - 1].tactical_rating || 7 }
    ] : [];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Select Player for KPI Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                    <Select value={selectedPlayer || ''} onValueChange={setSelectedPlayer}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue placeholder="Choose a player..." />
                        </SelectTrigger>
                        <SelectContent>
                            {players.map(p => (
                                <SelectItem key={p.id} value={p.id}>
                                    {p.name} - {p.position} ({p.age}y)
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </CardContent>
            </Card>

            {player && kpis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* KPI Cards */}
                    <div className="grid md:grid-cols-4 gap-4">
                        <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-slate-400 text-sm">Current Rating</p>
                                    <Activity className="w-5 h-5 text-cyan-400" />
                                </div>
                                <p className="text-4xl font-bold text-white mb-1">{kpis.currentRating}</p>
                                <Badge className={kpis.ratingChange > 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}>
                                    {kpis.ratingChange > 0 ? '+' : ''}{kpis.ratingChange} from first report
                                </Badge>
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-slate-400 text-sm">Consistency</p>
                                    <Target className="w-5 h-5 text-purple-400" />
                                </div>
                                <p className="text-4xl font-bold text-white mb-1">{kpis.consistency}</p>
                                <p className="text-slate-400 text-xs">Performance stability score</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-slate-400 text-sm">Dev Velocity</p>
                                    <Zap className="w-5 h-5 text-emerald-400" />
                                </div>
                                <p className="text-4xl font-bold text-white mb-1">{kpis.developmentVelocity}</p>
                                <p className="text-slate-400 text-xs">Rating points per year</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-slate-400 text-sm">Trend</p>
                                    <TrendingUp className="w-5 h-5 text-amber-400" />
                                </div>
                                <p className="text-2xl font-bold text-white mb-1">{kpis.performanceTrend}</p>
                                <p className="text-slate-400 text-xs">{kpis.reportsCount} reports analyzed</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Performance Timeline */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Performance Timeline</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={timelineData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="date" stroke="#94a3b8" />
                                    <YAxis domain={[0, 10]} stroke="#94a3b8" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #475569',
                                            borderRadius: '8px'
                                        }}
                                    />
                                    <Legend />
                                    <Line type="monotone" dataKey="overall" stroke="#06b6d4" strokeWidth={3} name="Overall" />
                                    <Line type="monotone" dataKey="technical" stroke="#8b5cf6" strokeWidth={2} name="Technical" />
                                    <Line type="monotone" dataKey="physical" stroke="#10b981" strokeWidth={2} name="Physical" />
                                    <Line type="monotone" dataKey="mental" stroke="#f59e0b" strokeWidth={2} name="Mental" />
                                </LineChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Attribute Breakdown */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Current Attributes</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <RadarChart data={radarData}>
                                        <PolarGrid stroke="#475569" />
                                        <PolarAngleAxis dataKey="attribute" stroke="#94a3b8" />
                                        <PolarRadiusAxis domain={[0, 10]} stroke="#94a3b8" />
                                        <Radar name="Current" dataKey="value" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.6} />
                                    </RadarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Key Statistics</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-400 text-sm mb-1">Average Rating</p>
                                    <p className="text-white text-3xl font-bold">{kpis.avgRating}/10</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-400 text-sm mb-1">Peak Performance</p>
                                    <p className="text-emerald-400 text-3xl font-bold">{kpis.peakRating}/10</p>
                                </div>
                                {projection && (
                                    <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                        <p className="text-purple-400 text-sm mb-1">Projected Peak</p>
                                        <p className="text-white text-3xl font-bold">{projection.peak_potential_rating}/10</p>
                                        <p className="text-slate-400 text-xs mt-1">
                                            In {projection.years_to_peak} years
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                </motion.div>
            )}

            {player && (!kpis || playerReports.length === 0) && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16 text-center">
                        <p className="text-slate-400">No scouting reports available for this player</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}