import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, Target, Award } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

export default function PortfolioAnalytics({ players, projections, reports }) {
    // Portfolio value calculation
    const totalValue = players.reduce((sum, p) => sum + (p.market_value || 0), 0);
    const avgValue = totalValue / players.length;

    // Age distribution
    const ageDistribution = players.reduce((acc, p) => {
        const bracket = p.age < 21 ? 'U21' : p.age < 24 ? '21-23' : p.age < 27 ? '24-26' : p.age < 30 ? '27-29' : '30+';
        acc[bracket] = (acc[bracket] || 0) + 1;
        return acc;
    }, {});

    const ageData = Object.entries(ageDistribution).map(([bracket, count]) => ({
        bracket,
        count,
        percentage: Math.round((count / players.length) * 100)
    }));

    // Position distribution
    const positionDistribution = players.reduce((acc, p) => {
        acc[p.position] = (acc[p.position] || 0) + 1;
        return acc;
    }, {});

    const positionData = Object.entries(positionDistribution).map(([position, count]) => ({
        position,
        count
    }));

    // Trajectory breakdown
    const trajectoryDistribution = projections.reduce((acc, p) => {
        acc[p.potential_trajectory] = (acc[p.potential_trajectory] || 0) + 1;
        return acc;
    }, {});

    const trajectoryData = Object.entries(trajectoryDistribution).map(([trajectory, count]) => ({
        trajectory,
        count
    }));

    // Top performers
    const topPerformers = reports
        .filter(r => r.overall_rating >= 8)
        .map(r => r.player_name)
        .filter((name, idx, arr) => arr.indexOf(name) === idx)
        .slice(0, 10);

    // Investment quality
    const eliteProspects = projections.filter(p => 
        p.potential_trajectory === 'Elite Tier Prospect' || p.potential_trajectory === 'Top Tier Prospect'
    ).length;

    const COLORS = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Total Value</p>
                                <p className="text-3xl font-bold text-emerald-400">€{totalValue}M</p>
                            </div>
                            <DollarSign className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Avg Value</p>
                                <p className="text-3xl font-bold text-cyan-400">€{avgValue.toFixed(1)}M</p>
                            </div>
                            <Target className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Elite Prospects</p>
                                <p className="text-3xl font-bold text-purple-400">{eliteProspects}</p>
                            </div>
                            <Award className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Top Performers</p>
                                <p className="text-3xl font-bold text-amber-400">{topPerformers.length}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                {/* Age Distribution */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Age Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <PieChart>
                                <Pie
                                    data={ageData}
                                    dataKey="count"
                                    nameKey="bracket"
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={80}
                                    label={(entry) => `${entry.bracket}: ${entry.percentage}%`}
                                >
                                    {ageData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* Position Distribution */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Position Coverage</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={positionData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="position" stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: '#1e293b',
                                        border: '1px solid #475569',
                                        borderRadius: '8px'
                                    }}
                                />
                                <Bar dataKey="count" fill="#06b6d4" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            {/* Trajectory Distribution */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Career Trajectory Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={trajectoryData} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis type="number" stroke="#94a3b8" />
                            <YAxis dataKey="trajectory" type="category" stroke="#94a3b8" width={200} />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: '#1e293b',
                                    border: '1px solid #475569',
                                    borderRadius: '8px'
                                }}
                            />
                            <Bar dataKey="count" fill="#8b5cf6" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Top Performers */}
            <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                <CardHeader>
                    <CardTitle className="text-emerald-400">Top Performers (8.0+ Rating)</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex flex-wrap gap-2">
                        {topPerformers.map((name, idx) => (
                            <Badge key={idx} className="bg-emerald-500/20 text-emerald-400 px-3 py-1">
                                {name}
                            </Badge>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}