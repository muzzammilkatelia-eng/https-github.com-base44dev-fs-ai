import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TrendingUp, AlertTriangle, DollarSign, Activity, Loader2, Sparkles, Brain } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function PredictiveAnalyticsDashboard({ players, reports, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [predictions, setPredictions] = useState(null);

    const runPredictiveAnalysis = async () => {
        if (!selectedPlayer) return;

        setAnalyzing(true);
        toast.loading('AI analyzing player trajectory...', { id: 'predict' });

        try {
            const playerReports = reports.filter(r => r.player_name?.toLowerCase() === selectedPlayer.name?.toLowerCase());
            const playerProjection = projections.find(p => p.player_name?.toLowerCase() === selectedPlayer.name?.toLowerCase());

            const prompt = `You are an elite football analytics AI specializing in predictive modeling. Analyze this player and generate comprehensive predictions:

PLAYER: ${selectedPlayer.name}
AGE: ${selectedPlayer.age}
POSITION: ${selectedPlayer.position}
CURRENT CLUB: ${selectedPlayer.current_club}
CURRENT VALUE: €${selectedPlayer.market_value}M
CONTRACT EXPIRY: ${selectedPlayer.contract_expiry || 'Unknown'}

HISTORICAL REPORTS: ${playerReports.length} scouting reports
PROJECTION DATA: ${playerProjection ? 'Available' : 'Not available'}

Generate detailed 5-year predictions with confidence intervals for:
1. Performance trajectory (rating progression)
2. Market value evolution
3. Injury risk assessment
4. Career path scenarios (best/expected/worst case)
5. Optimal transfer windows
6. Development priorities

Provide realistic, data-driven predictions with statistical confidence levels.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        current_age: { type: "number" },
                        performance_trajectory: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    rating: { type: "number" },
                                    confidence_lower: { type: "number" },
                                    confidence_upper: { type: "number" },
                                    confidence_level: { type: "number" }
                                }
                            }
                        },
                        market_value_forecast: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    value_millions: { type: "number" },
                                    confidence_lower: { type: "number" },
                                    confidence_upper: { type: "number" }
                                }
                            }
                        },
                        injury_risk_analysis: {
                            type: "object",
                            properties: {
                                current_risk_score: { type: "number" },
                                risk_trend: { type: "string" },
                                key_risk_factors: {
                                    type: "array",
                                    items: { type: "string" }
                                },
                                mitigation_strategies: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        },
                        career_scenarios: {
                            type: "object",
                            properties: {
                                best_case: { type: "string" },
                                expected_case: { type: "string" },
                                worst_case: { type: "string" },
                                probability_distribution: {
                                    type: "object",
                                    properties: {
                                        best_case_probability: { type: "number" },
                                        expected_case_probability: { type: "number" },
                                        worst_case_probability: { type: "number" }
                                    }
                                }
                            }
                        },
                        optimal_transfer_windows: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    reasoning: { type: "string" },
                                    expected_value: { type: "number" },
                                    risk_level: { type: "string" }
                                }
                            }
                        },
                        development_priorities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    priority: { type: "string" },
                                    expected_impact: { type: "string" },
                                    timeline: { type: "string" }
                                }
                            }
                        },
                        key_insights: {
                            type: "array",
                            items: { type: "string" }
                        },
                        overall_confidence: { type: "number" }
                    }
                }
            });

            setPredictions(response);
            toast.success('Predictive analysis complete!', { id: 'predict' });
        } catch (error) {
            console.error('Prediction failed:', error);
            toast.error('Failed to generate predictions', { id: 'predict' });
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 via-cyan-500/10 to-blue-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Brain className="w-6 h-6 text-purple-400" />
                        Predictive Analytics Dashboard
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        AI-powered forecasting for performance, value, and injury risk
                    </p>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Select Player</label>
                            <Select value={selectedPlayer?.id || ''} onValueChange={(id) => setSelectedPlayer(players.find(p => p.id === id))}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Choose a player..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {players.map(p => (
                                        <SelectItem key={p.id} value={p.id}>
                                            {p.name} - {p.position} ({p.age}y)
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="flex items-end">
                            <Button
                                onClick={runPredictiveAnalysis}
                                disabled={analyzing || !selectedPlayer}
                                className="w-full bg-gradient-to-r from-purple-500 to-cyan-600 hover:from-purple-400 hover:to-cyan-500"
                            >
                                {analyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Generate Predictions
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {predictions && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Confidence Indicator */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-3">
                                <span className="text-white font-semibold">Overall Prediction Confidence</span>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {predictions.overall_confidence}%
                                </Badge>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-3">
                                <div 
                                    className="bg-gradient-to-r from-purple-500 to-cyan-500 h-3 rounded-full transition-all"
                                    style={{ width: `${predictions.overall_confidence}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Performance Trajectory */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-cyan-400" />
                                Performance Trajectory (5-Year Forecast)
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={350}>
                                <AreaChart data={predictions.performance_trajectory}>
                                    <defs>
                                        <linearGradient id="colorRating" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                                            <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="year" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" domain={[0, 100]} />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #475569',
                                            borderRadius: '8px'
                                        }}
                                    />
                                    <Area type="monotone" dataKey="confidence_upper" stroke="transparent" fill="#06b6d4" fillOpacity={0.1} />
                                    <Area type="monotone" dataKey="rating" stroke="#06b6d4" strokeWidth={3} fill="url(#colorRating)" />
                                    <Area type="monotone" dataKey="confidence_lower" stroke="transparent" fill="#06b6d4" fillOpacity={0.1} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Market Value Forecast */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-emerald-400" />
                                Market Value Forecast
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={predictions.market_value_forecast}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="year" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #475569',
                                            borderRadius: '8px'
                                        }}
                                        formatter={(value) => `€${value}M`}
                                    />
                                    <Line type="monotone" dataKey="confidence_upper" stroke="#10b981" strokeDasharray="5 5" strokeWidth={1} dot={false} />
                                    <Line type="monotone" dataKey="value_millions" stroke="#10b981" strokeWidth={3} />
                                    <Line type="monotone" dataKey="confidence_lower" stroke="#10b981" strokeDasharray="5 5" strokeWidth={1} dot={false} />
                                </LineChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Injury Risk Analysis */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5 text-red-400" />
                                Injury Risk Assessment
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center justify-between">
                                <span className="text-white font-semibold">Current Risk Score</span>
                                <Badge className={
                                    predictions.injury_risk_analysis.current_risk_score > 70 ? 'bg-red-500/20 text-red-400' :
                                    predictions.injury_risk_analysis.current_risk_score > 40 ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-emerald-500/20 text-emerald-400'
                                }>
                                    {predictions.injury_risk_analysis.current_risk_score}/100
                                </Badge>
                            </div>

                            <div>
                                <h4 className="text-white font-semibold mb-2">Key Risk Factors</h4>
                                <ul className="space-y-1">
                                    {predictions.injury_risk_analysis.key_risk_factors.map((factor, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-center gap-2">
                                            <AlertTriangle className="w-3 h-3 text-amber-400" />
                                            {factor}
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            <div>
                                <h4 className="text-white font-semibold mb-2">Mitigation Strategies</h4>
                                <ul className="space-y-1">
                                    {predictions.injury_risk_analysis.mitigation_strategies.map((strategy, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-center gap-2">
                                            <Activity className="w-3 h-3 text-emerald-400" />
                                            {strategy}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Career Scenarios */}
                    <div className="grid md:grid-cols-3 gap-4">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 text-lg">Best Case</CardTitle>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    {predictions.career_scenarios.probability_distribution.best_case_probability}% probability
                                </Badge>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{predictions.career_scenarios.best_case}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-cyan-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-cyan-400 text-lg">Expected Case</CardTitle>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {predictions.career_scenarios.probability_distribution.expected_case_probability}% probability
                                </Badge>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{predictions.career_scenarios.expected_case}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400 text-lg">Worst Case</CardTitle>
                                <Badge className="bg-amber-500/20 text-amber-400">
                                    {predictions.career_scenarios.probability_distribution.worst_case_probability}% probability
                                </Badge>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{predictions.career_scenarios.worst_case}</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Optimal Transfer Windows */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Optimal Transfer Windows</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {predictions.optimal_transfer_windows.map((window, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-white font-semibold">Year {window.year}</span>
                                            <Badge className={
                                                window.risk_level === 'Low' ? 'bg-emerald-500/20 text-emerald-400' :
                                                window.risk_level === 'Medium' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-red-500/20 text-red-400'
                                            }>
                                                {window.risk_level} Risk
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm mb-2">{window.reasoning}</p>
                                        <p className="text-emerald-400 font-semibold">Expected Value: €{window.expected_value}M</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Development Priorities */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Development Priorities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {predictions.development_priorities.map((priority, idx) => (
                                    <div key={idx} className="flex items-start justify-between p-3 bg-slate-800/50 rounded-lg">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="text-white font-semibold">{priority.area}</h4>
                                                <Badge className={
                                                    priority.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                    priority.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-cyan-500/20 text-cyan-400'
                                                }>
                                                    {priority.priority}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-300 text-sm mb-1">{priority.expected_impact}</p>
                                            <p className="text-slate-500 text-xs">Timeline: {priority.timeline}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Key Insights */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Sparkles className="w-5 h-5 text-purple-400" />
                                Key Strategic Insights
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2">
                                {predictions.key_insights.map((insight, idx) => (
                                    <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-purple-400 font-bold mt-1">•</span>
                                        {insight}
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!predictions && !analyzing && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16 text-center">
                        <Brain className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-2">Select a player and generate AI predictions</p>
                        <p className="text-slate-500 text-sm">
                            Get 5-year forecasts for performance, market value, and injury risk
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}