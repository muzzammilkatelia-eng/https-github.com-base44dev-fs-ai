import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
    TrendingUp, TrendingDown, Target, CheckCircle, 
    Clock, AlertTriangle, Mail, FileText, BarChart3 
} from 'lucide-react';

export default function RecruitmentOverview({ 
    reports, 
    tasks, 
    communications, 
    projections, 
    marketData,
    timeRange 
}) {
    // Scouting Efficiency Metrics
    const totalReports = reports.length;
    const immediateSigningRecs = reports.filter(r => r.recommendation === 'Immediate Signing').length;
    const monitorCloselyRecs = reports.filter(r => r.recommendation === 'Monitor Closely').length;
    const avgTechnicalRating = reports.length > 0 
        ? Math.round(reports.reduce((sum, r) => sum + (r.technical_rating || 0), 0) / reports.length) 
        : 0;

    // Task Management Efficiency
    const completedTasks = tasks.filter(t => t.status === 'Completed').length;
    const inProgressTasks = tasks.filter(t => t.status === 'In Progress').length;
    const pendingTasks = tasks.filter(t => t.status === 'Pending').length;
    const blockedTasks = tasks.filter(t => t.status === 'Blocked').length;
    const avgTaskCompletion = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

    // Agent Engagement Metrics
    const sentComms = communications.filter(c => c.status === 'Sent' || c.status === 'Awaiting Response').length;
    const respondedComms = communications.filter(c => c.response_received).length;
    const responseRate = sentComms > 0 ? Math.round((respondedComms / sentComms) * 100) : 0;
    
    const positiveSentiment = communications.filter(c => 
        c.ai_sentiment_analysis?.sentiment === 'Very Positive' || 
        c.ai_sentiment_analysis?.sentiment === 'Positive'
    ).length;
    const negativeSentiment = communications.filter(c => 
        c.ai_sentiment_analysis?.sentiment === 'Negative' || 
        c.ai_sentiment_analysis?.sentiment === 'Very Negative'
    ).length;

    const successfulNegotiations = communications.filter(c => 
        c.status === 'Closed' && 
        (c.ai_sentiment_analysis?.sentiment === 'Very Positive' || c.ai_sentiment_analysis?.sentiment === 'Positive')
    ).length;

    // Player Pipeline Metrics
    const eliteProspects = projections.filter(p => p.potential_trajectory === 'Elite Tier Prospect').length;
    const topTierProspects = projections.filter(p => p.potential_trajectory === 'Top Tier Prospect').length;
    
    // Transfer Success Rate
    const proposalsSent = communications.filter(c => c.communication_type === 'Proposal').length;
    const successfulTransfers = communications.filter(c => 
        c.communication_type === 'Proposal' && 
        c.status === 'Closed' &&
        c.ai_sentiment_analysis?.sentiment?.includes('Positive')
    ).length;
    const transferSuccessRate = proposalsSent > 0 ? Math.round((successfulTransfers / proposalsSent) * 100) : 0;

    // Market Intelligence
    const trendingPlayers = marketData.filter(m => m.trending).length;
    const avgMarketValue = marketData.length > 0
        ? Math.round(marketData.reduce((sum, m) => sum + (m.market_value_eur || 0), 0) / marketData.length)
        : 0;

    return (
        <div className="space-y-6">
            {/* Scouting Efficiency */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Scouting Efficiency
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Total Reports</p>
                            <p className="text-3xl font-bold text-white mb-2">{totalReports}</p>
                            <div className="flex items-center gap-2">
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                    {immediateSigningRecs} Immediate
                                </Badge>
                                <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                    {monitorCloselyRecs} Monitor
                                </Badge>
                            </div>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Avg Technical Rating</p>
                            <p className="text-3xl font-bold text-cyan-400 mb-2">{avgTechnicalRating}/100</p>
                            <div className="w-full bg-slate-700 rounded-full h-2">
                                <div 
                                    className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full"
                                    style={{ width: `${avgTechnicalRating}%` }}
                                />
                            </div>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Elite Prospects</p>
                            <p className="text-3xl font-bold text-purple-400 mb-2">{eliteProspects}</p>
                            <p className="text-slate-500 text-xs">Top Tier: {topTierProspects}</p>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Quality Score</p>
                            <p className="text-3xl font-bold text-emerald-400 mb-2">
                                {totalReports > 0 ? Math.round((immediateSigningRecs / totalReports) * 100) : 0}%
                            </p>
                            <p className="text-slate-500 text-xs">Immediate signings</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Task Management */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                        Task Management & Workflow
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-white font-semibold">Task Distribution</h4>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    {avgTaskCompletion}% Complete
                                </Badge>
                            </div>
                            <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                                        <span className="text-slate-300 text-sm">Completed</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-32 bg-slate-700 rounded-full h-2">
                                            <div 
                                                className="bg-emerald-500 h-2 rounded-full"
                                                style={{ width: `${tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0}%` }}
                                            />
                                        </div>
                                        <span className="text-white font-semibold w-8">{completedTasks}</span>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <Clock className="w-4 h-4 text-cyan-400" />
                                        <span className="text-slate-300 text-sm">In Progress</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-32 bg-slate-700 rounded-full h-2">
                                            <div 
                                                className="bg-cyan-500 h-2 rounded-full"
                                                style={{ width: `${tasks.length > 0 ? (inProgressTasks / tasks.length) * 100 : 0}%` }}
                                            />
                                        </div>
                                        <span className="text-white font-semibold w-8">{inProgressTasks}</span>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <Clock className="w-4 h-4 text-amber-400" />
                                        <span className="text-slate-300 text-sm">Pending</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-32 bg-slate-700 rounded-full h-2">
                                            <div 
                                                className="bg-amber-500 h-2 rounded-full"
                                                style={{ width: `${tasks.length > 0 ? (pendingTasks / tasks.length) * 100 : 0}%` }}
                                            />
                                        </div>
                                        <span className="text-white font-semibold w-8">{pendingTasks}</span>
                                    </div>
                                </div>

                                {blockedTasks > 0 && (
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-400" />
                                            <span className="text-slate-300 text-sm">Blocked</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <div className="w-32 bg-slate-700 rounded-full h-2">
                                                <div 
                                                    className="bg-red-500 h-2 rounded-full"
                                                    style={{ width: `${tasks.length > 0 ? (blockedTasks / tasks.length) * 100 : 0}%` }}
                                                />
                                            </div>
                                            <span className="text-white font-semibold w-8">{blockedTasks}</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h4 className="text-white font-semibold mb-4">Workflow Insights</h4>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                    <span className="text-slate-400 text-sm">Completion Rate</span>
                                    <span className="text-emerald-400 font-bold">{avgTaskCompletion}%</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-slate-400 text-sm">Total Tasks</span>
                                    <span className="text-white font-bold">{tasks.length}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-slate-400 text-sm">AI Flagged</span>
                                    <span className="text-purple-400 font-bold">
                                        {tasks.filter(t => t.source === 'AI Flag').length}
                                    </span>
                                </div>
                                {blockedTasks > 0 && (
                                    <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                                        <div className="flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4 text-red-400" />
                                            <span className="text-red-400 text-sm font-semibold">
                                                {blockedTasks} blocked tasks need attention
                                            </span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Agent Communications */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Mail className="w-5 h-5 text-purple-400" />
                        Agent Engagement & Negotiations
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Response Rate</p>
                            <p className="text-3xl font-bold text-cyan-400 mb-2">{responseRate}%</p>
                            <p className="text-slate-500 text-xs">{respondedComms}/{sentComms} responses</p>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Positive Sentiment</p>
                            <p className="text-3xl font-bold text-emerald-400 mb-2">{positiveSentiment}</p>
                            <div className="flex items-center gap-1">
                                <TrendingUp className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-400 text-xs">
                                    {respondedComms > 0 ? Math.round((positiveSentiment / respondedComms) * 100) : 0}%
                                </span>
                            </div>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Successful Deals</p>
                            <p className="text-3xl font-bold text-purple-400 mb-2">{successfulNegotiations}</p>
                            <p className="text-slate-500 text-xs">Closed positively</p>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Transfer Success</p>
                            <p className="text-3xl font-bold text-amber-400 mb-2">{transferSuccessRate}%</p>
                            <p className="text-slate-500 text-xs">{successfulTransfers}/{proposalsSent} proposals</p>
                        </div>
                    </div>

                    {negativeSentiment > 0 && (
                        <div className="mt-6 p-4 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                                <AlertTriangle className="w-4 h-4 text-orange-400" />
                                <span className="text-orange-400 font-semibold text-sm">Attention Required</span>
                            </div>
                            <p className="text-slate-300 text-sm">
                                {negativeSentiment} communications received negative sentiment. Review and adjust approach.
                            </p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Overall Recruitment Performance */}
            <Card className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border-indigo-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-indigo-400" />
                        Overall Recruitment Performance
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="text-center">
                            <div className="w-32 h-32 mx-auto mb-4 relative">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        className="text-slate-700"
                                    />
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        strokeDasharray={`${(avgTaskCompletion / 100) * 351.86} 351.86`}
                                        className="text-emerald-500"
                                    />
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <span className="text-3xl font-bold text-white">{avgTaskCompletion}%</span>
                                </div>
                            </div>
                            <p className="text-white font-semibold mb-1">Workflow Efficiency</p>
                            <p className="text-slate-400 text-sm">Task completion rate</p>
                        </div>

                        <div className="text-center">
                            <div className="w-32 h-32 mx-auto mb-4 relative">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        className="text-slate-700"
                                    />
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        strokeDasharray={`${(responseRate / 100) * 351.86} 351.86`}
                                        className="text-cyan-500"
                                    />
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <span className="text-3xl font-bold text-white">{responseRate}%</span>
                                </div>
                            </div>
                            <p className="text-white font-semibold mb-1">Agent Engagement</p>
                            <p className="text-slate-400 text-sm">Response rate</p>
                        </div>

                        <div className="text-center">
                            <div className="w-32 h-32 mx-auto mb-4 relative">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        className="text-slate-700"
                                    />
                                    <circle
                                        cx="64"
                                        cy="64"
                                        r="56"
                                        stroke="currentColor"
                                        strokeWidth="8"
                                        fill="none"
                                        strokeDasharray={`${(transferSuccessRate / 100) * 351.86} 351.86`}
                                        className="text-purple-500"
                                    />
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <span className="text-3xl font-bold text-white">{transferSuccessRate}%</span>
                                </div>
                            </div>
                            <p className="text-white font-semibold mb-1">Transfer Success</p>
                            <p className="text-slate-400 text-sm">Deal closure rate</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}