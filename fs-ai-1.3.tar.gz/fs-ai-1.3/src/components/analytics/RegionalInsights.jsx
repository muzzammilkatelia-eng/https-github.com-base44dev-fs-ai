import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RegionalInsights({ reports, commissions }) {
    const regionalData = useMemo(() => {
        const regions = {};
        
        // Aggregate from scout reports
        reports.forEach(report => {
            const region = report.player_data?.region || 'Unknown';
            if (!regions[region]) {
                regions[region] = {
                    region,
                    scoutedPlayers: 0,
                    avgScore: 0,
                    totalScore: 0,
                    highPotential: 0
                };
            }
            regions[region].scoutedPlayers += 1;
            regions[region].totalScore += report.calafat_analysis?.ceiling_score || 0;
            if (report.recommendation === 'Strong Recommend') {
                regions[region].highPotential += 1;
            }
        });
        
        return Object.values(regions).map(r => ({
            ...r,
            avgScore: r.scoutedPlayers > 0 ? (r.totalScore / r.scoutedPlayers).toFixed(1) : 0
        })).sort((a, b) => b.scoutedPlayers - a.scoutedPlayers);
    }, [reports]);

    const topRegions = regionalData.slice(0, 6);
    
    const COLORS = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#ec4899'];

    const positionData = useMemo(() => {
        const positions = {};
        reports.forEach(report => {
            const pos = report.position || 'Unknown';
            if (!positions[pos]) {
                positions[pos] = { position: pos, count: 0, avgPotential: 0, totalPotential: 0 };
            }
            positions[pos].count += 1;
            positions[pos].totalPotential += report.calafat_analysis?.ceiling_score || 0;
        });
        
        return Object.values(positions).map(p => ({
            ...p,
            avgPotential: p.count > 0 ? (p.totalPotential / p.count).toFixed(1) : 0
        })).sort((a, b) => b.count - a.count).slice(0, 8);
    }, [reports]);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-cyan-400" />
                            Top Scouting Regions
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={topRegions}
                                    dataKey="scoutedPlayers"
                                    nameKey="region"
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={100}
                                    label={(entry) => `${entry.region} (${entry.scoutedPlayers})`}
                                >
                                    {topRegions.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                            Position Analysis
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={positionData} layout="vertical">
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis type="number" stroke="#94a3b8" />
                                <YAxis dataKey="position" type="category" stroke="#94a3b8" width={120} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                />
                                <Bar dataKey="count" fill="#10b981" name="Players Scouted" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </motion.div>

            <motion.div 
                initial={{ opacity: 0, y: 20 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: 0.2 }}
                className="lg:col-span-2"
            >
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Regional Performance Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {topRegions.map((region, idx) => (
                                <div key={region.region} className="bg-slate-800/50 rounded-lg p-4">
                                    <div className="flex items-center justify-between mb-2">
                                        <h4 className="text-white font-semibold">{region.region}</h4>
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            {region.scoutedPlayers} players
                                        </Badge>
                                    </div>
                                    <div className="space-y-1 text-sm text-slate-400">
                                        <p>Avg Score: <span className="text-emerald-400 font-semibold">{region.avgScore}</span></p>
                                        <p>High Potential: <span className="text-purple-400 font-semibold">{region.highPotential}</span></p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}