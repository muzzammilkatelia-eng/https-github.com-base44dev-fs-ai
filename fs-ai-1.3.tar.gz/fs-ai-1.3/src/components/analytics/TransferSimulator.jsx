import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Zap, TrendingUp, DollarSign, AlertTriangle, Loader2, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TransferSimulator({ projections }) {
    const [scenario, setScenario] = useState({
        player: '',
        from_club: '',
        to_club: '',
        transfer_fee: '',
        context: ''
    });
    const [simulation, setSimulation] = useState(null);

    const simulateMutation = useMutation({
        mutationFn: async (scenarioData) => {
            const playerContext = projections.find(p => 
                p.player_name.toLowerCase().includes(scenarioData.player.toLowerCase())
            );

            const prompt = `You are an elite football market analyst. Simulate this transfer scenario and predict ALL cascading market effects:

SCENARIO:
- Player: ${scenarioData.player} ${scenarioData.context ? `(${scenarioData.context})` : ''}
- From: ${scenarioData.from_club}
- To: ${scenarioData.to_club}
- Transfer Fee: €${scenarioData.transfer_fee}M

${playerContext ? `
PLAYER PROJECTION DATA:
- Age: ${playerContext.current_age}
- Position: ${playerContext.position}
- Current Rating: ${playerContext.current_rating}
- Potential: ${playerContext.peak_potential_rating}
- Trajectory: ${playerContext.potential_trajectory}
- Development Curve: ${playerContext.development_curve}
` : ''}

Analyze COMPREHENSIVE market impact:

1. **Immediate Market Effects** (within 6 months):
   - Direct replacement searches by selling club
   - Similar player value adjustments
   - Position market inflation/deflation
   - League-specific impacts

2. **Agent Commission Impact**:
   - Initial signing commission (5% of fee)
   - Projected career transfers (2.5% per future transfer)
   - Estimated lifetime agent earnings
   - Best/worst case scenarios

3. **Player Value Trajectory** (3 years):
   - Year 1 value
   - Year 2 value  
   - Year 3 value
   - Peak market value projection
   - Factors influencing trajectory

4. **Cascading Transfer Opportunities** (5-7 specific opportunities):
   - Player name/archetype
   - From/To clubs
   - Estimated fee
   - Why this transfer becomes likely
   - Confidence level

5. **Market Ripple Effects**:
   - Affected positions
   - League market shifts
   - Similar player valuations
   - New scouting opportunities

6. **Risk Factors** (3-4):
   - Adaptation risks
   - Market timing risks
   - Performance risks
   - Financial risks

Be realistic using actual football market dynamics, recent transfer trends, and player development patterns.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        immediate_effects: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    effect: { type: "string" },
                                    impact: { type: "string" },
                                    timeline: { type: "string" }
                                }
                            }
                        },
                        agent_commission: {
                            type: "object",
                            properties: {
                                initial_commission_gbp: { type: "number" },
                                projected_career_transfers: { type: "number" },
                                lifetime_earnings_estimate_gbp: { type: "number" },
                                best_case_gbp: { type: "number" },
                                worst_case_gbp: { type: "number" }
                            }
                        },
                        value_trajectory: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    value: { type: "number" },
                                    factors: { type: "string" }
                                }
                            }
                        },
                        cascading_transfers: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player: { type: "string" },
                                    from_club: { type: "string" },
                                    to_club: { type: "string" },
                                    estimated_fee: { type: "number" },
                                    reasoning: { type: "string" },
                                    confidence: { type: "string" }
                                }
                            }
                        },
                        ripple_effects: {
                            type: "object",
                            properties: {
                                affected_positions: { type: "array", items: { type: "string" } },
                                league_shifts: { type: "string" },
                                similar_player_impact: { type: "string" },
                                scouting_opportunities: { type: "string" }
                            }
                        },
                        risk_factors: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    risk: { type: "string" },
                                    severity: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setSimulation(data);
            toast.success('Transfer simulation complete');
        },
        onError: () => {
            toast.error('Simulation failed');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        simulateMutation.mutate(scenario);
    };

    const getConfidenceColor = (confidence) => {
        const colors = {
            'High': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[confidence] || '';
    };

    const getSeverityColor = (severity) => {
        const colors = {
            'High': 'bg-red-500/20 text-red-400 border-red-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[severity] || '';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-purple-400" />
                        Transfer Market Simulator
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400">Player Name *</Label>
                                <Input
                                    value={scenario.player}
                                    onChange={(e) => setScenario({...scenario, player: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder="e.g., Erling Haaland"
                                    required
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400">Transfer Fee (€M) *</Label>
                                <Input
                                    type="number"
                                    value={scenario.transfer_fee}
                                    onChange={(e) => setScenario({...scenario, transfer_fee: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder="75"
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400">From Club *</Label>
                                <Input
                                    value={scenario.from_club}
                                    onChange={(e) => setScenario({...scenario, from_club: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder="e.g., Manchester City"
                                    required
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400">To Club *</Label>
                                <Input
                                    value={scenario.to_club}
                                    onChange={(e) => setScenario({...scenario, to_club: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder="e.g., Real Madrid"
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-400">Additional Context (optional)</Label>
                            <Textarea
                                value={scenario.context}
                                onChange={(e) => setScenario({...scenario, context: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="Age, position, recent performance, contract details..."
                                rows={2}
                            />
                        </div>

                        <Button
                            type="submit"
                            disabled={simulateMutation.isPending}
                            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500"
                        >
                            {simulateMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Simulating...
                                </>
                            ) : (
                                <>
                                    <Zap className="w-4 h-4 mr-2" />
                                    Run Simulation
                                </>
                            )}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            <AnimatePresence>
                {simulation && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Agent Commission Impact */}
                        <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <DollarSign className="w-5 h-5 text-emerald-400" />
                                    Agent Commission Impact
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Initial Commission</p>
                                        <p className="text-emerald-400 text-2xl font-bold">
                                            £{simulation.agent_commission?.initial_commission_gbp?.toLocaleString()}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Lifetime Estimate</p>
                                        <p className="text-purple-400 text-2xl font-bold">
                                            £{simulation.agent_commission?.lifetime_earnings_estimate_gbp?.toLocaleString()}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Projected Transfers</p>
                                        <p className="text-cyan-400 text-2xl font-bold">
                                            {simulation.agent_commission?.projected_career_transfers}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center justify-between text-sm">
                                    <span className="text-slate-400">Best Case:</span>
                                    <span className="text-emerald-400 font-bold">
                                        £{simulation.agent_commission?.best_case_gbp?.toLocaleString()}
                                    </span>
                                </div>
                                <div className="flex items-center justify-between text-sm mt-1">
                                    <span className="text-slate-400">Worst Case:</span>
                                    <span className="text-red-400 font-bold">
                                        £{simulation.agent_commission?.worst_case_gbp?.toLocaleString()}
                                    </span>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Value Trajectory */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                                    Player Value Trajectory
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {simulation.value_trajectory?.map((point, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex justify-between items-center mb-1">
                                                <span className="text-white font-semibold">Year {point.year}</span>
                                                <Badge className="bg-cyan-500/20 text-cyan-400">€{point.value}M</Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{point.factors}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Cascading Transfers */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Users className="w-5 h-5 text-purple-400" />
                                    Cascading Transfer Opportunities
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {simulation.cascading_transfers?.map((transfer, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.05 }}
                                            className="bg-slate-800/50 rounded-lg p-4"
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <h4 className="text-white font-semibold">{transfer.player}</h4>
                                                <Badge className={getConfidenceColor(transfer.confidence)}>
                                                    {transfer.confidence}
                                                </Badge>
                                            </div>
                                            <div className="flex items-center gap-2 text-sm mb-2">
                                                <span className="text-slate-400">{transfer.from_club}</span>
                                                <span className="text-slate-600">→</span>
                                                <span className="text-white font-semibold">{transfer.to_club}</span>
                                                <Badge className="bg-amber-500/20 text-amber-400 ml-auto">
                                                    €{transfer.estimated_fee}M
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{transfer.reasoning}</p>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Ripple Effects & Risks */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Market Ripple Effects</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {simulation.ripple_effects?.affected_positions?.length > 0 && (
                                        <div>
                                            <p className="text-slate-400 text-sm mb-2">Affected Positions:</p>
                                            <div className="flex flex-wrap gap-2">
                                                {simulation.ripple_effects.affected_positions.map((pos, idx) => (
                                                    <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                                        {pos}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">League Shifts:</p>
                                        <p className="text-white text-sm">{simulation.ripple_effects?.league_shifts}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">Similar Player Impact:</p>
                                        <p className="text-white text-sm">{simulation.ripple_effects?.similar_player_impact}</p>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-2">
                                        <AlertTriangle className="w-5 h-5 text-red-400" />
                                        Risk Factors
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {simulation.risk_factors?.map((risk, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex justify-between items-start mb-1">
                                                    <h5 className="text-white text-sm font-semibold">{risk.risk}</h5>
                                                    <Badge className={getSeverityColor(risk.severity)}>
                                                        {risk.severity}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-xs">{risk.mitigation}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Immediate Effects */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Immediate Market Effects</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {simulation.immediate_effects?.map((effect, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3 flex justify-between items-start">
                                            <div className="flex-1">
                                                <p className="text-white text-sm font-semibold mb-1">{effect.effect}</p>
                                                <p className="text-slate-400 text-xs">{effect.impact}</p>
                                            </div>
                                            <Badge className="bg-slate-700 text-slate-300 text-xs ml-2">
                                                {effect.timeline}
                                            </Badge>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}