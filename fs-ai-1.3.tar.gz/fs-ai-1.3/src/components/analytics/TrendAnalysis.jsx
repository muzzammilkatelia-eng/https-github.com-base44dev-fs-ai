import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Calendar } from 'lucide-react';

export default function TrendAnalysis({ players, projections }) {
    const [timeRange, setTimeRange] = useState('12months');
    const [trendType, setTrendType] = useState('performance');

    // Generate trend data
    const marketValueTrend = [
        { month: 'Jan 24', avgValue: 15.2, topPlayers: 42.5 },
        { month: 'Feb 24', avgValue: 16.1, topPlayers: 44.2 },
        { month: 'Mar 24', avgValue: 15.8, topPlayers: 43.8 },
        { month: 'Apr 24', avgValue: 17.2, topPlayers: 46.1 },
        { month: 'May 24', avgValue: 18.5, topPlayers: 48.3 },
        { month: 'Jun 24', avgValue: 19.2, topPlayers: 50.1 },
        { month: 'Jul 24', avgValue: 18.9, topPlayers: 49.5 },
        { month: 'Aug 24', avgValue: 20.1, topPlayers: 52.2 },
        { month: 'Sep 24', avgValue: 21.3, topPlayers: 54.8 },
        { month: 'Oct 24', avgValue: 22.5, topPlayers: 56.3 },
        { month: 'Nov 24', avgValue: 23.1, topPlayers: 58.1 },
        { month: 'Dec 24', avgValue: 24.2, topPlayers: 60.5 }
    ];

    const performanceTrend = [
        { month: 'Jan 24', avgScore: 72, highPotential: 85 },
        { month: 'Feb 24', avgScore: 74, highPotential: 86 },
        { month: 'Mar 24', avgScore: 73, highPotential: 87 },
        { month: 'Apr 24', avgScore: 75, highPotential: 88 },
        { month: 'May 24', avgScore: 76, highPotential: 89 },
        { month: 'Jun 24', avgScore: 77, highPotential: 89 },
        { month: 'Jul 24', avgScore: 78, highPotential: 90 },
        { month: 'Aug 24', avgScore: 79, highPotential: 91 },
        { month: 'Sep 24', avgScore: 80, highPotential: 91 },
        { month: 'Oct 24', avgScore: 81, highPotential: 92 },
        { month: 'Nov 24', avgScore: 82, highPotential: 92 },
        { month: 'Dec 24', avgScore: 83, highPotential: 93 }
    ];

    const positionTrends = [
        { position: 'Striker', growth: 12.5, avgValue: 28.5 },
        { position: 'Winger', growth: 15.2, avgValue: 32.1 },
        { position: 'CAM', growth: 8.7, avgValue: 25.3 },
        { position: 'CM', growth: 6.4, avgValue: 22.8 },
        { position: 'DM', growth: 5.1, avgValue: 18.9 },
        { position: 'Full-Back', growth: 9.3, avgValue: 19.5 },
        { position: 'CB', growth: 7.8, avgValue: 21.2 },
        { position: 'GK', growth: 4.2, avgValue: 15.7 }
    ];

    const trendData = trendType === 'performance' ? performanceTrend : marketValueTrend;

    return (
        <div className="space-y-6">
            {/* Filters */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="flex gap-4">
                        <Select value={timeRange} onValueChange={setTimeRange}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="3months">Last 3 Months</SelectItem>
                                <SelectItem value="6months">Last 6 Months</SelectItem>
                                <SelectItem value="12months">Last 12 Months</SelectItem>
                                <SelectItem value="24months">Last 24 Months</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={trendType} onValueChange={setTrendType}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="performance">Performance Trends</SelectItem>
                                <SelectItem value="market">Market Value Trends</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Main Trend Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        {trendType === 'performance' ? 'Performance Trends' : 'Market Value Trends'}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                        <AreaChart data={trendData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Legend />
                            {trendType === 'performance' ? (
                                <>
                                    <Area type="monotone" dataKey="avgScore" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} name="Avg Score" />
                                    <Area type="monotone" dataKey="highPotential" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} name="High Potential" />
                                </>
                            ) : (
                                <>
                                    <Area type="monotone" dataKey="avgValue" stroke="#10b981" fill="#10b981" fillOpacity={0.3} name="Avg Value (€M)" />
                                    <Area type="monotone" dataKey="topPlayers" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} name="Top Players (€M)" />
                                </>
                            )}
                        </AreaChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Position-Based Trends */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Position-Based Growth Trends</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {positionTrends.map((trend) => (
                            <div key={trend.position} className="bg-slate-800/50 rounded-lg p-4">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-white font-semibold">{trend.position}</p>
                                    <div className="flex items-center gap-3">
                                        <Badge className={
                                            trend.growth > 10 ? 'bg-emerald-500/20 text-emerald-400' :
                                            trend.growth > 7 ? 'bg-blue-500/20 text-blue-400' :
                                            'bg-amber-500/20 text-amber-400'
                                        }>
                                            {trend.growth > 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                                            {trend.growth}% growth
                                        </Badge>
                                        <p className="text-slate-400 text-sm">Avg €{trend.avgValue}M</p>
                                    </div>
                                </div>
                                <div className="w-full bg-slate-700 rounded-full h-2">
                                    <div
                                        className="bg-gradient-to-r from-cyan-500 to-blue-600 h-2 rounded-full"
                                        style={{ width: `${Math.min(trend.growth * 5, 100)}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Key Insights */}
            <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <TrendingUp className="w-8 h-8 text-emerald-400 mb-3" />
                        <p className="text-slate-400 text-sm">Fastest Growing Position</p>
                        <p className="text-2xl font-bold text-white">Wingers</p>
                        <p className="text-emerald-400 text-sm">+15.2% value increase</p>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/30">
                    <CardContent className="pt-6">
                        <Calendar className="w-8 h-8 text-blue-400 mb-3" />
                        <p className="text-slate-400 text-sm">Best Performing Period</p>
                        <p className="text-2xl font-bold text-white">Q4 2024</p>
                        <p className="text-blue-400 text-sm">Peak performance scores</p>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border-purple-500/30">
                    <CardContent className="pt-6">
                        <TrendingUp className="w-8 h-8 text-purple-400 mb-3" />
                        <p className="text-slate-400 text-sm">Overall Database Growth</p>
                        <p className="text-2xl font-bold text-white">+42%</p>
                        <p className="text-purple-400 text-sm">Year-over-year</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}