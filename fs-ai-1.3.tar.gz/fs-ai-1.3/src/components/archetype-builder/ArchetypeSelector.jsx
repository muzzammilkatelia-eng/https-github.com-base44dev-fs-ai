import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Zap, Loader2, Target } from 'lucide-react';
import toast from 'react-hot-toast';

const ARCHETYPES = [
    {
        id: 'gegenpress',
        name: 'High Pressing Gegenpress',
        formation: '4-3-3',
        description: 'Intense pressing after losing possession, rapid transitions, high energy',
        keyAttributes: ['Physical Dominance', 'Tactical Awareness', 'Mental Fortitude'],
        requiredRoles: ['Box-to-Box Midfielder', 'Pressing Forward', 'Aggressive Full-Back']
    },
    {
        id: 'tiki-taka',
        name: 'Possession-Based Tiki-Taka',
        formation: '4-3-3',
        description: 'Short passing, positional play, controlling tempo through possession',
        keyAttributes: ['Technical Mastery', 'Tactical Awareness', 'Mental Fortitude'],
        requiredRoles: ['Deep-Lying Playmaker', 'Ball-Playing Centre-Back', 'Inverted Winger']
    },
    {
        id: 'counter-attack',
        name: 'Counter-Attacking',
        formation: '4-4-2',
        description: 'Compact defensive block, explosive transitions, pace on the break',
        keyAttributes: ['Physical Dominance', 'Development Velocity', 'Tactical Awareness'],
        requiredRoles: ['Target Man', 'Speedster Winger', 'Defensive Midfielder']
    },
    {
        id: 'total-football',
        name: 'Total Football',
        formation: '3-4-3',
        description: 'Fluid positions, tactical versatility, all players can attack/defend',
        keyAttributes: ['Tactical Awareness', 'Technical Mastery', 'Archetype Purity'],
        requiredRoles: ['Complete Wing-Back', 'False Nine', 'Ball-Playing Defender']
    },
    {
        id: 'pragmatic',
        name: 'Pragmatic/Results-Oriented',
        formation: '4-2-3-1',
        description: 'Adaptable system, solid defensive base, clinical in key moments',
        keyAttributes: ['Mental Fortitude', 'Tactical Awareness', 'Market Efficiency'],
        requiredRoles: ['Holding Midfielder', 'Clinical Striker', 'Versatile Midfielder']
    },
    {
        id: 'wing-play',
        name: 'Wing-Oriented Attack',
        formation: '4-2-3-1',
        description: 'Width-focused, crossing game, dominant wide players',
        keyAttributes: ['Physical Dominance', 'Technical Mastery', 'Development Velocity'],
        requiredRoles: ['Traditional Winger', 'Overlapping Full-Back', 'Aerial Striker']
    }
];

export default function ArchetypeSelector({ selectedArchetype, onSelectArchetype, onGenerateSuggestions, players }) {
    const [isGenerating, setIsGenerating] = useState(false);

    const generateSuggestions = async (archetype) => {
        setIsGenerating(true);
        toast.loading('AI analyzing player fits...', { id: 'suggestions' });

        try {
            const prompt = `You are the FS-AI Team Builder. Find the best players for this archetype.

ARCHETYPE: ${archetype.name}
Formation: ${archetype.formation}
Style: ${archetype.description}
Key Attributes: ${archetype.keyAttributes.join(', ')}
Required Roles: ${archetype.requiredRoles.join(', ')}

AVAILABLE PLAYERS (${players.length} with FS-AI scores):
${players.slice(0, 50).map(p => `
- ${p.name} (${p.position}, ${p.age}y) | FS-AI: ${p.fsai_proprietary_score} | Grade: ${p.fsai_investment_grade || 'N/A'}
  League: ${p.league} | Style: ${p.playing_style?.preferred_foot || 'N/A'} | Roles: ${p.tactical_roles?.join(', ') || 'N/A'}
`).join('\n')}

Task: Recommend the TOP 15 players that best fit this archetype.

For each player provide:
- Name
- Position
- Fit Score (0-100): How well they fit the archetype
- Role in System: Specific tactical role
- Why They Fit: 1-2 sentence explanation

Prioritize players with high FS-AI scores AND strong archetype alignment.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    fit_score: { type: "number" },
                                    role_in_system: { type: "string" },
                                    why_they_fit: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            onGenerateSuggestions(response.recommendations);
            toast.success('Suggestions generated!', { id: 'suggestions' });
        } catch (error) {
            console.error('Failed to generate suggestions:', error);
            toast.error('Failed to generate suggestions', { id: 'suggestions' });
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSelectArchetype = (archetype) => {
        onSelectArchetype(archetype);
        generateSuggestions(archetype);
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800 h-full">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-purple-400" />
                    Select Team Archetype
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3 max-h-[70vh] overflow-y-auto">
                    {ARCHETYPES.map((archetype) => (
                        <button
                            key={archetype.id}
                            onClick={() => handleSelectArchetype(archetype)}
                            disabled={isGenerating}
                            className={`w-full text-left p-4 rounded-lg border transition-all ${
                                selectedArchetype?.id === archetype.id
                                    ? 'bg-purple-500/20 border-purple-500/50'
                                    : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                            }`}
                        >
                            <div className="flex items-start justify-between mb-2">
                                <h3 className="text-white font-semibold">{archetype.name}</h3>
                                <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                    {archetype.formation}
                                </Badge>
                            </div>
                            <p className="text-slate-400 text-sm mb-3">{archetype.description}</p>
                            <div className="flex flex-wrap gap-1">
                                {archetype.keyAttributes.map((attr, idx) => (
                                    <Badge key={idx} className="bg-slate-700 text-slate-300 text-xs">
                                        {attr}
                                    </Badge>
                                ))}
                            </div>
                        </button>
                    ))}
                </div>

                {isGenerating && (
                    <div className="mt-4 flex items-center justify-center">
                        <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
                    </div>
                )}
            </CardContent>
        </Card>
    );
}