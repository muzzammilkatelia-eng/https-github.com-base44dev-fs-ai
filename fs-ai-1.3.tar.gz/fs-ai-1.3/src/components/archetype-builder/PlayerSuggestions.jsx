import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Plus, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PlayerSuggestions({ suggestions, selectedPlayers, onAddPlayer }) {
    if (!suggestions || suggestions.length === 0) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6 text-center">
                    <Sparkles className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">Select an archetype to see AI-powered player suggestions</p>
                </CardContent>
            </Card>
        );
    }

    const isSelected = (playerName) => selectedPlayers.some(p => p.name === playerName);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                    AI Recommendations ({suggestions.length})
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                    {suggestions.map((suggestion, idx) => (
                        <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            className="bg-slate-800/50 rounded-lg p-4"
                        >
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-1">
                                        <h4 className="text-white font-semibold">{suggestion.player_name}</h4>
                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                            {suggestion.position}
                                        </Badge>
                                    </div>
                                    <Badge className={`${
                                        suggestion.fit_score >= 85 ? 'bg-emerald-500/20 text-emerald-400' :
                                        suggestion.fit_score >= 70 ? 'bg-cyan-500/20 text-cyan-400' :
                                        'bg-amber-500/20 text-amber-400'
                                    } text-xs mb-2`}>
                                        {suggestion.fit_score}% Fit
                                    </Badge>
                                    <p className="text-purple-400 text-sm font-medium mb-2">
                                        {suggestion.role_in_system}
                                    </p>
                                    <p className="text-slate-400 text-sm">{suggestion.why_they_fit}</p>
                                </div>
                                <Button
                                    onClick={() => {
                                        const player = selectedPlayers.find(p => p.name === suggestion.player_name);
                                        if (!player) {
                                            // Need to find actual player object - this is a simplified version
                                            onAddPlayer({ name: suggestion.player_name, position: suggestion.position });
                                        }
                                    }}
                                    disabled={isSelected(suggestion.player_name)}
                                    size="sm"
                                    className={isSelected(suggestion.player_name) 
                                        ? 'bg-emerald-500/20 text-emerald-400'
                                        : 'bg-purple-500 hover:bg-purple-600'
                                    }
                                >
                                    {isSelected(suggestion.player_name) ? (
                                        <CheckCircle className="w-4 h-4" />
                                    ) : (
                                        <Plus className="w-4 h-4" />
                                    )}
                                </Button>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}