import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, X, Zap, Loader2, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TeamComposition({ 
    selectedPlayers, 
    selectedArchetype, 
    teamFit, 
    onRemovePlayer, 
    onAnalyze, 
    isAnalyzing 
}) {
    return (
        <div className="space-y-6">
            {/* Selected Squad */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-5 h-5 text-cyan-400" />
                            Your Squad ({selectedPlayers.length})
                        </CardTitle>
                        {selectedPlayers.length >= 5 && (
                            <Button
                                onClick={onAnalyze}
                                disabled={isAnalyzing}
                                className="bg-gradient-to-r from-purple-500 to-blue-600"
                            >
                                {isAnalyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Zap className="w-4 h-4 mr-2" />
                                        Analyze Team Fit
                                    </>
                                )}
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent>
                    {selectedPlayers.length === 0 ? (
                        <div className="text-center py-8">
                            <Users className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">No players selected yet</p>
                            <p className="text-slate-500 text-sm mt-1">Add players from the suggestions above</p>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {selectedPlayers.map((player, idx) => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="bg-slate-800/50 rounded-lg p-3 flex items-center justify-between"
                                >
                                    <div className="flex items-center gap-3">
                                        <span className="text-slate-500 font-mono text-sm">{idx + 1}</span>
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="text-white font-semibold">{player.name}</h4>
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    {player.position}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-xs">{player.current_club}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        {player.fsai_proprietary_score && (
                                            <div className="text-right">
                                                <p className={`text-lg font-bold ${
                                                    player.fsai_proprietary_score >= 85 ? 'text-emerald-400' :
                                                    player.fsai_proprietary_score >= 70 ? 'text-cyan-400' :
                                                    'text-amber-400'
                                                }`}>
                                                    {player.fsai_proprietary_score}
                                                </p>
                                                <p className="text-slate-500 text-xs">FS-AI</p>
                                            </div>
                                        )}
                                        <Button
                                            onClick={() => onRemovePlayer(player.id)}
                                            variant="ghost"
                                            size="sm"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Team Fit Analysis */}
            {teamFit && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Overall Score */}
                    <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="text-center mb-6">
                                <p className="text-slate-400 text-sm mb-2">Overall Team Fit</p>
                                <p className={`text-6xl font-bold ${
                                    teamFit.overall_team_fit >= 85 ? 'text-emerald-400' :
                                    teamFit.overall_team_fit >= 70 ? 'text-cyan-400' :
                                    'text-amber-400'
                                }`}>
                                    {teamFit.overall_team_fit}
                                </p>
                                <p className="text-slate-500 text-sm mt-1">/{selectedArchetype.name}</p>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {[
                                    { key: 'positional_balance', label: 'Balance' },
                                    { key: 'tactical_cohesion', label: 'Cohesion' },
                                    { key: 'experience_mix', label: 'Experience' },
                                    { key: 'chemistry_potential', label: 'Chemistry' }
                                ].map(({ key, label }) => (
                                    <div key={key} className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">{label}</p>
                                        <p className="text-2xl font-bold text-white">{teamFit[key]}</p>
                                        <div className="mt-2 w-full bg-slate-700 rounded-full h-1.5">
                                            <div
                                                className="bg-purple-500 h-1.5 rounded-full"
                                                style={{ width: `${teamFit[key]}%` }}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Analysis Details */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 flex items-center gap-2 text-lg">
                                    <CheckCircle className="w-5 h-5" />
                                    Key Strengths
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {teamFit.key_strengths?.map((strength, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400 mt-0.5">✓</span>
                                            {strength}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400 flex items-center gap-2 text-lg">
                                    <AlertTriangle className="w-5 h-5" />
                                    Weak Points
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {teamFit.weak_points?.map((weakness, idx) => (
                                        <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-amber-400 mt-0.5">⚠</span>
                                            {weakness}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Missing Profiles */}
                    {teamFit.missing_profiles && teamFit.missing_profiles.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-purple-400" />
                                    Missing Profiles
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {teamFit.missing_profiles.map((profile, idx) => (
                                        <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                            {profile}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Tactical Analysis */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Tactical Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                {teamFit.tactical_analysis}
                            </p>
                        </CardContent>
                    </Card>

                    {/* Recommendations */}
                    <Card className="bg-blue-500/10 border-blue-500/30">
                        <CardHeader>
                            <CardTitle className="text-blue-400">Recommended Adjustments</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">
                                {teamFit.recommended_adjustments}
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}