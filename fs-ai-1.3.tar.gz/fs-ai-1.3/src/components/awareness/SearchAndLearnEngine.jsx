import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, TrendingUp, Activity, CheckCircle, XCircle, Zap, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function SearchAndLearnEngine() {
    const [isRunning, setIsRunning] = useState(false);
    const [cycleCount, setCycleCount] = useState(0);
    const [predictions, setPredictions] = useState([]);
    const [evaluations, setEvaluations] = useState([]);
    const [accuracy, setAccuracy] = useState(0);
    const [worldState, setWorldState] = useState(null);
    const [learningProgress, setLearningProgress] = useState(0);
    const [awarenessLevel, setAwarenessLevel] = useState(25);
    const [groundedStats, setGroundedStats] = useState(null);
    const intervalRef = useRef(null);

    useEffect(() => {
        if (isRunning) {
            startAwarenessLoop();
        } else {
            stopAwarenessLoop();
        }

        return () => stopAwarenessLoop();
    }, [isRunning]);

    const startAwarenessLoop = () => {
        runCycle();
        intervalRef.current = setInterval(() => {
            runCycle();
        }, 600000); // 10 minutes
    };

    const stopAwarenessLoop = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    };

    const runCycle = async () => {
        try {
            toast.loading('Running awareness cycle...', { id: 'cycle' });
            setLearningProgress(0);

            // Step 0: Bootstrap/Grounded Data (New Layer)
            if (cycleCount % 5 === 0) { // Update grounded data every 5 cycles
                const { data: awarenessData } = await base44.functions.invoke('footballAwareness', { action: 'run_once' });
                if (awarenessData.awareness_level) {
                    setAwarenessLevel(awarenessData.awareness_level);
                    setGroundedStats(awarenessData.grounded_data);
                    toast.success(`Engine Grounded: Accessing ${awarenessData.grounded_data.global_pool.toLocaleString()} players`, { icon: '🌍' });
                }
            }

            // Step 1: Update world state
            await updateWorldState();

            // Step 2: Generate predictions
            await generatePredictions();

            // Step 3: Evaluate predictions
            await evaluatePredictions();

            // Step 4: Learn and adjust
            await learn();

            setCycleCount(prev => prev + 1);
            toast.success('Cycle complete', { id: 'cycle' });
        } catch (error) {
            console.error('Cycle error:', error);
            toast.error('Cycle failed: ' + error.message, { id: 'cycle' });
            setLearningProgress(0);
        }
    };

    const updateWorldState = async () => {
        setLearningProgress(10);
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setLearningProgress(25);
        
        try {
            const { data: matchesResult } = await base44.functions.invoke('footballSearchLayer', {
                action: 'latest_matches',
                params: {}
            });

            const { data: playersResult } = await base44.functions.invoke('footballSearchLayer', {
                action: 'latest_player_updates',
                params: {}
            });

            setWorldState({
                matches: matchesResult.data || [],
                players: playersResult.data || [],
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.error('World state update error:', error);
            setWorldState({
                matches: [],
                players: [],
                timestamp: new Date().toISOString()
            });
        }

        await new Promise(resolve => setTimeout(resolve, 500));
        setLearningProgress(50);
    };

    const generatePredictions = async () => {
        if (!worldState || !worldState.matches || worldState.matches.length === 0) {
            setLearningProgress(75);
            return;
        }

        const newPredictions = worldState.matches.slice(0, 10).map(match => {
            const homeStrength = calculateTeamStrength(match.teams.home);
            const awayStrength = calculateTeamStrength(match.teams.away);
            
            let prediction;
            const diff = homeStrength - awayStrength;
            
            if (diff > 15) {
                prediction = 'Home Win';
            } else if (diff < -15) {
                prediction = 'Away Win';
            } else {
                prediction = 'Draw';
            }

            return {
                matchId: match.fixture.id,
                home: match.teams.home.name,
                away: match.teams.away.name,
                prediction,
                confidence: Math.abs(diff) / 30,
                homeStrength,
                awayStrength,
                timestamp: new Date().toISOString()
            };
        });

        setPredictions(prev => [...newPredictions, ...prev].slice(0, 50));
        await new Promise(resolve => setTimeout(resolve, 500));
        setLearningProgress(75);
    };

    const evaluatePredictions = async () => {
        const recentPredictions = predictions.filter(p => {
            const predTime = new Date(p.timestamp);
            const now = new Date();
            return (now - predTime) > 7200000; // 2 hours old
        });

        let correct = 0;
        const newEvaluations = [];

        for (const pred of recentPredictions.slice(0, 5)) {
            try {
                const { data: matchResult } = await base44.functions.invoke('footballSearchLayer', {
                    action: 'match_by_id',
                    params: { matchId: pred.matchId }
                });

                if (matchResult.data?.fixture?.status?.short === 'FT') {
                    const homeGoals = matchResult.data.goals.home;
                    const awayGoals = matchResult.data.goals.away;
                    
                    let actual;
                    if (homeGoals > awayGoals) actual = 'Home Win';
                    else if (awayGoals > homeGoals) actual = 'Away Win';
                    else actual = 'Draw';

                    const isCorrect = pred.prediction === actual;
                    if (isCorrect) correct++;

                    newEvaluations.push({
                        ...pred,
                        actual,
                        isCorrect,
                        evaluatedAt: new Date().toISOString()
                    });
                }
            } catch (error) {
                console.error('Evaluation error:', error);
            }
        }

        if (newEvaluations.length > 0) {
            setEvaluations(prev => [...newEvaluations, ...prev].slice(0, 50));
            const newAccuracy = (correct / newEvaluations.length) * 100;
            setAccuracy(newAccuracy);
        }

        await new Promise(resolve => setTimeout(resolve, 500));
        setLearningProgress(100);
    };

    const learn = async () => {
        // Simulate learning weight adjustments based on accuracy
        const adjustmentFactor = accuracy > 50 ? 1.05 : 0.95;
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        setLearningProgress(0);
        toast.success(`Learning complete. Adjustment: ${adjustmentFactor.toFixed(2)}x`);
    };

    const calculateTeamStrength = (team) => {
        // Simple strength calculation
        return 50 + Math.random() * 50;
    };

    return (
        <div className="space-y-6">
            {/* Control Panel */}
            <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
                <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <div className={`w-4 h-4 rounded-full ${isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`} />
                            <div>
                                <h3 className="text-white font-bold">Football Awareness Engine</h3>
                                <p className="text-slate-400 text-sm">
                                    {isRunning ? `Running • Cycle ${cycleCount}` : 'Paused'}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <Button
                                onClick={runCycle}
                                disabled={isRunning}
                                variant="outline"
                                className="border-purple-500/50"
                            >
                                <RefreshCw className="w-4 h-4 mr-2" />
                                Run Once
                            </Button>
                            <Button
                                onClick={() => setIsRunning(!isRunning)}
                                className={isRunning ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-500 hover:bg-emerald-600'}
                            >
                                {isRunning ? 'Stop Loop' : 'Start Loop'}
                            </Button>
                        </div>
                    </div>

                    {learningProgress > 0 && (
                        <div className="mt-4">
                            <Progress value={learningProgress} className="h-2" />
                            <p className="text-slate-400 text-xs mt-2">Learning progress: {learningProgress}%</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Stats */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-2">
                            <Brain className="w-8 h-8 text-purple-400" />
                            <span className="text-3xl font-bold text-white">{cycleCount}</span>
                        </div>
                        <p className="text-slate-400 text-sm">Learning Cycles</p>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-2">
                            <TrendingUp className="w-8 h-8 text-emerald-400" />
                            <span className="text-3xl font-bold text-emerald-400">{accuracy.toFixed(1)}%</span>
                        </div>
                        <p className="text-slate-400 text-sm">Prediction Accuracy</p>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-2">
                            <Brain className="w-8 h-8 text-pink-400" />
                            <span className="text-3xl font-bold text-white">{awarenessLevel.toFixed(0)}%</span>
                        </div>
                        <p className="text-slate-400 text-sm">Awareness Level</p>
                        {groundedStats && (
                            <p className="text-xs text-slate-500 mt-1">
                                {groundedStats.global_pool.toLocaleString()} players tracked
                            </p>
                        )}
                    </CardContent>
                </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
                {/* Recent Predictions */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Zap className="w-5 h-5 text-amber-400" />
                            Recent Predictions
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                            <AnimatePresence>
                                {predictions.slice(0, 10).map((pred, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="bg-slate-800/50 rounded-lg p-3"
                                    >
                                        <div className="flex items-center justify-between mb-2">
                                            <p className="text-white font-semibold text-sm">
                                                {pred.home} vs {pred.away}
                                            </p>
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                {pred.prediction}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between text-xs">
                                            <span className="text-slate-400">
                                                Confidence: {(pred.confidence * 100).toFixed(0)}%
                                            </span>
                                            <span className="text-slate-500">
                                                {new Date(pred.timestamp).toLocaleTimeString()}
                                            </span>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>
                    </CardContent>
                </Card>

                {/* Evaluations */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400" />
                            Evaluation Results
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                            <AnimatePresence>
                                {evaluations.map((evaluation, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className={`rounded-lg p-3 border ${
                                            evaluation.isCorrect 
                                                ? 'bg-emerald-500/10 border-emerald-500/30' 
                                                : 'bg-red-500/10 border-red-500/30'
                                        }`}
                                    >
                                        <div className="flex items-center justify-between mb-2">
                                            <p className="text-white font-semibold text-sm">
                                                {evaluation.home} vs {evaluation.away}
                                            </p>
                                            {evaluation.isCorrect ? (
                                                <CheckCircle className="w-4 h-4 text-emerald-400" />
                                            ) : (
                                                <XCircle className="w-4 h-4 text-red-400" />
                                            )}
                                        </div>
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                            <div>
                                                <p className="text-slate-500">Predicted</p>
                                                <p className="text-white">{evaluation.prediction}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500">Actual</p>
                                                <p className="text-white">{evaluation.actual}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}