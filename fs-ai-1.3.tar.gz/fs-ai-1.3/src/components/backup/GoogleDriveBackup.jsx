import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Cloud, CheckCircle2, Loader2, FileText, Shield, Folder } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function GoogleDriveBackup() {
    const [documentType, setDocumentType] = useState('all');
    const [backupResult, setBackupResult] = useState(null);

    const backupMutation = useMutation({
        mutationFn: async () => {
            const response = await base44.functions.invoke('backupToGoogleDrive', { 
                documentType 
            });
            return response.data;
        },
        onSuccess: (data) => {
            setBackupResult(data);
            toast.success(`${data.files_uploaded} documents backed up to Google Drive!`);
        },
        onError: () => {
            toast.error('Failed to backup documents');
        }
    });

    const handleBackup = () => {
        backupMutation.mutate();
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-blue-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Cloud className="w-5 h-5 text-blue-400" />
                        Google Drive Backup
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-slate-300 text-sm">
                        Automatically backup your scouting reports, contracts, and other documents to Google Drive for safekeeping.
                    </p>

                    <div>
                        <label className="text-slate-400 text-sm mb-2 block">Document Type</label>
                        <Select value={documentType} onValueChange={setDocumentType}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Documents</SelectItem>
                                <SelectItem value="scouting_reports">Scouting Reports</SelectItem>
                                <SelectItem value="contracts">Contracts</SelectItem>
                                <SelectItem value="secure_documents">Secure Documents</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <Button
                        onClick={handleBackup}
                        disabled={backupMutation.isPending}
                        className="w-full bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-400 hover:to-cyan-500"
                    >
                        {backupMutation.isPending ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Backing up...
                            </>
                        ) : (
                            <>
                                <Cloud className="w-4 h-4 mr-2" />
                                Backup to Google Drive
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            <AnimatePresence>
                {backupResult && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                    >
                        <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                    Backup Successful
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <FileText className="w-6 h-6 text-cyan-400 mb-2" />
                                        <p className="text-slate-400 text-xs">Files Uploaded</p>
                                        <p className="text-2xl font-bold text-white">{backupResult.files_uploaded}</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <Folder className="w-6 h-6 text-blue-400 mb-2" />
                                        <p className="text-slate-400 text-xs">Folder</p>
                                        <p className="text-white text-sm font-semibold truncate">{backupResult.folder_name}</p>
                                    </div>
                                </div>

                                <Button
                                    onClick={() => window.open(`https://drive.google.com/drive/folders/${backupResult.folder_id}`, '_blank')}
                                    variant="outline"
                                    className="w-full border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                                >
                                    <Folder className="w-4 h-4 mr-2" />
                                    Open in Google Drive
                                </Button>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}