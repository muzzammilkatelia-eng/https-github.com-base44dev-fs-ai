import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MessageCircle, X, Send, Loader2, Minimize2, Maximize2, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';
import TeamBuildingChatbot from './TeamBuildingChatbot';

export default function GlobalChatbot() {
    const [isOpen, setIsOpen] = useState(false);
    const [isMinimized, setIsMinimized] = useState(false);
    const [teamBuildingOpen, setTeamBuildingOpen] = useState(false);
    const [messages, setMessages] = useState([
        { role: 'assistant', content: 'Hello! I\'m your FS-AI assistant. Ask me anything about football scouting, players, or how to use the platform!\n\nNeed team building advice? Click the Team Building AI button above! 🏆' }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || loading) return;

        const userMessage = input.trim();
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setLoading(true);

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are the FS-AI Football Scout Intelligence assistant. You help users with:
- Understanding football scouting concepts
- Finding and analyzing players
- Using FS-AI platform features
- Interpreting player ratings and projections
- Transfer market insights

Be helpful, concise, and football-focused. If asked about players not in the system, provide general guidance.

User: ${userMessage}`,
                add_context_from_internet: false
            });

            setMessages(prev => [...prev, { role: 'assistant', content: response }]);
        } catch (error) {
            console.error('Chatbot error:', error);
            toast.error('Failed to get response');
            setMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            {/* Floating Button */}
            <AnimatePresence>
                {!isOpen && (
                    <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="fixed bottom-6 right-6 z-50"
                    >
                        <Button
                            onClick={() => setIsOpen(true)}
                            className="w-14 h-14 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 shadow-2xl"
                        >
                            <MessageCircle className="w-6 h-6 text-white" />
                        </Button>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Chat Window */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ scale: 0.8, opacity: 0, y: 20 }}
                        animate={{ scale: 1, opacity: 1, y: 0 }}
                        exit={{ scale: 0.8, opacity: 0, y: 20 }}
                        className="fixed bottom-6 right-6 z-50"
                    >
                        <Card className={`bg-slate-900 border-cyan-500/30 shadow-2xl ${isMinimized ? 'w-80' : 'w-96 h-[600px]'} flex flex-col`}>
                            <CardHeader className="border-b border-slate-800 py-3">
                                <div className="flex items-center justify-between">
                                    <CardTitle className="text-white text-base flex items-center gap-2">
                                        <MessageCircle className="w-5 h-5 text-cyan-400" />
                                        FS-AI Assistant
                                    </CardTitle>
                                    <div className="flex items-center gap-2">
                                        <Button
                                            onClick={() => {
                                                setIsOpen(false);
                                                setTeamBuildingOpen(true);
                                            }}
                                            size="sm"
                                            className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 h-7 text-xs"
                                        >
                                            <Users className="w-3 h-3 mr-1" />
                                            Team Building AI
                                        </Button>
                                        <Button
                                            onClick={() => setIsMinimized(!isMinimized)}
                                            variant="ghost"
                                            size="icon"
                                            className="h-7 w-7 text-slate-400 hover:text-white"
                                        >
                                            {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
                                        </Button>
                                        <Button
                                            onClick={() => setIsOpen(false)}
                                            variant="ghost"
                                            size="icon"
                                            className="h-7 w-7 text-slate-400 hover:text-white"
                                        >
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>

                            {!isMinimized && (
                                <>
                                    <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                                        {messages.map((msg, idx) => (
                                            <div
                                                key={idx}
                                                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                            >
                                                <div
                                                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                                                        msg.role === 'user'
                                                            ? 'bg-cyan-600 text-white'
                                                            : 'bg-slate-800 text-slate-200'
                                                    }`}
                                                >
                                                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                                                </div>
                                            </div>
                                        ))}
                                        {loading && (
                                            <div className="flex justify-start">
                                                <div className="bg-slate-800 rounded-lg px-4 py-2">
                                                    <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                                                </div>
                                            </div>
                                        )}
                                        <div ref={messagesEndRef} />
                                    </CardContent>

                                    <div className="p-4 border-t border-slate-800">
                                        <div className="flex gap-2">
                                            <Input
                                                value={input}
                                                onChange={(e) => setInput(e.target.value)}
                                                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                                                placeholder="Ask me anything..."
                                                className="bg-slate-800 border-slate-700 text-white"
                                                disabled={loading}
                                            />
                                            <Button
                                                onClick={handleSend}
                                                disabled={loading || !input.trim()}
                                                className="bg-cyan-600 hover:bg-cyan-700"
                                            >
                                                <Send className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </>
                            )}

                            {isMinimized && (
                                <CardContent className="p-3">
                                    <p className="text-slate-400 text-sm text-center">
                                        Click to expand chat
                                    </p>
                                </CardContent>
                            )}
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Team Building Chatbot Modal */}
            <TeamBuildingChatbot open={teamBuildingOpen} onClose={() => setTeamBuildingOpen(false)} />
        </>
    );
}