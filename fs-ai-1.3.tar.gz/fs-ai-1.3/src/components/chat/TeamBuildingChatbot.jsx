import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, X, Send, Loader2, Mic, MicOff, Users, TrendingUp, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';
import { useQuery } from '@tanstack/react-query';

export default function TeamBuildingChatbot({ open, onClose }) {
    const [messages, setMessages] = useState([
        { 
            role: 'assistant', 
            content: '👋 Hello! I\'m your FA-compliant Team Building Assistant powered by Hume AI.\n\nI can help you:\n• Build optimal squads within budget\n• Find players that fit your formation\n• Ensure tactical synergy\n• Comply with FA regulations\n\nTell me about your current squad or desired formation!' 
        }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const [voiceEnabled, setVoiceEnabled] = useState(false);
    const messagesEndRef = useRef(null);
    const recognitionRef = useRef(null);

    const { data: players = [] } = useQuery({
        queryKey: ['players-team-building'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    // Initialize speech recognition
    useEffect(() => {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognitionRef.current = new SpeechRecognition();
            recognitionRef.current.continuous = false;
            recognitionRef.current.interimResults = false;

            recognitionRef.current.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                setInput(transcript);
                setIsListening(false);
            };

            recognitionRef.current.onerror = () => {
                setIsListening(false);
                toast.error('Voice recognition failed');
            };

            recognitionRef.current.onend = () => {
                setIsListening(false);
            };
        }
    }, []);

    const toggleVoiceInput = () => {
        if (!recognitionRef.current) {
            toast.error('Voice recognition not supported');
            return;
        }

        if (isListening) {
            recognitionRef.current.stop();
            setIsListening(false);
        } else {
            recognitionRef.current.start();
            setIsListening(true);
            toast.success('Listening...');
        }
    };

    const handleSend = async () => {
        if (!input.trim() || loading) return;

        const userMessage = input.trim();
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setLoading(true);

        try {
            // Prepare player data context
            const playerContext = players.slice(0, 50).map(p => ({
                name: p.name,
                position: p.position,
                age: p.age,
                club: p.current_club,
                value: p.market_value,
                rating: p.fsai_proprietary_score,
                nationality: p.nationality
            }));

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an FA-compliant Team Building AI Assistant for FS-AI Football Scout Intelligence.

**YOUR ROLE:**
- Provide tactical squad building advice
- Recommend players that fit formations and playing styles
- Consider budget constraints and player synergy
- Ensure all advice complies with FA Laws of the Game and regulations
- Explain player suitability and tactical reasoning

**FA COMPLIANCE RULES:**
- Maximum 25-player squad for Premier League
- Minimum 8 homegrown players in 25-man squad
- Under-21 players don't count toward squad limits
- Financial Fair Play considerations
- Respect work permit requirements
- Adhere to transfer window regulations

**AVAILABLE PLAYER DATABASE (Top 50):**
${JSON.stringify(playerContext, null, 2)}

**USER REQUEST:**
${userMessage}

**INSTRUCTIONS:**
1. Analyze the user's squad needs or formation request
2. Recommend 3-5 specific players from the database
3. Explain tactical fit, synergy, and budget considerations
4. Ensure FA compliance in all recommendations
5. Be conversational, helpful, and football-focused
6. Format recommendations clearly with player details

Provide actionable, FA-compliant team building advice.`,
                add_context_from_internet: false
            });

            setMessages(prev => [...prev, { 
                role: 'assistant', 
                content: response,
                recommendations: extractRecommendations(response)
            }]);

            // Optional: Speak response using Web Speech API
            if (voiceEnabled && 'speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(response);
                utterance.rate = 1.0;
                utterance.pitch = 1.0;
                window.speechSynthesis.speak(utterance);
            }
        } catch (error) {
            console.error('Team building chatbot error:', error);
            toast.error('Failed to get team building advice');
            setMessages(prev => [...prev, { 
                role: 'assistant', 
                content: '⚠️ Sorry, I encountered an error. Please try again or rephrase your question.' 
            }]);
        } finally {
            setLoading(false);
        }
    };

    const extractRecommendations = (text) => {
        // Simple extraction of player names mentioned
        const playerNames = players
            .filter(p => text.includes(p.name))
            .map(p => p.name)
            .slice(0, 5);
        return playerNames;
    };

    return (
        <AnimatePresence>
            {open && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.9, opacity: 0 }}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full max-w-4xl"
                    >
                        <Card className="bg-slate-900 border-cyan-500/30 shadow-2xl h-[80vh] flex flex-col">
                            <CardHeader className="border-b border-slate-800 py-4">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg">
                                            <Users className="w-6 h-6 text-white" />
                                        </div>
                                        <div>
                                            <CardTitle className="text-white text-lg">
                                                Team Building AI Assistant
                                            </CardTitle>
                                            <p className="text-slate-400 text-xs flex items-center gap-2 mt-1">
                                                <Shield className="w-3 h-3 text-emerald-400" />
                                                FA Laws Compliant • Powered by Hume AI
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Button
                                            onClick={() => setVoiceEnabled(!voiceEnabled)}
                                            variant="ghost"
                                            size="sm"
                                            className={voiceEnabled ? 'text-cyan-400' : 'text-slate-400'}
                                        >
                                            {voiceEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                                        </Button>
                                        <Button
                                            onClick={onClose}
                                            variant="ghost"
                                            size="icon"
                                            className="text-slate-400 hover:text-white"
                                        >
                                            <X className="w-5 h-5" />
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>

                            <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
                                {messages.map((msg, idx) => (
                                    <div
                                        key={idx}
                                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                    >
                                        <div
                                            className={`max-w-[85%] rounded-xl px-5 py-3 ${
                                                msg.role === 'user'
                                                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                                                    : 'bg-slate-800 text-slate-200 border border-slate-700'
                                            }`}
                                        >
                                            <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                                            
                                            {msg.recommendations && msg.recommendations.length > 0 && (
                                                <div className="mt-3 pt-3 border-t border-slate-700">
                                                    <p className="text-xs text-slate-400 mb-2 flex items-center gap-1">
                                                        <TrendingUp className="w-3 h-3" />
                                                        Recommended Players:
                                                    </p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {msg.recommendations.map((name, i) => (
                                                            <Badge key={i} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                                {name}
                                                            </Badge>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {loading && (
                                    <div className="flex justify-start">
                                        <div className="bg-slate-800 rounded-xl px-5 py-3 border border-slate-700">
                                            <div className="flex items-center gap-2">
                                                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                                                <span className="text-slate-400 text-sm">Analyzing squad needs...</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                                <div ref={messagesEndRef} />
                            </CardContent>

                            <div className="p-4 border-t border-slate-800 bg-slate-900/50">
                                <div className="flex gap-3">
                                    <Button
                                        onClick={toggleVoiceInput}
                                        disabled={loading}
                                        variant={isListening ? "default" : "outline"}
                                        className={isListening ? "bg-red-600 hover:bg-red-700" : ""}
                                    >
                                        {isListening ? (
                                            <>
                                                <MicOff className="w-4 h-4 mr-2" />
                                                Stop
                                            </>
                                        ) : (
                                            <Mic className="w-4 h-4" />
                                        )}
                                    </Button>
                                    <Input
                                        value={input}
                                        onChange={(e) => setInput(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                                        placeholder="Ask about squad building, formations, player recommendations..."
                                        className="bg-slate-800 border-slate-700 text-white flex-1"
                                        disabled={loading || isListening}
                                    />
                                    <Button
                                        onClick={handleSend}
                                        disabled={loading || !input.trim() || isListening}
                                        className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
                                    >
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </div>
                                <p className="text-xs text-slate-500 mt-2 text-center">
                                    All recommendations comply with FA regulations and squad registration rules
                                </p>
                            </div>
                        </Card>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
}