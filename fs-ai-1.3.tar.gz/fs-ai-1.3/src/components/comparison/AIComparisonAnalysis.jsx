import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, AlertCircle, TrendingUp, DollarSign, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIComparisonAnalysis({ players, reports, projections }) {
    const [analysis, setAnalysis] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const generateAnalysis = async () => {
        if (!players || players.length < 2) {
            toast.error('Select at least 2 players to compare');
            return;
        }

        setAnalyzing(true);
        toast.loading('AI analyzing players...', { id: 'compare' });

        try {
            const prompt = `You are an elite football scout AI comparing ${players.length} players for transfer decision-making.

PLAYERS TO COMPARE:

${players.map((p, idx) => {
    const playerReports = reports.filter(r => r.player_name?.toLowerCase() === p.name?.toLowerCase());
    const projection = projections.find(pr => pr.player_name?.toLowerCase() === p.name?.toLowerCase());
    const latestReport = playerReports[playerReports.length - 1];

    return `
PLAYER ${idx + 1}: ${p.name}
- Age: ${p.age}, Position: ${p.position}
- Market Value: €${p.market_value || 0}M
- League: ${p.league}
- FS-AI Score: ${p.fsai_proprietary_score || 'N/A'}
- Investment Grade: ${p.fsai_investment_grade || 'N/A'}

Career Stats:
${p.career_history?.slice(-3).map(h => `${h.season}: ${h.appearances || 0} apps, ${h.goals || 0}G, ${h.assists || 0}A`).join('\n') || 'No history'}

Latest Scouting Report:
${latestReport ? `
- Overall Rating: ${latestReport.overall_rating}/10
- Technical: ${latestReport.technical_rating}/10
- Physical: ${latestReport.physical_rating}/10
- Mental: ${latestReport.mental_rating}/10
- Recommendation: ${latestReport.recommendation}
- Verdict: ${latestReport.overall_verdict}
` : 'No reports'}

Projection:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Potential: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
` : 'No projection'}

Injury History: ${p.injury_history?.length || 0} injuries
Contract Expiry: ${p.contract_expiry || 'N/A'}
`;
}).join('\n---\n')}

PROVIDE COMPREHENSIVE COMPARATIVE ANALYSIS:

1. **Key Differences**: What fundamentally separates these players?
2. **Strengths Comparison**: Who excels where?
3. **Risk Assessment**: Compare injury risk, consistency, development concerns
4. **Value Analysis**: Best value for money? Hidden gems vs proven quality?
5. **Tactical Fit**: How would each fit different systems?
6. **Transfer Priority**: Who should be prioritized and why?
7. **Individual Verdicts**: Final recommendation for EACH player
8. **Head-to-Head Winner**: If you could only sign ONE, who and why?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        key_differences: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    category: { type: "string" },
                                    comparison: { type: "string" }
                                }
                            }
                        },
                        strengths_comparison: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    key_strengths: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        risk_assessment: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    risk_level: { type: "string" },
                                    risk_factors: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        value_analysis: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    value_rating: { type: "number" },
                                    value_explanation: { type: "string" }
                                }
                            }
                        },
                        tactical_fit: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    best_systems: { type: "array", items: { type: "string" } },
                                    tactical_role: { type: "string" }
                                }
                            }
                        },
                        transfer_priority_ranking: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    rank: { type: "number" },
                                    player_name: { type: "string" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        individual_verdicts: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    verdict: { type: "string" },
                                    recommendation: { type: "string" },
                                    confidence: { type: "string" }
                                }
                            }
                        },
                        head_to_head_winner: {
                            type: "object",
                            properties: {
                                player_name: { type: "string" },
                                reasoning: { type: "string" },
                                margin: { type: "string" }
                            }
                        },
                        summary: { type: "string" }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Comparison complete!', { id: 'compare' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to generate comparison', { id: 'compare' });
        } finally {
            setAnalyzing(false);
        }
    };

    const getRiskColor = (risk) => {
        if (risk?.toLowerCase().includes('low')) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (risk?.toLowerCase().includes('medium')) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    return (
        <div className="space-y-6">
            {!analysis ? (
                <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                    <CardContent className="py-12">
                        <div className="text-center">
                            <Sparkles className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                            <h3 className="text-white text-xl font-semibold mb-2">AI Comparative Analysis</h3>
                            <p className="text-slate-400 mb-6">
                                Get comprehensive AI-powered insights comparing {players.length} players
                            </p>
                            <Button
                                onClick={generateAnalysis}
                                disabled={analyzing || players.length < 2}
                                className="bg-gradient-to-r from-purple-500 to-cyan-600"
                            >
                                {analyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Generate AI Comparison
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            ) : (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Summary */}
                    <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">Executive Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{analysis.summary}</p>
                        </CardContent>
                    </Card>

                    {/* Head-to-Head Winner */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400 flex items-center gap-2">
                                <Target className="w-5 h-5" />
                                Top Priority Target
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-start gap-4">
                                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center flex-shrink-0">
                                    <span className="text-white text-2xl font-bold">1</span>
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-white text-2xl font-bold mb-2">{analysis.head_to_head_winner?.player_name}</h3>
                                    <Badge className="bg-emerald-500/20 text-emerald-400 mb-3">
                                        {analysis.head_to_head_winner?.margin}
                                    </Badge>
                                    <p className="text-slate-300">{analysis.head_to_head_winner?.reasoning}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Transfer Priority Ranking */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Transfer Priority Ranking</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {analysis.transfer_priority_ranking?.sort((a, b) => a.rank - b.rank).map((item, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4 flex items-start gap-4">
                                        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                                            item.rank === 1 ? 'bg-gradient-to-br from-emerald-500 to-teal-600' :
                                            item.rank === 2 ? 'bg-gradient-to-br from-cyan-500 to-blue-600' :
                                            'bg-gradient-to-br from-slate-600 to-slate-700'
                                        }`}>
                                            <span className="text-white font-bold">{item.rank}</span>
                                        </div>
                                        <div className="flex-1">
                                            <h4 className="text-white font-semibold mb-1">{item.player_name}</h4>
                                            <p className="text-slate-300 text-sm">{item.reasoning}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Key Differences */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Key Differences</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {analysis.key_differences?.map((diff, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <h5 className="text-cyan-400 font-semibold mb-2">{diff.category}</h5>
                                        <p className="text-slate-300 text-sm">{diff.comparison}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Strengths Comparison */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Strengths Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {analysis.strengths_comparison?.map((player, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <h5 className="text-white font-semibold mb-3">{player.player_name}</h5>
                                        <ul className="space-y-1">
                                            {player.key_strengths?.map((strength, i) => (
                                                <li key={i} className="text-emerald-400 text-sm flex items-start gap-2">
                                                    <span className="text-emerald-400 mt-1">+</span>
                                                    <span className="text-slate-300">{strength}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Risk Assessment */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <AlertCircle className="w-5 h-5 text-amber-400" />
                                Risk Assessment
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {analysis.risk_assessment?.map((player, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <h5 className="text-white font-semibold">{player.player_name}</h5>
                                            <Badge className={getRiskColor(player.risk_level)}>
                                                {player.risk_level}
                                            </Badge>
                                        </div>
                                        <ul className="space-y-1">
                                            {player.risk_factors?.map((factor, i) => (
                                                <li key={i} className="text-slate-400 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400 mt-1">!</span>
                                                    <span className="text-slate-300">{factor}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Value Analysis */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-amber-400" />
                                Value Analysis
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {analysis.value_analysis?.sort((a, b) => b.value_rating - a.value_rating).map((player, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <h5 className="text-white font-semibold">{player.player_name}</h5>
                                            <div className="text-amber-400 text-2xl font-bold">{player.value_rating}/10</div>
                                        </div>
                                        <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                                            <div 
                                                className="bg-gradient-to-r from-amber-500 to-orange-600 h-2 rounded-full"
                                                style={{ width: `${player.value_rating * 10}%` }}
                                            />
                                        </div>
                                        <p className="text-slate-300 text-sm">{player.value_explanation}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Tactical Fit */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Tactical Fit Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {analysis.tactical_fit?.map((player, idx) => (
                                    <div key={idx} className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                        <h5 className="text-white font-semibold mb-2">{player.player_name}</h5>
                                        <p className="text-purple-400 text-sm font-medium mb-2">{player.tactical_role}</p>
                                        <div className="space-y-1">
                                            <p className="text-slate-400 text-xs mb-1">Best Systems:</p>
                                            {player.best_systems?.map((system, i) => (
                                                <Badge key={i} className="bg-purple-500/20 text-purple-400 mr-2 text-xs">
                                                    {system}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Individual Verdicts */}
                    <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Individual Scouting Verdicts</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {analysis.individual_verdicts?.map((verdict, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-3">
                                            <h5 className="text-white text-lg font-semibold">{verdict.player_name}</h5>
                                            <div className="text-right">
                                                <Badge className={
                                                    verdict.recommendation?.toLowerCase().includes('sign') ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                                                    verdict.recommendation?.toLowerCase().includes('monitor') ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                                                    verdict.recommendation?.toLowerCase().includes('pass') ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                                                    'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                                                }>
                                                    {verdict.recommendation}
                                                </Badge>
                                                <p className="text-slate-500 text-xs mt-1">{verdict.confidence} Confidence</p>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm leading-relaxed">{verdict.verdict}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Button
                        onClick={() => setAnalysis(null)}
                        variant="outline"
                        className="w-full"
                    >
                        Generate New Comparison
                    </Button>
                </motion.div>
            )}
        </div>
    );
}