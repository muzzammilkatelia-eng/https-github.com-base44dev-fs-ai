import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Filter, X, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdvancedFiltering({ players, onFilteredPlayersChange }) {
    const [filters, setFilters] = useState({
        positions: [],
        ageRange: [16, 35],
        valueRange: [0, 200],
        leagues: [],
        archetypes: [],
        minRating: 0,
        injuryRisk: 100,
        searchTerm: '',
        performances: {
            minGoals: 0,
            minAssists: 0,
            minApps: 0
        }
    });
    const [showFilters, setShowFilters] = useState(false);

    const positions = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 
                       'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];
    
    const archetypes = ['Deep-Lying Playmaker', 'Box-to-Box', 'Ball-Winning Midfielder', 
                        'Inverted Winger', 'Target Man', 'Complete Forward', 'Pressing Forward',
                        'Ball-Playing Defender', 'Sweeper Keeper'];
    
    const leagues = [...new Set(players.map(p => p.league).filter(Boolean))].sort();

    const applyFilters = () => {
        let filtered = players.filter(player => {
            // Search term
            if (filters.searchTerm && !player.name.toLowerCase().includes(filters.searchTerm.toLowerCase())) {
                return false;
            }

            // Position
            if (filters.positions.length > 0 && !filters.positions.includes(player.position)) {
                return false;
            }

            // Age range
            if (player.age < filters.ageRange[0] || player.age > filters.ageRange[1]) {
                return false;
            }

            // Market value
            if (player.market_value && (player.market_value < filters.valueRange[0] || player.market_value > filters.valueRange[1])) {
                return false;
            }

            // League
            if (filters.leagues.length > 0 && !filters.leagues.includes(player.league)) {
                return false;
            }

            // Archetype
            if (filters.archetypes.length > 0) {
                const playerArchetype = player.fsai_archetype_primary || player.fsai_archetype_secondary;
                if (!playerArchetype || !filters.archetypes.some(arch => playerArchetype.includes(arch))) {
                    return false;
                }
            }

            // Min rating
            if (filters.minRating > 0 && (!player.fsai_proprietary_score || player.fsai_proprietary_score < filters.minRating)) {
                return false;
            }

            // Injury risk
            if (player.injury_prone_score && player.injury_prone_score > filters.injuryRisk) {
                return false;
            }

            // Performance stats
            const latestSeason = player.career_history?.slice(-1)[0];
            if (latestSeason) {
                if (filters.performances.minGoals > 0 && (latestSeason.goals || 0) < filters.performances.minGoals) return false;
                if (filters.performances.minAssists > 0 && (latestSeason.assists || 0) < filters.performances.minAssists) return false;
                if (filters.performances.minApps > 0 && (latestSeason.appearances || 0) < filters.performances.minApps) return false;
            }

            return true;
        });

        onFilteredPlayersChange(filtered);
    };

    const clearFilters = () => {
        setFilters({
            positions: [],
            ageRange: [16, 35],
            valueRange: [0, 200],
            leagues: [],
            archetypes: [],
            minRating: 0,
            injuryRisk: 100,
            searchTerm: '',
            performances: { minGoals: 0, minAssists: 0, minApps: 0 }
        });
        onFilteredPlayersChange(players);
    };

    const togglePosition = (position) => {
        const newPositions = filters.positions.includes(position)
            ? filters.positions.filter(p => p !== position)
            : [...filters.positions, position];
        setFilters({ ...filters, positions: newPositions });
    };

    const toggleLeague = (league) => {
        const newLeagues = filters.leagues.includes(league)
            ? filters.leagues.filter(l => l !== league)
            : [...filters.leagues, league];
        setFilters({ ...filters, leagues: newLeagues });
    };

    const toggleArchetype = (archetype) => {
        const newArchetypes = filters.archetypes.includes(archetype)
            ? filters.archetypes.filter(a => a !== archetype)
            : [...filters.archetypes, archetype];
        setFilters({ ...filters, archetypes: newArchetypes });
    };

    React.useEffect(() => {
        applyFilters();
    }, [filters]);

    const activeFilterCount = filters.positions.length + filters.leagues.length + filters.archetypes.length +
        (filters.minRating > 0 ? 1 : 0) + (filters.injuryRisk < 100 ? 1 : 0) +
        (filters.performances.minGoals > 0 ? 1 : 0) + (filters.performances.minAssists > 0 ? 1 : 0) +
        (filters.performances.minApps > 0 ? 1 : 0);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Filter className="w-5 h-5 text-cyan-400" />
                        Advanced Filtering
                        {activeFilterCount > 0 && (
                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                {activeFilterCount} active
                            </Badge>
                        )}
                    </CardTitle>
                    <div className="flex gap-2">
                        {activeFilterCount > 0 && (
                            <Button onClick={clearFilters} variant="ghost" size="sm" className="text-slate-400">
                                Clear All
                            </Button>
                        )}
                        <Button
                            onClick={() => setShowFilters(!showFilters)}
                            variant="outline"
                            size="sm"
                        >
                            {showFilters ? 'Hide' : 'Show'} Filters
                        </Button>
                    </div>
                </div>
            </CardHeader>
            
            <AnimatePresence>
                {showFilters && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                    >
                        <CardContent className="space-y-6">
                            {/* Search */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">Search Players</Label>
                                <div className="relative">
                                    <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                                    <Input
                                        placeholder="Search by name..."
                                        value={filters.searchTerm}
                                        onChange={(e) => setFilters({ ...filters, searchTerm: e.target.value })}
                                        className="pl-10 bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>

                            {/* Positions */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">Positions</Label>
                                <div className="flex flex-wrap gap-2">
                                    {positions.map(pos => (
                                        <Badge
                                            key={pos}
                                            onClick={() => togglePosition(pos)}
                                            className={`cursor-pointer ${
                                                filters.positions.includes(pos)
                                                    ? 'bg-cyan-500/30 text-cyan-400 border-cyan-500'
                                                    : 'bg-slate-800 text-slate-400 border-slate-700'
                                            }`}
                                        >
                                            {pos}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Age Range */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">
                                    Age Range: {filters.ageRange[0]} - {filters.ageRange[1]} years
                                </Label>
                                <Slider
                                    min={16}
                                    max={40}
                                    step={1}
                                    value={filters.ageRange}
                                    onValueChange={(value) => setFilters({ ...filters, ageRange: value })}
                                    className="w-full"
                                />
                            </div>

                            {/* Market Value Range */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">
                                    Market Value: €{filters.valueRange[0]}M - €{filters.valueRange[1]}M
                                </Label>
                                <Slider
                                    min={0}
                                    max={200}
                                    step={5}
                                    value={filters.valueRange}
                                    onValueChange={(value) => setFilters({ ...filters, valueRange: value })}
                                    className="w-full"
                                />
                            </div>

                            {/* Leagues */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">Leagues</Label>
                                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                                    {leagues.map(league => (
                                        <Badge
                                            key={league}
                                            onClick={() => toggleLeague(league)}
                                            className={`cursor-pointer ${
                                                filters.leagues.includes(league)
                                                    ? 'bg-purple-500/30 text-purple-400 border-purple-500'
                                                    : 'bg-slate-800 text-slate-400 border-slate-700'
                                            }`}
                                        >
                                            {league}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Tactical Archetypes */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">Tactical Archetypes</Label>
                                <div className="flex flex-wrap gap-2">
                                    {archetypes.map(arch => (
                                        <Badge
                                            key={arch}
                                            onClick={() => toggleArchetype(arch)}
                                            className={`cursor-pointer ${
                                                filters.archetypes.includes(arch)
                                                    ? 'bg-emerald-500/30 text-emerald-400 border-emerald-500'
                                                    : 'bg-slate-800 text-slate-400 border-slate-700'
                                            }`}
                                        >
                                            {arch}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Minimum FS-AI Rating */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">
                                    Minimum FS-AI Rating: {filters.minRating}
                                </Label>
                                <Slider
                                    min={0}
                                    max={100}
                                    step={5}
                                    value={[filters.minRating]}
                                    onValueChange={(value) => setFilters({ ...filters, minRating: value[0] })}
                                    className="w-full"
                                />
                            </div>

                            {/* Injury Risk */}
                            <div>
                                <Label className="text-slate-400 mb-2 block">
                                    Maximum Injury Risk: {filters.injuryRisk}
                                </Label>
                                <Slider
                                    min={0}
                                    max={100}
                                    step={5}
                                    value={[filters.injuryRisk]}
                                    onValueChange={(value) => setFilters({ ...filters, injuryRisk: value[0] })}
                                    className="w-full"
                                />
                            </div>

                            {/* Performance Filters */}
                            <div className="grid grid-cols-3 gap-4">
                                <div>
                                    <Label className="text-slate-400 text-xs mb-1 block">Min Goals</Label>
                                    <Input
                                        type="number"
                                        min="0"
                                        value={filters.performances.minGoals}
                                        onChange={(e) => setFilters({
                                            ...filters,
                                            performances: { ...filters.performances, minGoals: Number(e.target.value) }
                                        })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                                <div>
                                    <Label className="text-slate-400 text-xs mb-1 block">Min Assists</Label>
                                    <Input
                                        type="number"
                                        min="0"
                                        value={filters.performances.minAssists}
                                        onChange={(e) => setFilters({
                                            ...filters,
                                            performances: { ...filters.performances, minAssists: Number(e.target.value) }
                                        })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                                <div>
                                    <Label className="text-slate-400 text-xs mb-1 block">Min Apps</Label>
                                    <Input
                                        type="number"
                                        min="0"
                                        value={filters.performances.minApps}
                                        onChange={(e) => setFilters({
                                            ...filters,
                                            performances: { ...filters.performances, minApps: Number(e.target.value) }
                                        })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>
                        </CardContent>
                    </motion.div>
                )}
            </AnimatePresence>
        </Card>
    );
}