import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Zap, Activity, Brain, Target } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AttributesComparison({ players }) {
    const getAttributeValue = (player, category, attribute) => {
        if (category === 'physical') {
            return player.physical_attributes?.[attribute] || 0;
        }
        return 0;
    };

    const calculateAverage = (values) => {
        const sum = values.reduce((a, b) => a + b, 0);
        return values.length > 0 ? Math.round(sum / values.length) : 0;
    };

    const getComparisonIndicator = (value, values) => {
        const max = Math.max(...values);
        const min = Math.min(...values);
        
        if (value === max && value !== min) {
            return <TrendingUp className="w-4 h-4 text-emerald-400" />;
        } else if (value === min && value !== max) {
            return <TrendingDown className="w-4 h-4 text-red-400" />;
        }
        return <Minus className="w-4 h-4 text-slate-500" />;
    };

    const getColorClass = (value, values) => {
        const max = Math.max(...values);
        const min = Math.min(...values);
        
        if (value === max && value !== min) {
            return 'text-emerald-400 font-bold';
        } else if (value === min && value !== max) {
            return 'text-red-400';
        }
        return 'text-slate-300';
    };

    const physicalAttributes = [
        { key: 'height', label: 'Height (cm)', icon: Activity },
        { key: 'pace', label: 'Pace', icon: Zap },
        { key: 'strength', label: 'Strength', icon: Activity },
        { key: 'stamina', label: 'Stamina', icon: Activity }
    ];

    const categories = [
        {
            title: 'Physical Attributes',
            icon: Activity,
            color: 'cyan',
            attributes: physicalAttributes
        }
    ];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-cyan-400" />
                    Attributes Side-by-Side
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {categories.map((category, catIdx) => (
                    <div key={catIdx} className="space-y-4">
                        <div className="flex items-center gap-2">
                            <category.icon className={`w-5 h-5 text-${category.color}-400`} />
                            <h3 className={`text-${category.color}-400 font-semibold text-lg`}>
                                {category.title}
                            </h3>
                        </div>

                        <div className="space-y-3">
                            {category.attributes.map((attr) => {
                                const values = players.map(p => getAttributeValue(p, 'physical', attr.key));
                                const average = calculateAverage(values);

                                return (
                                    <motion.div
                                        key={attr.key}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="bg-slate-800/50 rounded-lg p-4"
                                    >
                                        <div className="flex items-center justify-between mb-3">
                                            <div className="flex items-center gap-2">
                                                <attr.icon className="w-4 h-4 text-slate-400" />
                                                <span className="text-white font-medium">{attr.label}</span>
                                            </div>
                                            <Badge variant="outline" className="border-slate-600 text-slate-400">
                                                Avg: {average}
                                            </Badge>
                                        </div>

                                        <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${players.length}, 1fr)` }}>
                                            {players.map((player, idx) => {
                                                const value = getAttributeValue(player, 'physical', attr.key);
                                                const percentage = value > 0 ? (value / 100) * 100 : 0;

                                                return (
                                                    <div key={idx} className="space-y-2">
                                                        <div className="flex items-center justify-between">
                                                            <span className="text-slate-400 text-xs truncate">
                                                                {player.name.split(' ')[0]}
                                                            </span>
                                                            <div className="flex items-center gap-1">
                                                                {getComparisonIndicator(value, values)}
                                                                <span className={`text-sm font-bold ${getColorClass(value, values)}`}>
                                                                    {value || 'N/A'}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                                                            <motion.div
                                                                initial={{ width: 0 }}
                                                                animate={{ width: `${percentage}%` }}
                                                                transition={{ duration: 0.5, delay: 0.1 * idx }}
                                                                className={`h-full rounded-full ${
                                                                    value === Math.max(...values) && value !== Math.min(...values)
                                                                        ? 'bg-emerald-500'
                                                                        : value === Math.min(...values) && value !== Math.max(...values)
                                                                        ? 'bg-red-500'
                                                                        : 'bg-slate-500'
                                                                }`}
                                                            />
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </div>
                    </div>
                ))}

                {/* Market Value & Age Comparison */}
                <div className="space-y-3 pt-4 border-t border-slate-700">
                    <h3 className="text-amber-400 font-semibold text-lg">Market & Profile</h3>
                    
                    <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${players.length}, 1fr)` }}>
                        {players.map((player, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.1 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="text-center">
                                    <p className="text-white font-bold text-lg mb-1">{player.name}</p>
                                    <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                                        {player.position}
                                    </Badge>
                                </div>

                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Age</span>
                                        <span className="text-white font-semibold">{player.age}y</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Value</span>
                                        <span className="text-amber-400 font-bold">€{player.market_value}M</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Club</span>
                                        <span className="text-white text-xs truncate max-w-[120px]" title={player.current_club}>
                                            {player.current_club}
                                        </span>
                                    </div>
                                    {player.injury_prone_score !== undefined && (
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Injury Risk</span>
                                            <span className={`font-semibold ${
                                                player.injury_prone_score > 70 ? 'text-red-400' :
                                                player.injury_prone_score > 40 ? 'text-amber-400' :
                                                'text-emerald-400'
                                            }`}>
                                                {player.injury_prone_score}/100
                                            </span>
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}