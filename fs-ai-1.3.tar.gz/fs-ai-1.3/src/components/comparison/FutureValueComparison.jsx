import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, Calendar } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function FutureValueComparison({ players, projections }) {
    const [chartData, setChartData] = useState([]);

    useEffect(() => {
        generateChartData();
    }, [players, projections]);

    const generateChartData = () => {
        // Create timeline data for next 5 years
        const currentYear = new Date().getFullYear();
        const years = Array.from({ length: 6 }, (_, i) => currentYear + i);

        const data = years.map(year => {
            const dataPoint = { year: year.toString() };
            
            players.forEach(player => {
                const projection = projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase());
                const yearsFromNow = year - currentYear;
                
                // Simple projection: current value with growth/decline
                let projectedValue = player.market_value || 0;
                
                if (projection) {
                    const yearsToPeak = projection.years_to_peak || 3;
                    if (yearsFromNow < yearsToPeak) {
                        // Growth phase
                        const growthRate = 1.2; // 20% per year
                        projectedValue = projectedValue * Math.pow(growthRate, yearsFromNow);
                    } else {
                        // Peak then decline
                        const peakValue = projectedValue * Math.pow(1.2, yearsToPeak);
                        const declineRate = 0.9; // 10% decline per year
                        projectedValue = peakValue * Math.pow(declineRate, yearsFromNow - yearsToPeak);
                    }
                } else {
                    // Default projection based on age
                    if (player.age < 23) {
                        projectedValue = projectedValue * Math.pow(1.15, yearsFromNow);
                    } else if (player.age < 27) {
                        projectedValue = projectedValue * Math.pow(1.05, Math.min(yearsFromNow, 2));
                    } else {
                        projectedValue = projectedValue * Math.pow(0.92, yearsFromNow);
                    }
                }
                
                dataPoint[player.name] = Math.round(projectedValue * 10) / 10;
            });
            
            return dataPoint;
        });

        setChartData(data);
    };

    const colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    const calculateROI = (player, projection) => {
        const currentValue = player.market_value || 0;
        const projection5Year = chartData[5]?.[player.name] || currentValue;
        const roi = ((projection5Year - currentValue) / currentValue) * 100;
        return Math.round(roi);
    };

    const getOptimalSellWindow = (player, projection) => {
        if (!projection) return 'Year 2-3';
        return projection.years_to_peak <= 2 ? `Year ${projection.years_to_peak}` : 'Year 2-3';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                        5-Year Value Projection
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="year" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" label={{ value: 'Value (€M)', angle: -90, position: 'insideLeft' }} />
                            <Tooltip 
                                contentStyle={{ 
                                    backgroundColor: '#1e293b', 
                                    border: '1px solid #475569',
                                    borderRadius: '8px'
                                }} 
                            />
                            <Legend />
                            {players.map((player, idx) => (
                                <Line
                                    key={player.id}
                                    type="monotone"
                                    dataKey={player.name}
                                    stroke={colors[idx % colors.length]}
                                    strokeWidth={3}
                                    dot={{ fill: colors[idx % colors.length], r: 5 }}
                                />
                            ))}
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {players.map((player, idx) => {
                    const projection = projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase());
                    const roi = calculateROI(player, projection);
                    const optimalWindow = getOptimalSellWindow(player, projection);

                    return (
                        <Card key={player.id} className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <h4 className="text-white font-semibold mb-4">{player.name}</h4>
                                
                                <div className="space-y-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-slate-400 text-xs">Current Value</span>
                                            <DollarSign className="w-4 h-4 text-amber-400" />
                                        </div>
                                        <p className="text-white text-xl font-bold">€{player.market_value || 0}M</p>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-slate-400 text-xs">5-Year Projection</span>
                                            <TrendingUp className="w-4 h-4 text-emerald-400" />
                                        </div>
                                        <p className="text-emerald-400 text-xl font-bold">
                                            €{chartData[5]?.[player.name] || player.market_value || 0}M
                                        </p>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <span className="text-slate-400 text-xs block mb-1">ROI Potential</span>
                                        <div className="flex items-center gap-2">
                                            <p className={`text-2xl font-bold ${roi > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                                {roi > 0 ? '+' : ''}{roi}%
                                            </p>
                                            <Badge className={roi > 50 ? 'bg-emerald-500/20 text-emerald-400' : roi > 0 ? 'bg-cyan-500/20 text-cyan-400' : 'bg-red-500/20 text-red-400'}>
                                                {roi > 50 ? 'High' : roi > 0 ? 'Medium' : 'Low'}
                                            </Badge>
                                        </div>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-slate-400 text-xs">Optimal Sell Window</span>
                                            <Calendar className="w-4 h-4 text-purple-400" />
                                        </div>
                                        <p className="text-purple-400 font-semibold">{optimalWindow}</p>
                                    </div>

                                    {projection && (
                                        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3">
                                            <p className="text-purple-400 text-xs font-semibold mb-1">Trajectory</p>
                                            <p className="text-white text-sm">{projection.potential_trajectory}</p>
                                            <p className="text-slate-400 text-xs mt-2">
                                                Peak in {projection.years_to_peak} years at {projection.peak_potential_rating}/10
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    );
                })}
            </div>
        </div>
    );
}