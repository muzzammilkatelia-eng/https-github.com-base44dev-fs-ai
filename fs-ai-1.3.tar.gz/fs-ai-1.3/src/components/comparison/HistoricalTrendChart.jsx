import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

export default function HistoricalTrendChart({ playersData }) {
    if (!playersData || playersData.length === 0) return null;

    const colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    // Combine all player reports into timeline data
    const timelineData = {};
    
    playersData.forEach((playerData, playerIndex) => {
        if (playerData.reports && playerData.reports.length > 0) {
            playerData.reports.forEach(report => {
                const date = new Date(report.created_date).toLocaleDateString('en-US', { 
                    month: 'short', 
                    year: 'numeric' 
                });
                
                if (!timelineData[date]) {
                    timelineData[date] = { date };
                }
                
                timelineData[date][`${playerData.name}_overall`] = report.overall_rating || 0;
            });
        }
    });

    const chartData = Object.values(timelineData).sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateA - dateB;
    });

    if (chartData.length === 0) return null;

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                    Performance Trends Over Time
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="date" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                        <YAxis domain={[0, 10]} stroke="#94a3b8" style={{ fontSize: '12px' }} />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: '#1e293b', 
                                border: '1px solid #475569',
                                borderRadius: '8px',
                                color: '#fff'
                            }} 
                        />
                        <Legend />
                        {playersData.map((playerData, index) => (
                            <Line
                                key={playerData.name}
                                type="monotone"
                                dataKey={`${playerData.name}_overall`}
                                stroke={colors[index % colors.length]}
                                strokeWidth={2}
                                name={playerData.name}
                                dot={{ r: 4 }}
                            />
                        ))}
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}