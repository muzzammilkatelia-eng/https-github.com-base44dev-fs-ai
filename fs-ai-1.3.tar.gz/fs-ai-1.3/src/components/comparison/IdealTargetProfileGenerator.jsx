import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Loader2, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function IdealTargetProfileGenerator() {
    const [teamNeeds, setTeamNeeds] = useState('');
    const [profile, setProfile] = useState(null);
    const [generating, setGenerating] = useState(false);

    const generateProfile = async () => {
        if (!teamNeeds.trim()) {
            toast.error('Please describe your team needs or tactical style');
            return;
        }

        setGenerating(true);
        toast.loading('AI generating ideal player profile...', { id: 'profile' });

        try {
            const prompt = `You are an elite football recruitment consultant. Based on the following team needs and tactical requirements, generate a detailed ideal player profile:

TEAM NEEDS & TACTICAL STYLE:
${teamNeeds}

Generate a comprehensive ideal target player profile with:

1. **Position & Role**: Primary position and tactical role
2. **Key Attributes** (Physical, Technical, Mental, Tactical): Prioritized list with importance ratings (1-10)
3. **Playing Style Requirements**: What style of play should this player excel in?
4. **Age Range**: Ideal age bracket (consider development vs immediate impact)
5. **Market Value Estimate**: Realistic budget range in millions (EUR)
6. **League Experience**: Which leagues/levels to target
7. **Statistical Benchmarks**: Key stats this player should achieve (goals, assists, tackles, etc.)
8. **Personality Traits**: Mental attributes and character needed
9. **Contract Situation**: Ideal contract status (years remaining, release clause, etc.)
10. **Comparable Players**: Examples of players who fit this profile
11. **Red Flags to Avoid**: What to watch out for when scouting
12. **Scouting Priority Level**: How urgent is this signing?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        position_role: {
                            type: "object",
                            properties: {
                                primary_position: { type: "string" },
                                tactical_role: { type: "string" },
                                alternative_positions: { type: "array", items: { type: "string" } }
                            }
                        },
                        key_attributes: {
                            type: "object",
                            properties: {
                                physical: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            attribute: { type: "string" },
                                            importance: { type: "number" },
                                            benchmark: { type: "string" }
                                        }
                                    }
                                },
                                technical: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            attribute: { type: "string" },
                                            importance: { type: "number" },
                                            benchmark: { type: "string" }
                                        }
                                    }
                                },
                                mental: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            attribute: { type: "string" },
                                            importance: { type: "number" },
                                            benchmark: { type: "string" }
                                        }
                                    }
                                },
                                tactical: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            attribute: { type: "string" },
                                            importance: { type: "number" },
                                            benchmark: { type: "string" }
                                        }
                                    }
                                }
                            }
                        },
                        playing_style: { type: "string" },
                        age_range: {
                            type: "object",
                            properties: {
                                min: { type: "number" },
                                max: { type: "number" },
                                ideal: { type: "number" },
                                reasoning: { type: "string" }
                            }
                        },
                        market_value: {
                            type: "object",
                            properties: {
                                min: { type: "number" },
                                max: { type: "number" },
                                ideal: { type: "number" },
                                currency: { type: "string" }
                            }
                        },
                        league_experience: {
                            type: "array",
                            items: { type: "string" }
                        },
                        statistical_benchmarks: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    metric: { type: "string" },
                                    target_value: { type: "string" }
                                }
                            }
                        },
                        personality_traits: {
                            type: "array",
                            items: { type: "string" }
                        },
                        contract_situation: { type: "string" },
                        comparable_players: {
                            type: "array",
                            items: { type: "string" }
                        },
                        red_flags: {
                            type: "array",
                            items: { type: "string" }
                        },
                        scouting_priority: {
                            type: "object",
                            properties: {
                                level: { type: "string" },
                                urgency: { type: "string" },
                                reasoning: { type: "string" }
                            }
                        }
                    }
                }
            });

            setProfile(response);
            toast.success('Ideal player profile generated!', { id: 'profile' });
        } catch (error) {
            console.error('Profile generation failed:', error);
            toast.error('Failed to generate profile', { id: 'profile' });
        } finally {
            setGenerating(false);
        }
    };

    const getImportanceColor = (importance) => {
        if (importance >= 8) return 'text-red-400';
        if (importance >= 6) return 'text-amber-400';
        return 'text-cyan-400';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-cyan-400" />
                    Ideal Target Profile Generator
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Describe your team's needs and tactical style to generate an ideal player profile
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {!profile ? (
                    <>
                        <Textarea
                            placeholder="Example: We need a creative central midfielder for a possession-based 4-3-3 system. Must have excellent vision, passing range, and press resistance. Budget: €30-50M. Prefer young players (21-24) from top 5 leagues who can make an immediate impact..."
                            value={teamNeeds}
                            onChange={(e) => setTeamNeeds(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white min-h-32"
                        />
                        <Button
                            onClick={generateProfile}
                            disabled={generating}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {generating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating Profile...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Ideal Player Profile
                                </>
                            )}
                        </Button>
                    </>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Position & Role */}
                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <h3 className="text-cyan-400 font-semibold mb-2">Position & Tactical Role</h3>
                            <div className="flex flex-wrap gap-2 mb-2">
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {profile.position_role?.primary_position}
                                </Badge>
                                {profile.position_role?.alternative_positions?.map((pos, i) => (
                                    <Badge key={i} className="bg-slate-700 text-slate-300">
                                        {pos}
                                    </Badge>
                                ))}
                            </div>
                            <p className="text-white">{profile.position_role?.tactical_role}</p>
                        </div>

                        {/* Key Attributes */}
                        <div className="grid md:grid-cols-2 gap-4">
                            {Object.entries(profile.key_attributes || {}).map(([category, attributes]) => (
                                <Card key={category} className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white text-sm capitalize">{category}</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-2">
                                            {attributes?.map((attr, idx) => (
                                                <div key={idx} className="flex items-start justify-between">
                                                    <div className="flex-1">
                                                        <p className="text-slate-300 text-sm">{attr.attribute}</p>
                                                        <p className="text-slate-500 text-xs">{attr.benchmark}</p>
                                                    </div>
                                                    <span className={`text-lg font-bold ${getImportanceColor(attr.importance)}`}>
                                                        {attr.importance}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>

                        {/* Age & Value */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-2">Age Range</h4>
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {profile.age_range?.min} - {profile.age_range?.max} years
                                    </Badge>
                                    <Badge className="bg-purple-600/30 text-purple-300">
                                        Ideal: {profile.age_range?.ideal}
                                    </Badge>
                                </div>
                                <p className="text-slate-400 text-sm">{profile.age_range?.reasoning}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-2">Market Value</h4>
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge className="bg-amber-500/20 text-amber-400">
                                        €{profile.market_value?.min}M - €{profile.market_value?.max}M
                                    </Badge>
                                    <Badge className="bg-amber-600/30 text-amber-300">
                                        Target: €{profile.market_value?.ideal}M
                                    </Badge>
                                </div>
                            </div>
                        </div>

                        {/* Playing Style */}
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h4 className="text-emerald-400 font-semibold mb-2">Playing Style Requirements</h4>
                            <p className="text-slate-300">{profile.playing_style}</p>
                        </div>

                        {/* Statistical Benchmarks */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Statistical Benchmarks</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                    {profile.statistical_benchmarks?.map((bench, idx) => (
                                        <div key={idx} className="bg-slate-900/50 rounded p-3">
                                            <p className="text-slate-400 text-xs">{bench.metric}</p>
                                            <p className="text-white font-semibold">{bench.target_value}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Leagues & Personality */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-2">Target Leagues</h4>
                                <div className="flex flex-wrap gap-2">
                                    {profile.league_experience?.map((league, i) => (
                                        <Badge key={i} className="bg-blue-500/20 text-blue-400">
                                            {league}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-2">Personality Traits</h4>
                                <div className="flex flex-wrap gap-2">
                                    {profile.personality_traits?.map((trait, i) => (
                                        <Badge key={i} className="bg-purple-500/20 text-purple-400">
                                            {trait}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Comparable Players */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h4 className="text-white font-semibold mb-2">Comparable Players (Examples)</h4>
                            <div className="flex flex-wrap gap-2">
                                {profile.comparable_players?.map((player, i) => (
                                    <Badge key={i} className="bg-cyan-500/20 text-cyan-400">
                                        {player}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {/* Red Flags */}
                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                            <h4 className="text-red-400 font-semibold mb-2">Red Flags to Avoid</h4>
                            <ul className="space-y-1">
                                {profile.red_flags?.map((flag, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-red-400">⚠</span>
                                        {flag}
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {/* Priority */}
                        <div className={`border rounded-lg p-4 ${
                            profile.scouting_priority?.level === 'Critical' ? 'bg-red-500/10 border-red-500/30' :
                            profile.scouting_priority?.level === 'High' ? 'bg-amber-500/10 border-amber-500/30' :
                            'bg-cyan-500/10 border-cyan-500/30'
                        }`}>
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-white font-semibold">Scouting Priority</h4>
                                <Badge className={
                                    profile.scouting_priority?.level === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                    profile.scouting_priority?.level === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-cyan-500/20 text-cyan-400'
                                }>
                                    {profile.scouting_priority?.level} - {profile.scouting_priority?.urgency}
                                </Badge>
                            </div>
                            <p className="text-slate-300 text-sm">{profile.scouting_priority?.reasoning}</p>
                        </div>

                        <Button onClick={() => setProfile(null)} variant="outline" className="w-full">
                            Generate New Profile
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}