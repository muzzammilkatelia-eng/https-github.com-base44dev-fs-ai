import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Activity, AlertTriangle, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import toast from 'react-hot-toast';

export default function InjuryTrendPredictor() {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [prediction, setPrediction] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const analyzedPlayer = selectedPlayer ? players.find(p => p.id === selectedPlayer) : null;

    const analyzeInjuryRisk = async () => {
        if (!analyzedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setAnalyzing(true);
        toast.loading('Analyzing injury patterns...', { id: 'injury' });

        try {
            const prompt = `You are a sports medicine and injury prediction specialist. Analyze this player's injury history and predict future injury risk:

PLAYER PROFILE:
Name: ${analyzedPlayer.name}
Age: ${analyzedPlayer.age}
Position: ${analyzedPlayer.position}
Physical Attributes: ${JSON.stringify(analyzedPlayer.physical_attributes)}
Playing Style: ${JSON.stringify(analyzedPlayer.playing_style)}
Current Injury Prone Score: ${analyzedPlayer.injury_prone_score || 'N/A'}

INJURY HISTORY:
${analyzedPlayer.injury_history?.length > 0 ? analyzedPlayer.injury_history.map((inj, i) => `
${i + 1}. ${inj.injury_type} - ${inj.date}
   Severity: ${inj.severity}
   Recovery: ${inj.recovery_time}
   ${inj.notes ? `Notes: ${inj.notes}` : ''}
`).join('\n') : 'No recorded injuries'}

CAREER STATISTICS (Recent Seasons):
${analyzedPlayer.career_history?.slice(-3).map(season => `
${season.season}: ${season.appearances || 0} appearances, ${season.minutes_played || 0} minutes
`).join('\n') || 'No history available'}

PROVIDE COMPREHENSIVE INJURY RISK ASSESSMENT:

1. **Overall Risk Score** (0-100): Current injury risk level
2. **Future Risk Projection**: Next 12-24 months outlook
3. **Injury Pattern Analysis**: Identify recurring patterns or problem areas
4. **Risk Factors**: 
   - Biomechanical vulnerabilities
   - Age-related concerns
   - Position-specific risks
   - Playing style impact
   - Workload concerns
5. **High-Risk Scenarios**: Situations that increase injury likelihood
6. **Injury Type Predictions**: Most likely injury types with probabilities
7. **Prevention Recommendations**: Training, conditioning, load management
8. **Medical Monitoring**: What to track closely
9. **Career Longevity Assessment**: Long-term durability outlook
10. **Transfer Risk Analysis**: Should this affect transfer decisions?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_risk_score: { type: "number", minimum: 0, maximum: 100 },
                        risk_category: { type: "string" },
                        future_projection: {
                            type: "object",
                            properties: {
                                next_6_months: { type: "string" },
                                next_12_months: { type: "string" },
                                next_24_months: { type: "string" }
                            }
                        },
                        injury_patterns: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    pattern_type: { type: "string" },
                                    description: { type: "string" },
                                    concern_level: { type: "string" }
                                }
                            }
                        },
                        risk_factors: {
                            type: "object",
                            properties: {
                                biomechanical: { type: "array", items: { type: "string" } },
                                age_related: { type: "array", items: { type: "string" } },
                                position_specific: { type: "array", items: { type: "string" } },
                                playing_style: { type: "array", items: { type: "string" } },
                                workload: { type: "array", items: { type: "string" } }
                            }
                        },
                        high_risk_scenarios: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    risk_increase: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        injury_predictions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    injury_type: { type: "string" },
                                    probability: { type: "string" },
                                    typical_recovery: { type: "string" },
                                    impact: { type: "string" }
                                }
                            }
                        },
                        prevention_plan: {
                            type: "object",
                            properties: {
                                training_focus: { type: "array", items: { type: "string" } },
                                conditioning_priorities: { type: "array", items: { type: "string" } },
                                load_management: { type: "string" },
                                rest_requirements: { type: "string" }
                            }
                        },
                        medical_monitoring: {
                            type: "array",
                            items: { type: "string" }
                        },
                        career_longevity: {
                            type: "object",
                            properties: {
                                projected_peak_years: { type: "string" },
                                durability_rating: { type: "number" },
                                decline_trajectory: { type: "string" }
                            }
                        },
                        transfer_risk_analysis: {
                            type: "object",
                            properties: {
                                investment_risk: { type: "string" },
                                insurance_considerations: { type: "string" },
                                medical_due_diligence: { type: "string" }
                            }
                        },
                        final_verdict: { type: "string" }
                    }
                }
            });

            setPrediction(response);
            toast.success('Injury risk analysis complete!', { id: 'injury' });
        } catch (error) {
            console.error('Injury analysis failed:', error);
            toast.error('Failed to analyze injury risk', { id: 'injury' });
        } finally {
            setAnalyzing(false);
        }
    };

    const getRiskColor = (score) => {
        if (score >= 70) return 'from-red-500 to-pink-600';
        if (score >= 50) return 'from-amber-500 to-orange-600';
        if (score >= 30) return 'from-yellow-500 to-amber-500';
        return 'from-emerald-500 to-green-600';
    };

    const getRiskBadgeColor = (level) => {
        if (level?.toLowerCase().includes('critical') || level?.toLowerCase().includes('high')) 
            return 'bg-red-500/20 text-red-400 border-red-500/30';
        if (level?.toLowerCase().includes('moderate') || level?.toLowerCase().includes('medium')) 
            return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    };

    // Prepare timeline data for chart
    const timelineData = analyzedPlayer?.injury_history?.map((inj, idx) => ({
        name: `Injury ${idx + 1}`,
        date: inj.date,
        severity: inj.severity === 'Severe' ? 4 : inj.severity === 'Serious' ? 3 : inj.severity === 'Moderate' ? 2 : 1,
        type: inj.injury_type
    })) || [];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Activity className="w-5 h-5 text-red-400" />
                    Injury Trend Predictor
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    AI-powered injury risk assessment and prediction based on historical patterns
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {!prediction ? (
                    <>
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Select Player to Analyze</label>
                            <Select value={selectedPlayer || ''} onValueChange={setSelectedPlayer}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Choose a player..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {players.slice(0, 200).map(p => (
                                        <SelectItem key={p.id} value={p.id}>
                                            {p.name} - {p.position} ({p.age}y)
                                            {p.injury_prone_score && ` - Risk: ${p.injury_prone_score}`}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        {analyzedPlayer && (
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-2">{analyzedPlayer.name}</h4>
                                <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                                    <p className="text-slate-400">Position: <span className="text-white">{analyzedPlayer.position}</span></p>
                                    <p className="text-slate-400">Age: <span className="text-white">{analyzedPlayer.age}</span></p>
                                    <p className="text-slate-400">Injuries Recorded: <span className="text-white">{analyzedPlayer.injury_history?.length || 0}</span></p>
                                    <p className="text-slate-400">Current Risk: <span className={
                                        analyzedPlayer.injury_prone_score > 60 ? 'text-red-400' :
                                        analyzedPlayer.injury_prone_score > 30 ? 'text-amber-400' :
                                        'text-emerald-400'
                                    }>{analyzedPlayer.injury_prone_score || 'N/A'}</span></p>
                                </div>

                                {timelineData.length > 0 && (
                                    <div>
                                        <p className="text-slate-400 text-xs mb-2">Injury History Timeline</p>
                                        <ResponsiveContainer width="100%" height={150}>
                                            <LineChart data={timelineData}>
                                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                                                <YAxis stroke="#94a3b8" fontSize={10} />
                                                <Tooltip
                                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                                    formatter={(value, name, props) => [props.payload.type, 'Type']}
                                                />
                                                <Line type="monotone" dataKey="severity" stroke="#ef4444" strokeWidth={2} />
                                                <ReferenceLine y={2.5} stroke="#f59e0b" strokeDasharray="3 3" />
                                            </LineChart>
                                        </ResponsiveContainer>
                                    </div>
                                )}
                            </div>
                        )}

                        <Button
                            onClick={analyzeInjuryRisk}
                            disabled={analyzing || !selectedPlayer}
                            className="w-full bg-gradient-to-r from-red-500 to-pink-600"
                        >
                            {analyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing Injury Risk...
                                </>
                            ) : (
                                <>
                                    <Activity className="w-4 h-4 mr-2" />
                                    Analyze Injury Risk
                                </>
                            )}
                        </Button>
                    </>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Overall Risk Score */}
                        <div className={`bg-gradient-to-r ${getRiskColor(prediction.overall_risk_score)} p-6 rounded-lg text-center`}>
                            <p className="text-white/80 text-sm mb-2">Overall Injury Risk</p>
                            <div className="text-6xl font-bold text-white mb-2">
                                {Math.round(prediction.overall_risk_score)}
                            </div>
                            <Badge className="bg-white/20 text-white border-white/30">
                                {prediction.risk_category}
                            </Badge>
                        </div>

                        {/* Future Projection */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Future Risk Projection</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    <div className="bg-slate-900/50 rounded p-3">
                                        <p className="text-slate-400 text-xs mb-1">Next 6 Months</p>
                                        <p className="text-white text-sm">{prediction.future_projection?.next_6_months}</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-3">
                                        <p className="text-slate-400 text-xs mb-1">Next 12 Months</p>
                                        <p className="text-white text-sm">{prediction.future_projection?.next_12_months}</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-3">
                                        <p className="text-slate-400 text-xs mb-1">Next 24 Months</p>
                                        <p className="text-white text-sm">{prediction.future_projection?.next_24_months}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Injury Patterns */}
                        {prediction.injury_patterns && prediction.injury_patterns.length > 0 && (
                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardHeader>
                                    <CardTitle className="text-amber-400 flex items-center gap-2">
                                        <AlertTriangle className="w-5 h-5" />
                                        Identified Injury Patterns
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {prediction.injury_patterns.map((pattern, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                <div className="flex items-start justify-between mb-2">
                                                    <h5 className="text-white font-semibold">{pattern.pattern_type}</h5>
                                                    <Badge className={getRiskBadgeColor(pattern.concern_level)}>
                                                        {pattern.concern_level}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-300 text-sm">{pattern.description}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Risk Factors */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white">Risk Factor Breakdown</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-4">
                                    {Object.entries(prediction.risk_factors || {}).map(([category, factors]) => (
                                        <div key={category} className="bg-slate-900/50 rounded p-3">
                                            <p className="text-cyan-400 text-xs font-semibold mb-2 capitalize">
                                                {category.replace(/_/g, ' ')}
                                            </p>
                                            <ul className="space-y-1">
                                                {factors?.map((factor, i) => (
                                                    <li key={i} className="text-slate-300 text-xs flex items-start gap-1">
                                                        <span className="text-amber-400">•</span>
                                                        <span>{factor}</span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Injury Predictions */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white">Predicted Injury Types</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {prediction.injury_predictions?.map((pred, idx) => (
                                        <div key={idx} className="bg-slate-900/50 rounded p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <h5 className="text-white font-semibold">{pred.injury_type}</h5>
                                                <Badge className="bg-red-500/20 text-red-400">
                                                    {pred.probability}
                                                </Badge>
                                            </div>
                                            <div className="grid grid-cols-2 gap-2 text-xs">
                                                <p className="text-slate-400">Recovery: <span className="text-white">{pred.typical_recovery}</span></p>
                                                <p className="text-slate-400">Impact: <span className="text-white">{pred.impact}</span></p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Prevention Plan */}
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400">Prevention & Management Plan</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <p className="text-emerald-400 text-sm font-semibold mb-2">Training Focus</p>
                                        <div className="flex flex-wrap gap-2">
                                            {prediction.prevention_plan?.training_focus?.map((item, i) => (
                                                <Badge key={i} className="bg-emerald-500/20 text-emerald-400">
                                                    {item}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-cyan-400 text-sm font-semibold mb-2">Conditioning Priorities</p>
                                        <div className="flex flex-wrap gap-2">
                                            {prediction.prevention_plan?.conditioning_priorities?.map((item, i) => (
                                                <Badge key={i} className="bg-cyan-500/20 text-cyan-400">
                                                    {item}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="bg-slate-800/50 rounded p-3">
                                        <p className="text-purple-400 text-xs font-semibold mb-1">Load Management</p>
                                        <p className="text-slate-300 text-sm">{prediction.prevention_plan?.load_management}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Career Longevity */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-purple-400" />
                                    Career Longevity Assessment
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-3 gap-4 mb-4">
                                    <div className="bg-slate-900/50 rounded p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Peak Years</p>
                                        <p className="text-white font-semibold">{prediction.career_longevity?.projected_peak_years}</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Durability Rating</p>
                                        <p className="text-purple-400 text-2xl font-bold">
                                            {prediction.career_longevity?.durability_rating}/10
                                        </p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Decline Trajectory</p>
                                        <p className="text-white text-sm">{prediction.career_longevity?.decline_trajectory}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Transfer Risk */}
                        <Card className="bg-gradient-to-r from-amber-500/10 to-red-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400">Transfer Risk Analysis</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Investment Risk</p>
                                    <p className="text-white text-sm">{prediction.transfer_risk_analysis?.investment_risk}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Insurance Considerations</p>
                                    <p className="text-white text-sm">{prediction.transfer_risk_analysis?.insurance_considerations}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Medical Due Diligence</p>
                                    <p className="text-white text-sm">{prediction.transfer_risk_analysis?.medical_due_diligence}</p>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Final Verdict */}
                        <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <h3 className="text-cyan-400 font-semibold mb-2">Final Medical Assessment</h3>
                            <p className="text-slate-300 leading-relaxed">{prediction.final_verdict}</p>
                        </div>

                        <Button onClick={() => setPrediction(null)} variant="outline" className="w-full">
                            Analyze Another Player
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}