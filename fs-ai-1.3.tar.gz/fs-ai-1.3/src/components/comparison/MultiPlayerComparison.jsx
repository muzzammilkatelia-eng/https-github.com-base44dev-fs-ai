import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Search, X, Brain, Loader2, TrendingUp, Shield, Target, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

export default function MultiPlayerComparison() {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [comparisons, setComparisons] = useState({});
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 100)
    });

    const filteredPlayers = players.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.current_club?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const addPlayer = (player) => {
        if (selectedPlayers.length >= 4) {
            toast.error('Maximum 4 players can be compared');
            return;
        }
        if (selectedPlayers.find(p => p.id === player.id)) {
            toast.error('Player already selected');
            return;
        }
        setSelectedPlayers([...selectedPlayers, player]);
        setSearchQuery('');
    };

    const removePlayer = (playerId) => {
        setSelectedPlayers(selectedPlayers.filter(p => p.id !== playerId));
        const newComparisons = { ...comparisons };
        delete newComparisons[playerId];
        setComparisons(newComparisons);
    };

    const runMultiBrainAnalysis = async () => {
        if (selectedPlayers.length < 2) {
            toast.error('Select at least 2 players to compare');
            return;
        }

        setLoading(true);
        try {
            const results = await Promise.all(
                selectedPlayers.map(async (player) => {
                    const { data } = await base44.functions.invoke('multiBrainScout', {
                        player_profile: {
                            name: player.name,
                            age: player.age,
                            position: player.position,
                            metrics: {}
                        },
                        context: {
                            club_style: "Versatile tactical system",
                            role: player.position
                        }
                    });
                    return { playerId: player.id, analysis: data };
                })
            );

            const newComparisons = {};
            results.forEach(({ playerId, analysis }) => {
                newComparisons[playerId] = analysis;
            });
            setComparisons(newComparisons);
            toast.success('Multi-brain analysis complete');
        } catch (error) {
            toast.error('Analysis failed: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const getPlayerReport = (playerName) => {
        return reports.find(r => r.player_name?.toLowerCase() === playerName?.toLowerCase());
    };

    const getPlayerProjection = (playerName) => {
        return projections.find(p => p.player_name?.toLowerCase() === playerName?.toLowerCase());
    };

    // Prepare radar chart data
    const radarData = selectedPlayers.length > 0 && Object.keys(comparisons).length > 0
        ? ['deep', 'creative', 'risk', 'summary'].map(brain => {
            const dataPoint = { brain: brain.toUpperCase() };
            selectedPlayers.forEach(player => {
                const analysis = comparisons[player.id];
                if (analysis?.views?.[brain]) {
                    dataPoint[player.name] = analysis.views[brain].rating;
                }
            });
            return dataPoint;
        })
        : [];

    // Prepare bar chart data for final ratings
    const barData = selectedPlayers.map(player => {
        const analysis = comparisons[player.id];
        return {
            name: player.name.split(' ').pop(),
            rating: analysis?.final?.average_rating || 0,
            confidence: (analysis?.final?.confidence || 0) * 100
        };
    });

    const brainColors = {
        deep: '#06b6d4',
        creative: '#a855f7',
        risk: '#f59e0b',
        summary: '#10b981'
    };

    return (
        <div className="space-y-6">
            {/* Player Selection */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-6 h-6 text-cyan-400" />
                        Select Players to Compare
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                        <Input
                            placeholder="Search players..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 bg-slate-800 border-slate-700 text-white"
                        />
                    </div>

                    {searchQuery && (
                        <div className="max-h-48 overflow-y-auto space-y-2">
                            {filteredPlayers.slice(0, 10).map(player => (
                                <button
                                    key={player.id}
                                    onClick={() => addPlayer(player)}
                                    className="w-full text-left p-3 bg-slate-800/50 hover:bg-slate-800 rounded-lg transition-colors"
                                >
                                    <p className="text-white font-semibold">{player.name}</p>
                                    <p className="text-slate-400 text-sm">
                                        {player.position} • {player.age}y • {player.current_club}
                                    </p>
                                </button>
                            ))}
                        </div>
                    )}

                    <div className="flex flex-wrap gap-2">
                        <AnimatePresence>
                            {selectedPlayers.map((player) => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.8 }}
                                >
                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-sm px-3 py-2">
                                        {player.name}
                                        <button
                                            onClick={() => removePlayer(player.id)}
                                            className="ml-2 hover:text-red-400"
                                        >
                                            <X className="w-3 h-3" />
                                        </button>
                                    </Badge>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>

                    <Button
                        onClick={runMultiBrainAnalysis}
                        disabled={loading || selectedPlayers.length < 2}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Running multi-brain analysis...
                            </>
                        ) : (
                            <>
                                <Brain className="w-4 h-4 mr-2" />
                                Compare Players
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {/* Comparison Results */}
            {selectedPlayers.length > 0 && Object.keys(comparisons).length > 0 && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-6"
                >
                    {/* Radar Chart - Brain Ratings */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Multi-Brain Rating Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={400}>
                                <RadarChart data={radarData}>
                                    <PolarGrid stroke="#334155" />
                                    <PolarAngleAxis dataKey="brain" stroke="#94a3b8" />
                                    {selectedPlayers.map((player, idx) => (
                                        <Radar
                                            key={player.id}
                                            name={player.name}
                                            dataKey={player.name}
                                            stroke={Object.values(brainColors)[idx]}
                                            fill={Object.values(brainColors)[idx]}
                                            fillOpacity={0.3}
                                        />
                                    ))}
                                    <Legend />
                                </RadarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Bar Chart - Final Ratings */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Final Ratings & Confidence</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={barData}>
                                    <XAxis dataKey="name" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #334155',
                                            borderRadius: '8px'
                                        }}
                                    />
                                    <Legend />
                                    <Bar dataKey="rating" fill="#06b6d4" name="Rating (0-10)" />
                                    <Bar dataKey="confidence" fill="#10b981" name="Confidence (%)" />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Side-by-Side Comparison Table */}
                    <Card className="bg-slate-900/50 border-slate-800 overflow-x-auto">
                        <CardHeader>
                            <CardTitle className="text-white">Detailed Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-4">
                                {selectedPlayers.map((player) => {
                                    const analysis = comparisons[player.id];
                                    const report = getPlayerReport(player.name);
                                    const projection = getPlayerProjection(player.name);

                                    return (
                                        <Card key={player.id} className="bg-slate-800/50 border-slate-700">
                                            <CardHeader>
                                                <CardTitle className="text-white text-lg">{player.name}</CardTitle>
                                                <p className="text-slate-400 text-sm">
                                                    {player.position} • {player.age}y
                                                </p>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                {/* Basic Info */}
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-2">Club & Value</p>
                                                    <p className="text-white text-sm">{player.current_club}</p>
                                                    {player.market_value && (
                                                        <p className="text-amber-400 font-semibold">€{player.market_value}M</p>
                                                    )}
                                                </div>

                                                {/* Final AI Rating */}
                                                {analysis?.final && (
                                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
                                                        <p className="text-slate-400 text-xs mb-1">AI Rating</p>
                                                        <p className="text-3xl font-bold text-cyan-400">
                                                            {analysis.final.average_rating}
                                                        </p>
                                                        <p className="text-emerald-400 text-sm">
                                                            {(analysis.final.confidence * 100).toFixed(0)}% confidence
                                                        </p>
                                                        <Badge className={
                                                            analysis.final.decision === 'sign' ? 'bg-emerald-500/20 text-emerald-400 mt-2' :
                                                            analysis.final.decision === 'monitor' ? 'bg-cyan-500/20 text-cyan-400 mt-2' :
                                                            'bg-amber-500/20 text-amber-400 mt-2'
                                                        }>
                                                            {analysis.final.decision.toUpperCase()}
                                                        </Badge>
                                                    </div>
                                                )}

                                                {/* Brain Ratings */}
                                                {analysis?.views && (
                                                    <div className="space-y-2">
                                                        <p className="text-slate-400 text-xs">Brain Ratings</p>
                                                        {Object.entries(analysis.views).map(([brain, view]) => (
                                                            <div key={brain} className="flex justify-between items-center">
                                                                <span className="text-slate-300 text-sm capitalize">{brain}</span>
                                                                <span className="text-white font-semibold">
                                                                    {view.rating?.toFixed(1) || 'N/A'}
                                                                </span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}

                                                {/* Scout Report */}
                                                {report && (
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Scout Recommendation</p>
                                                        <Badge className={
                                                            report.recommendation === 'Strong Recommend' ? 'bg-emerald-500/20 text-emerald-400' :
                                                            report.recommendation === 'Recommend' ? 'bg-cyan-500/20 text-cyan-400' :
                                                            report.recommendation === 'Monitor' ? 'bg-amber-500/20 text-amber-400' :
                                                            'bg-slate-500/20 text-slate-400'
                                                        }>
                                                            {report.recommendation}
                                                        </Badge>
                                                    </div>
                                                )}

                                                {/* Projection */}
                                                {projection && (
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Trajectory</p>
                                                        <p className="text-purple-400 text-sm font-semibold">
                                                            {projection.potential_trajectory}
                                                        </p>
                                                        {projection.peak_potential_rating && (
                                                            <p className="text-slate-300 text-xs">
                                                                Peak: {projection.peak_potential_rating}/10
                                                            </p>
                                                        )}
                                                    </div>
                                                )}

                                                {/* Injury Risk */}
                                                {player.injury_prone_score && (
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Injury Risk</p>
                                                        <p className={`font-semibold ${
                                                            player.injury_prone_score > 60 ? 'text-red-400' :
                                                            player.injury_prone_score > 30 ? 'text-amber-400' :
                                                            'text-emerald-400'
                                                        }`}>
                                                            {player.injury_prone_score}/100
                                                        </p>
                                                    </div>
                                                )}
                                            </CardContent>
                                        </Card>
                                    );
                                })}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Headlines Comparison */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">AI Assessment Headlines</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            {selectedPlayers.map((player) => {
                                const analysis = comparisons[player.id];
                                return analysis?.final?.headline ? (
                                    <div key={player.id} className="bg-slate-800/50 rounded-lg p-4">
                                        <p className="text-cyan-400 font-semibold mb-1">{player.name}</p>
                                        <p className="text-slate-300 text-sm">{analysis.final.headline}</p>
                                        {analysis.final.consensus && (
                                            <p className="text-slate-400 text-xs mt-2">{analysis.final.consensus}</p>
                                        )}
                                    </div>
                                ) : null;
                            })}
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}