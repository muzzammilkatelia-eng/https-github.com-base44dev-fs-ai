import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, Award, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PerformanceStatsComparison({ players }) {
    const getRecentSeasonStats = (player) => {
        if (!player.career_history || player.career_history.length === 0) {
            return null;
        }
        
        // Get most recent season
        const recent = player.career_history[0];
        return {
            season: recent.season,
            club: recent.club,
            appearances: recent.appearances || 0,
            goals: recent.goals || 0,
            assists: recent.assists || 0,
            minutes: recent.minutes_played || 0,
            goals_per_90: recent.minutes_played > 0 
                ? ((recent.goals || 0) / (recent.minutes_played / 90)).toFixed(2)
                : 0,
            assists_per_90: recent.minutes_played > 0
                ? ((recent.assists || 0) / (recent.minutes_played / 90)).toFixed(2)
                : 0
        };
    };

    const getCareerTotals = (player) => {
        if (!player.career_history || player.career_history.length === 0) {
            return { appearances: 0, goals: 0, assists: 0 };
        }

        return player.career_history.reduce((acc, season) => ({
            appearances: acc.appearances + (season.appearances || 0),
            goals: acc.goals + (season.goals || 0),
            assists: acc.assists + (season.assists || 0)
        }), { appearances: 0, goals: 0, assists: 0 });
    };

    const getBestStat = (stat, values) => {
        return Math.max(...values.filter(v => v !== null && v !== undefined));
    };

    const StatRow = ({ label, icon: Icon, values, format = (v) => v, higher = true }) => {
        const bestValue = higher ? getBestStat(label, values) : Math.min(...values.filter(v => v !== null && v !== undefined));
        
        return (
            <div className="bg-slate-800/30 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-3">
                    <Icon className="w-4 h-4 text-cyan-400" />
                    <span className="text-slate-300 text-sm font-medium">{label}</span>
                </div>
                <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${players.length}, 1fr)` }}>
                    {players.map((player, idx) => {
                        const value = values[idx];
                        const isBest = value === bestValue && value !== null && value !== undefined;
                        
                        return (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: 0.05 * idx }}
                                className={`text-center p-2 rounded ${
                                    isBest ? 'bg-emerald-500/20 border border-emerald-500/30' : 'bg-slate-700/30'
                                }`}
                            >
                                <div className={`font-bold text-lg ${
                                    isBest ? 'text-emerald-400' : 'text-white'
                                }`}>
                                    {value !== null && value !== undefined ? format(value) : 'N/A'}
                                </div>
                                <div className="text-xs text-slate-400 truncate">
                                    {player.name.split(' ')[0]}
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Activity className="w-5 h-5 text-purple-400" />
                    Performance Statistics
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* Recent Season Stats */}
                <div className="space-y-3">
                    <div className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        <h3 className="text-cyan-400 font-semibold">Recent Season Performance</h3>
                    </div>

                    <StatRow
                        label="Appearances"
                        icon={Activity}
                        values={players.map(p => getRecentSeasonStats(p)?.appearances)}
                    />

                    <StatRow
                        label="Goals"
                        icon={Target}
                        values={players.map(p => getRecentSeasonStats(p)?.goals)}
                    />

                    <StatRow
                        label="Assists"
                        icon={Award}
                        values={players.map(p => getRecentSeasonStats(p)?.assists)}
                    />

                    <StatRow
                        label="Goals per 90 min"
                        icon={Target}
                        values={players.map(p => getRecentSeasonStats(p)?.goals_per_90)}
                        format={(v) => v || '0.00'}
                    />

                    <StatRow
                        label="Assists per 90 min"
                        icon={Award}
                        values={players.map(p => getRecentSeasonStats(p)?.assists_per_90)}
                        format={(v) => v || '0.00'}
                    />
                </div>

                {/* Career Totals */}
                <div className="space-y-3 pt-4 border-t border-slate-700">
                    <div className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-400" />
                        <h3 className="text-amber-400 font-semibold">Career Totals</h3>
                    </div>

                    <StatRow
                        label="Total Appearances"
                        icon={Activity}
                        values={players.map(p => getCareerTotals(p).appearances)}
                    />

                    <StatRow
                        label="Total Goals"
                        icon={Target}
                        values={players.map(p => getCareerTotals(p).goals)}
                    />

                    <StatRow
                        label="Total Assists"
                        icon={Award}
                        values={players.map(p => getCareerTotals(p).assists)}
                    />
                </div>

                {/* Awards Summary */}
                {players.some(p => p.awards_honours?.length > 0) && (
                    <div className="space-y-3 pt-4 border-t border-slate-700">
                        <div className="flex items-center gap-2">
                            <Award className="w-5 h-5 text-yellow-400" />
                            <h3 className="text-yellow-400 font-semibold">Awards & Honours</h3>
                        </div>

                        <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${players.length}, 1fr)` }}>
                            {players.map((player, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.1 * idx }}
                                    className="bg-slate-800/50 rounded-lg p-4"
                                >
                                    <p className="text-white font-semibold mb-2 text-sm truncate">
                                        {player.name.split(' ')[0]}
                                    </p>
                                    {player.awards_honours?.length > 0 ? (
                                        <div className="space-y-1 max-h-40 overflow-y-auto">
                                            {player.awards_honours.slice(0, 5).map((award, i) => (
                                                <div key={i} className="text-xs text-slate-300">
                                                    <Badge variant="outline" className="text-xs border-yellow-500/30 text-yellow-400 mb-1">
                                                        {award.year}
                                                    </Badge>
                                                    <p className="text-slate-400">{award.award_name}</p>
                                                </div>
                                            ))}
                                            {player.awards_honours.length > 5 && (
                                                <p className="text-slate-500 text-xs italic">
                                                    +{player.awards_honours.length - 5} more
                                                </p>
                                            )}
                                        </div>
                                    ) : (
                                        <p className="text-slate-500 text-xs">No awards listed</p>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}