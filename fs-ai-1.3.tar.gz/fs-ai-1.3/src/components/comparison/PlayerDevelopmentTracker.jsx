import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, TrendingUp, LineChart as LineChartIcon, Sparkles, Plus, Eye } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, Area, AreaChart } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PlayerDevelopmentTracker() {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [trackingNotes, setTrackingNotes] = useState('');
    const [prediction, setPrediction] = useState(null);
    const [predicting, setPredicting] = useState(false);

    const queryClient = useQueryClient();

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const { data: savedPlayers = [] } = useQuery({
        queryKey: ['saved-players'],
        queryFn: () => base44.entities.SavedPlayer.list('-updated_date', 200)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 200)
    });

    const addToWatchlistMutation = useMutation({
        mutationFn: (data) => base44.entities.SavedPlayer.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['saved-players'] });
            toast.success('Added to watchlist');
            setTrackingNotes('');
        }
    });

    const analyzedPlayer = selectedPlayer ? players.find(p => p.id === selectedPlayer) : null;
    const isTracked = savedPlayers.some(sp => sp.player_name === analyzedPlayer?.name);

    const addToWatchlist = () => {
        if (!analyzedPlayer) return;
        
        addToWatchlistMutation.mutate({
            player_name: analyzedPlayer.name,
            player_id: analyzedPlayer.id,
            position: analyzedPlayer.position,
            age: analyzedPlayer.age,
            current_club: analyzedPlayer.current_club,
            market_value: analyzedPlayer.market_value,
            reason: trackingNotes || 'Talent ID prospect',
            watch_status: 'Monitoring'
        });
    };

    const predictDevelopment = async () => {
        if (!analyzedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setPredicting(true);
        toast.loading('AI predicting development trajectory...', { id: 'predict' });

        try {
            const careerData = analyzedPlayer.career_history?.slice(-5).map(season => ({
                season: season.season,
                appearances: season.appearances || 0,
                goals: season.goals || 0,
                assists: season.assists || 0,
                minutes: season.minutes_played || 0
            })) || [];

            const projection = projections.find(p => p.player_name?.toLowerCase() === analyzedPlayer.name?.toLowerCase());

            const prompt = `You are an elite player development analyst. Predict the future development trajectory for this player:

PLAYER: ${analyzedPlayer.name}
Current Age: ${analyzedPlayer.age}
Position: ${analyzedPlayer.position}
Current Club: ${analyzedPlayer.current_club} (${analyzedPlayer.league})
Market Value: €${analyzedPlayer.market_value || 'N/A'}M
FS-AI Score: ${analyzedPlayer.fsai_proprietary_score || 'N/A'}
Investment Grade: ${analyzedPlayer.fsai_investment_grade || 'N/A'}

CAREER PROGRESSION (Last 5 Seasons):
${careerData.map(s => `${s.season}: ${s.appearances} apps, ${s.goals}G, ${s.assists}A, ${s.minutes} mins`).join('\n') || 'Limited history'}

${projection ? `EXISTING PROJECTION:
Trajectory: ${projection.potential_trajectory}
Peak Rating: ${projection.peak_potential_rating}/10
Years to Peak: ${projection.years_to_peak}
Risk Factors: ${projection.risk_factors?.join(', ')}` : 'No existing projection'}

Physical Profile: ${JSON.stringify(analyzedPlayer.physical_attributes)}
Playing Style: ${JSON.stringify(analyzedPlayer.playing_style)}

PREDICT DEVELOPMENT TRAJECTORY:

1. **Growth Curve**: Map attribute development over next 5 years
2. **Peak Timeline**: When will they reach their peak?
3. **Attribute Projections**: Predict specific skill improvements
4. **Performance Milestones**: Expected achievements by age/season
5. **Development Speed**: Fast riser, steady growth, or late bloomer?
6. **Ceiling Assessment**: Maximum potential rating
7. **Value Trajectory**: How will market value evolve?
8. **Development Risks**: What could derail progress?
9. **Optimal Pathway**: Best environment/role for development
10. **Comparison to Elite**: How close can they get to world-class?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        growth_curve: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age: { type: "number" },
                                    year: { type: "string" },
                                    overall_rating: { type: "number" },
                                    technical: { type: "number" },
                                    physical: { type: "number" },
                                    mental: { type: "number" },
                                    tactical: { type: "number" },
                                    market_value: { type: "number" }
                                }
                            }
                        },
                        peak_timeline: {
                            type: "object",
                            properties: {
                                peak_age: { type: "number" },
                                years_to_peak: { type: "number" },
                                peak_rating: { type: "number" },
                                confidence: { type: "string" }
                            }
                        },
                        attribute_projections: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    attribute: { type: "string" },
                                    current_level: { type: "number" },
                                    projected_level: { type: "number" },
                                    growth_potential: { type: "string" },
                                    timeline: { type: "string" }
                                }
                            }
                        },
                        performance_milestones: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age: { type: "number" },
                                    milestone: { type: "string" },
                                    likelihood: { type: "string" }
                                }
                            }
                        },
                        development_speed: { type: "string" },
                        ceiling_assessment: {
                            type: "object",
                            properties: {
                                maximum_rating: { type: "number" },
                                realistic_ceiling: { type: "number" },
                                ceiling_description: { type: "string" }
                            }
                        },
                        value_trajectory: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "string" },
                                    projected_value: { type: "number" },
                                    value_driver: { type: "string" }
                                }
                            }
                        },
                        development_risks: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    risk: { type: "string" },
                                    probability: { type: "string" },
                                    impact: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        optimal_pathway: {
                            type: "object",
                            properties: {
                                ideal_environment: { type: "string" },
                                recommended_role: { type: "string" },
                                development_plan: { type: "string" }
                            }
                        },
                        elite_comparison: { type: "string" },
                        final_verdict: { type: "string" }
                    }
                }
            });

            setPrediction(response);
            toast.success('Development prediction complete!', { id: 'predict' });
        } catch (error) {
            console.error('Prediction failed:', error);
            toast.error('Failed to predict development', { id: 'predict' });
        } finally {
            setPredicting(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                    Player Development Tracker
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Track prospect progress and predict future development with AI
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <label className="text-slate-400 text-sm mb-2 block">Select Player to Track</label>
                    <Select value={selectedPlayer || ''} onValueChange={setSelectedPlayer}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue placeholder="Choose a player..." />
                        </SelectTrigger>
                        <SelectContent>
                            {players.slice(0, 200).map(p => (
                                <SelectItem key={p.id} value={p.id}>
                                    {p.name} - {p.position} ({p.age}y) - €{p.market_value || '?'}M
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                {analyzedPlayer && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Player Card */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <h4 className="text-white text-lg font-bold mb-1">{analyzedPlayer.name}</h4>
                                    <p className="text-slate-400 text-sm">
                                        {analyzedPlayer.position} • {analyzedPlayer.age}y • {analyzedPlayer.current_club}
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="text-amber-400 text-xl font-bold">€{analyzedPlayer.market_value || '?'}M</p>
                                    {analyzedPlayer.fsai_proprietary_score && (
                                        <Badge className="bg-cyan-500/20 text-cyan-400 mt-1">
                                            FS-AI: {analyzedPlayer.fsai_proprietary_score}
                                        </Badge>
                                    )}
                                </div>
                            </div>

                            {/* Career History Chart */}
                            {analyzedPlayer.career_history && analyzedPlayer.career_history.length > 0 && (
                                <div className="mt-4">
                                    <p className="text-slate-400 text-xs mb-2">Career Performance Trend</p>
                                    <ResponsiveContainer width="100%" height={150}>
                                        <AreaChart data={analyzedPlayer.career_history.slice(-5)}>
                                            <XAxis dataKey="season" stroke="#94a3b8" fontSize={10} />
                                            <YAxis stroke="#94a3b8" fontSize={10} />
                                            <Tooltip
                                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                            />
                                            <Area type="monotone" dataKey="goals" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                                            <Area type="monotone" dataKey="assists" stackId="2" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            )}
                        </div>

                        {/* Tracking Actions */}
                        {!isTracked && (
                            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                <p className="text-purple-400 text-sm font-semibold mb-2">Add to Watchlist</p>
                                <Textarea
                                    placeholder="Why are you tracking this player? (Optional)"
                                    value={trackingNotes}
                                    onChange={(e) => setTrackingNotes(e.target.value)}
                                    className="bg-slate-800 border-slate-700 text-white mb-3"
                                />
                                <Button
                                    onClick={addToWatchlist}
                                    disabled={addToWatchlistMutation.isPending}
                                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                                >
                                    {addToWatchlistMutation.isPending ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Adding...
                                        </>
                                    ) : (
                                        <>
                                            <Plus className="w-4 h-4 mr-2" />
                                            Add to Watchlist
                                        </>
                                    )}
                                </Button>
                            </div>
                        )}

                        {isTracked && (
                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                <div className="flex items-center gap-2">
                                    <Eye className="w-4 h-4 text-emerald-400" />
                                    <p className="text-emerald-400 font-semibold">Player is on your watchlist</p>
                                </div>
                            </div>
                        )}

                        {/* AI Development Prediction */}
                        {!prediction ? (
                            <Button
                                onClick={predictDevelopment}
                                disabled={predicting}
                                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                            >
                                {predicting ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Predicting...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Predict Future Development
                                    </>
                                )}
                            </Button>
                        ) : (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-6"
                            >
                                {/* Peak Timeline */}
                                <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-lg p-6 text-center">
                                    <p className="text-slate-400 text-sm mb-2">Projected Peak</p>
                                    <div className="text-5xl font-bold text-emerald-400 mb-2">
                                        {prediction.peak_timeline?.peak_rating}/10
                                    </div>
                                    <p className="text-white text-lg mb-1">
                                        at age {prediction.peak_timeline?.peak_age}
                                    </p>
                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                        {prediction.peak_timeline?.years_to_peak} years away
                                    </Badge>
                                    <p className="text-slate-400 text-xs mt-2">{prediction.peak_timeline?.confidence}</p>
                                </div>

                                {/* Growth Curve Chart */}
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white text-lg">5-Year Development Projection</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ResponsiveContainer width="100%" height={300}>
                                            <LineChart data={prediction.growth_curve}>
                                                <XAxis dataKey="year" stroke="#94a3b8" />
                                                <YAxis stroke="#94a3b8" domain={[0, 100]} />
                                                <Tooltip
                                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                                />
                                                <Legend />
                                                <Line type="monotone" dataKey="overall_rating" stroke="#06b6d4" name="Overall" strokeWidth={3} />
                                                <Line type="monotone" dataKey="technical" stroke="#10b981" name="Technical" />
                                                <Line type="monotone" dataKey="physical" stroke="#f59e0b" name="Physical" />
                                                <Line type="monotone" dataKey="mental" stroke="#a855f7" name="Mental" />
                                                <Line type="monotone" dataKey="tactical" stroke="#ec4899" name="Tactical" />
                                            </LineChart>
                                        </ResponsiveContainer>
                                        <p className="text-slate-400 text-xs mt-3 text-center">
                                            Development Speed: <span className="text-cyan-400 font-semibold">{prediction.development_speed}</span>
                                        </p>
                                    </CardContent>
                                </Card>

                                {/* Attribute Projections */}
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white">Attribute Development Forecast</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {prediction.attribute_projections?.map((attr, idx) => (
                                                <div key={idx} className="bg-slate-900/50 rounded p-3">
                                                    <div className="flex justify-between items-center mb-2">
                                                        <p className="text-white font-semibold">{attr.attribute}</p>
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-slate-400 text-sm">{attr.current_level}</span>
                                                            <span className="text-slate-500">→</span>
                                                            <span className="text-cyan-400 font-bold">{attr.projected_level}</span>
                                                        </div>
                                                    </div>
                                                    <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                                                        <div
                                                            className="bg-gradient-to-r from-cyan-500 to-blue-600 h-2 rounded-full"
                                                            style={{ width: `${(attr.projected_level / 10) * 100}%` }}
                                                        />
                                                    </div>
                                                    <p className="text-slate-400 text-xs">
                                                        {attr.growth_potential} • {attr.timeline}
                                                    </p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Performance Milestones */}
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white">Expected Milestones</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-2">
                                            {prediction.performance_milestones?.map((milestone, idx) => (
                                                <div key={idx} className="flex items-start justify-between bg-slate-900/50 rounded p-3">
                                                    <div className="flex-1">
                                                        <Badge className="bg-purple-500/20 text-purple-400 mb-1">
                                                            Age {milestone.age}
                                                        </Badge>
                                                        <p className="text-white text-sm">{milestone.milestone}</p>
                                                    </div>
                                                    <Badge className={
                                                        milestone.likelihood?.includes('High') ? 'bg-emerald-500/20 text-emerald-400' :
                                                        milestone.likelihood?.includes('Medium') ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {milestone.likelihood}
                                                    </Badge>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Value Trajectory */}
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white">Market Value Projection</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ResponsiveContainer width="100%" height={200}>
                                            <AreaChart data={prediction.value_trajectory}>
                                                <XAxis dataKey="year" stroke="#94a3b8" />
                                                <YAxis stroke="#94a3b8" />
                                                <Tooltip
                                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                                />
                                                <Area type="monotone" dataKey="projected_value" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </CardContent>
                                </Card>

                                {/* Development Risks */}
                                <Card className="bg-red-500/10 border-red-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-red-400">Development Risks</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {prediction.development_risks?.map((risk, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded p-3">
                                                    <div className="flex items-start justify-between mb-2">
                                                        <h5 className="text-white font-semibold text-sm">{risk.risk}</h5>
                                                        <div className="flex gap-2">
                                                            <Badge className="bg-red-500/20 text-red-400 text-xs">{risk.probability}</Badge>
                                                            <Badge className="bg-amber-500/20 text-amber-400 text-xs">{risk.impact}</Badge>
                                                        </div>
                                                    </div>
                                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded p-2">
                                                        <p className="text-cyan-400 text-xs">Mitigation: {risk.mitigation}</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Optimal Pathway */}
                                <Card className="bg-purple-500/10 border-purple-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-purple-400">Optimal Development Pathway</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Ideal Environment</p>
                                            <p className="text-white text-sm">{prediction.optimal_pathway?.ideal_environment}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Recommended Role</p>
                                            <p className="text-white text-sm">{prediction.optimal_pathway?.recommended_role}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Development Plan</p>
                                            <p className="text-slate-300 text-sm">{prediction.optimal_pathway?.development_plan}</p>
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Elite Comparison */}
                                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                                    <h4 className="text-cyan-400 font-semibold mb-2">Path to Elite Level</h4>
                                    <p className="text-slate-300 text-sm">{prediction.elite_comparison}</p>
                                </div>

                                {/* Final Verdict */}
                                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                                    <h4 className="text-white font-semibold mb-2">Development Assessment</h4>
                                    <p className="text-slate-300 leading-relaxed">{prediction.final_verdict}</p>
                                </div>

                                <div className="flex gap-3">
                                    <Button onClick={() => setPrediction(null)} variant="outline" className="flex-1">
                                        Analyze Another Player
                                    </Button>
                                    <Link to={createPageUrl('PlayerProfile') + `?playerName=${encodeURIComponent(analyzedPlayer.name)}`}>
                                        <Button variant="outline">
                                            View Full Profile
                                        </Button>
                                    </Link>
                                </div>
                            </motion.div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}