import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X, Users, ArrowUpDown, Eye, ChevronUp, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { motion, AnimatePresence } from 'framer-motion';

const PLAYER_COLORS = ['#06b6d4', '#a855f7', '#f59e0b', '#10b981'];

const StatBar = ({ value, maxValue = 100, color = '#06b6d4', showValue = true }) => {
    const percentage = Math.min((value / maxValue) * 100, 100);
    return (
        <div className="flex items-center gap-2 w-full">
            <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                    className="h-full rounded-full"
                    style={{ backgroundColor: color }}
                />
            </div>
            {showValue && <span className="text-white text-xs w-8 text-right">{value ?? '-'}</span>}
        </div>
    );
};

const DifferenceIndicator = ({ values, statKey }) => {
    const numericValues = values.filter(v => v != null && !isNaN(v));
    if (numericValues.length < 2) return null;
    
    const max = Math.max(...numericValues);
    const min = Math.min(...numericValues);
    const diff = max - min;
    
    if (diff === 0) return null;
    
    const diffPercent = ((diff / max) * 100).toFixed(0);
    const isSignificant = diff > (max * 0.15); // >15% difference is significant
    
    return (
        <Badge className={`text-xs ${isSignificant ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-700 text-slate-400'}`}>
            Δ {diffPercent}%
        </Badge>
    );
};

const STAT_CATEGORIES = {
    basic: {
        label: 'Basic Info',
        stats: [
            { key: 'age', label: 'Age', max: 45 },
            { key: 'market_value', label: 'Market Value (€M)', max: 200 },
            { key: 'fsai_proprietary_score', label: 'FS-AI Score', max: 100 },
        ]
    },
    attacking: {
        label: 'Attacking',
        stats: [
            { key: 'detailed_stats.attacking.goals', label: 'Goals', max: 50 },
            { key: 'detailed_stats.attacking.assists', label: 'Assists', max: 30 },
            { key: 'detailed_stats.attacking.shots_per_game', label: 'Shots/Game', max: 5 },
            { key: 'detailed_stats.attacking.shot_accuracy', label: 'Shot Accuracy %', max: 100 },
            { key: 'detailed_stats.attacking.expected_goals', label: 'xG', max: 30 },
            { key: 'detailed_stats.attacking.expected_assists', label: 'xA', max: 20 },
        ]
    },
    passing: {
        label: 'Passing',
        stats: [
            { key: 'detailed_stats.passing.accuracy', label: 'Pass Accuracy %', max: 100 },
            { key: 'detailed_stats.passing.key_passes_per_game', label: 'Key Passes/Game', max: 5 },
            { key: 'detailed_stats.passing.crosses_per_game', label: 'Crosses/Game', max: 10 },
            { key: 'detailed_stats.passing.cross_accuracy', label: 'Cross Accuracy %', max: 100 },
        ]
    },
    defending: {
        label: 'Defending',
        stats: [
            { key: 'detailed_stats.defending.tackles_per_game', label: 'Tackles/Game', max: 5 },
            { key: 'detailed_stats.defending.tackling_success_rate', label: 'Tackle Success %', max: 100 },
            { key: 'detailed_stats.defending.interceptions_per_game', label: 'Interceptions/Game', max: 5 },
            { key: 'detailed_stats.defending.aerial_duels_won_pct', label: 'Aerial Duels Won %', max: 100 },
        ]
    },
    possession: {
        label: 'Possession',
        stats: [
            { key: 'detailed_stats.possession.dribbles_per_game', label: 'Dribbles/Game', max: 10 },
            { key: 'detailed_stats.possession.dribble_success_rate', label: 'Dribble Success %', max: 100 },
            { key: 'detailed_stats.possession.touches_per_game', label: 'Touches/Game', max: 100 },
        ]
    },
    physical: {
        label: 'Physical',
        stats: [
            { key: 'physical_attributes.height', label: 'Height (cm)', max: 210 },
            { key: 'physical_attributes.weight', label: 'Weight (kg)', max: 100 },
            { key: 'physical_attributes.pace', label: 'Pace', max: 100 },
            { key: 'physical_attributes.strength', label: 'Strength', max: 100 },
        ]
    }
};

const getNestedValue = (obj, path) => {
    if (!path || !obj) return null;
    return path.split('.').reduce((acc, part) => acc?.[part], obj);
};

export default function QuickComparePanel({ initialPlayers = [], onClose }) {
    const [selectedPlayers, setSelectedPlayers] = useState(initialPlayers);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'desc' });
    const [activeCategory, setActiveCategory] = useState('basic');

    const { data: allPlayers = [] } = useQuery({
        queryKey: ['players-compare'],
        queryFn: () => base44.entities.Player.list()
    });

    const filteredPlayers = useMemo(() => {
        if (!searchQuery) return [];
        return allPlayers
            .filter(p => 
                !selectedPlayers.find(sp => sp.id === p.id) &&
                (p.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                 p.current_club?.toLowerCase().includes(searchQuery.toLowerCase()))
            )
            .slice(0, 8);
    }, [allPlayers, searchQuery, selectedPlayers]);

    const addPlayer = (player) => {
        if (selectedPlayers.length >= 4) return;
        if (selectedPlayers.find(p => p.id === player.id)) return;
        setSelectedPlayers([...selectedPlayers, player]);
        setSearchQuery('');
    };

    const removePlayer = (playerId) => {
        setSelectedPlayers(selectedPlayers.filter(p => p.id !== playerId));
    };

    const handleSort = (statKey) => {
        setSortConfig(prev => ({
            key: statKey,
            direction: prev.key === statKey && prev.direction === 'desc' ? 'asc' : 'desc'
        }));
    };

    const sortedPlayers = useMemo(() => {
        if (!sortConfig.key) return selectedPlayers;
        return [...selectedPlayers].sort((a, b) => {
            const aVal = getNestedValue(a, sortConfig.key) ?? 0;
            const bVal = getNestedValue(b, sortConfig.key) ?? 0;
            return sortConfig.direction === 'desc' ? bVal - aVal : aVal - bVal;
        });
    }, [selectedPlayers, sortConfig]);

    const getMaxValueForStat = (statKey, stats) => {
        const values = selectedPlayers.map(p => getNestedValue(p, statKey)).filter(v => v != null);
        if (values.length === 0) return stats.find(s => s.key === statKey)?.max || 100;
        return Math.max(...values, stats.find(s => s.key === statKey)?.max || 100);
    };

    const currentStats = STAT_CATEGORIES[activeCategory]?.stats || [];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-cyan-400" />
                        Quick Compare ({selectedPlayers.length}/4)
                    </CardTitle>
                    {onClose && (
                        <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-400">
                            <X className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Player Search */}
                {selectedPlayers.length < 4 && (
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                        <Input
                            placeholder="Search players to add..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 bg-slate-800 border-slate-700 text-white"
                        />
                        {filteredPlayers.length > 0 && (
                            <div className="absolute z-10 w-full mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto">
                                {filteredPlayers.map(player => (
                                    <button
                                        key={player.id}
                                        onClick={() => addPlayer(player)}
                                        className="w-full text-left p-3 hover:bg-slate-700 transition-colors border-b border-slate-700 last:border-0"
                                    >
                                        <p className="text-white font-medium">{player.name}</p>
                                        <p className="text-slate-400 text-xs">
                                            {player.position} • {player.age}y • {player.current_club}
                                        </p>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Selected Players Tags */}
                <div className="flex flex-wrap gap-2">
                    <AnimatePresence>
                        {selectedPlayers.map((player, idx) => (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.8 }}
                            >
                                <Badge 
                                    className="text-sm px-3 py-2 gap-2"
                                    style={{ backgroundColor: `${PLAYER_COLORS[idx]}20`, color: PLAYER_COLORS[idx], borderColor: `${PLAYER_COLORS[idx]}50` }}
                                >
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PLAYER_COLORS[idx] }} />
                                    {player.name}
                                    <button onClick={() => removePlayer(player.id)} className="hover:opacity-70">
                                        <X className="w-3 h-3" />
                                    </button>
                                </Badge>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>

                {selectedPlayers.length >= 2 && (
                    <>
                        {/* Category Selector */}
                        <div className="flex gap-2 flex-wrap">
                            {Object.entries(STAT_CATEGORIES).map(([key, cat]) => (
                                <Button
                                    key={key}
                                    variant={activeCategory === key ? 'default' : 'outline'}
                                    size="sm"
                                    onClick={() => setActiveCategory(key)}
                                    className={activeCategory === key 
                                        ? 'bg-cyan-600 hover:bg-cyan-700' 
                                        : 'border-slate-700 text-slate-300 hover:bg-slate-800'}
                                >
                                    {cat.label}
                                </Button>
                            ))}
                        </div>

                        {/* Comparison Table */}
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead>
                                    <tr className="border-b border-slate-700">
                                        <th className="text-left text-slate-400 text-xs font-medium py-2 px-2 w-32">Stat</th>
                                        {sortedPlayers.map((player, idx) => (
                                            <th key={player.id} className="text-center py-2 px-2 min-w-32">
                                                <div className="flex flex-col items-center gap-1">
                                                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PLAYER_COLORS[idx] }} />
                                                    <span className="text-white text-xs font-medium truncate max-w-24">
                                                        {player.name.split(' ').pop()}
                                                    </span>
                                                </div>
                                            </th>
                                        ))}
                                        <th className="text-center text-slate-400 text-xs font-medium py-2 px-2 w-16">Diff</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentStats.map((stat) => {
                                        const values = sortedPlayers.map(p => getNestedValue(p, stat.key));
                                        const maxInGroup = Math.max(...values.filter(v => v != null), 0);
                                        const dynamicMax = Math.max(maxInGroup, stat.max * 0.5);

                                        return (
                                            <tr key={stat.key} className="border-b border-slate-800 hover:bg-slate-800/30">
                                                <td className="py-3 px-2">
                                                    <button
                                                        onClick={() => handleSort(stat.key)}
                                                        className="flex items-center gap-1 text-slate-300 text-xs hover:text-white transition-colors"
                                                    >
                                                        {stat.label}
                                                        {sortConfig.key === stat.key && (
                                                            sortConfig.direction === 'desc' 
                                                                ? <ChevronDown className="w-3 h-3" />
                                                                : <ChevronUp className="w-3 h-3" />
                                                        )}
                                                    </button>
                                                </td>
                                                {sortedPlayers.map((player, idx) => {
                                                    const value = getNestedValue(player, stat.key);
                                                    const isMax = value != null && value === maxInGroup && maxInGroup > 0;
                                                    return (
                                                        <td key={player.id} className="py-3 px-2">
                                                            <div className="flex flex-col items-center gap-1">
                                                                <StatBar 
                                                                    value={value} 
                                                                    maxValue={dynamicMax} 
                                                                    color={PLAYER_COLORS[idx]}
                                                                />
                                                                {isMax && values.filter(v => v === maxInGroup).length === 1 && (
                                                                    <Badge className="text-xs bg-emerald-500/20 text-emerald-400 px-1">
                                                                        Best
                                                                    </Badge>
                                                                )}
                                                            </div>
                                                        </td>
                                                    );
                                                })}
                                                <td className="py-3 px-2 text-center">
                                                    <DifferenceIndicator values={values} statKey={stat.key} />
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>

                        {/* Quick Actions */}
                        <div className="flex justify-end gap-2 pt-2">
                            <Link to={createPageUrl('PlayerComparison')}>
                                <Button variant="outline" size="sm" className="border-slate-700 text-slate-300">
                                    <Eye className="w-4 h-4 mr-2" />
                                    Full Comparison
                                </Button>
                            </Link>
                        </div>
                    </>
                )}

                {selectedPlayers.length < 2 && (
                    <div className="text-center py-8 text-slate-500">
                        Select at least 2 players to compare
                    </div>
                )}
            </CardContent>
        </Card>
    );
}