import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { BarChart3, Target } from 'lucide-react';

export default function StatisticalBreakdown({ playersData }) {
    if (!playersData || playersData.length === 0) return null;

    const colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    // Prepare radar chart data
    const radarData = [
        'Technical',
        'Physical', 
        'Mental',
        'Tactical'
    ].map(category => {
        const dataPoint = { category };
        playersData.forEach(player => {
            if (player.latest_report) {
                dataPoint[player.name] = player.latest_report[`${category.toLowerCase()}_rating`] || 0;
            }
        });
        return dataPoint;
    });

    // Prepare bar chart data for comparison
    const barData = playersData.map(player => ({
        name: player.name,
        technical: player.latest_report?.technical_rating || 0,
        physical: player.latest_report?.physical_rating || 0,
        mental: player.latest_report?.mental_rating || 0,
        tactical: player.latest_report?.tactical_rating || 0,
        overall: player.latest_report?.overall_rating || 0
    }));

    return (
        <div className="grid md:grid-cols-2 gap-6">
            {/* Radar Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-400" />
                        Multi-Attribute Radar
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <RadarChart data={radarData}>
                            <PolarGrid stroke="#475569" />
                            <PolarAngleAxis dataKey="category" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <PolarRadiusAxis angle={90} domain={[0, 10]} stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ 
                                    backgroundColor: '#1e293b', 
                                    border: '1px solid #475569',
                                    borderRadius: '8px',
                                    color: '#fff'
                                }} 
                            />
                            <Legend />
                            {playersData.map((player, index) => (
                                <Radar
                                    key={player.name}
                                    name={player.name}
                                    dataKey={player.name}
                                    stroke={colors[index % colors.length]}
                                    fill={colors[index % colors.length]}
                                    fillOpacity={0.3}
                                />
                            ))}
                        </RadarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Bar Chart Comparison */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-amber-400" />
                        Rating Comparison
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <BarChart data={barData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="name" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <YAxis domain={[0, 10]} stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <Tooltip 
                                contentStyle={{ 
                                    backgroundColor: '#1e293b', 
                                    border: '1px solid #475569',
                                    borderRadius: '8px',
                                    color: '#fff'
                                }} 
                            />
                            <Legend />
                            <Bar dataKey="technical" fill="#8b5cf6" name="Technical" />
                            <Bar dataKey="physical" fill="#f59e0b" name="Physical" />
                            <Bar dataKey="mental" fill="#10b981" name="Mental" />
                            <Bar dataKey="overall" fill="#06b6d4" name="Overall" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Statistical Summary Cards */}
            <Card className="bg-slate-900/50 border-slate-800 md:col-span-2">
                <CardHeader>
                    <CardTitle className="text-white">Player Statistics Summary</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {playersData.map((player, index) => (
                            <div key={player.name} className="bg-slate-800/50 rounded-lg p-4 space-y-3">
                                <div className="flex items-center justify-between mb-3">
                                    <h4 className="text-white font-semibold">{player.name}</h4>
                                    <div 
                                        className="w-3 h-3 rounded-full"
                                        style={{ backgroundColor: colors[index % colors.length] }}
                                    />
                                </div>
                                
                                <div className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Overall Rating</span>
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            {player.latest_report?.overall_rating || 'N/A'}/10
                                        </Badge>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Age</span>
                                        <span className="text-white">{player.age}y</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Market Value</span>
                                        <span className="text-amber-400 font-semibold">€{player.market_value}M</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Reports Count</span>
                                        <span className="text-white">{player.reports?.length || 0}</span>
                                    </div>
                                    {player.injury_prone_score !== undefined && (
                                        <div className="flex justify-between text-sm">
                                            <span className="text-slate-400">Injury Risk</span>
                                            <Badge className={
                                                player.injury_prone_score > 70 ? 'bg-red-500/20 text-red-400' :
                                                player.injury_prone_score > 40 ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-emerald-500/20 text-emerald-400'
                                            }>
                                                {player.injury_prone_score}/100
                                            </Badge>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}