import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Target, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function TacticalSystemAnalysis({ playersData }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzeSystems = async () => {
        setIsAnalyzing(true);
        toast.loading('AI analyzing tactical fit...', { id: 'tactical-systems' });

        try {
            const playersInfo = playersData.map(p => ({
                name: p.name,
                position: p.position,
                age: p.age,
                physical: p.physical_attributes,
                playing_style: p.playing_style,
                latest_report: p.latest_report,
                strengths: p.latest_report?.strengths,
                weaknesses: p.latest_report?.weaknesses
            }));

            const prompt = `Analyze how these ${playersData.length} players would fit in different tactical systems:

PLAYERS:
${playersInfo.map((p, i) => `
${i + 1}. ${p.name} (${p.position}, ${p.age}y)
   - Physical: ${JSON.stringify(p.physical)}
   - Style: ${JSON.stringify(p.playing_style)}
   - Latest Rating: ${p.latest_report?.overall_rating}/10
   - Strengths: ${p.strengths}
   - Weaknesses: ${p.weaknesses}
`).join('\n')}

ANALYZE FIT FOR THESE SYSTEMS:
1. 4-3-3 (High Pressing)
2. 4-2-3-1 (Counter-Attack)
3. 3-5-2 (Wing-Back Focus)
4. 4-4-2 (Direct)
5. 3-4-3 (Possession)

For each system, provide:
- Best player fit and why (0-100 score)
- How each player would perform
- Synergy between players if used together
- Key tactical advantages
- Potential weaknesses`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        systems: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    formation: { type: "string" },
                                    description: { type: "string" },
                                    player_fits: {
                                        type: "array",
                                        items: {
                                            type: "object",
                                            properties: {
                                                player_name: { type: "string" },
                                                fit_score: { type: "number" },
                                                role_in_system: { type: "string" },
                                                reasoning: { type: "string" }
                                            }
                                        }
                                    },
                                    best_fit_player: { type: "string" },
                                    synergy_rating: { type: "number" },
                                    tactical_advantages: { type: "array", items: { type: "string" } },
                                    potential_weaknesses: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        overall_best_system: { type: "string" },
                        recommendations: { type: "string" }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Tactical analysis complete!', { id: 'tactical-systems' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze tactical systems', { id: 'tactical-systems' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getScoreColor = (score) => {
        if (score >= 80) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (score >= 60) return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        if (score >= 40) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Tactical System Fit Analysis
                    </CardTitle>
                    {!analysis && (
                        <Button
                            onClick={analyzeSystems}
                            disabled={isAnalyzing}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Analyze Systems
                                </>
                            )}
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-12">
                        <Target className="w-16 h-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                        <p className="text-slate-400 mb-2">
                            Discover how players fit in different tactical systems
                        </p>
                        <p className="text-slate-500 text-sm">
                            AI will analyze {playersData.length} players across 5 formations
                        </p>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {/* Best System */}
                        <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h4 className="text-emerald-400 font-semibold mb-2">Recommended System</h4>
                            <p className="text-white text-xl font-bold mb-2">{analysis.overall_best_system}</p>
                            <p className="text-slate-300 text-sm">{analysis.recommendations}</p>
                        </div>

                        {/* Tactical Systems Tabs */}
                        <Tabs defaultValue="0" className="w-full">
                            <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                                {analysis.systems?.map((system, idx) => (
                                    <TabsTrigger key={idx} value={idx.toString()}>
                                        {system.formation}
                                    </TabsTrigger>
                                ))}
                            </TabsList>

                            {analysis.systems?.map((system, idx) => (
                                <TabsContent key={idx} value={idx.toString()} className="space-y-4 mt-6">
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h4 className="text-white font-semibold mb-2">{system.formation}</h4>
                                        <p className="text-slate-300 text-sm mb-3">{system.description}</p>
                                        
                                        {/* Synergy Rating */}
                                        <div className="flex items-center gap-3 mb-4">
                                            <span className="text-slate-400 text-sm">Team Synergy:</span>
                                            <Progress value={system.synergy_rating} className="flex-1" />
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                {system.synergy_rating}%
                                            </Badge>
                                        </div>

                                        {/* Best Fit Player */}
                                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 mb-4">
                                            <p className="text-emerald-400 text-xs font-semibold mb-1">
                                                Best Fit for This System
                                            </p>
                                            <p className="text-white font-semibold">{system.best_fit_player}</p>
                                        </div>
                                    </div>

                                    {/* Player Fits */}
                                    <div className="space-y-3">
                                        <h5 className="text-white font-semibold">Player Analysis</h5>
                                        {system.player_fits?.map((fit, i) => (
                                            <div key={i} className="bg-slate-800/50 rounded-lg p-4">
                                                <div className="flex items-start justify-between mb-3">
                                                    <div>
                                                        <h6 className="text-white font-semibold">{fit.player_name}</h6>
                                                        <p className="text-cyan-400 text-sm">{fit.role_in_system}</p>
                                                    </div>
                                                    <Badge className={getScoreColor(fit.fit_score)}>
                                                        {fit.fit_score}/100
                                                    </Badge>
                                                </div>
                                                <div className="w-full bg-slate-700 rounded-full h-2 mb-3">
                                                    <div 
                                                        className={`h-2 rounded-full ${
                                                            fit.fit_score >= 80 ? 'bg-emerald-500' :
                                                            fit.fit_score >= 60 ? 'bg-cyan-500' :
                                                            fit.fit_score >= 40 ? 'bg-amber-500' :
                                                            'bg-red-500'
                                                        }`}
                                                        style={{ width: `${fit.fit_score}%` }}
                                                    />
                                                </div>
                                                <p className="text-slate-300 text-sm">{fit.reasoning}</p>
                                            </div>
                                        ))}
                                    </div>

                                    {/* Advantages & Weaknesses */}
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                            <h5 className="text-emerald-400 font-semibold mb-2 text-sm">
                                                Tactical Advantages
                                            </h5>
                                            <ul className="space-y-1">
                                                {system.tactical_advantages?.map((adv, i) => (
                                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                        <span className="text-emerald-400 mt-0.5">✓</span>
                                                        {adv}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                            <h5 className="text-amber-400 font-semibold mb-2 text-sm">
                                                Potential Weaknesses
                                            </h5>
                                            <ul className="space-y-1">
                                                {system.potential_weaknesses?.map((weak, i) => (
                                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                        <span className="text-amber-400 mt-0.5">⚠</span>
                                                        {weak}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </TabsContent>
                            ))}
                        </Tabs>

                        <Button
                            onClick={analyzeSystems}
                            variant="outline"
                            className="w-full border-slate-700"
                            size="sm"
                        >
                            Refresh Analysis
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}