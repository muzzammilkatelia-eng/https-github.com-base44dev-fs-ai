import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Search, TrendingUp, Star, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useMutation, useQueryClient } from '@tanstack/react-query';

export default function TalentIDScanner() {
    const [searchCriteria, setSearchCriteria] = useState({
        position: '',
        minAge: 16,
        maxAge: 25,
        maxValue: 50,
        minRating: 70,
        specificAttributes: ''
    });
    const [matches, setMatches] = useState(null);
    const [scanning, setScanning] = useState(false);

    const queryClient = useQueryClient();

    const addToWatchlistMutation = useMutation({
        mutationFn: (data) => base44.entities.SavedPlayer.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['saved-players'] });
            toast.success('Added to watchlist');
        }
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 10000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 200)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 200)
    });

    const scanForTalent = async () => {
        setScanning(true);
        toast.loading('Scanning database for talent...', { id: 'scan' });

        try {
            // Filter players based on basic criteria
            const filtered = players.filter(p => {
                if (searchCriteria.position && p.position !== searchCriteria.position) return false;
                if (p.age < searchCriteria.minAge || p.age > searchCriteria.maxAge) return false;
                if (p.market_value && p.market_value > searchCriteria.maxValue) return false;
                if (searchCriteria.minRating > 0 && (!p.fsai_proprietary_score || p.fsai_proprietary_score < searchCriteria.minRating)) return false;
                return true;
            });

            if (filtered.length === 0) {
                toast.error('No players match your criteria', { id: 'scan' });
                setScanning(false);
                return;
            }

            // AI analysis of top candidates
            const topCandidates = filtered.slice(0, 50).map(p => {
                const playerReports = reports.filter(r => r.player_name?.toLowerCase() === p.name?.toLowerCase());
                const projection = projections.find(pr => pr.player_name?.toLowerCase() === p.name?.toLowerCase());
                
                return {
                    name: p.name,
                    age: p.age,
                    position: p.position,
                    club: p.current_club,
                    league: p.league,
                    value: p.market_value,
                    fsai_score: p.fsai_proprietary_score,
                    grade: p.fsai_investment_grade,
                    latest_report: playerReports[playerReports.length - 1],
                    projection: projection
                };
            });

            const prompt = `You are an elite talent identification specialist. Analyze these ${topCandidates.length} prospects and identify the top hidden gems and high-potential players:

SEARCH CRITERIA:
- Position: ${searchCriteria.position || 'Any'}
- Age Range: ${searchCriteria.minAge}-${searchCriteria.maxAge}
- Max Value: €${searchCriteria.maxValue}M
- Min Rating: ${searchCriteria.minRating}
${searchCriteria.specificAttributes ? `- Specific Requirements: ${searchCriteria.specificAttributes}` : ''}

PROSPECT DATABASE:
${topCandidates.map(p => `
${p.name} (${p.age}y) - ${p.position}
Club: ${p.club} (${p.league})
Value: €${p.value || 'N/A'}M | FS-AI: ${p.fsai_score || 'N/A'} | Grade: ${p.grade || 'N/A'}
${p.projection ? `Trajectory: ${p.projection.potential_trajectory}` : ''}
${p.latest_report ? `Scout Rating: ${p.latest_report.overall_rating}/10` : ''}
`).join('\n')}

Identify and rank the TOP prospects with:
1. **Match Score** (0-100): How well they fit the criteria
2. **Value Rating**: Hidden gem potential vs market value
3. **Development Potential**: Ceiling and timeline
4. **Immediate Impact**: Can they contribute now?
5. **Key Strengths**: What makes them special?
6. **Risk Factors**: What are the concerns?
7. **Recommendation**: Sign now, monitor, or pass?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        top_prospects: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    match_score: { type: "number" },
                                    value_rating: { type: "number" },
                                    hidden_gem_factor: { type: "string" },
                                    development_potential: {
                                        type: "object",
                                        properties: {
                                            ceiling: { type: "string" },
                                            timeline: { type: "string" },
                                            confidence: { type: "string" }
                                        }
                                    },
                                    immediate_impact: {
                                        type: "object",
                                        properties: {
                                            readiness_score: { type: "number" },
                                            deployment_timing: { type: "string" }
                                        }
                                    },
                                    key_strengths: { type: "array", items: { type: "string" } },
                                    risk_factors: { type: "array", items: { type: "string" } },
                                    recommendation: { type: "string" },
                                    tactical_fit: { type: "string" },
                                    scouting_notes: { type: "string" }
                                }
                            }
                        },
                        hidden_gems: {
                            type: "array",
                            items: { type: "string" }
                        },
                        summary: { type: "string" }
                    }
                }
            });

            // Enrich with player data
            const enrichedMatches = response.top_prospects.map(prospect => {
                const playerData = topCandidates.find(p => p.name === prospect.player_name);
                return { ...prospect, playerData };
            });

            setMatches({ ...response, top_prospects: enrichedMatches });
            toast.success(`Found ${enrichedMatches.length} top prospects!`, { id: 'scan' });
        } catch (error) {
            console.error('Talent scan failed:', error);
            toast.error('Failed to scan for talent', { id: 'scan' });
        } finally {
            setScanning(false);
        }
    };

    const getMatchColor = (score) => {
        if (score >= 90) return 'from-emerald-500 to-green-600';
        if (score >= 80) return 'from-cyan-500 to-blue-600';
        if (score >= 70) return 'from-amber-500 to-orange-600';
        return 'from-slate-500 to-slate-600';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Search className="w-5 h-5 text-cyan-400" />
                    Talent ID Scanner
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Scan the database for prospects matching your ideal player profile
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {!matches ? (
                    <>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400 mb-2 block">Position</Label>
                                <Input
                                    placeholder="e.g., Central Midfielder"
                                    value={searchCriteria.position}
                                    onChange={(e) => setSearchCriteria({ ...searchCriteria, position: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400 mb-2 block">Age Range</Label>
                                <div className="flex gap-2">
                                    <Input
                                        type="number"
                                        placeholder="Min"
                                        value={searchCriteria.minAge}
                                        onChange={(e) => setSearchCriteria({ ...searchCriteria, minAge: Number(e.target.value) })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                    <Input
                                        type="number"
                                        placeholder="Max"
                                        value={searchCriteria.maxAge}
                                        onChange={(e) => setSearchCriteria({ ...searchCriteria, maxAge: Number(e.target.value) })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>
                            <div>
                                <Label className="text-slate-400 mb-2 block">Max Market Value (€M)</Label>
                                <Input
                                    type="number"
                                    value={searchCriteria.maxValue}
                                    onChange={(e) => setSearchCriteria({ ...searchCriteria, maxValue: Number(e.target.value) })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400 mb-2 block">Min FS-AI Rating</Label>
                                <Input
                                    type="number"
                                    value={searchCriteria.minRating}
                                    onChange={(e) => setSearchCriteria({ ...searchCriteria, minRating: Number(e.target.value) })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                        </div>
                        <div>
                            <Label className="text-slate-400 mb-2 block">Specific Attributes (Optional)</Label>
                            <Input
                                placeholder="e.g., High work rate, press resistant, excellent passing..."
                                value={searchCriteria.specificAttributes}
                                onChange={(e) => setSearchCriteria({ ...searchCriteria, specificAttributes: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <Button
                            onClick={scanForTalent}
                            disabled={scanning}
                            className="w-full bg-gradient-to-r from-purple-500 to-cyan-600"
                        >
                            {scanning ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Scanning Database...
                                </>
                            ) : (
                                <>
                                    <Search className="w-4 h-4 mr-2" />
                                    Scan for Talent
                                </>
                            )}
                        </Button>
                    </>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Summary */}
                        <div className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-lg p-4">
                            <h3 className="text-purple-400 font-semibold mb-2">Scan Summary</h3>
                            <p className="text-slate-300 text-sm">{matches.summary}</p>
                        </div>

                        {/* Hidden Gems Highlight */}
                        {matches.hidden_gems && matches.hidden_gems.length > 0 && (
                            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                <div className="flex items-center gap-2 mb-2">
                                    <Star className="w-5 h-5 text-amber-400" />
                                    <h3 className="text-amber-400 font-semibold">Hidden Gems Identified</h3>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {matches.hidden_gems.map((gem, i) => (
                                        <Badge key={i} className="bg-amber-500/20 text-amber-400">
                                            {gem}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Top Prospects */}
                        <div className="space-y-4">
                            {matches.top_prospects?.map((prospect, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.1 }}
                                >
                                    <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-colors">
                                        <CardContent className="pt-6">
                                            <div className="flex items-start justify-between mb-4">
                                                <div className="flex-1">
                                                    <Link 
                                                        to={createPageUrl('PlayerProfile') + `?playerName=${encodeURIComponent(prospect.player_name)}`}
                                                        className="text-white text-lg font-bold hover:text-cyan-400 transition-colors"
                                                    >
                                                        {prospect.player_name}
                                                    </Link>
                                                    {prospect.playerData && (
                                                        <p className="text-slate-400 text-sm">
                                                            {prospect.playerData.position} • {prospect.playerData.age}y • {prospect.playerData.club}
                                                        </p>
                                                    )}
                                                </div>
                                                <div className={`text-right bg-gradient-to-r ${getMatchColor(prospect.match_score)} rounded-lg px-4 py-2`}>
                                                    <p className="text-white text-2xl font-bold">{prospect.match_score}</p>
                                                    <p className="text-white/80 text-xs">Match</p>
                                                </div>
                                            </div>

                                            <div className="grid md:grid-cols-3 gap-3 mb-4">
                                                <div className="bg-slate-900/50 rounded p-3">
                                                    <p className="text-slate-400 text-xs">Value Rating</p>
                                                    <p className="text-emerald-400 text-xl font-bold">{prospect.value_rating}/10</p>
                                                    <p className="text-slate-500 text-xs">{prospect.hidden_gem_factor}</p>
                                                </div>
                                                <div className="bg-slate-900/50 rounded p-3">
                                                    <p className="text-slate-400 text-xs">Development</p>
                                                    <p className="text-purple-400 text-sm font-semibold">{prospect.development_potential?.ceiling}</p>
                                                    <p className="text-slate-500 text-xs">{prospect.development_potential?.timeline}</p>
                                                </div>
                                                <div className="bg-slate-900/50 rounded p-3">
                                                    <p className="text-slate-400 text-xs">Readiness</p>
                                                    <p className="text-cyan-400 text-xl font-bold">{prospect.immediate_impact?.readiness_score}/10</p>
                                                    <p className="text-slate-500 text-xs">{prospect.immediate_impact?.deployment_timing}</p>
                                                </div>
                                            </div>

                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-emerald-400 text-xs font-semibold mb-1">Key Strengths</p>
                                                    <div className="flex flex-wrap gap-1">
                                                        {prospect.key_strengths?.map((strength, i) => (
                                                            <Badge key={i} className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                                {strength}
                                                            </Badge>
                                                        ))}
                                                    </div>
                                                </div>

                                                {prospect.risk_factors && prospect.risk_factors.length > 0 && (
                                                    <div>
                                                        <p className="text-amber-400 text-xs font-semibold mb-1">Risk Factors</p>
                                                        <ul className="space-y-1">
                                                            {prospect.risk_factors.map((risk, i) => (
                                                                <li key={i} className="text-slate-400 text-xs flex items-start gap-1">
                                                                    <span>⚠</span>
                                                                    <span>{risk}</span>
                                                                </li>
                                                            ))}
                                                        </ul>
                                                    </div>
                                                )}

                                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded p-3">
                                                    <p className="text-cyan-400 text-xs font-semibold mb-1">Scouting Notes</p>
                                                    <p className="text-slate-300 text-sm">{prospect.scouting_notes}</p>
                                                </div>

                                                <div className="flex items-center justify-between gap-2">
                                                    <Badge className={
                                                        prospect.recommendation?.toLowerCase().includes('sign') ? 'bg-emerald-500/20 text-emerald-400' :
                                                        prospect.recommendation?.toLowerCase().includes('monitor') ? 'bg-cyan-500/20 text-cyan-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {prospect.recommendation}
                                                    </Badge>
                                                    <div className="flex items-center gap-2">
                                                        {prospect.playerData && (
                                                            <p className="text-amber-400 font-semibold">
                                                                €{prospect.playerData.value || '?'}M
                                                            </p>
                                                        )}
                                                        <Button
                                                            size="sm"
                                                            onClick={() => {
                                                                const player = players.find(p => p.name === prospect.player_name);
                                                                if (player) {
                                                                    addToWatchlistMutation.mutate({
                                                                        player_name: player.name,
                                                                        player_id: player.id,
                                                                        position: player.position,
                                                                        age: player.age,
                                                                        current_club: player.current_club,
                                                                        market_value: player.market_value,
                                                                        reason: `Talent ID Match: ${prospect.match_score}% - ${prospect.hidden_gem_factor}`,
                                                                        watch_status: 'High Priority'
                                                                    });
                                                                }
                                                            }}
                                                            disabled={addToWatchlistMutation.isPending}
                                                            className="bg-purple-600 hover:bg-purple-700"
                                                        >
                                                            <Plus className="w-3 h-3 mr-1" />
                                                            Track
                                                        </Button>
                                                    </div>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </div>

                        <Button onClick={() => setMatches(null)} variant="outline" className="w-full">
                            New Talent Scan
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}