import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Users, Zap, CheckCircle, AlertTriangle, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TeamSynergyAnalysis({ players }) {
    const [synergy, setSynergy] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const analyzeSynergy = async () => {
        if (players.length < 2) {
            toast.error('Select at least 2 players to analyze synergy');
            return;
        }

        setAnalyzing(true);
        toast.loading('Analyzing team synergy...', { id: 'synergy' });

        try {
            const prompt = `You are an elite tactical analyst. Analyze how these ${players.length} players would work together in the same team:

PLAYER PROFILES:
${players.map((p, idx) => `
${idx + 1}. ${p.name}
   - Position: ${p.position}
   - Age: ${p.age}
   - Playing Style: ${JSON.stringify(p.playing_style)}
   - Tactical Roles: ${p.tactical_roles?.join(', ') || 'N/A'}
   - Archetype: ${p.fsai_archetype_primary || 'N/A'}
   - Physical Attributes: ${JSON.stringify(p.physical_attributes)}
   - Preferred Formations: ${p.preferred_formations?.join(', ') || 'N/A'}
`).join('\n')}

PROVIDE TEAM SYNERGY ANALYSIS:

1. **Overall Synergy Score** (0-100): How well would they work together?
2. **Complementary Strengths**: Which players' strengths complement each other?
3. **Overlapping Skills**: Areas where players have similar attributes
4. **Potential Chemistry Issues**: Conflicts, style clashes, or redundancies
5. **Recommended Formation**: Best tactical system to maximize their collective potential
6. **Tactical Balance Analysis**: 
   - Defensive solidity
   - Midfield control
   - Attacking threat
   - Transition speed
7. **Partnership Ratings**: Rate each player pairing (0-10)
8. **Team Building Recommendations**: Additional player profiles needed to complete the squad
9. **Playing Style Identity**: What type of football would this combination play?
10. **Rotation & Depth Analysis**: Can they provide tactical flexibility?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_synergy_score: { type: "number", minimum: 0, maximum: 100 },
                        synergy_grade: { type: "string" },
                        complementary_strengths: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    players: { type: "array", items: { type: "string" } },
                                    synergy_type: { type: "string" },
                                    explanation: { type: "string" }
                                }
                            }
                        },
                        overlapping_skills: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    skill: { type: "string" },
                                    players: { type: "array", items: { type: "string" } },
                                    impact: { type: "string" }
                                }
                            }
                        },
                        chemistry_issues: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    issue_type: { type: "string" },
                                    affected_players: { type: "array", items: { type: "string" } },
                                    severity: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        recommended_formation: {
                            type: "object",
                            properties: {
                                formation: { type: "string" },
                                reasoning: { type: "string" },
                                player_positions: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            player_name: { type: "string" },
                                            position_in_formation: { type: "string" }
                                        }
                                    }
                                }
                            }
                        },
                        tactical_balance: {
                            type: "object",
                            properties: {
                                defensive_solidity: { type: "number", minimum: 0, maximum: 10 },
                                midfield_control: { type: "number", minimum: 0, maximum: 10 },
                                attacking_threat: { type: "number", minimum: 0, maximum: 10 },
                                transition_speed: { type: "number", minimum: 0, maximum: 10 }
                            }
                        },
                        partnership_ratings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player1: { type: "string" },
                                    player2: { type: "string" },
                                    rating: { type: "number", minimum: 0, maximum: 10 },
                                    chemistry_type: { type: "string" }
                                }
                            }
                        },
                        team_building_needs: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    priority: { type: "string" },
                                    required_attributes: { type: "array", items: { type: "string" } },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        playing_style_identity: { type: "string" },
                        rotation_analysis: { type: "string" },
                        final_verdict: { type: "string" }
                    }
                }
            });

            setSynergy(response);
            toast.success('Synergy analysis complete!', { id: 'synergy' });
        } catch (error) {
            console.error('Synergy analysis failed:', error);
            toast.error('Failed to analyze synergy', { id: 'synergy' });
        } finally {
            setAnalyzing(false);
        }
    };

    const getSynergyColor = (score) => {
        if (score >= 80) return 'from-emerald-500 to-green-600';
        if (score >= 60) return 'from-cyan-500 to-blue-600';
        if (score >= 40) return 'from-amber-500 to-orange-600';
        return 'from-red-500 to-pink-600';
    };

    const getRatingColor = (rating) => {
        if (rating >= 8) return 'text-emerald-400';
        if (rating >= 6) return 'text-cyan-400';
        if (rating >= 4) return 'text-amber-400';
        return 'text-red-400';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-cyan-400" />
                    Team Synergy Analysis
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    AI-driven analysis of how these players would work together in a team
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {!synergy ? (
                    <div className="text-center py-12">
                        <Zap className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                        <h3 className="text-white text-xl font-semibold mb-2">Analyze Team Chemistry</h3>
                        <p className="text-slate-400 mb-6">
                            Get insights on complementary strengths, tactical balance, and partnership compatibility
                        </p>
                        <Button
                            onClick={analyzeSynergy}
                            disabled={analyzing || players.length < 2}
                            className="bg-gradient-to-r from-purple-500 to-cyan-600"
                        >
                            {analyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Analyze Team Synergy
                                </>
                            )}
                        </Button>
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Overall Synergy Score */}
                        <div className={`bg-gradient-to-r ${getSynergyColor(synergy.overall_synergy_score)} p-6 rounded-lg text-center`}>
                            <p className="text-white/80 text-sm mb-2">Overall Team Synergy</p>
                            <div className="text-6xl font-bold text-white mb-2">
                                {Math.round(synergy.overall_synergy_score)}
                            </div>
                            <Badge className="bg-white/20 text-white border-white/30">
                                Grade: {synergy.synergy_grade}
                            </Badge>
                        </div>

                        {/* Tactical Balance */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Tactical Balance</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 gap-4">
                                    {Object.entries(synergy.tactical_balance || {}).map(([key, value]) => (
                                        <div key={key}>
                                            <div className="flex justify-between text-sm mb-1">
                                                <span className="text-slate-400 capitalize">{key.replace(/_/g, ' ')}</span>
                                                <span className={`font-semibold ${getRatingColor(value)}`}>{value}/10</span>
                                            </div>
                                            <div className="w-full bg-slate-700 rounded-full h-2">
                                                <div
                                                    className={`h-2 rounded-full bg-gradient-to-r ${getSynergyColor(value * 10)}`}
                                                    style={{ width: `${value * 10}%` }}
                                                />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Recommended Formation */}
                        <Card className="bg-purple-500/10 border-purple-500/30">
                            <CardHeader>
                                <CardTitle className="text-purple-400">Recommended Formation</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-center mb-4">
                                    <div className="inline-block bg-purple-500/20 border border-purple-500/40 rounded-lg px-6 py-3">
                                        <p className="text-3xl font-bold text-purple-400">
                                            {synergy.recommended_formation?.formation}
                                        </p>
                                    </div>
                                </div>
                                <p className="text-slate-300 text-sm mb-4">{synergy.recommended_formation?.reasoning}</p>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                    {synergy.recommended_formation?.player_positions?.map((pos, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded p-2 text-center">
                                            <p className="text-white text-sm font-semibold">{pos.player_name}</p>
                                            <p className="text-purple-400 text-xs">{pos.position_in_formation}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Complementary Strengths */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                                    Complementary Strengths
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {synergy.complementary_strengths?.map((strength, idx) => (
                                        <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                            <Badge className="bg-emerald-500/20 text-emerald-400 mb-2">
                                                {strength.synergy_type}
                                            </Badge>
                                            <p className="text-white text-sm font-semibold mb-1">
                                                {strength.players.join(' + ')}
                                            </p>
                                            <p className="text-slate-300 text-sm">{strength.explanation}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Partnership Ratings */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white">Partnership Compatibility</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {synergy.partnership_ratings?.sort((a, b) => b.rating - a.rating).map((pair, idx) => (
                                        <div key={idx} className="flex items-center justify-between bg-slate-900/50 rounded p-3">
                                            <div className="flex-1">
                                                <p className="text-white text-sm">{pair.player1} ↔ {pair.player2}</p>
                                                <p className="text-slate-400 text-xs">{pair.chemistry_type}</p>
                                            </div>
                                            <div className={`text-2xl font-bold ${getRatingColor(pair.rating)}`}>
                                                {pair.rating}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Chemistry Issues */}
                        {synergy.chemistry_issues && synergy.chemistry_issues.length > 0 && (
                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardHeader>
                                    <CardTitle className="text-amber-400 flex items-center gap-2">
                                        <AlertTriangle className="w-5 h-5" />
                                        Potential Chemistry Issues
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {synergy.chemistry_issues.map((issue, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                <div className="flex items-start justify-between mb-2">
                                                    <h5 className="text-white font-semibold">{issue.issue_type}</h5>
                                                    <Badge className={
                                                        issue.severity === 'High' ? 'bg-red-500/20 text-red-400' :
                                                        issue.severity === 'Medium' ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {issue.severity}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm mb-2">
                                                    Affects: {issue.affected_players.join(', ')}
                                                </p>
                                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded p-2">
                                                    <p className="text-cyan-400 text-xs font-semibold mb-1">Mitigation:</p>
                                                    <p className="text-slate-300 text-xs">{issue.mitigation}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Team Building Needs */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white">Squad Building Recommendations</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {synergy.team_building_needs?.map((need, idx) => (
                                        <div key={idx} className="bg-slate-900/50 rounded-lg p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <h5 className="text-white font-semibold">{need.position}</h5>
                                                <Badge className={
                                                    need.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                    need.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-cyan-500/20 text-cyan-400'
                                                }>
                                                    {need.priority} Priority
                                                </Badge>
                                            </div>
                                            <p className="text-slate-300 text-sm mb-2">{need.reasoning}</p>
                                            <div className="flex flex-wrap gap-1">
                                                {need.required_attributes?.map((attr, i) => (
                                                    <Badge key={i} className="bg-purple-500/20 text-purple-400 text-xs">
                                                        {attr}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Playing Style & Final Verdict */}
                        <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-cyan-400">Team Identity & Final Verdict</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Playing Style:</p>
                                    <p className="text-white">{synergy.playing_style_identity}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Final Assessment:</p>
                                    <p className="text-slate-300 leading-relaxed">{synergy.final_verdict}</p>
                                </div>
                            </CardContent>
                        </Card>

                        <Button onClick={() => setSynergy(null)} variant="outline" className="w-full">
                            Run New Analysis
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}