import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, FileText, Calendar, TrendingDown, AlertTriangle, CheckCircle2, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ContractAnalyser() {
    const [analysis, setAnalysis] = useState(null);
    const [analysing, setAnalysing] = useState(false);

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players-contracts'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    // Filter players with contract data
    const playersWithContracts = players.filter(p => p.contract_expiry);

    // Categorise by urgency
    const getExpiryUrgency = (expiryDate) => {
        const months = Math.floor((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24 * 30));
        if (months <= 6) return 'critical';
        if (months <= 12) return 'high';
        if (months <= 24) return 'medium';
        return 'low';
    };

    const criticalContracts = playersWithContracts.filter(p => getExpiryUrgency(p.contract_expiry) === 'critical');
    const highPriorityContracts = playersWithContracts.filter(p => getExpiryUrgency(p.contract_expiry) === 'high');

    const analyseContracts = async () => {
        setAnalysing(true);
        toast.loading('AI analysing contract portfolio...', { id: 'contract-analysis' });

        try {
            const contractData = playersWithContracts.slice(0, 50).map(p => ({
                name: p.name,
                age: p.age,
                position: p.position,
                market_value: p.market_value,
                contract_expiry: p.contract_expiry,
                months_remaining: Math.floor((new Date(p.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30)),
                transfer_status: p.transfer_status,
                fsai_score: p.fsai_proprietary_score,
                investment_grade: p.fsai_investment_grade
            }));

            const prompt = `You are an elite football contract strategist. Analyse this club's contract portfolio and provide strategic recommendations:

CONTRACT PORTFOLIO DATA:
${contractData.map(p => `
- ${p.name} (${p.position}, ${p.age}y)
  Market Value: €${p.market_value}M
  Contract Expires: ${p.contract_expiry}
  Months Remaining: ${p.months_remaining}
  FS-AI Score: ${p.fsai_score || 'N/A'}
  Grade: ${p.investment_grade || 'N/A'}
`).join('\n')}

SUMMARY STATS:
- Total Contracts: ${playersWithContracts.length}
- Critical (≤6 months): ${criticalContracts.length}
- High Priority (≤12 months): ${highPriorityContracts.length}

Provide comprehensive contract strategy analysis:

1. **Portfolio Health Assessment**: Overall contract management rating
2. **Critical Priority Actions**: Players requiring immediate attention
3. **Renewal Recommendations**: Who to renew, terms, and timing
4. **Negotiation Strategies**: Tactics for each contract situation
5. **Financial Impact Analysis**: Budget implications of recommendations
6. **Risk Assessment**: Players at risk of leaving on free transfer
7. **Opportunity Analysis**: Strategic contract situations to exploit
8. **Timeline Recommendations**: Month-by-month action plan`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        portfolio_health: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                summary: { type: "string" },
                                key_concerns: { type: "array", items: { type: "string" } }
                            }
                        },
                        critical_actions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    urgency: { type: "string" },
                                    action_required: { type: "string" },
                                    deadline: { type: "string" },
                                    risk_level: { type: "string" }
                                }
                            }
                        },
                        renewal_recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    recommendation: { type: "string" },
                                    proposed_length_years: { type: "number" },
                                    salary_guidance: { type: "string" },
                                    negotiation_timing: { type: "string" },
                                    priority_level: { type: "string" },
                                    rationale: { type: "string" }
                                }
                            }
                        },
                        negotiation_strategies: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    strategy: { type: "string" },
                                    tactics: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        financial_impact: {
                            type: "object",
                            properties: {
                                estimated_renewal_cost_total: { type: "string" },
                                potential_loss_if_no_action: { type: "string" },
                                recommended_budget_allocation: { type: "string" }
                            }
                        },
                        risk_assessment: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    risk_type: { type: "string" },
                                    probability: { type: "string" },
                                    impact: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        opportunities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    opportunity_type: { type: "string" },
                                    description: { type: "string" },
                                    potential_benefit: { type: "string" }
                                }
                            }
                        },
                        action_timeline: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    month: { type: "string" },
                                    actions: { type: "array", items: { type: "string" } }
                                }
                            }
                        }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Contract analysis complete!', { id: 'contract-analysis' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyse contracts', { id: 'contract-analysis' });
        } finally {
            setAnalysing(false);
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Contract Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Total Contracts</p>
                                <p className="text-3xl font-bold text-white">{playersWithContracts.length}</p>
                            </div>
                            <FileText className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-red-500/10 to-red-600/10 border-red-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Critical (≤6mo)</p>
                                <p className="text-3xl font-bold text-red-400">{criticalContracts.length}</p>
                            </div>
                            <AlertTriangle className="w-8 h-8 text-red-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">High Priority (≤12mo)</p>
                                <p className="text-3xl font-bold text-amber-400">{highPriorityContracts.length}</p>
                            </div>
                            <Calendar className="w-8 h-8 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Analysis Status</p>
                                <p className="text-lg font-bold text-emerald-400">
                                    {analysis ? 'Complete' : 'Pending'}
                                </p>
                            </div>
                            <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Generate Analysis Button */}
            {!analysis && (
                <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                    <CardContent className="py-12 text-center">
                        <Target className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                        <h3 className="text-white text-xl font-semibold mb-2">AI Contract Strategy Engine</h3>
                        <p className="text-slate-400 mb-6 max-w-2xl mx-auto">
                            Generate comprehensive contract analysis with renewal recommendations, negotiation strategies, and financial impact projections
                        </p>
                        <Button
                            onClick={analyseContracts}
                            disabled={analysing || playersWithContracts.length === 0}
                            className="bg-gradient-to-r from-purple-500 to-cyan-600"
                            size="lg"
                        >
                            {analysing ? (
                                <>
                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                    Analysing Portfolio...
                                </>
                            ) : (
                                <>
                                    <Target className="w-5 h-5 mr-2" />
                                    Generate Contract Analysis
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>
            )}

            {/* Analysis Results */}
            {analysis && (
                <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="critical">Critical Actions</TabsTrigger>
                        <TabsTrigger value="renewals">Renewals</TabsTrigger>
                        <TabsTrigger value="strategy">Strategy</TabsTrigger>
                        <TabsTrigger value="timeline">Timeline</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="mt-6 space-y-6">
                        {/* Portfolio Health */}
                        <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400">Portfolio Health Assessment</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex items-center justify-between mb-4">
                                    <p className="text-slate-300">Overall Rating</p>
                                    <div className="text-5xl font-bold text-emerald-400">
                                        {analysis.portfolio_health?.rating}/10
                                    </div>
                                </div>
                                <p className="text-slate-300 mb-4">{analysis.portfolio_health?.summary}</p>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h5 className="text-white font-semibold mb-2">Key Concerns</h5>
                                    <div className="space-y-2">
                                        {analysis.portfolio_health?.key_concerns?.map((concern, idx) => (
                                            <div key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                                                {concern}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Financial Impact */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Financial Impact Analysis</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-3 gap-4">
                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Renewal Cost</p>
                                        <p className="text-white text-xl font-bold">
                                            {analysis.financial_impact?.estimated_renewal_cost_total}
                                        </p>
                                    </div>
                                    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Potential Loss</p>
                                        <p className="text-white text-xl font-bold">
                                            {analysis.financial_impact?.potential_loss_if_no_action}
                                        </p>
                                    </div>
                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Budget Allocation</p>
                                        <p className="text-white text-xl font-bold">
                                            {analysis.financial_impact?.recommended_budget_allocation}
                                        </p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="critical" className="mt-6">
                        <Card className="bg-red-500/10 border-red-500/30">
                            <CardHeader>
                                <CardTitle className="text-red-400">Critical Priority Actions</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.critical_actions?.map((action, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="bg-slate-800/50 rounded-lg p-4"
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <h5 className="text-white font-semibold">{action.player_name}</h5>
                                                <div className="flex gap-2">
                                                    <Badge className={
                                                        action.risk_level === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                        action.risk_level === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {action.risk_level}
                                                    </Badge>
                                                    <Badge className="bg-purple-500/20 text-purple-400">
                                                        {action.urgency}
                                                    </Badge>
                                                </div>
                                            </div>
                                            <p className="text-slate-300 text-sm mb-2">{action.action_required}</p>
                                            <div className="flex items-center gap-2 text-xs">
                                                <Calendar className="w-3 h-3 text-amber-400" />
                                                <span className="text-amber-400">Deadline: {action.deadline}</span>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="renewals" className="mt-6">
                        <div className="space-y-4">
                            {analysis.renewal_recommendations?.map((renewal, idx) => (
                                <Card key={idx} className="bg-slate-900/50 border-slate-800">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-3">
                                            <div>
                                                <h4 className="text-white font-semibold text-lg mb-1">{renewal.player_name}</h4>
                                                <Badge className={
                                                    renewal.priority_level === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                    renewal.priority_level === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-emerald-500/20 text-emerald-400'
                                                }>
                                                    {renewal.priority_level} Priority
                                                </Badge>
                                            </div>
                                            <Badge className={
                                                renewal.recommendation?.toLowerCase().includes('renew') ? 'bg-emerald-500/20 text-emerald-400' :
                                                renewal.recommendation?.toLowerCase().includes('consider') ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-red-500/20 text-red-400'
                                            }>
                                                {renewal.recommendation}
                                            </Badge>
                                        </div>

                                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                                            <div className="bg-slate-800/50 rounded p-3">
                                                <p className="text-slate-400 text-xs mb-1">Proposed Length</p>
                                                <p className="text-white font-semibold">{renewal.proposed_length_years} years</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded p-3">
                                                <p className="text-slate-400 text-xs mb-1">Salary Guidance</p>
                                                <p className="text-white font-semibold">{renewal.salary_guidance}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded p-3">
                                                <p className="text-slate-400 text-xs mb-1">Timing</p>
                                                <p className="text-white font-semibold">{renewal.negotiation_timing}</p>
                                            </div>
                                        </div>

                                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
                                            <p className="text-cyan-400 font-semibold text-sm mb-1">Rationale</p>
                                            <p className="text-slate-300 text-sm">{renewal.rationale}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="strategy" className="mt-6 space-y-6">
                        {/* Negotiation Strategies */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Negotiation Strategies</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analysis.negotiation_strategies?.map((strategy, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <h5 className="text-white font-semibold mb-2">{strategy.scenario}</h5>
                                            <p className="text-slate-300 text-sm mb-3">{strategy.strategy}</p>
                                            <div className="space-y-1">
                                                <p className="text-cyan-400 text-xs font-semibold mb-1">Tactics:</p>
                                                {strategy.tactics?.map((tactic, tidx) => (
                                                    <div key={tidx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                        <span className="text-emerald-400">•</span>
                                                        {tactic}
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Risk Assessment */}
                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400">Risk Assessment</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.risk_assessment?.map((risk, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <h5 className="text-white font-semibold">{risk.player_name}</h5>
                                                <Badge className="bg-red-500/20 text-red-400">{risk.risk_type}</Badge>
                                            </div>
                                            <div className="grid grid-cols-2 gap-3 mb-2 text-sm">
                                                <div>
                                                    <span className="text-slate-400">Probability: </span>
                                                    <span className="text-white">{risk.probability}</span>
                                                </div>
                                                <div>
                                                    <span className="text-slate-400">Impact: </span>
                                                    <span className="text-white">{risk.impact}</span>
                                                </div>
                                            </div>
                                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded p-2">
                                                <p className="text-emerald-400 text-xs font-semibold mb-1">Mitigation:</p>
                                                <p className="text-slate-300 text-sm">{risk.mitigation}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Opportunities */}
                        <Card className="bg-purple-500/10 border-purple-500/30">
                            <CardHeader>
                                <CardTitle className="text-purple-400">Strategic Opportunities</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.opportunities?.map((opp, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <Badge className="bg-purple-500/20 text-purple-400 mb-2">{opp.opportunity_type}</Badge>
                                            <p className="text-slate-300 text-sm mb-2">{opp.description}</p>
                                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded p-2">
                                                <p className="text-emerald-400 text-xs">
                                                    <strong>Benefit:</strong> {opp.potential_benefit}
                                                </p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="timeline" className="mt-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">12-Month Action Timeline</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analysis.action_timeline?.map((month, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: idx * 0.05 }}
                                            className="bg-slate-800/50 rounded-lg p-4"
                                        >
                                            <div className="flex items-center gap-2 mb-3">
                                                <Calendar className="w-5 h-5 text-cyan-400" />
                                                <h5 className="text-white font-semibold">{month.month}</h5>
                                            </div>
                                            <div className="space-y-2">
                                                {month.actions?.map((action, aidx) => (
                                                    <div key={aidx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                                                        {action}
                                                    </div>
                                                ))}
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            )}

            {analysis && (
                <Button onClick={() => setAnalysis(null)} variant="outline" className="w-full">
                    Generate New Analysis
                </Button>
            )}
        </div>
    );
}