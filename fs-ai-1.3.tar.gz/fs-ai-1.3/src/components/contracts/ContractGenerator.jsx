import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { FileText, Sparkles } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ContractGenerator({ templates, preselectedTemplate, onComplete }) {
    const [selectedTemplate, setSelectedTemplate] = useState(preselectedTemplate || null);
    const [formData, setFormData] = useState({});
    const [contractTitle, setContractTitle] = useState('');
    const [generatedContent, setGeneratedContent] = useState('');

    const queryClient = useQueryClient();

    useEffect(() => {
        if (preselectedTemplate) {
            setSelectedTemplate(preselectedTemplate);
        }
    }, [preselectedTemplate]);

    const createContractMutation = useMutation({
        mutationFn: (data) => base44.entities.Contract.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contracts'] });
            toast.success('Contract created');
            onComplete();
        }
    });

    const handleTemplateChange = (templateId) => {
        const template = templates.find(t => t.id === templateId);
        setSelectedTemplate(template);
        setFormData({});
        setGeneratedContent('');
        setContractTitle('');
    };

    const handleGenerate = () => {
        if (!selectedTemplate || !contractTitle) {
            toast.error('Please select a template and enter a title');
            return;
        }

        // Replace placeholders with form data
        let content = selectedTemplate.content;
        
        // Replace variables
        Object.keys(formData).forEach(key => {
            const regex = new RegExp(`{{${key}}}`, 'g');
            content = content.replace(regex, formData[key] || `[${key}]`);
        });

        // Replace date placeholders
        const today = new Date().toLocaleDateString();
        content = content.replace(/{{current_date}}/g, today);

        setGeneratedContent(content);
    };

    const handleSave = () => {
        if (!generatedContent || !contractTitle) {
            toast.error('Please generate the contract first');
            return;
        }

        createContractMutation.mutate({
            title: contractTitle,
            template_name: selectedTemplate.name,
            category: selectedTemplate.category,
            content: generatedContent,
            client_data: formData,
            status: 'Draft'
        });
    };

    return (
        <div className="space-y-6">
            {!generatedContent ? (
                <>
                    <div>
                        <Label className="text-slate-400">Select Template *</Label>
                        <Select 
                            value={selectedTemplate?.id} 
                            onValueChange={handleTemplateChange}
                        >
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                <SelectValue placeholder="Choose a template..." />
                            </SelectTrigger>
                            <SelectContent>
                                {templates.filter(t => t.active).map(template => (
                                    <SelectItem key={template.id} value={template.id}>
                                        {template.name} ({template.category})
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {selectedTemplate && (
                        <>
                            <div>
                                <Label className="text-slate-400">Contract Title *</Label>
                                <Input
                                    value={contractTitle}
                                    onChange={(e) => setContractTitle(e.target.value)}
                                    placeholder="e.g., Transfer Agreement - John Doe"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>

                            {selectedTemplate.variables && selectedTemplate.variables.length > 0 && (
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardHeader>
                                        <CardTitle className="text-white text-lg">Fill Template Data</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        {selectedTemplate.variables.map((variable, idx) => (
                                            <div key={idx}>
                                                <Label className="text-slate-400">
                                                    {variable.label}
                                                    {variable.required && <span className="text-red-400"> *</span>}
                                                </Label>
                                                {variable.type === 'text' || !variable.type ? (
                                                    <Input
                                                        value={formData[variable.key] || ''}
                                                        onChange={(e) => setFormData({
                                                            ...formData,
                                                            [variable.key]: e.target.value
                                                        })}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        required={variable.required}
                                                    />
                                                ) : variable.type === 'number' || variable.type === 'currency' ? (
                                                    <Input
                                                        type="number"
                                                        value={formData[variable.key] || ''}
                                                        onChange={(e) => setFormData({
                                                            ...formData,
                                                            [variable.key]: e.target.value
                                                        })}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        required={variable.required}
                                                    />
                                                ) : variable.type === 'date' ? (
                                                    <Input
                                                        type="date"
                                                        value={formData[variable.key] || ''}
                                                        onChange={(e) => setFormData({
                                                            ...formData,
                                                            [variable.key]: e.target.value
                                                        })}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        required={variable.required}
                                                    />
                                                ) : null}
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            )}

                            <Button
                                onClick={handleGenerate}
                                className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
                            >
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate Contract
                            </Button>
                        </>
                    )}
                </>
            ) : (
                <>
                    <Card className="bg-slate-950 border-slate-800">
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle className="text-white">Generated Contract</CardTitle>
                                <Button
                                    onClick={() => setGeneratedContent('')}
                                    variant="outline"
                                    size="sm"
                                    className="border-slate-700 text-slate-400"
                                >
                                    Edit Data
                                </Button>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <Textarea
                                value={generatedContent}
                                onChange={(e) => setGeneratedContent(e.target.value)}
                                className="bg-slate-900 border-slate-700 text-white min-h-[400px] font-mono text-sm"
                            />
                        </CardContent>
                    </Card>

                    <div className="flex gap-3">
                        <Button
                            onClick={handleSave}
                            disabled={createContractMutation.isPending}
                            className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500"
                        >
                            <FileText className="w-4 h-4 mr-2" />
                            Save Contract
                        </Button>
                        <Button
                            onClick={onComplete}
                            variant="outline"
                            className="border-slate-700 text-slate-400"
                        >
                            Cancel
                        </Button>
                    </div>
                </>
            )}
        </div>
    );
}