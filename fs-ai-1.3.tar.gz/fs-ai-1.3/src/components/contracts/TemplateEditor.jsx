import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, X } from 'lucide-react';
import toast from 'react-hot-toast';

export default function TemplateEditor({ template, onComplete }) {
    const [formData, setFormData] = useState(template || {
        name: '',
        category: 'Other',
        content: '',
        variables: [],
        active: true
    });

    const [newVariable, setNewVariable] = useState({
        key: '',
        label: '',
        type: 'text',
        required: false
    });

    const queryClient = useQueryClient();

    const saveMutation = useMutation({
        mutationFn: (data) => {
            if (template) {
                return base44.entities.ContractTemplate.update(template.id, data);
            } else {
                return base44.entities.ContractTemplate.create(data);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contract-templates'] });
            toast.success(template ? 'Template updated' : 'Template created');
            onComplete();
        }
    });

    const addVariable = () => {
        if (!newVariable.key || !newVariable.label) {
            toast.error('Variable key and label are required');
            return;
        }

        setFormData({
            ...formData,
            variables: [...(formData.variables || []), { ...newVariable }]
        });

        setNewVariable({
            key: '',
            label: '',
            type: 'text',
            required: false
        });
    };

    const removeVariable = (index) => {
        setFormData({
            ...formData,
            variables: formData.variables.filter((_, idx) => idx !== index)
        });
    };

    const insertPlaceholder = (key) => {
        const placeholder = `{{${key}}}`;
        const textarea = document.getElementById('template-content');
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = formData.content;
        const newText = text.substring(0, start) + placeholder + text.substring(end);
        
        setFormData({ ...formData, content: newText });
        
        setTimeout(() => {
            textarea.focus();
            textarea.setSelectionRange(start + placeholder.length, start + placeholder.length);
        }, 0);
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-slate-400">Template Name *</Label>
                    <Input
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g., Standard Player Transfer Agreement"
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                    />
                </div>
                <div>
                    <Label className="text-slate-400">Category *</Label>
                    <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Player Transfer">Player Transfer</SelectItem>
                            <SelectItem value="Scouting Agreement">Scouting Agreement</SelectItem>
                            <SelectItem value="Agency Contract">Agency Contract</SelectItem>
                            <SelectItem value="Loan Agreement">Loan Agreement</SelectItem>
                            <SelectItem value="NDA">NDA</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <div className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                <Label className="text-white">Active Template</Label>
                <Switch
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                    <CardTitle className="text-white text-lg">Template Variables</CardTitle>
                    <p className="text-slate-400 text-sm">Define placeholders like {'{{player_name}}'}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                    {formData.variables && formData.variables.length > 0 && (
                        <div className="space-y-2">
                            {formData.variables.map((variable, idx) => (
                                <div key={idx} className="flex items-center gap-2 bg-slate-900 p-3 rounded-lg">
                                    <Badge 
                                        onClick={() => insertPlaceholder(variable.key)}
                                        className="cursor-pointer bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
                                    >
                                        {'{{'}{variable.key}{'}}'}
                                    </Badge>
                                    <span className="text-slate-300 flex-1">{variable.label}</span>
                                    <Badge className="bg-slate-700 text-slate-400">{variable.type}</Badge>
                                    {variable.required && <Badge className="bg-red-500/20 text-red-400">Required</Badge>}
                                    <Button
                                        onClick={() => removeVariable(idx)}
                                        size="sm"
                                        variant="ghost"
                                        className="text-red-400"
                                    >
                                        <X className="w-3 h-3" />
                                    </Button>
                                </div>
                            ))}
                        </div>
                    )}

                    <div className="grid grid-cols-4 gap-2">
                        <Input
                            placeholder="Key (e.g., player_name)"
                            value={newVariable.key}
                            onChange={(e) => setNewVariable({ ...newVariable, key: e.target.value.replace(/\s/g, '_') })}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Input
                            placeholder="Label (e.g., Player Name)"
                            value={newVariable.label}
                            onChange={(e) => setNewVariable({ ...newVariable, label: e.target.value })}
                            className="bg-slate-900 border-slate-700 text-white"
                        />
                        <Select value={newVariable.type} onValueChange={(v) => setNewVariable({ ...newVariable, type: v })}>
                            <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="text">Text</SelectItem>
                                <SelectItem value="number">Number</SelectItem>
                                <SelectItem value="date">Date</SelectItem>
                                <SelectItem value="currency">Currency</SelectItem>
                            </SelectContent>
                        </Select>
                        <Button onClick={addVariable} size="sm" className="bg-indigo-500/20 text-indigo-400">
                            <Plus className="w-4 h-4 mr-1" />
                            Add
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <div>
                <Label className="text-slate-400">Template Content *</Label>
                <p className="text-xs text-slate-500 mb-2">Use {'{{variable_key}}'} for placeholders. {'{{current_date}}'} is auto-filled.</p>
                <Textarea
                    id="template-content"
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="Enter your contract template here..."
                    className="bg-slate-900 border-slate-700 text-white min-h-[300px] font-mono text-sm"
                />
            </div>

            <div className="flex gap-3">
                <Button
                    onClick={() => saveMutation.mutate(formData)}
                    disabled={!formData.name || !formData.content || saveMutation.isPending}
                    className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
                >
                    {template ? 'Update' : 'Create'} Template
                </Button>
                <Button onClick={onComplete} variant="outline" className="border-slate-700 text-slate-400">
                    Cancel
                </Button>
            </div>
        </div>
    );
}