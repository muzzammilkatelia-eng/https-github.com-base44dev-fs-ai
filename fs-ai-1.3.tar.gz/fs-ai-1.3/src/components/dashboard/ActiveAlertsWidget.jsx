import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ActiveAlertsWidget({ alerts = [] }) {
    const typeColors = {
        player_performance: 'bg-emerald-500/20 text-emerald-400',
        transfer_news: 'bg-blue-500/20 text-blue-400',
        injury_update: 'bg-red-500/20 text-red-400',
        market_value: 'bg-amber-500/20 text-amber-400',
        contract_expiry: 'bg-purple-500/20 text-purple-400',
        team_news: 'bg-cyan-500/20 text-cyan-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Bell className="w-5 h-5 text-amber-400" />
                    Active Alerts
                    <Badge className="ml-auto bg-amber-500/20 text-amber-400">
                        {alerts.filter(a => a.enabled).length}
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent>
                {alerts.length === 0 ? (
                    <p className="text-slate-400 text-sm">No active alerts</p>
                ) : (
                    <div className="space-y-2">
                        {alerts.slice(0, 5).map((alert, idx) => (
                            <motion.div
                                key={alert.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="p-3 rounded-lg bg-slate-800/50 border border-slate-700"
                            >
                                <div className="flex items-start justify-between mb-1">
                                    <span className="text-white font-medium text-sm">{alert.alert_name}</span>
                                    <Badge className={typeColors[alert.alert_type]}>
                                        {alert.alert_type.replace('_', ' ')}
                                    </Badge>
                                </div>
                                {alert.trigger_count > 0 && (
                                    <div className="flex items-center gap-1 text-slate-400 text-xs">
                                        <TrendingUp className="w-3 h-3" />
                                        Triggered {alert.trigger_count} times
                                    </div>
                                )}
                            </motion.div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}