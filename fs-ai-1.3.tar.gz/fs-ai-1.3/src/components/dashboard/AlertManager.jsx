import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, Plus, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function AlertManager({ open, onClose }) {
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({
        alert_name: '',
        alert_type: 'player_performance',
        criteria: {},
        frequency: 'daily'
    });

    const queryClient = useQueryClient();

    const { data: alerts = [] } = useQuery({
        queryKey: ['user-alerts'],
        queryFn: async () => {
            const user = await base44.auth.me();
            return base44.entities.UserAlert.filter({ user_email: user.email });
        }
    });

    const createMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me();
            return base44.entities.UserAlert.create({
                ...data,
                user_email: user.email
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-alerts'] });
            toast.success('Alert created');
            setShowForm(false);
            setFormData({
                alert_name: '',
                alert_type: 'player_performance',
                criteria: {},
                frequency: 'daily'
            });
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.UserAlert.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-alerts'] });
            toast.success('Alert deleted');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        createMutation.mutate(formData);
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Bell className="w-5 h-5 text-amber-400" />
                        Alert Manager
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                    <Button
                        onClick={() => setShowForm(!showForm)}
                        className="w-full bg-gradient-to-r from-amber-500 to-orange-600"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        Create New Alert
                    </Button>

                    {showForm && (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardContent className="pt-6">
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <Label>Alert Name</Label>
                                        <Input
                                            value={formData.alert_name}
                                            onChange={(e) => setFormData({ ...formData, alert_name: e.target.value })}
                                            placeholder="e.g., Mbappe Performance Tracker"
                                            className="bg-slate-900 border-slate-700"
                                            required
                                        />
                                    </div>

                                    <div>
                                        <Label>Alert Type</Label>
                                        <Select
                                            value={formData.alert_type}
                                            onValueChange={(v) => setFormData({ ...formData, alert_type: v })}
                                        >
                                            <SelectTrigger className="bg-slate-900 border-slate-700">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="player_performance">Player Performance</SelectItem>
                                                <SelectItem value="transfer_news">Transfer News</SelectItem>
                                                <SelectItem value="injury_update">Injury Update</SelectItem>
                                                <SelectItem value="market_value">Market Value Change</SelectItem>
                                                <SelectItem value="contract_expiry">Contract Expiry</SelectItem>
                                                <SelectItem value="team_news">Team News</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <Label>Player Name (Optional)</Label>
                                            <Input
                                                value={formData.criteria.player_name || ''}
                                                onChange={(e) => setFormData({
                                                    ...formData,
                                                    criteria: { ...formData.criteria, player_name: e.target.value }
                                                })}
                                                placeholder="Specific player"
                                                className="bg-slate-900 border-slate-700"
                                            />
                                        </div>
                                        <div>
                                            <Label>Position (Optional)</Label>
                                            <Input
                                                value={formData.criteria.position || ''}
                                                onChange={(e) => setFormData({
                                                    ...formData,
                                                    criteria: { ...formData.criteria, position: e.target.value }
                                                })}
                                                placeholder="e.g., Striker"
                                                className="bg-slate-900 border-slate-700"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <Label>Frequency</Label>
                                        <Select
                                            value={formData.frequency}
                                            onValueChange={(v) => setFormData({ ...formData, frequency: v })}
                                        >
                                            <SelectTrigger className="bg-slate-900 border-slate-700">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="instant">Instant</SelectItem>
                                                <SelectItem value="daily">Daily</SelectItem>
                                                <SelectItem value="weekly">Weekly</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <Button type="submit" className="w-full" disabled={createMutation.isPending}>
                                        Create Alert
                                    </Button>
                                </form>
                            </CardContent>
                        </Card>
                    )}

                    <div className="space-y-3">
                        {alerts.map((alert, idx) => (
                            <motion.div
                                key={alert.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-4">
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1">
                                                <h4 className="text-white font-semibold mb-1">{alert.alert_name}</h4>
                                                <div className="flex items-center gap-2 flex-wrap mb-2">
                                                    <Badge className="bg-cyan-500/20 text-cyan-400">
                                                        {alert.alert_type.replace('_', ' ')}
                                                    </Badge>
                                                    <Badge variant="outline">{alert.frequency}</Badge>
                                                    {alert.trigger_count > 0 && (
                                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                                            {alert.trigger_count} triggers
                                                        </Badge>
                                                    )}
                                                </div>
                                                {alert.criteria?.player_name && (
                                                    <p className="text-slate-400 text-sm">
                                                        Player: {alert.criteria.player_name}
                                                    </p>
                                                )}
                                            </div>
                                            <Button
                                                size="icon"
                                                variant="ghost"
                                                onClick={() => deleteMutation.mutate(alert.id)}
                                                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}

                        {alerts.length === 0 && !showForm && (
                            <p className="text-slate-400 text-center py-8">No alerts configured yet</p>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}