import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Settings, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';

const widgetOptions = [
    { id: 'recent_searches', name: 'Recent Searches', description: 'Your latest player searches' },
    { id: 'active_alerts', name: 'Active Alerts', description: 'Custom alerts and notifications' },
    { id: 'prediction_accuracy', name: 'Prediction Accuracy', description: 'AI prediction performance' },
    { id: 'saved_players', name: 'Saved Players', description: 'Your saved player profiles' },
    { id: 'scout_activity', name: 'Scout Activity', description: 'Recent scouting activities' },
    { id: 'market_trends', name: 'Market Trends', description: 'Transfer market insights' }
];

export default function DashboardCustomizer({ config, open, onClose }) {
    const [widgets, setWidgets] = useState(config?.widgets || []);
    const queryClient = useQueryClient();

    const updateMutation = useMutation({
        mutationFn: async (newWidgets) => {
            const user = await base44.auth.me();
            const existingConfigs = await base44.entities.UserDashboardConfig.filter({ user_email: user.email });
            
            if (existingConfigs.length > 0) {
                return base44.entities.UserDashboardConfig.update(existingConfigs[0].id, {
                    widgets: newWidgets
                });
            } else {
                return base44.entities.UserDashboardConfig.create({
                    user_email: user.email,
                    widgets: newWidgets
                });
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['dashboard-config'] });
            toast.success('Dashboard updated');
            onClose();
        }
    });

    const toggleWidget = (widgetType) => {
        const updated = widgets.map(w =>
            w.type === widgetType ? { ...w, enabled: !w.enabled } : w
        );
        
        const exists = widgets.find(w => w.type === widgetType);
        if (!exists) {
            updated.push({
                id: Date.now().toString(),
                type: widgetType,
                enabled: true,
                position: widgets.length,
                size: 'medium'
            });
        }
        
        setWidgets(updated);
    };

    const handleSave = () => {
        updateMutation.mutate(widgets);
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Settings className="w-5 h-5 text-cyan-400" />
                        Customize Dashboard
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                        <Sparkles className="w-5 h-5 text-cyan-400" />
                        <p className="text-sm text-slate-300">
                            Toggle widgets to personalize your dashboard view
                        </p>
                    </div>

                    <div className="space-y-3">
                        {widgetOptions.map((option) => {
                            const widget = widgets.find(w => w.type === option.id);
                            const enabled = widget?.enabled || false;

                            return (
                                <Card key={option.id} className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <Label className="text-white font-medium">{option.name}</Label>
                                                <p className="text-slate-400 text-sm">{option.description}</p>
                                            </div>
                                            <Switch
                                                checked={enabled}
                                                onCheckedChange={() => toggleWidget(option.id)}
                                            />
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>

                    <div className="flex gap-3 pt-4">
                        <Button onClick={onClose} variant="outline" className="flex-1">
                            Cancel
                        </Button>
                        <Button
                            onClick={handleSave}
                            disabled={updateMutation.isPending}
                            className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            Save Changes
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}