import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RecentSearchesWidget({ searches = [] }) {
    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Search className="w-5 h-5 text-cyan-400" />
                    Recent Searches
                </CardTitle>
            </CardHeader>
            <CardContent>
                {searches.length === 0 ? (
                    <p className="text-slate-400 text-sm">No recent searches</p>
                ) : (
                    <div className="space-y-2">
                        {searches.slice(0, 5).map((search, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer"
                            >
                                <span className="text-white text-sm">{search.query}</span>
                                <div className="flex items-center gap-1 text-slate-500 text-xs">
                                    <Clock className="w-3 h-3" />
                                    {new Date(search.timestamp).toLocaleDateString()}
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}