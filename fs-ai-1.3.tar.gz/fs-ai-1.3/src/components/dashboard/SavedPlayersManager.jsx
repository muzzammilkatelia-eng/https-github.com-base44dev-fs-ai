import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Folder, Plus, Trash2, Edit } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function SavedPlayersManager({ open, onClose }) {
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [formData, setFormData] = useState({
        player_name: '',
        folder: 'Default',
        tags: [],
        notes: '',
        rating: 3,
        priority: 'Medium',
        status: 'Watching'
    });
    const [tagInput, setTagInput] = useState('');

    const queryClient = useQueryClient();

    const { data: savedPlayers = [] } = useQuery({
        queryKey: ['saved-players'],
        queryFn: async () => {
            const user = await base44.auth.me();
            return base44.entities.SavedPlayer.filter({ user_email: user.email });
        }
    });

    const createMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me();
            if (editingId) {
                return base44.entities.SavedPlayer.update(editingId, data);
            }
            return base44.entities.SavedPlayer.create({
                ...data,
                user_email: user.email
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['saved-players'] });
            toast.success(editingId ? 'Player updated' : 'Player saved');
            resetForm();
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.SavedPlayer.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['saved-players'] });
            toast.success('Player removed');
        }
    });

    const resetForm = () => {
        setShowForm(false);
        setEditingId(null);
        setFormData({
            player_name: '',
            folder: 'Default',
            tags: [],
            notes: '',
            rating: 3,
            priority: 'Medium',
            status: 'Watching'
        });
    };

    const handleEdit = (player) => {
        setFormData({
            player_name: player.player_name,
            folder: player.folder || 'Default',
            tags: player.tags || [],
            notes: player.notes || '',
            rating: player.rating || 3,
            priority: player.priority,
            status: player.status
        });
        setEditingId(player.id);
        setShowForm(true);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        createMutation.mutate(formData);
    };

    const addTag = () => {
        if (tagInput && !formData.tags.includes(tagInput)) {
            setFormData({ ...formData, tags: [...formData.tags, tagInput] });
            setTagInput('');
        }
    };

    const removeTag = (tag) => {
        setFormData({ ...formData, tags: formData.tags.filter(t => t !== tag) });
    };

    const folders = [...new Set(savedPlayers.map(p => p.folder))];

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-amber-400" />
                        Saved Players Manager
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                    <Button
                        onClick={() => setShowForm(!showForm)}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        {editingId ? 'Cancel Edit' : 'Add Player'}
                    </Button>

                    {showForm && (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardContent className="pt-6">
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <Label>Player Name *</Label>
                                        <Input
                                            value={formData.player_name}
                                            onChange={(e) => setFormData({ ...formData, player_name: e.target.value })}
                                            placeholder="Enter player name"
                                            className="bg-slate-900 border-slate-700"
                                            required
                                        />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <Label>Folder</Label>
                                            <Input
                                                value={formData.folder}
                                                onChange={(e) => setFormData({ ...formData, folder: e.target.value })}
                                                placeholder="Organization folder"
                                                className="bg-slate-900 border-slate-700"
                                            />
                                        </div>
                                        <div>
                                            <Label>Rating</Label>
                                            <Select
                                                value={formData.rating.toString()}
                                                onValueChange={(v) => setFormData({ ...formData, rating: parseInt(v) })}
                                            >
                                                <SelectTrigger className="bg-slate-900 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {[1, 2, 3, 4, 5].map(n => (
                                                        <SelectItem key={n} value={n.toString()}>
                                                            {'⭐'.repeat(n)}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <Label>Priority</Label>
                                            <Select
                                                value={formData.priority}
                                                onValueChange={(v) => setFormData({ ...formData, priority: v })}
                                            >
                                                <SelectTrigger className="bg-slate-900 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Low">Low</SelectItem>
                                                    <SelectItem value="Medium">Medium</SelectItem>
                                                    <SelectItem value="High">High</SelectItem>
                                                    <SelectItem value="Critical">Critical</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        <div>
                                            <Label>Status</Label>
                                            <Select
                                                value={formData.status}
                                                onValueChange={(v) => setFormData({ ...formData, status: v })}
                                            >
                                                <SelectTrigger className="bg-slate-900 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Watching">Watching</SelectItem>
                                                    <SelectItem value="Under Review">Under Review</SelectItem>
                                                    <SelectItem value="Shortlisted">Shortlisted</SelectItem>
                                                    <SelectItem value="Recommended">Recommended</SelectItem>
                                                    <SelectItem value="Passed">Passed</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div>
                                        <Label>Tags</Label>
                                        <div className="flex gap-2 mb-2">
                                            <Input
                                                value={tagInput}
                                                onChange={(e) => setTagInput(e.target.value)}
                                                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                                                placeholder="Add tag and press Enter"
                                                className="bg-slate-900 border-slate-700"
                                            />
                                            <Button type="button" onClick={addTag} size="sm">Add</Button>
                                        </div>
                                        <div className="flex gap-2 flex-wrap">
                                            {formData.tags.map(tag => (
                                                <Badge key={tag} className="bg-cyan-500/20 text-cyan-400 cursor-pointer" onClick={() => removeTag(tag)}>
                                                    {tag} ×
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>

                                    <div>
                                        <Label>Notes</Label>
                                        <Textarea
                                            value={formData.notes}
                                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                            placeholder="Personal scouting notes..."
                                            className="bg-slate-900 border-slate-700"
                                            rows={4}
                                        />
                                    </div>

                                    <div className="flex gap-3">
                                        <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                                            Cancel
                                        </Button>
                                        <Button type="submit" className="flex-1" disabled={createMutation.isPending}>
                                            {editingId ? 'Update' : 'Save'} Player
                                        </Button>
                                    </div>
                                </form>
                            </CardContent>
                        </Card>
                    )}

                    <div className="space-y-3">
                        {savedPlayers.map((player, idx) => (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-colors">
                                    <CardContent className="pt-4">
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <Link
                                                    to={createPageUrl('PlayerProfile') + `?id=${player.player_id}`}
                                                    className="text-white font-semibold text-lg hover:text-cyan-400 transition-colors"
                                                >
                                                    {player.player_name}
                                                </Link>
                                                <div className="flex items-center gap-1 mt-1">
                                                    {[...Array(5)].map((_, i) => (
                                                        <Star
                                                            key={i}
                                                            className={`w-4 h-4 ${
                                                                i < player.rating
                                                                    ? 'text-amber-400 fill-amber-400'
                                                                    : 'text-slate-600'
                                                            }`}
                                                        />
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="flex gap-2">
                                                <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    onClick={() => handleEdit(player)}
                                                    className="text-cyan-400 hover:text-cyan-300"
                                                >
                                                    <Edit className="w-4 h-4" />
                                                </Button>
                                                <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    onClick={() => deleteMutation.mutate(player.id)}
                                                    className="text-red-400 hover:text-red-300"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-2 flex-wrap mb-3">
                                            <Badge className={
                                                player.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                player.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                player.priority === 'Medium' ? 'bg-blue-500/20 text-blue-400' :
                                                'bg-slate-500/20 text-slate-400'
                                            }>
                                                {player.priority}
                                            </Badge>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">{player.status}</Badge>
                                            {player.folder !== 'Default' && (
                                                <div className="flex items-center gap-1 text-slate-400 text-sm">
                                                    <Folder className="w-3 h-3" />
                                                    {player.folder}
                                                </div>
                                            )}
                                        </div>

                                        {player.tags?.length > 0 && (
                                            <div className="flex gap-2 flex-wrap mb-3">
                                                {player.tags.map(tag => (
                                                    <Badge key={tag} variant="outline" className="text-xs">
                                                        {tag}
                                                    </Badge>
                                                ))}
                                            </div>
                                        )}

                                        {player.notes && (
                                            <p className="text-slate-400 text-sm line-clamp-2">{player.notes}</p>
                                        )}
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}

                        {savedPlayers.length === 0 && !showForm && (
                            <p className="text-slate-400 text-center py-8">No saved players yet</p>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}