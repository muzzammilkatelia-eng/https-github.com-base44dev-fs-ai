import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Folder } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function SavedPlayersWidget({ players = [] }) {
    const priorityColors = {
        Low: 'bg-slate-500/20 text-slate-400',
        Medium: 'bg-blue-500/20 text-blue-400',
        High: 'bg-amber-500/20 text-amber-400',
        Critical: 'bg-red-500/20 text-red-400'
    };

    const statusColors = {
        Watching: 'bg-cyan-500/20 text-cyan-400',
        'Under Review': 'bg-purple-500/20 text-purple-400',
        Shortlisted: 'bg-emerald-500/20 text-emerald-400',
        Recommended: 'bg-green-500/20 text-green-400',
        Passed: 'bg-slate-500/20 text-slate-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Star className="w-5 h-5 text-amber-400" />
                    Saved Players
                    <Badge className="ml-auto bg-cyan-500/20 text-cyan-400">
                        {players.length}
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent>
                {players.length === 0 ? (
                    <p className="text-slate-400 text-sm">No saved players yet</p>
                ) : (
                    <div className="space-y-2">
                        {players.slice(0, 6).map((player, idx) => (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Link
                                    to={createPageUrl('PlayerProfile') + `?id=${player.player_id}`}
                                    className="block p-3 rounded-lg bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-colors"
                                >
                                    <div className="flex items-start justify-between mb-2">
                                        <span className="text-white font-medium">{player.player_name}</span>
                                        <div className="flex gap-1">
                                            {[...Array(5)].map((_, i) => (
                                                <Star
                                                    key={i}
                                                    className={`w-3 h-3 ${
                                                        i < player.rating
                                                            ? 'text-amber-400 fill-amber-400'
                                                            : 'text-slate-600'
                                                    }`}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <Badge className={priorityColors[player.priority]}>
                                            {player.priority}
                                        </Badge>
                                        <Badge className={statusColors[player.status]}>
                                            {player.status}
                                        </Badge>
                                        {player.folder !== 'Default' && (
                                            <div className="flex items-center gap-1 text-slate-400 text-xs">
                                                <Folder className="w-3 h-3" />
                                                {player.folder}
                                            </div>
                                        )}
                                    </div>
                                    {player.notes && (
                                        <p className="text-slate-400 text-xs mt-2 line-clamp-2">
                                            {player.notes}
                                        </p>
                                    )}
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}