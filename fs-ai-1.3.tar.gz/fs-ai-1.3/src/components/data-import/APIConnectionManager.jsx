import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, RefreshCw, Settings, Trash2, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function APIConnectionManager({ integrations }) {
    const [showAddForm, setShowAddForm] = useState(false);
    const [formData, setFormData] = useState({
        integration_name: '',
        integration_type: 'Scouting Database',
        api_endpoint: '',
        sync_frequency: 'Daily'
    });

    const queryClient = useQueryClient();

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.ExternalIntegration.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['external-integrations'] });
            setShowAddForm(false);
            setFormData({
                integration_name: '',
                integration_type: 'Scouting Database',
                api_endpoint: '',
                sync_frequency: 'Daily'
            });
            toast.success('API connection created');
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ExternalIntegration.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['external-integrations'] });
            toast.success('Connection updated');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.ExternalIntegration.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['external-integrations'] });
            toast.success('Connection deleted');
        }
    });

    const syncMutation = useMutation({
        mutationFn: async (integration) => {
            await updateMutation.mutateAsync({
                id: integration.id,
                data: { status: 'Syncing' }
            });

            // Trigger appropriate sync function
            let result;
            if (integration.integration_name.toLowerCase().includes('wyscout')) {
                result = await base44.functions.invoke('syncWyscoutDatabase', {});
            } else if (integration.integration_name.toLowerCase().includes('transfermarkt')) {
                result = await base44.functions.invoke('syncTransfermarktData', {});
            } else {
                throw new Error('Sync function not configured for this integration');
            }

            return result.data;
        },
        onSuccess: (data, integration) => {
            updateMutation.mutate({
                id: integration.id,
                data: {
                    status: 'Active',
                    last_sync: new Date().toISOString(),
                    last_sync_count: data.players_synced || 0,
                    players_synced: (integration.players_synced || 0) + (data.players_synced || 0)
                }
            });
            toast.success('Sync completed successfully');
        },
        onError: (error, integration) => {
            updateMutation.mutate({
                id: integration.id,
                data: {
                    status: 'Error',
                    error_log: [
                        ...(integration.error_log || []),
                        { timestamp: new Date().toISOString(), error: error.message }
                    ]
                }
            });
            toast.error('Sync failed: ' + error.message);
        }
    });

    const toggleStatus = (integration) => {
        const newStatus = integration.status === 'Active' ? 'Inactive' : 'Active';
        updateMutation.mutate({
            id: integration.id,
            data: { status: newStatus }
        });
    };

    const statusColors = {
        Active: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        Inactive: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
        Error: 'bg-red-500/20 text-red-400 border-red-500/30',
        Syncing: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white">Connected APIs</h2>
                <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Connection
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white">
                        <DialogHeader>
                            <DialogTitle>Add API Connection</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={(e) => { e.preventDefault(); createMutation.mutate(formData); }} className="space-y-4">
                            <div>
                                <Label>Integration Name *</Label>
                                <Input
                                    required
                                    value={formData.integration_name}
                                    onChange={(e) => setFormData({...formData, integration_name: e.target.value})}
                                    className="bg-slate-800 border-slate-700"
                                    placeholder="e.g., Wyscout API"
                                />
                            </div>

                            <div>
                                <Label>Type</Label>
                                <Select value={formData.integration_type} onValueChange={(v) => setFormData({...formData, integration_type: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Scouting Database">Scouting Database</SelectItem>
                                        <SelectItem value="Analytics Provider">Analytics Provider</SelectItem>
                                        <SelectItem value="Data Feed">Data Feed</SelectItem>
                                        <SelectItem value="Video Platform">Video Platform</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div>
                                <Label>API Endpoint</Label>
                                <Input
                                    value={formData.api_endpoint}
                                    onChange={(e) => setFormData({...formData, api_endpoint: e.target.value})}
                                    className="bg-slate-800 border-slate-700"
                                    placeholder="https://api.example.com/v1"
                                />
                            </div>

                            <div>
                                <Label>Sync Frequency</Label>
                                <Select value={formData.sync_frequency} onValueChange={(v) => setFormData({...formData, sync_frequency: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Manual">Manual</SelectItem>
                                        <SelectItem value="Hourly">Hourly</SelectItem>
                                        <SelectItem value="Daily">Daily</SelectItem>
                                        <SelectItem value="Weekly">Weekly</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <Button type="submit" disabled={createMutation.isPending} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600">
                                {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                Add Connection
                            </Button>
                        </form>
                    </DialogContent>
                </Dialog>
            </div>

            {integrations.length === 0 ? (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-12 text-center">
                        <Settings className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No API connections configured</p>
                        <p className="text-slate-500 text-sm mt-1">Add your first connection to start syncing data</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid gap-4">
                    {integrations.map((integration) => (
                        <motion.div
                            key={integration.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-all">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-4">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                <h3 className="text-white font-bold text-lg">{integration.integration_name}</h3>
                                                <Badge className={statusColors[integration.status]}>
                                                    {integration.status}
                                                </Badge>
                                                {integration.api_key_configured && (
                                                    <Badge className="bg-cyan-500/20 text-cyan-400">
                                                        API Key Set
                                                    </Badge>
                                                )}
                                            </div>
                                            <p className="text-slate-400 text-sm mb-2">{integration.integration_type}</p>
                                            {integration.api_endpoint && (
                                                <p className="text-slate-500 text-xs font-mono">{integration.api_endpoint}</p>
                                            )}
                                        </div>
                                        <div className="flex gap-2">
                                            <Button
                                                onClick={() => syncMutation.mutate(integration)}
                                                disabled={syncMutation.isPending || integration.status === 'Syncing'}
                                                size="sm"
                                                variant="outline"
                                                className="border-slate-700"
                                            >
                                                <RefreshCw className={`w-4 h-4 ${integration.status === 'Syncing' ? 'animate-spin' : ''}`} />
                                            </Button>
                                            <Button
                                                onClick={() => toggleStatus(integration)}
                                                size="sm"
                                                variant="outline"
                                                className="border-slate-700"
                                            >
                                                {integration.status === 'Active' ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                                            </Button>
                                            <Button
                                                onClick={() => deleteMutation.mutate(integration.id)}
                                                size="sm"
                                                variant="outline"
                                                className="border-red-500/30 text-red-400 hover:bg-red-500/20"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-slate-700">
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Sync Frequency</p>
                                            <p className="text-white text-sm font-semibold">{integration.sync_frequency}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Players Synced</p>
                                            <p className="text-white text-sm font-semibold">{integration.players_synced?.toLocaleString() || 0}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Last Sync</p>
                                            <p className="text-white text-sm font-semibold">
                                                {integration.last_sync ? new Date(integration.last_sync).toLocaleDateString() : 'Never'}
                                            </p>
                                        </div>
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Last Count</p>
                                            <p className="text-white text-sm font-semibold">{integration.last_sync_count || 0}</p>
                                        </div>
                                    </div>

                                    {integration.error_log?.length > 0 && (
                                        <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-lg p-3">
                                            <p className="text-red-400 text-xs font-semibold mb-1">Recent Error:</p>
                                            <p className="text-red-300 text-xs">
                                                {integration.error_log[integration.error_log.length - 1].error}
                                            </p>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            )}
        </div>
    );
}