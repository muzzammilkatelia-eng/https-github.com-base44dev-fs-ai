import React from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Clock, Play, Pause } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ScheduledRefreshManager({ integrations }) {
    const queryClient = useQueryClient();

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ExternalIntegration.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['external-integrations'] });
            toast.success('Schedule updated');
        }
    });

    const updateFrequency = (integration, frequency) => {
        updateMutation.mutate({
            id: integration.id,
            data: { sync_frequency: frequency }
        });
    };

    const frequencyColors = {
        Manual: 'bg-slate-500/20 text-slate-400',
        Hourly: 'bg-red-500/20 text-red-400',
        Daily: 'bg-emerald-500/20 text-emerald-400',
        Weekly: 'bg-blue-500/20 text-blue-400'
    };

    const activeSchedules = integrations.filter(i => i.sync_frequency !== 'Manual');

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold text-white">Scheduled Refreshes</h2>
                    <p className="text-slate-400 text-sm mt-1">
                        {activeSchedules.length} active schedule{activeSchedules.length !== 1 ? 's' : ''}
                    </p>
                </div>
            </div>

            {integrations.length === 0 ? (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-12 text-center">
                        <Clock className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No integrations to schedule</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid gap-4">
                    {integrations.map((integration) => (
                        <motion.div
                            key={integration.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardContent className="pt-6">
                                    <div className="flex items-center justify-between">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                <h3 className="text-white font-bold">{integration.integration_name}</h3>
                                                <Badge className={frequencyColors[integration.sync_frequency]}>
                                                    {integration.sync_frequency}
                                                </Badge>
                                                {integration.status === 'Active' && integration.sync_frequency !== 'Manual' && (
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        <Play className="w-3 h-3 mr-1" />
                                                        Running
                                                    </Badge>
                                                )}
                                            </div>
                                            <p className="text-slate-400 text-sm">
                                                {integration.sync_frequency === 'Manual' ? (
                                                    'Manual sync only - no automatic refreshes'
                                                ) : integration.sync_frequency === 'Hourly' ? (
                                                    'Syncs every hour'
                                                ) : integration.sync_frequency === 'Daily' ? (
                                                    'Syncs once per day at midnight UTC'
                                                ) : (
                                                    'Syncs once per week on Sunday at midnight UTC'
                                                )}
                                            </p>
                                            {integration.last_sync && (
                                                <p className="text-slate-500 text-xs mt-1">
                                                    Last synced: {new Date(integration.last_sync).toLocaleString()}
                                                </p>
                                            )}
                                        </div>

                                        <div className="flex items-center gap-3">
                                            <Select
                                                value={integration.sync_frequency}
                                                onValueChange={(v) => updateFrequency(integration, v)}
                                            >
                                                <SelectTrigger className="w-32 bg-slate-800 border-slate-700">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Manual">Manual</SelectItem>
                                                    <SelectItem value="Hourly">Hourly</SelectItem>
                                                    <SelectItem value="Daily">Daily</SelectItem>
                                                    <SelectItem value="Weekly">Weekly</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    {integration.sync_frequency !== 'Manual' && (
                                        <div className="mt-4 bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                                            <div className="flex items-center gap-2 text-blue-400 text-xs">
                                                <Clock className="w-4 h-4" />
                                                <span>
                                                    Next scheduled sync: {
                                                        integration.sync_frequency === 'Hourly' ? 'Within the hour' :
                                                        integration.sync_frequency === 'Daily' ? 'Tomorrow at 00:00 UTC' :
                                                        'Next Sunday at 00:00 UTC'
                                                    }
                                                </span>
                                            </div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            )}

            {/* Info Card */}
            <Card className="bg-amber-500/10 border-amber-500/30">
                <CardContent className="pt-6">
                    <h3 className="text-amber-400 font-semibold mb-2">Scheduling Information</h3>
                    <ul className="text-slate-300 text-sm space-y-1">
                        <li>• <strong>Manual:</strong> No automatic refreshes - sync only when triggered manually</li>
                        <li>• <strong>Hourly:</strong> Data refreshes every hour (intensive - use for critical data)</li>
                        <li>• <strong>Daily:</strong> Data refreshes once per day at midnight UTC (recommended)</li>
                        <li>• <strong>Weekly:</strong> Data refreshes every Sunday at midnight UTC (for less critical data)</li>
                    </ul>
                </CardContent>
            </Card>
        </div>
    );
}