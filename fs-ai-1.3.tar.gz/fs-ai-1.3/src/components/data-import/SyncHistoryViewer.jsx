import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, CheckCircle2, XCircle, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SyncHistoryViewer({ integrations }) {
    // Build sync history from integrations
    const syncHistory = integrations
        .filter(i => i.last_sync)
        .map(i => ({
            integration: i.integration_name,
            timestamp: i.last_sync,
            count: i.last_sync_count || 0,
            status: i.status === 'Error' ? 'Failed' : 'Success',
            total_synced: i.players_synced || 0
        }))
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        .slice(0, 20);

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-xl font-bold text-white mb-1">Sync History</h2>
                <p className="text-slate-400 text-sm">Recent data synchronization events</p>
            </div>

            {syncHistory.length === 0 ? (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-12 text-center">
                        <History className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No sync history available</p>
                        <p className="text-slate-500 text-sm mt-1">Syncs will appear here once completed</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-3">
                    {syncHistory.map((sync, idx) => (
                        <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                        >
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardContent className="py-4">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-4">
                                            {sync.status === 'Success' ? (
                                                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                            ) : (
                                                <XCircle className="w-5 h-5 text-red-400" />
                                            )}
                                            <div>
                                                <div className="flex items-center gap-3 mb-1">
                                                    <h4 className="text-white font-semibold">{sync.integration}</h4>
                                                    <Badge className={
                                                        sync.status === 'Success'
                                                            ? 'bg-emerald-500/20 text-emerald-400'
                                                            : 'bg-red-500/20 text-red-400'
                                                    }>
                                                        {sync.status}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">
                                                    {new Date(sync.timestamp).toLocaleString()}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="text-right">
                                            <div className="flex items-center gap-2 text-cyan-400 mb-1">
                                                <TrendingUp className="w-4 h-4" />
                                                <span className="font-bold">{sync.count.toLocaleString()}</span>
                                            </div>
                                            <p className="text-slate-500 text-xs">
                                                Total: {sync.total_synced.toLocaleString()}
                                            </p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            )}
        </div>
    );
}