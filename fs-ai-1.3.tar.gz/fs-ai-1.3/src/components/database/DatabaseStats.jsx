import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Globe2, MapPin, Building2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DatabaseStats() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const stats = {
        total: players.length,
        local: players.filter(p => p.league === 'Yorkshire' || p.current_club?.includes('Hull')).length,
        regional: players.filter(p => ['North East', 'North West', 'Midlands', 'Scotland'].some(r => p.league?.includes(r))).length,
        national: players.filter(p => ['Premier League', 'Championship', 'League One', 'League Two'].some(l => p.league?.includes(l))).length,
        worldwide: players.filter(p => !p.league?.includes('England') && !p.league?.includes('Yorkshire')).length
    };

    const statCards = [
        { label: 'Total Players', value: stats.total, icon: Users, color: 'cyan' },
        { label: 'Local (Hull/Yorkshire)', value: stats.local, icon: MapPin, color: 'emerald' },
        { label: 'Regional (UK)', value: stats.regional, icon: Building2, color: 'purple' },
        { label: 'National (England)', value: stats.national, icon: Globe2, color: 'amber' },
        { label: 'Worldwide', value: stats.worldwide, icon: Globe2, color: 'rose' }
    ];

    return (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {statCards.map((stat, i) => (
                <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex flex-col items-center text-center">
                                <div className={`p-3 bg-${stat.color}-500/20 rounded-lg mb-2`}>
                                    <stat.icon className={`w-6 h-6 text-${stat.color}-400`} />
                                </div>
                                <p className="text-3xl font-bold text-white">{stat.value}</p>
                                <p className="text-slate-400 text-xs mt-1">{stat.label}</p>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
}