import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Globe2, Building2, Map } from 'lucide-react';

export default function GeographicFilter({ selectedScope, onScopeChange }) {
    const scopes = [
        { value: 'all', label: 'All Players', icon: Globe2, color: 'slate' },
        { value: 'local', label: 'Local (Hull/Yorkshire)', icon: MapPin, color: 'emerald' },
        { value: 'regional', label: 'Regional (UK)', icon: Building2, color: 'purple' },
        { value: 'national', label: 'National (England)', icon: Map, color: 'amber' },
        { value: 'worldwide', label: 'Worldwide', icon: Globe2, color: 'cyan' }
    ];

    return (
        <div className="flex flex-wrap gap-2">
            {scopes.map((scope) => {
                const Icon = scope.icon;
                const isSelected = selectedScope === scope.value;
                
                return (
                    <Button
                        key={scope.value}
                        onClick={() => onScopeChange(scope.value)}
                        variant={isSelected ? 'default' : 'outline'}
                        className={isSelected 
                            ? `bg-${scope.color}-600 hover:bg-${scope.color}-700 border-${scope.color}-500` 
                            : 'border-slate-700 text-slate-300'
                        }
                    >
                        <Icon className="w-4 h-4 mr-2" />
                        {scope.label}
                    </Button>
                );
            })}
        </div>
    );
}