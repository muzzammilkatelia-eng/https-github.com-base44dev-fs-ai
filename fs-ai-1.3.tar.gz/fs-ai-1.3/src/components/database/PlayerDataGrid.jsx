import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Search, Filter, Eye, SortAsc, X, RotateCcw, GitCompare, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { motion } from 'framer-motion';
import QuickComparePanel from '../comparison/QuickComparePanel';

const defaultFilters = {
    searchTerm: '',
    position: 'all',
    gender: 'all',
    nationality: 'all',
    club: 'all',
    league: 'all',
    ageRange: [15, 45],
    minRating: 0
};

export default function PlayerDataGrid({ geographicScope }) {
    const [filters, setFilters] = useState(defaultFilters);
    const [sortBy, setSortBy] = useState('name');
    const [visibleCount, setVisibleCount] = useState(0);
    const [showAdvanced, setShowAdvanced] = useState(false);
    const [compareMode, setCompareMode] = useState(false);
    const [selectedForCompare, setSelectedForCompare] = useState([]);
    const [showComparePanel, setShowComparePanel] = useState(false);

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    // Extract unique values for filter dropdowns
    const filterOptions = useMemo(() => {
        const nationalities = [...new Set(players.map(p => p.nationality).filter(Boolean))].sort();
        const clubs = [...new Set(players.map(p => p.current_club).filter(Boolean))].sort();
        const leagues = [...new Set(players.map(p => p.league).filter(Boolean))].sort();
        return { nationalities, clubs, leagues };
    }, [players]);

    const categorizePlayer = (player) => {
        if (player.league === 'Yorkshire' || player.current_club?.includes('Hull')) return 'local';
        if (['North East', 'North West', 'Midlands', 'Scotland'].some(r => player.league?.includes(r))) return 'regional';
        if (['Premier League', 'Championship', 'League One', 'League Two'].some(l => player.league?.includes(l))) return 'national';
        return 'worldwide';
    };

    const filteredPlayers = players
        .filter(p => {
            const matchesSearch = p.name?.toLowerCase().includes(filters.searchTerm.toLowerCase());
            const matchesPosition = filters.position === 'all' || p.position === filters.position;
            const matchesGender = filters.gender === 'all' || (p.gender || p.wyscout_data?.gender || 'male') === filters.gender;
            const matchesNationality = filters.nationality === 'all' || p.nationality === filters.nationality;
            const matchesClub = filters.club === 'all' || p.current_club === filters.club;
            const matchesLeague = filters.league === 'all' || p.league === filters.league;
            const matchesAge = (p.age || 20) >= filters.ageRange[0] && (p.age || 20) <= filters.ageRange[1];
            const matchesRating = (p.fsai_proprietary_score || 0) >= filters.minRating;
            const matchesScope = geographicScope === 'all' || categorizePlayer(p) === geographicScope;
            return matchesSearch && matchesPosition && matchesGender && matchesNationality && matchesClub && matchesLeague && matchesAge && matchesRating && matchesScope;
        })
        .sort((a, b) => {
            if (sortBy === 'name') return (a.name || '').localeCompare(b.name || '');
            if (sortBy === 'age') return (a.age || 0) - (b.age || 0);
            if (sortBy === 'rating') return (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0);
            if (sortBy === 'club') return (a.current_club || '').localeCompare(b.current_club || '');
            return 0;
        });

    // Animate players appearing one by one
    React.useEffect(() => {
        setVisibleCount(0);
        if (filteredPlayers.length === 0) return;
        
        const interval = setInterval(() => {
            setVisibleCount(prev => {
                if (prev >= filteredPlayers.length) {
                    clearInterval(interval);
                    return prev;
                }
                return prev + 1;
            });
        }, 50);

        return () => clearInterval(interval);
    }, [filteredPlayers.length, filters, sortBy, geographicScope]);

    const updateFilter = (key, value) => {
        setFilters(prev => ({ ...prev, [key]: value }));
    };

    const clearAllFilters = () => {
        setFilters(defaultFilters);
    };

    const hasActiveFilters = JSON.stringify(filters) !== JSON.stringify(defaultFilters);

    const togglePlayerForCompare = (player) => {
        if (selectedForCompare.find(p => p.id === player.id)) {
            setSelectedForCompare(selectedForCompare.filter(p => p.id !== player.id));
        } else if (selectedForCompare.length < 4) {
            setSelectedForCompare([...selectedForCompare, player]);
        }
    };

    const positions = ['all', 'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Search className="w-5 h-5 text-cyan-400" />
                    Player Database ({filteredPlayers.length})
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Primary Filters Row */}
                <div className="grid md:grid-cols-5 gap-3">
                    <Input
                        placeholder="Search players..."
                        value={filters.searchTerm}
                        onChange={(e) => updateFilter('searchTerm', e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                    <Select value={filters.position} onValueChange={(v) => updateFilter('position', v)}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue placeholder="Position" />
                        </SelectTrigger>
                        <SelectContent>
                            {positions.map(pos => (
                                <SelectItem key={pos} value={pos}>
                                    {pos === 'all' ? 'All Positions' : pos}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Select value={filters.nationality} onValueChange={(v) => updateFilter('nationality', v)}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue placeholder="Nationality" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Nationalities</SelectItem>
                            {filterOptions.nationalities.map(nat => (
                                <SelectItem key={nat} value={nat}>{nat}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Select value={sortBy} onValueChange={setSortBy}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SortAsc className="w-4 h-4 mr-2" />
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="name">Name</SelectItem>
                            <SelectItem value="age">Age</SelectItem>
                            <SelectItem value="rating">FS-AI Rating</SelectItem>
                            <SelectItem value="club">Club</SelectItem>
                        </SelectContent>
                    </Select>
                    <div className="flex gap-2">
                          <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setShowAdvanced(!showAdvanced)}
                              className="border-slate-700 text-slate-300 hover:bg-slate-800"
                          >
                              <Filter className="w-4 h-4 mr-1" />
                              {showAdvanced ? 'Less' : 'More'}
                          </Button>
                          <Button 
                              variant={compareMode ? "default" : "outline"}
                              size="sm"
                              onClick={() => {
                                  setCompareMode(!compareMode);
                                  if (compareMode) setSelectedForCompare([]);
                              }}
                              className={compareMode 
                                  ? "bg-cyan-600 hover:bg-cyan-700" 
                                  : "border-slate-700 text-slate-300 hover:bg-slate-800"}
                          >
                              <GitCompare className="w-4 h-4 mr-1" />
                              Compare
                          </Button>
                          {hasActiveFilters && (
                              <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={clearAllFilters}
                                  className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                              >
                                  <RotateCcw className="w-4 h-4" />
                              </Button>
                          )}
                      </div>
                </div>

                {/* Advanced Filters */}
                {showAdvanced && (
                    <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="bg-slate-800/50 rounded-lg p-4 space-y-4"
                    >
                        <div className="grid md:grid-cols-4 gap-3">
                            <Select value={filters.club} onValueChange={(v) => updateFilter('club', v)}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Club" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Clubs</SelectItem>
                                    {filterOptions.clubs.map(club => (
                                        <SelectItem key={club} value={club}>{club}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <Select value={filters.league} onValueChange={(v) => updateFilter('league', v)}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="League" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Leagues</SelectItem>
                                    {filterOptions.leagues.map(league => (
                                        <SelectItem key={league} value={league}>{league}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <Select value={filters.gender} onValueChange={(v) => updateFilter('gender', v)}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Gender" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Genders</SelectItem>
                                    <SelectItem value="male">Men</SelectItem>
                                    <SelectItem value="female">Women</SelectItem>
                                </SelectContent>
                            </Select>
                            <div className="flex items-center gap-2">
                                <span className="text-slate-400 text-sm whitespace-nowrap">Min Rating:</span>
                                <Input
                                    type="number"
                                    min={0}
                                    max={100}
                                    value={filters.minRating}
                                    onChange={(e) => updateFilter('minRating', Number(e.target.value))}
                                    className="bg-slate-800 border-slate-700 text-white w-20"
                                />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Age Range</span>
                                <span className="text-cyan-400">{filters.ageRange[0]} - {filters.ageRange[1]} years</span>
                            </div>
                            <Slider
                                value={filters.ageRange}
                                onValueChange={(v) => updateFilter('ageRange', v)}
                                min={15}
                                max={45}
                                step={1}
                                className="py-2"
                            />
                        </div>
                    </motion.div>
                )}

                {/* Active Filters Tags */}
                {hasActiveFilters && (
                    <div className="flex flex-wrap gap-2">
                        {filters.searchTerm && (
                            <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-400 gap-1">
                                Search: {filters.searchTerm}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('searchTerm', '')} />
                            </Badge>
                        )}
                        {filters.position !== 'all' && (
                            <Badge variant="secondary" className="bg-purple-500/20 text-purple-400 gap-1">
                                {filters.position}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('position', 'all')} />
                            </Badge>
                        )}
                        {filters.nationality !== 'all' && (
                            <Badge variant="secondary" className="bg-green-500/20 text-green-400 gap-1">
                                {filters.nationality}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('nationality', 'all')} />
                            </Badge>
                        )}
                        {filters.club !== 'all' && (
                            <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 gap-1">
                                {filters.club}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('club', 'all')} />
                            </Badge>
                        )}
                        {filters.league !== 'all' && (
                            <Badge variant="secondary" className="bg-blue-500/20 text-blue-400 gap-1">
                                {filters.league}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('league', 'all')} />
                            </Badge>
                        )}
                        {(filters.ageRange[0] !== 15 || filters.ageRange[1] !== 45) && (
                            <Badge variant="secondary" className="bg-pink-500/20 text-pink-400 gap-1">
                                Age: {filters.ageRange[0]}-{filters.ageRange[1]}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('ageRange', [15, 45])} />
                            </Badge>
                        )}
                        {filters.minRating > 0 && (
                            <Badge variant="secondary" className="bg-orange-500/20 text-orange-400 gap-1">
                                Rating ≥ {filters.minRating}
                                <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('minRating', 0)} />
                            </Badge>
                        )}
                    </div>
                )}

                {/* Compare Mode Selection Bar */}
                {compareMode && selectedForCompare.length > 0 && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 flex items-center justify-between"
                    >
                        <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-cyan-400 text-sm font-medium">
                                {selectedForCompare.length}/4 selected:
                            </span>
                            {selectedForCompare.map(p => (
                                <Badge key={p.id} className="bg-cyan-500/20 text-cyan-400 gap-1">
                                    {p.name}
                                    <X className="w-3 h-3 cursor-pointer" onClick={() => togglePlayerForCompare(p)} />
                                </Badge>
                            ))}
                        </div>
                        <Button
                            size="sm"
                            onClick={() => setShowComparePanel(true)}
                            disabled={selectedForCompare.length < 2}
                            className="bg-cyan-600 hover:bg-cyan-700"
                        >
                            <GitCompare className="w-4 h-4 mr-1" />
                            Compare Now
                        </Button>
                    </motion.div>
                )}

                {isLoading ? (
                    <div className="text-center py-12 text-slate-400">Loading players...</div>
                ) : filteredPlayers.length === 0 ? (
                    <div className="text-center py-12 text-slate-400">No players found</div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {filteredPlayers.slice(0, visibleCount).map((player, i) => {
                            const isSelected = selectedForCompare.find(p => p.id === player.id);
                            return (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, y: 20, scale: 0.9 }}
                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                    transition={{ duration: 0.3, ease: "easeOut" }}
                                >
                                    <Card 
                                        className={`bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-all ${
                                            isSelected ? 'ring-2 ring-cyan-500 border-cyan-500' : ''
                                        } ${compareMode ? 'cursor-pointer' : ''}`}
                                        onClick={compareMode ? () => togglePlayerForCompare(player) : undefined}
                                    >
                                        <CardContent className="pt-4">
                                            <div className="flex justify-between items-start mb-3">
                                                <div className="flex items-start gap-2">
                                                    {compareMode && (
                                                        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 ${
                                                            isSelected 
                                                                ? 'bg-cyan-500 border-cyan-500' 
                                                                : 'border-slate-600'
                                                        }`}>
                                                            {isSelected && <Check className="w-3 h-3 text-white" />}
                                                        </div>
                                                    )}
                                                    <div>
                                                        <h3 className="text-white font-semibold">{player.name}</h3>
                                                        <p className="text-slate-400 text-sm">{player.current_club}</p>
                                                    </div>
                                                </div>
                                                {!compareMode && (
                                                    <Link to={createPageUrl('PlayerProfileDetail') + '?id=' + player.id}>
                                                        <Button size="icon" variant="ghost" className="h-8 w-8 text-cyan-400">
                                                            <Eye className="w-4 h-4" />
                                                        </Button>
                                                    </Link>
                                                )}
                                            </div>
                                            <div className="flex flex-wrap gap-2">
                                                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                    {player.position}
                                                </Badge>
                                                <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                    {player.age} yrs
                                                </Badge>
                                                {player.fsai_proprietary_score && (
                                                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                        ⭐ {player.fsai_proprietary_score.toFixed(1)}
                                                    </Badge>
                                                )}
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            );
                        })}
                    </div>
                )}

                {/* Compare Panel Modal */}
                {showComparePanel && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
                        onClick={() => setShowComparePanel(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            className="w-full max-w-5xl max-h-[90vh] overflow-y-auto"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <QuickComparePanel 
                                initialPlayers={selectedForCompare}
                                onClose={() => setShowComparePanel(false)}
                            />
                        </motion.div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}