import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Target, Shield, Footprints, AlertTriangle, Goal } from 'lucide-react';

const StatBar = ({ label, value, max = 100, suffix = '%', color = 'cyan' }) => {
    const percentage = Math.min((value / max) * 100, 100);
    const colorClasses = {
        cyan: 'bg-cyan-500',
        green: 'bg-green-500',
        amber: 'bg-amber-500',
        red: 'bg-red-500',
        purple: 'bg-purple-500'
    };
    
    return (
        <div className="space-y-1">
            <div className="flex justify-between text-sm">
                <span className="text-slate-400">{label}</span>
                <span className="text-white font-medium">{value}{suffix}</span>
            </div>
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <div 
                    className={`h-full ${colorClasses[color]} rounded-full transition-all`}
                    style={{ width: `${percentage}%` }}
                />
            </div>
        </div>
    );
};

const StatValue = ({ label, value, suffix = '' }) => (
    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
        <div className="text-2xl font-bold text-white">{value ?? '-'}{suffix}</div>
        <div className="text-xs text-slate-400">{label}</div>
    </div>
);

export default function PlayerDetailedStats({ player }) {
    const stats = player?.detailed_stats;
    
    if (!stats) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-8 text-center text-slate-500">
                    No detailed statistics available for this player.
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-cyan-400" />
                    Detailed Statistics - {player.name}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="attacking" className="w-full">
                    <TabsList className="grid grid-cols-5 bg-slate-800/50 mb-4">
                        <TabsTrigger value="attacking" className="data-[state=active]:bg-cyan-600">
                            <Goal className="w-4 h-4 mr-1" /> Attack
                        </TabsTrigger>
                        <TabsTrigger value="passing" className="data-[state=active]:bg-cyan-600">
                            Passing
                        </TabsTrigger>
                        <TabsTrigger value="defending" className="data-[state=active]:bg-cyan-600">
                            <Shield className="w-4 h-4 mr-1" /> Defense
                        </TabsTrigger>
                        <TabsTrigger value="possession" className="data-[state=active]:bg-cyan-600">
                            <Footprints className="w-4 h-4 mr-1" /> Possession
                        </TabsTrigger>
                        <TabsTrigger value="discipline" className="data-[state=active]:bg-cyan-600">
                            <AlertTriangle className="w-4 h-4 mr-1" /> Discipline
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="attacking" className="space-y-4">
                        <div className="grid grid-cols-4 gap-3">
                            <StatValue label="Goals" value={stats.attacking?.goals} />
                            <StatValue label="Assists" value={stats.attacking?.assists} />
                            <StatValue label="xG" value={stats.attacking?.expected_goals?.toFixed(1)} />
                            <StatValue label="xA" value={stats.attacking?.expected_assists?.toFixed(1)} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <StatBar label="Shot Accuracy" value={stats.attacking?.shot_accuracy} color="cyan" />
                            <StatBar label="Shots per Game" value={stats.attacking?.shots_per_game} max={5} suffix="" color="amber" />
                            <StatBar label="Goals from Outside Box" value={stats.attacking?.goals_from_outside_box} max={10} suffix="" color="purple" />
                            <StatBar label="Headed Goals" value={stats.attacking?.headed_goals} max={10} suffix="" color="green" />
                            <StatBar label="Assists after Dribble" value={stats.attacking?.assists_after_dribble} max={10} suffix="" color="cyan" />
                            <StatBar label="Big Chances Created" value={stats.attacking?.big_chances_created} max={20} suffix="" color="amber" />
                        </div>
                    </TabsContent>

                    <TabsContent value="passing" className="space-y-4">
                        <div className="grid grid-cols-3 gap-3">
                            <StatValue label="Pass Accuracy" value={stats.passing?.accuracy} suffix="%" />
                            <StatValue label="Key Passes/Game" value={stats.passing?.key_passes_per_game?.toFixed(1)} />
                            <StatValue label="Crosses/Game" value={stats.passing?.crosses_per_game?.toFixed(1)} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <StatBar label="Passing Accuracy" value={stats.passing?.accuracy} color="cyan" />
                            <StatBar label="Long Balls Accuracy" value={stats.passing?.long_balls_accuracy} color="amber" />
                            <StatBar label="Cross Accuracy" value={stats.passing?.cross_accuracy} color="green" />
                            <StatBar label="Through Balls/Game" value={stats.passing?.through_balls_per_game} max={3} suffix="" color="purple" />
                        </div>
                    </TabsContent>

                    <TabsContent value="defending" className="space-y-4">
                        <div className="grid grid-cols-4 gap-3">
                            <StatValue label="Tackles/Game" value={stats.defending?.tackles_per_game?.toFixed(1)} />
                            <StatValue label="Interceptions/Game" value={stats.defending?.interceptions_per_game?.toFixed(1)} />
                            <StatValue label="Clearances/Game" value={stats.defending?.clearances_per_game?.toFixed(1)} />
                            <StatValue label="Blocks/Game" value={stats.defending?.blocks_per_game?.toFixed(1)} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <StatBar label="Tackling Success Rate" value={stats.defending?.tackling_success_rate} color="green" />
                            <StatBar label="Aerial Duels Won %" value={stats.defending?.aerial_duels_won_pct} color="cyan" />
                            <StatBar label="Ground Duels Won %" value={stats.defending?.ground_duels_won_pct} color="amber" />
                            <StatBar label="Aerial Duels Won" value={stats.defending?.aerial_duels_won} max={100} suffix="" color="purple" />
                        </div>
                    </TabsContent>

                    <TabsContent value="possession" className="space-y-4">
                        <div className="grid grid-cols-3 gap-3">
                            <StatValue label="Touches/Game" value={stats.possession?.touches_per_game?.toFixed(0)} />
                            <StatValue label="Dribbles/Game" value={stats.possession?.dribbles_per_game?.toFixed(1)} />
                            <StatValue label="Recoveries/Game" value={stats.possession?.ball_recoveries_per_game?.toFixed(1)} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <StatBar label="Dribble Success Rate" value={stats.possession?.dribble_success_rate} color="cyan" />
                            <StatBar label="Dispossessed/Game" value={stats.possession?.dispossessed_per_game} max={5} suffix="" color="red" />
                        </div>
                    </TabsContent>

                    <TabsContent value="discipline" className="space-y-4">
                        <div className="grid grid-cols-4 gap-3">
                            <StatValue label="Yellow Cards" value={stats.discipline?.yellow_cards} />
                            <StatValue label="Red Cards" value={stats.discipline?.red_cards} />
                            <StatValue label="Fouls/Game" value={stats.discipline?.fouls_committed_per_game?.toFixed(1)} />
                            <StatValue label="Fouls Won/Game" value={stats.discipline?.fouls_won_per_game?.toFixed(1)} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <StatBar label="Fouls Committed/Game" value={stats.discipline?.fouls_committed_per_game} max={4} suffix="" color="red" />
                            <StatBar label="Fouls Won/Game" value={stats.discipline?.fouls_won_per_game} max={4} suffix="" color="green" />
                            <StatBar label="Offsides/Game" value={stats.discipline?.offsides_per_game} max={3} suffix="" color="amber" />
                        </div>
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}