import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, ArrowRight, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TalentPipeline() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list()
    });

    const categorizePlayer = (player) => {
        if (player.league === 'Yorkshire' || player.current_club?.includes('Hull')) return 'local';
        if (['North East', 'North West', 'Midlands', 'Scotland'].some(r => player.league?.includes(r))) return 'regional';
        if (['Premier League', 'Championship', 'League One', 'League Two'].some(l => player.league?.includes(l))) return 'national';
        return 'worldwide';
    };

    const pipeline = {
        local: players.filter(p => categorizePlayer(p) === 'local'),
        regional: players.filter(p => categorizePlayer(p) === 'regional'),
        national: players.filter(p => categorizePlayer(p) === 'national'),
        worldwide: players.filter(p => categorizePlayer(p) === 'worldwide')
    };

    const stages = [
        { key: 'local', label: 'Local', color: 'emerald', icon: MapPin },
        { key: 'regional', label: 'Regional', color: 'purple', icon: MapPin },
        { key: 'national', label: 'National', color: 'amber', icon: MapPin },
        { key: 'worldwide', label: 'Worldwide', color: 'cyan', icon: TrendingUp }
    ];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                    Talent Expansion Pipeline
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    {stages.map((stage, i) => {
                        const Icon = stage.icon;
                        const count = pipeline[stage.key].length;
                        const topTalent = pipeline[stage.key]
                            .filter(p => p.fsai_proprietary_score >= 75)
                            .length;

                        return (
                            <motion.div
                                key={stage.key}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                            >
                                <div className="flex items-center gap-4">
                                    <div className={`p-3 bg-${stage.color}-500/20 rounded-lg`}>
                                        <Icon className={`w-6 h-6 text-${stage.color}-400`} />
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4 className="text-white font-semibold">{stage.label}</h4>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-slate-800 text-white border-slate-700">
                                                    {count} players
                                                </Badge>
                                                {topTalent > 0 && (
                                                    <Badge className={`bg-${stage.color}-500/20 text-${stage.color}-400 border-${stage.color}-500/30`}>
                                                        {topTalent} elite
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                        <div className="w-full bg-slate-800 rounded-full h-2">
                                            <div
                                                className={`bg-${stage.color}-500 h-2 rounded-full transition-all`}
                                                style={{ width: `${Math.min((count / players.length) * 100, 100)}%` }}
                                            />
                                        </div>
                                    </div>
                                    {i < stages.length - 1 && (
                                        <ArrowRight className="w-5 h-5 text-slate-600" />
                                    )}
                                </div>
                            </motion.div>
                        );
                    })}
                </div>

                <div className="mt-6 p-4 bg-slate-800/50 rounded-lg">
                    <p className="text-slate-300 text-sm">
                        <span className="font-semibold text-cyan-400">Smart 5.1 Principle:</span> Start small, learn deeply, scale intelligently. Build local patterns first, then expand regionally, nationally, and globally.
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}