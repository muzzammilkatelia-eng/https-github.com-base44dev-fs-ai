import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Loader2, Brain, TrendingUp, AlertTriangle, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function DevelopmentAnalyzer({ players, reports, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const queryClient = useQueryClient();

    const analyzePlayer = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setIsAnalyzing(true);
        try {
            const player = players.find(p => p.id === selectedPlayer);
            const playerReports = reports.filter(r => r.player_name === player.name);
            const playerProjection = projections.find(p => p.player_name === player.name);

            const prompt = `
You are an elite player development analyst. Analyze historical performance data and predict growth potential.

PLAYER PROFILE:
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Club: ${player.current_club || 'Unknown'}

HISTORICAL SCOUTING DATA (${playerReports.length} reports):
${playerReports.slice(0, 5).map((r, i) => `
Report ${i + 1} (${r.created_date}):
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10
- Physical: ${r.physical_rating}/10
- Tactical: ${r.tactical_rating}/10
- Mental: ${r.mental_rating}/10
- Strengths: ${r.strengths || 'N/A'}
- Weaknesses: ${r.weaknesses || 'N/A'}
`).join('\n')}

${playerProjection ? `
CURRENT PROJECTION:
- Trajectory: ${playerProjection.potential_trajectory}
- Peak Rating: ${playerProjection.peak_potential_rating}/10
- Years to Peak: ${playerProjection.years_to_peak}
` : ''}

${player.physical_attributes ? `
PHYSICAL DATA:
- Height: ${player.physical_attributes.height}cm
- Weight: ${player.physical_attributes.weight}kg
- Pace: ${player.physical_attributes.pace}/10
- Strength: ${player.physical_attributes.strength}/10
` : ''}

Based on this comprehensive data, provide a detailed development analysis including:

1. **Growth Potential Score** (0-100)
2. **Current Strengths** (ranked by importance)
3. **Critical Weaknesses** (areas needing immediate work)
4. **Development Priorities** (short-term and long-term)
5. **Risk Factors** (injury prone, mentality issues, etc.)
6. **Optimal Training Focus** (technical, physical, tactical, mental)
7. **Realistic Peak Timeline**
8. **Comparison to Similar Players**

Analyze trends in the historical reports. Is the player improving or stagnating?
            `;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        growth_potential_score: { type: "number", minimum: 0, maximum: 100 },
                        potential_category: { type: "string", enum: ["Elite Prospect", "High Potential", "Solid Prospect", "Average", "Limited"] },
                        current_strengths: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    rating: { type: "number" },
                                    description: { type: "string" }
                                }
                            }
                        },
                        critical_weaknesses: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    severity: { type: "string", enum: ["Critical", "High", "Medium"] },
                                    description: { type: "string" }
                                }
                            }
                        },
                        development_priorities: {
                            type: "object",
                            properties: {
                                short_term: { type: "array", items: { type: "string" } },
                                long_term: { type: "array", items: { type: "string" } }
                            }
                        },
                        risk_factors: { type: "array", items: { type: "string" } },
                        training_focus: {
                            type: "object",
                            properties: {
                                technical: { type: "number" },
                                physical: { type: "number" },
                                tactical: { type: "number" },
                                mental: { type: "number" }
                            }
                        },
                        peak_timeline: { type: "string" },
                        trend_analysis: { type: "string" },
                        similar_players: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis({ ...result, player_name: player.name, player_id: player.id });
            toast.success('Analysis complete');
        } catch (error) {
            toast.error('Analysis failed');
            console.error(error);
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getPotentialColor = (score) => {
        if (score >= 80) return 'text-green-400';
        if (score >= 60) return 'text-cyan-400';
        if (score >= 40) return 'text-yellow-400';
        return 'text-orange-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-400" />
                        AI Development Analysis
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label className="text-slate-400">Select Player</Label>
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                <SelectValue placeholder="Choose player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} - {p.position} ({p.age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <Button
                        onClick={analyzePlayer}
                        disabled={isAnalyzing || !selectedPlayer}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Historical Data...
                            </>
                        ) : (
                            <>
                                <Brain className="w-4 h-4 mr-2" />
                                Analyze Growth Potential
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {analysis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Growth Potential */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="text-center mb-4">
                                <div className={`text-6xl font-bold ${getPotentialColor(analysis.growth_potential_score)}`}>
                                    {analysis.growth_potential_score}
                                </div>
                                <p className="text-slate-400 text-sm mt-2">Growth Potential Score</p>
                                <Badge className="bg-purple-500/20 text-purple-400 mt-2">
                                    {analysis.potential_category}
                                </Badge>
                            </div>

                            <div className="space-y-3">
                                <h4 className="text-white font-semibold text-sm">Training Focus Distribution</h4>
                                {Object.entries(analysis.training_focus || {}).map(([area, value]) => (
                                    <div key={area}>
                                        <div className="flex justify-between text-sm mb-1">
                                            <span className="text-slate-400 capitalize">{area}</span>
                                            <span className="text-white font-medium">{value}%</span>
                                        </div>
                                        <Progress value={value} className="h-2" />
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Strengths & Weaknesses */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-green-400 text-lg flex items-center gap-2">
                                    <Target className="w-5 h-5" />
                                    Current Strengths
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {analysis.current_strengths?.map((strength, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded p-3">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="text-white font-medium">{strength.area}</span>
                                            <Badge className="bg-green-500/20 text-green-400">
                                                {strength.rating}/10
                                            </Badge>
                                        </div>
                                        <p className="text-slate-400 text-sm">{strength.description}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-amber-400 text-lg flex items-center gap-2">
                                    <AlertTriangle className="w-5 h-5" />
                                    Critical Weaknesses
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {analysis.critical_weaknesses?.map((weakness, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded p-3">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="text-white font-medium">{weakness.area}</span>
                                            <Badge className="bg-red-500/20 text-red-400">
                                                {weakness.severity}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-400 text-sm">{weakness.description}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Development Priorities */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Development Priorities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="text-cyan-400 font-semibold mb-2">Short-Term (0-6 months)</h4>
                                    <ul className="space-y-2">
                                        {analysis.development_priorities?.short_term?.map((priority, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-cyan-400 mt-0.5">•</span>
                                                {priority}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="text-purple-400 font-semibold mb-2">Long-Term (6-18 months)</h4>
                                    <ul className="space-y-2">
                                        {analysis.development_priorities?.long_term?.map((priority, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-purple-400 mt-0.5">•</span>
                                                {priority}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Additional Insights */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Trend Analysis</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.trend_analysis}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Risk Factors</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {analysis.risk_factors?.map((risk, idx) => (
                                        <li key={idx} className="text-amber-400 text-sm flex items-start gap-2">
                                            <AlertTriangle className="w-4 h-4 mt-0.5" />
                                            {risk}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Peak Timeline */}
                    <Card className="bg-cyan-500/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <h4 className="text-cyan-400 font-semibold mb-2">Peak Timeline Prediction</h4>
                            <p className="text-white text-lg">{analysis.peak_timeline}</p>
                            {analysis.similar_players?.length > 0 && (
                                <div className="mt-4">
                                    <p className="text-slate-400 text-sm mb-2">Similar player trajectories:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {analysis.similar_players.map((player, idx) => (
                                            <Badge key={idx} className="bg-slate-700 text-slate-300">
                                                {player}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}