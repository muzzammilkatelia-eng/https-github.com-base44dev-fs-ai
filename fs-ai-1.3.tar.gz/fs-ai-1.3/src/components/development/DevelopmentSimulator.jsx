import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, GitBranch, Zap, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function DevelopmentSimulator({ players, projections, reports }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [selectedPath, setSelectedPath] = useState('');
    const [simulation, setSimulation] = useState(null);
    const [isSimulating, setIsSimulating] = useState(false);

    const DEVELOPMENT_PATHS = [
        { id: 'aggressive', name: 'Aggressive Development', description: 'Fast-track with intensive training' },
        { id: 'balanced', name: 'Balanced Approach', description: 'Steady, sustainable growth' },
        { id: 'conservative', name: 'Conservative Development', description: 'Low-risk, injury prevention focus' },
        { id: 'specialized', name: 'Specialized Training', description: 'Focus on specific archetype' }
    ];

    const simulatePath = async () => {
        if (!selectedPlayer || !selectedPath) {
            toast.error('Select player and development path');
            return;
        }

        setIsSimulating(true);
        toast.loading('Simulating development path...', { id: 'simulate' });

        try {
            const player = players.find(p => p.id === selectedPlayer);
            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );
            const playerReports = reports.filter(r => 
                r.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            const path = DEVELOPMENT_PATHS.find(p => p.id === selectedPath);

            const prompt = `You are the FS-AI Development Simulator. Simulate the outcomes of this development path.

PLAYER: ${player.name}
Age: ${player.age}
Position: ${player.position}
Current FS-AI Score: ${player.fsai_proprietary_score || 'N/A'}

CURRENT STATE:
${playerReports[0] ? `
- Overall: ${playerReports[0].overall_rating}/10
- Technical: ${playerReports[0].technical_rating}/10
- Physical: ${playerReports[0].physical_rating}/10
- Mental: ${playerReports[0].mental_rating}/10
` : 'No recent reports'}

PROJECTION:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Potential: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
` : 'No projection'}

DEVELOPMENT PATH: ${path.name}
Approach: ${path.description}

SIMULATE 3 TIMEFRAMES:
1. 6-Month Outcome
2. 12-Month Outcome
3. 24-Month Outcome

For each timeframe, provide:
- Predicted ratings (Overall, Technical, Physical, Mental, Tactical)
- Key developments
- Potential risks
- Probability of success (%)
- Market value impact

Also compare this path against alternative paths (what would happen differently).`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        path_selected: { type: "string" },
                        timeframes: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    period: { type: "string" },
                                    predicted_overall: { type: "number" },
                                    predicted_technical: { type: "number" },
                                    predicted_physical: { type: "number" },
                                    predicted_mental: { type: "number" },
                                    predicted_tactical: { type: "number" },
                                    key_developments: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    risks: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    success_probability: { type: "number" },
                                    market_value_change: { type: "string" }
                                }
                            }
                        },
                        path_comparison: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    alternative_path: { type: "string" },
                                    outcome_difference: { type: "string" },
                                    recommendation: { type: "string" }
                                }
                            }
                        },
                        overall_recommendation: { type: "string" },
                        critical_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        exit_strategies: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    action: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setSimulation(response);
            toast.success('Simulation complete!', { id: 'simulate' });
        } catch (error) {
            console.error('Simulation failed:', error);
            toast.error('Simulation failed', { id: 'simulate' });
        } finally {
            setIsSimulating(false);
        }
    };

    const getRatingColor = (rating) => {
        if (rating >= 8) return 'text-emerald-400';
        if (rating >= 6) return 'text-cyan-400';
        if (rating >= 4) return 'text-amber-400';
        return 'text-red-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <GitBranch className="w-5 h-5 text-purple-400" />
                        Development Path Simulator
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Select Player</label>
                                <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Choose player..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {players.map(player => (
                                            <SelectItem key={player.id} value={player.id}>
                                                {player.name} - {player.position} ({player.age}y)
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Development Path</label>
                                <Select value={selectedPath} onValueChange={setSelectedPath}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Choose path..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {DEVELOPMENT_PATHS.map(path => (
                                            <SelectItem key={path.id} value={path.id}>
                                                {path.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        {selectedPath && (
                            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3">
                                <p className="text-purple-400 font-semibold text-sm">
                                    {DEVELOPMENT_PATHS.find(p => p.id === selectedPath)?.name}
                                </p>
                                <p className="text-slate-300 text-sm">
                                    {DEVELOPMENT_PATHS.find(p => p.id === selectedPath)?.description}
                                </p>
                            </div>
                        )}

                        <Button
                            onClick={simulatePath}
                            disabled={isSimulating || !selectedPlayer || !selectedPath}
                            className="w-full bg-gradient-to-r from-purple-500 to-blue-600"
                        >
                            {isSimulating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Simulating...
                                </>
                            ) : (
                                <>
                                    <Zap className="w-4 h-4 mr-2" />
                                    Run Simulation
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {simulation && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Timeframe Simulations */}
                    {simulation.timeframes?.map((timeframe, idx) => (
                        <Card key={idx} className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <CardTitle className="text-white">{timeframe.period} Projection</CardTitle>
                                    <Badge className={
                                        timeframe.success_probability >= 80 ? 'bg-emerald-500/20 text-emerald-400' :
                                        timeframe.success_probability >= 60 ? 'bg-cyan-500/20 text-cyan-400' :
                                        'bg-amber-500/20 text-amber-400'
                                    }>
                                        {timeframe.success_probability}% Success Rate
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Overall</p>
                                        <p className={`text-2xl font-bold ${getRatingColor(timeframe.predicted_overall)}`}>
                                            {timeframe.predicted_overall}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Technical</p>
                                        <p className={`text-2xl font-bold ${getRatingColor(timeframe.predicted_technical)}`}>
                                            {timeframe.predicted_technical}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Physical</p>
                                        <p className={`text-2xl font-bold ${getRatingColor(timeframe.predicted_physical)}`}>
                                            {timeframe.predicted_physical}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Mental</p>
                                        <p className={`text-2xl font-bold ${getRatingColor(timeframe.predicted_mental)}`}>
                                            {timeframe.predicted_mental}
                                        </p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1">Tactical</p>
                                        <p className={`text-2xl font-bold ${getRatingColor(timeframe.predicted_tactical)}`}>
                                            {timeframe.predicted_tactical}
                                        </p>
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-4">
                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                                        <p className="text-emerald-400 font-semibold text-sm mb-2">Key Developments</p>
                                        <ul className="space-y-1">
                                            {timeframe.key_developments?.map((dev, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-emerald-400">✓</span>
                                                    {dev}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                                        <p className="text-amber-400 font-semibold text-sm mb-2">Potential Risks</p>
                                        <ul className="space-y-1">
                                            {timeframe.risks?.map((risk, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400">⚠</span>
                                                    {risk}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                                    <span className="text-slate-400 text-sm">Market Value:</span>
                                    <span className="text-emerald-400 font-semibold">{timeframe.market_value_change}</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}

                    {/* Path Comparison */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Alternative Path Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {simulation.path_comparison?.map((comparison, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <h4 className="text-white font-semibold mb-2">{comparison.alternative_path}</h4>
                                        <p className="text-slate-300 text-sm mb-2">{comparison.outcome_difference}</p>
                                        <p className="text-cyan-400 text-sm">{comparison.recommendation}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Critical Factors */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">Critical Success Factors</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex flex-wrap gap-2">
                                {simulation.critical_factors?.map((factor, idx) => (
                                    <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                        {factor}
                                    </Badge>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Exit Strategies */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-red-400 flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5" />
                                Exit Strategies
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {simulation.exit_strategies?.map((strategy, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-red-400 font-semibold text-sm mb-1">{strategy.scenario}</p>
                                        <p className="text-slate-300 text-sm">{strategy.action}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Overall Recommendation */}
                    <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">AI Recommendation</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-white leading-relaxed">
                                {simulation.overall_recommendation}
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!simulation && !isSimulating && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12">
                        <div className="text-center">
                            <GitBranch className="w-16 h-16 text-purple-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Simulate Development Paths</h3>
                            <p className="text-slate-400">
                                Select a player and path to simulate potential outcomes over 6, 12, and 24 months
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}