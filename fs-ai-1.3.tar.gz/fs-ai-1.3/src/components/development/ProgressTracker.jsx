import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, TrendingUp, TrendingDown, Minus, Sparkles, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function ProgressTracker({ players, reports, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const trackProgress = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('AI analyzing progress...', { id: 'progress-track' });

        try {
            const player = players.find(p => p.id === selectedPlayer);
            const playerReports = reports.filter(r => 
                r.player_name?.toLowerCase() === player.name?.toLowerCase()
            ).sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            if (playerReports.length < 2) {
                toast.error('Need at least 2 reports to track progress', { id: 'progress-track' });
                setIsAnalyzing(false);
                return;
            }

            const prompt = `Analyze the development progress and suggest plan adjustments for this player:

PLAYER: ${player.name} (${player.age}y, ${player.position})

HISTORICAL REPORTS (${playerReports.length} total):
${playerReports.map((r, i) => `
Report ${i + 1} (${new Date(r.created_date).toLocaleDateString()}):
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10
- Physical: ${r.physical_rating}/10
- Mental: ${r.mental_rating}/10
- Tactical: ${r.tactical_rating}/10
- Strengths: ${r.strengths}
- Weaknesses: ${r.weaknesses}
`).join('\n')}

PROJECTION DATA:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Potential: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
- Development Plan: ${JSON.stringify(projection.development_plan)}
` : 'No projection available'}

ANALYZE:
1. Rating trends over time (improving/declining/plateauing)
2. Strengths that have developed
3. Weaknesses that persist
4. Unexpected improvements
5. Areas of concern
6. Compare actual progress vs expected projection
7. Suggest training plan adjustments
8. Predict next 6-month trajectory
9. Risk assessment`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        analysis_period: { type: "string" },
                        overall_trend: {
                            type: "object",
                            properties: {
                                direction: { type: "string" },
                                rating_change: { type: "number" },
                                summary: { type: "string" }
                            }
                        },
                        category_trends: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    category: { type: "string" },
                                    trend: { type: "string" },
                                    change: { type: "number" },
                                    analysis: { type: "string" }
                                }
                            }
                        },
                        strengths_developed: { type: "array", items: { type: "string" } },
                        persistent_weaknesses: { type: "array", items: { type: "string" } },
                        unexpected_improvements: { type: "array", items: { type: "string" } },
                        areas_of_concern: { type: "array", items: { type: "string" } },
                        projection_comparison: {
                            type: "object",
                            properties: {
                                on_track: { type: "boolean" },
                                deviation: { type: "string" },
                                explanation: { type: "string" }
                            }
                        },
                        training_adjustments: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    current_approach: { type: "string" },
                                    suggested_change: { type: "string" },
                                    priority: { type: "string" }
                                }
                            }
                        },
                        six_month_prediction: {
                            type: "object",
                            properties: {
                                predicted_overall: { type: "number" },
                                predicted_technical: { type: "number" },
                                predicted_physical: { type: "number" },
                                predicted_mental: { type: "number" },
                                confidence: { type: "string" },
                                factors: { type: "array", items: { type: "string" } }
                            }
                        },
                        risk_assessment: {
                            type: "object",
                            properties: {
                                level: { type: "string" },
                                factors: { type: "array", items: { type: "string" } },
                                mitigation: { type: "array", items: { type: "string" } }
                            }
                        },
                        recommendations: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis({ ...response, player_data: player, reports: playerReports });
            toast.success('Progress analysis complete!', { id: 'progress-track' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze progress', { id: 'progress-track' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getTrendIcon = (trend) => {
        if (trend?.toLowerCase().includes('improving') || trend?.toLowerCase().includes('upward')) {
            return <TrendingUp className="w-4 h-4 text-emerald-400" />;
        }
        if (trend?.toLowerCase().includes('declining') || trend?.toLowerCase().includes('downward')) {
            return <TrendingDown className="w-4 h-4 text-red-400" />;
        }
        return <Minus className="w-4 h-4 text-slate-400" />;
    };

    const getTrendColor = (trend) => {
        if (trend?.toLowerCase().includes('improving') || trend?.toLowerCase().includes('upward')) {
            return 'text-emerald-400';
        }
        if (trend?.toLowerCase().includes('declining') || trend?.toLowerCase().includes('downward')) {
            return 'text-red-400';
        }
        return 'text-slate-400';
    };

    // Prepare chart data
    const timelineData = analysis?.reports?.map(r => ({
        date: new Date(r.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        Overall: r.overall_rating,
        Technical: r.technical_rating,
        Physical: r.physical_rating,
        Mental: r.mental_rating,
        Tactical: r.tactical_rating
    })) || [];

    const radarData = analysis?.category_trends?.map(t => ({
        category: t.category,
        current: parseFloat(t.change) + 5,
        predicted: analysis.six_month_prediction?.[`predicted_${t.category.toLowerCase()}`] || 5
    })) || [];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                        Progress Tracker & AI Insights
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="flex-1 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select a player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(player => (
                                    <SelectItem key={player.id} value={player.id}>
                                        {player.name} - {player.position} ({player.age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={trackProgress}
                            disabled={isAnalyzing || !selectedPlayer}
                            className="bg-gradient-to-r from-emerald-500 to-cyan-600"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Analyze Progress
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {analysis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Overall Trend */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Overall Development Trend</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-3">
                                    {getTrendIcon(analysis.overall_trend?.direction)}
                                    <span className={`text-2xl font-bold ${getTrendColor(analysis.overall_trend?.direction)}`}>
                                        {analysis.overall_trend?.direction}
                                    </span>
                                </div>
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-lg">
                                    {analysis.overall_trend?.rating_change > 0 ? '+' : ''}{analysis.overall_trend?.rating_change}
                                </Badge>
                            </div>
                            <p className="text-slate-300">{analysis.overall_trend?.summary}</p>
                        </CardContent>
                    </Card>

                    {/* Performance Charts */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Historical Performance</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <LineChart data={timelineData}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                        <XAxis dataKey="date" stroke="#94a3b8" style={{ fontSize: '11px' }} />
                                        <YAxis domain={[0, 10]} stroke="#94a3b8" />
                                        <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                                        <Legend />
                                        <Line type="monotone" dataKey="Overall" stroke="#06b6d4" strokeWidth={2} />
                                        <Line type="monotone" dataKey="Technical" stroke="#8b5cf6" />
                                        <Line type="monotone" dataKey="Physical" stroke="#f59e0b" />
                                        <Line type="monotone" dataKey="Mental" stroke="#10b981" />
                                    </LineChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Current vs 6-Month Prediction</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <RadarChart data={radarData}>
                                        <PolarGrid stroke="#475569" />
                                        <PolarAngleAxis dataKey="category" stroke="#94a3b8" />
                                        <PolarRadiusAxis domain={[0, 10]} stroke="#94a3b8" />
                                        <Radar name="Current" dataKey="current" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                                        <Radar name="Predicted" dataKey="predicted" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                                        <Legend />
                                    </RadarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Category Trends */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Category-Specific Trends</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {analysis.category_trends?.map((trend, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4 className="text-white font-semibold">{trend.category}</h4>
                                            <div className="flex items-center gap-2">
                                                {getTrendIcon(trend.trend)}
                                                <span className={`font-bold ${getTrendColor(trend.trend)}`}>
                                                    {trend.change > 0 ? '+' : ''}{trend.change}
                                                </span>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{trend.analysis}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Projection Comparison */}
                    <Card className={`border ${analysis.projection_comparison?.on_track ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-amber-500/10 border-amber-500/30'}`}>
                        <CardHeader>
                            <CardTitle className={analysis.projection_comparison?.on_track ? 'text-emerald-400' : 'text-amber-400'}>
                                Projection vs Actual Progress
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-3 mb-3">
                                <Badge className={analysis.projection_comparison?.on_track ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}>
                                    {analysis.projection_comparison?.on_track ? 'On Track' : 'Off Track'}
                                </Badge>
                                <span className="text-white font-semibold">{analysis.projection_comparison?.deviation}</span>
                            </div>
                            <p className="text-slate-300">{analysis.projection_comparison?.explanation}</p>
                        </CardContent>
                    </Card>

                    {/* Development Updates */}
                    <div className="grid md:grid-cols-3 gap-6">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 text-sm">Strengths Developed</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.strengths_developed?.map((strength, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400">✓</span>
                                            {strength}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400 text-sm">Persistent Weaknesses</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.persistent_weaknesses?.map((weakness, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-amber-400">⚠</span>
                                            {weakness}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-purple-500/10 border-purple-500/30">
                            <CardHeader>
                                <CardTitle className="text-purple-400 text-sm">Unexpected Improvements</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.unexpected_improvements?.map((improvement, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-purple-400">★</span>
                                            {improvement}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Training Adjustments */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Target className="w-5 h-5 text-cyan-400" />
                                Suggested Training Plan Adjustments
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {analysis.training_adjustments?.map((adjustment, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-2">
                                            <h4 className="text-white font-semibold">{adjustment.area}</h4>
                                            <Badge className={
                                                adjustment.priority?.toLowerCase().includes('high') ? 'bg-red-500/20 text-red-400' :
                                                adjustment.priority?.toLowerCase().includes('medium') ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-cyan-500/20 text-cyan-400'
                                            }>
                                                {adjustment.priority}
                                            </Badge>
                                        </div>
                                        <div className="space-y-2">
                                            <div>
                                                <p className="text-slate-400 text-xs">Current Approach:</p>
                                                <p className="text-slate-300 text-sm">{adjustment.current_approach}</p>
                                            </div>
                                            <div>
                                                <p className="text-cyan-400 text-xs">Suggested Change:</p>
                                                <p className="text-white text-sm font-medium">{adjustment.suggested_change}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* 6-Month Prediction */}
                    <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">6-Month Performance Prediction</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Overall</p>
                                    <p className="text-white text-2xl font-bold">{analysis.six_month_prediction?.predicted_overall}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Technical</p>
                                    <p className="text-purple-400 text-2xl font-bold">{analysis.six_month_prediction?.predicted_technical}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Physical</p>
                                    <p className="text-amber-400 text-2xl font-bold">{analysis.six_month_prediction?.predicted_physical}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Mental</p>
                                    <p className="text-emerald-400 text-2xl font-bold">{analysis.six_month_prediction?.predicted_mental}</p>
                                </div>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Confidence: <span className="text-white font-semibold">{analysis.six_month_prediction?.confidence}</span></p>
                                <p className="text-slate-400 text-sm mb-2">Key Factors:</p>
                                <div className="flex flex-wrap gap-2">
                                    {analysis.six_month_prediction?.factors?.map((factor, i) => (
                                        <Badge key={i} variant="outline" className="text-slate-300">
                                            {factor}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Risk Assessment */}
                    {analysis.risk_assessment && (
                        <Card className="bg-red-500/10 border-red-500/30">
                            <CardHeader>
                                <CardTitle className="text-red-400">Risk Assessment</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <Badge className="bg-red-500/20 text-red-400">
                                    Risk Level: {analysis.risk_assessment.level}
                                </Badge>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Risk Factors:</p>
                                    <ul className="space-y-1">
                                        {analysis.risk_assessment.factors?.map((factor, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-red-400">!</span>
                                                {factor}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Mitigation Strategies:</p>
                                    <ul className="space-y-1">
                                        {analysis.risk_assessment.mitigation?.map((strategy, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400">✓</span>
                                                {strategy}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Recommendations */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">AI Recommendations</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2">
                                {analysis.recommendations?.map((rec, i) => (
                                    <li key={i} className="text-slate-300 flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                                        <span className="text-cyan-400 font-bold">{i + 1}.</span>
                                        {rec}
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!analysis && !isAnalyzing && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12">
                        <div className="text-center">
                            <TrendingUp className="w-16 h-16 text-emerald-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Track Player Development</h3>
                            <p className="text-slate-400">
                                Select a player to analyze historical progress and get AI-driven insights
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}