import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Target, Sparkles, Calendar, TrendingUp, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function TrainingPlanGenerator({ players, projections }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [trainingPlan, setTrainingPlan] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const generatePlan = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        setIsGenerating(true);
        toast.loading('AI generating personalized training plan...', { id: 'training-plan' });

        try {
            const player = players.find(p => p.id === selectedPlayer);
            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            // Fetch player's scouting reports
            const reports = await base44.entities.ScoutingReport.filter({
                player_name: player.name
            });

            const latestReport = reports.sort((a, b) => 
                new Date(b.created_date) - new Date(a.created_date)
            )[0];

            const prompt = `Create a comprehensive, personalized training plan for this player:

PLAYER PROFILE:
Name: ${player.name}
Age: ${player.age}
Position: ${player.position}
Current Market Value: €${player.market_value}M

CURRENT PERFORMANCE:
${latestReport ? `
- Overall Rating: ${latestReport.overall_rating}/10
- Technical: ${latestReport.technical_rating}/10
- Physical: ${latestReport.physical_rating}/10
- Mental: ${latestReport.mental_rating}/10
- Tactical: ${latestReport.tactical_rating}/10
- Strengths: ${latestReport.strengths}
- Weaknesses: ${latestReport.weaknesses}
` : 'No recent reports available'}

FUTURE PROJECTION:
${projection ? `
- Potential Trajectory: ${projection.potential_trajectory}
- Peak Rating Potential: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
- Development Areas: ${JSON.stringify(projection.development_priorities)}
- Risk Factors: ${projection.risk_factors?.join(', ')}
` : 'No projection available'}

PHYSICAL ATTRIBUTES:
${JSON.stringify(player.physical_attributes)}

PLAYING STYLE:
${JSON.stringify(player.playing_style)}

INJURY HISTORY:
Injury Prone Score: ${player.injury_prone_score || 0}/100
Recent Injuries: ${player.injury_history?.length || 0}

CREATE A DETAILED 12-WEEK TRAINING PLAN:
1. Identify 3-5 key development priorities based on weaknesses and projection
2. Design specific training drills for each priority area
3. Set measurable weekly goals
4. Include physical conditioning to prevent injuries
5. Mental and tactical training recommendations
6. Progress checkpoints (weeks 4, 8, 12)
7. Expected improvements in ratings
8. Risk mitigation strategies

Make it actionable, specific, and tailored to this player's unique needs.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        plan_duration: { type: "string" },
                        overview: { type: "string" },
                        development_priorities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    current_level: { type: "number" },
                                    target_level: { type: "number" },
                                    priority: { type: "string" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        weekly_schedule: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    week: { type: "number" },
                                    focus: { type: "string" },
                                    drills: { type: "array", items: { type: "string" } },
                                    goals: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        training_drills: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    drill_name: { type: "string" },
                                    category: { type: "string" },
                                    description: { type: "string" },
                                    duration: { type: "string" },
                                    frequency: { type: "string" },
                                    equipment: { type: "string" }
                                }
                            }
                        },
                        progress_checkpoints: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    week: { type: "number" },
                                    assessment_areas: { type: "array", items: { type: "string" } },
                                    expected_improvements: { type: "string" }
                                }
                            }
                        },
                        injury_prevention: {
                            type: "object",
                            properties: {
                                risk_level: { type: "string" },
                                recommendations: { type: "array", items: { type: "string" } },
                                warm_up_routine: { type: "string" },
                                recovery_protocol: { type: "string" }
                            }
                        },
                        expected_outcomes: {
                            type: "object",
                            properties: {
                                technical_improvement: { type: "string" },
                                physical_improvement: { type: "string" },
                                mental_improvement: { type: "string" },
                                overall_rating_increase: { type: "string" }
                            }
                        },
                        success_indicators: { type: "array", items: { type: "string" } },
                        adjustments_needed: { type: "string" }
                    }
                }
            });

            setTrainingPlan({ ...response, player_data: player });
            toast.success('Training plan generated!', { id: 'training-plan' });
        } catch (error) {
            console.error('Failed to generate plan:', error);
            toast.error('Failed to generate training plan', { id: 'training-plan' });
        } finally {
            setIsGenerating(false);
        }
    };

    const getPriorityColor = (priority) => {
        if (priority?.toLowerCase().includes('critical') || priority?.toLowerCase().includes('high')) {
            return 'bg-red-500/20 text-red-400 border-red-500/30';
        }
        if (priority?.toLowerCase().includes('medium')) {
            return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        }
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        AI Training Plan Generator
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="flex-1 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select a player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(player => (
                                    <SelectItem key={player.id} value={player.id}>
                                        {player.name} - {player.position} ({player.age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={generatePlan}
                            disabled={isGenerating || !selectedPlayer}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isGenerating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Plan
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {trainingPlan && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Overview */}
                    <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-white">Training Plan Overview</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400">Player:</span>
                                <span className="text-white font-semibold">{trainingPlan.player_name}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400">Duration:</span>
                                <Badge className="bg-purple-500/20 text-purple-400">{trainingPlan.plan_duration}</Badge>
                            </div>
                            <p className="text-slate-300 text-sm leading-relaxed">{trainingPlan.overview}</p>
                        </CardContent>
                    </Card>

                    {/* Development Priorities */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Development Priorities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {trainingPlan.development_priorities?.map((priority, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-3">
                                            <h4 className="text-white font-semibold">{priority.area}</h4>
                                            <Badge className={getPriorityColor(priority.priority)}>
                                                {priority.priority}
                                            </Badge>
                                        </div>
                                        <div className="space-y-2 mb-3">
                                            <div className="flex justify-between text-sm">
                                                <span className="text-slate-400">Current Level</span>
                                                <span className="text-amber-400">{priority.current_level}/10</span>
                                            </div>
                                            <div className="flex justify-between text-sm">
                                                <span className="text-slate-400">Target Level</span>
                                                <span className="text-emerald-400">{priority.target_level}/10</span>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{priority.reasoning}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Training Drills */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Training Drills Library</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {trainingPlan.training_drills?.map((drill, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-2">
                                            <div>
                                                <h4 className="text-white font-semibold">{drill.drill_name}</h4>
                                                <Badge className="bg-purple-500/20 text-purple-400 mt-1">
                                                    {drill.category}
                                                </Badge>
                                            </div>
                                            <div className="text-right text-sm">
                                                <p className="text-cyan-400">{drill.duration}</p>
                                                <p className="text-slate-400">{drill.frequency}</p>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm mb-2">{drill.description}</p>
                                        <p className="text-slate-400 text-xs">Equipment: {drill.equipment}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Weekly Schedule */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Calendar className="w-5 h-5 text-amber-400" />
                                12-Week Schedule
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {trainingPlan.weekly_schedule?.map((week, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center gap-3 mb-3">
                                            <Badge className="bg-cyan-500/20 text-cyan-400">Week {week.week}</Badge>
                                            <h4 className="text-white font-semibold">{week.focus}</h4>
                                        </div>
                                        <div className="grid md:grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-slate-400 text-sm font-semibold mb-2">Drills:</p>
                                                <ul className="space-y-1">
                                                    {week.drills?.map((drill, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-cyan-400">•</span>
                                                            {drill}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 text-sm font-semibold mb-2">Goals:</p>
                                                <ul className="space-y-1">
                                                    {week.goals?.map((goal, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-emerald-400">✓</span>
                                                            {goal}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Progress Checkpoints */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-emerald-400" />
                                Progress Checkpoints
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {trainingPlan.progress_checkpoints?.map((checkpoint, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <h4 className="text-emerald-400 font-semibold mb-2">Week {checkpoint.week} Assessment</h4>
                                        <div className="mb-3">
                                            <p className="text-slate-400 text-sm mb-1">Areas to Assess:</p>
                                            <div className="flex flex-wrap gap-2">
                                                {checkpoint.assessment_areas?.map((area, i) => (
                                                    <Badge key={i} variant="outline" className="text-slate-300">
                                                        {area}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{checkpoint.expected_improvements}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Injury Prevention */}
                    <Card className="bg-amber-500/10 border-amber-500/30">
                        <CardHeader>
                            <CardTitle className="text-amber-400 flex items-center gap-2">
                                <AlertCircle className="w-5 h-5" />
                                Injury Prevention Protocol
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Risk Level:</p>
                                <Badge className="bg-amber-500/20 text-amber-400">
                                    {trainingPlan.injury_prevention?.risk_level}
                                </Badge>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm font-semibold mb-2">Recommendations:</p>
                                <ul className="space-y-1">
                                    {trainingPlan.injury_prevention?.recommendations?.map((rec, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-amber-400">⚠</span>
                                            {rec}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-white font-semibold text-sm mb-1">Warm-Up Routine</p>
                                    <p className="text-slate-300 text-sm">{trainingPlan.injury_prevention?.warm_up_routine}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-white font-semibold text-sm mb-1">Recovery Protocol</p>
                                    <p className="text-slate-300 text-sm">{trainingPlan.injury_prevention?.recovery_protocol}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Expected Outcomes */}
                    <Card className="bg-emerald-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Expected Outcomes (12 Weeks)</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="grid md:grid-cols-2 gap-4">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-sm">Technical</p>
                                    <p className="text-white font-semibold">{trainingPlan.expected_outcomes?.technical_improvement}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-sm">Physical</p>
                                    <p className="text-white font-semibold">{trainingPlan.expected_outcomes?.physical_improvement}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-sm">Mental</p>
                                    <p className="text-white font-semibold">{trainingPlan.expected_outcomes?.mental_improvement}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-sm">Overall Rating</p>
                                    <p className="text-emerald-400 font-semibold text-lg">{trainingPlan.expected_outcomes?.overall_rating_increase}</p>
                                </div>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm font-semibold mb-2">Success Indicators:</p>
                                <ul className="space-y-1">
                                    {trainingPlan.success_indicators?.map((indicator, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400">✓</span>
                                            {indicator}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Adjustments */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Plan Adjustments & Flexibility</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 text-sm leading-relaxed">
                                {trainingPlan.adjustments_needed}
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!trainingPlan && !isGenerating && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12">
                        <div className="text-center">
                            <Target className="w-16 h-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Generate Your First Training Plan</h3>
                            <p className="text-slate-400">
                                Select a player and let AI create a personalized 12-week development program
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}