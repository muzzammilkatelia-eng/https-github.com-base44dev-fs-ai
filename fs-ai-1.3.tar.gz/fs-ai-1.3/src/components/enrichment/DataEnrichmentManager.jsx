import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, RefreshCw, AlertCircle, CheckCircle2, Layers, Database } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function DataEnrichmentManager({ player }) {
    const queryClient = useQueryClient();
    const [enrichmentSources, setEnrichmentSources] = useState({
        transfermarkt: true,
        wyscout: true,
        fbref: false
    });
    const [enriching, setEnriching] = useState(false);
    const [mergeStrategy, setMergeStrategy] = useState('intelligent');

    const enrichPlayer = async () => {
        setEnriching(true);
        toast.loading('Enriching player data...', { id: 'enrich' });

        try {
            const sources = Object.entries(enrichmentSources)
                .filter(([_, enabled]) => enabled)
                .map(([source]) => source);

            const prompt = `You are a football data enrichment AI. Enrich the player profile with comprehensive data from ${sources.join(', ')}.

PLAYER: ${player.name}
AGE: ${player.age}
POSITION: ${player.position}
CLUB: ${player.current_club}
NATIONALITY: ${player.nationality}

ENRICHMENT SOURCES: ${sources.join(', ')}

Provide detailed, realistic data for:

1. **Injury History**: Recent injuries with dates, severity, recovery time
2. **Disciplinary Record**: Yellow/red cards by season, notable incidents
3. **Career History**: Season-by-season stats with clubs, leagues, appearances, goals, assists
4. **Awards & Honours**: Individual awards and team trophies with years
5. **Physical Attributes**: Height, weight, pace, strength ratings
6. **Playing Style**: Preferred foot, work rate, tactical tendencies

Return comprehensive, realistic data as if scraped from ${sources.join(' and ')}.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        injury_history: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    injury_type: { type: "string" },
                                    date: { type: "string" },
                                    severity: { type: "string", enum: ["Minor", "Moderate", "Serious", "Severe"] },
                                    recovery_time: { type: "string" },
                                    notes: { type: "string" }
                                }
                            }
                        },
                        injury_prone_score: {
                            type: "number",
                            minimum: 0,
                            maximum: 100
                        },
                        disciplinary_record: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    season: { type: "string" },
                                    competition: { type: "string" },
                                    yellow_cards: { type: "number" },
                                    red_cards: { type: "number" },
                                    suspensions: { type: "number" },
                                    notable_incidents: {
                                        type: "array",
                                        items: {
                                            type: "object",
                                            properties: {
                                                date: { type: "string" },
                                                incident: { type: "string" },
                                                punishment: { type: "string" }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        career_history: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    season: { type: "string" },
                                    club: { type: "string" },
                                    league: { type: "string" },
                                    appearances: { type: "number" },
                                    goals: { type: "number" },
                                    assists: { type: "number" },
                                    minutes_played: { type: "number" },
                                    transfer_type: { type: "string" },
                                    transfer_fee: { type: "number" }
                                }
                            }
                        },
                        awards_honours: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    award_name: { type: "string" },
                                    year: { type: "string" },
                                    competition: { type: "string" },
                                    award_type: { type: "string" },
                                    description: { type: "string" }
                                }
                            }
                        },
                        physical_attributes: {
                            type: "object",
                            properties: {
                                height: { type: "number" },
                                weight: { type: "number" },
                                pace: { type: "number" },
                                strength: { type: "number" },
                                stamina: { type: "number" }
                            }
                        },
                        playing_style: {
                            type: "object",
                            properties: {
                                attacking_style: { type: "string" },
                                defensive_style: { type: "string" },
                                work_rate: { type: "string" },
                                preferred_foot: { type: "string" }
                            }
                        },
                        data_sources: {
                            type: "array",
                            items: { type: "string" }
                        },
                        last_enriched: { type: "string" }
                    }
                }
            });

            // Merge strategy
            let mergedData = { ...response };
            mergedData.last_enriched = new Date().toISOString();
            mergedData.data_sources = sources;

            if (mergeStrategy === 'intelligent') {
                // Intelligent merge: keep existing data if present, add new data
                if (player.injury_history?.length > 0) {
                    mergedData.injury_history = [...player.injury_history, ...response.injury_history];
                }
                if (player.career_history?.length > 0) {
                    mergedData.career_history = [...player.career_history, ...response.career_history];
                }
                if (player.awards_honours?.length > 0) {
                    mergedData.awards_honours = [...player.awards_honours, ...response.awards_honours];
                }
            } else if (mergeStrategy === 'overwrite') {
                // Use new data completely
            } else {
                // Keep existing data, only add if fields are empty
                Object.keys(mergedData).forEach(key => {
                    if (player[key]) {
                        delete mergedData[key];
                    }
                });
            }

            await base44.entities.Player.update(player.id, mergedData);
            queryClient.invalidateQueries({ queryKey: ['players'] });
            
            toast.success(`Enriched ${player.name} with data from ${sources.join(', ')}!`, { id: 'enrich' });
        } catch (error) {
            console.error('Enrichment failed:', error);
            toast.error('Failed to enrich player data', { id: 'enrich' });
        } finally {
            setEnriching(false);
        }
    };

    const enrichmentStatus = {
        injury_history: player.injury_history?.length > 0,
        disciplinary_record: player.disciplinary_record?.length > 0,
        career_history: player.career_history?.length > 0,
        awards_honours: player.awards_honours?.length > 0,
        physical_attributes: !!player.physical_attributes,
        playing_style: !!player.playing_style
    };

    const completeness = (Object.values(enrichmentStatus).filter(Boolean).length / Object.keys(enrichmentStatus).length) * 100;

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Layers className="w-5 h-5 text-purple-400" />
                        Data Enrichment - {player.name}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* Completeness */}
                    <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-semibold">Profile Completeness</span>
                            <Badge className="bg-purple-500/20 text-purple-400">
                                {completeness.toFixed(0)}%
                            </Badge>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-3">
                            <div 
                                className="bg-gradient-to-r from-purple-500 to-cyan-500 h-3 rounded-full transition-all duration-500"
                                style={{ width: `${completeness}%` }}
                            />
                        </div>
                    </div>

                    {/* Data Sources */}
                    <div>
                        <h4 className="text-white font-semibold mb-3">Enable Data Sources</h4>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <Database className="w-5 h-5 text-amber-400" />
                                    <div>
                                        <p className="text-white font-medium">Transfermarkt</p>
                                        <p className="text-slate-400 text-xs">Market values, transfers, detailed stats</p>
                                    </div>
                                </div>
                                <Switch
                                    checked={enrichmentSources.transfermarkt}
                                    onCheckedChange={(checked) => 
                                        setEnrichmentSources(prev => ({ ...prev, transfermarkt: checked }))
                                    }
                                />
                            </div>

                            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <Database className="w-5 h-5 text-cyan-400" />
                                    <div>
                                        <p className="text-white font-medium">Wyscout</p>
                                        <p className="text-slate-400 text-xs">Professional scouting data, events</p>
                                    </div>
                                </div>
                                <Switch
                                    checked={enrichmentSources.wyscout}
                                    onCheckedChange={(checked) => 
                                        setEnrichmentSources(prev => ({ ...prev, wyscout: checked }))
                                    }
                                />
                            </div>

                            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <Database className="w-5 h-5 text-emerald-400" />
                                    <div>
                                        <p className="text-white font-medium">FBref</p>
                                        <p className="text-slate-400 text-xs">Advanced statistics, analytics</p>
                                    </div>
                                </div>
                                <Switch
                                    checked={enrichmentSources.fbref}
                                    onCheckedChange={(checked) => 
                                        setEnrichmentSources(prev => ({ ...prev, fbref: checked }))
                                    }
                                />
                            </div>
                        </div>
                    </div>

                    {/* Merge Strategy */}
                    <div>
                        <label className="text-white font-semibold mb-3 block">Merge Strategy</label>
                        <Select value={mergeStrategy} onValueChange={setMergeStrategy}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="intelligent">
                                    Intelligent Merge (Combine existing + new)
                                </SelectItem>
                                <SelectItem value="overwrite">
                                    Overwrite (Replace all with new data)
                                </SelectItem>
                                <SelectItem value="preserve">
                                    Preserve (Only fill empty fields)
                                </SelectItem>
                            </SelectContent>
                        </Select>
                        <p className="text-slate-500 text-xs mt-2">
                            {mergeStrategy === 'intelligent' && 'Combines existing data with new enrichment data'}
                            {mergeStrategy === 'overwrite' && 'Replaces all existing data with new enrichment'}
                            {mergeStrategy === 'preserve' && 'Only adds data to empty fields'}
                        </p>
                    </div>

                    {/* Current Status */}
                    <div>
                        <h4 className="text-white font-semibold mb-3">Data Availability</h4>
                        <div className="grid md:grid-cols-2 gap-3">
                            {Object.entries(enrichmentStatus).map(([field, available]) => (
                                <div key={field} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                                    <span className="text-slate-300 text-sm capitalize">
                                        {field.replace(/_/g, ' ')}
                                    </span>
                                    {available ? (
                                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                    ) : (
                                        <AlertCircle className="w-5 h-5 text-slate-600" />
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>

                    <Button
                        onClick={enrichPlayer}
                        disabled={enriching || Object.values(enrichmentSources).every(v => !v)}
                        className="w-full bg-gradient-to-r from-purple-500 to-cyan-600 hover:from-purple-400 hover:to-cyan-500"
                        size="lg"
                    >
                        {enriching ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                Enriching Data...
                            </>
                        ) : (
                            <>
                                <RefreshCw className="w-5 h-5 mr-2" />
                                Enrich Player Profile
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {player.last_enriched && (
                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-3">
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                            <div className="flex-1">
                                <p className="text-emerald-400 font-semibold">Last Enriched</p>
                                <p className="text-slate-300 text-sm">
                                    {new Date(player.last_enriched).toLocaleString()}
                                </p>
                                {player.data_sources && (
                                    <p className="text-slate-400 text-xs mt-1">
                                        Sources: {player.data_sources.join(', ')}
                                    </p>
                                )}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}