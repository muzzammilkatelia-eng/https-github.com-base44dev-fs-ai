import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MapPin, Users, TrendingUp } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

function MapController({ center }) {
    const map = useMap();
    useEffect(() => {
        map.setView(center, 6);
    }, [center, map]);
    return null;
}

export default function CountryMap({ country, onBack, players = [] }) {
    const [selectedRegion, setSelectedRegion] = useState(null);
    
    // UK/England configuration - Premier League & Championship focus
    const ukConfig = {
        center: [54.5, -2.0],
        zoom: 6,
        regions: [
            {
                name: 'Manchester',
                lat: 53.4808,
                lng: -2.2426,
                players: 68,
                avgScore: 88,
                clubs: ['Man City (7x PL)', 'Man United (13x PL)'],
                topTalent: [
                    { name: 'Cole Palmer', age: 21, position: 'CAM', club: 'Man City Academy → Chelsea', score: 89 },
                    { name: 'Kobbie Mainoo', age: 19, position: 'CM', club: 'Man United Academy', score: 86 },
                    { name: 'Alejandro Garnacho', age: 20, position: 'Winger', club: 'Man United', score: 84 }
                ]
            },
            {
                name: 'London',
                lat: 51.5074,
                lng: -0.1278,
                players: 92,
                avgScore: 85,
                clubs: ['Arsenal (3x PL)', 'Chelsea (5x PL)', 'Tottenham', 'West Ham', 'Crystal Palace', 'Fulham', 'Brentford'],
                topTalent: [
                    { name: 'Bukayo Saka', age: 23, position: 'Winger', club: 'Arsenal', score: 91 },
                    { name: 'Levi Colwill', age: 21, position: 'CB', club: 'Chelsea', score: 86 },
                    { name: 'Emile Smith Rowe', age: 24, position: 'CAM', club: 'Arsenal → Fulham', score: 83 }
                ]
            },
            {
                name: 'Liverpool',
                lat: 53.4084,
                lng: -2.9916,
                players: 47,
                avgScore: 87,
                clubs: ['Liverpool (1x PL)', 'Everton'],
                topTalent: [
                    { name: 'Trent Alexander-Arnold', age: 26, position: 'RB', club: 'Liverpool', score: 90 },
                    { name: 'Curtis Jones', age: 23, position: 'CM', club: 'Liverpool', score: 85 },
                    { name: 'Jarell Quansah', age: 21, position: 'CB', club: 'Liverpool', score: 82 }
                ]
            },
            {
                name: 'Leicester',
                lat: 52.6369,
                lng: -1.1398,
                players: 34,
                avgScore: 81,
                clubs: ['Leicester City (1x PL)', 'Leicester (Championship)'],
                topTalent: [
                    { name: 'Kiernan Dewsbury-Hall', age: 26, position: 'CM', club: 'Leicester → Chelsea', score: 83 },
                    { name: 'Luke Thomas', age: 23, position: 'LB', club: 'Leicester', score: 79 }
                ]
            },
            {
                name: 'Brighton',
                lat: 50.8429,
                lng: -0.1313,
                players: 41,
                avgScore: 84,
                clubs: ['Brighton & Hove Albion'],
                topTalent: [
                    { name: 'Evan Ferguson', age: 20, position: 'Striker', club: 'Brighton', score: 86 },
                    { name: 'Facundo Buonanotte', age: 19, position: 'CAM', club: 'Brighton', score: 82 },
                    { name: 'James Milner', age: 38, position: 'CM', club: 'Brighton', score: 78 }
                ]
            },
            {
                name: 'Newcastle',
                lat: 54.9783,
                lng: -1.6178,
                players: 39,
                avgScore: 83,
                clubs: ['Newcastle United', 'Sunderland (Championship)'],
                topTalent: [
                    { name: 'Anthony Gordon', age: 23, position: 'Winger', club: 'Newcastle', score: 85 },
                    { name: 'Lewis Miley', age: 18, position: 'CM', club: 'Newcastle Academy', score: 81 }
                ]
            },
            {
                name: 'Southampton',
                lat: 50.9097,
                lng: -1.4044,
                players: 36,
                avgScore: 82,
                clubs: ['Southampton'],
                topTalent: [
                    { name: 'Tyler Dibling', age: 18, position: 'Winger', club: 'Southampton Academy', score: 84 },
                    { name: 'James Bree', age: 26, position: 'RB', club: 'Southampton', score: 79 }
                ]
            },
            {
                name: 'Nottingham',
                lat: 52.9548,
                lng: -1.1581,
                players: 28,
                avgScore: 78,
                clubs: ['Nottingham Forest'],
                topTalent: [
                    { name: 'Morgan Gibbs-White', age: 24, position: 'CAM', club: 'Nottingham Forest', score: 82 }
                ]
            },
            {
                name: 'Leeds',
                lat: 53.8008,
                lng: -1.5491,
                players: 31,
                avgScore: 80,
                clubs: ['Leeds United (Championship)'],
                topTalent: [
                    { name: 'Archie Gray', age: 18, position: 'CM', club: 'Leeds → Tottenham', score: 83 },
                    { name: 'Joe Gelhardt', age: 22, position: 'Striker', club: 'Leeds', score: 78 }
                ]
            },
            {
                name: 'West Midlands',
                lat: 52.4862,
                lng: -1.8904,
                players: 44,
                avgScore: 81,
                clubs: ['Aston Villa', 'Wolves', 'West Brom (Championship)', 'Birmingham (Championship)'],
                topTalent: [
                    { name: 'Jacob Ramsey', age: 23, position: 'CM', club: 'Aston Villa', score: 84 },
                    { name: 'Matty Cash', age: 27, position: 'RB', club: 'Aston Villa', score: 81 }
                ]
            }
        ]
    };

    const config = country === 'United Kingdom' || country === 'England' ? ukConfig : ukConfig;

    const getMarkerColor = (avgScore) => {
        if (avgScore >= 85) return '#10b981'; // emerald
        if (avgScore >= 80) return '#3b82f6'; // blue
        if (avgScore >= 75) return '#f59e0b'; // amber
        return '#ef4444'; // red
    };

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute inset-0 z-20 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950"
        >
            {/* Header */}
            <div className="absolute top-6 left-6 right-6 z-30 flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Button
                        onClick={onBack}
                        className="bg-slate-900/80 backdrop-blur-xl border border-cyan-500/30 hover:bg-slate-800"
                    >
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Globe
                    </Button>
                    <div className="bg-slate-900/80 backdrop-blur-xl border border-cyan-500/30 rounded-xl px-6 py-3">
                        <h2 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                            {country} Talent Map
                        </h2>
                        <p className="text-slate-400 text-xs mt-1">Regional talent distribution</p>
                    </div>
                </div>

                <div className="bg-slate-900/80 backdrop-blur-xl border border-cyan-500/30 rounded-xl px-4 py-2">
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                            <Users className="w-4 h-4 text-cyan-400" />
                            <span className="text-white font-semibold">
                                {config.regions.reduce((sum, r) => sum + r.players, 0)}
                            </span>
                            <span className="text-slate-400 text-sm">Players</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-purple-400" />
                            <span className="text-white font-semibold">{config.regions.length}</span>
                            <span className="text-slate-400 text-sm">Regions</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Map */}
            <div className="absolute inset-0 pt-24">
                <MapContainer
                    center={config.center}
                    zoom={config.zoom}
                    style={{ height: '100%', width: '100%' }}
                    className="z-10"
                >
                    <MapController center={config.center} />
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />

                    {config.regions.map((region, idx) => (
                        <React.Fragment key={idx}>
                            <Circle
                                center={[region.lat, region.lng]}
                                radius={region.players * 300}
                                pathOptions={{
                                    fillColor: getMarkerColor(region.avgScore),
                                    fillOpacity: 0.3,
                                    color: getMarkerColor(region.avgScore),
                                    weight: 2,
                                    opacity: 0.6
                                }}
                            />
                            <Marker
                                position={[region.lat, region.lng]}
                                eventHandlers={{
                                    click: () => setSelectedRegion(region)
                                }}
                            >
                                <Popup>
                                    <div className="text-sm">
                                        <h3 className="font-bold text-slate-900">{region.name}</h3>
                                        <p className="text-slate-600">{region.players} players</p>
                                        <p className="text-blue-600 font-semibold">Avg Score: {region.avgScore}/100</p>
                                    </div>
                                </Popup>
                            </Marker>
                        </React.Fragment>
                    ))}
                </MapContainer>
            </div>

            {/* Legend */}
            <div className="absolute bottom-6 left-6 z-30 bg-slate-900/90 backdrop-blur-xl border border-cyan-500/30 rounded-xl p-4 shadow-lg">
                <h4 className="text-white font-semibold text-sm mb-3">Talent Score</h4>
                <div className="space-y-2">
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-emerald-500"></div>
                        <span className="text-slate-300 text-xs">Elite (85+)</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-blue-500"></div>
                        <span className="text-slate-300 text-xs">High (80-84)</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-amber-500"></div>
                        <span className="text-slate-300 text-xs">Good (75-79)</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-red-500"></div>
                        <span className="text-slate-300 text-xs">Developing (&lt;75)</span>
                    </div>
                </div>
            </div>

            {/* Region Details Panel */}
            {selectedRegion && (
                <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="absolute top-24 right-6 z-30 w-96 max-h-[calc(100vh-200px)] overflow-y-auto"
                >
                    <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between mb-4">
                                <div>
                                    <h3 className="text-white text-xl font-bold">{selectedRegion.name}</h3>
                                    <div className="flex items-center gap-2 mt-1">
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            {selectedRegion.players} Players
                                        </Badge>
                                        <Badge className="bg-blue-500/20 text-blue-400">
                                            Avg {selectedRegion.avgScore}/100
                                        </Badge>
                                    </div>
                                </div>
                                <Button
                                    onClick={() => setSelectedRegion(null)}
                                    variant="ghost"
                                    size="sm"
                                    className="text-slate-400"
                                >
                                    ✕
                                </Button>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <h4 className="text-slate-400 text-xs font-semibold mb-2">Major Clubs</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedRegion.clubs.map((club, idx) => (
                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400 text-xs">
                                                {club}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <h4 className="text-slate-400 text-xs font-semibold mb-2 flex items-center gap-2">
                                        <TrendingUp className="w-3 h-3" />
                                        Top Talent
                                    </h4>
                                    <div className="space-y-2">
                                        {selectedRegion.topTalent.map((player, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-start justify-between mb-1">
                                                    <div>
                                                        <p className="text-white font-semibold text-sm">{player.name}</p>
                                                        <p className="text-slate-400 text-xs">
                                                            {player.position} • {player.age}y
                                                        </p>
                                                    </div>
                                                    <Badge className={
                                                        player.score >= 85 ? 'bg-emerald-500/20 text-emerald-400' :
                                                        player.score >= 80 ? 'bg-blue-500/20 text-blue-400' :
                                                        'bg-amber-500/20 text-amber-400'
                                                    }>
                                                        {player.score}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-500 text-xs">{player.club}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </motion.div>
    );
}