import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Filter, X, SlidersHorizontal } from 'lucide-react';

export default function DataFiltersPanel({ heatmapData, onFilterChange, onClose }) {
    const [filters, setFilters] = React.useState({
        riskLevel: 'all',
        minScore: 0,
        maxScore: 100,
        minPlayers: 0,
        sortBy: 'avgScore',
        sortOrder: 'desc'
    });

    const applyFilters = () => {
        let filtered = [...heatmapData];

        // Risk level filter
        if (filters.riskLevel !== 'all') {
            filtered = filtered.filter(h => h.riskLevel === filters.riskLevel);
        }

        // Score range filter
        filtered = filtered.filter(h => 
            h.avgScore >= filters.minScore && h.avgScore <= filters.maxScore
        );

        // Min players filter
        filtered = filtered.filter(h => h.count >= filters.minPlayers);

        // Sorting
        filtered.sort((a, b) => {
            const aVal = a[filters.sortBy] || 0;
            const bVal = b[filters.sortBy] || 0;
            return filters.sortOrder === 'desc' ? bVal - aVal : aVal - bVal;
        });

        onFilterChange(filtered);
    };

    React.useEffect(() => {
        applyFilters();
    }, [filters]);

    const handleFilterChange = (key, value) => {
        setFilters(prev => ({ ...prev, [key]: value }));
    };

    const resetFilters = () => {
        setFilters({
            riskLevel: 'all',
            minScore: 0,
            maxScore: 100,
            minPlayers: 0,
            sortBy: 'avgScore',
            sortOrder: 'desc'
        });
    };

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Filter className="w-5 h-5 text-cyan-400" />
                        Advanced Filters
                    </CardTitle>
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={onClose}
                        className="text-slate-400 hover:text-white"
                    >
                        <X className="w-4 h-4" />
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Risk Level */}
                <div>
                    <label className="text-slate-400 text-sm mb-2 block">Risk Level</label>
                    <Select value={filters.riskLevel} onValueChange={(val) => handleFilterChange('riskLevel', val)}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700">
                            <SelectItem value="all">All Levels</SelectItem>
                            <SelectItem value="Very Low">Very Low</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                {/* Score Range */}
                <div>
                    <label className="text-slate-400 text-sm mb-2 block">
                        Score Range: {filters.minScore} - {filters.maxScore}
                    </label>
                    <Slider
                        value={[filters.minScore, filters.maxScore]}
                        onValueChange={([min, max]) => {
                            handleFilterChange('minScore', min);
                            handleFilterChange('maxScore', max);
                        }}
                        max={100}
                        step={5}
                        className="mt-2"
                    />
                </div>

                {/* Min Players */}
                <div>
                    <label className="text-slate-400 text-sm mb-2 block">
                        Min Players: {filters.minPlayers}
                    </label>
                    <Slider
                        value={[filters.minPlayers]}
                        onValueChange={([val]) => handleFilterChange('minPlayers', val)}
                        max={50}
                        step={5}
                        className="mt-2"
                    />
                </div>

                {/* Sort By */}
                <div>
                    <label className="text-slate-400 text-sm mb-2 block">Sort By</label>
                    <Select value={filters.sortBy} onValueChange={(val) => handleFilterChange('sortBy', val)}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700">
                            <SelectItem value="avgScore">Average Score</SelectItem>
                            <SelectItem value="count">Player Count</SelectItem>
                            <SelectItem value="valueDelta">Value Delta</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                {/* Sort Order */}
                <div className="flex gap-2">
                    <Button
                        variant={filters.sortOrder === 'desc' ? 'default' : 'outline'}
                        onClick={() => handleFilterChange('sortOrder', 'desc')}
                        className="flex-1"
                    >
                        High to Low
                    </Button>
                    <Button
                        variant={filters.sortOrder === 'asc' ? 'default' : 'outline'}
                        onClick={() => handleFilterChange('sortOrder', 'asc')}
                        className="flex-1"
                    >
                        Low to High
                    </Button>
                </div>

                {/* Reset */}
                <Button
                    variant="outline"
                    onClick={resetFilters}
                    className="w-full border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                >
                    <X className="w-4 h-4 mr-2" />
                    Reset Filters
                </Button>
            </CardContent>
        </Card>
    );
}