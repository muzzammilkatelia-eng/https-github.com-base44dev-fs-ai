import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Crosshair, Activity, Loader2, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

export default function GPSTracker({ onLocationUpdate }) {
    const [isTracking, setIsTracking] = useState(false);
    const [currentLocation, setCurrentLocation] = useState(null);
    const [accuracy, setAccuracy] = useState(null);
    const [watchId, setWatchId] = useState(null);
    const [locationHistory, setLocationHistory] = useState([]);
    const [isMinimized, setIsMinimized] = useState(false);

    // Auto-start tracking on mount
    useEffect(() => {
        const autoStart = setTimeout(() => {
            startTracking();
        }, 1000);

        return () => {
            clearTimeout(autoStart);
            if (watchId) {
                navigator.geolocation.clearWatch(watchId);
            }
        };
    }, []);

    const startTracking = () => {
        if (!navigator.geolocation) {
            toast.error('Geolocation not supported by your browser');
            return;
        }

        toast.loading('Acquiring GPS signal...', { id: 'gps' });

        const options = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        };

        const id = navigator.geolocation.watchPosition(
            (position) => {
                const location = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    altitude: position.coords.altitude,
                    speed: position.coords.speed,
                    heading: position.coords.heading,
                    timestamp: new Date(position.timestamp).toISOString()
                };

                setCurrentLocation(location);
                setAccuracy(position.coords.accuracy);
                setLocationHistory(prev => [...prev, location].slice(-50));
                
                if (onLocationUpdate) {
                    onLocationUpdate(location);
                }

                toast.success('GPS locked', { id: 'gps' });
            },
            (error) => {
                console.error('GPS error:', error);
                toast.error(`GPS error: ${error.message}`, { id: 'gps' });
                setIsTracking(false);
            },
            options
        );

        setWatchId(id);
        setIsTracking(true);
    };

    const stopTracking = () => {
        if (watchId) {
            navigator.geolocation.clearWatch(watchId);
            setWatchId(null);
        }
        setIsTracking(false);
        toast.success('GPS tracking stopped');
    };

    const getOneTimeLocation = () => {
        if (!navigator.geolocation) {
            toast.error('Geolocation not supported');
            return;
        }

        toast.loading('Getting current position...', { id: 'gps-once' });

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const location = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    altitude: position.coords.altitude,
                    timestamp: new Date(position.timestamp).toISOString()
                };

                setCurrentLocation(location);
                setAccuracy(position.coords.accuracy);
                
                if (onLocationUpdate) {
                    onLocationUpdate(location);
                }

                toast.success('Position acquired', { id: 'gps-once' });
            },
            (error) => {
                toast.error(`Error: ${error.message}`, { id: 'gps-once' });
            },
            { enableHighAccuracy: true }
        );
    };

    return (
        <div className="space-y-4">
            <Card className="bg-slate-900/80 backdrop-blur-xl border-cyan-500/30">
                <CardHeader className="cursor-pointer" onClick={() => setIsMinimized(!isMinimized)}>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-cyan-400" />
                            GPS Tracker
                            {isMinimized && currentLocation && (
                                <span className="text-xs text-slate-400 font-mono ml-2">
                                    {currentLocation.lat.toFixed(4)}°, {currentLocation.lng.toFixed(4)}°
                                </span>
                            )}
                        </CardTitle>
                        <div className="flex items-center gap-2">
                            <Badge className={isTracking ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'}>
                                {isTracking ? (
                                    <>
                                        <Activity className="w-3 h-3 mr-1 animate-pulse" />
                                        Live
                                    </>
                                ) : (
                                    'Inactive'
                                )}
                            </Badge>
                            {isMinimized ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronUp className="w-4 h-4 text-slate-400" />}
                        </div>
                    </div>
                </CardHeader>
                {!isMinimized && (
                    <CardContent className="space-y-4">
                    <div className="flex gap-2">
                        {!isTracking ? (
                            <>
                                <Button
                                    onClick={startTracking}
                                    className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
                                >
                                    <Navigation className="w-4 h-4 mr-2" />
                                    Start Tracking
                                </Button>
                                <Button
                                    onClick={getOneTimeLocation}
                                    variant="outline"
                                    className="border-cyan-500/30"
                                >
                                    <Crosshair className="w-4 h-4" />
                                </Button>
                            </>
                        ) : (
                            <Button
                                onClick={stopTracking}
                                className="w-full bg-red-500 hover:bg-red-600"
                            >
                                Stop Tracking
                            </Button>
                        )}
                    </div>

                    <AnimatePresence>
                        {currentLocation && (
                            <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -10 }}
                                className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/20"
                            >
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Latitude</p>
                                        <p className="text-white font-mono text-sm">
                                            {currentLocation.lat.toFixed(6)}°
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Longitude</p>
                                        <p className="text-white font-mono text-sm">
                                            {currentLocation.lng.toFixed(6)}°
                                        </p>
                                    </div>
                                    {currentLocation.altitude && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Altitude</p>
                                            <p className="text-white font-mono text-sm">
                                                {currentLocation.altitude.toFixed(1)}m
                                            </p>
                                        </div>
                                    )}
                                    {accuracy && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Accuracy</p>
                                            <p className="text-cyan-400 font-mono text-sm">
                                                ±{accuracy.toFixed(1)}m
                                            </p>
                                        </div>
                                    )}
                                    {currentLocation.speed !== null && currentLocation.speed > 0 && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Speed</p>
                                            <p className="text-emerald-400 font-mono text-sm">
                                                {(currentLocation.speed * 3.6).toFixed(1)} km/h
                                            </p>
                                        </div>
                                    )}
                                    {currentLocation.heading !== null && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Heading</p>
                                            <p className="text-purple-400 font-mono text-sm">
                                                {currentLocation.heading.toFixed(0)}°
                                            </p>
                                        </div>
                                    )}
                                </div>
                                
                                <div className="mt-3 pt-3 border-t border-slate-700">
                                    <p className="text-slate-500 text-xs">
                                        Updated: {new Date(currentLocation.timestamp).toLocaleTimeString()}
                                    </p>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {isTracking && locationHistory.length > 0 && (
                        <div className="bg-slate-800/30 rounded-lg p-3 border border-slate-700">
                            <div className="flex items-center justify-between mb-2">
                                <p className="text-slate-400 text-xs font-semibold">Tracking History</p>
                                <Badge variant="outline" className="border-cyan-500/30 text-cyan-400">
                                    {locationHistory.length} points
                                </Badge>
                            </div>
                            <div className="space-y-1 max-h-32 overflow-y-auto">
                                {locationHistory.slice(-10).reverse().map((loc, i) => (
                                    <div key={i} className="text-xs text-slate-500 font-mono flex justify-between">
                                        <span>{loc.lat.toFixed(4)}, {loc.lng.toFixed(4)}</span>
                                        <span>{new Date(loc.timestamp).toLocaleTimeString()}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    </CardContent>
                )}
            </Card>
        </div>
    );
}