import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, TrendingUp, AlertCircle, Award, Plus } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import MetricDisplay from '../scouting/MetricDisplay';

export default function HotspotPanel({ hotspot, onClose, onAddToComparison }) {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    
    if (!hotspot) return null;

    return (
        <motion.div
            initial={{ x: 400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 400, opacity: 0 }}
            transition={{ type: 'spring', damping: 25 }}
            className="absolute right-0 top-0 bottom-0 w-full md:w-96 bg-slate-900/95 backdrop-blur-xl border-l border-cyan-500/30 overflow-y-auto z-20"
        >
            <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex items-start justify-between">
                    <div>
                        <h2 className="text-2xl font-bold text-white mb-1">{hotspot.region}</h2>
                        <p className="text-slate-400 text-sm">{hotspot.country}</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors"
                    >
                        <X className="w-4 h-4 text-slate-400" />
                    </button>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-800/50 rounded-lg p-3">
                        <p className="text-slate-400 text-xs mb-1">Players</p>
                        <p className="text-white text-2xl font-bold">{hotspot.count}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3">
                        <p className="text-slate-400 text-xs mb-1">Avg Score</p>
                        <p className="text-cyan-400 text-2xl font-bold">{hotspot.avgScore}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3">
                        <p className="text-slate-400 text-xs mb-1">Risk</p>
                        <p className="text-amber-400 text-2xl font-bold">{hotspot.riskLevel}</p>
                    </div>
                </div>

                {/* Market Intelligence */}
                <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-white text-sm flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-cyan-400" />
                            Market Intelligence
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <MetricDisplay 
                            label="Value Delta" 
                            value={hotspot.valueDelta || 65} 
                            color="emerald" 
                        />
                        <div>
                            <p className="text-slate-400 text-xs mb-1">Market Trajectory</p>
                            <p className="text-white text-sm">{hotspot.trajectory || "Rising - High Demand Expected"}</p>
                        </div>
                    </CardContent>
                </Card>

                {/* Top Players */}
                <div>
                    <h3 className="text-white font-bold mb-3 flex items-center gap-2">
                        <Award className="w-4 h-4 text-amber-400" />
                        Top Talents
                    </h3>
                    <div className="space-y-2">
                        {hotspot.topPlayers?.map((player, index) => (
                            <div
                                key={index}
                                onClick={() => setSelectedPlayer(player)}
                                className="bg-slate-800/50 rounded-lg p-3 hover:bg-slate-800 transition-colors cursor-pointer"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex-1">
                                        <p className="text-white font-semibold">{player.name}</p>
                                        <p className="text-slate-400 text-xs">{player.position} · {player.age} years</p>
                                        {player.market_value && (
                                            <p className="text-amber-400 text-xs font-semibold mt-0.5">€{player.market_value}M</p>
                                        )}
                                        {player.contract_expiry && (
                                            <p className="text-slate-500 text-xs">Contract: {player.contract_expiry}</p>
                                        )}
                                        {player.recent_performance && (
                                            <p className="text-cyan-400 text-xs mt-1 italic">{player.recent_performance}</p>
                                        )}
                                    </div>
                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                        {player.score}/100
                                    </Badge>
                                </div>
                                <div className="flex gap-2 flex-wrap items-center">
                                    {player.tags?.map((tag, i) => (
                                        <span key={i} className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                                            {tag}
                                        </span>
                                    ))}
                                    {onAddToComparison && (
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                onAddToComparison(player);
                                            }}
                                            className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10 h-6 px-2"
                                        >
                                            <Plus className="w-3 h-3 mr-1" />
                                            Compare
                                        </Button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Development Pathway */}
                <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                        <CardTitle className="text-white text-sm flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-amber-400" />
                            Development Pathway
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 text-sm leading-relaxed">
                            {hotspot.pathway || "Strong pipeline from local academies. Recommended for U21 acquisition with 2-3 year development plan before first-team integration."}
                        </p>
                    </CardContent>
                </Card>

                {/* Risk Assessment */}
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                        <div>
                            <p className="text-amber-400 font-semibold text-sm mb-1">Risk Factors</p>
                            <p className="text-slate-300 text-xs leading-relaxed">
                                {hotspot.riskFactors || "Limited senior football exposure. Cultural adaptation required for European leagues. Work permit considerations for some prospects."}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Player Detail Dialog */}
            <Dialog open={!!selectedPlayer} onOpenChange={() => setSelectedPlayer(null)}>
                <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl text-white max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                            {selectedPlayer?.name}
                        </DialogTitle>
                    </DialogHeader>
                    
                    {selectedPlayer && (
                        <div className="space-y-6">
                            {/* Header Info */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-xs mb-1">Position</p>
                                    <p className="text-white font-semibold">{selectedPlayer.position}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-xs mb-1">Age</p>
                                    <p className="text-white font-semibold">{selectedPlayer.age} years</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-xs mb-1">Talent Score</p>
                                    <p className="text-cyan-400 font-bold text-xl">{selectedPlayer.score}/100</p>
                                </div>
                                {selectedPlayer.market_value && (
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Market Value</p>
                                        <p className="text-amber-400 font-semibold">€{selectedPlayer.market_value}M</p>
                                    </div>
                                )}
                            </div>

                            {/* Contract Info */}
                            {selectedPlayer.contract_expiry && (
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-4">
                                        <p className="text-slate-400 text-sm">Contract Expiry</p>
                                        <p className="text-white font-semibold">{selectedPlayer.contract_expiry}</p>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Recent Performance */}
                            {selectedPlayer.recent_performance && (
                                <Card className="bg-cyan-500/10 border-cyan-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-cyan-400 text-sm flex items-center gap-2">
                                            <TrendingUp className="w-4 h-4" />
                                            Recent Performance
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-white">{selectedPlayer.recent_performance}</p>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Player Tags/Attributes */}
                            {selectedPlayer.tags && selectedPlayer.tags.length > 0 && (
                                <div>
                                    <h4 className="text-white font-semibold mb-3">Key Attributes</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedPlayer.tags.map((tag, i) => (
                                            <Badge key={i} className="bg-slate-700 text-slate-200 px-3 py-1">
                                                {tag}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Location Context */}
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm">Location</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-slate-300">{hotspot.region}, {hotspot.country}</p>
                                    <p className="text-slate-400 text-sm mt-2">{hotspot.pathway}</p>
                                </CardContent>
                            </Card>

                            {/* Risk Assessment */}
                            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                <div className="flex items-start gap-3">
                                    <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    <div>
                                        <p className="text-amber-400 font-semibold mb-1">Transfer Considerations</p>
                                        <p className="text-slate-300 text-sm">{hotspot.riskFactors}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </motion.div>
    );
}