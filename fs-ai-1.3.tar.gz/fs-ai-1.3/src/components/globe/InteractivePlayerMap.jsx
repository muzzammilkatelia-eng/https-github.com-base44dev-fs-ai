import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Globe, TrendingUp, MapPin, Users, Filter } from 'lucide-react';
import TalentGlobe from './TalentGlobe';
import CountryMap from './CountryMap';
import { motion } from 'framer-motion';

export default function InteractivePlayerMap({ players = [] }) {
    const [selectedCountry, setSelectedCountry] = useState(null);
    const [filterMode, setFilterMode] = useState('nationality'); // nationality, club_location, origin
    const [selectedRegion, setSelectedRegion] = useState(null);
    const [dataOverlay, setDataOverlay] = useState('density'); // density, market_value, transfers

    // Generate heatmap data based on filter mode
    const heatmapData = useMemo(() => {
        const regionMap = new Map();

        players.forEach(player => {
            let location;
            
            if (filterMode === 'nationality') {
                location = player.nationality;
            } else if (filterMode === 'club_location') {
                location = player.league || player.current_club;
            } else {
                location = player.nationality; // origin/scouting fallback
            }

            if (!location) return;

            if (!regionMap.has(location)) {
                regionMap.set(location, {
                    region: location,
                    count: 0,
                    avgScore: 0,
                    totalValue: 0,
                    players: [],
                    lat: getLatLng(location).lat,
                    lng: getLatLng(location).lng
                });
            }

            const data = regionMap.get(location);
            data.count++;
            data.avgScore += player.fsai_proprietary_score || 0;
            data.totalValue += player.market_value || 0;
            data.players.push(player);
        });

        return Array.from(regionMap.values()).map(data => ({
            ...data,
            avgScore: Math.round(data.avgScore / data.count),
            avgValue: (data.totalValue / data.count).toFixed(1),
            riskLevel: data.count > 20 ? 'High' : data.count > 10 ? 'Medium' : 'Low'
        }));
    }, [players, filterMode]);

    // Get overlay-specific data
    const overlayData = useMemo(() => {
        if (dataOverlay === 'density') return heatmapData;
        
        if (dataOverlay === 'market_value') {
            return heatmapData.map(d => ({
                ...d,
                displayValue: `€${d.totalValue.toFixed(1)}M total`
            })).sort((a, b) => b.totalValue - a.totalValue);
        }

        // Recent transfers (mock - would need transfer data)
        return heatmapData.map(d => ({
            ...d,
            transfers: Math.floor(Math.random() * 10)
        }));
    }, [heatmapData, dataOverlay]);

    // Get top regions for overlay
    const topRegions = overlayData.slice(0, 5);

    return (
        <div className="space-y-6">
            {/* Controls */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="flex flex-wrap gap-4 items-center">
                        <div className="flex items-center gap-2">
                            <Filter className="w-4 h-4 text-cyan-400" />
                            <span className="text-slate-300 text-sm font-medium">Filter by:</span>
                        </div>

                        <Select value={filterMode} onValueChange={setFilterMode}>
                            <SelectTrigger className="w-40 bg-slate-800 border-slate-700">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="nationality">Nationality</SelectItem>
                                <SelectItem value="club_location">Club Location</SelectItem>
                                <SelectItem value="origin">Scouting Origin</SelectItem>
                            </SelectContent>
                        </Select>

                        <div className="h-6 w-px bg-slate-700" />

                        <div className="flex items-center gap-2">
                            <span className="text-slate-300 text-sm font-medium">Overlay:</span>
                        </div>

                        <Select value={dataOverlay} onValueChange={setDataOverlay}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="density">Player Density</SelectItem>
                                <SelectItem value="market_value">Market Value Trends</SelectItem>
                                <SelectItem value="transfers">Recent Activity</SelectItem>
                            </SelectContent>
                        </Select>

                        {selectedCountry && (
                            <Button
                                onClick={() => setSelectedCountry(null)}
                                variant="outline"
                                size="sm"
                                className="border-slate-700"
                            >
                                Reset View
                            </Button>
                        )}
                    </div>
                </CardContent>
            </Card>

            {/* Map View */}
            <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Globe className="w-5 h-5 text-cyan-400" />
                                {selectedCountry ? `${selectedCountry} - Detailed View` : 'Global Player Distribution'}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="h-[600px] bg-slate-950/50 rounded-lg overflow-hidden">
                                {selectedCountry ? (
                                    <CountryMap
                                        country={selectedCountry}
                                        players={heatmapData.find(d => d.region === selectedCountry)?.players || []}
                                        onBack={() => setSelectedCountry(null)}
                                    />
                                ) : (
                                    <TalentGlobe
                                        heatmapData={overlayData}
                                        onHotspotClick={(hotspot) => setSelectedRegion(hotspot)}
                                        onCountryClick={(country) => setSelectedCountry(country)}
                                        selectedLayer={dataOverlay}
                                    />
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Sidebar Stats */}
                <div className="space-y-6">
                    {/* Top Regions */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2 text-sm">
                                <TrendingUp className="w-4 h-4 text-cyan-400" />
                                Top Regions {dataOverlay === 'density' ? '(Players)' : dataOverlay === 'market_value' ? '(Value)' : '(Activity)'}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {topRegions.map((region, idx) => (
                                    <motion.div
                                        key={region.region}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        onClick={() => setSelectedCountry(region.region)}
                                        className="bg-slate-800/50 rounded-lg p-3 cursor-pointer hover:bg-slate-800 transition-all border border-slate-700 hover:border-cyan-500/50"
                                    >
                                        <div className="flex items-center justify-between mb-2">
                                            <h4 className="text-white font-semibold text-sm">{region.region}</h4>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                #{idx + 1}
                                            </Badge>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                            <div>
                                                <p className="text-slate-500">Players</p>
                                                <p className="text-white font-semibold">{region.count}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500">Avg Score</p>
                                                <p className="text-cyan-400 font-semibold">{region.avgScore}/100</p>
                                            </div>
                                        </div>
                                        {dataOverlay === 'market_value' && (
                                            <div className="mt-2 pt-2 border-t border-slate-700">
                                                <p className="text-slate-500 text-xs">Total Value</p>
                                                <p className="text-emerald-400 font-semibold">€{region.totalValue.toFixed(1)}M</p>
                                            </div>
                                        )}
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Selected Region Details */}
                    {selectedRegion && (
                        <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2 text-sm">
                                    <MapPin className="w-4 h-4 text-cyan-400" />
                                    {selectedRegion.region}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="grid grid-cols-2 gap-3">
                                        <div className="bg-slate-900/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-xs mb-1">Total Players</p>
                                            <p className="text-white text-2xl font-bold">{selectedRegion.count}</p>
                                        </div>
                                        <div className="bg-slate-900/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-xs mb-1">Avg Score</p>
                                            <p className="text-cyan-400 text-2xl font-bold">{selectedRegion.avgScore}</p>
                                        </div>
                                    </div>

                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-2">Top Players</p>
                                        <div className="space-y-2">
                                            {selectedRegion.players.slice(0, 5).map(player => (
                                                <div key={player.id} className="flex items-center justify-between">
                                                    <span className="text-white text-xs">{player.name}</span>
                                                    <span className="text-slate-400 text-xs">{player.position}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <Button
                                        onClick={() => setSelectedCountry(selectedRegion.region)}
                                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                                        size="sm"
                                    >
                                        View Details
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Global Stats */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2 text-sm">
                                <Users className="w-4 h-4 text-purple-400" />
                                Global Overview
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Total Players</span>
                                    <span className="text-white font-bold">{players.length}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Regions</span>
                                    <span className="text-white font-bold">{heatmapData.length}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Avg Market Value</span>
                                    <span className="text-emerald-400 font-bold">
                                        €{(players.reduce((sum, p) => sum + (p.market_value || 0), 0) / players.length).toFixed(1)}M
                                    </span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}

// Helper function to get approximate lat/lng for locations
function getLatLng(location) {
    const coords = {
        // Major countries
        'Spain': { lat: 40.4168, lng: -3.7038 },
        'England': { lat: 51.5074, lng: -0.1278 },
        'United Kingdom': { lat: 51.5074, lng: -0.1278 },
        'France': { lat: 48.8566, lng: 2.3522 },
        'Germany': { lat: 52.5200, lng: 13.4050 },
        'Italy': { lat: 41.9028, lng: 12.4964 },
        'Brazil': { lat: -15.7939, lng: -47.8828 },
        'Argentina': { lat: -34.6037, lng: -58.3816 },
        'Portugal': { lat: 38.7223, lng: -9.1393 },
        'Netherlands': { lat: 52.3702, lng: 4.8952 },
        'Belgium': { lat: 50.8503, lng: 4.3517 },
        'Croatia': { lat: 45.8150, lng: 15.9819 },
        'Uruguay': { lat: -34.9011, lng: -56.1645 },
        'Colombia': { lat: 4.7110, lng: -74.0721 },
        'Mexico': { lat: 19.4326, lng: -99.1332 },
        'USA': { lat: 37.0902, lng: -95.7129 },
        'Senegal': { lat: 14.6928, lng: -17.4467 },
        'Nigeria': { lat: 9.0765, lng: 7.3986 },
        'Ghana': { lat: 5.6037, lng: -0.1870 },
        'Japan': { lat: 35.6762, lng: 139.6503 },
        'South Korea': { lat: 37.5665, lng: 126.9780 },
        // Leagues
        'Premier League': { lat: 51.5074, lng: -0.1278 },
        'La Liga': { lat: 40.4168, lng: -3.7038 },
        'Bundesliga': { lat: 52.5200, lng: 13.4050 },
        'Serie A': { lat: 41.9028, lng: 12.4964 },
        'Ligue 1': { lat: 48.8566, lng: 2.3522 }
    };

    return coords[location] || { lat: 0, lng: 0 };
}