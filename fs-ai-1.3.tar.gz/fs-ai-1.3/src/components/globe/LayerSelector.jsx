import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, TrendingUp, Target, Users, FileText, Globe } from 'lucide-react';

export default function LayerSelector({ selectedLayer, onLayerChange }) {
    const layers = [
        { 
            id: 'wonderkids', 
            name: 'Wonderkids (U21)', 
            icon: Sparkles, 
            color: 'from-purple-500 to-pink-600',
            gradient: 'purple'
        },
        { 
            id: 'attackers', 
            name: 'High-Ceiling Attackers', 
            icon: Target, 
            color: 'from-red-500 to-orange-600',
            gradient: 'red'
        },
        { 
            id: 'value', 
            name: 'Market Inefficiencies', 
            icon: TrendingUp, 
            color: 'from-cyan-500 to-blue-600',
            gradient: 'cyan'
        },
        { 
            id: 'pipeline', 
            name: 'South American Pipeline', 
            icon: Globe, 
            color: 'from-emerald-500 to-teal-600',
            gradient: 'emerald'
        },
        { 
            id: 'youth', 
            name: 'Youth Acceleration', 
            icon: Users, 
            color: 'from-amber-500 to-yellow-600',
            gradient: 'amber'
        },
        { 
            id: 'technical', 
            name: 'Technical DNA', 
            icon: FileText, 
            color: 'from-indigo-500 to-purple-600',
            gradient: 'indigo'
        }
    ];

    return (
        <div className="absolute left-0 sm:left-6 top-1/2 transform -translate-y-1/2 z-10 space-y-2">
            {layers.map((layer) => (
                <motion.button
                    key={layer.id}
                    onClick={() => onLayerChange(layer.id)}
                    whileHover={{ scale: 1.05, x: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className={`flex items-center gap-2 sm:gap-3 px-2 sm:px-4 py-2 sm:py-3 rounded-r-xl transition-all group ${
                        selectedLayer === layer.id
                            ? `bg-gradient-to-r ${layer.color} shadow-lg`
                            : 'bg-slate-900/80 backdrop-blur-xl border border-slate-700 hover:border-cyan-500/30'
                    }`}
                >
                    <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center ${
                        selectedLayer === layer.id 
                            ? 'bg-white/20' 
                            : `bg-gradient-to-br ${layer.color}`
                    }`}>
                        <layer.icon className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                    </div>
                    <div className="text-left hidden sm:block">
                        <p className={`text-xs sm:text-sm font-semibold ${
                            selectedLayer === layer.id ? 'text-white' : 'text-slate-300'
                        }`}>
                            {layer.name}
                        </p>
                    </div>
                    {selectedLayer === layer.id && (
                        <motion.div
                            layoutId="activeLayer"
                            className="absolute inset-0 bg-white/10 rounded-r-xl"
                            initial={false}
                        />
                    )}
                </motion.button>
            ))}
        </div>
    );
}