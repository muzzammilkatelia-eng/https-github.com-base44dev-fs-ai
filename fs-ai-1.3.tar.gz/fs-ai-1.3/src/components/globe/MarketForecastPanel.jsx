import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, X, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { base44 } from '@/api/base44Client';

export default function MarketForecastPanel({ regions = [], horizon = 6, onClose }) {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [data, setData] = React.useState(null);

  const runForecast = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('generateMarketForecast', { regions, horizon_months: horizon });
      setData(res.data?.forecast || null);
    } catch (e) {
      setError(e.message || 'Failed to generate forecast');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    runForecast();
  }, []);

  return (
    <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
      <CardHeader className="flex items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-cyan-400" />
          Market Forecast ({horizon}m)
        </CardTitle>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-400 hover:text-white">
          <X className="w-4 h-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading && (
          <div className="flex items-center justify-center py-6 text-slate-400">
            <Loader2 className="w-4 h-4 animate-spin mr-2" />
            Generating forecast from live sources...
          </div>
        )}

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded p-3 text-red-300 text-sm">
            {error}
          </div>
        )}

        {data && (
          <div className="space-y-4">
            <p className="text-slate-300 text-sm leading-relaxed">{data.forecast_summary}</p>

            {/* Hotspots */}
            <div>
              <h4 className="text-cyan-400 text-sm font-semibold mb-2">Emerging Hotspots</h4>
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {data.emerging_hotspots.map((h, i) => (
                  <div key={i} className="bg-slate-800/50 rounded p-3 border border-slate-700">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-white font-semibold">{h.region} · {h.country}</p>
                        <p className="text-slate-400 text-xs">Top: {(h.top_positions || []).join(', ')}</p>
                      </div>
                      <Badge className="bg-emerald-500/20 text-emerald-400">{(h.expected_value_growth_pct || 0).toFixed(0)}%</Badge>
                    </div>
                    <Progress value={Math.min(100, Math.max(0, h.expected_value_growth_pct || 0))} className="h-1.5" />
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="border-slate-600 text-slate-300 text-xs">Conf: {h.confidence || 0}/100</Badge>
                      <Badge className={
                        h.risk_level === 'High' ? 'bg-red-500/20 text-red-400' :
                        h.risk_level === 'Medium' ? 'bg-amber-500/20 text-amber-400' : 'bg-cyan-500/20 text-cyan-400'
                      }>
                        {h.risk_level || 'Medium'}
                      </Badge>
                    </div>
                    {h.trend_reason && <p className="text-slate-400 text-xs mt-2">{h.trend_reason}</p>}
                  </div>
                ))}
              </div>
            </div>

            {/* Undervalued Players */}
            <div>
              <h4 className="text-cyan-400 text-sm font-semibold mb-2">Undervalued Players</h4>
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {data.undervalued_players.map((p, i) => (
                  <div key={i} className="bg-slate-800/50 rounded p-3 border border-slate-700">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-white font-semibold">{p.name} · {p.position} · {p.age}</p>
                      <Badge className="bg-amber-500/20 text-amber-400">{(p.undervaluation_pct || 0).toFixed(0)}% undervalued</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400">Current</span>
                        <p className="text-slate-200 font-semibold">€{p.current_value_eur_m}M</p>
                      </div>
                      <div>
                        <span className="text-slate-400">Fair</span>
                        <p className="text-emerald-400 font-semibold">€{p.fair_value_eur_m}M</p>
                      </div>
                      <div>
                        <span className="text-slate-400">Clubs</span>
                        <p className="text-slate-300">{(p.clubs_interested || []).join(', ') || '—'}</p>
                      </div>
                    </div>
                    {p.rationale && <p className="text-slate-400 text-xs mt-2">{p.rationale}</p>}
                  </div>
                ))}
              </div>
            </div>

            {/* Risks */}
            {data.market_risks?.length > 0 && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded p-3">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-400 text-sm font-semibold">Market Risks</span>
                </div>
                <ul className="list-disc list-inside text-slate-300 text-sm space-y-1">
                  {data.market_risks.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              </div>
            )}

            {/* Methodology */}
            {data.methodology && (
              <p className="text-slate-500 text-xs">Methodology: {data.methodology}</p>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={runForecast} className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10">Refresh</Button>
              <Button onClick={onClose} className="bg-cyan-600 hover:bg-cyan-700">Close</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}