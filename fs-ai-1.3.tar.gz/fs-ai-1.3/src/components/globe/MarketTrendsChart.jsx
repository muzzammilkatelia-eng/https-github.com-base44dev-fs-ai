import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, BarChart3, PieChart as PieIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function MarketTrendsChart({ heatmapData }) {
    // Aggregate data for charts
    const regionData = heatmapData.map(h => ({
        name: h.region,
        players: h.count,
        avgScore: h.avgScore,
        valueDelta: h.valueDelta,
        risk: h.riskLevel
    }));

    const riskDistribution = heatmapData.reduce((acc, h) => {
        const existing = acc.find(item => item.name === h.riskLevel);
        if (existing) {
            existing.value += h.count;
        } else {
            acc.push({ name: h.riskLevel, value: h.count });
        }
        return acc;
    }, []);

    const COLORS = {
        'Very Low': '#10b981',
        'Low': '#06b6d4',
        'Medium': '#f59e0b',
        'High': '#ef4444'
    };

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-cyan-400" />
                    Market Analytics
                </CardTitle>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="trends" className="w-full">
                    <TabsList className="bg-slate-800 border-slate-700">
                        <TabsTrigger value="trends" className="data-[state=active]:bg-cyan-600">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Trends
                        </TabsTrigger>
                        <TabsTrigger value="distribution" className="data-[state=active]:bg-cyan-600">
                            <PieIcon className="w-4 h-4 mr-2" />
                            Risk
                        </TabsTrigger>
                        <TabsTrigger value="value" className="data-[state=active]:bg-cyan-600">
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Value
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="trends" className="mt-4">
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={regionData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                                <YAxis stroke="#94a3b8" fontSize={12} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #06b6d4' }}
                                    labelStyle={{ color: '#fff' }}
                                />
                                <Legend wrapperStyle={{ color: '#94a3b8' }} />
                                <Line type="monotone" dataKey="avgScore" stroke="#06b6d4" strokeWidth={2} name="Avg Score" />
                                <Line type="monotone" dataKey="players" stroke="#10b981" strokeWidth={2} name="Players" />
                            </LineChart>
                        </ResponsiveContainer>
                    </TabsContent>

                    <TabsContent value="distribution" className="mt-4">
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={riskDistribution}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                    outerRadius={100}
                                    fill="#8884d8"
                                    dataKey="value"
                                >
                                    {riskDistribution.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[entry.name] || '#94a3b8'} />
                                    ))}
                                </Pie>
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #06b6d4' }}
                                />
                            </PieChart>
                        </ResponsiveContainer>
                    </TabsContent>

                    <TabsContent value="value" className="mt-4">
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={regionData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                                <YAxis stroke="#94a3b8" fontSize={12} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #06b6d4' }}
                                    labelStyle={{ color: '#fff' }}
                                />
                                <Legend wrapperStyle={{ color: '#94a3b8' }} />
                                <Bar dataKey="valueDelta" fill="#f59e0b" name="Value Delta %" />
                            </BarChart>
                        </ResponsiveContainer>
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}