import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Users, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, ResponsiveContainer } from 'recharts';

export default function PlayerComparison({ selectedPlayers, onRemovePlayer, onClose }) {
    if (selectedPlayers.length === 0) {
        return (
            <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-5 h-5 text-cyan-400" />
                            Player Comparison
                        </CardTitle>
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={onClose}
                            className="text-slate-400 hover:text-white"
                        >
                            <X className="w-4 h-4" />
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="text-center py-8">
                        <Users className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">Select players from hotspots to compare</p>
                    </div>
                </CardContent>
            </Card>
        );
    }

    // Create comparison data for radar chart
    const radarData = [
        { attribute: 'Score', ...selectedPlayers.reduce((acc, p, i) => ({ ...acc, [`player${i}`]: p.score }), {}) },
        { attribute: 'Age Fit', ...selectedPlayers.reduce((acc, p, i) => ({ ...acc, [`player${i}`]: Math.max(0, 100 - (p.age - 18) * 3) }), {}) },
        { attribute: 'Market Value', ...selectedPlayers.reduce((acc, p, i) => ({ ...acc, [`player${i}`]: Math.min(100, (p.market_value || 50)) }), {}) },
        { attribute: 'Potential', ...selectedPlayers.reduce((acc, p, i) => ({ ...acc, [`player${i}`]: p.score + Math.random() * 10 }), {}) },
        { attribute: 'Form', ...selectedPlayers.reduce((acc, p, i) => ({ ...acc, [`player${i}`]: 70 + Math.random() * 30 }), {}) }
    ];

    const PLAYER_COLORS = ['#06b6d4', '#f59e0b', '#10b981', '#8b5cf6'];

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-cyan-400" />
                        Player Comparison ({selectedPlayers.length})
                    </CardTitle>
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={onClose}
                        className="text-slate-400 hover:text-white"
                    >
                        <X className="w-4 h-4" />
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Player Cards */}
                <div className="grid grid-cols-1 gap-3">
                    {selectedPlayers.map((player, index) => (
                        <div key={index} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                            <div className="flex items-center justify-between mb-2">
                                <div>
                                    <p className="text-white font-semibold">{player.name}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                        <Badge variant="outline" className="border-cyan-500/30 text-cyan-400 text-xs">
                                            {player.position}
                                        </Badge>
                                        <span className="text-slate-500 text-xs">{player.age} years</span>
                                    </div>
                                </div>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => onRemovePlayer(index)}
                                    className="text-slate-400 hover:text-red-400"
                                >
                                    <X className="w-4 h-4" />
                                </Button>
                            </div>
                            <div className="grid grid-cols-3 gap-2 text-xs">
                                <div>
                                    <span className="text-slate-400">Score</span>
                                    <p className="text-cyan-400 font-bold">{player.score}/100</p>
                                </div>
                                {player.market_value && (
                                    <div>
                                        <span className="text-slate-400">Value</span>
                                        <p className="text-emerald-400 font-bold">€{player.market_value}M</p>
                                    </div>
                                )}
                                <div>
                                    <span className="text-slate-400">Tags</span>
                                    <p className="text-slate-300">{player.tags?.length || 0}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Radar Chart */}
                {selectedPlayers.length >= 2 && (
                    <div className="mt-4">
                        <h4 className="text-slate-400 text-sm mb-3">Performance Comparison</h4>
                        <ResponsiveContainer width="100%" height={300}>
                            <RadarChart data={radarData}>
                                <PolarGrid stroke="#334155" />
                                <PolarAngleAxis dataKey="attribute" stroke="#94a3b8" fontSize={12} />
                                <PolarRadiusAxis stroke="#94a3b8" fontSize={10} />
                                {selectedPlayers.map((player, index) => (
                                    <Radar
                                        key={index}
                                        name={player.name}
                                        dataKey={`player${index}`}
                                        stroke={PLAYER_COLORS[index]}
                                        fill={PLAYER_COLORS[index]}
                                        fillOpacity={0.3}
                                    />
                                ))}
                                <Legend wrapperStyle={{ color: '#94a3b8', fontSize: '12px' }} />
                            </RadarChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {/* Comparison Matrix */}
                <div className="mt-4">
                    <h4 className="text-slate-400 text-sm mb-3">Head-to-Head</h4>
                    <div className="space-y-2">
                        {selectedPlayers.length >= 2 && (
                            <>
                                <ComparisonRow 
                                    label="Higher Score" 
                                    values={selectedPlayers.map(p => p.score)}
                                    names={selectedPlayers.map(p => p.name)}
                                />
                                <ComparisonRow 
                                    label="Younger Age" 
                                    values={selectedPlayers.map(p => -p.age)}
                                    names={selectedPlayers.map(p => p.name)}
                                    inverse
                                />
                            </>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function ComparisonRow({ label, values, names, inverse = false }) {
    const maxIndex = values.indexOf(Math.max(...values));
    const minIndex = values.indexOf(Math.min(...values));
    const allEqual = values.every(v => v === values[0]);

    return (
        <div className="flex items-center justify-between bg-slate-800/30 rounded-lg p-2">
            <span className="text-slate-400 text-xs">{label}</span>
            {allEqual ? (
                <Badge variant="outline" className="border-slate-600 text-slate-400">
                    <Minus className="w-3 h-3 mr-1" />
                    Equal
                </Badge>
            ) : (
                <Badge className="bg-emerald-500/20 text-emerald-400">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {names[maxIndex]}
                </Badge>
            )}
        </div>
    );
}