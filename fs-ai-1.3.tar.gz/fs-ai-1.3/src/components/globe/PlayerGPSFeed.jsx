import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Zap, TrendingUp, Heart, Wind, MapPin, Radio, Gauge, AlertTriangle, Brain, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Progress } from '@/components/ui/progress';

export default function PlayerGPSFeed({ onPlayerLocationUpdate }) {
    const [activePlayers, setActivePlayers] = useState([]);
    const [isSimulating, setIsSimulating] = useState(true);
    const [isMinimized, setIsMinimized] = useState(false);

    // Simulate real-time player GPS data
    useEffect(() => {
        if (!isSimulating) return;

        const mockPlayers = [
            { id: 1, name: 'Kylian Mbappé', position: 'FW', team: 'Real Madrid', lat: 40.4530, lng: -3.6883 },
            { id: 2, name: 'Erling Haaland', position: 'ST', team: 'Man City', lat: 53.4831, lng: -2.2004 },
            { id: 3, name: 'Vinicius Jr', position: 'LW', team: 'Real Madrid', lat: 40.4530, lng: -3.6883 },
            { id: 4, name: 'Mohamed Salah', position: 'RW', team: 'Liverpool', lat: 53.4308, lng: -2.9608 },
            { id: 5, name: 'Jude Bellingham', position: 'CM', team: 'Real Madrid', lat: 40.4530, lng: -3.6883 },
            { id: 6, name: 'Bukayo Saka', position: 'RW', team: 'Arsenal', lat: 51.5549, lng: -0.1084 },
            { id: 7, name: 'Phil Foden', position: 'CAM', team: 'Man City', lat: 53.4831, lng: -2.2004 },
            { id: 8, name: 'Lamine Yamal', position: 'RW', team: 'Barcelona', lat: 41.3809, lng: 2.1228 },
            { id: 9, name: 'Pedri', position: 'CM', team: 'Barcelona', lat: 41.3809, lng: 2.1228 },
            { id: 10, name: 'Florian Wirtz', position: 'CAM', team: 'Leverkusen', lat: 51.0379, lng: 7.0027 }
        ];

        const generateMetrics = () => {
            return mockPlayers.map(player => ({
                ...player,
                metrics: {
                    distance: (Math.random() * 3 + 8).toFixed(2), // 8-11 km
                    topSpeed: (Math.random() * 2 + 32).toFixed(1), // 32-34 km/h
                    sprints: Math.floor(Math.random() * 15 + 45), // 45-60 sprints
                    highIntensityRuns: Math.floor(Math.random() * 25 + 80), // 80-105 runs
                    accelerations: Math.floor(Math.random() * 30 + 120), // 120-150
                    decelerations: Math.floor(Math.random() * 30 + 110), // 110-140
                    heartRate: Math.floor(Math.random() * 15 + 165), // 165-180 bpm
                    heartRateAvg: Math.floor(Math.random() * 10 + 155), // 155-165 bpm
                    workload: Math.floor(Math.random() * 150 + 750), // 750-900 AU
                    powerEvents: Math.floor(Math.random() * 20 + 35), // 35-55 events
                    distanceZones: {
                        walking: (Math.random() * 1 + 2).toFixed(1),
                        jogging: (Math.random() * 2 + 3).toFixed(1),
                        running: (Math.random() * 2 + 2).toFixed(1),
                        highSpeed: (Math.random() * 1 + 0.5).toFixed(1),
                        sprint: (Math.random() * 0.5 + 0.3).toFixed(1)
                    },
                    fatigue: Math.floor(Math.random() * 30 + 60), // 60-90%
                    recoveryStatus: ['Optimal', 'Good', 'Moderate', 'Low'][Math.floor(Math.random() * 4)],
                    // Advanced Metrics
                    playerLoad: (Math.random() * 200 + 600).toFixed(1), // 600-800 AU - cumulative mechanical load
                    stressIndex: (Math.random() * 30 + 60).toFixed(1), // 60-90 - physiological stress
                    fatigueScore: (Math.random() * 40 + 30).toFixed(1), // 30-70 - neural and muscular fatigue
                    metabolicPower: (Math.random() * 5 + 15).toFixed(1), // 15-20 W/kg
                    asymmetryIndex: (Math.random() * 8 + 2).toFixed(1), // 2-10% - left/right imbalance
                    explosiveActions: Math.floor(Math.random() * 20 + 40), // 40-60 explosive movements
                    timestamp: new Date().toISOString()
                }
            }));
        };

        // Initial data
        setActivePlayers(generateMetrics());

        // Update every 5 seconds with new data
        const interval = setInterval(() => {
            setActivePlayers(generateMetrics());
            
            // Notify parent component
            if (onPlayerLocationUpdate) {
                const locations = generateMetrics().map(p => ({
                    name: p.name,
                    lat: p.lat + (Math.random() - 0.5) * 0.01,
                    lng: p.lng + (Math.random() - 0.5) * 0.01,
                    metrics: p.metrics
                }));
                onPlayerLocationUpdate(locations);
            }
        }, 5000);

        return () => clearInterval(interval);
    }, [isSimulating]);

    const getRecoveryColor = (status) => {
        const colors = {
            'Optimal': 'bg-emerald-500/20 text-emerald-400',
            'Good': 'bg-cyan-500/20 text-cyan-400',
            'Moderate': 'bg-amber-500/20 text-amber-400',
            'Low': 'bg-red-500/20 text-red-400'
        };
        return colors[status] || colors['Moderate'];
    };

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader className="cursor-pointer" onClick={() => setIsMinimized(!isMinimized)}>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Radio className="w-5 h-5 text-cyan-400 animate-pulse" />
                        Live Player GPS Feed
                        {isMinimized && (
                            <span className="text-xs text-slate-400 font-normal ml-2">
                                {activePlayers.length} players tracking
                            </span>
                        )}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                        <Badge className="bg-red-500/20 text-red-400 animate-pulse">
                            <Activity className="w-3 h-3 mr-1" />
                            {activePlayers.length} LIVE
                        </Badge>
                        {isMinimized ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronUp className="w-4 h-4 text-slate-400" />}
                    </div>
                </div>
            </CardHeader>
            {!isMinimized && (
            <CardContent>
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                    <AnimatePresence>
                        {activePlayers.map((player, index) => (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.05 }}
                                className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20 hover:border-cyan-500/50 transition-all"
                            >
                                {/* Player Header */}
                                <div className="flex items-center justify-between mb-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                                        <div>
                                            <p className="text-white font-semibold text-sm">{player.name}</p>
                                            <div className="flex items-center gap-2">
                                                <Badge variant="outline" className="border-cyan-500/30 text-cyan-400 text-xs">
                                                    {player.position}
                                                </Badge>
                                                <span className="text-slate-500 text-xs">{player.team}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <Badge className={getRecoveryColor(player.metrics.recoveryStatus)}>
                                        {player.metrics.recoveryStatus}
                                    </Badge>
                                </div>

                                {/* Key Metrics Grid */}
                                <div className="grid grid-cols-3 gap-2 mb-3">
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <div className="flex items-center gap-1 mb-1">
                                            <MapPin className="w-3 h-3 text-cyan-400" />
                                            <span className="text-slate-400 text-xs">Distance</span>
                                        </div>
                                        <p className="text-white font-bold text-sm">{player.metrics.distance} km</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <div className="flex items-center gap-1 mb-1">
                                            <Zap className="w-3 h-3 text-amber-400" />
                                            <span className="text-slate-400 text-xs">Top Speed</span>
                                        </div>
                                        <p className="text-amber-400 font-bold text-sm">{player.metrics.topSpeed} km/h</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <div className="flex items-center gap-1 mb-1">
                                            <Heart className="w-3 h-3 text-red-400" />
                                            <span className="text-slate-400 text-xs">HR</span>
                                        </div>
                                        <p className="text-red-400 font-bold text-sm">{player.metrics.heartRate} bpm</p>
                                    </div>
                                </div>

                                {/* Detailed Stats */}
                                <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Sprints</span>
                                        <span className="text-white font-semibold">{player.metrics.sprints}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">HI Runs</span>
                                        <span className="text-white font-semibold">{player.metrics.highIntensityRuns}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Accelerations</span>
                                        <span className="text-emerald-400 font-semibold">{player.metrics.accelerations}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Decelerations</span>
                                        <span className="text-cyan-400 font-semibold">{player.metrics.decelerations}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Power Events</span>
                                        <span className="text-purple-400 font-semibold">{player.metrics.powerEvents}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-400">Workload</span>
                                        <span className="text-amber-400 font-semibold">{player.metrics.workload} AU</span>
                                    </div>
                                </div>

                                {/* Advanced Analytics */}
                                <div className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 rounded-lg p-3 mb-3 border border-purple-500/30">
                                    <p className="text-purple-300 text-xs font-semibold mb-2 flex items-center gap-1">
                                        <Brain className="w-3 h-3" />
                                        Advanced Analytics
                                    </p>
                                    <div className="grid grid-cols-2 gap-2 text-xs">
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Player Load</span>
                                            <span className="text-purple-400 font-bold">{player.metrics.playerLoad} AU</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Stress Index</span>
                                            <span className="text-orange-400 font-bold">{player.metrics.stressIndex}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Fatigue Score</span>
                                            <span className="text-red-400 font-bold">{player.metrics.fatigueScore}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Metabolic Power</span>
                                            <span className="text-pink-400 font-bold">{player.metrics.metabolicPower} W/kg</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Asymmetry</span>
                                            <span className="text-yellow-400 font-bold">{player.metrics.asymmetryIndex}%</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Explosive</span>
                                            <span className="text-indigo-400 font-bold">{player.metrics.explosiveActions}</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Fatigue Bar */}
                                <div>
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="text-slate-400 text-xs">Energy Level</span>
                                        <span className="text-white text-xs font-semibold">{player.metrics.fatigue}%</span>
                                    </div>
                                    <Progress 
                                        value={player.metrics.fatigue} 
                                        className="h-1.5"
                                    />
                                </div>

                                {/* Timestamp */}
                                <p className="text-slate-600 text-xs mt-2">
                                    Last update: {new Date(player.metrics.timestamp).toLocaleTimeString()}
                                </p>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    </div>
                    </CardContent>
                    )}
                    </Card>
                    );
                    }