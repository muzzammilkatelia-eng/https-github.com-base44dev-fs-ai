import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'framer-motion';

export default function TalentGlobe({ 
    selectedLayer, 
    onHotspotClick,
    onCountryClick,
    heatmapData = [],
    gpsLocation = null
}) {
    const mountRef = useRef(null);
    const [hoveredHotspot, setHoveredHotspot] = useState(null);
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
    const [webglError, setWebglError] = useState(false);
    const sceneRef = useRef(null);
    const cameraRef = useRef(null);
    const rendererRef = useRef(null);
    const globeRef = useRef(null);
    const particlesRef = useRef(null);
    const connectionsRef = useRef(null);
    const isDragging = useRef(false);
    const previousMousePosition = useRef({ x: 0, y: 0 });

    useEffect(() => {
        if (!mountRef.current) return;

        try {
            // Check WebGL support
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (!gl) {
                setWebglError(true);
                return;
            }

            // Scene setup
            const scene = new THREE.Scene();
            sceneRef.current = scene;
            
            const camera = new THREE.PerspectiveCamera(
                45,
                mountRef.current.clientWidth / mountRef.current.clientHeight,
                0.1,
                1000
            );
            camera.position.z = 5;
            cameraRef.current = camera;

            const renderer = new THREE.WebGLRenderer({ 
                antialias: true, 
                alpha: true,
                failIfMajorPerformanceCaveat: false
            });
            
            // Handle context loss
            renderer.domElement.addEventListener('webglcontextlost', (event) => {
                event.preventDefault();
                setWebglError(true);
            }, false);

            renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
            renderer.setClearColor(0x000000, 0);
            mountRef.current.appendChild(renderer.domElement);
            rendererRef.current = renderer;

        // Create globe
        const geometry = new THREE.SphereGeometry(1.5, 64, 64);
        
        // Quantum-level material with advanced shaders
        const material = new THREE.ShaderMaterial({
            uniforms: {
                time: { value: 0 },
                opacity: { value: 0.85 },
                scanlinePosition: { value: 0 }
            },
            vertexShader: `
                varying vec3 vNormal;
                varying vec2 vUv;
                varying vec3 vPosition;
                void main() {
                    vNormal = normalize(normalMatrix * normal);
                    vUv = uv;
                    vPosition = position;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float time;
                uniform float opacity;
                uniform float scanlinePosition;
                varying vec3 vNormal;
                varying vec2 vUv;
                varying vec3 vPosition;
                
                void main() {
                    // Quantum grid with hexagonal pattern
                    float lat = mod(vUv.y * 24.0, 1.0);
                    float lon = mod(vUv.x * 48.0, 1.0);
                    float grid = smoothstep(0.92, 0.98, lat) + smoothstep(0.92, 0.98, lon);
                    
                    // Hexagonal mesh pattern
                    vec2 hex = vec2(vUv.x * 15.0, vUv.y * 15.0 + vUv.x * 7.5);
                    vec2 hexFloor = floor(hex);
                    vec2 hexFract = fract(hex);
                    float hexDist = min(
                        length(hexFract - vec2(0.5)), 
                        min(length(hexFract - vec2(0.0, 0.5)), length(hexFract - vec2(1.0, 0.5)))
                    );
                    float hexPattern = smoothstep(0.45, 0.5, hexDist);
                    
                    // Data flow lines
                    float dataFlow = sin(vUv.x * 20.0 - time * 3.0) * 0.5 + 0.5;
                    dataFlow *= sin(vUv.y * 15.0 + time * 2.0) * 0.5 + 0.5;
                    
                    // Scanning hologram effect
                    float scanline = abs(vPosition.y - scanlinePosition);
                    float scan = exp(-scanline * 8.0) * 0.8;
                    
                    // Energy pulses
                    float pulse1 = sin(time * 3.0 + vUv.x * 10.0) * 0.3 + 0.7;
                    float pulse2 = cos(time * 2.5 + vUv.y * 12.0) * 0.3 + 0.7;
                    
                    // Quantum interference pattern
                    float interference = sin(vUv.x * 30.0 + time) * cos(vUv.y * 30.0 + time * 1.3);
                    interference = pow(abs(interference), 3.0) * 0.3;
                    
                    // Colors - cyan/teal quantum palette
                    vec3 baseColor = vec3(0.0, 0.1, 0.2);
                    vec3 gridColor = vec3(0.0, 0.8, 1.0);
                    vec3 hexColor = vec3(0.0, 0.95, 0.95);
                    vec3 scanColor = vec3(0.0, 1.0, 0.8);
                    vec3 dataColor = vec3(0.4, 0.9, 1.0);
                    
                    // Combine all effects
                    vec3 color = baseColor;
                    color = mix(color, gridColor, grid * 0.4 * pulse1);
                    color = mix(color, hexColor, hexPattern * 0.25 * pulse2);
                    color += scanColor * scan;
                    color += dataColor * dataFlow * 0.15;
                    color += vec3(0.2, 0.6, 1.0) * interference;
                    
                    // Edge glow
                    float fresnel = pow(1.0 - abs(dot(vNormal, vec3(0, 0, 1))), 3.0);
                    color += vec3(0.0, 0.7, 1.0) * fresnel * 0.5;
                    
                    gl_FragColor = vec4(color, opacity);
                }
            `,
            transparent: true,
            side: THREE.DoubleSide
        });

        const globe = new THREE.Mesh(geometry, material);
        scene.add(globe);
        globeRef.current = globe;

        // Load GeoJSON data for world map outlines (continents and countries)
        fetch('https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson')
            .then(response => response.json())
            .then(geojson => {
                const lineMaterial = new THREE.LineBasicMaterial({ 
                    color: 0x00ffff, 
                    transparent: true, 
                    opacity: 0.25 
                });
                
                geojson.features.forEach(feature => {
                    if (feature.geometry.type === 'Polygon') {
                        feature.geometry.coordinates.forEach(coords => {
                            const points = [];
                            coords.forEach(coord => {
                                const lat = coord[1];
                                const lon = coord[0];
                                const phi = (90 - lat) * (Math.PI / 180);
                                const theta = (lon + 180) * (Math.PI / 180);
                                const radius = 1.51; // Slightly larger than globe surface
                                points.push(new THREE.Vector3(
                                    -(radius * Math.sin(phi) * Math.cos(theta)),
                                    radius * Math.cos(phi),
                                    radius * Math.sin(phi) * Math.sin(theta)
                                ));
                            });
                            const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
                            const line = new THREE.LineLoop(lineGeometry, lineMaterial);
                            globe.add(line);
                        });
                    } else if (feature.geometry.type === 'MultiPolygon') {
                        feature.geometry.coordinates.forEach(polygon => {
                            polygon.forEach(coords => {
                                const points = [];
                                coords.forEach(coord => {
                                    const lat = coord[1];
                                    const lon = coord[0];
                                    const phi = (90 - lat) * (Math.PI / 180);
                                    const theta = (lon + 180) * (Math.PI / 180);
                                    const radius = 1.51;
                                    points.push(new THREE.Vector3(
                                        -(radius * Math.sin(phi) * Math.cos(theta)),
                                        radius * Math.cos(phi),
                                        radius * Math.sin(phi) * Math.sin(theta)
                                    ));
                                });
                                const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
                                const line = new THREE.LineLoop(lineGeometry, lineMaterial);
                                globe.add(line);
                            });
                        });
                    }
                });
            })
            .catch(error => console.error('Failed to load world map data:', error));

        // Quantum particle field
        const particleCount = 2000;
        const particleGeometry = new THREE.BufferGeometry();
        const positions = new Float32Array(particleCount * 3);
        const velocities = new Float32Array(particleCount * 3);
        
        for (let i = 0; i < particleCount * 3; i += 3) {
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(Math.random() * 2 - 1);
            const radius = 1.6 + Math.random() * 0.8;
            
            positions[i] = radius * Math.sin(phi) * Math.cos(theta);
            positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
            positions[i + 2] = radius * Math.cos(phi);
            
            velocities[i] = (Math.random() - 0.5) * 0.002;
            velocities[i + 1] = (Math.random() - 0.5) * 0.002;
            velocities[i + 2] = (Math.random() - 0.5) * 0.002;
        }
        
        particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        particleGeometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
        
        const particleMaterial = new THREE.PointsMaterial({
            color: 0x00ffff,
            size: 0.02,
            transparent: true,
            opacity: 0.6,
            blending: THREE.AdditiveBlending
        });
        
        const particles = new THREE.Points(particleGeometry, particleMaterial);
        scene.add(particles);
        particlesRef.current = particles;

        // Quantum network connections between hotspots
        const connectionGroup = new THREE.Group();
        const lineMaterial = new THREE.LineBasicMaterial({
            color: 0x00ffff,
            transparent: true,
            opacity: 0.3,
            linewidth: 2
        });

        // Connect nearby hotspots
        for (let i = 0; i < heatmapData.length; i++) {
            for (let j = i + 1; j < heatmapData.length; j++) {
                const dist = Math.sqrt(
                    Math.pow(heatmapData[i].lat - heatmapData[j].lat, 2) +
                    Math.pow(heatmapData[i].lng - heatmapData[j].lng, 2)
                );
                
                if (dist < 80 && Math.random() > 0.5) {
                    const points = [];
                    const phi1 = (90 - heatmapData[i].lat) * (Math.PI / 180);
                    const theta1 = (heatmapData[i].lng + 180) * (Math.PI / 180);
                    const phi2 = (90 - heatmapData[j].lat) * (Math.PI / 180);
                    const theta2 = (heatmapData[j].lng + 180) * (Math.PI / 180);
                    const radius = 1.53;
                    
                    points.push(new THREE.Vector3(
                        -(radius * Math.sin(phi1) * Math.cos(theta1)),
                        radius * Math.cos(phi1),
                        radius * Math.sin(phi1) * Math.sin(theta1)
                    ));
                    points.push(new THREE.Vector3(
                        -(radius * Math.sin(phi2) * Math.cos(theta2)),
                        radius * Math.cos(phi2),
                        radius * Math.sin(phi2) * Math.sin(theta2)
                    ));
                    
                    const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
                    const line = new THREE.Line(lineGeometry, lineMaterial);
                    connectionGroup.add(line);
                }
            }
        }
        globe.add(connectionGroup);
        connectionsRef.current = connectionGroup;

        // GPS to Player Connections (Neural Network Effect)
        const gpsConnectionGroup = new THREE.Group();
        const gpsLineMaterial = new THREE.LineBasicMaterial({
            color: 0xff00ff,
            transparent: true,
            opacity: 0.5,
            linewidth: 3
        });

        if (gpsLocation) {
            const userHotspot = heatmapData.find(h => h.isUserLocation);
            if (userHotspot) {
                heatmapData.filter(h => !h.isUserLocation).forEach(hotspot => {
                    const points = [];
                    const phi1 = (90 - userHotspot.lat) * (Math.PI / 180);
                    const theta1 = (userHotspot.lng + 180) * (Math.PI / 180);
                    const phi2 = (90 - hotspot.lat) * (Math.PI / 180);
                    const theta2 = (hotspot.lng + 180) * (Math.PI / 180);
                    const radius = 1.53;
                    
                    points.push(new THREE.Vector3(
                        -(radius * Math.sin(phi1) * Math.cos(theta1)),
                        radius * Math.cos(phi1),
                        radius * Math.sin(phi1) * Math.sin(theta1)
                    ));
                    points.push(new THREE.Vector3(
                        -(radius * Math.sin(phi2) * Math.cos(theta2)),
                        radius * Math.cos(phi2),
                        radius * Math.sin(phi2) * Math.sin(theta2)
                    ));
                    
                    const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
                    const line = new THREE.Line(lineGeometry, gpsLineMaterial);
                    gpsConnectionGroup.add(line);
                });
            }
        }
        globe.add(gpsConnectionGroup);

        // Enhanced hotspot markers with pulse effect
        const hotspotGeometry = new THREE.SphereGeometry(0.04, 16, 16);

        heatmapData.forEach((hotspot, index) => {
            // Main marker - special handling for GPS and Player locations
            const isGPS = hotspot.riskLevel === 'GPS' || hotspot.isUserLocation;
            const isPlayer = hotspot.riskLevel === 'Player' || hotspot.isPlayerGPS;
            const markerMaterial = new THREE.MeshBasicMaterial({ 
                color: isGPS ? 0xff00ff :
                       isPlayer ? 0x00ffff :
                       hotspot.riskLevel === 'Low' ? 0x00ff88 : 
                       hotspot.riskLevel === 'Medium' ? 0xffaa00 : 0xff3366,
                transparent: true,
                opacity: 0.9
            });
            const marker = new THREE.Mesh(hotspotGeometry, markerMaterial);
            
            // Pulse ring
            const ringGeometry = new THREE.RingGeometry(0.05, 0.08, 32);
            const ringMaterial = new THREE.MeshBasicMaterial({
                color: markerMaterial.color,
                transparent: true,
                opacity: 0.4,
                side: THREE.DoubleSide
            });
            const ring = new THREE.Mesh(ringGeometry, ringMaterial);
            
            const phi = (90 - hotspot.lat) * (Math.PI / 180);
            const theta = (hotspot.lng + 180) * (Math.PI / 180);
            const radius = 1.53;

            marker.position.x = -(radius * Math.sin(phi) * Math.cos(theta));
            marker.position.y = radius * Math.cos(phi);
            marker.position.z = radius * Math.sin(phi) * Math.sin(theta);
            
            ring.position.copy(marker.position);
            ring.lookAt(0, 0, 0);
            ring.rotateX(Math.PI / 2);
            
            marker.userData = { hotspot, index, ring };
            marker.add(ring);
            globe.add(marker);
        });

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);

        const pointLight = new THREE.PointLight(0x00d4ff, 1, 100);
        pointLight.position.set(5, 5, 5);
        scene.add(pointLight);

        // Animation loop
        let animationId;
        const clock = new THREE.Clock();
        
        const animate = () => {
            animationId = requestAnimationFrame(animate);
            
            const elapsedTime = clock.getElapsedTime();
            
            // Animate globe
            if (globe) {
                globe.rotation.y += 0.0008;
                globe.material.uniforms.time.value = elapsedTime;
                globe.material.uniforms.scanlinePosition.value = Math.sin(elapsedTime * 0.5) * 1.5;
                
                // Animate hotspot pulse rings
                globe.children.forEach(child => {
                    if (child.userData.ring) {
                        const ring = child.userData.ring;
                        ring.scale.set(
                            1 + Math.sin(elapsedTime * 2 + child.userData.index) * 0.3,
                            1 + Math.sin(elapsedTime * 2 + child.userData.index) * 0.3,
                            1
                        );
                        ring.material.opacity = 0.3 + Math.sin(elapsedTime * 2 + child.userData.index) * 0.2;
                    }
                });
            }
            
            // Animate particles
            if (particles) {
                const positions = particles.geometry.attributes.position.array;
                const velocities = particles.geometry.attributes.velocity.array;
                
                for (let i = 0; i < positions.length; i += 3) {
                    positions[i] += velocities[i];
                    positions[i + 1] += velocities[i + 1];
                    positions[i + 2] += velocities[i + 2];
                    
                    // Orbital motion
                    const dist = Math.sqrt(
                        positions[i] ** 2 + 
                        positions[i + 1] ** 2 + 
                        positions[i + 2] ** 2
                    );
                    
                    if (dist > 2.5 || dist < 1.6) {
                        const theta = Math.random() * Math.PI * 2;
                        const phi = Math.acos(Math.random() * 2 - 1);
                        const radius = 1.6 + Math.random() * 0.8;
                        
                        positions[i] = radius * Math.sin(phi) * Math.cos(theta);
                        positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
                        positions[i + 2] = radius * Math.cos(phi);
                    }
                }
                
                particles.geometry.attributes.position.needsUpdate = true;
                particles.rotation.y += 0.0005;
            }
            
            // Animate connection lines
            if (connectionGroup) {
                connectionGroup.children.forEach((line, idx) => {
                    line.material.opacity = 0.2 + Math.sin(elapsedTime * 2 + idx * 0.5) * 0.15;
                });
            }

            // Animate GPS connection lines with pulse
            globe.children.forEach(child => {
                if (child.type === 'Group' && child.children.length > 0 && child.children[0].material?.color?.getHex() === 0xff00ff) {
                    child.children.forEach((line, idx) => {
                        line.material.opacity = 0.3 + Math.sin(elapsedTime * 3 + idx * 0.3) * 0.25;
                    });
                }
            });
            
            renderer.render(scene, camera);
        };
        animate();

        // Mouse interaction
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();

        const onMouseMove = (event) => {
            const rect = mountRef.current.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            setMousePos({ x: event.clientX, y: event.clientY });

            raycaster.setFromCamera(mouse, camera);
            // Check globe children (hotspots) recursively
            const intersects = raycaster.intersectObjects(scene.children, true);

            let found = false;
            for (let intersect of intersects) {
                if (intersect.object.userData.hotspot) {
                    setHoveredHotspot(intersect.object.userData);
                    found = true;
                    break;
                }
            }
            if (!found) {
                setHoveredHotspot(null);
            }

            // Rotation on drag
            if (isDragging.current && globe) {
                const deltaX = event.clientX - previousMousePosition.current.x;
                const deltaY = event.clientY - previousMousePosition.current.y;

                globe.rotation.y += deltaX * 0.005;
                globe.rotation.x += deltaY * 0.005;
            }

            previousMousePosition.current = { x: event.clientX, y: event.clientY };
        };

        const onMouseDown = (event) => {
            isDragging.current = true;
            previousMousePosition.current = { x: event.clientX, y: event.clientY };

            const rect = mountRef.current.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, camera);
            // Check globe children (hotspots) recursively
            const intersects = raycaster.intersectObjects(scene.children, true);

            for (let intersect of intersects) {
                if (intersect.object.userData.hotspot) {
                    const hotspot = intersect.object.userData.hotspot;
                    // Check if clicking on UK/England - trigger country zoom
                    if (hotspot.country === 'United Kingdom' || hotspot.country === 'England' || 
                        hotspot.region?.toLowerCase().includes('london') || 
                        hotspot.region?.toLowerCase().includes('manchester')) {
                        if (onCountryClick) {
                            onCountryClick('United Kingdom');
                        }
                    } else {
                        onHotspotClick(hotspot);
                    }
                    break;
                }
            }
        };

        const onMouseUp = () => {
            isDragging.current = false;
        };

        const onWheel = (event) => {
            event.preventDefault();
            // Smooth zoom with better control
            const zoomSpeed = 0.002;
            camera.position.z += event.deltaY * zoomSpeed;
            // Clamp zoom between 2.5 (close) and 10 (far)
            camera.position.z = Math.max(2.5, Math.min(10, camera.position.z));
        };

        // Touch controls
        let touchStartDistance = 0;
        let touchStartRotation = { x: 0, y: 0 };

        const onTouchStart = (event) => {
            if (event.touches.length === 1) {
                isDragging.current = true;
                previousMousePosition.current = { 
                    x: event.touches[0].clientX, 
                    y: event.touches[0].clientY 
                };
                touchStartRotation = { x: globe.rotation.x, y: globe.rotation.y };
            } else if (event.touches.length === 2) {
                isDragging.current = false;
                const dx = event.touches[0].clientX - event.touches[1].clientX;
                const dy = event.touches[0].clientY - event.touches[1].clientY;
                touchStartDistance = Math.sqrt(dx * dx + dy * dy);
            }
        };

        const onTouchMove = (event) => {
            event.preventDefault();
            
            if (event.touches.length === 1 && isDragging.current && globe) {
                const deltaX = event.touches[0].clientX - previousMousePosition.current.x;
                const deltaY = event.touches[0].clientY - previousMousePosition.current.y;

                globe.rotation.y += deltaX * 0.005;
                globe.rotation.x += deltaY * 0.005;

                previousMousePosition.current = { 
                    x: event.touches[0].clientX, 
                    y: event.touches[0].clientY 
                };
            } else if (event.touches.length === 2) {
                const dx = event.touches[0].clientX - event.touches[1].clientX;
                const dy = event.touches[0].clientY - event.touches[1].clientY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                const delta = touchStartDistance - distance;
                camera.position.z += delta * 0.01;
                camera.position.z = Math.max(2.5, Math.min(10, camera.position.z));
                
                touchStartDistance = distance;
            }
        };

        const onTouchEnd = () => {
            isDragging.current = false;
        };

        mountRef.current.addEventListener('mousemove', onMouseMove);
        mountRef.current.addEventListener('mousedown', onMouseDown);
        mountRef.current.addEventListener('mouseup', onMouseUp);
        mountRef.current.addEventListener('wheel', onWheel, { passive: false });
        
        // Touch events
        mountRef.current.addEventListener('touchstart', onTouchStart, { passive: false });
        mountRef.current.addEventListener('touchmove', onTouchMove, { passive: false });
        mountRef.current.addEventListener('touchend', onTouchEnd);

        // Handle resize
        const handleResize = () => {
            if (!mountRef.current) return;
            camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
        };
        window.addEventListener('resize', handleResize);

        // Cleanup
        return () => {
            cancelAnimationFrame(animationId);
            if (mountRef.current && renderer.domElement) {
                mountRef.current.removeChild(renderer.domElement);
            }
            mountRef.current?.removeEventListener('mousemove', onMouseMove);
            mountRef.current?.removeEventListener('mousedown', onMouseDown);
            mountRef.current?.removeEventListener('mouseup', onMouseUp);
            mountRef.current?.removeEventListener('wheel', onWheel);
            mountRef.current?.removeEventListener('touchstart', onTouchStart);
            mountRef.current?.removeEventListener('touchmove', onTouchMove);
            mountRef.current?.removeEventListener('touchend', onTouchEnd);
            window.removeEventListener('resize', handleResize);
            geometry.dispose();
            material.dispose();
            renderer.dispose();
            };
            } catch (error) {
            console.error('WebGL initialization error:', error);
            setWebglError(true);
            }
            }, [heatmapData, gpsLocation, onHotspotClick]);

            if (webglError) {
            return (
            <div className="relative w-full h-full flex items-center justify-center">
                <div className="text-center p-8 bg-slate-900/80 backdrop-blur-xl border border-cyan-500/30 rounded-xl max-w-md">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-500/20 flex items-center justify-center">
                        <span className="text-3xl">⚠️</span>
                    </div>
                    <h3 className="text-white font-bold text-lg mb-2">WebGL Not Available</h3>
                    <p className="text-slate-400 text-sm mb-4">
                        Your browser doesn't support WebGL or it's disabled. The 3D globe requires WebGL to render.
                    </p>
                    <div className="text-slate-500 text-xs space-y-1">
                        <p>• Enable hardware acceleration in your browser</p>
                        <p>• Try using Chrome, Firefox, or Edge</p>
                        <p>• Update your graphics drivers</p>
                    </div>
                </div>
            </div>
            );
            }

            return (
            <div className="relative w-full h-full">
            <div ref={mountRef} className="w-full h-full" />
            
            {/* Hover tooltip */}
            <AnimatePresence>
                {hoveredHotspot && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        style={{
                            position: 'fixed',
                            left: mousePos.x + 20,
                            top: mousePos.y - 20,
                            pointerEvents: 'none',
                            zIndex: 1000
                        }}
                        className="bg-slate-900/95 backdrop-blur-xl border border-cyan-500/30 rounded-lg px-4 py-3 shadow-xl shadow-cyan-500/20"
                    >
                        <p className="text-white font-bold text-sm">{hoveredHotspot.hotspot.region}</p>
                        <p className="text-cyan-400 text-xs">{hoveredHotspot.hotspot.count} players</p>
                        <p className="text-amber-400 text-xs">Avg Score: {hoveredHotspot.hotspot.avgScore}/100</p>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}