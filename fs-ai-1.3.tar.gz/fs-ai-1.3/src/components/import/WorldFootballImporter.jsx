import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Globe, Download, CheckCircle, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import toast from 'react-hot-toast';

export default function WorldFootballImporter() {
    const [url, setUrl] = useState('');
    const [isImporting, setIsImporting] = useState(false);
    const [result, setResult] = useState(null);

    const handleImport = async () => {
        if (!url.trim()) {
            toast.error('Please enter a URL');
            return;
        }

        setIsImporting(true);
        toast.loading('Fetching data from worldfootball.net...', { id: 'import-wf' });

        try {
            // Fetch the website content
            const websiteData = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football data extraction AI. Extract player, team, or match information from this URL: ${url}
                
If it's a player profile, extract: name, position, age, nationality, current club, market value (estimate if not available)
If it's a team squad list, extract multiple players with basic info
If it's a match report, extract key players mentioned with performance stats

Return structured data that can be imported into a football scouting database.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        data_type: { 
                            type: "string", 
                            enum: ["player", "team_squad", "match_report", "league_table", "unknown"] 
                        },
                        players: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    name: { type: "string" },
                                    position: { type: "string" },
                                    age: { type: "number" },
                                    nationality: { type: "string" },
                                    current_club: { type: "string" },
                                    league: { type: "string" },
                                    market_value: { type: "number" },
                                    notes: { type: "string" }
                                }
                            }
                        },
                        match_info: {
                            type: "object",
                            properties: {
                                home_team: { type: "string" },
                                away_team: { type: "string" },
                                score: { type: "string" },
                                date: { type: "string" }
                            }
                        },
                        success: { type: "boolean" },
                        message: { type: "string" }
                    }
                }
            });

            if (!websiteData.success || !websiteData.players || websiteData.players.length === 0) {
                setResult({
                    success: false,
                    message: websiteData.message || 'No player data found at this URL. Try a player profile, team squad page, or match report.'
                });
                toast.error('No player data found', { id: 'import-wf' });
                setIsImporting(false);
                return;
            }

            // Import players to database
            const importedPlayers = [];
            const errors = [];

            for (const playerData of websiteData.players) {
                try {
                    // Check if player already exists
                    const existingPlayers = await base44.entities.Player.filter({ 
                        name: playerData.name 
                    });

                    if (existingPlayers.length === 0) {
                        const newPlayer = await base44.entities.Player.create({
                            name: playerData.name,
                            position: playerData.position || 'Unknown',
                            age: playerData.age || 25,
                            nationality: playerData.nationality || 'Unknown',
                            current_club: playerData.current_club || 'Unknown',
                            league: playerData.league || 'Unknown',
                            market_value: playerData.market_value || 5,
                            notes: playerData.notes || `Imported from worldfootball.net on ${new Date().toISOString().split('T')[0]}`
                        });
                        importedPlayers.push(newPlayer);
                    } else {
                        errors.push(`${playerData.name} already exists in database`);
                    }
                } catch (error) {
                    errors.push(`Failed to import ${playerData.name}: ${error.message}`);
                }
            }

            setResult({
                success: true,
                data_type: websiteData.data_type,
                message: `Successfully imported ${importedPlayers.length} player(s)`,
                imported_count: importedPlayers.length,
                skipped_count: errors.length,
                errors: errors,
                players: importedPlayers,
                match_info: websiteData.match_info
            });

            if (importedPlayers.length > 0) {
                toast.success(`Imported ${importedPlayers.length} player(s)!`, { id: 'import-wf' });
            } else {
                toast.error('All players already exist in database', { id: 'import-wf' });
            }
        } catch (error) {
            console.error('Import failed:', error);
            setResult({
                success: false,
                message: 'Import failed. Check console for details.',
                error: error.message
            });
            toast.error('Import failed', { id: 'import-wf' });
        } finally {
            setIsImporting(false);
        }
    };

    const exampleUrls = [
        'https://www.worldfootball.net/player_summary/erling-haaland/',
        'https://www.worldfootball.net/teams/manchester-city/2024/2/',
        'https://www.worldfootball.net/match-report/premier-league-2024-2025-manchester-city-chelsea/'
    ];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Globe className="w-5 h-5 text-blue-400" />
                    WorldFootball.net Importer
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Import player data from worldfootball.net profiles, squads, and matches
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <Label className="text-slate-300 mb-2 block">WorldFootball.net URL</Label>
                    <Input
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white"
                        placeholder="https://www.worldfootball.net/player_summary/..."
                    />
                    <div className="mt-3">
                        <p className="text-slate-500 text-xs mb-2">Example URLs (click to use):</p>
                        <div className="space-y-1">
                            {exampleUrls.map((exampleUrl, idx) => (
                                <button
                                    key={idx}
                                    onClick={() => setUrl(exampleUrl)}
                                    className="block w-full text-left px-3 py-2 bg-slate-800/50 hover:bg-slate-800 rounded text-cyan-400 text-xs transition-colors"
                                >
                                    {exampleUrl}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                    <h4 className="text-blue-400 font-semibold text-sm mb-2">Supported Pages:</h4>
                    <ul className="text-slate-300 text-xs space-y-1">
                        <li>• Player profiles (detailed stats)</li>
                        <li>• Team squad pages (multiple players)</li>
                        <li>• Match reports (key performers)</li>
                        <li>• League tables (team info)</li>
                    </ul>
                </div>

                <Button
                    onClick={handleImport}
                    disabled={isImporting || !url.trim()}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600"
                >
                    {isImporting ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Extracting Data...
                        </>
                    ) : (
                        <>
                            <Download className="w-4 h-4 mr-2" />
                            Import from WorldFootball.net
                        </>
                    )}
                </Button>

                {result && (
                    <div className={`rounded-lg p-4 ${result.success ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
                        <div className="flex items-start gap-2 mb-3">
                            {result.success ? (
                                <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            ) : (
                                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            )}
                            <div className="flex-1">
                                <p className={`font-semibold ${result.success ? 'text-emerald-400' : 'text-red-400'}`}>
                                    {result.success ? 'Import Successful' : 'Import Failed'}
                                </p>
                                <p className="text-slate-300 text-sm mt-1">{result.message}</p>
                            </div>
                        </div>

                        {result.data_type && (
                            <Badge className="bg-blue-500/20 text-blue-400 mb-3">
                                {result.data_type.replace('_', ' ')}
                            </Badge>
                        )}

                        {result.imported_count !== undefined && (
                            <div className="space-y-2 text-sm">
                                <p className="text-slate-300">✓ Imported: {result.imported_count} player(s)</p>
                                {result.skipped_count > 0 && (
                                    <p className="text-amber-400">⊘ Skipped: {result.skipped_count} (already exist)</p>
                                )}
                            </div>
                        )}

                        {result.players && result.players.length > 0 && (
                            <div className="mt-3 space-y-2">
                                <p className="text-slate-400 text-xs font-semibold">Imported Players:</p>
                                {result.players.map((player, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded p-2 text-xs">
                                        <p className="text-white font-semibold">{player.name}</p>
                                        <p className="text-slate-400">
                                            {player.position} • {player.age}y • {player.current_club}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        )}

                        {result.errors && result.errors.length > 0 && (
                            <div className="mt-3">
                                <p className="text-amber-400 text-xs font-semibold mb-2">Notes:</p>
                                <div className="space-y-1 max-h-32 overflow-y-auto">
                                    {result.errors.map((err, idx) => (
                                        <p key={idx} className="text-slate-400 text-xs">• {err}</p>
                                    ))}
                                </div>
                            </div>
                        )}

                        {result.match_info && (
                            <div className="mt-3 bg-slate-800/50 rounded p-3">
                                <p className="text-slate-400 text-xs mb-1">Match Context:</p>
                                <p className="text-white text-sm">
                                    {result.match_info.home_team} vs {result.match_info.away_team}
                                </p>
                                {result.match_info.score && (
                                    <p className="text-slate-400 text-xs">Score: {result.match_info.score}</p>
                                )}
                            </div>
                        )}

                        {result.error && (
                            <p className="text-red-400 text-xs mt-2">{result.error}</p>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}