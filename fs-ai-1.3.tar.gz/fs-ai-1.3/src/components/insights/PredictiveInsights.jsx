import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, TrendingUp, TrendingDown, Gem, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function PredictiveInsights() {
    const [insights, setInsights] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 100)
    });

    const runPredictiveAnalysis = async () => {
        setIsAnalyzing(true);
        toast.loading('AI analyzing market predictions...', { id: 'predict' });

        try {
            const response = await base44.functions.runPredictiveAnalysis({});
            
            if (response.success) {
                setInsights(response.insights);
                toast.success(`Analysis complete! Analyzed ${response.players_analyzed} players`, { id: 'predict' });
            } else {
                toast.error('Analysis failed. Enable backend functions first.', { id: 'predict' });
            }
        } catch (error) {
            console.error('Prediction failed:', error);
            toast.error('Failed to generate predictions', { id: 'predict' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Predictive Intelligence Engine
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 mb-4">
                        Advanced AI-powered market predictions based on player trajectories, performance data, and market trends
                    </p>
                    <Button
                        onClick={runPredictiveAnalysis}
                        disabled={isAnalyzing || players.length === 0}
                        className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing {players.length} players...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Run Predictive Analysis
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {insights && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Rising Stars */}
                    <Card className="bg-emerald-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400 flex items-center gap-2">
                                <TrendingUp className="w-5 h-5" />
                                Rising Stars - High Growth Potential
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {insights.rising_stars.map((player, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        className="bg-slate-800/50 rounded-lg p-4"
                                    >
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <div className="flex items-center gap-2 mb-2">
                                                    <h4 className="text-white font-bold">{player.player_name}</h4>
                                                    <Badge className={
                                                        player.confidence_level === 'Very High' ? 'bg-emerald-500/20 text-emerald-400' :
                                                        player.confidence_level === 'High' ? 'bg-cyan-500/20 text-cyan-400' :
                                                        'bg-slate-600 text-slate-300'
                                                    }>
                                                        {player.confidence_level} Confidence
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">
                                                    {player.position} • {player.age}y
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <Badge className="bg-emerald-500/20 text-emerald-400 text-lg px-3 py-1">
                                                    +{player.growth_percentage}%
                                                </Badge>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-3 gap-3 mb-3">
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Current</p>
                                                <p className="text-white font-semibold">€{player.current_value}M</p>
                                            </div>
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">1 Year</p>
                                                <p className="text-emerald-400 font-semibold">€{player.predicted_value_1yr}M</p>
                                            </div>
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">2 Years</p>
                                                <p className="text-emerald-400 font-semibold">€{player.predicted_value_2yr}M</p>
                                            </div>
                                        </div>

                                        <p className="text-slate-300 text-sm mb-2">{player.reasoning}</p>
                                        
                                        <div className="flex flex-wrap gap-1">
                                            {player.key_factors.map((factor, i) => (
                                                <Badge key={i} className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                    {factor}
                                                </Badge>
                                            ))}
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Hidden Gems */}
                    <Card className="bg-cyan-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400 flex items-center gap-2">
                                <Gem className="w-5 h-5" />
                                Hidden Gems - Undervalued Talent
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {insights.hidden_gems.map((player, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        className="bg-slate-800/50 rounded-lg p-4"
                                    >
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <h4 className="text-white font-bold mb-1">{player.player_name}</h4>
                                                <p className="text-slate-400 text-sm">
                                                    {player.position} • {player.age}y
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-slate-500 text-xs">Opportunity Score</p>
                                                <p className="text-2xl font-bold text-cyan-400">
                                                    {player.opportunity_score}/10
                                                </p>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-3 mb-3">
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Current Value</p>
                                                <p className="text-amber-400 font-semibold">€{player.current_value}M</p>
                                            </div>
                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-500 text-xs">Fair Value</p>
                                                <p className="text-emerald-400 font-semibold">€{player.fair_value}M</p>
                                            </div>
                                        </div>

                                        <div className="space-y-2 mb-3">
                                            <div>
                                                <p className="text-slate-500 text-xs mb-1">Why Undervalued:</p>
                                                <p className="text-slate-300 text-sm">{player.why_undervalued}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs mb-1">Upside Potential:</p>
                                                <p className="text-cyan-400 text-sm">{player.upside_potential}</p>
                                            </div>
                                        </div>

                                        <div className="bg-cyan-500/20 border border-cyan-500/30 rounded p-3">
                                            <p className="text-cyan-400 text-sm font-semibold">
                                                📋 {player.recommended_action}
                                            </p>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Investment Risks */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-red-400 flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5" />
                                Investment Risks - Players to Avoid
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {insights.investment_risks.map((player, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-red-500"
                                    >
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1">
                                                <h4 className="text-white font-bold mb-1">{player.player_name}</h4>
                                                <p className="text-slate-400 text-sm">
                                                    {player.position} • {player.age}y
                                                </p>
                                            </div>
                                            <Badge className={
                                                player.risk_level === 'Critical' ? 'bg-red-500/30 text-red-400' :
                                                player.risk_level === 'Very High' ? 'bg-red-500/20 text-red-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }>
                                                {player.risk_level} Risk
                                            </Badge>
                                        </div>

                                        <div className="bg-slate-900/50 rounded p-2 mb-3">
                                            <p className="text-slate-500 text-xs">Current Valuation</p>
                                            <p className="text-amber-400 font-semibold text-lg">€{player.current_value}M</p>
                                        </div>

                                        <div className="space-y-2">
                                            <div>
                                                <p className="text-red-400 font-semibold text-sm mb-1">⚠️ Risk Factors:</p>
                                                <ul className="space-y-1">
                                                    {player.risk_factors.map((risk, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-red-400 mt-0.5">•</span>
                                                            {risk}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div className="bg-red-500/20 border border-red-500/30 rounded p-3 mt-2">
                                                <p className="text-red-400 text-sm">{player.warning}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}