import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, RefreshCw, CheckCircle2, AlertCircle, Database, Settings } from 'lucide-react';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function ExternalDataSync() {
    const [selectedIntegration, setSelectedIntegration] = useState(null);
    const [syncConfig, setSyncConfig] = useState({
        leagues: '',
        age_range: { min: 16, max: 35 },
        positions: []
    });
    const [syncOptions, setSyncOptions] = useState({
        areas: true,
        competitions: true,
        teams: true,
        players: true,
        matches: false,
        season_ids: [],
        competition_ids: [],
        age_min: 18,
        age_max: 25
    });

    const queryClient = useQueryClient();

    const { data: integrations = [], isLoading } = useQuery({
        queryKey: ['integrations'],
        queryFn: () => base44.entities.ExternalIntegration.list()
    });

    const syncMutation = useMutation({
        mutationFn: async ({ integrationId, type }) => {
            if (type === 'Wyscout') {
                const { data } = await base44.functions.invoke('syncWyscoutDatabase', {
                    integration_id: integrationId,
                    sync_options: syncOptions
                });
                return data;
            } else if (type === 'Transfermarkt') {
                const { data } = await base44.functions.invoke('syncTransfermarktData', {
                    integration_id: integrationId,
                    leagues: syncConfig.leagues.split(',').map(l => l.trim()),
                    max_value: 100
                });
                return data;
            }
        },
        onSuccess: (data) => {
            if (data.success) {
                toast.success(data.message);
                queryClient.invalidateQueries({ queryKey: ['integrations'] });
                queryClient.invalidateQueries({ queryKey: ['players'] });
            } else {
                toast.error(data.error || 'Sync failed');
            }
        },
        onError: (error) => {
            toast.error('Backend functions required. Enable in settings first.');
        }
    });

    const createIntegrationMutation = useMutation({
        mutationFn: (data) => base44.entities.ExternalIntegration.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['integrations'] });
            toast.success('Integration created');
        }
    });

    const handleSync = (integration) => {
        const integrationType = integration.integration_name.includes('Wyscout') ? 'Wyscout' : 'Transfermarkt';
        syncMutation.mutate({
            integrationId: integration.id,
            type: integrationType
        });
    };

    const createDefaultIntegrations = async () => {
        const defaults = [
            {
                integration_name: 'Wyscout Pro',
                integration_type: 'Scouting Database',
                api_endpoint: 'https://api.wyscout.com/v3',
                sync_frequency: 'Daily'
            },
            {
                integration_name: 'Transfermarkt Data Feed',
                integration_type: 'Data Feed',
                api_endpoint: 'https://api.transfermarkt.com/v1',
                sync_frequency: 'Daily'
            }
        ];

        for (const integration of defaults) {
            await createIntegrationMutation.mutateAsync(integration);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Active': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
            case 'Syncing': return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
            case 'Error': return 'bg-red-500/20 text-red-400 border-red-500/30';
            default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {integrations.length === 0 ? (
                <Card className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-cyan-500/30">
                    <CardContent className="py-16 text-center">
                        <Database className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
                        <h3 className="text-white text-xl font-semibold mb-2">
                            Connect to Scouting Databases
                        </h3>
                        <p className="text-slate-400 mb-6 max-w-2xl mx-auto">
                            Integrate with Wyscout, Transfermarkt, and other scouting platforms to automatically sync player data, statistics, and market values
                        </p>
                        <Button
                            onClick={createDefaultIntegrations}
                            className="bg-gradient-to-r from-cyan-500 to-purple-600"
                        >
                            <Settings className="w-4 h-4 mr-2" />
                            Set Up Integrations
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <>
                    {/* Sync Configuration */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Sync Configuration</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label className="text-slate-300">Leagues (comma-separated)</Label>
                                <Input
                                    value={syncConfig.leagues}
                                    onChange={(e) => setSyncConfig({ ...syncConfig, leagues: e.target.value })}
                                    placeholder="Premier League, La Liga, Serie A"
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label className="text-slate-300">Min Age</Label>
                                    <Input
                                        type="number"
                                        value={syncConfig.age_range.min}
                                        onChange={(e) => setSyncConfig({
                                            ...syncConfig,
                                            age_range: { ...syncConfig.age_range, min: Number(e.target.value) }
                                        })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                                <div>
                                    <Label className="text-slate-300">Max Age</Label>
                                    <Input
                                        type="number"
                                        value={syncConfig.age_range.max}
                                        onChange={(e) => setSyncConfig({
                                            ...syncConfig,
                                            age_range: { ...syncConfig.age_range, max: Number(e.target.value) }
                                        })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Integration Cards */}
                    <div className="grid md:grid-cols-2 gap-6">
                        {integrations.map(integration => (
                            <motion.div
                                key={integration.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <div className="flex items-start justify-between">
                                            <div>
                                                <CardTitle className="text-white text-lg">
                                                    {integration.integration_name}
                                                </CardTitle>
                                                <Badge className="mt-2 bg-cyan-500/20 text-cyan-400">
                                                    {integration.integration_type}
                                                </Badge>
                                            </div>
                                            <Badge className={getStatusColor(integration.status)}>
                                                {integration.status}
                                            </Badge>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="bg-slate-800/50 rounded-lg p-4 space-y-2">
                                            <div className="flex justify-between text-sm">
                                                <span className="text-slate-400">Players Synced</span>
                                                <span className="text-white font-semibold">
                                                    {integration.players_synced || 0}
                                                </span>
                                            </div>
                                            <div className="flex justify-between text-sm">
                                                <span className="text-slate-400">Last Sync</span>
                                                <span className="text-white">
                                                    {integration.last_sync
                                                        ? new Date(integration.last_sync).toLocaleDateString()
                                                        : 'Never'}
                                                </span>
                                            </div>
                                            <div className="flex justify-between text-sm">
                                                <span className="text-slate-400">Frequency</span>
                                                <span className="text-white">{integration.sync_frequency}</span>
                                            </div>
                                        </div>

                                        <Button
                                            onClick={() => handleSync(integration)}
                                            disabled={syncMutation.isPending}
                                            className="w-full bg-gradient-to-r from-emerald-500 to-cyan-600"
                                        >
                                            {syncMutation.isPending ? (
                                                <>
                                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                    Syncing...
                                                </>
                                            ) : (
                                                <>
                                                    <RefreshCw className="w-4 h-4 mr-2" />
                                                    Sync Now
                                                </>
                                            )}
                                        </Button>

                                        {integration.error_log && integration.error_log.length > 0 && (
                                            <div className="bg-red-500/10 border border-red-500/30 rounded p-3">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <AlertCircle className="w-4 h-4 text-red-400" />
                                                    <span className="text-red-400 text-sm font-semibold">
                                                        Recent Error
                                                    </span>
                                                </div>
                                                <p className="text-slate-300 text-xs">
                                                    {integration.error_log[integration.error_log.length - 1].error}
                                                </p>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>

                    {/* Setup Instructions */}
                    <Card className="bg-amber-500/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-start gap-3">
                                <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                <div>
                                    <h4 className="text-amber-400 font-semibold mb-2">Setup Required</h4>
                                    <ol className="text-slate-300 text-sm space-y-1 list-decimal list-inside">
                                        <li>Enable backend functions in Dashboard → Settings</li>
                                        <li>Configure API keys for each integration (contact providers)</li>
                                        <li>Set sync preferences and schedule</li>
                                        <li>Run initial sync to populate database</li>
                                    </ol>
                                    <p className="text-slate-500 text-xs mt-3">
                                        Note: Add API credentials in integration config to sync real data. Demo mode uses simulated data.
                                    </p>
                                    <div className="mt-4 bg-slate-800/50 rounded p-3 space-y-3">
                                        <div>
                                            <p className="text-cyan-400 text-sm font-semibold mb-1">Wyscout API v3 Setup:</p>
                                            <ol className="text-slate-400 text-xs space-y-1 list-decimal list-inside ml-2">
                                                <li>Get API key from Wyscout at <a href="https://apidocs.wyscout.com" target="_blank" className="text-cyan-400 underline">apidocs.wyscout.com</a></li>
                                                <li>Store in integration config: config.api_key</li>
                                                <li>Endpoint: https://apirest.wyscout.com/v3</li>
                                            </ol>
                                        </div>

                                        <div>
                                            <p className="text-purple-400 text-sm font-semibold mb-2">Sync Options:</p>
                                            <div className="space-y-2">
                                                <label className="flex items-center gap-2">
                                                    <input 
                                                        type="checkbox" 
                                                        checked={syncOptions.players}
                                                        onChange={(e) => setSyncOptions({...syncOptions, players: e.target.checked})}
                                                        className="rounded"
                                                    />
                                                    <span className="text-slate-300 text-xs">Players</span>
                                                </label>
                                                <label className="flex items-center gap-2">
                                                    <input 
                                                        type="checkbox" 
                                                        checked={syncOptions.teams}
                                                        onChange={(e) => setSyncOptions({...syncOptions, teams: e.target.checked})}
                                                        className="rounded"
                                                    />
                                                    <span className="text-slate-300 text-xs">Teams</span>
                                                </label>
                                                <label className="flex items-center gap-2">
                                                    <input 
                                                        type="checkbox" 
                                                        checked={syncOptions.competitions}
                                                        onChange={(e) => setSyncOptions({...syncOptions, competitions: e.target.checked})}
                                                        className="rounded"
                                                    />
                                                    <span className="text-slate-300 text-xs">Competitions</span>
                                                </label>
                                                <label className="flex items-center gap-2">
                                                    <input 
                                                        type="checkbox" 
                                                        checked={syncOptions.matches}
                                                        onChange={(e) => setSyncOptions({...syncOptions, matches: e.target.checked})}
                                                        className="rounded"
                                                    />
                                                    <span className="text-slate-300 text-xs">Match Data</span>
                                                </label>
                                                <div className="flex gap-2 pt-2">
                                                    <input 
                                                        type="number"
                                                        placeholder="Min Age"
                                                        value={syncOptions.age_min}
                                                        onChange={(e) => setSyncOptions({...syncOptions, age_min: parseInt(e.target.value)})}
                                                        className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 text-xs"
                                                    />
                                                    <input 
                                                        type="number"
                                                        placeholder="Max Age"
                                                        value={syncOptions.age_max}
                                                        onChange={(e) => setSyncOptions({...syncOptions, age_max: parseInt(e.target.value)})}
                                                        className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 text-xs"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </>
            )}
        </div>
    );
}