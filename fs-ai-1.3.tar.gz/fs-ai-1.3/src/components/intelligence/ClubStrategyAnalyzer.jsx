import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, Loader2, Target, Users, TrendingUp, ArrowRight, Briefcase } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

const LEAGUES = [
    { value: 'Premier League', label: 'Premier League' },
    { value: 'La Liga', label: 'La Liga' },
    { value: 'Bundesliga', label: 'Bundesliga' },
    { value: 'Serie A', label: 'Serie A' },
    { value: 'Ligue 1', label: 'Ligue 1' },
    { value: 'Championship', label: 'Championship' }
];

export default function ClubStrategyAnalyzer() {
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);
    const [selectedLeague, setSelectedLeague] = useState('Premier League');

    const { data: players = [] } = useQuery({
        queryKey: ['players-strategy'],
        queryFn: () => base44.entities.Player.list('-market_value', 200)
    });

    const { data: strategies = [] } = useQuery({
        queryKey: ['team-strategies'],
        queryFn: () => base44.entities.TeamStrategy.list('-created_date', 20)
    });

    const analyzeStrategies = async () => {
        setLoading(true);
        toast.loading('AI analyzing club strategies...', { id: 'strategy-ai' });

        try {
            const leaguePlayers = players.filter(p => p.league === selectedLeague).slice(0, 50);
            const clubData = {};
            
            leaguePlayers.forEach(p => {
                if (!clubData[p.current_club]) {
                    clubData[p.current_club] = { players: [], totalValue: 0, avgAge: 0 };
                }
                clubData[p.current_club].players.push({
                    name: p.name,
                    position: p.position,
                    age: p.age,
                    value: p.market_value
                });
                clubData[p.current_club].totalValue += p.market_value || 0;
            });

            Object.keys(clubData).forEach(club => {
                const ages = clubData[club].players.map(p => p.age).filter(a => a);
                clubData[club].avgAge = ages.length ? (ages.reduce((a, b) => a + b, 0) / ages.length).toFixed(1) : 0;
            });

            const existingStrategies = strategies.filter(s => s.league === selectedLeague).map(s => ({
                club: s.club_name,
                priority_positions: s.priority_positions,
                budget: s.transfer_budget
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football transfer strategy analyst. Analyze clubs in ${selectedLeague}.

CLUB DATA:
${JSON.stringify(clubData, null, 2)}

KNOWN STRATEGIES:
${JSON.stringify(existingStrategies, null, 2)}

For each major club (6-8 clubs), analyze and predict:

1. **Squad Needs** - Positions they need to strengthen
2. **Transfer Strategy** - Buy young/proven, loan market, academy focus
3. **Likely Targets** - Type of players they'll pursue
4. **Budget Tier** - High/Medium/Low spender
5. **Movement Predictions** - Players they might sell/buy

Return JSON with:
- clubs: array of {
    club_name,
    squad_assessment (1-2 sentences),
    priority_positions (array of 2-3 positions),
    transfer_style ("Big Spender" | "Smart Investor" | "Youth Focus" | "Loan Market" | "Selling Club"),
    likely_ins (array of player types/names they'll target),
    likely_outs (array of player types likely to leave),
    budget_estimate (string like "€100-150M"),
    key_insight (1 sentence unique insight)
  }
- league_trends: string (2-3 sentences on overall league transfer trends)
- hot_positions: array of positions in high demand across the league`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        clubs: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    club_name: { type: 'string' },
                                    squad_assessment: { type: 'string' },
                                    priority_positions: { type: 'array', items: { type: 'string' } },
                                    transfer_style: { type: 'string' },
                                    likely_ins: { type: 'array', items: { type: 'string' } },
                                    likely_outs: { type: 'array', items: { type: 'string' } },
                                    budget_estimate: { type: 'string' },
                                    key_insight: { type: 'string' }
                                }
                            }
                        },
                        league_trends: { type: 'string' },
                        hot_positions: { type: 'array', items: { type: 'string' } }
                    }
                }
            });

            setAnalysis(result);
            toast.success('Strategy analysis complete!', { id: 'strategy-ai' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'strategy-ai' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const styleColors = {
        'Big Spender': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
        'Smart Investor': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
        'Youth Focus': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Loan Market': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Selling Club': 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                        <Building2 className="w-5 h-5 text-purple-400" />
                        Club Strategy Analyzer
                    </CardTitle>
                    <Select value={selectedLeague} onValueChange={setSelectedLeague}>
                        <SelectTrigger className="w-40 bg-slate-800 border-slate-700">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {LEAGUES.map(league => (
                                <SelectItem key={league.value} value={league.value}>
                                    {league.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-8">
                        <Building2 className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Analyze club transfer strategies and squad needs in {selectedLeague}
                        </p>
                        <Button
                            onClick={analyzeStrategies}
                            disabled={loading}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                            ) : (
                                <><Building2 className="w-4 h-4 mr-2" /> Analyze {selectedLeague}</>
                            )}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {/* League Trends */}
                        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                            <h4 className="text-purple-400 font-semibold mb-2 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4" /> League Trends
                            </h4>
                            <p className="text-slate-300 text-sm mb-3">{analysis.league_trends}</p>
                            <div className="flex flex-wrap gap-2">
                                <span className="text-slate-400 text-xs">Hot Positions:</span>
                                {analysis.hot_positions?.map((pos, i) => (
                                    <Badge key={i} variant="outline" className="text-xs border-purple-500/30 text-purple-300">
                                        {pos}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {/* Club Cards */}
                        <div className="space-y-3 max-h-[500px] overflow-y-auto">
                            {analysis.clubs?.map((club, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.1 }}
                                    className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                                >
                                    <div className="flex items-start justify-between mb-3">
                                        <div>
                                            <h4 className="text-white font-bold text-lg">{club.club_name}</h4>
                                            <p className="text-slate-400 text-sm">{club.squad_assessment}</p>
                                        </div>
                                        <Badge className={styleColors[club.transfer_style] || styleColors['Smart Investor']}>
                                            {club.transfer_style}
                                        </Badge>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4 mb-3">
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                                <Target className="w-3 h-3" /> Priority Positions
                                            </p>
                                            <div className="flex flex-wrap gap-1">
                                                {club.priority_positions?.map((pos, i) => (
                                                    <Badge key={i} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                        {pos}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                                <Briefcase className="w-3 h-3" /> Budget
                                            </p>
                                            <span className="text-emerald-400 font-semibold">{club.budget_estimate}</span>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4 mb-3 text-sm">
                                        <div>
                                            <p className="text-emerald-400 text-xs mb-1 flex items-center gap-1">
                                                <ArrowRight className="w-3 h-3" /> Likely Ins
                                            </p>
                                            <ul className="text-slate-300 text-xs space-y-0.5">
                                                {club.likely_ins?.slice(0, 3).map((target, i) => (
                                                    <li key={i}>• {target}</li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div>
                                            <p className="text-red-400 text-xs mb-1 flex items-center gap-1">
                                                <ArrowRight className="w-3 h-3 rotate-180" /> Likely Outs
                                            </p>
                                            <ul className="text-slate-300 text-xs space-y-0.5">
                                                {club.likely_outs?.slice(0, 3).map((player, i) => (
                                                    <li key={i}>• {player}</li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="pt-2 border-t border-slate-700">
                                        <p className="text-slate-400 text-xs italic">{club.key_insight}</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        <Button onClick={analyzeStrategies} variant="outline" className="w-full border-slate-700">
                            Re-analyze
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}