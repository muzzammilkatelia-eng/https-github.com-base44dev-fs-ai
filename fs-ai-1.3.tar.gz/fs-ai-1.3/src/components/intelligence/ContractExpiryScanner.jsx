import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Loader2, Calendar, Star, AlertTriangle, Gift, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { format, differenceInMonths, parseISO } from 'date-fns';

export default function ContractExpiryScanner() {
    const [aiInsights, setAiInsights] = useState(null);
    const [loading, setLoading] = useState(false);
    const [filterMonths, setFilterMonths] = useState('12');

    const { data: players = [] } = useQuery({
        queryKey: ['players-contract'],
        queryFn: () => base44.entities.Player.list('-market_value', 200)
    });

    const expiringPlayers = useMemo(() => {
        const now = new Date();
        const maxMonths = parseInt(filterMonths);
        
        return players
            .filter(p => p.contract_expiry)
            .map(p => {
                const expiryDate = parseISO(p.contract_expiry);
                const monthsRemaining = differenceInMonths(expiryDate, now);
                return { ...p, monthsRemaining, expiryDate };
            })
            .filter(p => p.monthsRemaining > 0 && p.monthsRemaining <= maxMonths)
            .sort((a, b) => a.monthsRemaining - b.monthsRemaining);
    }, [players, filterMonths]);

    const freeAgents = useMemo(() => {
        const now = new Date();
        return players.filter(p => {
            if (!p.contract_expiry) return false;
            const expiryDate = parseISO(p.contract_expiry);
            return differenceInMonths(expiryDate, now) <= 6;
        });
    }, [players]);

    const generateInsights = async () => {
        setLoading(true);
        toast.loading('AI analyzing contract situations...', { id: 'contract-ai' });

        try {
            const targetPlayers = expiringPlayers.slice(0, 25).map(p => ({
                name: p.name,
                age: p.age,
                position: p.position,
                club: p.current_club,
                league: p.league,
                value: p.market_value,
                months_remaining: p.monthsRemaining,
                fsai_score: p.fsai_proprietary_score
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football contract and transfer specialist. Analyze these players with expiring contracts:

EXPIRING CONTRACTS:
${JSON.stringify(targetPlayers, null, 2)}

Identify the best opportunities and provide insights:

1. **Top Free Agent Targets** - Players available on free/reduced fee
2. **Bargain Opportunities** - Players whose value will drop due to contract situation
3. **Pre-Contract Targets** - Players to approach 6 months before expiry
4. **Risk Assessment** - Players likely to renew vs leave

Return JSON with:
- top_targets: array of 5-6 objects with {player_name, opportunity_type, reasoning, estimated_acquisition_cost, urgency}
- market_insights: string (2-3 sentences on overall contract market)
- negotiation_windows: array of {player_name, optimal_approach_date, strategy}`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        top_targets: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    opportunity_type: { type: 'string' },
                                    reasoning: { type: 'string' },
                                    estimated_acquisition_cost: { type: 'string' },
                                    urgency: { type: 'string' }
                                }
                            }
                        },
                        market_insights: { type: 'string' },
                        negotiation_windows: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    optimal_approach_date: { type: 'string' },
                                    strategy: { type: 'string' }
                                }
                            }
                        }
                    }
                }
            });

            setAiInsights(result);
            toast.success('Contract analysis complete!', { id: 'contract-ai' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'contract-ai' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const getUrgencyColor = (months) => {
        if (months <= 3) return 'bg-red-500/20 text-red-400 border-red-500/30';
        if (months <= 6) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                        <FileText className="w-5 h-5 text-amber-400" />
                        Contract Expiry Scanner
                    </CardTitle>
                    <div className="flex items-center gap-2">
                        <Select value={filterMonths} onValueChange={setFilterMonths}>
                            <SelectTrigger className="w-32 bg-slate-800 border-slate-700">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="6">6 Months</SelectItem>
                                <SelectItem value="12">12 Months</SelectItem>
                                <SelectItem value="18">18 Months</SelectItem>
                                <SelectItem value="24">24 Months</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-3">
                    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-center">
                        <Gift className="w-5 h-5 text-red-400 mx-auto mb-1" />
                        <p className="text-2xl font-bold text-white">{freeAgents.length}</p>
                        <p className="text-slate-400 text-xs">Free Agents (6mo)</p>
                    </div>
                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-center">
                        <Calendar className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                        <p className="text-2xl font-bold text-white">{expiringPlayers.length}</p>
                        <p className="text-slate-400 text-xs">Expiring ({filterMonths}mo)</p>
                    </div>
                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 text-center">
                        <TrendingUp className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                        <p className="text-2xl font-bold text-white">
                            €{expiringPlayers.reduce((sum, p) => sum + (p.market_value || 0), 0).toFixed(0)}M
                        </p>
                        <p className="text-slate-400 text-xs">Total Value</p>
                    </div>
                </div>

                {/* AI Insights Button */}
                <Button
                    onClick={generateInsights}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-600"
                >
                    {loading ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                    ) : (
                        <><Star className="w-4 h-4 mr-2" /> Generate AI Insights</>
                    )}
                </Button>

                {/* AI Insights */}
                {aiInsights && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-lg p-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Market Insights</h4>
                            <p className="text-slate-300 text-sm">{aiInsights.market_insights}</p>
                        </div>

                        <div className="space-y-2">
                            <h4 className="text-white font-semibold flex items-center gap-2">
                                <Star className="w-4 h-4 text-amber-400" /> Top Targets
                            </h4>
                            {aiInsights.top_targets?.map((target, idx) => (
                                <div key={idx} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                    <div className="flex items-start justify-between mb-1">
                                        <h5 className="text-white font-medium">{target.player_name}</h5>
                                        <Badge variant="outline" className="text-xs">
                                            {target.opportunity_type}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-400 text-xs mb-2">{target.reasoning}</p>
                                    <div className="flex items-center justify-between text-xs">
                                        <span className="text-emerald-400">{target.estimated_acquisition_cost}</span>
                                        <Badge className={target.urgency === 'High' ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'}>
                                            {target.urgency} Urgency
                                        </Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}

                {/* Player List */}
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                    <h4 className="text-slate-400 text-sm font-medium sticky top-0 bg-slate-900 py-1">
                        Expiring Contracts
                    </h4>
                    {expiringPlayers.slice(0, 20).map((player, idx) => (
                        <motion.div
                            key={player.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: idx * 0.03 }}
                            className="bg-slate-800/30 rounded-lg p-3 flex items-center justify-between"
                        >
                            <div>
                                <h5 className="text-white font-medium text-sm">{player.name}</h5>
                                <p className="text-slate-500 text-xs">{player.position} • {player.current_club}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-slate-400 text-xs">€{player.market_value}M</span>
                                <Badge className={getUrgencyColor(player.monthsRemaining)}>
                                    {player.monthsRemaining}mo
                                </Badge>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}