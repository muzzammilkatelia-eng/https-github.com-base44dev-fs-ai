import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { 
    MapPin, Filter, Zap, TrendingUp, Users, 
    Globe, Search, X, ChevronRight 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function GlobalTalentMap() {
    const [filters, setFilters] = useState({
        minScore: 0,
        position: 'all',
        league: 'all',
        investmentGrade: 'all',
        search: ''
    });
    const [selectedCluster, setSelectedCluster] = useState(null);
    const [viewMode, setViewMode] = useState('regions'); // regions, leagues, archetypes

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players-scored'],
        queryFn: () => base44.entities.Player.list('-fsai_proprietary_score', 500)
    });

    // Filter players
    const filteredPlayers = useMemo(() => {
        return players.filter(p => {
            if (!p.fsai_proprietary_score) return false;
            if (p.fsai_proprietary_score < filters.minScore) return false;
            if (filters.position !== 'all' && p.position !== filters.position) return false;
            if (filters.league !== 'all' && p.league !== filters.league) return false;
            if (filters.investmentGrade !== 'all' && p.fsai_investment_grade !== filters.investmentGrade) return false;
            if (filters.search && !p.name?.toLowerCase().includes(filters.search.toLowerCase())) return false;
            return true;
        });
    }, [players, filters]);

    // Regional mapping
    const regionMap = {
        'Premier League': 'England',
        'Championship': 'England',
        'La Liga': 'Spain',
        'Bundesliga': 'Germany',
        'Serie A': 'Italy',
        'Ligue 1': 'France',
        'Eredivisie': 'Netherlands',
        'Primeira Liga': 'Portugal',
        'MLS': 'North America',
        'Liga MX': 'North America',
        'Brazilian Serie A': 'South America',
        'Argentine Primera': 'South America',
        'Saudi Pro League': 'Middle East',
        'J-League': 'Asia'
    };

    // Cluster data by view mode
    const clusters = useMemo(() => {
        const grouped = {};

        if (viewMode === 'regions') {
            filteredPlayers.forEach(p => {
                const region = regionMap[p.league] || 'Other';
                if (!grouped[region]) grouped[region] = [];
                grouped[region].push(p);
            });
        } else if (viewMode === 'leagues') {
            filteredPlayers.forEach(p => {
                const league = p.league || 'Unknown';
                if (!grouped[league]) grouped[league] = [];
                grouped[league].push(p);
            });
        } else if (viewMode === 'archetypes') {
            filteredPlayers.forEach(p => {
                const archetype = p.position || 'Unknown';
                if (!grouped[archetype]) grouped[archetype] = [];
                grouped[archetype].push(p);
            });
        }

        return Object.entries(grouped).map(([name, players]) => ({
            name,
            count: players.length,
            avgScore: players.reduce((acc, p) => acc + p.fsai_proprietary_score, 0) / players.length,
            topGrades: players.filter(p => p.fsai_investment_grade?.startsWith('A')).length,
            players: players.sort((a, b) => b.fsai_proprietary_score - a.fsai_proprietary_score)
        })).sort((a, b) => b.avgScore - a.avgScore);
    }, [filteredPlayers, viewMode]);

    const uniquePositions = [...new Set(players.map(p => p.position).filter(Boolean))];
    const uniqueLeagues = [...new Set(players.map(p => p.league).filter(Boolean))];

    const stats = {
        totalScored: players.filter(p => p.fsai_proprietary_score).length,
        avgScore: players.filter(p => p.fsai_proprietary_score).reduce((acc, p) => acc + p.fsai_proprietary_score, 0) / 
                 Math.max(1, players.filter(p => p.fsai_proprietary_score).length),
        elitePlayers: players.filter(p => p.fsai_proprietary_score >= 85).length,
        topGrades: players.filter(p => p.fsai_investment_grade?.startsWith('A')).length
    };

    const getClusterColor = (avgScore) => {
        if (avgScore >= 85) return 'from-emerald-500/20 to-emerald-600/20 border-emerald-500/40';
        if (avgScore >= 70) return 'from-cyan-500/20 to-cyan-600/20 border-cyan-500/40';
        if (avgScore >= 50) return 'from-amber-500/20 to-amber-600/20 border-amber-500/40';
        return 'from-slate-500/20 to-slate-600/20 border-slate-500/40';
    };

    const getScoreColor = (score) => {
        if (score >= 85) return 'text-emerald-400';
        if (score >= 70) return 'text-cyan-400';
        if (score >= 50) return 'text-amber-400';
        return 'text-slate-400';
    };

    return (
        <div className="space-y-6">
            {/* Stats Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-4">
                        <div className="flex items-center gap-2 mb-1">
                            <Globe className="w-4 h-4 text-cyan-400" />
                            <span className="text-slate-400 text-xs">Total Mapped</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.totalScored}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-4">
                        <div className="flex items-center gap-2 mb-1">
                            <Zap className="w-4 h-4 text-purple-400" />
                            <span className="text-slate-400 text-xs">Avg Score</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.avgScore.toFixed(1)}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-4">
                        <div className="flex items-center gap-2 mb-1">
                            <TrendingUp className="w-4 h-4 text-emerald-400" />
                            <span className="text-slate-400 text-xs">Elite (85+)</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.elitePlayers}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-4">
                        <div className="flex items-center gap-2 mb-1">
                            <Users className="w-4 h-4 text-amber-400" />
                            <span className="text-slate-400 text-xs">A-Grade</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.topGrades}</p>
                    </CardContent>
                </Card>
            </div>

            {/* Filters */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Filter className="w-5 h-5 text-cyan-400" />
                        Map Filters & View Mode
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {/* View Mode */}
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">View Mode</label>
                            <div className="flex gap-2">
                                <Button
                                    onClick={() => setViewMode('regions')}
                                    variant={viewMode === 'regions' ? 'default' : 'outline'}
                                    className={viewMode === 'regions' ? 'bg-cyan-500' : ''}
                                >
                                    Regions
                                </Button>
                                <Button
                                    onClick={() => setViewMode('leagues')}
                                    variant={viewMode === 'leagues' ? 'default' : 'outline'}
                                    className={viewMode === 'leagues' ? 'bg-cyan-500' : ''}
                                >
                                    Leagues
                                </Button>
                                <Button
                                    onClick={() => setViewMode('archetypes')}
                                    variant={viewMode === 'archetypes' ? 'default' : 'outline'}
                                    className={viewMode === 'archetypes' ? 'bg-cyan-500' : ''}
                                >
                                    Positions
                                </Button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Min FS-AI Score</label>
                                <Input
                                    type="number"
                                    value={filters.minScore}
                                    onChange={(e) => setFilters({...filters, minScore: Number(e.target.value)})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    min="0"
                                    max="100"
                                />
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Position</label>
                                <Select value={filters.position} onValueChange={(v) => setFilters({...filters, position: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">All Positions</SelectItem>
                                        {uniquePositions.map(pos => (
                                            <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">League</label>
                                <Select value={filters.league} onValueChange={(v) => setFilters({...filters, league: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">All Leagues</SelectItem>
                                        {uniqueLeagues.map(league => (
                                            <SelectItem key={league} value={league}>{league}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Search</label>
                                <div className="relative">
                                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                    <Input
                                        value={filters.search}
                                        onChange={(e) => setFilters({...filters, search: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white pl-9"
                                        placeholder="Player name..."
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Talent Clusters Map */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-purple-400" />
                        Global Talent Clusters ({filteredPlayers.length} players)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {clusters.map((cluster) => (
                            <motion.div
                                key={cluster.name}
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className={`bg-gradient-to-br ${getClusterColor(cluster.avgScore)} border rounded-lg p-4 cursor-pointer hover:scale-105 transition-transform`}
                                onClick={() => setSelectedCluster(cluster)}
                            >
                                <div className="flex items-start justify-between mb-3">
                                    <div>
                                        <h3 className="text-white font-bold text-lg">{cluster.name}</h3>
                                        <p className="text-slate-400 text-sm">{cluster.count} players</p>
                                    </div>
                                    <Badge className="bg-white/10 text-white">
                                        {cluster.avgScore.toFixed(1)}
                                    </Badge>
                                </div>
                                <div className="flex items-center gap-2 mb-2">
                                    <div className="flex-1 bg-slate-700 rounded-full h-2">
                                        <div
                                            className={`h-2 rounded-full ${
                                                cluster.avgScore >= 85 ? 'bg-emerald-500' :
                                                cluster.avgScore >= 70 ? 'bg-cyan-500' :
                                                cluster.avgScore >= 50 ? 'bg-amber-500' :
                                                'bg-slate-500'
                                            }`}
                                            style={{ width: `${cluster.avgScore}%` }}
                                        />
                                    </div>
                                </div>
                                <div className="flex items-center justify-between text-xs">
                                    <span className="text-slate-400">A-Grade: {cluster.topGrades}</span>
                                    <ChevronRight className="w-4 h-4 text-slate-400" />
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Drill-down Modal */}
            <AnimatePresence>
                {selectedCluster && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
                        onClick={() => setSelectedCluster(null)}
                    >
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="bg-slate-900 rounded-xl border border-slate-800 max-w-4xl w-full max-h-[80vh] overflow-hidden"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="p-6 border-b border-slate-800 flex items-center justify-between">
                                <div>
                                    <h2 className="text-2xl font-bold text-white">{selectedCluster.name}</h2>
                                    <p className="text-slate-400 text-sm">{selectedCluster.count} players • Avg: {selectedCluster.avgScore.toFixed(1)}</p>
                                </div>
                                <Button onClick={() => setSelectedCluster(null)} variant="ghost">
                                    <X className="w-5 h-5" />
                                </Button>
                            </div>
                            <div className="p-6 overflow-y-auto max-h-[60vh]">
                                <div className="space-y-3">
                                    {selectedCluster.players.map((player) => (
                                        <Link
                                            key={player.id}
                                            to={createPageUrl('PlayerProfile') + `?id=${player.id}`}
                                            className="block bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                                        >
                                            <div className="flex items-center justify-between">
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-3 mb-1">
                                                        <h4 className="text-white font-semibold">{player.name}</h4>
                                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                            {player.position}
                                                        </Badge>
                                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                            {player.age}y
                                                        </Badge>
                                                    </div>
                                                    <p className="text-slate-400 text-sm">{player.current_club} • {player.league}</p>
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <div className="text-right">
                                                        <p className={`text-2xl font-bold ${getScoreColor(player.fsai_proprietary_score)}`}>
                                                            {player.fsai_proprietary_score}
                                                        </p>
                                                        <p className="text-slate-500 text-xs">FS-AI</p>
                                                    </div>
                                                    {player.fsai_investment_grade && (
                                                        <Badge className={
                                                            player.fsai_investment_grade?.startsWith('A') ? 'bg-emerald-500/20 text-emerald-400' :
                                                            player.fsai_investment_grade?.startsWith('B') ? 'bg-cyan-500/20 text-cyan-400' :
                                                            'bg-amber-500/20 text-amber-400'
                                                        }>
                                                            {player.fsai_investment_grade}
                                                        </Badge>
                                                    )}
                                                </div>
                                            </div>
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}