import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, Database, Zap, TrendingUp, Users, Globe, Network, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export default function IntelligenceBrain() {
    const { data: players = [] } = useQuery({
        queryKey: ['all-players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['all-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 500)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['all-projections'],
        queryFn: () => base44.entities.PlayerProjection.list()
    });

    const { data: alerts = [] } = useQuery({
        queryKey: ['all-alerts'],
        queryFn: () => base44.entities.Alert.list('-created_date', 100)
    });

    // Intelligence Metrics
    const scoredPlayers = players.filter(p => p.fsai_proprietary_score);
    const uniqueLeagues = [...new Set(players.map(p => p.league).filter(Boolean))];
    const uniqueNationalities = [...new Set(players.map(p => p.nationality).filter(Boolean))];
    const avgScore = scoredPlayers.length > 0 
        ? (scoredPlayers.reduce((acc, p) => acc + p.fsai_proprietary_score, 0) / scoredPlayers.length).toFixed(1)
        : 0;

    const eliteProspects = scoredPlayers.filter(p => p.fsai_proprietary_score >= 85);
    const topTier = scoredPlayers.filter(p => p.fsai_proprietary_score >= 70 && p.fsai_proprietary_score < 85);
    const emerging = scoredPlayers.filter(p => p.fsai_proprietary_score >= 55 && p.fsai_proprietary_score < 70);

    const dataPoints = {
        players: players.length,
        scored: scoredPlayers.length,
        reports: reports.length,
        projections: projections.length,
        alerts: alerts.length,
        leagues: uniqueLeagues.length,
        nationalities: uniqueNationalities.length,
        eliteProspects: eliteProspects.length
    };

    const totalIntelligencePoints = Object.values(dataPoints).reduce((a, b) => a + b, 0);
    const coverage = players.length > 0 ? ((scoredPlayers.length / players.length) * 100).toFixed(1) : 0;

    const brainPulse = {
        scale: [1, 1.05, 1],
        opacity: [0.5, 1, 0.5],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    };

    return (
        <Card className="bg-gradient-to-br from-purple-500/10 via-cyan-500/10 to-blue-500/10 border-purple-500/30 overflow-hidden">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Brain className="w-6 h-6 text-purple-400" />
                    Football Scout AI Intelligence Brain
                </CardTitle>
                <p className="text-slate-400 text-sm">Live proprietary database generating scouting intelligence</p>
            </CardHeader>
            <CardContent>
                {/* Brain Visualization */}
                <div className="relative mb-8">
                    <div className="flex items-center justify-center mb-4">
                        <div className="relative">
                            <motion.div
                                animate={brainPulse}
                                className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 blur-2xl"
                            />
                            <div className="relative w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 via-cyan-500 to-blue-600 flex items-center justify-center shadow-2xl">
                                <Brain className="w-16 h-16 text-white" />
                            </div>
                        </div>
                    </div>
                    <div className="text-center mb-6">
                        <div className="flex items-center justify-center gap-2 mb-2">
                            <motion.div
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ duration: 1.5, repeat: Infinity }}
                                className="w-2 h-2 rounded-full bg-emerald-400"
                            />
                            <p className="text-emerald-400 text-sm font-semibold">LIVE INTELLIGENCE NETWORK</p>
                        </div>
                        <h3 className="text-4xl font-bold text-white mb-1">
                            {totalIntelligencePoints.toLocaleString()}
                        </h3>
                        <p className="text-slate-400">Total Intelligence Data Points</p>
                    </div>
                </div>

                {/* Intelligence Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="bg-slate-900/50 rounded-lg p-4"
                    >
                        <Database className="w-5 h-5 text-cyan-400 mb-2" />
                        <p className="text-2xl font-bold text-white">{dataPoints.players}</p>
                        <p className="text-slate-400 text-xs">Players Tracked</p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="bg-slate-900/50 rounded-lg p-4"
                    >
                        <Brain className="w-5 h-5 text-purple-400 mb-2" />
                        <p className="text-2xl font-bold text-white">{dataPoints.scored}</p>
                        <p className="text-slate-400 text-xs">FS-AI Scored</p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="bg-slate-900/50 rounded-lg p-4"
                    >
                        <Zap className="w-5 h-5 text-amber-400 mb-2" />
                        <p className="text-2xl font-bold text-white">{dataPoints.reports}</p>
                        <p className="text-slate-400 text-xs">Scout Reports</p>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 }}
                        className="bg-slate-900/50 rounded-lg p-4"
                    >
                        <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
                        <p className="text-2xl font-bold text-white">{dataPoints.projections}</p>
                        <p className="text-slate-400 text-xs">Projections</p>
                    </motion.div>
                </div>

                {/* Coverage & Quality Metrics */}
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-slate-900/50 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-slate-400 text-sm">Coverage</span>
                            <Badge className="bg-emerald-500/20 text-emerald-400">{coverage}%</Badge>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2">
                            <div 
                                className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-2 rounded-full transition-all duration-1000"
                                style={{ width: `${coverage}%` }}
                            />
                        </div>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-slate-400 text-sm">Avg Score</span>
                            <Badge className="bg-cyan-500/20 text-cyan-400">{avgScore}/100</Badge>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2">
                            <div 
                                className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full"
                                style={{ width: `${avgScore}%` }}
                            />
                        </div>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-slate-400 text-sm">Elite Prospects</span>
                            <Badge className="bg-purple-500/20 text-purple-400">{dataPoints.eliteProspects}</Badge>
                        </div>
                        <p className="text-white text-sm">Score ≥85</p>
                    </div>
                </div>

                {/* Intelligence Distribution */}
                <div className="bg-slate-900/50 rounded-lg p-4 mb-6">
                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <Activity className="w-4 h-4 text-purple-400" />
                        Talent Distribution
                    </h4>
                    <div className="space-y-3">
                        <div>
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-slate-400 text-sm">Elite (85+)</span>
                                <span className="text-emerald-400 font-semibold">{eliteProspects.length}</span>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-2">
                                <div 
                                    className="bg-emerald-500 h-2 rounded-full"
                                    style={{ width: `${(eliteProspects.length / scoredPlayers.length) * 100}%` }}
                                />
                            </div>
                        </div>
                        <div>
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-slate-400 text-sm">Top Tier (70-84)</span>
                                <span className="text-cyan-400 font-semibold">{topTier.length}</span>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-2">
                                <div 
                                    className="bg-cyan-500 h-2 rounded-full"
                                    style={{ width: `${(topTier.length / scoredPlayers.length) * 100}%` }}
                                />
                            </div>
                        </div>
                        <div>
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-slate-400 text-sm">Emerging (55-69)</span>
                                <span className="text-amber-400 font-semibold">{emerging.length}</span>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-2">
                                <div 
                                    className="bg-amber-500 h-2 rounded-full"
                                    style={{ width: `${(emerging.length / scoredPlayers.length) * 100}%` }}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Global Reach */}
                <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-slate-900/50 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <Globe className="w-4 h-4 text-cyan-400" />
                            <span className="text-white font-semibold">Global Reach</span>
                        </div>
                        <div className="space-y-1">
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400 text-sm">Leagues</span>
                                <span className="text-cyan-400 font-semibold">{dataPoints.leagues}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400 text-sm">Nationalities</span>
                                <span className="text-purple-400 font-semibold">{dataPoints.nationalities}</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <Network className="w-4 h-4 text-emerald-400" />
                            <span className="text-white font-semibold">Intelligence Network</span>
                        </div>
                        <div className="space-y-1">
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400 text-sm">Active Alerts</span>
                                <span className="text-amber-400 font-semibold">{dataPoints.alerts}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-slate-400 text-sm">Live Tracking</span>
                                <motion.div
                                    animate={{ opacity: [1, 0.5, 1] }}
                                    transition={{ duration: 2, repeat: Infinity }}
                                    className="flex items-center gap-1"
                                >
                                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                                    <span className="text-emerald-400 font-semibold text-sm">Active</span>
                                </motion.div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Intelligence Statement */}
                <div className="mt-6 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-lg p-4">
                    <p className="text-slate-300 text-sm text-center italic">
                        "This intelligence is <span className="text-purple-400 font-semibold">proprietary to Football Scout AI</span>. 
                        Every score, insight, and projection forms our own growing database—built by AI, refined by data, owned by us."
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}