import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Scale, Loader2, Globe, TrendingUp } from 'lucide-react';
import toast from 'react-hot-toast';

export default function LeagueNormalizer({ player }) {
    const [normalizedScore, setNormalizedScore] = useState(null);
    const [isNormalizing, setIsNormalizing] = useState(false);

    const normalizeAcrossLeagues = async () => {
        setIsNormalizing(true);
        toast.loading('Normalizing across leagues...', { id: 'normalize' });

        try {
            const prompt = `You are the FS-AI League Normalization Engine. Normalize this player's performance across global league standards.

PLAYER: ${player.name}
Current League: ${player.league}
Position: ${player.position}
Age: ${player.age}
Market Value: €${player.market_value}M

Current Stats/Ratings:
${player.physical_attributes ? JSON.stringify(player.physical_attributes) : 'Not available'}

Task: Calculate the normalized score that accounts for league strength, competition level, and relative performance.

League Difficulty Multipliers (internal FS-AI standard):
- Premier League: 1.0 (baseline)
- La Liga: 0.98
- Bundesliga: 0.96
- Serie A: 0.95
- Ligue 1: 0.92
- Eredivisie: 0.85
- Championship: 0.80
- MLS: 0.75
- Saudi Pro League: 0.70
- Other leagues: estimate based on UEFA coefficients

Provide:
1. Raw Score (player's current performance in their league)
2. Normalized Score (adjusted to Premier League baseline)
3. League Difficulty Factor
4. Cross-League Percentile (where they rank globally)
5. Equivalent Performance in Top 5 Leagues
6. Adjustment Explanation`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        raw_score: { type: "number" },
                        normalized_score: { type: "number" },
                        league_difficulty_factor: { type: "number" },
                        cross_league_percentile: { type: "number" },
                        equivalent_performance: {
                            type: "object",
                            properties: {
                                premier_league: { type: "string" },
                                la_liga: { type: "string" },
                                bundesliga: { type: "string" },
                                serie_a: { type: "string" },
                                ligue_1: { type: "string" }
                            }
                        },
                        adjustment_explanation: { type: "string" },
                        global_ranking_estimate: { type: "string" },
                        transfer_value_impact: { type: "string" }
                    }
                }
            });

            // Save normalized score to player
            await base44.entities.Player.update(player.id, {
                fsai_normalized_score: response.normalized_score,
                fsai_league_factor: response.league_difficulty_factor,
                fsai_global_percentile: response.cross_league_percentile
            });

            setNormalizedScore(response);
            toast.success('League normalization complete!', { id: 'normalize' });
        } catch (error) {
            console.error('Normalization failed:', error);
            toast.error('Failed to normalize', { id: 'normalize' });
        } finally {
            setIsNormalizing(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Scale className="w-5 h-5 text-cyan-400" />
                            Cross-League Normalization
                        </CardTitle>
                        <Button
                            onClick={normalizeAcrossLeagues}
                            disabled={isNormalizing}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isNormalizing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Normalizing...
                                </>
                            ) : (
                                <>
                                    <Globe className="w-4 h-4 mr-2" />
                                    Normalize
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        Adjust performance metrics to account for league strength and competition level
                    </p>
                </CardContent>
            </Card>

            {normalizedScore && (
                <div className="space-y-6">
                    {/* Score Comparison */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="grid md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">Raw Score ({player.league})</p>
                                    <p className="text-4xl font-bold text-slate-300">
                                        {normalizedScore.raw_score.toFixed(1)}
                                    </p>
                                </div>
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">Normalized Score</p>
                                    <p className="text-4xl font-bold text-cyan-400">
                                        {normalizedScore.normalized_score.toFixed(1)}
                                    </p>
                                    <Badge className="bg-cyan-500/20 text-cyan-400 mt-2">
                                        Premier League Baseline
                                    </Badge>
                                </div>
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">Global Percentile</p>
                                    <p className="text-4xl font-bold text-emerald-400">
                                        {normalizedScore.cross_league_percentile}
                                    </p>
                                    <p className="text-slate-500 text-xs mt-1">top %</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* League Factor */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">League Difficulty Factor</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between mb-3">
                                <span className="text-slate-400">{player.league}</span>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {normalizedScore.league_difficulty_factor.toFixed(2)}x
                                </Badge>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-3">
                                <div
                                    className="bg-purple-500 h-3 rounded-full"
                                    style={{ width: `${normalizedScore.league_difficulty_factor * 100}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Equivalent Performance */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-amber-400" />
                                Equivalent Performance in Top 5 Leagues
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {Object.entries(normalizedScore.equivalent_performance).map(([league, performance]) => (
                                    <div key={league} className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center justify-between">
                                            <span className="text-white capitalize">{league.replace('_', ' ')}</span>
                                            <span className="text-cyan-400 text-sm">{performance}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Analysis */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Adjustment Explanation</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {normalizedScore.adjustment_explanation}
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Global Ranking</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {normalizedScore.global_ranking_estimate}
                                </p>
                            </CardContent>
                        </Card>
                    </div>

                    <Card className="bg-blue-500/10 border-blue-500/30">
                        <CardHeader>
                            <CardTitle className="text-blue-400">Transfer Value Impact</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">
                                {normalizedScore.transfer_value_impact}
                            </p>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}