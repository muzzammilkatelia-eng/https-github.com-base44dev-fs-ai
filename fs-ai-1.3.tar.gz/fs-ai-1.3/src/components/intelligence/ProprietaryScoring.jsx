import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, Loader2, Zap, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ProprietaryScoring({ player, onScoreGenerated }) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [fsaiScore, setFsaiScore] = useState(null);

    const generateProprietaryScore = async () => {
        setIsGenerating(true);
        toast.loading('Generating FS-AI Proprietary Score...', { id: 'fsai-score' });

        try {
            const reports = await base44.entities.ScoutingReport.filter({ player_name: player.name });
            const projection = (await base44.entities.PlayerProjection.list()).find(
                p => p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            const prompt = `You are the FS-AI Intelligence Engine. Generate a proprietary multi-dimensional player score that goes beyond traditional metrics.

PLAYER: ${player.name}
Position: ${player.position}
Age: ${player.age}
League: ${player.league}
Market Value: €${player.market_value}M

PHYSICAL DATA:
${JSON.stringify(player.physical_attributes || {}, null, 2)}

PLAYING STYLE:
${JSON.stringify(player.playing_style || {}, null, 2)}

SCOUTING DATA (${reports.length} reports):
${reports.slice(0, 3).map(r => `
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10
- Physical: ${r.physical_rating}/10
- Mental: ${r.mental_rating}/10
- Tactical: ${r.tactical_rating}/10
- Recommendation: ${r.recommendation}
`).join('\n')}

PROJECTION:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Potential: ${projection.peak_potential_rating}/10
` : 'No projection available'}

Generate the FS-AI Proprietary Score (0-100) across these dimensions:

1. **Technical Mastery** (0-100): Raw technical ability, skill execution, ball control
2. **Physical Dominance** (0-100): Athleticism, pace, strength, stamina
3. **Mental Fortitude** (0-100): Decision-making, composure, game intelligence
4. **Tactical Awareness** (0-100): Positioning, system understanding, adaptability
5. **Development Velocity** (0-100): Rate of improvement, learning curve, coachability
6. **Market Efficiency** (0-100): Value relative to ability, contract situation, transferability
7. **Archetype Purity** (0-100): How well player fits their defined archetype
8. **Injury Resilience** (0-100): Durability, injury history, physical robustness

Also provide:
- Overall FS-AI Score (weighted average, 0-100)
- Confidence Level (0-100)
- Key Differentiators (what makes this player unique)
- Comp Players (similar FS-AI profiles)
- Investment Grade (A+ to F)`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        technical_mastery: { type: "number" },
                        physical_dominance: { type: "number" },
                        mental_fortitude: { type: "number" },
                        tactical_awareness: { type: "number" },
                        development_velocity: { type: "number" },
                        market_efficiency: { type: "number" },
                        archetype_purity: { type: "number" },
                        injury_resilience: { type: "number" },
                        overall_fsai_score: { type: "number" },
                        confidence_level: { type: "number" },
                        investment_grade: {
                            type: "string",
                            enum: ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"]
                        },
                        key_differentiators: {
                            type: "array",
                            items: { type: "string" }
                        },
                        comparable_players: {
                            type: "array",
                            items: { type: "string" }
                        },
                        score_breakdown: { type: "string" },
                        investment_rationale: { type: "string" }
                    }
                }
            });

            // Save to player record
            await base44.entities.Player.update(player.id, {
                fsai_proprietary_score: response.overall_fsai_score,
                fsai_score_breakdown: {
                    technical_mastery: response.technical_mastery,
                    physical_dominance: response.physical_dominance,
                    mental_fortitude: response.mental_fortitude,
                    tactical_awareness: response.tactical_awareness,
                    development_velocity: response.development_velocity,
                    market_efficiency: response.market_efficiency,
                    archetype_purity: response.archetype_purity,
                    injury_resilience: response.injury_resilience
                },
                fsai_investment_grade: response.investment_grade,
                fsai_score_timestamp: new Date().toISOString()
            });

            setFsaiScore(response);
            if (onScoreGenerated) onScoreGenerated(response);
            toast.success('FS-AI Proprietary Score Generated!', { id: 'fsai-score' });
        } catch (error) {
            console.error('Score generation failed:', error);
            toast.error('Failed to generate score', { id: 'fsai-score' });
        } finally {
            setIsGenerating(false);
        }
    };

    const getGradeColor = (grade) => {
        if (grade?.startsWith('A')) return 'bg-emerald-500/20 text-emerald-400';
        if (grade?.startsWith('B')) return 'bg-cyan-500/20 text-cyan-400';
        if (grade?.startsWith('C')) return 'bg-amber-500/20 text-amber-400';
        return 'bg-red-500/20 text-red-400';
    };

    const getScoreColor = (score) => {
        if (score >= 85) return 'text-emerald-400';
        if (score >= 70) return 'text-cyan-400';
        if (score >= 50) return 'text-amber-400';
        return 'text-red-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Brain className="w-5 h-5 text-purple-400" />
                            FS-AI Proprietary Intelligence Score
                        </CardTitle>
                        <Button
                            onClick={generateProprietaryScore}
                            disabled={isGenerating}
                            className="bg-gradient-to-r from-purple-500 to-blue-600"
                        >
                            {isGenerating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Zap className="w-4 h-4 mr-2" />
                                    Generate Score
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        Proprietary multi-dimensional intelligence scoring beyond traditional metrics
                    </p>
                </CardContent>
            </Card>

            {fsaiScore && (
                <div className="space-y-6">
                    {/* Overall Score */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="grid md:grid-cols-3 gap-6">
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">FS-AI Score</p>
                                    <p className={`text-5xl font-bold ${getScoreColor(fsaiScore.overall_fsai_score)}`}>
                                        {fsaiScore.overall_fsai_score}
                                    </p>
                                    <p className="text-slate-500 text-xs mt-1">/100</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">Investment Grade</p>
                                    <Badge className={`${getGradeColor(fsaiScore.investment_grade)} text-2xl px-4 py-2`}>
                                        {fsaiScore.investment_grade}
                                    </Badge>
                                </div>
                                <div className="text-center">
                                    <p className="text-slate-400 text-sm mb-2">Confidence</p>
                                    <p className="text-3xl font-bold text-cyan-400">
                                        {fsaiScore.confidence_level}%
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* 8 Dimensions */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">8-Dimensional Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {[
                                    { key: 'technical_mastery', label: 'Technical Mastery', icon: '⚡' },
                                    { key: 'physical_dominance', label: 'Physical Dominance', icon: '💪' },
                                    { key: 'mental_fortitude', label: 'Mental Fortitude', icon: '🧠' },
                                    { key: 'tactical_awareness', label: 'Tactical Awareness', icon: '♟️' },
                                    { key: 'development_velocity', label: 'Development Velocity', icon: '📈' },
                                    { key: 'market_efficiency', label: 'Market Efficiency', icon: '💰' },
                                    { key: 'archetype_purity', label: 'Archetype Purity', icon: '🎯' },
                                    { key: 'injury_resilience', label: 'Injury Resilience', icon: '🛡️' }
                                ].map(({ key, label, icon }) => (
                                    <div key={key} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-slate-300 text-sm flex items-center gap-2">
                                                <span>{icon}</span>
                                                {label}
                                            </span>
                                            <span className={`font-bold ${getScoreColor(fsaiScore[key])}`}>
                                                {fsaiScore[key]}
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-700 rounded-full h-2">
                                            <div
                                                className={`h-2 rounded-full ${
                                                    fsaiScore[key] >= 85 ? 'bg-emerald-500' :
                                                    fsaiScore[key] >= 70 ? 'bg-cyan-500' :
                                                    fsaiScore[key] >= 50 ? 'bg-amber-500' :
                                                    'bg-red-500'
                                                }`}
                                                style={{ width: `${fsaiScore[key]}%` }}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Key Differentiators */}
                    {fsaiScore.key_differentiators && fsaiScore.key_differentiators.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Zap className="w-5 h-5 text-amber-400" />
                                    Key Differentiators
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {fsaiScore.key_differentiators.map((diff, idx) => (
                                        <div key={idx} className="flex items-start gap-2">
                                            <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                            <span className="text-slate-300 text-sm">{diff}</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Comparable Players */}
                    {fsaiScore.comparable_players && fsaiScore.comparable_players.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Similar FS-AI Profiles</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {fsaiScore.comparable_players.map((player, idx) => (
                                        <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                            {player}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Analysis */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-lg">Score Breakdown</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {fsaiScore.score_breakdown}
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-blue-500/10 border-blue-500/30">
                            <CardHeader>
                                <CardTitle className="text-blue-400 text-lg">Investment Rationale</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {fsaiScore.investment_rationale}
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            )}
        </div>
    );
}