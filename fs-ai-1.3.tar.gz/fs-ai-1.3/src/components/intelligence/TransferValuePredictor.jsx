import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { DollarSign, Loader2, TrendingUp, TrendingDown, Clock, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TransferValuePredictor() {
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const { data: players = [] } = useQuery({
        queryKey: ['players-value'],
        queryFn: () => base44.entities.Player.list('-market_value', 100)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports-value'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const analyzeValues = async () => {
        setLoading(true);
        toast.loading('AI analyzing transfer values...', { id: 'value-analysis' });

        try {
            const playerData = players.slice(0, 40).map(p => ({
                name: p.name,
                age: p.age,
                position: p.position,
                club: p.current_club,
                league: p.league,
                current_value: p.market_value,
                contract_expiry: p.contract_expiry,
                fsai_score: p.fsai_proprietary_score,
                recent_stats: p.career_history?.[0]
            }));

            const reportContext = reports.slice(0, 20).map(r => ({
                player: r.player_name,
                recommendation: r.recommendation,
                modules: r.modules_activated
            }));

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a transfer market valuation expert. Analyze player values and predict fair market prices.

PLAYER DATABASE:
${JSON.stringify(playerData, null, 2)}

SCOUTING INTELLIGENCE:
${JSON.stringify(reportContext, null, 2)}

For each player, analyze:
1. Current market value vs true value based on performance/potential
2. Optimal timing for signing (now, summer, wait)
3. Value trajectory (increasing/decreasing/stable)

Return JSON with "valuations" array of 12-15 players with significant findings:
- player_name: string
- current_value: number (millions)
- fair_value: number (millions)
- value_difference_percent: number (positive = undervalued)
- optimal_timing: "Immediate" | "Summer 2025" | "Winter 2025" | "Wait - Declining"
- timing_reasoning: string (1 sentence)
- trajectory: "Rising" | "Peak" | "Stable" | "Declining"
- confidence: number (0-100)
- key_insight: string (1-2 sentences)`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        valuations: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    current_value: { type: 'number' },
                                    fair_value: { type: 'number' },
                                    value_difference_percent: { type: 'number' },
                                    optimal_timing: { type: 'string' },
                                    timing_reasoning: { type: 'string' },
                                    trajectory: { type: 'string' },
                                    confidence: { type: 'number' },
                                    key_insight: { type: 'string' }
                                }
                            }
                        }
                    }
                }
            });

            setAnalysis(result.valuations || []);
            toast.success('Value analysis complete!', { id: 'value-analysis' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'value-analysis' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const filteredAnalysis = analysis?.filter(v => 
        v.player_name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const trajectoryIcons = {
        'Rising': <TrendingUp className="w-4 h-4 text-emerald-400" />,
        'Peak': <DollarSign className="w-4 h-4 text-amber-400" />,
        'Stable': <Clock className="w-4 h-4 text-blue-400" />,
        'Declining': <TrendingDown className="w-4 h-4 text-red-400" />
    };

    const timingColors = {
        'Immediate': 'bg-red-500/20 text-red-400 border-red-500/30',
        'Summer 2025': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Winter 2025': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        'Wait - Declining': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                    <DollarSign className="w-5 h-5 text-emerald-400" />
                    AI Transfer Value Predictor
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-8">
                        <DollarSign className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">
                            Analyze fair transfer values and optimal signing timing
                        </p>
                        <Button
                            onClick={analyzeValues}
                            disabled={loading}
                            className="bg-gradient-to-r from-emerald-500 to-cyan-600"
                        >
                            {loading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                            ) : (
                                <><DollarSign className="w-4 h-4 mr-2" /> Analyze Values</>
                            )}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex items-center gap-2">
                            <Search className="w-4 h-4 text-slate-400" />
                            <Input
                                placeholder="Filter players..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div className="space-y-3 max-h-[500px] overflow-y-auto">
                            {filteredAnalysis?.map((val, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                                >
                                    <div className="flex items-start justify-between mb-2">
                                        <div>
                                            <h4 className="text-white font-bold">{val.player_name}</h4>
                                            <div className="flex items-center gap-2 mt-1">
                                                <Badge className={timingColors[val.optimal_timing] || timingColors['Summer 2025']}>
                                                    {val.optimal_timing}
                                                </Badge>
                                                <span className="flex items-center gap-1 text-slate-400 text-sm">
                                                    {trajectoryIcons[val.trajectory]} {val.trajectory}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className={`text-xl font-bold ${val.value_difference_percent > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                                {val.value_difference_percent > 0 ? '+' : ''}{val.value_difference_percent}%
                                            </div>
                                            <p className="text-slate-500 text-xs">Value Gap</p>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4 mb-2 text-sm">
                                        <div>
                                            <span className="text-slate-400">Current:</span>
                                            <span className="text-white ml-2">€{val.current_value}M</span>
                                        </div>
                                        <div>
                                            <span className="text-slate-400">Fair Value:</span>
                                            <span className="text-emerald-400 ml-2 font-semibold">€{val.fair_value}M</span>
                                        </div>
                                    </div>

                                    <p className="text-slate-300 text-sm mb-2">{val.key_insight}</p>
                                    <p className="text-slate-500 text-xs italic">{val.timing_reasoning}</p>

                                    <div className="mt-2 flex items-center justify-between">
                                        <span className="text-slate-500 text-xs">Confidence: {val.confidence}%</span>
                                        <div className="w-24 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-cyan-400 rounded-full"
                                                style={{ width: `${val.confidence}%` }}
                                            />
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        <Button onClick={analyzeValues} variant="outline" className="w-full border-slate-700">
                            Re-analyze Values
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}