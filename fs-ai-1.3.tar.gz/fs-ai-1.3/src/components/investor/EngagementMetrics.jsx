import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Activity, FileText, MessageSquare } from 'lucide-react';
import moment from 'moment';

export default function EngagementMetrics() {
    const [chartData, setChartData] = useState([]);
    const [stats, setStats] = useState({ reports: 0, messages: 0, avgReportsPerScout: 0 });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadEngagementData();
    }, []);

    const loadEngagementData = async () => {
        try {
            const [reports, messages, scouts] = await Promise.all([
                base44.entities.ScoutingReport.list('-created_date'),
                base44.entities.ScoutMessage.list('-created_date'),
                base44.entities.Scout.list()
            ]);

            // Group by month
            const monthlyData = {};

            reports.forEach(report => {
                const month = moment(report.created_date).format('MMM YYYY');
                if (!monthlyData[month]) {
                    monthlyData[month] = { reports: 0, messages: 0 };
                }
                monthlyData[month].reports++;
            });

            messages.forEach(message => {
                const month = moment(message.created_date).format('MMM YYYY');
                if (!monthlyData[month]) {
                    monthlyData[month] = { reports: 0, messages: 0 };
                }
                monthlyData[month].messages++;
            });

            // Convert to chart array
            const chartArray = Object.entries(monthlyData)
                .sort((a, b) => moment(a[0], 'MMM YYYY').valueOf() - moment(b[0], 'MMM YYYY').valueOf())
                .map(([month, data]) => ({
                    month,
                    reports: data.reports,
                    messages: data.messages
                }));

            setChartData(chartArray);

            // Calculate current month stats
            const currentMonth = moment().format('MMM YYYY');
            const currentMonthReports = monthlyData[currentMonth]?.reports || 0;
            const currentMonthMessages = monthlyData[currentMonth]?.messages || 0;
            const avgReportsPerScout = scouts.length > 0 ? (reports.length / scouts.length).toFixed(1) : 0;

            setStats({ 
                reports: currentMonthReports, 
                messages: currentMonthMessages,
                avgReportsPerScout 
            });

            // Update summary card
            document.getElementById('reports-count').textContent = currentMonthReports;
        } catch (error) {
            console.error('Failed to load engagement data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center py-12 text-slate-400">Loading engagement data...</div>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Activity className="w-5 h-5 text-cyan-400" />
                        Platform Activity Over Time
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="reports" stroke="#06b6d4" strokeWidth={2} name="Reports Generated" />
                            <Line type="monotone" dataKey="messages" stroke="#8b5cf6" strokeWidth={2} name="Messages Sent" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-emerald-400" />
                        Monthly Report Generation
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Bar dataKey="reports" fill="#10b981" name="Reports" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid grid-cols-3 gap-4">
                <Card className="bg-cyan-500/10 border-cyan-500/30">
                    <CardContent className="pt-6">
                        <p className="text-cyan-400 text-sm mb-2">Reports This Month</p>
                        <p className="text-3xl font-bold text-white">{stats.reports}</p>
                    </CardContent>
                </Card>
                <Card className="bg-purple-500/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <p className="text-purple-400 text-sm mb-2">Messages This Month</p>
                        <p className="text-3xl font-bold text-white">{stats.messages}</p>
                    </CardContent>
                </Card>
                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <p className="text-emerald-400 text-sm mb-2">Avg Reports/Scout</p>
                        <p className="text-3xl font-bold text-white">{stats.avgReportsPerScout}</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}