import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Mail, Send, UserPlus, Trash2, Calendar, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function InvestorContactManager() {
    const [showAddDialog, setShowAddDialog] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        company: '',
        report_frequency: 'monthly',
        metrics_included: ['user_growth', 'mrr', 'engagement', 'partnerships'],
        notes: ''
    });

    const queryClient = useQueryClient();

    const { data: contacts = [], isLoading } = useQuery({
        queryKey: ['investor-contacts'],
        queryFn: () => base44.entities.InvestorContact.list('-created_date')
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.InvestorContact.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['investor-contacts'] });
            setShowAddDialog(false);
            setFormData({
                name: '',
                email: '',
                company: '',
                report_frequency: 'monthly',
                metrics_included: ['user_growth', 'mrr', 'engagement', 'partnerships'],
                notes: ''
            });
            toast.success('Investor contact added');
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.InvestorContact.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['investor-contacts'] });
            toast.success('Contact updated');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.InvestorContact.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['investor-contacts'] });
            toast.success('Contact removed');
        }
    });

    const sendReportMutation = useMutation({
        mutationFn: async (frequency) => {
            return await base44.functions.generateInvestorReport({ frequency });
        },
        onSuccess: (result) => {
            queryClient.invalidateQueries({ queryKey: ['investor-contacts'] });
            if (result.success) {
                toast.success(`Reports sent to ${result.reportsSent} investor(s)`);
            } else {
                toast.error('Failed to send reports');
            }
        },
        onError: () => {
            toast.error('Enable backend functions first to send reports');
        }
    });

    const handleMetricToggle = (metric) => {
        const updated = formData.metrics_included.includes(metric)
            ? formData.metrics_included.filter(m => m !== metric)
            : [...formData.metrics_included, metric];
        setFormData({ ...formData, metrics_included: updated });
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Mail className="w-5 h-5 text-purple-400" />
                            Automated Investor Reporting
                        </CardTitle>
                        <div className="flex gap-2">
                            <Button
                                onClick={() => sendReportMutation.mutate('monthly')}
                                disabled={sendReportMutation.isPending}
                                variant="outline"
                                className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
                            >
                                <Send className="w-4 h-4 mr-2" />
                                Send Monthly Now
                            </Button>
                            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                                <DialogTrigger asChild>
                                    <Button className="bg-gradient-to-r from-purple-500 to-indigo-600">
                                        <UserPlus className="w-4 h-4 mr-2" />
                                        Add Investor
                                    </Button>
                                </DialogTrigger>
                                <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
                                    <DialogHeader>
                                        <DialogTitle className="text-white">Add Investor Contact</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <Label className="text-slate-400">Name *</Label>
                                                <Input
                                                    value={formData.name}
                                                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                                />
                                            </div>
                                            <div>
                                                <Label className="text-slate-400">Email *</Label>
                                                <Input
                                                    type="email"
                                                    value={formData.email}
                                                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                                />
                                            </div>
                                        </div>

                                        <div>
                                            <Label className="text-slate-400">Company</Label>
                                            <Input
                                                value={formData.company}
                                                onChange={(e) => setFormData({...formData, company: e.target.value})}
                                                className="bg-slate-800 border-slate-700 text-white mt-1"
                                            />
                                        </div>

                                        <div>
                                            <Label className="text-slate-400">Report Frequency</Label>
                                            <Select 
                                                value={formData.report_frequency}
                                                onValueChange={(v) => setFormData({...formData, report_frequency: v})}
                                            >
                                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="monthly">Monthly</SelectItem>
                                                    <SelectItem value="quarterly">Quarterly</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        <div>
                                            <Label className="text-slate-400 mb-2 block">Metrics to Include</Label>
                                            <div className="space-y-2">
                                                {[
                                                    { value: 'user_growth', label: 'User Growth' },
                                                    { value: 'mrr', label: 'Monthly Recurring Revenue' },
                                                    { value: 'engagement', label: 'Engagement Metrics' },
                                                    { value: 'partnerships', label: 'Partnership Metrics' }
                                                ].map((metric) => (
                                                    <div key={metric.value} className="flex items-center space-x-2">
                                                        <Checkbox
                                                            checked={formData.metrics_included.includes(metric.value)}
                                                            onCheckedChange={() => handleMetricToggle(metric.value)}
                                                        />
                                                        <label className="text-sm text-slate-300">{metric.label}</label>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        <div>
                                            <Label className="text-slate-400">Notes</Label>
                                            <Textarea
                                                value={formData.notes}
                                                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                                                className="bg-slate-800 border-slate-700 text-white mt-1"
                                                rows={3}
                                            />
                                        </div>

                                        <Button
                                            onClick={() => createMutation.mutate(formData)}
                                            disabled={!formData.name || !formData.email || createMutation.isPending}
                                            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600"
                                        >
                                            <UserPlus className="w-4 h-4 mr-2" />
                                            Add Contact
                                        </Button>
                                    </div>
                                </DialogContent>
                            </Dialog>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        Configure automated report delivery to investors. Reports are generated and sent via email at the specified frequency.
                    </p>
                </CardContent>
            </Card>

            {/* Contact List */}
            <div className="grid grid-cols-1 gap-4">
                {contacts.map((contact, idx) => (
                    <motion.div
                        key={contact.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <h4 className="text-white font-semibold">{contact.name}</h4>
                                            {contact.company && (
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    {contact.company}
                                                </Badge>
                                            )}
                                            <Badge className={
                                                contact.active 
                                                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                                    : 'bg-slate-700 text-slate-400'
                                            }>
                                                {contact.active ? 'Active' : 'Inactive'}
                                            </Badge>
                                        </div>
                                        
                                        <p className="text-slate-400 text-sm mb-3">{contact.email}</p>

                                        <div className="flex items-center gap-4 text-sm">
                                            <div className="flex items-center gap-1 text-slate-400">
                                                <Calendar className="w-4 h-4" />
                                                <span className="capitalize">{contact.report_frequency}</span>
                                            </div>
                                            {contact.last_report_sent && (
                                                <div className="flex items-center gap-1 text-emerald-400">
                                                    <CheckCircle className="w-4 h-4" />
                                                    <span>Last sent: {moment(contact.last_report_sent).fromNow()}</span>
                                                </div>
                                            )}
                                        </div>

                                        {contact.metrics_included && contact.metrics_included.length > 0 && (
                                            <div className="flex flex-wrap gap-1 mt-3">
                                                {contact.metrics_included.map((metric) => (
                                                    <span key={metric} className="px-2 py-1 bg-purple-500/10 text-purple-400 text-xs rounded border border-purple-500/30">
                                                        {metric.replace('_', ' ')}
                                                    </span>
                                                ))}
                                            </div>
                                        )}

                                        {contact.notes && (
                                            <p className="text-slate-500 text-xs mt-2 italic">{contact.notes}</p>
                                        )}
                                    </div>

                                    <div className="flex gap-2">
                                        <Button
                                            size="sm"
                                            onClick={() => updateMutation.mutate({ 
                                                id: contact.id, 
                                                data: { active: !contact.active } 
                                            })}
                                            variant="outline"
                                            className="border-slate-700 text-slate-400"
                                        >
                                            {contact.active ? 'Deactivate' : 'Activate'}
                                        </Button>
                                        <Button
                                            size="sm"
                                            onClick={() => {
                                                if (confirm(`Remove ${contact.name}?`)) {
                                                    deleteMutation.mutate(contact.id);
                                                }
                                            }}
                                            variant="outline"
                                            className="border-red-500/30 text-red-400 hover:bg-red-500/20"
                                        >
                                            <Trash2 className="w-3 h-3" />
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {contacts.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Mail className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No investor contacts added yet</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}