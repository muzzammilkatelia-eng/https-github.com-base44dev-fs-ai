import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { DollarSign, TrendingUp } from 'lucide-react';
import moment from 'moment';

export default function MRRChart() {
    const [chartData, setChartData] = useState([]);
    const [productBreakdown, setProductBreakdown] = useState([]);
    const [stats, setStats] = useState({ mrr: 0, arr: 0, avgDeal: 0 });
    const [isLoading, setIsLoading] = useState(true);

    const COLORS = ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

    useEffect(() => {
        loadRevenueData();
    }, []);

    const loadRevenueData = async () => {
        try {
            const sales = await base44.entities.Sale.list('-created_date');

            // Group by month
            const monthlyRevenue = {};
            const productRevenue = {};

            sales.forEach(sale => {
                const month = moment(sale.created_date).format('MMM YYYY');
                
                if (!monthlyRevenue[month]) {
                    monthlyRevenue[month] = { total: 0, count: 0 };
                }
                
                const amount = sale.amount || 0;
                const monthlyAmount = sale.subscription_period === 'annual' ? amount / 12 : amount;
                
                monthlyRevenue[month].total += monthlyAmount;
                monthlyRevenue[month].count += 1;

                // Product breakdown
                productRevenue[sale.product_type] = (productRevenue[sale.product_type] || 0) + monthlyAmount;
            });

            // Convert to chart array
            const chartArray = Object.entries(monthlyRevenue)
                .sort((a, b) => moment(a[0], 'MMM YYYY').valueOf() - moment(b[0], 'MMM YYYY').valueOf())
                .map(([month, data]) => ({
                    month,
                    mrr: Math.round(data.total),
                    deals: data.count
                }));

            setChartData(chartArray);

            // Product breakdown for pie chart
            const productArray = Object.entries(productRevenue).map(([name, value]) => ({
                name,
                value: Math.round(value)
            }));
            setProductBreakdown(productArray);

            // Calculate stats
            const currentMRR = chartArray[chartArray.length - 1]?.mrr || 0;
            const arr = currentMRR * 12;
            const avgDeal = sales.length > 0 ? sales.reduce((sum, s) => sum + (s.amount || 0), 0) / sales.length : 0;

            setStats({ mrr: currentMRR, arr, avgDeal: Math.round(avgDeal) });

            // Update summary card
            document.getElementById('mrr-count').textContent = `£${currentMRR.toLocaleString()}`;
        } catch (error) {
            console.error('Failed to load revenue data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center py-12 text-slate-400">Loading revenue data...</div>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                        Monthly Recurring Revenue (MRR)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                                formatter={(value) => `£${value.toLocaleString()}`}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="mrr" stroke="#10b981" strokeWidth={3} name="MRR (£)" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Revenue by Product Type</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={productBreakdown}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                    outerRadius={100}
                                    fill="#8884d8"
                                    dataKey="value"
                                >
                                    {productBreakdown.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(value) => `£${value.toLocaleString()}`} />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Monthly Deals Closed</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="month" stroke="#94a3b8" />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                    labelStyle={{ color: '#e2e8f0' }}
                                />
                                <Bar dataKey="deals" fill="#06b6d4" name="Deals Closed" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-3 gap-4">
                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <p className="text-emerald-400 text-sm mb-2">Current MRR</p>
                        <p className="text-3xl font-bold text-white">£{stats.mrr.toLocaleString()}</p>
                    </CardContent>
                </Card>
                <Card className="bg-purple-500/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <p className="text-purple-400 text-sm mb-2">Annual Run Rate (ARR)</p>
                        <p className="text-3xl font-bold text-white">£{stats.arr.toLocaleString()}</p>
                    </CardContent>
                </Card>
                <Card className="bg-cyan-500/10 border-cyan-500/30">
                    <CardContent className="pt-6">
                        <p className="text-cyan-400 text-sm mb-2">Average Deal Size</p>
                        <p className="text-3xl font-bold text-white">£{stats.avgDeal.toLocaleString()}</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}