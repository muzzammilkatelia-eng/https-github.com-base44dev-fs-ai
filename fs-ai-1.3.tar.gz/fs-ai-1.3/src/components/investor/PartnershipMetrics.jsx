import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users, CheckCircle, Clock } from 'lucide-react';
import moment from 'moment';

export default function PartnershipMetrics() {
    const [conversionData, setConversionData] = useState([]);
    const [stats, setStats] = useState({ totalScouts: 0, activeScouts: 0, conversionRate: 0 });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadPartnershipData();
    }, []);

    const loadPartnershipData = async () => {
        try {
            const scouts = await base44.entities.Scout.list('-created_date');

            // Calculate conversion funnel
            const totalScouts = scouts.length;
            const byStatus = {
                'Prospect': scouts.filter(s => s.status === 'Prospect').length,
                'Vetting': scouts.filter(s => s.status === 'Vetting').length,
                'Active': scouts.filter(s => s.status === 'Active').length,
                'Inactive': scouts.filter(s => s.status === 'Inactive').length,
                'Rejected': scouts.filter(s => s.status === 'Rejected').length
            };

            const conversionArray = Object.entries(byStatus).map(([status, count]) => ({
                status,
                count,
                percentage: totalScouts > 0 ? ((count / totalScouts) * 100).toFixed(1) : 0
            }));

            setConversionData(conversionArray);

            // Calculate stats
            const activeScouts = byStatus['Active'];
            const conversionRate = totalScouts > 0 ? ((activeScouts / totalScouts) * 100).toFixed(1) : 0;

            setStats({ totalScouts, activeScouts, conversionRate });
        } catch (error) {
            console.error('Failed to load partnership data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center py-12 text-slate-400">Loading partnership data...</div>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-amber-400" />
                        Scout Conversion Funnel
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <BarChart data={conversionData} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis type="number" stroke="#94a3b8" />
                            <YAxis dataKey="status" type="category" stroke="#94a3b8" width={100} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                                formatter={(value, name, props) => [`${value} (${props.payload.percentage}%)`, 'Count']}
                            />
                            <Bar dataKey="count" fill="#f59e0b" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Pipeline Health</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {conversionData.map((item, index) => (
                            <div key={index}>
                                <div className="flex justify-between mb-2">
                                    <span className="text-slate-400 text-sm">{item.status}</span>
                                    <span className="text-white text-sm font-semibold">{item.count} ({item.percentage}%)</span>
                                </div>
                                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                    <div 
                                        className="h-full bg-gradient-to-r from-amber-500 to-orange-500"
                                        style={{ width: `${item.percentage}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <div className="space-y-4">
                    <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <p className="text-amber-400 text-sm mb-2">Total Scout Network</p>
                                    <p className="text-4xl font-bold text-white">{stats.totalScouts}</p>
                                </div>
                                <Users className="w-10 h-10 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <p className="text-emerald-400 text-sm mb-2">Active Scouts</p>
                                    <p className="text-4xl font-bold text-white">{stats.activeScouts}</p>
                                </div>
                                <CheckCircle className="w-10 h-10 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div>
                                    <p className="text-purple-400 text-sm mb-2">Conversion Rate</p>
                                    <p className="text-4xl font-bold text-white">{stats.conversionRate}%</p>
                                </div>
                                <Clock className="w-10 h-10 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}