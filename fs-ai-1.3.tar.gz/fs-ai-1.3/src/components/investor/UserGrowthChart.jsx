import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users, TrendingUp } from 'lucide-react';
import moment from 'moment';

export default function UserGrowthChart() {
    const [chartData, setChartData] = useState([]);
    const [stats, setStats] = useState({ total: 0, growthRate: 0, activeScouts: 0 });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadGrowthData();
    }, []);

    const loadGrowthData = async () => {
        try {
            const [scouts, users] = await Promise.all([
                base44.entities.Scout.list(),
                base44.entities.User.list()
            ]);

            // Group by month
            const monthlyData = {};
            
            [...scouts, ...users].forEach(item => {
                const month = moment(item.created_date).format('MMM YYYY');
                if (!monthlyData[month]) {
                    monthlyData[month] = { scouts: 0, clubs: 0, total: 0 };
                }
                
                if (item.full_name) { // Scout
                    monthlyData[month].scouts++;
                } else { // Club/User
                    monthlyData[month].clubs++;
                }
                monthlyData[month].total++;
            });

            // Convert to array and calculate cumulative
            let cumulative = 0;
            const chartArray = Object.entries(monthlyData)
                .sort((a, b) => moment(a[0], 'MMM YYYY').valueOf() - moment(b[0], 'MMM YYYY').valueOf())
                .map(([month, data]) => {
                    cumulative += data.total;
                    return {
                        month,
                        scouts: data.scouts,
                        clubs: data.clubs,
                        total: data.total,
                        cumulative
                    };
                });

            setChartData(chartArray);

            // Calculate stats
            const totalUsers = scouts.length + users.length;
            const activeScouts = scouts.filter(s => s.status === 'Active').length;
            
            // Calculate growth rate (last 2 months)
            const lastMonthTotal = chartArray[chartArray.length - 1]?.total || 0;
            const prevMonthTotal = chartArray[chartArray.length - 2]?.total || 1;
            const growthRate = ((lastMonthTotal - prevMonthTotal) / prevMonthTotal * 100).toFixed(1);

            setStats({ total: totalUsers, growthRate, activeScouts });

            // Update summary card
            document.getElementById('total-users-count').textContent = totalUsers;
            document.getElementById('growth-rate').textContent = `${growthRate}%`;
        } catch (error) {
            console.error('Failed to load growth data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center py-12 text-slate-400">Loading growth data...</div>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-purple-400" />
                        Cumulative User Growth
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="cumulative" stroke="#a855f7" strokeWidth={3} name="Total Users" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-cyan-400" />
                        Monthly New Users by Type
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={350}>
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="month" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Legend />
                            <Bar dataKey="scouts" fill="#06b6d4" name="Scouts" />
                            <Bar dataKey="clubs" fill="#8b5cf6" name="Clubs" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid grid-cols-3 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <p className="text-slate-400 text-sm mb-2">Total Users</p>
                        <p className="text-3xl font-bold text-purple-400">{stats.total}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <p className="text-slate-400 text-sm mb-2">Active Scouts</p>
                        <p className="text-3xl font-bold text-cyan-400">{stats.activeScouts}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <p className="text-slate-400 text-sm mb-2">Growth Rate (MoM)</p>
                        <p className="text-3xl font-bold text-emerald-400">{stats.growthRate}%</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}