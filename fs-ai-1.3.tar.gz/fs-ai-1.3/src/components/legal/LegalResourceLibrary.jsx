import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, ExternalLink } from 'lucide-react';

export default function LegalResourceLibrary() {
    const { data: documents = [], isLoading } = useQuery({
        queryKey: ['legalResources'],
        queryFn: async () => {
            const docs = await base44.entities.SecureDocument.filter({
                approval_status: 'Approved',
                access_level: 'Public'
            });
            return docs.filter(doc => doc.tags?.includes('legal'));
        }
    });

    if (isLoading) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <p className="text-slate-400 text-center">Loading resources...</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-cyan-400" />
                    Legal Resources Library
                </CardTitle>
            </CardHeader>
            <CardContent>
                {documents.length === 0 ? (
                    <p className="text-slate-400 text-center py-8">
                        No documents uploaded yet
                    </p>
                ) : (
                    <div className="space-y-3">
                        {documents.map((doc) => (
                            <div
                                key={doc.id}
                                className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-all"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-cyan-500/20 rounded">
                                        <FileText className="w-5 h-5 text-cyan-400" />
                                    </div>
                                    <div>
                                        <h3 className="text-white font-medium">{doc.title}</h3>
                                        <p className="text-slate-400 text-sm">
                                            {doc.document_type} • {(doc.file_size / 1024 / 1024).toFixed(2)} MB
                                        </p>
                                    </div>
                                </div>
                                <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                                    <Button variant="outline" size="sm" className="border-cyan-500/50 text-cyan-400">
                                        <Download className="w-4 h-4 mr-2" />
                                        Download
                                    </Button>
                                </a>
                            </div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}