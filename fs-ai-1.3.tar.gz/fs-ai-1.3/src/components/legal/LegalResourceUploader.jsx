import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { Upload, FileText, Check, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function LegalResourceUploader() {
    const [uploading, setUploading] = useState(false);
    const [title, setTitle] = useState('');
    const [docType, setDocType] = useState('Other');
    const [file, setFile] = useState(null);

    const handleUpload = async (e) => {
        e.preventDefault();
        if (!file || !title) {
            toast.error('Please provide a title and file');
            return;
        }

        setUploading(true);
        try {
            // Upload file
            const { file_url } = await base44.integrations.Core.UploadFile({ file });

            // Store in SecureDocument entity
            await base44.entities.SecureDocument.create({
                title,
                document_type: docType,
                file_url,
                file_type: file.type,
                file_size: file.size,
                access_level: 'Public',
                approval_status: 'Approved',
                tags: ['legal', 'compliance', 'FA']
            });

            toast.success('Document uploaded successfully!');
            setTitle('');
            setDocType('Other');
            setFile(null);
            e.target.reset();
        } catch (error) {
            toast.error('Upload failed: ' + error.message);
        } finally {
            setUploading(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Upload className="w-5 h-5 text-cyan-400" />
                    Upload Legal Resource
                </CardTitle>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleUpload} className="space-y-4">
                    <div>
                        <Label className="text-slate-300">Document Title</Label>
                        <Input
                            placeholder="e.g., FA Handbook 2024"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-300">Document Type</Label>
                        <Select value={docType} onValueChange={setDocType}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Other">FA Handbook / Legal Document</SelectItem>
                                <SelectItem value="Contract Document">Contract Template</SelectItem>
                                <SelectItem value="Scouting Report">Scouting Guidelines</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div>
                        <Label className="text-slate-300">Upload File</Label>
                        <Input
                            type="file"
                            accept=".pdf,.doc,.docx"
                            onChange={(e) => setFile(e.target.files[0])}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                        <p className="text-slate-500 text-xs mt-1">
                            Accepted formats: PDF, DOC, DOCX
                        </p>
                    </div>

                    <Button
                        type="submit"
                        disabled={uploading || !file || !title}
                        className="w-full bg-cyan-600 hover:bg-cyan-700"
                    >
                        {uploading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Uploading...
                            </>
                        ) : (
                            <>
                                <Upload className="w-4 h-4 mr-2" />
                                Upload Document
                            </>
                        )}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}