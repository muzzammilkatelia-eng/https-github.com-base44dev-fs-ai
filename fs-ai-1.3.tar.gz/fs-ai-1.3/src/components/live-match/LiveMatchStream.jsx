import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, TrendingUp, Zap, AlertCircle, Play, Pause } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function LiveMatchStream({ matchId = 'demo_match_001' }) {
    const [isLive, setIsLive] = useState(false);
    const [matchData, setMatchData] = useState(null);
    const [events, setEvents] = useState([]);
    const [insights, setInsights] = useState([]);
    const intervalRef = useRef(null);

    useEffect(() => {
        if (isLive) {
            startStream();
        } else {
            stopStream();
        }

        return () => stopStream();
    }, [isLive]);

    const startStream = () => {
        // Initial fetch
        fetchLiveData();
        
        // Update every second
        intervalRef.current = setInterval(() => {
            fetchLiveData();
        }, 1000);
    };

    const stopStream = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    };

    const fetchLiveData = async () => {
        try {
            const { data } = await base44.functions.invoke('getLiveMatchData', { matchId });
            
            setMatchData(data);
            
            // Add new events
            if (data.events && data.events.length > 0) {
                setEvents(prev => [...data.events, ...prev].slice(0, 20));
                
                // Show notification for critical events
                data.events.forEach(event => {
                    if (event.type === 'goal') {
                        toast.success(`⚽ GOAL! ${event.team} - ${event.player}`, {
                            duration: 5000,
                            position: 'top-center'
                        });
                    }
                });
            }
            
            // Update insights
            if (data.insights) {
                setInsights(data.insights);
            }
        } catch (error) {
            console.error('Failed to fetch live data:', error);
        }
    };

    const severityColors = {
        info: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        success: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        warning: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        critical: 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    const eventIcons = {
        goal: '⚽',
        shot: '🎯',
        corner: '🚩',
        foul: '⚠️',
        yellow_card: '🟨',
        substitution: '🔄',
        offside: '🚫'
    };

    return (
        <div className="space-y-6">
            {/* Control Panel */}
            <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-red-500 animate-pulse' : 'bg-slate-600'}`} />
                            <span className="text-white font-semibold">
                                {isLive ? 'LIVE STREAMING' : 'Stream Paused'}
                            </span>
                            {matchData && (
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {matchData.minute}'
                                </Badge>
                            )}
                        </div>
                        <Button
                            onClick={() => setIsLive(!isLive)}
                            className={isLive ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-500 hover:bg-emerald-600'}
                        >
                            {isLive ? (
                                <>
                                    <Pause className="w-4 h-4 mr-2" />
                                    Pause Stream
                                </>
                            ) : (
                                <>
                                    <Play className="w-4 h-4 mr-2" />
                                    Start Stream
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Live Stats */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Match Stats */}
                    {matchData && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Activity className="w-5 h-5 text-cyan-400" />
                                    Live Match Statistics
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {/* Possession */}
                                    <div>
                                        <div className="flex justify-between text-sm mb-2">
                                            <span className="text-white font-semibold">Possession</span>
                                            <div className="flex gap-4">
                                                <span className="text-cyan-400">{matchData.stats.possession.home.toFixed(0)}%</span>
                                                <span className="text-purple-400">{matchData.stats.possession.away.toFixed(0)}%</span>
                                            </div>
                                        </div>
                                        <div className="flex h-2 rounded-full overflow-hidden">
                                            <div 
                                                className="bg-gradient-to-r from-cyan-500 to-cyan-600 transition-all duration-500"
                                                style={{ width: `${matchData.stats.possession.home}%` }}
                                            />
                                            <div 
                                                className="bg-gradient-to-r from-purple-500 to-purple-600 transition-all duration-500"
                                                style={{ width: `${matchData.stats.possession.away}%` }}
                                            />
                                        </div>
                                    </div>

                                    {/* Other Stats */}
                                    <div className="grid grid-cols-3 gap-4">
                                        <StatBlock 
                                            label="Shots"
                                            home={matchData.stats.shots.home}
                                            away={matchData.stats.shots.away}
                                        />
                                        <StatBlock 
                                            label="On Target"
                                            home={matchData.stats.shotsOnTarget.home}
                                            away={matchData.stats.shotsOnTarget.away}
                                        />
                                        <StatBlock 
                                            label="Corners"
                                            home={matchData.stats.corners.home}
                                            away={matchData.stats.corners.away}
                                        />
                                    </div>

                                    {/* xG */}
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex justify-between items-center">
                                            <div className="text-center flex-1">
                                                <p className="text-cyan-400 text-2xl font-bold">{matchData.stats.xG.home}</p>
                                                <p className="text-slate-400 text-xs">Home xG</p>
                                            </div>
                                            <div className="text-slate-500 font-bold">xG</div>
                                            <div className="text-center flex-1">
                                                <p className="text-purple-400 text-2xl font-bold">{matchData.stats.xG.away}</p>
                                                <p className="text-slate-400 text-xs">Away xG</p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Momentum */}
                                    {matchData.momentum && (
                                        <div>
                                            <div className="flex justify-between text-sm mb-2">
                                                <span className="text-white font-semibold flex items-center gap-2">
                                                    <Zap className="w-4 h-4 text-amber-400" />
                                                    Match Momentum
                                                </span>
                                                <div className="flex gap-4">
                                                    <span className="text-cyan-400">{matchData.momentum.home}%</span>
                                                    <span className="text-purple-400">{matchData.momentum.away}%</span>
                                                </div>
                                            </div>
                                            <div className="flex h-3 rounded-full overflow-hidden">
                                                <div 
                                                    className="bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-500"
                                                    style={{ width: `${matchData.momentum.home}%` }}
                                                />
                                                <div 
                                                    className="bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-500"
                                                    style={{ width: `${matchData.momentum.away}%` }}
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Live Events */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-emerald-400" />
                                Live Events Feed
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2 max-h-96 overflow-y-auto">
                                <AnimatePresence>
                                    {events.map((event, idx) => (
                                        <motion.div
                                            key={`${event.type}-${event.minute}-${idx}`}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            exit={{ opacity: 0, x: 20 }}
                                            className={`bg-slate-800/50 rounded-lg p-3 border ${
                                                event.type === 'goal' ? 'border-emerald-500/50' : 'border-slate-700'
                                            }`}
                                        >
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <span className="text-2xl">{eventIcons[event.type]}</span>
                                                    <div>
                                                        <p className="text-white font-semibold text-sm">
                                                            {event.type.replace('_', ' ').toUpperCase()}
                                                        </p>
                                                        <p className="text-slate-400 text-xs">
                                                            {event.team} - {event.player}
                                                        </p>
                                                    </div>
                                                </div>
                                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                                    {event.minute}'
                                                </Badge>
                                            </div>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Tactical Insights */}
                <div>
                    <Card className="bg-slate-900/50 border-slate-800 sticky top-6">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <AlertCircle className="w-5 h-5 text-amber-400" />
                                AI Tactical Insights
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <AnimatePresence>
                                    {insights.map((insight, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, scale: 0.95 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            exit={{ opacity: 0, scale: 0.95 }}
                                            className={`p-3 rounded-lg border ${severityColors[insight.severity]}`}
                                        >
                                            <p className="text-xs font-semibold mb-1">{insight.type.toUpperCase()}</p>
                                            <p className="text-sm">{insight.message}</p>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                                
                                {insights.length === 0 && (
                                    <p className="text-slate-400 text-sm text-center py-8">
                                        Start the stream to see AI-powered tactical insights
                                    </p>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}

function StatBlock({ label, home, away }) {
    return (
        <div className="bg-slate-800/50 rounded-lg p-3">
            <p className="text-slate-400 text-xs mb-2 text-center">{label}</p>
            <div className="flex justify-between items-center">
                <span className="text-cyan-400 font-bold">{home}</span>
                <span className="text-slate-600">-</span>
                <span className="text-purple-400 font-bold">{away}</span>
            </div>
        </div>
    );
}