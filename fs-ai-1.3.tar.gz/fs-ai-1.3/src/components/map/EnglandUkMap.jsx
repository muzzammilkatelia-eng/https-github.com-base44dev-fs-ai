import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from 'react-leaflet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { User, MapPin } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

// UK Major Cities with coordinates
export const UK_CITIES = {
    'London': { lat: 51.5074, lng: -0.1278 },
    'Manchester': { lat: 53.4808, lng: -2.2426 },
    'Liverpool': { lat: 53.4084, lng: -2.9916 },
    'Birmingham': { lat: 52.4862, lng: -1.8904 },
    'Leeds': { lat: 53.8008, lng: -1.5491 },
    'Newcastle': { lat: 54.9783, lng: -1.6178 },
    'Sheffield': { lat: 53.3811, lng: -1.4701 },
    'Bristol': { lat: 51.4545, lng: -2.5879 },
    'Nottingham': { lat: 52.9548, lng: -1.1581 },
    'Leicester': { lat: 52.6369, lng: -1.1398 },
    'Hull': { lat: 53.7676, lng: -0.3274 },
    'Brighton': { lat: 50.8225, lng: -0.1372 }
};

const UK_CENTER = [54.0, -2.5];

export default function EnglandUkMap({ players = [], onSelectPlayer }) {
    // Map players to their nearest city coordinates
    const getPlayerCoords = (player) => {
        // Try to match player's club city
        const clubCityMatch = Object.entries(UK_CITIES).find(([city]) => 
            player.current_club?.toLowerCase().includes(city.toLowerCase()) ||
            player.city?.toLowerCase() === city.toLowerCase()
        );
        
        if (clubCityMatch) {
            return { lat: clubCityMatch[1].lat, lng: clubCityMatch[1].lng, city: clubCityMatch[0] };
        }
        
        // Default to London with slight offset for visualization
        const offset = Math.random() * 0.1 - 0.05;
        return { lat: UK_CITIES.London.lat + offset, lng: UK_CITIES.London.lng + offset, city: 'London' };
    };

    return (
        <MapContainer
            center={UK_CENTER}
            zoom={6}
            minZoom={5}
            maxZoom={13}
            style={{ width: '100%', height: '100%', background: '#1e293b' }}
            className="rounded-lg"
        >
            <TileLayer
                attribution='&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>'
                url="https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
            />

            {/* City Markers */}
            {Object.entries(UK_CITIES).map(([city, coords]) => (
                <CircleMarker
                    key={city}
                    center={[coords.lat, coords.lng]}
                    radius={8}
                    pathOptions={{ 
                        color: '#06b6d4', 
                        fillColor: '#0e7490', 
                        fillOpacity: 0.6,
                        weight: 2
                    }}
                >
                    <Popup className="uk-map-popup">
                        <div className="text-center">
                            <MapPin className="w-4 h-4 inline mr-1 text-cyan-500" />
                            <strong>{city}</strong>
                        </div>
                    </Popup>
                </CircleMarker>
            ))}

            {/* Player Markers */}
            {players.map((player) => {
                const coords = getPlayerCoords(player);
                return (
                    <CircleMarker
                        key={player.id}
                        center={[coords.lat, coords.lng]}
                        radius={12}
                        pathOptions={{ 
                            color: '#f59e0b', 
                            fillColor: '#d97706', 
                            fillOpacity: 0.8,
                            weight: 2
                        }}
                    >
                        <Popup>
                            <div className="min-w-[200px] p-2">
                                <h4 className="font-bold text-base mb-1">{player.name}</h4>
                                <p className="text-sm text-gray-600 mb-2">
                                    {player.position} · {player.age} years
                                </p>
                                <p className="text-sm mb-2">
                                    <strong>Club:</strong> {player.current_club || 'Unknown'}
                                </p>
                                <p className="text-sm mb-2">
                                    <strong>City:</strong> {coords.city}
                                </p>
                                {player.market_value && (
                                    <p className="text-sm text-amber-600 font-semibold mb-2">
                                        €{player.market_value}M
                                    </p>
                                )}
                                {onSelectPlayer && (
                                    <button
                                        onClick={() => onSelectPlayer(player)}
                                        className="w-full mt-2 px-3 py-1.5 bg-cyan-600 text-white text-sm rounded hover:bg-cyan-700"
                                    >
                                        View Profile
                                    </button>
                                )}
                            </div>
                        </Popup>
                    </CircleMarker>
                );
            })}
        </MapContainer>
    );
}