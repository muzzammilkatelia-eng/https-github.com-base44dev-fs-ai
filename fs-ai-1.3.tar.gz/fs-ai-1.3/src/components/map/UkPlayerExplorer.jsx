import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { MapPin, User, Search, Filter, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import EnglandUkMap, { UK_CITIES } from './EnglandUkMap';

export default function UkPlayerExplorer() {
    const [selectedCity, setSelectedCity] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['uk-players'],
        queryFn: () => base44.entities.Player.list('-market_value', 100)
    });

    // Filter players - in a real scenario, you'd filter by UK-based players
    const filteredPlayers = players.filter(player => {
        const matchesCity = selectedCity === 'all' || 
            player.current_club?.toLowerCase().includes(selectedCity.toLowerCase()) ||
            player.city?.toLowerCase() === selectedCity.toLowerCase();
        
        const matchesSearch = !searchTerm || 
            player.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            player.current_club?.toLowerCase().includes(searchTerm.toLowerCase());

        return matchesCity && matchesSearch;
    });

    const handleSelectPlayer = (player) => {
        setSelectedPlayer(player);
    };

    if (isLoading) {
        return (
            <div className="h-full flex items-center justify-center bg-slate-900">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="h-full flex">
            {/* Sidebar */}
            <div className="w-80 bg-slate-900 border-r border-slate-800 flex flex-col">
                <div className="p-4 border-b border-slate-800">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
                        <MapPin className="w-5 h-5 text-cyan-400" />
                        England & UK Map
                    </h2>

                    {/* Search */}
                    <div className="relative mb-3">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                            placeholder="Search players..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-9 bg-slate-800 border-slate-700"
                        />
                    </div>

                    {/* City Filter */}
                    <Select value={selectedCity} onValueChange={setSelectedCity}>
                        <SelectTrigger className="bg-slate-800 border-slate-700">
                            <Filter className="w-4 h-4 mr-2" />
                            <SelectValue placeholder="Filter by city" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Cities</SelectItem>
                            {Object.keys(UK_CITIES).map(city => (
                                <SelectItem key={city} value={city.toLowerCase()}>{city}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                {/* Player List */}
                <div className="flex-1 overflow-y-auto p-2">
                    <p className="text-slate-400 text-xs px-2 mb-2">{filteredPlayers.length} players found</p>
                    {filteredPlayers.slice(0, 50).map(player => (
                        <div
                            key={player.id}
                            onClick={() => handleSelectPlayer(player)}
                            className={`p-3 rounded-lg cursor-pointer mb-2 transition-all ${
                                selectedPlayer?.id === player.id 
                                    ? 'bg-cyan-500/20 border border-cyan-500/50' 
                                    : 'bg-slate-800/50 border border-transparent hover:bg-slate-800'
                            }`}
                        >
                            <div className="flex items-start justify-between">
                                <div>
                                    <h4 className="text-white font-medium text-sm">{player.name}</h4>
                                    <p className="text-slate-400 text-xs">
                                        {player.position} · {player.age}y
                                    </p>
                                    <p className="text-slate-500 text-xs mt-1">{player.current_club}</p>
                                </div>
                                {player.market_value && (
                                    <Badge className="bg-amber-500/20 text-amber-400 text-xs">
                                        €{player.market_value}M
                                    </Badge>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Selected Player Detail */}
                {selectedPlayer && (
                    <div className="p-4 border-t border-slate-800 bg-slate-800/50">
                        <h4 className="text-white font-bold mb-2">{selectedPlayer.name}</h4>
                        <div className="space-y-1 text-sm">
                            <p className="text-slate-300">
                                <span className="text-slate-500">Position:</span> {selectedPlayer.position}
                            </p>
                            <p className="text-slate-300">
                                <span className="text-slate-500">Age:</span> {selectedPlayer.age}
                            </p>
                            <p className="text-slate-300">
                                <span className="text-slate-500">Club:</span> {selectedPlayer.current_club}
                            </p>
                            {selectedPlayer.market_value && (
                                <p className="text-amber-400 font-semibold">
                                    €{selectedPlayer.market_value}M
                                </p>
                            )}
                        </div>
                        <Link to={createPageUrl(`PlayerProfile?id=${selectedPlayer.id}`)}>
                            <Button className="w-full mt-3 bg-cyan-600 hover:bg-cyan-700" size="sm">
                                <User className="w-4 h-4 mr-2" />
                                View Full Profile
                            </Button>
                        </Link>
                    </div>
                )}
            </div>

            {/* Map */}
            <div className="flex-1">
                <EnglandUkMap 
                    players={filteredPlayers} 
                    onSelectPlayer={handleSelectPlayer} 
                />
            </div>
        </div>
    );
}