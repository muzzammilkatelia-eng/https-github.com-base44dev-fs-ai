import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Search, TrendingUp, Activity, Users, Trophy, Video } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function LiveDataIntegration() {
    const [activeTab, setActiveTab] = useState('fixtures');
    const [isLoading, setIsLoading] = useState(false);
    const [results, setResults] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [dateRange, setDateRange] = useState({
        from: new Date().toISOString().split('T')[0],
        to: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    });

    const fetchData = async (method, options = {}) => {
        setIsLoading(true);
        try {
            const result = await base44.functions.fetchLiveFootballData({
                method: method,
                options: options
            });

            if (result.success) {
                setResults(result.data);
                toast.success('Data loaded successfully');
            } else {
                toast.error(result.error || 'Failed to fetch data');
            }
        } catch (error) {
            toast.error('API call failed. Enable backend functions first.');
        } finally {
            setIsLoading(false);
        }
    };

    const searchPlayer = async () => {
        if (!searchQuery.trim()) {
            toast.error('Enter a player name');
            return;
        }
        await fetchData('Players', { playerName: searchQuery });
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Activity className="w-5 h-5 text-cyan-400" />
                        Real-Time Football Data Integration
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="grid grid-cols-5 bg-slate-800">
                            <TabsTrigger value="fixtures">
                                <Trophy className="w-4 h-4 mr-2" />
                                Fixtures
                            </TabsTrigger>
                            <TabsTrigger value="livescore">
                                <Activity className="w-4 h-4 mr-2" />
                                Live Scores
                            </TabsTrigger>
                            <TabsTrigger value="players">
                                <Users className="w-4 h-4 mr-2" />
                                Players
                            </TabsTrigger>
                            <TabsTrigger value="standings">
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Standings
                            </TabsTrigger>
                            <TabsTrigger value="topscorers">
                                <Trophy className="w-4 h-4 mr-2" />
                                Top Scorers
                            </TabsTrigger>
                        </TabsList>

                        {/* Fixtures Tab */}
                        <TabsContent value="fixtures" className="space-y-4 mt-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">From Date</label>
                                    <Input
                                        type="date"
                                        value={dateRange.from}
                                        onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">To Date</label>
                                    <Input
                                        type="date"
                                        value={dateRange.to}
                                        onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>
                            <Button
                                onClick={() => fetchData('Fixtures', dateRange)}
                                disabled={isLoading}
                                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                            >
                                {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
                                Load Fixtures
                            </Button>
                        </TabsContent>

                        {/* Livescore Tab */}
                        <TabsContent value="livescore" className="mt-4">
                            <Button
                                onClick={() => fetchData('Livescore')}
                                disabled={isLoading}
                                className="w-full bg-gradient-to-r from-red-500 to-pink-600"
                            >
                                {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Activity className="w-4 h-4 mr-2" />}
                                Load Live Matches
                            </Button>
                        </TabsContent>

                        {/* Players Tab */}
                        <TabsContent value="players" className="space-y-4 mt-4">
                            <div className="flex gap-2">
                                <Input
                                    placeholder="Search player name..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    onKeyPress={(e) => e.key === 'Enter' && searchPlayer()}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                                <Button onClick={searchPlayer} disabled={isLoading}>
                                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                                </Button>
                            </div>
                        </TabsContent>

                        {/* Standings Tab */}
                        <TabsContent value="standings" className="space-y-4 mt-4">
                            <p className="text-slate-400 text-sm">Select a league ID to view standings</p>
                            <Input
                                placeholder="League ID (e.g., 148 for Premier League)"
                                type="number"
                                onChange={(e) => e.target.value && fetchData('Standings', { leagueId: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </TabsContent>

                        {/* Top Scorers Tab */}
                        <TabsContent value="topscorers" className="space-y-4 mt-4">
                            <p className="text-slate-400 text-sm">Select a league ID to view top scorers</p>
                            <Input
                                placeholder="League ID (e.g., 148 for Premier League)"
                                type="number"
                                onChange={(e) => e.target.value && fetchData('Topscorers', { leagueId: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>

            {/* Results Display */}
            {results && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Results</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {activeTab === 'fixtures' && Array.isArray(results) && (
                                <div className="space-y-3">
                                    {results.slice(0, 20).map((match, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                                    {match.league_name}
                                                </Badge>
                                                <span className="text-slate-400 text-sm">
                                                    {match.event_date} {match.event_time}
                                                </span>
                                            </div>
                                            <div className="flex items-center justify-between">
                                                <div className="text-white font-semibold">{match.event_home_team}</div>
                                                <div className="text-cyan-400 font-bold">
                                                    {match.event_final_result || 'vs'}
                                                </div>
                                                <div className="text-white font-semibold">{match.event_away_team}</div>
                                            </div>
                                            <Badge className={
                                                match.event_status === 'Finished' ? 'bg-emerald-500/20 text-emerald-400 mt-2' :
                                                match.event_live === '1' ? 'bg-red-500/20 text-red-400 mt-2' :
                                                'bg-slate-600 text-slate-300 mt-2'
                                            }>
                                                {match.event_status}
                                            </Badge>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {activeTab === 'players' && Array.isArray(results) && (
                                <div className="space-y-3">
                                    {results.map((player, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <h4 className="text-white font-bold">{player.player_name}</h4>
                                                    <p className="text-slate-400 text-sm">{player.team_name}</p>
                                                    <div className="flex gap-2 mt-2">
                                                        <Badge className="bg-slate-700 text-slate-300">
                                                            {player.player_type}
                                                        </Badge>
                                                        <Badge className="bg-slate-700 text-slate-300">
                                                            {player.player_age}y
                                                        </Badge>
                                                        <Badge className="bg-slate-700 text-slate-300">
                                                            #{player.player_number}
                                                        </Badge>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="text-emerald-400 font-bold text-2xl">
                                                        {player.player_goals}
                                                    </div>
                                                    <p className="text-slate-400 text-xs">Goals</p>
                                                    <p className="text-slate-400 text-xs mt-1">
                                                        {player.player_match_played} matches
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {activeTab === 'standings' && results?.total && (
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm">
                                        <thead className="bg-slate-800">
                                            <tr className="text-slate-300">
                                                <th className="p-2 text-left">#</th>
                                                <th className="p-2 text-left">Team</th>
                                                <th className="p-2">P</th>
                                                <th className="p-2">W</th>
                                                <th className="p-2">D</th>
                                                <th className="p-2">L</th>
                                                <th className="p-2">GD</th>
                                                <th className="p-2 font-bold">PTS</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {results.total.map((team, idx) => (
                                                <tr key={idx} className="border-b border-slate-700 text-white hover:bg-slate-800/50">
                                                    <td className="p-2">{team.standing_place}</td>
                                                    <td className="p-2 font-semibold">{team.standing_team}</td>
                                                    <td className="p-2 text-center">{team.standing_P}</td>
                                                    <td className="p-2 text-center">{team.standing_W}</td>
                                                    <td className="p-2 text-center">{team.standing_D}</td>
                                                    <td className="p-2 text-center">{team.standing_L}</td>
                                                    <td className="p-2 text-center">{team.standing_GD}</td>
                                                    <td className="p-2 text-center font-bold text-cyan-400">
                                                        {team.standing_PTS}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}

                            {activeTab === 'topscorers' && Array.isArray(results) && (
                                <div className="space-y-2">
                                    {results.map((scorer, idx) => (
                                        <div key={idx} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex items-center gap-3">
                                                <div className="bg-cyan-500/20 text-cyan-400 font-bold rounded-full w-8 h-8 flex items-center justify-center">
                                                    {scorer.player_place}
                                                </div>
                                                <div>
                                                    <p className="text-white font-semibold">{scorer.player_name}</p>
                                                    <p className="text-slate-400 text-sm">{scorer.team_name}</p>
                                                </div>
                                            </div>
                                            <div className="text-emerald-400 font-bold text-xl">
                                                {scorer.goals} goals
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {activeTab === 'livescore' && Array.isArray(results) && (
                                <div className="space-y-3">
                                    {results.length === 0 ? (
                                        <p className="text-slate-400 text-center py-8">No live matches at the moment</p>
                                    ) : (
                                        results.map((match, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-red-500">
                                                <div className="flex items-center justify-between mb-2">
                                                    <Badge className="bg-red-500/20 text-red-400 animate-pulse">
                                                        LIVE
                                                    </Badge>
                                                    <span className="text-slate-400 text-sm">{match.league_name}</span>
                                                </div>
                                                <div className="grid grid-cols-3 items-center gap-4 text-center">
                                                    <div className="text-white font-semibold">{match.event_home_team}</div>
                                                    <div className="text-cyan-400 font-bold text-2xl">
                                                        {match.event_final_result}
                                                    </div>
                                                    <div className="text-white font-semibold">{match.event_away_team}</div>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {/* Setup Instructions */}
            <Card className="bg-amber-500/10 border-amber-500/30">
                <CardContent className="pt-6">
                    <h3 className="text-amber-400 font-semibold mb-2">Setup Instructions</h3>
                    <ol className="text-slate-300 text-sm space-y-2 list-decimal list-inside">
                        <li>Enable backend functions in Dashboard → Settings</li>
                        <li>Add your AllSportsAPI key as secret: <code className="bg-slate-800 px-2 py-1 rounded">ALLSPORTS_API_KEY</code></li>
                        <li>Get your API key from <a href="https://allsportsapi.com" target="_blank" className="text-cyan-400 hover:underline">allsportsapi.com</a></li>
                        <li>Access real-time fixtures, livescores, player data, and standings</li>
                    </ol>
                </CardContent>
            </Card>
        </div>
    );
}