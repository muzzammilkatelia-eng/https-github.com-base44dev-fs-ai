import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Loader2, Radio, TrendingUp, Users, Calendar, Trophy, Wifi, WifiOff } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useAllSportsWebSocket } from './useWebSocket';

export default function LiveMarketData() {
    const [liveData, setLiveData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedLeague, setSelectedLeague] = useState('');
    const [leagues, setLeagues] = useState([]);
    const [apiKey, setApiKey] = useState('');
    const [websocketEnabled, setWebsocketEnabled] = useState(false);

    // WebSocket connection for real-time updates
    const { liveMatches, isConnected, error: wsError } = useAllSportsWebSocket(
        websocketEnabled ? apiKey : null,
        { leagueId: selectedLeague }
    );

    React.useEffect(() => {
        if (liveMatches.length > 0 && websocketEnabled) {
            setLiveData({ type: 'livescore', data: liveMatches });
        }
    }, [liveMatches, websocketEnabled]);

    const fetchLeagues = async () => {
        setIsLoading(true);
        try {
            const result = await base44.functions.fetchAllSportsData({
                method: 'Leagues'
            });

            if (result.success) {
                setLeagues(result.data.slice(0, 50)); // Top 50 leagues
                toast.success('Leagues loaded');
            } else {
                toast.error(result.error || 'Failed to fetch leagues');
            }
        } catch (error) {
            toast.error('Backend functions not enabled');
        } finally {
            setIsLoading(false);
        }
    };

    const fetchLiveScores = async () => {
        setIsLoading(true);
        try {
            const params = selectedLeague ? { leagueId: selectedLeague } : {};
            const result = await base44.functions.fetchAllSportsData({
                method: 'Livescore',
                methodParams: params
            });

            if (result.success) {
                setLiveData({ type: 'livescore', data: result.data });
                toast.success(`${result.data.length} live matches found`);
            } else {
                toast.error(result.error || 'Failed to fetch live scores');
            }
        } catch (error) {
            toast.error('Backend functions not enabled');
        } finally {
            setIsLoading(false);
        }
    };

    const fetchTodayFixtures = async () => {
        setIsLoading(true);
        try {
            const today = new Date().toISOString().split('T')[0];
            const params = {
                from: today,
                to: today
            };
            if (selectedLeague) params.leagueId = selectedLeague;

            const result = await base44.functions.fetchAllSportsData({
                method: 'Fixtures',
                methodParams: params
            });

            if (result.success) {
                setLiveData({ type: 'fixtures', data: result.data });
                toast.success(`${result.data.length} fixtures today`);
            } else {
                toast.error(result.error || 'Failed to fetch fixtures');
            }
        } catch (error) {
            toast.error('Backend functions not enabled');
        } finally {
            setIsLoading(false);
        }
    };

    const fetchStandings = async () => {
        if (!selectedLeague) {
            toast.error('Please select a league first');
            return;
        }

        setIsLoading(true);
        try {
            const result = await base44.functions.fetchAllSportsData({
                method: 'Standings',
                methodParams: { leagueId: selectedLeague }
            });

            if (result.success) {
                setLiveData({ type: 'standings', data: result.data });
                toast.success('Standings loaded');
            } else {
                toast.error(result.error || 'Failed to fetch standings');
            }
        } catch (error) {
            toast.error('Backend functions not enabled');
        } finally {
            setIsLoading(false);
        }
    };

    const fetchTopScorers = async () => {
        if (!selectedLeague) {
            toast.error('Please select a league first');
            return;
        }

        setIsLoading(true);
        try {
            const result = await base44.functions.fetchAllSportsData({
                method: 'Topscorers',
                methodParams: { leagueId: selectedLeague }
            });

            if (result.success) {
                setLiveData({ type: 'topscorers', data: result.data });
                toast.success('Top scorers loaded');
            } else {
                toast.error(result.error || 'Failed to fetch top scorers');
            }
        } catch (error) {
            toast.error('Backend functions not enabled');
        } finally {
            setIsLoading(false);
        }
    };

    React.useEffect(() => {
        fetchLeagues();
    }, []);

    return (
        <div className="space-y-6">
            {/* Controls */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Radio className="w-5 h-5 text-cyan-400" />
                        Real-Time Football Data
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {/* Real-time WebSocket Toggle */}
                    <div className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/30">
                        <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                                {isConnected ? (
                                    <Wifi className="w-5 h-5 text-emerald-400 animate-pulse" />
                                ) : (
                                    <WifiOff className="w-5 h-5 text-slate-500" />
                                )}
                                <div>
                                    <p className="text-white font-semibold text-sm">Real-Time Updates</p>
                                    <p className="text-slate-400 text-xs">
                                        {isConnected ? 'Connected - Updates streaming' : 'Enable WebSocket connection'}
                                    </p>
                                </div>
                            </div>
                            <Switch checked={websocketEnabled} onCheckedChange={setWebsocketEnabled} />
                        </div>
                        {websocketEnabled && !apiKey && (
                            <input
                                type="password"
                                placeholder="Enter AllSportsAPI key..."
                                value={apiKey}
                                onChange={(e) => setApiKey(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white text-sm"
                            />
                        )}
                        {isConnected && (
                            <Badge className="bg-emerald-500/20 text-emerald-400 mt-2">
                                {liveMatches.length} live matches streaming
                            </Badge>
                        )}
                    </div>

                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Select League (Optional)</label>
                        <Select value={selectedLeague} onValueChange={setSelectedLeague}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="All Leagues" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value={null}>All Leagues</SelectItem>
                                {leagues.map(league => (
                                    <SelectItem key={league.league_key} value={league.league_key}>
                                        {league.league_name} - {league.country_name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <Button
                            onClick={fetchLiveScores}
                            disabled={isLoading}
                            variant="outline"
                            className="border-emerald-500/30 hover:bg-emerald-500/10"
                        >
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Radio className="w-4 h-4" />}
                            <span className="ml-2">Live Scores</span>
                        </Button>

                        <Button
                            onClick={fetchTodayFixtures}
                            disabled={isLoading}
                            variant="outline"
                            className="border-cyan-500/30 hover:bg-cyan-500/10"
                        >
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calendar className="w-4 h-4" />}
                            <span className="ml-2">Today's Fixtures</span>
                        </Button>

                        <Button
                            onClick={fetchStandings}
                            disabled={isLoading || !selectedLeague}
                            variant="outline"
                            className="border-purple-500/30 hover:bg-purple-500/10"
                        >
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trophy className="w-4 h-4" />}
                            <span className="ml-2">Standings</span>
                        </Button>

                        <Button
                            onClick={fetchTopScorers}
                            disabled={isLoading || !selectedLeague}
                            variant="outline"
                            className="border-amber-500/30 hover:bg-amber-500/10"
                        >
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
                            <span className="ml-2">Top Scorers</span>
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Data Display */}
            {liveData && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    {liveData.type === 'livescore' && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
                                    Live Matches ({liveData.data.length})
                                    {isConnected && (
                                        <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                            Real-time
                                        </Badge>
                                    )}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {liveData.data.length === 0 ? (
                                    <p className="text-slate-400 text-center py-8">No live matches at the moment</p>
                                ) : (
                                    <div className="space-y-3">
                                        {liveData.data.map((match, idx) => (
                                            <motion.div
                                                key={match.event_key || idx}
                                                initial={{ opacity: 0, scale: 0.95 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-emerald-500"
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <div className="flex items-center gap-2">
                                                        <Badge className="bg-emerald-500/20 text-emerald-400 animate-pulse">
                                                            LIVE {match.event_status}'
                                                        </Badge>
                                                        {match.event_halftime_result && (
                                                            <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                                HT: {match.event_halftime_result}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                    <span className="text-slate-400 text-xs">{match.league_name}</span>
                                                </div>
                                                <div className="flex items-center justify-between mb-3">
                                                    <div className="flex-1">
                                                        <p className="text-white font-semibold">{match.event_home_team}</p>
                                                        <p className="text-slate-400 text-sm">{match.event_away_team}</p>
                                                    </div>
                                                    <div className="text-center px-4">
                                                        <p className="text-2xl font-bold text-cyan-400">
                                                            {match.event_final_result || '0 - 0'}
                                                        </p>
                                                    </div>
                                                </div>
                                                {match.goalscorers && match.goalscorers.length > 0 && (
                                                    <div className="space-y-1 text-xs">
                                                        <p className="text-slate-500 font-semibold mb-1">Goals:</p>
                                                        {match.goalscorers.slice(-3).map((goal, i) => (
                                                            <div key={i} className="flex items-center gap-2 text-slate-300">
                                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                                    {goal.time}'
                                                                </Badge>
                                                                <span>
                                                                    {goal.home_scorer || goal.away_scorer} {goal.score}
                                                                </span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                                {match.statistics && match.statistics.length > 0 && (
                                                    <div className="mt-3 pt-3 border-t border-slate-700">
                                                        <div className="grid grid-cols-3 gap-2 text-xs">
                                                            {match.statistics.slice(0, 3).map((stat, i) => (
                                                                <div key={i} className="text-center">
                                                                    <p className="text-slate-500">{stat.type}</p>
                                                                    <p className="text-white font-semibold">
                                                                        {stat.home} - {stat.away}
                                                                    </p>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </motion.div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    )}

                    {liveData.type === 'fixtures' && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Today's Fixtures ({liveData.data.length})</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {liveData.data.map((match, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <span className="text-cyan-400 text-sm">{match.event_time}</span>
                                                <span className="text-slate-400 text-xs">{match.league_name}</span>
                                            </div>
                                            <div className="flex items-center justify-between">
                                                <div className="flex-1">
                                                    <p className="text-white font-semibold">{match.event_home_team}</p>
                                                    <p className="text-slate-400 text-sm">{match.event_away_team}</p>
                                                </div>
                                                {match.event_final_result && (
                                                    <div className="text-center px-4">
                                                        <p className="text-xl font-bold text-white">
                                                            {match.event_final_result}
                                                        </p>
                                                        <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                            {match.event_status}
                                                        </Badge>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {liveData.type === 'standings' && liveData.data.total && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Trophy className="w-5 h-5 text-amber-400" />
                                    League Standings
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead>
                                            <tr className="border-b border-slate-700">
                                                <th className="text-left text-slate-400 text-xs py-2">#</th>
                                                <th className="text-left text-slate-400 text-xs py-2">Team</th>
                                                <th className="text-center text-slate-400 text-xs py-2">P</th>
                                                <th className="text-center text-slate-400 text-xs py-2">W</th>
                                                <th className="text-center text-slate-400 text-xs py-2">D</th>
                                                <th className="text-center text-slate-400 text-xs py-2">L</th>
                                                <th className="text-center text-slate-400 text-xs py-2">GD</th>
                                                <th className="text-center text-slate-400 text-xs py-2 font-bold">PTS</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {liveData.data.total.map((team, idx) => (
                                                <tr key={idx} className="border-b border-slate-800 hover:bg-slate-800/30">
                                                    <td className="py-3 text-slate-300 text-sm">{team.standing_place}</td>
                                                    <td className="py-3 text-white font-medium">{team.standing_team}</td>
                                                    <td className="py-3 text-center text-slate-300 text-sm">{team.standing_P}</td>
                                                    <td className="py-3 text-center text-emerald-400 text-sm">{team.standing_W}</td>
                                                    <td className="py-3 text-center text-slate-400 text-sm">{team.standing_D}</td>
                                                    <td className="py-3 text-center text-red-400 text-sm">{team.standing_L}</td>
                                                    <td className="py-3 text-center text-slate-300 text-sm">{team.standing_GD}</td>
                                                    <td className="py-3 text-center text-cyan-400 font-bold">{team.standing_PTS}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {liveData.type === 'topscorers' && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-amber-400" />
                                    Top Scorers
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {liveData.data.map((player, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4 flex items-center justify-between">
                                            <div className="flex items-center gap-4">
                                                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                                                    <span className="text-cyan-400 font-bold">{player.player_place}</span>
                                                </div>
                                                <div>
                                                    <p className="text-white font-semibold">{player.player_name}</p>
                                                    <p className="text-slate-400 text-sm">{player.team_name}</p>
                                                </div>
                                            </div>
                                            <Badge className="bg-amber-500/20 text-amber-400">
                                                {player.goals} goals
                                            </Badge>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </motion.div>
            )}
        </div>
    );
}