import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, TrendingUp, TrendingDown, Globe2, DollarSign, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function MarketTrendAnalyzer() {
    const [selectedPosition, setSelectedPosition] = useState('');
    const [analysisResults, setAnalysisResults] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const positions = [
        'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 
        'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'
    ];

    const analyzeMarket = async () => {
        setIsAnalyzing(true);
        try {
            const players = await base44.entities.Player.list('-updated_date', 100);
            const projections = await base44.entities.PlayerProjection.list('-created_date', 50);
            const reports = await base44.entities.ScoutingReport.list('-created_date', 50);

            // Filter by position if selected
            const filteredPlayers = selectedPosition 
                ? players.filter(p => p.position === selectedPosition)
                : players;

            // Gather market data
            const marketData = filteredPlayers.map(player => ({
                name: player.name,
                age: player.age,
                position: player.position,
                current_value: player.market_value,
                league: player.league,
                nationality: player.nationality,
                injury_score: player.injury_prone_score,
                projection: projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase()),
                latest_report: reports.find(r => r.player_name?.toLowerCase() === player.name?.toLowerCase())
            }));

            // AI Analysis
            const prompt = `Analyze the football transfer market trends based on this data:

Position Focus: ${selectedPosition || 'All Positions'}
Total Players Analyzed: ${marketData.length}

Market Data Summary:
${marketData.slice(0, 20).map(p => `
- ${p.name} (${p.position}, ${p.age}y, ${p.league})
  Value: €${p.current_value}M
  Trajectory: ${p.projection?.potential_trajectory || 'Unknown'}
  Peak Potential: ${p.projection?.peak_potential_rating || 'N/A'}/10
  Injury Risk: ${p.injury_score}/100
`).join('\n')}

Provide comprehensive market intelligence:

1. **Transfer Market Fluctuations**: Analyze current pricing trends for ${selectedPosition || 'all positions'}. Are valuations rising or falling? What's driving changes?

2. **Emerging Talent Hotspots**: Identify 3-5 geographic regions or leagues producing exceptional talent in this category. Include specific countries and why they're hotspots.

3. **Future Valuation Predictions**: 
   - Identify 5 players with highest growth potential
   - Predict their value in 1-2 years
   - Explain the reasoning (performance trajectory, age curve, market demand)

4. **Market Opportunities**:
   - Undervalued players (high potential, low current value)
   - Overvalued players (caution zones)
   - Best value-for-money signings

5. **Risk Assessment**: Players with injury concerns or declining trajectories to avoid

6. **Tactical Trends**: How is the market valuing different playing styles within this position?`;

            const aiResponse = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        market_fluctuations: {
                            type: "object",
                            properties: {
                                trend: { type: "string", enum: ["Rising", "Falling", "Stable"] },
                                average_change_percentage: { type: "number" },
                                analysis: { type: "string" },
                                drivers: { type: "array", items: { type: "string" } }
                            }
                        },
                        emerging_hotspots: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    region: { type: "string" },
                                    countries: { type: "array", items: { type: "string" } },
                                    leagues: { type: "array", items: { type: "string" } },
                                    talent_level: { type: "string" },
                                    reasoning: { type: "string" },
                                    top_players: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        valuation_predictions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    current_value: { type: "number" },
                                    predicted_value_1yr: { type: "number" },
                                    predicted_value_2yr: { type: "number" },
                                    growth_percentage: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        market_opportunities: {
                            type: "object",
                            properties: {
                                undervalued: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            player: { type: "string" },
                                            current_value: { type: "number" },
                                            fair_value: { type: "number" },
                                            upside: { type: "string" }
                                        }
                                    }
                                },
                                overvalued: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            player: { type: "string" },
                                            current_value: { type: "number" },
                                            risk_factors: { type: "array", items: { type: "string" } }
                                        }
                                    }
                                },
                                best_value: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            player: { type: "string" },
                                            value: { type: "number" },
                                            roi_potential: { type: "string" }
                                        }
                                    }
                                }
                            }
                        },
                        risk_assessment: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player: { type: "string" },
                                    risk_level: { type: "string" },
                                    concerns: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        tactical_trends: {
                            type: "object",
                            properties: {
                                most_valued_style: { type: "string" },
                                emerging_styles: { type: "array", items: { type: "string" } },
                                declining_styles: { type: "array", items: { type: "string" } },
                                analysis: { type: "string" }
                            }
                        }
                    }
                }
            });

            setAnalysisResults(aiResponse);
        } catch (error) {
            console.error('Market analysis failed:', error);
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            {/* Control Panel */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        Market Intelligence Engine
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Position Focus (Optional)</label>
                        <Select value={selectedPosition} onValueChange={setSelectedPosition}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="All Positions" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value={null}>All Positions</SelectItem>
                                {positions.map(pos => (
                                    <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <Button
                        onClick={analyzeMarket}
                        disabled={isAnalyzing}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Market Trends...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Run Market Analysis
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {/* Results */}
            {analysisResults && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Market Fluctuations */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                {analysisResults.market_fluctuations.trend === 'Rising' ? (
                                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                                ) : analysisResults.market_fluctuations.trend === 'Falling' ? (
                                    <TrendingDown className="w-5 h-5 text-red-400" />
                                ) : (
                                    <DollarSign className="w-5 h-5 text-amber-400" />
                                )}
                                Transfer Market Fluctuations
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center gap-4">
                                <Badge className={
                                    analysisResults.market_fluctuations.trend === 'Rising' 
                                        ? 'bg-emerald-500/20 text-emerald-400' 
                                        : analysisResults.market_fluctuations.trend === 'Falling'
                                        ? 'bg-red-500/20 text-red-400'
                                        : 'bg-amber-500/20 text-amber-400'
                                }>
                                    {analysisResults.market_fluctuations.trend}
                                </Badge>
                                <span className="text-2xl font-bold text-white">
                                    {analysisResults.market_fluctuations.average_change_percentage > 0 ? '+' : ''}
                                    {analysisResults.market_fluctuations.average_change_percentage}%
                                </span>
                            </div>
                            <p className="text-slate-300 leading-relaxed">
                                {analysisResults.market_fluctuations.analysis}
                            </p>
                            <div>
                                <h4 className="text-slate-400 text-sm mb-2">Key Drivers:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {analysisResults.market_fluctuations.drivers.map((driver, i) => (
                                        <Badge key={i} className="bg-slate-700 text-slate-300">
                                            {driver}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Emerging Hotspots */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Globe2 className="w-5 h-5 text-cyan-400" />
                                Emerging Talent Hotspots
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                {analysisResults.emerging_hotspots.map((hotspot, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                                    >
                                        <div className="flex items-start justify-between">
                                            <h4 className="text-white font-bold">{hotspot.region}</h4>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                                {hotspot.talent_level}
                                            </Badge>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Countries:</p>
                                            <div className="flex flex-wrap gap-1">
                                                {hotspot.countries.map((country, i) => (
                                                    <Badge key={i} className="bg-slate-700 text-slate-300 text-xs">
                                                        {country}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Leagues:</p>
                                            <div className="flex flex-wrap gap-1">
                                                {hotspot.leagues.map((league, i) => (
                                                    <Badge key={i} className="bg-slate-700 text-slate-300 text-xs">
                                                        {league}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{hotspot.reasoning}</p>
                                        {hotspot.top_players.length > 0 && (
                                            <div>
                                                <p className="text-slate-400 text-xs mb-1">Notable Players:</p>
                                                <p className="text-cyan-400 text-sm">
                                                    {hotspot.top_players.join(', ')}
                                                </p>
                                            </div>
                                        )}
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Valuation Predictions */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Target className="w-5 h-5 text-purple-400" />
                                Future Valuation Predictions
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {analysisResults.valuation_predictions.map((pred, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-3">
                                            <div>
                                                <h4 className="text-white font-bold">{pred.player_name}</h4>
                                                <p className="text-slate-400 text-sm">
                                                    Current: €{pred.current_value}M
                                                </p>
                                            </div>
                                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                                +{pred.growth_percentage}%
                                            </Badge>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4 mb-3">
                                            <div className="bg-slate-900/50 rounded p-3">
                                                <p className="text-slate-400 text-xs">1 Year</p>
                                                <p className="text-2xl font-bold text-emerald-400">
                                                    €{pred.predicted_value_1yr}M
                                                </p>
                                            </div>
                                            <div className="bg-slate-900/50 rounded p-3">
                                                <p className="text-slate-400 text-xs">2 Years</p>
                                                <p className="text-2xl font-bold text-emerald-400">
                                                    €{pred.predicted_value_2yr}M
                                                </p>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{pred.reasoning}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Market Opportunities */}
                    <div className="grid md:grid-cols-3 gap-6">
                        {/* Undervalued */}
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 text-sm">Undervalued Gems</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {analysisResults.market_opportunities.undervalued.map((player, i) => (
                                    <div key={i} className="bg-slate-800/50 rounded p-3">
                                        <p className="text-white font-semibold text-sm">{player.player}</p>
                                        <p className="text-slate-400 text-xs">
                                            Current: €{player.current_value}M → Fair: €{player.fair_value}M
                                        </p>
                                        <p className="text-emerald-400 text-xs mt-1">{player.upside}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        {/* Best Value */}
                        <Card className="bg-cyan-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-cyan-400 text-sm">Best Value Signings</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {analysisResults.market_opportunities.best_value.map((player, i) => (
                                    <div key={i} className="bg-slate-800/50 rounded p-3">
                                        <p className="text-white font-semibold text-sm">{player.player}</p>
                                        <p className="text-slate-400 text-xs">€{player.value}M</p>
                                        <p className="text-cyan-400 text-xs mt-1">{player.roi_potential}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        {/* Overvalued */}
                        <Card className="bg-red-500/10 border-red-500/30">
                            <CardHeader>
                                <CardTitle className="text-red-400 text-sm">Caution Zones</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {analysisResults.market_opportunities.overvalued.map((player, i) => (
                                    <div key={i} className="bg-slate-800/50 rounded p-3">
                                        <p className="text-white font-semibold text-sm">{player.player}</p>
                                        <p className="text-slate-400 text-xs">€{player.current_value}M</p>
                                        <div className="mt-1">
                                            {player.risk_factors.map((risk, j) => (
                                                <p key={j} className="text-red-400 text-xs">• {risk}</p>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Tactical Trends */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Tactical Trends & Playing Styles</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Most Valued Style:</p>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    {analysisResults.tactical_trends.most_valued_style}
                                </Badge>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Emerging Styles:</p>
                                <div className="flex flex-wrap gap-2">
                                    {analysisResults.tactical_trends.emerging_styles.map((style, i) => (
                                        <Badge key={i} className="bg-cyan-500/20 text-cyan-400">
                                            {style}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Declining Styles:</p>
                                <div className="flex flex-wrap gap-2">
                                    {analysisResults.tactical_trends.declining_styles.map((style, i) => (
                                        <Badge key={i} className="bg-slate-600 text-slate-400">
                                            {style}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <p className="text-slate-300">{analysisResults.tactical_trends.analysis}</p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}