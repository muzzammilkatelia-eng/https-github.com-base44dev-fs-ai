import { useEffect, useRef, useState } from 'react';

export function useAllSportsWebSocket(apiKey, options = {}) {
    const [liveMatches, setLiveMatches] = useState([]);
    const [isConnected, setIsConnected] = useState(false);
    const [error, setError] = useState(null);
    const socketRef = useRef(null);

    useEffect(() => {
        if (!apiKey) {
            setError('API key required');
            return;
        }

        // Build WebSocket URL with parameters
        let wsUrl = `wss://wss.allsportsapi.com/live_events?APIkey=${apiKey}`;
        if (options.timezone) wsUrl += `&timezone=${options.timezone}`;
        if (options.countryId) wsUrl += `&countryId=${options.countryId}`;
        if (options.leagueId) wsUrl += `&leagueId=${options.leagueId}`;
        if (options.matchId) wsUrl += `&matchId=${options.matchId}`;

        try {
            const socket = new WebSocket(wsUrl);
            socketRef.current = socket;

            socket.onopen = () => {
                setIsConnected(true);
                setError(null);
                console.log('WebSocket connected');
            };

            socket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (Array.isArray(data)) {
                        setLiveMatches(data);
                    }
                } catch (err) {
                    console.error('Failed to parse WebSocket message:', err);
                }
            };

            socket.onerror = (err) => {
                setError('WebSocket error');
                console.error('WebSocket error:', err);
            };

            socket.onclose = () => {
                setIsConnected(false);
                console.log('WebSocket disconnected');
            };

            return () => {
                if (socket.readyState === WebSocket.OPEN) {
                    socket.close();
                }
            };
        } catch (err) {
            setError('Failed to connect to WebSocket');
            console.error(err);
        }
    }, [apiKey, options.timezone, options.countryId, options.leagueId, options.matchId]);

    return { liveMatches, isConnected, error };
}