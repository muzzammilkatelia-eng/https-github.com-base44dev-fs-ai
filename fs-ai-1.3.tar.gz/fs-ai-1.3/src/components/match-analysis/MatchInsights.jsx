import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, AlertCircle, Clock } from 'lucide-react';

export default function MatchInsights({ analysis, matchData }) {
    return (
        <div className="space-y-6">
            {/* Match Summary */}
            <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardHeader>
                    <CardTitle className="text-white">Match Summary</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center justify-center mb-4">
                        <div className="text-center">
                            <p className="text-2xl font-bold text-white">
                                {matchData.home_team} <span className="text-cyan-400">{matchData.score}</span> {matchData.away_team}
                            </p>
                            <p className="text-slate-400 text-sm mt-1">{matchData.date}</p>
                        </div>
                    </div>
                    <p className="text-slate-300 leading-relaxed">{analysis.match_summary}</p>
                </CardContent>
            </Card>

            {/* Outcome Explanation */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Why This Result?
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 leading-relaxed mb-4">{analysis.outcome_explanation}</p>
                    <div>
                        <h4 className="text-white font-semibold mb-2 text-sm">Winning Factors:</h4>
                        <div className="space-y-2">
                            {analysis.winning_factors?.map((factor, idx) => (
                                <div key={idx} className="flex items-start gap-2">
                                    <span className="text-emerald-400 mt-0.5">✓</span>
                                    <span className="text-slate-300 text-sm">{factor}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Key Moments */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Clock className="w-5 h-5 text-purple-400" />
                        Key Moments
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {analysis.key_moments?.map((moment, idx) => (
                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                <div className="flex items-start gap-3">
                                    <Badge className="bg-purple-500/20 text-purple-400 shrink-0">
                                        {moment.minute}
                                    </Badge>
                                    <div className="flex-1">
                                        <h5 className="text-white font-semibold mb-1">{moment.event}</h5>
                                        <p className="text-slate-400 text-sm mb-2">{moment.impact}</p>
                                        <p className="text-slate-300 text-sm">{moment.tactical_significance}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Formation Analysis */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-amber-400" />
                        Formation Effectiveness
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-white font-semibold">{matchData.home_team}</span>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {analysis.formation_analysis?.home_effectiveness}/10
                                </Badge>
                            </div>
                            <p className="text-slate-400 text-xs mb-2">{matchData.home_formation}</p>
                            <p className="text-slate-300 text-sm">{analysis.formation_analysis?.home_analysis}</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-white font-semibold">{matchData.away_team}</span>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {analysis.formation_analysis?.away_effectiveness}/10
                                </Badge>
                            </div>
                            <p className="text-slate-400 text-xs mb-2">{matchData.away_formation}</p>
                            <p className="text-slate-300 text-sm">{analysis.formation_analysis?.away_analysis}</p>
                        </div>
                    </div>
                    {analysis.formation_analysis?.exploited_weaknesses?.length > 0 && (
                        <div>
                            <h5 className="text-slate-400 text-sm mb-2">Exploited Weaknesses:</h5>
                            <ul className="space-y-1">
                                {analysis.formation_analysis.exploited_weaknesses.map((weakness, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-amber-400">⚠</span>
                                        {weakness}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* What Worked / Didn't Work */}
            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardHeader>
                        <CardTitle className="text-emerald-400 text-sm">What Worked</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div>
                            <p className="text-white font-semibold text-sm mb-2">{matchData.home_team}</p>
                            <ul className="space-y-1">
                                {analysis.what_worked?.home?.map((item, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-emerald-400">✓</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <p className="text-white font-semibold text-sm mb-2">{matchData.away_team}</p>
                            <ul className="space-y-1">
                                {analysis.what_worked?.away?.map((item, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-emerald-400">✓</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-red-500/10 border-red-500/30">
                    <CardHeader>
                        <CardTitle className="text-red-400 text-sm">What Didn't Work</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        <div>
                            <p className="text-white font-semibold text-sm mb-2">{matchData.home_team}</p>
                            <ul className="space-y-1">
                                {analysis.what_didnt_work?.home?.map((item, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-red-400">✗</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <p className="text-white font-semibold text-sm mb-2">{matchData.away_team}</p>
                            <ul className="space-y-1">
                                {analysis.what_didnt_work?.away?.map((item, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-red-400">✗</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Tactical Mistakes */}
            <Card className="bg-amber-500/10 border-amber-500/30">
                <CardHeader>
                    <CardTitle className="text-amber-400 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5" />
                        Tactical Mistakes
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {analysis.tactical_mistakes?.map((mistake, idx) => (
                            <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                <div className="flex items-start justify-between mb-1">
                                    <span className="text-white font-semibold text-sm">{mistake.team}</span>
                                    <Badge className="bg-amber-500/20 text-amber-400 text-xs">Mistake</Badge>
                                </div>
                                <p className="text-slate-300 text-sm mb-1">{mistake.mistake}</p>
                                <p className="text-slate-400 text-xs">Consequence: {mistake.consequence}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}