import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, TrendingUp, AlertTriangle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function PlayerContributions({ analysis }) {
    const chartData = analysis.player_ratings?.map(p => ({
        name: p.player_name?.split(' ')[1] || p.player_name,
        rating: p.rating
    })) || [];

    const getRatingColor = (rating) => {
        if (rating >= 8) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (rating >= 7) return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        if (rating >= 6) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    return (
        <div className="space-y-6">
            {/* Ratings Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Player Ratings Overview</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={250}>
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="name" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <YAxis domain={[0, 10]} stroke="#94a3b8" />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                labelStyle={{ color: '#fff' }}
                            />
                            <Bar dataKey="rating" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Individual Player Analysis */}
            <div className="grid gap-4">
                {analysis.player_ratings?.map((player, idx) => (
                    <Card key={idx} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between mb-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                                        <User className="w-6 h-6 text-white" />
                                    </div>
                                    <div>
                                        <h4 className="text-white font-semibold">{player.player_name}</h4>
                                        <p className="text-slate-400 text-sm">{player.performance_summary}</p>
                                    </div>
                                </div>
                                <Badge className={getRatingColor(player.rating)}>
                                    {player.rating}/10
                                </Badge>
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                                    <h5 className="text-emerald-400 font-semibold text-sm mb-2 flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4" />
                                        Key Contributions
                                    </h5>
                                    <ul className="space-y-1">
                                        {player.key_contributions?.map((contrib, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400">•</span>
                                                {contrib}
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                                    <h5 className="text-amber-400 font-semibold text-sm mb-2 flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4" />
                                        Areas to Improve
                                    </h5>
                                    <ul className="space-y-1">
                                        {player.areas_to_improve?.map((area, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-amber-400">•</span>
                                                {area}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Player-Specific Recommendations */}
            {analysis.player_recommendations?.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Individual Development Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {analysis.player_recommendations.map((rec, idx) => (
                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                    <h5 className="text-white font-semibold mb-2">{rec.player_name}</h5>
                                    <ul className="space-y-1">
                                        {rec.recommendations?.map((recommendation, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-cyan-400">→</span>
                                                {recommendation}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}