import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, Lightbulb, TrendingUp } from 'lucide-react';

export default function TacticalRecommendations({ analysis }) {
    const getPriorityColor = (priority) => {
        if (priority?.toLowerCase().includes('critical') || priority?.toLowerCase().includes('high')) {
            return 'bg-red-500/20 text-red-400 border-red-500/30';
        }
        if (priority?.toLowerCase().includes('medium')) {
            return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        }
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
    };

    return (
        <div className="space-y-6">
            {/* Tactical Adjustments */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Recommended Tactical Adjustments
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {analysis.tactical_adjustments?.map((adj, idx) => (
                            <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                <div className="flex items-start justify-between mb-3">
                                    <div>
                                        <h4 className="text-white font-semibold mb-1">{adj.team}</h4>
                                        <p className="text-cyan-400 text-sm">{adj.adjustment}</p>
                                    </div>
                                    <Badge className={getPriorityColor(adj.priority)}>
                                        {adj.priority}
                                    </Badge>
                                </div>
                                <div className="space-y-2">
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Reasoning:</p>
                                        <p className="text-slate-300 text-sm">{adj.reasoning}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Expected Impact:</p>
                                        <p className="text-emerald-400 text-sm font-medium">{adj.expected_impact}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Alternative Formations */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-amber-400" />
                        Alternative Formations
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        {analysis.alternative_formations?.map((alt, idx) => (
                            <div key={idx} className="bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border border-purple-500/30 rounded-lg p-4">
                                <div className="flex items-start justify-between mb-2">
                                    <div>
                                        <h5 className="text-white font-semibold">{alt.team}</h5>
                                        <Badge className="bg-purple-500/20 text-purple-400 mt-1">
                                            {alt.formation}
                                        </Badge>
                                    </div>
                                </div>
                                <p className="text-slate-300 text-sm mb-3">{alt.reasoning}</p>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Advantages:</p>
                                    <ul className="space-y-1">
                                        {alt.advantages?.map((adv, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400">✓</span>
                                                {adv}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Implementation Roadmap */}
            <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5" />
                        Implementation Priority
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {analysis.tactical_adjustments
                            ?.sort((a, b) => {
                                const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
                                return (priorityOrder[a.priority?.toLowerCase()] || 99) - 
                                       (priorityOrder[b.priority?.toLowerCase()] || 99);
                            })
                            .slice(0, 5)
                            .map((adj, idx) => (
                                <div key={idx} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                                        <span className="text-cyan-400 font-bold">{idx + 1}</span>
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-white font-medium text-sm">{adj.adjustment}</span>
                                            <Badge className={getPriorityColor(adj.priority)} variant="outline">
                                                {adj.priority}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-400 text-xs">{adj.team}</p>
                                    </div>
                                </div>
                            ))}
                    </div>
                </CardContent>
            </Card>

            {/* Next Match Preparation */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Next Match Preparation Summary</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                            <h5 className="text-emerald-400 font-semibold text-sm mb-2">Immediate Training Focus</h5>
                            <ul className="space-y-1">
                                {analysis.tactical_adjustments
                                    ?.filter(adj => adj.priority?.toLowerCase().includes('high') || adj.priority?.toLowerCase().includes('critical'))
                                    .slice(0, 3)
                                    .map((adj, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400">→</span>
                                            {adj.adjustment}
                                        </li>
                                    ))}
                            </ul>
                        </div>
                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                            <h5 className="text-amber-400 font-semibold text-sm mb-2">Watch Out For</h5>
                            <ul className="space-y-1">
                                {analysis.tactical_mistakes?.slice(0, 3).map((mistake, i) => (
                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-amber-400">⚠</span>
                                        Avoid: {mistake.mistake}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}