import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, Loader2 } from 'lucide-react';

export default function ClubNeedsInput({ onSubmit, isLoading }) {
    const [needs, setNeeds] = useState({
        squadGaps: '',
        playingStyle: '',
        budget: '',
        ageProfile: '',
        priority: 'Medium',
        timeline: '',
        additionalRequirements: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(needs);
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base sm:text-lg">
                    <Target className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
                    Define Club Requirements
                </CardTitle>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                        <div>
                            <Label className="text-slate-400 text-sm">Squad Gaps / Positions Needed</Label>
                            <Input
                                value={needs.squadGaps}
                                onChange={(e) => setNeeds({...needs, squadGaps: e.target.value})}
                                placeholder="e.g., Centre-back, Right Winger"
                                className="bg-slate-800 border-slate-700 text-white mt-1 text-sm"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400 text-sm">Budget Range</Label>
                            <Input
                                value={needs.budget}
                                onChange={(e) => setNeeds({...needs, budget: e.target.value})}
                                placeholder="e.g., €10M - €25M"
                                className="bg-slate-800 border-slate-700 text-white mt-1 text-sm"
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                        <div>
                            <Label className="text-slate-400 text-sm">Age Profile</Label>
                            <Input
                                value={needs.ageProfile}
                                onChange={(e) => setNeeds({...needs, ageProfile: e.target.value})}
                                placeholder="e.g., 21-25 years old"
                                className="bg-slate-800 border-slate-700 text-white mt-1 text-sm"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400 text-sm">Timeline</Label>
                            <Select value={needs.timeline} onValueChange={(v) => setNeeds({...needs, timeline: v})}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white text-sm">
                                    <SelectValue placeholder="Select timeline" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Immediate (This window)">Immediate (This window)</SelectItem>
                                    <SelectItem value="Next transfer window">Next transfer window</SelectItem>
                                    <SelectItem value="Long-term (6-12 months)">Long-term (6-12 months)</SelectItem>
                                    <SelectItem value="Future planning">Future planning</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-400 text-sm">Preferred Playing Style</Label>
                        <Input
                            value={needs.playingStyle}
                            onChange={(e) => setNeeds({...needs, playingStyle: e.target.value})}
                            placeholder="e.g., Possession-based, Counter-attacking"
                            className="bg-slate-800 border-slate-700 text-white mt-1 text-sm"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-400 text-sm">Priority Level</Label>
                        <Select value={needs.priority} onValueChange={(v) => setNeeds({...needs, priority: v})}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white text-sm">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Critical">Critical</SelectItem>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Medium">Medium</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div>
                        <Label className="text-slate-400 text-sm">Additional Requirements</Label>
                        <Textarea
                            value={needs.additionalRequirements}
                            onChange={(e) => setNeeds({...needs, additionalRequirements: e.target.value})}
                            placeholder="e.g., Must be left-footed, Premier League experience..."
                            className="bg-slate-800 border-slate-700 text-white mt-1 text-sm"
                            rows={3}
                        />
                    </div>

                    <Button
                        type="submit"
                        disabled={isLoading || !needs.squadGaps}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-sm sm:text-base"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="w-3 h-3 sm:w-4 sm:h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Target className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                                Find Matching Players
                            </>
                        )}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}