import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { CheckCircle, AlertTriangle, TrendingUp, Clock, Phone, FileText, Mail, ClipboardList } from 'lucide-react';
import { motion } from 'framer-motion';
import TaskForm from '../workflow/TaskForm';

export default function MatchResults({ matches }) {
    const [expandedMatch, setExpandedMatch] = useState(null);
    const [showTaskDialog, setShowTaskDialog] = useState(false);
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const getMatchColor = (score) => {
        if (score >= 85) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (score >= 70) return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        if (score >= 60) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    const getPriorityColor = (priority) => {
        if (priority === 'Critical') return 'bg-red-500/20 text-red-400';
        if (priority === 'High') return 'bg-amber-500/20 text-amber-400';
        if (priority === 'Medium') return 'bg-cyan-500/20 text-cyan-400';
        return 'bg-slate-500/20 text-slate-400';
    };

    const getComplexityColor = (complexity) => {
        if (complexity === 'Easy') return 'text-emerald-400';
        if (complexity === 'Moderate') return 'text-amber-400';
        return 'text-red-400';
    };

    const sortedMatches = [...matches.matches].sort((a, b) => b.match_score - a.match_score);

    return (
        <div className="space-y-4 sm:space-y-6">
            {matches.summary && (
                <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                    <CardContent className="pt-4 sm:pt-6">
                        <p className="text-slate-300 text-xs sm:text-sm">{matches.summary}</p>
                    </CardContent>
                </Card>
            )}

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2 text-base sm:text-lg">
                        <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
                        Matched Players ({sortedMatches.length})
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3 sm:space-y-4">
                        {sortedMatches.map((match, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/30 transition-all">
                                    <CardHeader className="pb-3 sm:pb-6">
                                        <div className="flex flex-col sm:flex-row justify-between items-start gap-2 sm:gap-0">
                                            <div className="flex-1 w-full">
                                                <div className="flex flex-wrap items-center gap-2 mb-2">
                                                    <h3 className="text-white font-bold text-base sm:text-lg">{match.player_name}</h3>
                                                    <Badge className={`${getPriorityColor(match.priority)} text-xs`}>
                                                        {match.priority}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-xs sm:text-sm">
                                                    {match.age}y • {match.position} • {match.current_club}
                                                </p>
                                            </div>
                                            <Badge className={`${getMatchColor(match.match_score)} text-sm sm:text-base px-2 sm:px-3 py-1 shrink-0`}>
                                                {match.match_score}%
                                            </Badge>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-3 sm:space-y-4">
                                        <div className="grid grid-cols-3 gap-2 sm:gap-4 text-xs sm:text-sm">
                                            <div>
                                                <p className="text-slate-500 text-[10px] sm:text-xs mb-1">Est. Fee</p>
                                                <p className="text-emerald-400 font-semibold text-xs sm:text-sm">{match.estimated_fee}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-[10px] sm:text-xs mb-1">Complexity</p>
                                                <p className={`font-semibold text-xs sm:text-sm ${getComplexityColor(match.transfer_complexity)}`}>
                                                    {match.transfer_complexity}
                                                </p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-[10px] sm:text-xs mb-1">Timeline</p>
                                                <p className="text-cyan-400 font-semibold text-xs sm:text-sm">{match.timeline_fit}</p>
                                            </div>
                                        </div>

                                        <div className="bg-slate-900/50 rounded-lg p-3 sm:p-4">
                                            <h4 className="text-cyan-400 font-semibold text-xs sm:text-sm mb-2">Why This Match?</h4>
                                            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">{match.rationale}</p>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                                            <div>
                                                <h4 className="text-emerald-400 font-semibold text-xs sm:text-sm mb-2 flex items-center gap-2">
                                                    <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4" />
                                                    Key Strengths
                                                </h4>
                                                <ul className="space-y-1">
                                                    {match.key_strengths.map((strength, i) => (
                                                        <li key={i} className="text-slate-300 text-xs sm:text-sm">
                                                            ✓ {strength}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            {match.concerns && match.concerns.length > 0 && (
                                                <div>
                                                    <h4 className="text-amber-400 font-semibold text-xs sm:text-sm mb-2 flex items-center gap-2">
                                                        <AlertTriangle className="w-3 h-3 sm:w-4 sm:h-4" />
                                                        Concerns
                                                    </h4>
                                                    <ul className="space-y-1">
                                                        {match.concerns.map((concern, i) => (
                                                            <li key={i} className="text-slate-300 text-xs sm:text-sm">
                                                                ⚠ {concern}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}
                                        </div>

                                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 sm:p-4">
                                            <h4 className="text-blue-400 font-semibold text-xs sm:text-sm mb-2 sm:mb-3 flex items-center gap-2">
                                                <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                                                Next Steps
                                            </h4>
                                            <div className="space-y-1.5 sm:space-y-2">
                                                {match.next_steps.map((step, i) => (
                                                    <div key={i} className="flex items-start gap-2">
                                                        <span className="text-blue-400 font-bold text-[10px] sm:text-xs mt-0.5">{i + 1}.</span>
                                                        <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">{step}</p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="flex gap-2 flex-wrap">
                                            <Button 
                                                size="sm" 
                                                onClick={() => {
                                                    setSelectedPlayer(match);
                                                    setShowTaskDialog(true);
                                                }}
                                                className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 text-xs sm:text-sm"
                                            >
                                                <ClipboardList className="w-3 h-3 mr-1 sm:mr-2" />
                                                Create Task
                                            </Button>
                                            <Button 
                                                size="sm" 
                                                className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 text-xs sm:text-sm"
                                            >
                                                <Phone className="w-3 h-3 mr-1 sm:mr-2" />
                                                Contact
                                            </Button>
                                            <Button 
                                                size="sm" 
                                                className="bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 text-xs sm:text-sm"
                                            >
                                                <FileText className="w-3 h-3 mr-1 sm:mr-2" />
                                                Report
                                            </Button>
                                            <Button 
                                                size="sm" 
                                                className="bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 text-xs sm:text-sm"
                                            >
                                                <Mail className="w-3 h-3 mr-1 sm:mr-2" />
                                                Send
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Create Task Dialog */}
            <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                    <DialogHeader>
                        <DialogTitle>Create Scouting Task</DialogTitle>
                    </DialogHeader>
                    {selectedPlayer && (
                        <TaskForm 
                            onClose={() => setShowTaskDialog(false)} 
                            linkedPlayer={selectedPlayer}
                        />
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}