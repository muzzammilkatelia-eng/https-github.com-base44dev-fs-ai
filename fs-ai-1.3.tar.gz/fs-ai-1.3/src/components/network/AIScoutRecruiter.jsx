import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Zap, Loader2, Search, CheckCircle, UserPlus, Target, GitCompare, FileText, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIScoutRecruiter({ onScoutAdded }) {
    const [activeTab, setActiveTab] = useState('recruit');
    const [searchCriteria, setSearchCriteria] = useState({
        region: '',
        specialization: '',
        experience_level: '',
        additional_requirements: ''
    });
    const [candidates, setCandidates] = useState(null);
    const [transferTargets, setTransferTargets] = useState(null);
    const [comparisonReport, setComparisonReport] = useState(null);
    const [contractSuggestion, setContractSuggestion] = useState(null);
    const [targetCriteria, setTargetCriteria] = useState('');
    const [comparisonPlayers, setComparisonPlayers] = useState({ player1: '', player2: '' });
    const [contractPlayer, setContractPlayer] = useState('');

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const { data: messages = [] } = useQuery({
        queryKey: ['scout-messages'],
        queryFn: () => base44.entities.ScoutMessage.list('-created_date', 50)
    });

    const queryClient = useQueryClient();

    const searchScoutsMutation = useMutation({
        mutationFn: async (criteria) => {
            const prompt = `You are an elite talent acquisition AI specializing in football scouting networks. Search for and vet potential scouts based on these criteria:

SEARCH CRITERIA:
- Region: ${criteria.region || 'Global'}
- Specialization: ${criteria.specialization || 'General'}
- Experience Level: ${criteria.experience_level || 'Any'}
- Additional: ${criteria.additional_requirements || 'None'}

Identify 5-8 potential scout candidates with:

1. **Professional Background**:
   - Full name (realistic)
   - Email (professional format)
   - Phone (with country code)
   - Current location/region
   - Years of experience

2. **Expertise**:
   - Countries/leagues covered
   - Position specializations
   - Languages spoken
   - Certifications/licenses

3. **Credentials**:
   - Previous clubs worked with
   - Notable discoveries
   - Professional network

4. **AI Vetting Assessment** (0-100):
   - Credibility score
   - Network strength
   - Track record
   - Risk assessment
   - Overall recommendation

Be realistic and provide diverse candidates from different backgrounds. Include contact information and detailed vetting analysis.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        candidates: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    full_name: { type: "string" },
                                    email: { type: "string" },
                                    phone: { type: "string" },
                                    region: { type: "string" },
                                    countries: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    specializations: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    experience_years: { type: "number" },
                                    languages: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    credentials: {
                                        type: "object",
                                        properties: {
                                            previous_clubs: {
                                                type: "array",
                                                items: { type: "string" }
                                            },
                                            certifications: {
                                                type: "array",
                                                items: { type: "string" }
                                            }
                                        }
                                    },
                                    ai_vetting_score: { type: "number" },
                                    vetting_notes: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setCandidates(data.candidates);
            toast.success(`Found ${data.candidates.length} scout candidates`);
        },
        onError: () => {
            toast.error('Search failed');
        }
    });

    const addScoutMutation = useMutation({
        mutationFn: (scoutData) => base44.entities.Scout.create({
            ...scoutData,
            status: 'Vetting',
            verification_status: 'Pending'
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouts'] });
            toast.success('Scout added for vetting');
            onScoutAdded();
        }
    });

    const identifyTransferTargetsMutation = useMutation({
        mutationFn: async (criteria) => {
            const reportContext = reports.slice(0, 10).map(r => 
                `${r.player_name} (Age: ${r.player_age}, Position: ${r.position}, Recommendation: ${r.recommendation})`
            ).join('\n');

            const messageContext = messages.slice(0, 10).map(m => 
                `Scout ${m.scout_name}: ${m.subject} - ${m.message.substring(0, 100)}...`
            ).join('\n');

            const prompt = `You are an elite football transfer strategy AI. Analyze recent scout reports and messages to identify potential transfer targets.

RECENT SCOUT REPORTS:
${reportContext}

RECENT SCOUT MESSAGES:
${messageContext}

SEARCH CRITERIA: ${criteria || 'General analysis'}

Identify 5-8 high-potential transfer targets based on:
1. Scout recommendations and reports
2. Market value and value-for-money
3. Position needs and tactical fit
4. Age profile and development potential
5. Contract situations and availability

For each target provide:
- Player name, age, position, current club
- Why they're a good target (based on reports/intel)
- Estimated transfer fee and market value
- Priority rating (Critical/High/Medium)
- Best approach strategy
- Risk factors`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        targets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    current_club: { type: "string" },
                                    rationale: { type: "string" },
                                    estimated_fee: { type: "string" },
                                    market_value: { type: "string" },
                                    priority: { type: "string" },
                                    approach_strategy: { type: "string" },
                                    risk_factors: { type: "array", items: { type: "string" } }
                                }
                            }
                        }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setTransferTargets(data.targets);
            toast.success(`Identified ${data.targets.length} transfer targets`);
        }
    });

    const generateComparisonMutation = useMutation({
        mutationFn: async (players) => {
            const prompt = `You are an elite football analytics AI. Generate a comprehensive comparison between two players:

Player 1: ${players.player1}
Player 2: ${players.player2}

Provide detailed comparison covering:
1. Technical abilities (passing, dribbling, shooting, etc.)
2. Physical attributes (pace, strength, stamina)
3. Tactical intelligence and positioning
4. Mental attributes (decision-making, composure)
5. Statistical comparison (goals, assists, key metrics)
6. Market value and transfer value
7. Development trajectory
8. Overall recommendation for signing

Be objective and data-driven. Include specific scores and metrics.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player1_name: { type: "string" },
                        player2_name: { type: "string" },
                        technical: {
                            type: "object",
                            properties: {
                                player1_score: { type: "number" },
                                player2_score: { type: "number" },
                                analysis: { type: "string" }
                            }
                        },
                        physical: {
                            type: "object",
                            properties: {
                                player1_score: { type: "number" },
                                player2_score: { type: "number" },
                                analysis: { type: "string" }
                            }
                        },
                        tactical: {
                            type: "object",
                            properties: {
                                player1_score: { type: "number" },
                                player2_score: { type: "number" },
                                analysis: { type: "string" }
                            }
                        },
                        market_value: {
                            type: "object",
                            properties: {
                                player1: { type: "string" },
                                player2: { type: "string" },
                                better_value: { type: "string" }
                            }
                        },
                        recommendation: { type: "string" },
                        winner: { type: "string" }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setComparisonReport(data);
            toast.success('Comparison report generated');
        }
    });

    const suggestContractMutation = useMutation({
        mutationFn: async (playerName) => {
            const prompt = `You are an elite football contract negotiation AI. Analyze player performance, market trends, and contract benchmarks to suggest optimal contract terms for: ${playerName}

Consider:
1. Current market value and recent transfer fees for similar players
2. Player's age, potential, and career trajectory
3. League and club financial standards
4. Performance metrics and achievements
5. Contract length best practices
6. Salary structure and bonuses
7. Release clause recommendations
8. Agent commission expectations

Provide detailed contract recommendations including salary ranges, bonuses, clauses, and negotiation strategy.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        recommended_salary: {
                            type: "object",
                            properties: {
                                base_salary: { type: "string" },
                                signing_bonus: { type: "string" },
                                performance_bonuses: { type: "array", items: { type: "string" } }
                            }
                        },
                        contract_length: { type: "string" },
                        release_clause: { type: "string" },
                        agent_commission: { type: "string" },
                        salary_progression: { type: "string" },
                        key_clauses: { type: "array", items: { type: "string" } },
                        negotiation_strategy: { type: "string" },
                        market_benchmark: { type: "string" }
                    }
                }
            });
            return result;
        },
        onSuccess: (data) => {
            setContractSuggestion(data);
            toast.success('Contract terms generated');
        }
    });

    const handleSearch = (e) => {
        e.preventDefault();
        searchScoutsMutation.mutate(searchCriteria);
    };

    return (
        <div className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    <TabsTrigger value="recruit" className="data-[state=active]:bg-purple-500/20">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Recruit Scouts
                    </TabsTrigger>
                    <TabsTrigger value="targets" className="data-[state=active]:bg-cyan-500/20">
                        <Target className="w-4 h-4 mr-2" />
                        Transfer Targets
                    </TabsTrigger>
                    <TabsTrigger value="compare" className="data-[state=active]:bg-emerald-500/20">
                        <GitCompare className="w-4 h-4 mr-2" />
                        Compare Players
                    </TabsTrigger>
                    <TabsTrigger value="contracts" className="data-[state=active]:bg-amber-500/20">
                        <FileText className="w-4 h-4 mr-2" />
                        Contract Terms
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="recruit">
            <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-purple-400" />
                        AI-Powered Scout Recruitment
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Autonomously search and vet potential scouts worldwide using AI
                    </p>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSearch} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-400">Target Region</Label>
                                <Input
                                    value={searchCriteria.region}
                                    onChange={(e) => setSearchCriteria({...searchCriteria, region: e.target.value})}
                                    placeholder="e.g., South America, West Africa"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400">Specialization</Label>
                                <Input
                                    value={searchCriteria.specialization}
                                    onChange={(e) => setSearchCriteria({...searchCriteria, specialization: e.target.value})}
                                    placeholder="e.g., Young strikers, Technical midfielders"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-400">Experience Level</Label>
                            <Input
                                value={searchCriteria.experience_level}
                                onChange={(e) => setSearchCriteria({...searchCriteria, experience_level: e.target.value})}
                                placeholder="e.g., 5+ years, Senior level"
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                        </div>

                        <div>
                            <Label className="text-slate-400">Additional Requirements (optional)</Label>
                            <Textarea
                                value={searchCriteria.additional_requirements}
                                onChange={(e) => setSearchCriteria({...searchCriteria, additional_requirements: e.target.value})}
                                placeholder="Languages, connections, specific leagues..."
                                className="bg-slate-800 border-slate-700 text-white mt-1"
                                rows={3}
                            />
                        </div>

                        <Button
                            type="submit"
                            disabled={searchScoutsMutation.isPending}
                            className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500"
                        >
                            {searchScoutsMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Searching Global Networks...
                                </>
                            ) : (
                                <>
                                    <Search className="w-4 h-4 mr-2" />
                                    Search & Vet Scouts
                                </>
                            )}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            <AnimatePresence>
                {candidates && candidates.length > 0 && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">
                                    AI-Vetted Candidates ({candidates.length})
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                    {candidates.map((candidate, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                                        >
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h4 className="text-white font-semibold">{candidate.full_name}</h4>
                                                    <p className="text-slate-400 text-sm">{candidate.region}</p>
                                                </div>
                                                <Badge className={
                                                    candidate.ai_vetting_score >= 80 ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                                                    candidate.ai_vetting_score >= 60 ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                                                    'bg-red-500/20 text-red-400 border-red-500/30'
                                                }>
                                                    {candidate.ai_vetting_score}/100
                                                </Badge>
                                            </div>

                                            <div className="space-y-2 text-sm">
                                                <div>
                                                    <span className="text-slate-500">Experience:</span>
                                                    <span className="text-white ml-2">{candidate.experience_years} years</span>
                                                </div>
                                                <div>
                                                    <span className="text-slate-500">Email:</span>
                                                    <span className="text-cyan-400 ml-2">{candidate.email}</span>
                                                </div>
                                                {candidate.countries && candidate.countries.length > 0 && (
                                                    <div>
                                                        <span className="text-slate-500">Countries:</span>
                                                        <div className="flex flex-wrap gap-1 mt-1">
                                                            {candidate.countries.map((c, i) => (
                                                                <Badge key={i} className="bg-slate-700 text-slate-300 text-xs">
                                                                    {c}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                                {candidate.specializations && candidate.specializations.length > 0 && (
                                                    <div>
                                                        <span className="text-slate-500">Specializations:</span>
                                                        <div className="flex flex-wrap gap-1 mt-1">
                                                            {candidate.specializations.map((s, i) => (
                                                                <Badge key={i} className="bg-purple-500/20 text-purple-400 text-xs">
                                                                    {s}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                            <div className="bg-slate-900/50 rounded p-2">
                                                <p className="text-slate-400 text-xs mb-1">AI Vetting Notes:</p>
                                                <p className="text-slate-300 text-xs">{candidate.vetting_notes}</p>
                                            </div>

                                            <Button
                                                onClick={() => addScoutMutation.mutate(candidate)}
                                                disabled={addScoutMutation.isPending}
                                                size="sm"
                                                className="w-full bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                                            >
                                                <UserPlus className="w-3 h-3 mr-2" />
                                                Add to Vetting
                                            </Button>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>
                </TabsContent>

                <TabsContent value="targets">
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <Target className="w-5 h-5 text-cyan-400" />
                                AI Transfer Target Identification
                            </CardTitle>
                            <p className="text-slate-400 text-sm">
                                Automatically identify potential transfers based on scout reports and intel
                            </p>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div>
                                    <Label className="text-slate-400">Search Criteria (optional)</Label>
                                    <Textarea
                                        value={targetCriteria}
                                        onChange={(e) => setTargetCriteria(e.target.value)}
                                        placeholder="e.g., Young strikers under 23, Value under €20M, Premier League ready..."
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                        rows={3}
                                    />
                                </div>
                                <Button
                                    onClick={() => identifyTransferTargetsMutation.mutate(targetCriteria)}
                                    disabled={identifyTransferTargetsMutation.isPending}
                                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                                >
                                    {identifyTransferTargetsMutation.isPending ? (
                                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing Reports & Intel...</>
                                    ) : (
                                        <><Target className="w-4 h-4 mr-2" />Identify Transfer Targets</>
                                    )}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    <AnimatePresence>
                        {transferTargets && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">Identified Targets ({transferTargets.length})</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-4">
                                            {transferTargets.map((target, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4 space-y-3">
                                                    <div className="flex justify-between items-start">
                                                        <div>
                                                            <h4 className="text-white font-semibold text-lg">{target.player_name}</h4>
                                                            <p className="text-slate-400 text-sm">{target.age} years • {target.position} • {target.current_club}</p>
                                                        </div>
                                                        <Badge className={
                                                            target.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                            target.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                            'bg-blue-500/20 text-blue-400'
                                                        }>
                                                            {target.priority}
                                                        </Badge>
                                                    </div>
                                                    <div className="grid grid-cols-2 gap-4 text-sm">
                                                        <div>
                                                            <span className="text-slate-500">Estimated Fee:</span>
                                                            <span className="text-emerald-400 ml-2 font-semibold">{target.estimated_fee}</span>
                                                        </div>
                                                        <div>
                                                            <span className="text-slate-500">Market Value:</span>
                                                            <span className="text-cyan-400 ml-2 font-semibold">{target.market_value}</span>
                                                        </div>
                                                    </div>
                                                    <div className="bg-slate-900/50 rounded p-3">
                                                        <p className="text-slate-400 text-xs mb-1">Rationale:</p>
                                                        <p className="text-slate-300 text-sm">{target.rationale}</p>
                                                    </div>
                                                    <div className="bg-blue-500/10 rounded p-3 border border-blue-500/30">
                                                        <p className="text-blue-400 text-xs mb-1 font-semibold">Approach Strategy:</p>
                                                        <p className="text-slate-300 text-sm">{target.approach_strategy}</p>
                                                    </div>
                                                    {target.risk_factors && target.risk_factors.length > 0 && (
                                                        <div className="flex gap-1 flex-wrap">
                                                            {target.risk_factors.map((risk, i) => (
                                                                <Badge key={i} className="bg-red-500/10 text-red-400 text-xs">
                                                                    ⚠️ {risk}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </TabsContent>

                <TabsContent value="compare">
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <GitCompare className="w-5 h-5 text-emerald-400" />
                                Player Comparison Report
                            </CardTitle>
                            <p className="text-slate-400 text-sm">
                                Generate detailed AI-powered comparison between two players
                            </p>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <Label className="text-slate-400">Player 1</Label>
                                        <Input
                                            value={comparisonPlayers.player1}
                                            onChange={(e) => setComparisonPlayers({...comparisonPlayers, player1: e.target.value})}
                                            placeholder="e.g., Erling Haaland"
                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-slate-400">Player 2</Label>
                                        <Input
                                            value={comparisonPlayers.player2}
                                            onChange={(e) => setComparisonPlayers({...comparisonPlayers, player2: e.target.value})}
                                            placeholder="e.g., Kylian Mbappé"
                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                        />
                                    </div>
                                </div>
                                <Button
                                    onClick={() => generateComparisonMutation.mutate(comparisonPlayers)}
                                    disabled={!comparisonPlayers.player1 || !comparisonPlayers.player2 || generateComparisonMutation.isPending}
                                    className="w-full bg-gradient-to-r from-emerald-500 to-green-600"
                                >
                                    {generateComparisonMutation.isPending ? (
                                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Generating Comparison...</>
                                    ) : (
                                        <><GitCompare className="w-4 h-4 mr-2" />Generate Comparison</>
                                    )}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    <AnimatePresence>
                        {comparisonReport && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">
                                            {comparisonReport.player1_name} vs {comparisonReport.player2_name}
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        {['technical', 'physical', 'tactical'].map((category) => (
                                            <div key={category} className="bg-slate-800/50 rounded-lg p-4">
                                                <h4 className="text-white font-semibold capitalize mb-3">{category}</h4>
                                                <div className="flex items-center gap-4 mb-2">
                                                    <div className="flex-1">
                                                        <div className="flex justify-between mb-1">
                                                            <span className="text-slate-400 text-sm">{comparisonReport.player1_name}</span>
                                                            <span className="text-cyan-400 font-semibold">{comparisonReport[category].player1_score}/100</span>
                                                        </div>
                                                        <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                                                            <div 
                                                                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                                                                style={{width: `${comparisonReport[category].player1_score}%`}}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="flex-1">
                                                        <div className="flex justify-between mb-1">
                                                            <span className="text-slate-400 text-sm">{comparisonReport.player2_name}</span>
                                                            <span className="text-emerald-400 font-semibold">{comparisonReport[category].player2_score}/100</span>
                                                        </div>
                                                        <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                                                            <div 
                                                                className="h-full bg-gradient-to-r from-emerald-500 to-green-500"
                                                                style={{width: `${comparisonReport[category].player2_score}%`}}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <p className="text-slate-300 text-sm mt-2">{comparisonReport[category].analysis}</p>
                                            </div>
                                        ))}

                                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                            <h4 className="text-amber-400 font-semibold mb-2">Market Value Comparison</h4>
                                            <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                                                <div>
                                                    <span className="text-slate-400">{comparisonReport.player1_name}:</span>
                                                    <span className="text-white ml-2 font-semibold">{comparisonReport.market_value.player1}</span>
                                                </div>
                                                <div>
                                                    <span className="text-slate-400">{comparisonReport.player2_name}:</span>
                                                    <span className="text-white ml-2 font-semibold">{comparisonReport.market_value.player2}</span>
                                                </div>
                                            </div>
                                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                                Better Value: {comparisonReport.market_value.better_value}
                                            </Badge>
                                        </div>

                                        <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-lg p-4">
                                            <h4 className="text-purple-400 font-semibold mb-2 flex items-center gap-2">
                                                <TrendingUp className="w-4 h-4" />
                                                Final Recommendation
                                            </h4>
                                            <p className="text-white text-sm mb-2">{comparisonReport.recommendation}</p>
                                            <Badge className="bg-purple-500/20 text-purple-400 text-lg">
                                                Winner: {comparisonReport.winner}
                                            </Badge>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </TabsContent>

                <TabsContent value="contracts">
                    <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <FileText className="w-5 h-5 text-amber-400" />
                                AI Contract Term Suggestions
                            </CardTitle>
                            <p className="text-slate-400 text-sm">
                                Get optimal contract recommendations based on market trends and performance
                            </p>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div>
                                    <Label className="text-slate-400">Player Name</Label>
                                    <Input
                                        value={contractPlayer}
                                        onChange={(e) => setContractPlayer(e.target.value)}
                                        placeholder="e.g., Jude Bellingham"
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>
                                <Button
                                    onClick={() => suggestContractMutation.mutate(contractPlayer)}
                                    disabled={!contractPlayer || suggestContractMutation.isPending}
                                    className="w-full bg-gradient-to-r from-amber-500 to-orange-600"
                                >
                                    {suggestContractMutation.isPending ? (
                                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing Market Data...</>
                                    ) : (
                                        <><FileText className="w-4 h-4 mr-2" />Generate Contract Proposal</>
                                    )}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    <AnimatePresence>
                        {contractSuggestion && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">Contract Proposal: {contractSuggestion.player_name}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                                <h4 className="text-emerald-400 font-semibold mb-2">Base Salary</h4>
                                                <p className="text-white text-2xl font-bold">{contractSuggestion.recommended_salary.base_salary}</p>
                                            </div>
                                            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                                <h4 className="text-amber-400 font-semibold mb-2">Signing Bonus</h4>
                                                <p className="text-white text-2xl font-bold">{contractSuggestion.recommended_salary.signing_bonus}</p>
                                            </div>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-cyan-400 font-semibold mb-2">Performance Bonuses</h4>
                                            <ul className="space-y-1">
                                                {contractSuggestion.recommended_salary.performance_bonuses.map((bonus, i) => (
                                                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                        <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                                        {bonus}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="grid grid-cols-3 gap-4 text-sm">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 mb-1">Contract Length</p>
                                                <p className="text-white font-semibold">{contractSuggestion.contract_length}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 mb-1">Release Clause</p>
                                                <p className="text-white font-semibold">{contractSuggestion.release_clause}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 mb-1">Agent Fee</p>
                                                <p className="text-white font-semibold">{contractSuggestion.agent_commission}</p>
                                            </div>
                                        </div>

                                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                                            <h4 className="text-blue-400 font-semibold mb-2">Salary Progression</h4>
                                            <p className="text-slate-300 text-sm">{contractSuggestion.salary_progression}</p>
                                        </div>

                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-purple-400 font-semibold mb-2">Key Contract Clauses</h4>
                                            <ul className="space-y-1">
                                                {contractSuggestion.key_clauses.map((clause, i) => (
                                                    <li key={i} className="text-slate-300 text-sm">• {clause}</li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                                            <h4 className="text-purple-400 font-semibold mb-2">Negotiation Strategy</h4>
                                            <p className="text-slate-300 text-sm mb-3">{contractSuggestion.negotiation_strategy}</p>
                                            <div className="bg-slate-900/50 rounded p-3">
                                                <p className="text-slate-400 text-xs mb-1">Market Benchmark:</p>
                                                <p className="text-white text-sm">{contractSuggestion.market_benchmark}</p>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </TabsContent>
            </Tabs>
        </div>
    );
}