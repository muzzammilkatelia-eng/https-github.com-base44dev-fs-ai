import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    FileEdit, Plus, Save, Eye, MessageSquare, Users, 
    Clock, CheckCircle, Lock, Loader2, Send 
} from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function CollaborativeEditor({ scouts }) {
    const [showNewReport, setShowNewReport] = useState(false);
    const [selectedReport, setSelectedReport] = useState(null);
    const [editMode, setEditMode] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);

    const [formData, setFormData] = useState({
        title: '',
        player_name: '',
        report_type: 'Initial Assessment',
        access_level: 'Internal',
        sections: {
            technical_skills: '',
            physical_attributes: '',
            tactical_awareness: '',
            mental_attributes: '',
            strengths: '',
            weaknesses: '',
            recommendation: ''
        }
    });

    const [comment, setComment] = useState('');

    const queryClient = useQueryClient();

    React.useEffect(() => {
        base44.auth.me().then(setCurrentUser).catch(() => {});
    }, []);

    const { data: reports = [], isLoading } = useQuery({
        queryKey: ['collaborative-reports'],
        queryFn: () => base44.entities.CollaborativeReport.list('-last_edited_at')
    });

    const createReportMutation = useMutation({
        mutationFn: (reportData) => base44.entities.CollaborativeReport.create({
            ...reportData,
            contributors: [{
                email: currentUser.email,
                name: currentUser.full_name || currentUser.email,
                role: currentUser.role,
                contributions: 1
            }],
            status: 'Draft',
            version: 1,
            change_log: [{
                timestamp: new Date().toISOString(),
                user: currentUser.email,
                change: 'Report created'
            }],
            comments: [],
            last_edited_by: currentUser.email,
            last_edited_at: new Date().toISOString()
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['collaborative-reports'] });
            setShowNewReport(false);
            toast.success('Report created');
            setFormData({
                title: '',
                player_name: '',
                report_type: 'Initial Assessment',
                access_level: 'Internal',
                sections: {
                    technical_skills: '',
                    physical_attributes: '',
                    tactical_awareness: '',
                    mental_attributes: '',
                    strengths: '',
                    weaknesses: '',
                    recommendation: ''
                }
            });
        }
    });

    const updateReportMutation = useMutation({
        mutationFn: async ({ reportId, updates }) => {
            const updatedChangeLog = [
                ...(selectedReport.change_log || []),
                {
                    timestamp: new Date().toISOString(),
                    user: currentUser.email,
                    change: updates.status === 'Approved' ? 'Report approved' : 'Report updated'
                }
            ];

            // Update contributors
            let contributors = selectedReport.contributors || [];
            const existingContributor = contributors.find(c => c.email === currentUser.email);
            if (existingContributor) {
                existingContributor.contributions += 1;
            } else {
                contributors.push({
                    email: currentUser.email,
                    name: currentUser.full_name || currentUser.email,
                    role: currentUser.role,
                    contributions: 1
                });
            }

            const result = await base44.entities.CollaborativeReport.update(reportId, {
                ...updates,
                version: (selectedReport.version || 1) + 1,
                change_log: updatedChangeLog,
                contributors: contributors,
                last_edited_by: currentUser.email,
                last_edited_at: new Date().toISOString()
            });

            // If status changed to Approved, send Slack notification
            if (updates.status === 'Approved' && selectedReport.status !== 'Approved') {
                try {
                    const notifyResult = await base44.functions.notifyDocumentApproval({
                        documentId: reportId,
                        documentType: 'collaborative_report'
                    });
                    
                    if (notifyResult.success) {
                        toast.success('Announcement posted to Slack #announcements');
                    }
                } catch (error) {
                    console.log('Slack notification skipped:', error);
                }
            }

            return result;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['collaborative-reports'] });
            setEditMode(false);
            toast.success('Report updated');
        }
    });

    const addCommentMutation = useMutation({
        mutationFn: ({ reportId, commentText }) => {
            const newComment = {
                user: currentUser.email,
                comment: commentText,
                timestamp: new Date().toISOString(),
                resolved: false
            };
            const updatedComments = [...(selectedReport.comments || []), newComment];
            return base44.entities.CollaborativeReport.update(reportId, {
                comments: updatedComments
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['collaborative-reports'] });
            setComment('');
            toast.success('Comment added');
        }
    });

    const handleSaveReport = () => {
        if (selectedReport && editMode) {
            updateReportMutation.mutate({
                reportId: selectedReport.id,
                updates: formData
            });
        } else {
            createReportMutation.mutate(formData);
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            'Draft': 'bg-slate-500/20 text-slate-400',
            'In Review': 'bg-amber-500/20 text-amber-400',
            'Approved': 'bg-emerald-500/20 text-emerald-400',
            'Published': 'bg-cyan-500/20 text-cyan-400',
            'Archived': 'bg-slate-700/20 text-slate-500'
        };
        return colors[status] || '';
    };

    const getAccessColor = (level) => {
        const colors = {
            'Internal': 'bg-blue-500/20 text-blue-400',
            'Confidential': 'bg-amber-500/20 text-amber-400',
            'Restricted': 'bg-red-500/20 text-red-400'
        };
        return colors[level] || '';
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-white">Collaborative Reports</h2>
                    <p className="text-slate-400 text-sm">Create and edit scouting reports with your team</p>
                </div>
                <Dialog open={showNewReport} onOpenChange={setShowNewReport}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600">
                            <Plus className="w-4 h-4 mr-2" />
                            New Report
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 max-w-4xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle className="text-white">Create New Report</DialogTitle>
                        </DialogHeader>
                        <ReportForm 
                            formData={formData} 
                            setFormData={setFormData} 
                            onSave={handleSaveReport}
                            isLoading={createReportMutation.isPending}
                        />
                    </DialogContent>
                </Dialog>
            </div>

            {/* Reports Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {reports.map((report, idx) => (
                    <motion.div
                        key={report.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/30 transition-all cursor-pointer"
                              onClick={() => {
                                  setSelectedReport(report);
                                  setFormData(report);
                              }}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <CardTitle className="text-white text-lg mb-2">{report.title}</CardTitle>
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                {report.player_name}
                                            </Badge>
                                            <Badge className={getStatusColor(report.status)}>
                                                {report.status}
                                            </Badge>
                                            <Badge className={getAccessColor(report.access_level)}>
                                                <Lock className="w-3 h-3 mr-1" />
                                                {report.access_level}
                                            </Badge>
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between text-sm">
                                        <div className="flex items-center gap-2">
                                            <Users className="w-3 h-3 text-slate-400" />
                                            <span className="text-slate-400">
                                                {report.contributors?.length || 0} contributor(s)
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <MessageSquare className="w-3 h-3 text-slate-400" />
                                            <span className="text-slate-400">
                                                {report.comments?.length || 0} comment(s)
                                            </span>
                                        </div>
                                    </div>
                                    <div className="text-xs text-slate-500">
                                        <div>Version {report.version || 1}</div>
                                        <div>Last edited {moment(report.last_edited_at).fromNow()}</div>
                                        <div>by {report.last_edited_by}</div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {/* Report Viewer/Editor */}
            {selectedReport && (
                <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
                    <DialogContent className="bg-slate-900 border-slate-800 max-w-6xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <div className="flex justify-between items-start">
                                <div>
                                    <DialogTitle className="text-white text-xl">{selectedReport.title}</DialogTitle>
                                    <div className="flex items-center gap-2 mt-2">
                                        <Badge className={getStatusColor(selectedReport.status)}>
                                            {selectedReport.status}
                                        </Badge>
                                        <Badge className="bg-purple-500/20 text-purple-400">
                                            {selectedReport.player_name}
                                        </Badge>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    {!editMode && (
                                        <Button
                                            size="sm"
                                            onClick={() => setEditMode(true)}
                                            className="bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                                        >
                                            <FileEdit className="w-3 h-3 mr-1" />
                                            Edit
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </DialogHeader>

                        <Tabs defaultValue="content" className="mt-4">
                            <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                                <TabsTrigger value="content">Content</TabsTrigger>
                                <TabsTrigger value="comments">
                                    Comments ({selectedReport.comments?.length || 0})
                                </TabsTrigger>
                                <TabsTrigger value="history">History</TabsTrigger>
                            </TabsList>

                            <TabsContent value="content" className="space-y-4">
                                {editMode ? (
                                    <ReportForm 
                                        formData={formData} 
                                        setFormData={setFormData} 
                                        onSave={() => updateReportMutation.mutate({
                                            reportId: selectedReport.id,
                                            updates: formData
                                        })}
                                        isLoading={updateReportMutation.isPending}
                                        isEdit={true}
                                    />
                                ) : (
                                    <ReportViewer report={selectedReport} />
                                )}
                            </TabsContent>

                            <TabsContent value="comments" className="space-y-4">
                                <div className="space-y-3">
                                    {selectedReport.comments?.map((c, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-cyan-400 text-sm font-semibold">{c.user}</span>
                                                <span className="text-slate-500 text-xs">{moment(c.timestamp).fromNow()}</span>
                                            </div>
                                            <p className="text-slate-300 text-sm">{c.comment}</p>
                                        </div>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <Textarea
                                        placeholder="Add a comment..."
                                        value={comment}
                                        onChange={(e) => setComment(e.target.value)}
                                        className="bg-slate-800 border-slate-700 text-white"
                                        rows={3}
                                    />
                                    <Button
                                        onClick={() => addCommentMutation.mutate({
                                            reportId: selectedReport.id,
                                            commentText: comment
                                        })}
                                        disabled={!comment.trim()}
                                        className="bg-cyan-500/20 text-cyan-400"
                                    >
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </div>
                            </TabsContent>

                            <TabsContent value="history" className="space-y-2">
                                {selectedReport.change_log?.map((log, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 flex items-center gap-3">
                                        <Clock className="w-4 h-4 text-slate-400" />
                                        <div className="flex-1">
                                            <p className="text-white text-sm">{log.change}</p>
                                            <p className="text-slate-500 text-xs">{log.user} • {moment(log.timestamp).fromNow()}</p>
                                        </div>
                                    </div>
                                ))}
                            </TabsContent>
                        </Tabs>
                    </DialogContent>
                </Dialog>
            )}
        </div>
    );
}

function ReportForm({ formData, setFormData, onSave, isLoading, isEdit }) {
    return (
        <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-slate-400">Report Title *</Label>
                    <Input
                        value={formData.title}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                        placeholder="e.g., Initial Assessment - John Doe"
                    />
                </div>
                <div>
                    <Label className="text-slate-400">Player Name *</Label>
                    <Input
                        value={formData.player_name}
                        onChange={(e) => setFormData({...formData, player_name: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                    />
                </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
                <div>
                    <Label className="text-slate-400">Report Type</Label>
                    <Select 
                        value={formData.report_type} 
                        onValueChange={(v) => setFormData({...formData, report_type: v})}
                    >
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Initial Assessment">Initial Assessment</SelectItem>
                            <SelectItem value="Detailed Analysis">Detailed Analysis</SelectItem>
                            <SelectItem value="Match Report">Match Report</SelectItem>
                            <SelectItem value="Progress Update">Progress Update</SelectItem>
                            <SelectItem value="Final Recommendation">Final Recommendation</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label className="text-slate-400">Access Level</Label>
                    <Select 
                        value={formData.access_level} 
                        onValueChange={(v) => setFormData({...formData, access_level: v})}
                    >
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Internal">Internal</SelectItem>
                            <SelectItem value="Confidential">Confidential</SelectItem>
                            <SelectItem value="Restricted">Restricted</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                {isEdit && (
                    <div>
                        <Label className="text-slate-400">Status</Label>
                        <Select 
                            value={formData.status} 
                            onValueChange={(v) => setFormData({...formData, status: v})}
                        >
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Draft">Draft</SelectItem>
                                <SelectItem value="In Review">In Review</SelectItem>
                                <SelectItem value="Approved">Approved</SelectItem>
                                <SelectItem value="Published">Published</SelectItem>
                                <SelectItem value="Archived">Archived</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                )}
            </div>

            <div className="space-y-3">
                {Object.entries(formData.sections || {}).map(([key, value]) => (
                    <div key={key}>
                        <Label className="text-slate-400 capitalize">
                            {key.replace(/_/g, ' ')}
                        </Label>
                        <Textarea
                            value={value}
                            onChange={(e) => setFormData({
                                ...formData,
                                sections: {...formData.sections, [key]: e.target.value}
                            })}
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                            rows={3}
                        />
                    </div>
                ))}
            </div>

            <Button
                onClick={onSave}
                disabled={isLoading || !formData.title || !formData.player_name}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
            >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                {isEdit ? 'Save Changes' : 'Create Report'}
            </Button>
        </div>
    );
}

function ReportViewer({ report }) {
    return (
        <div className="space-y-4">
            {Object.entries(report.sections || {}).map(([key, value]) => (
                value && (
                    <div key={key} className="bg-slate-800/50 rounded-lg p-4">
                        <h4 className="text-cyan-400 font-semibold mb-2 capitalize">
                            {key.replace(/_/g, ' ')}
                        </h4>
                        <p className="text-slate-300 text-sm whitespace-pre-wrap">{value}</p>
                    </div>
                )
            ))}
        </div>
    );
}