import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    MessageCircle, Send, Search, Clock, AlertCircle, 
    CheckCheck, Paperclip, X 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function DirectMessaging({ scouts }) {
    const [selectedRecipient, setSelectedRecipient] = useState(null);
    const [messageText, setMessageText] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [isUrgent, setIsUrgent] = useState(false);
    const messagesEndRef = useRef(null);
    const queryClient = useQueryClient();

    const [currentUser, setCurrentUser] = useState(null);

    useEffect(() => {
        base44.auth.me().then(setCurrentUser).catch(() => {});
    }, []);

    const { data: allMessages = [] } = useQuery({
        queryKey: ['direct-messages'],
        queryFn: () => base44.entities.DirectMessage.list('-created_date', 200),
        refetchInterval: 5000 // Poll every 5 seconds for real-time feel
    });

    const sendMessageMutation = useMutation({
        mutationFn: async (messageData) => {
            const conversationId = [currentUser.email, messageData.recipient_email].sort().join('_');
            return base44.entities.DirectMessage.create({
                ...messageData,
                conversation_id: conversationId,
                sender_email: currentUser.email,
                sender_name: currentUser.full_name || currentUser.email
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['direct-messages'] });
            setMessageText('');
            setIsUrgent(false);
            toast.success('Message sent');
        }
    });

    const markAsReadMutation = useMutation({
        mutationFn: ({ messageId }) => 
            base44.entities.DirectMessage.update(messageId, {
                read: true,
                read_at: new Date().toISOString()
            }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['direct-messages'] });
        }
    });

    const conversationMessages = selectedRecipient && currentUser
        ? allMessages.filter(msg => {
            const conversationId = [currentUser.email, selectedRecipient.email].sort().join('_');
            return msg.conversation_id === conversationId;
        }).sort((a, b) => new Date(a.created_date) - new Date(b.created_date))
        : [];

    // Mark unread messages as read when viewing conversation
    useEffect(() => {
        if (selectedRecipient && currentUser) {
            const unreadMessages = conversationMessages.filter(
                msg => !msg.read && msg.recipient_email === currentUser.email
            );
            unreadMessages.forEach(msg => {
                markAsReadMutation.mutate({ messageId: msg.id });
            });
        }
    }, [selectedRecipient, conversationMessages.length]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [conversationMessages.length]);

    const handleSendMessage = () => {
        if (!messageText.trim() || !selectedRecipient) return;
        
        sendMessageMutation.mutate({
            recipient_email: selectedRecipient.email,
            recipient_name: selectedRecipient.full_name || selectedRecipient.email,
            message_content: messageText,
            urgent: isUrgent,
            message_type: isUrgent ? 'Alert' : 'Direct'
        });
    };

    // Get unique conversations
    const conversations = currentUser ? scouts.filter(scout => {
        return allMessages.some(msg => 
            (msg.sender_email === scout.email || msg.recipient_email === scout.email) &&
            (msg.sender_email === currentUser.email || msg.recipient_email === currentUser.email)
        );
    }) : [];

    const getUnreadCount = (scoutEmail) => {
        if (!currentUser) return 0;
        return allMessages.filter(msg => 
            msg.sender_email === scoutEmail && 
            msg.recipient_email === currentUser.email && 
            !msg.read
        ).length;
    };

    const filteredScouts = scouts.filter(scout => 
        scout.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        scout.email?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
            {/* Contacts Sidebar */}
            <Card className="lg:col-span-1 bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white text-sm">Contacts</CardTitle>
                    <div className="relative mt-2">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                        <Input
                            placeholder="Search scouts..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-9 bg-slate-800 border-slate-700 text-white text-sm"
                        />
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <ScrollArea className="h-[450px]">
                        <div className="p-4 space-y-2">
                            {filteredScouts.map(scout => {
                                const unreadCount = getUnreadCount(scout.email);
                                return (
                                    <motion.div
                                        key={scout.id}
                                        whileHover={{ scale: 1.02 }}
                                        onClick={() => setSelectedRecipient(scout)}
                                        className={`p-3 rounded-lg cursor-pointer transition-all ${
                                            selectedRecipient?.id === scout.id
                                                ? 'bg-cyan-500/20 border border-cyan-500/30'
                                                : 'bg-slate-800/50 hover:bg-slate-800 border border-transparent'
                                        }`}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex-1 min-w-0">
                                                <p className="text-white text-sm font-semibold truncate">
                                                    {scout.full_name || scout.email}
                                                </p>
                                                <p className="text-slate-400 text-xs truncate">{scout.region}</p>
                                            </div>
                                            {unreadCount > 0 && (
                                                <Badge className="bg-red-500 text-white text-xs">
                                                    {unreadCount}
                                                </Badge>
                                            )}
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </div>
                    </ScrollArea>
                </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="lg:col-span-3 bg-slate-900/50 border-slate-800">
                {selectedRecipient ? (
                    <>
                        <CardHeader className="border-b border-slate-800">
                            <div className="flex items-center justify-between">
                                <div>
                                    <CardTitle className="text-white text-lg">
                                        {selectedRecipient.full_name || selectedRecipient.email}
                                    </CardTitle>
                                    <p className="text-slate-400 text-xs">{selectedRecipient.region}</p>
                                </div>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    {selectedRecipient.status}
                                </Badge>
                            </div>
                        </CardHeader>
                        <CardContent className="p-0 flex flex-col h-[500px]">
                            {/* Messages */}
                            <ScrollArea className="flex-1 p-4">
                                <div className="space-y-4">
                                    <AnimatePresence>
                                        {conversationMessages.map((msg, idx) => {
                                            const isSender = msg.sender_email === currentUser?.email;
                                            return (
                                                <motion.div
                                                    key={msg.id}
                                                    initial={{ opacity: 0, y: 10 }}
                                                    animate={{ opacity: 1, y: 0 }}
                                                    transition={{ delay: idx * 0.05 }}
                                                    className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}
                                                >
                                                    <div className={`max-w-[70%] ${isSender ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                                                        <div className={`rounded-lg p-3 ${
                                                            isSender 
                                                                ? 'bg-cyan-500/20 border border-cyan-500/30' 
                                                                : 'bg-slate-800 border border-slate-700'
                                                        }`}>
                                                            {msg.urgent && (
                                                                <div className="flex items-center gap-1 mb-1">
                                                                    <AlertCircle className="w-3 h-3 text-red-400" />
                                                                    <span className="text-red-400 text-xs font-semibold">URGENT</span>
                                                                </div>
                                                            )}
                                                            <p className="text-white text-sm whitespace-pre-wrap">
                                                                {msg.message_content}
                                                            </p>
                                                            {msg.related_player && (
                                                                <Badge className="bg-purple-500/20 text-purple-400 text-xs mt-2">
                                                                    Re: {msg.related_player}
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <div className="flex items-center gap-2 px-2">
                                                            <span className="text-slate-500 text-xs">
                                                                {moment(msg.created_date).format('h:mm A')}
                                                            </span>
                                                            {isSender && msg.read && (
                                                                <CheckCheck className="w-3 h-3 text-cyan-400" />
                                                            )}
                                                        </div>
                                                    </div>
                                                </motion.div>
                                            );
                                        })}
                                    </AnimatePresence>
                                    <div ref={messagesEndRef} />
                                </div>
                            </ScrollArea>

                            {/* Message Input */}
                            <div className="border-t border-slate-800 p-4 space-y-3">
                                <div className="flex items-center gap-2">
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={isUrgent}
                                            onChange={(e) => setIsUrgent(e.target.checked)}
                                            className="w-3 h-3 rounded border-slate-600 text-red-500"
                                        />
                                        <span className="text-slate-400 text-xs">Mark as Urgent</span>
                                    </label>
                                </div>
                                <div className="flex gap-2">
                                    <Textarea
                                        placeholder="Type your message..."
                                        value={messageText}
                                        onChange={(e) => setMessageText(e.target.value)}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' && !e.shiftKey) {
                                                e.preventDefault();
                                                handleSendMessage();
                                            }
                                        }}
                                        className="flex-1 bg-slate-800 border-slate-700 text-white resize-none"
                                        rows={2}
                                    />
                                    <Button
                                        onClick={handleSendMessage}
                                        disabled={!messageText.trim() || sendMessageMutation.isPending}
                                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                                    >
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </>
                ) : (
                    <CardContent className="h-full flex items-center justify-center">
                        <div className="text-center">
                            <MessageCircle className="w-16 h-16 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">Select a scout to start messaging</p>
                        </div>
                    </CardContent>
                )}
            </Card>
        </div>
    );
}