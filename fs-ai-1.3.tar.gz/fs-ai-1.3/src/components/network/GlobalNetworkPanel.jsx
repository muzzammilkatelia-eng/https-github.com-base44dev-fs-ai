import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Search, MapPin, UserPlus, CheckCircle, X } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function GlobalNetworkPanel() {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedRole, setSelectedRole] = useState('All');
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: profiles = [] } = useQuery({
        queryKey: ['networkProfiles'],
        queryFn: () => base44.entities.NetworkProfile.filter({ public_profile: true })
    });

    const { data: myConnections = [] } = useQuery({
        queryKey: ['myConnections', user?.email],
        queryFn: () => base44.entities.NetworkConnection.filter({ 
            user_email: user?.email,
            status: 'Connected'
        }),
        enabled: !!user
    });

    const { data: pendingRequests = [] } = useQuery({
        queryKey: ['pendingRequests', user?.email],
        queryFn: () => base44.entities.NetworkConnection.filter({
            connected_email: user?.email,
            status: 'Pending'
        }),
        enabled: !!user
    });

    const connectMutation = useMutation({
        mutationFn: (profile) => base44.entities.NetworkConnection.create({
            user_email: user.email,
            connected_email: profile.user_email,
            status: 'Pending',
            connection_type: 'Professional'
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['myConnections']);
            toast.success('Connection request sent');
        }
    });

    const acceptMutation = useMutation({
        mutationFn: (connection) => base44.entities.NetworkConnection.update(connection.id, {
            status: 'Connected'
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['myConnections', 'pendingRequests']);
            toast.success('Connection accepted');
        }
    });

    const rejectMutation = useMutation({
        mutationFn: (connectionId) => base44.entities.NetworkConnection.delete(connectionId),
        onSuccess: () => {
            queryClient.invalidateQueries(['pendingRequests']);
            toast.success('Connection rejected');
        }
    });

    const filteredProfiles = profiles.filter(p => {
        const matchesSearch = p.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            p.club?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            p.location?.city?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = selectedRole === 'All' || p.role === selectedRole;
        const notMe = p.user_email !== user?.email;
        const notConnected = !myConnections.find(c => c.connected_email === p.user_email);
        return matchesSearch && matchesRole && notMe && notConnected;
    });

    const connectedProfiles = profiles.filter(p => 
        myConnections.find(c => c.connected_email === p.user_email)
    );

    const getRoleBadgeColor = (role) => {
        const colors = {
            'Player': 'bg-cyan-500/20 text-cyan-400',
            'Coach': 'bg-emerald-500/20 text-emerald-400',
            'Agent': 'bg-purple-500/20 text-purple-400',
            'Scout': 'bg-amber-500/20 text-amber-400',
            'Analyst': 'bg-blue-500/20 text-blue-400'
        };
        return colors[role] || 'bg-slate-500/20 text-slate-400';
    };

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-cyan-400" />
                    Global Football Network
                </CardTitle>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="discover" className="space-y-4">
                    <TabsList className="bg-slate-800 grid grid-cols-3">
                        <TabsTrigger value="discover">
                            Discover ({filteredProfiles.length})
                        </TabsTrigger>
                        <TabsTrigger value="connections">
                            Connected ({connectedProfiles.length})
                        </TabsTrigger>
                        <TabsTrigger value="requests">
                            Requests ({pendingRequests.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="discover" className="space-y-3">
                        <div className="flex gap-2">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <Input
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder="Search by name, club, or location..."
                                    className="pl-10 bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                        </div>

                        <div className="flex gap-2 flex-wrap">
                            {['All', 'Player', 'Coach', 'Agent', 'Scout', 'Analyst'].map(role => (
                                <Button
                                    key={role}
                                    onClick={() => setSelectedRole(role)}
                                    variant={selectedRole === role ? 'default' : 'outline'}
                                    size="sm"
                                    className={selectedRole === role ? 'bg-cyan-600' : ''}
                                >
                                    {role}
                                </Button>
                            ))}
                        </div>

                        <div className="space-y-2 max-h-[400px] overflow-y-auto">
                            {filteredProfiles.map((profile, idx) => (
                                <motion.div
                                    key={profile.id}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className="bg-slate-800/50 rounded-lg p-3 border border-slate-700"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <p className="text-white font-semibold">{profile.display_name}</p>
                                            <div className="flex items-center gap-2 mt-1">
                                                <Badge className={getRoleBadgeColor(profile.role)}>
                                                    {profile.role}
                                                </Badge>
                                                {profile.position && (
                                                    <Badge variant="outline" className="text-xs">
                                                        {profile.position}
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                        <Button
                                            size="sm"
                                            onClick={() => connectMutation.mutate(profile)}
                                            className="bg-cyan-600 hover:bg-cyan-700"
                                        >
                                            <UserPlus className="w-4 h-4 mr-1" />
                                            Connect
                                        </Button>
                                    </div>
                                    {profile.club && (
                                        <p className="text-slate-400 text-sm mb-1">{profile.club}</p>
                                    )}
                                    {profile.location && (
                                        <div className="flex items-center gap-1 text-slate-500 text-xs">
                                            <MapPin className="w-3 h-3" />
                                            {profile.location.city}, {profile.location.country}
                                        </div>
                                    )}
                                    {profile.bio && (
                                        <p className="text-slate-400 text-xs mt-2">{profile.bio}</p>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="connections" className="space-y-2 max-h-[500px] overflow-y-auto">
                        {connectedProfiles.map((profile) => (
                            <div key={profile.id} className="bg-slate-800/50 rounded-lg p-3 border border-emerald-500/30">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-white font-semibold">{profile.display_name}</p>
                                        <Badge className={getRoleBadgeColor(profile.role)}>
                                            {profile.role}
                                        </Badge>
                                        {profile.club && (
                                            <p className="text-slate-400 text-sm mt-1">{profile.club}</p>
                                        )}
                                    </div>
                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                        <CheckCircle className="w-3 h-3 mr-1" />
                                        Connected
                                    </Badge>
                                </div>
                            </div>
                        ))}
                    </TabsContent>

                    <TabsContent value="requests" className="space-y-2 max-h-[500px] overflow-y-auto">
                        {pendingRequests.map((request) => {
                            const requesterProfile = profiles.find(p => p.user_email === request.user_email);
                            return (
                                <div key={request.id} className="bg-slate-800/50 rounded-lg p-3 border border-amber-500/30">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <p className="text-white font-semibold">
                                                {requesterProfile?.display_name || 'Unknown User'}
                                            </p>
                                            {requesterProfile && (
                                                <Badge className={getRoleBadgeColor(requesterProfile.role)}>
                                                    {requesterProfile.role}
                                                </Badge>
                                            )}
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button
                                            size="sm"
                                            onClick={() => acceptMutation.mutate(request)}
                                            className="bg-emerald-600 hover:bg-emerald-700 flex-1"
                                        >
                                            <CheckCircle className="w-4 h-4 mr-1" />
                                            Accept
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => rejectMutation.mutate(request.id)}
                                            className="flex-1"
                                        >
                                            <X className="w-4 h-4 mr-1" />
                                            Decline
                                        </Button>
                                    </div>
                                </div>
                            );
                        })}
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}