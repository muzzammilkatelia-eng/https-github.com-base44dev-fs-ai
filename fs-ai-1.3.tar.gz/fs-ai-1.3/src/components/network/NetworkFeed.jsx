import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MessageSquare, Heart, Send, TrendingUp, Zap, MapPin, Award, Brain, Gauge, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import moment from 'moment';

export default function NetworkFeed({ sharedGPSData = null }) {
    const [newPost, setNewPost] = useState('');
    const [postType, setPostType] = useState('General');
    const [showComments, setShowComments] = useState({});
    const [commentText, setCommentText] = useState({});
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: myProfile } = useQuery({
        queryKey: ['myProfile', user?.email],
        queryFn: () => base44.entities.NetworkProfile.filter({ user_email: user.email }).then(p => p[0]),
        enabled: !!user
    });

    const { data: posts = [] } = useQuery({
        queryKey: ['networkPosts'],
        queryFn: () => base44.entities.NetworkPost.list('-created_date', 50)
    });

    const createPostMutation = useMutation({
        mutationFn: (postData) => base44.entities.NetworkPost.create(postData),
        onSuccess: () => {
            queryClient.invalidateQueries(['networkPosts']);
            setNewPost('');
            toast.success('Post shared with network');
        }
    });

    const likeMutation = useMutation({
        mutationFn: ({ postId, post }) => {
            const liked = post.liked_by?.includes(user.email);
            return base44.entities.NetworkPost.update(postId, {
                likes: liked ? post.likes - 1 : post.likes + 1,
                liked_by: liked 
                    ? post.liked_by.filter(e => e !== user.email)
                    : [...(post.liked_by || []), user.email]
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['networkPosts']);
        }
    });

    const commentMutation = useMutation({
        mutationFn: ({ postId, post, comment }) => {
            return base44.entities.NetworkPost.update(postId, {
                comments: [...(post.comments || []), {
                    author_email: user.email,
                    author_name: myProfile?.display_name || user.full_name,
                    content: comment,
                    timestamp: new Date().toISOString()
                }]
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['networkPosts']);
            setCommentText({});
            toast.success('Comment added');
        }
    });

    const handlePost = () => {
        if (!newPost.trim()) return;
        
        const postData = {
            author_email: user.email,
            author_name: myProfile?.display_name || user.full_name,
            author_role: myProfile?.role || 'Player',
            post_type: postType,
            content: newPost,
            tags: []
        };

        if (sharedGPSData && postType === 'GPS Share') {
            postData.gps_data = sharedGPSData;
        }

        createPostMutation.mutate(postData);
    };

    const getPostIcon = (type) => {
        const icons = {
            'Performance Update': TrendingUp,
            'Training Insight': Zap,
            'Achievement': Award,
            'GPS Share': MapPin,
            'General': MessageSquare
        };
        return icons[type] || MessageSquare;
    };

    return (
        <Card className="bg-slate-900/95 backdrop-blur-xl border-cyan-500/30">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-cyan-400" />
                    Network Feed
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Create Post */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                    <Textarea
                        value={newPost}
                        onChange={(e) => setNewPost(e.target.value)}
                        placeholder="Share an update with your network..."
                        className="bg-slate-900 border-slate-700 text-white mb-3"
                        rows={3}
                    />
                    <div className="flex gap-2">
                        <Select value={postType} onValueChange={setPostType}>
                            <SelectTrigger className="bg-slate-900 border-slate-700 text-white w-48">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="General">General</SelectItem>
                                <SelectItem value="Performance Update">Performance Update</SelectItem>
                                <SelectItem value="Training Insight">Training Insight</SelectItem>
                                <SelectItem value="Advice Request">Advice Request</SelectItem>
                                <SelectItem value="Achievement">Achievement</SelectItem>
                                {sharedGPSData && <SelectItem value="GPS Share">GPS Share</SelectItem>}
                            </SelectContent>
                        </Select>
                        <Button 
                            onClick={handlePost}
                            className="bg-cyan-600 hover:bg-cyan-700 ml-auto"
                        >
                            <Send className="w-4 h-4 mr-2" />
                            Post
                        </Button>
                    </div>
                </div>

                {/* Feed */}
                <div className="space-y-3 max-h-[500px] overflow-y-auto">
                    {posts.map((post, idx) => {
                        const PostIcon = getPostIcon(post.post_type);
                        const isLiked = post.liked_by?.includes(user?.email);
                        
                        return (
                            <motion.div
                                key={post.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                            >
                                {/* Post Header */}
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <p className="text-white font-semibold">{post.author_name}</p>
                                        <div className="flex items-center gap-2 mt-1">
                                            <Badge variant="outline" className="text-xs">
                                                {post.author_role}
                                            </Badge>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                                <PostIcon className="w-3 h-3 mr-1" />
                                                {post.post_type}
                                            </Badge>
                                        </div>
                                    </div>
                                    <span className="text-slate-500 text-xs">
                                        {moment(post.created_date).fromNow()}
                                    </span>
                                </div>

                                {/* Post Content */}
                                <p className="text-slate-300 mb-3">{post.content}</p>

                                {/* GPS Data with Advanced Metrics */}
                                {post.gps_data && (
                                    <div className="space-y-2 mb-3">
                                        <div className="bg-slate-900/50 rounded p-3 grid grid-cols-3 gap-2">
                                            <div>
                                                <p className="text-slate-400 text-xs">Distance</p>
                                                <p className="text-cyan-400 font-bold">{post.gps_data.distance} km</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 text-xs">Top Speed</p>
                                                <p className="text-amber-400 font-bold">{post.gps_data.topSpeed} km/h</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 text-xs">Sprints</p>
                                                <p className="text-emerald-400 font-bold">{post.gps_data.sprints}</p>
                                            </div>
                                        </div>
                                        
                                        {/* Advanced Analytics Display */}
                                        {(post.gps_data.playerLoad || post.gps_data.stressIndex || post.gps_data.fatigueScore) && (
                                            <div className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 rounded-lg p-3 border border-purple-500/30">
                                                <div className="flex items-center gap-2 mb-2">
                                                    <Brain className="w-4 h-4 text-purple-400" />
                                                    <p className="text-purple-300 text-xs font-semibold">Advanced Metrics</p>
                                                </div>
                                                <div className="grid grid-cols-3 gap-2">
                                                    {post.gps_data.playerLoad && (
                                                        <div>
                                                            <div className="flex items-center gap-1 mb-1">
                                                                <Gauge className="w-3 h-3 text-purple-400" />
                                                                <p className="text-slate-400 text-xs">Player Load</p>
                                                            </div>
                                                            <p className="text-purple-400 font-bold text-sm">{post.gps_data.playerLoad} AU</p>
                                                        </div>
                                                    )}
                                                    {post.gps_data.stressIndex && (
                                                        <div>
                                                            <div className="flex items-center gap-1 mb-1">
                                                                <AlertTriangle className="w-3 h-3 text-orange-400" />
                                                                <p className="text-slate-400 text-xs">Stress Index</p>
                                                            </div>
                                                            <p className="text-orange-400 font-bold text-sm">{post.gps_data.stressIndex}</p>
                                                        </div>
                                                    )}
                                                    {post.gps_data.fatigueScore && (
                                                        <div>
                                                            <div className="flex items-center gap-1 mb-1">
                                                                <TrendingUp className="w-3 h-3 text-red-400" />
                                                                <p className="text-slate-400 text-xs">Fatigue Score</p>
                                                            </div>
                                                            <p className="text-red-400 font-bold text-sm">{post.gps_data.fatigueScore}</p>
                                                        </div>
                                                    )}
                                                </div>
                                                {(post.gps_data.metabolicPower || post.gps_data.asymmetryIndex || post.gps_data.explosiveActions) && (
                                                    <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-purple-500/20">
                                                        {post.gps_data.metabolicPower && (
                                                            <div>
                                                                <p className="text-slate-500 text-xs">Metabolic Power</p>
                                                                <p className="text-pink-400 font-semibold text-xs">{post.gps_data.metabolicPower} W/kg</p>
                                                            </div>
                                                        )}
                                                        {post.gps_data.asymmetryIndex && (
                                                            <div>
                                                                <p className="text-slate-500 text-xs">Asymmetry</p>
                                                                <p className="text-yellow-400 font-semibold text-xs">{post.gps_data.asymmetryIndex}%</p>
                                                            </div>
                                                        )}
                                                        {post.gps_data.explosiveActions && (
                                                            <div>
                                                                <p className="text-slate-500 text-xs">Explosive</p>
                                                                <p className="text-indigo-400 font-semibold text-xs">{post.gps_data.explosiveActions}</p>
                                                            </div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                )}

                                {/* Actions */}
                                <div className="flex items-center gap-4 text-sm border-t border-slate-700 pt-3">
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => likeMutation.mutate({ postId: post.id, post })}
                                        className={isLiked ? 'text-red-400' : 'text-slate-400'}
                                    >
                                        <Heart className={`w-4 h-4 mr-1 ${isLiked ? 'fill-red-400' : ''}`} />
                                        {post.likes || 0}
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => setShowComments(prev => ({ ...prev, [post.id]: !prev[post.id] }))}
                                        className="text-slate-400"
                                    >
                                        <MessageSquare className="w-4 h-4 mr-1" />
                                        {post.comments?.length || 0}
                                    </Button>
                                </div>

                                {/* Comments Section */}
                                {showComments[post.id] && (
                                    <div className="mt-3 space-y-2 border-t border-slate-700 pt-3">
                                        {post.comments?.map((comment, cidx) => (
                                            <div key={cidx} className="bg-slate-900/50 rounded p-2">
                                                <p className="text-white text-sm font-semibold">{comment.author_name}</p>
                                                <p className="text-slate-300 text-sm">{comment.content}</p>
                                                <p className="text-slate-600 text-xs mt-1">
                                                    {moment(comment.timestamp).fromNow()}
                                                </p>
                                            </div>
                                        ))}
                                        <div className="flex gap-2">
                                            <Textarea
                                                value={commentText[post.id] || ''}
                                                onChange={(e) => setCommentText({ ...commentText, [post.id]: e.target.value })}
                                                placeholder="Write a comment..."
                                                className="bg-slate-900 border-slate-700 text-white"
                                                rows={2}
                                            />
                                            <Button
                                                onClick={() => {
                                                    if (commentText[post.id]?.trim()) {
                                                        commentMutation.mutate({
                                                            postId: post.id,
                                                            post,
                                                            comment: commentText[post.id]
                                                        });
                                                    }
                                                }}
                                                size="sm"
                                                className="bg-cyan-600"
                                            >
                                                <Send className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                )}
                            </motion.div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}