import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { TrendingUp, MessageSquare, ThumbsUp, Share2, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function NetworkFeedComponent() {
    const [newPost, setNewPost] = useState('');
    const [postTitle, setPostTitle] = useState('');
    const [postType, setPostType] = useState('insight');
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: feed = [] } = useQuery({
        queryKey: ['networkFeed'],
        queryFn: () => base44.entities.NetworkFeed.list('-trending_score', 50)
    });

    const postMutation = useMutation({
        mutationFn: (data) => base44.entities.NetworkFeed.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['networkFeed']);
            setNewPost('');
            setPostTitle('');
            toast.success('Posted to network!');
        }
    });

    const likeMutation = useMutation({
        mutationFn: ({ id, likes }) => base44.entities.NetworkFeed.update(id, { likes: likes + 1 }),
        onSuccess: () => queryClient.invalidateQueries(['networkFeed'])
    });

    const handlePost = () => {
        if (!newPost.trim() || !postTitle.trim()) return;
        postMutation.mutate({
            author_email: user.email,
            post_type: postType,
            title: postTitle,
            content: newPost,
            tags: [],
            player_references: []
        });
    };

    return (
        <div className="space-y-6">
            {/* Create Post */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6 space-y-3">
                    <Input
                        value={postTitle}
                        onChange={(e) => setPostTitle(e.target.value)}
                        placeholder="Post title..."
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                    <Textarea
                        value={newPost}
                        onChange={(e) => setNewPost(e.target.value)}
                        placeholder="Share insights, trending players, or market news..."
                        className="bg-slate-800 border-slate-700 text-white"
                        rows={3}
                    />
                    <div className="flex items-center gap-2">
                        <select
                            value={postType}
                            onChange={(e) => setPostType(e.target.value)}
                            className="bg-slate-800 border border-slate-700 text-white rounded px-3 py-2 text-sm"
                        >
                            <option value="insight">Insight</option>
                            <option value="player_spotlight">Player Spotlight</option>
                            <option value="market_news">Market News</option>
                            <option value="question">Question</option>
                        </select>
                        <Button onClick={handlePost} className="bg-cyan-600 ml-auto">
                            Post to Network
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Feed */}
            <div className="space-y-4">
                {feed.map(post => (
                    <Card key={post.id} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-start gap-3 mb-3">
                                <div className="w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center text-white">
                                    {post.author_email[0].toUpperCase()}
                                </div>
                                <div className="flex-1">
                                    <div className="flex items-center gap-2">
                                        <p className="text-white font-semibold">{post.author_email}</p>
                                        <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                            {post.post_type.replace('_', ' ')}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-400 text-xs">
                                        {new Date(post.created_date).toLocaleString()}
                                    </p>
                                </div>
                                {post.trending_score > 50 && (
                                    <Badge className="bg-amber-500/20 text-amber-400">
                                        <TrendingUp className="w-3 h-3 mr-1" />
                                        Trending
                                    </Badge>
                                )}
                            </div>
                            
                            <h3 className="text-white font-semibold text-lg mb-2">{post.title}</h3>
                            <p className="text-slate-300 mb-4">{post.content}</p>

                            {post.player_references && post.player_references.length > 0 && (
                                <div className="flex flex-wrap gap-2 mb-3">
                                    {post.player_references.map((player, idx) => (
                                        <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                            {player}
                                        </Badge>
                                    ))}
                                </div>
                            )}

                            <div className="flex items-center gap-4 pt-3 border-t border-slate-800">
                                <Button
                                    onClick={() => likeMutation.mutate({ id: post.id, likes: post.likes || 0 })}
                                    variant="ghost"
                                    size="sm"
                                    className="text-slate-400 hover:text-cyan-400"
                                >
                                    <ThumbsUp className="w-4 h-4 mr-1" />
                                    {post.likes || 0}
                                </Button>
                                <Button variant="ghost" size="sm" className="text-slate-400">
                                    <MessageSquare className="w-4 h-4 mr-1" />
                                    {post.comments_count || 0}
                                </Button>
                                <Button variant="ghost" size="sm" className="text-slate-400">
                                    <Share2 className="w-4 h-4 mr-1" />
                                    Share
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}