import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function NetworkMessaging() {
    const [selectedConversation, setSelectedConversation] = useState(null);
    const [message, setMessage] = useState('');
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: messages = [] } = useQuery({
        queryKey: ['networkMessages', user?.email],
        queryFn: () => base44.entities.NetworkMessage.filter({
            $or: [{ sender_email: user.email }, { recipient_email: user.email }]
        }),
        enabled: !!user
    });

    const sendMutation = useMutation({
        mutationFn: (data) => base44.entities.NetworkMessage.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['networkMessages']);
            setMessage('');
            toast.success('Message sent!');
        }
    });

    const conversations = {};
    messages.forEach(msg => {
        const otherUser = msg.sender_email === user?.email ? msg.recipient_email : msg.sender_email;
        const convId = msg.conversation_id || otherUser;
        if (!conversations[convId]) {
            conversations[convId] = { otherUser, messages: [] };
        }
        conversations[convId].messages.push(msg);
    });

    const handleSend = () => {
        if (!message.trim() || !selectedConversation) return;
        sendMutation.mutate({
            sender_email: user.email,
            recipient_email: selectedConversation,
            conversation_id: selectedConversation,
            message: message.trim()
        });
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800 h-[600px] flex flex-col">
            <CardHeader className="border-b border-slate-800">
                <CardTitle className="text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-cyan-400" />
                    Direct Messages
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex p-0">
                {/* Conversations List */}
                <div className="w-1/3 border-r border-slate-800 overflow-y-auto">
                    {Object.entries(conversations).map(([convId, conv]) => (
                        <button
                            key={convId}
                            onClick={() => setSelectedConversation(conv.otherUser)}
                            className={`w-full p-4 text-left border-b border-slate-800 hover:bg-slate-800/50 transition-colors ${
                                selectedConversation === conv.otherUser ? 'bg-slate-800/50' : ''
                            }`}
                        >
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center text-white">
                                    {conv.otherUser[0].toUpperCase()}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-white font-semibold truncate">{conv.otherUser}</p>
                                    <p className="text-slate-400 text-sm truncate">
                                        {conv.messages[conv.messages.length - 1]?.message}
                                    </p>
                                </div>
                                {conv.messages.some(m => !m.read && m.recipient_email === user.email) && (
                                    <Badge className="bg-cyan-500">New</Badge>
                                )}
                            </div>
                        </button>
                    ))}
                </div>

                {/* Messages */}
                <div className="flex-1 flex flex-col">
                    {selectedConversation ? (
                        <>
                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                                {conversations[selectedConversation]?.messages.map(msg => (
                                    <div
                                        key={msg.id}
                                        className={`flex ${msg.sender_email === user.email ? 'justify-end' : 'justify-start'}`}
                                    >
                                        <div
                                            className={`max-w-[70%] rounded-lg px-4 py-2 ${
                                                msg.sender_email === user.email
                                                    ? 'bg-cyan-600 text-white'
                                                    : 'bg-slate-800 text-slate-200'
                                            }`}
                                        >
                                            <p className="text-sm">{msg.message}</p>
                                            <p className="text-xs opacity-70 mt-1">
                                                {new Date(msg.created_date).toLocaleTimeString()}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="p-4 border-t border-slate-800">
                                <div className="flex gap-2">
                                    <Input
                                        value={message}
                                        onChange={(e) => setMessage(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                                        placeholder="Type a message..."
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                    <Button onClick={handleSend} className="bg-cyan-600">
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="flex-1 flex items-center justify-center text-slate-400">
                            Select a conversation to start messaging
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}