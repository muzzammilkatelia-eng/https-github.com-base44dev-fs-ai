import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    Radio, TrendingUp, TrendingDown, DollarSign, 
    Activity, Clock, Loader2, Search, Zap, RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function RealTimeDataFeeds({ feeds, onUpdate }) {
    const [playerName, setPlayerName] = useState('');
    const [dataSource, setDataSource] = useState('Transfermarkt');
    const [isFetching, setIsFetching] = useState(false);

    const queryClient = useQueryClient();

    const fetchDataMutation = useMutation({
        mutationFn: async ({ player, source }) => {
            const prompt = `Fetch comprehensive real-time data for football player: ${player}

Source: ${source}

Provide detailed, current information:

1. **Market Value & Transfer Status**:
   - Current market value (EUR millions)
   - Recent value changes
   - Transfer rumors/news
   - Contract expiration

2. **Performance Statistics** (current season):
   - Goals, assists
   - Matches played
   - Average rating
   - Key metrics for position

3. **Recent Form**:
   - Last 5 matches performance
   - Injury status
   - Fitness level

4. **Market Intelligence**:
   - Interested clubs
   - Agent information
   - Potential transfer fee
   - Market trend (rising/stable/declining)

Use real, current data from ${source} and other reputable sources. Be accurate and up-to-date.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        age: { type: "number" },
                        position: { type: "string" },
                        club: { type: "string" },
                        league: { type: "string" },
                        market_value_eur: { type: "number" },
                        value_trend: { type: "string" },
                        performance: {
                            type: "object",
                            properties: {
                                goals: { type: "number" },
                                assists: { type: "number" },
                                matches: { type: "number" },
                                rating: { type: "number" }
                            }
                        },
                        transfer_news: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    headline: { type: "string" },
                                    details: { type: "string" },
                                    source: { type: "string" },
                                    reliability: { type: "string" }
                                }
                            }
                        },
                        injury_status: { type: "string" },
                        contract_expires: { type: "string" },
                        interested_clubs: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            // Store in DataFeed entity
            await base44.entities.DataFeed.create({
                player_name: result.player_name,
                source: source,
                data_type: 'Market_Value',
                data: result,
                league: result.league,
                club: result.club,
                position: result.position,
                age: result.age,
                market_value_eur: result.market_value_eur,
                trending: true,
                fetched_at: new Date().toISOString()
            });

            return result;
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: ['data-feeds'] });
            toast.success(`Data fetched for ${data.player_name}`);
            onUpdate();
            setPlayerName('');
        },
        onError: () => {
            toast.error('Failed to fetch data');
        }
    });

    const handleFetch = (e) => {
        e.preventDefault();
        if (!playerName) {
            toast.error('Enter a player name');
            return;
        }
        fetchDataMutation.mutate({ player: playerName, source: dataSource });
    };

    const groupedFeeds = feeds.reduce((acc, feed) => {
        if (!acc[feed.player_name]) {
            acc[feed.player_name] = [];
        }
        acc[feed.player_name].push(feed);
        return acc;
    }, {});

    const getValueTrendIcon = (trend) => {
        if (trend?.toLowerCase().includes('rising')) return <TrendingUp className="w-4 h-4 text-emerald-400" />;
        if (trend?.toLowerCase().includes('declining')) return <TrendingDown className="w-4 h-4 text-red-400" />;
        return <Activity className="w-4 h-4 text-slate-400" />;
    };

    return (
        <div className="space-y-6">
            {/* Fetch Interface */}
            <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Radio className="w-5 h-5 text-amber-400" />
                        Real-Time Data Feeds
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Fetch live player data from Transfermarkt, Opta, WhoScored, and more
                    </p>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleFetch} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="md:col-span-2">
                                <Label className="text-slate-400">Player Name</Label>
                                <Input
                                    value={playerName}
                                    onChange={(e) => setPlayerName(e.target.value)}
                                    placeholder="e.g., Kylian Mbappé, Vinicius Jr"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-400">Data Source</Label>
                                <Select value={dataSource} onValueChange={setDataSource}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Transfermarkt">Transfermarkt</SelectItem>
                                        <SelectItem value="Opta">Opta</SelectItem>
                                        <SelectItem value="WhoScored">WhoScored</SelectItem>
                                        <SelectItem value="SofaScore">SofaScore</SelectItem>
                                        <SelectItem value="FBref">FBref</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <Button
                            type="submit"
                            disabled={fetchDataMutation.isPending}
                            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500"
                        >
                            {fetchDataMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Fetching Live Data...
                                </>
                            ) : (
                                <>
                                    <Search className="w-4 h-4 mr-2" />
                                    Fetch Real-Time Data
                                </>
                            )}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            {/* Live Feeds */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {Object.entries(groupedFeeds).map(([playerName, playerFeeds], idx) => {
                    const latestFeed = playerFeeds[0];
                    const data = latestFeed.data;

                    return (
                        <motion.div
                            key={playerName}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.1 }}
                        >
                            <Card className="bg-slate-900/50 border-slate-800 hover:border-amber-500/30 transition-all">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-white flex items-center gap-2">
                                                {latestFeed.trending && (
                                                    <span className="relative flex h-2 w-2">
                                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                                        <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                                                    </span>
                                                )}
                                                {playerName}
                                            </CardTitle>
                                            <div className="flex items-center gap-2 mt-1">
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    {latestFeed.position}
                                                </Badge>
                                                <span className="text-slate-400 text-sm">{latestFeed.club}</span>
                                            </div>
                                        </div>
                                        <Badge className="bg-amber-500/20 text-amber-400">
                                            {latestFeed.source}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {/* Market Value */}
                                    <div className="bg-gradient-to-r from-emerald-500/10 to-emerald-500/5 rounded-lg p-3">
                                        <div className="flex justify-between items-center">
                                            <div className="flex items-center gap-2">
                                                <DollarSign className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-400 text-sm">Market Value</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <span className="text-emerald-400 font-bold">
                                                    €{data.market_value_eur}M
                                                </span>
                                                {getValueTrendIcon(data.value_trend)}
                                            </div>
                                        </div>
                                    </div>

                                    {/* Performance */}
                                    {data.performance && (
                                        <div className="grid grid-cols-4 gap-2">
                                            <div className="bg-slate-800/50 rounded p-2 text-center">
                                                <p className="text-slate-400 text-xs">Goals</p>
                                                <p className="text-white font-bold">{data.performance.goals}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded p-2 text-center">
                                                <p className="text-slate-400 text-xs">Assists</p>
                                                <p className="text-white font-bold">{data.performance.assists}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded p-2 text-center">
                                                <p className="text-slate-400 text-xs">Matches</p>
                                                <p className="text-white font-bold">{data.performance.matches}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded p-2 text-center">
                                                <p className="text-slate-400 text-xs">Rating</p>
                                                <p className="text-white font-bold">{data.performance.rating}</p>
                                            </div>
                                        </div>
                                    )}

                                    {/* Transfer News */}
                                    {data.transfer_news && data.transfer_news.length > 0 && (
                                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                                            <p className="text-blue-400 text-xs font-semibold mb-2 flex items-center gap-1">
                                                <Zap className="w-3 h-3" />
                                                Latest Transfer News
                                            </p>
                                            {data.transfer_news.slice(0, 2).map((news, i) => (
                                                <div key={i} className="mb-2 last:mb-0">
                                                    <p className="text-white text-sm">{news.headline}</p>
                                                    <p className="text-slate-400 text-xs">{news.details}</p>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    {/* Interested Clubs */}
                                    {data.interested_clubs && data.interested_clubs.length > 0 && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-1">Interested Clubs:</p>
                                            <div className="flex flex-wrap gap-1">
                                                {data.interested_clubs.map((club, i) => (
                                                    <Badge key={i} className="bg-purple-500/20 text-purple-400 text-xs">
                                                        {club}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    <div className="flex justify-between items-center text-xs text-slate-500 pt-2 border-t border-slate-800">
                                        <div className="flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {moment(latestFeed.fetched_at).fromNow()}
                                        </div>
                                        <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={() => fetchDataMutation.mutate({ player: playerName, source: latestFeed.source })}
                                            className="text-slate-400 h-6 px-2"
                                        >
                                            <RefreshCw className="w-3 h-3 mr-1" />
                                            Refresh
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    );
                })}
            </div>

            {feeds.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Radio className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No data feeds yet</p>
                        <p className="text-slate-500 text-sm">Fetch real-time player data to get started</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}