import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Share2, Lock, Unlock, Users, Globe, Eye, ThumbsUp } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import toast from 'react-hot-toast';

export default function ReportSharingPanel() {
    const [shareDialogOpen, setShareDialogOpen] = useState(false);
    const [selectedReport, setSelectedReport] = useState(null);
    const [privacyLevel, setPrivacyLevel] = useState('connections');
    const [allowDownload, setAllowDownload] = useState(false);
    const [allowReshare, setAllowReshare] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scoutingReports'],
        queryFn: () => base44.entities.ScoutingReport.filter({ created_by: user?.email }),
        enabled: !!user
    });

    const { data: sharedReports = [] } = useQuery({
        queryKey: ['sharedReports', user?.email],
        queryFn: () => base44.entities.SharedReport.filter({
            $or: [{ owner_email: user.email }, { shared_with: { $contains: user.email } }]
        }),
        enabled: !!user
    });

    const shareMutation = useMutation({
        mutationFn: (data) => base44.entities.SharedReport.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['sharedReports']);
            toast.success('Report shared!');
            setShareDialogOpen(false);
        }
    });

    const handleShare = () => {
        if (!selectedReport) return;
        shareMutation.mutate({
            report_id: selectedReport.id,
            report_type: 'scouting_report',
            owner_email: user.email,
            player_name: selectedReport.player_name,
            privacy_level: privacyLevel,
            allow_download: allowDownload,
            allow_reshare: allowReshare,
            shared_with: []
        });
    };

    const getPrivacyIcon = (level) => {
        switch (level) {
            case 'private': return <Lock className="w-4 h-4" />;
            case 'connections': return <Users className="w-4 h-4" />;
            case 'network': return <Share2 className="w-4 h-4" />;
            case 'public': return <Globe className="w-4 h-4" />;
            default: return <Lock className="w-4 h-4" />;
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <Share2 className="w-5 h-5 text-cyan-400" />
                            Share Reports
                        </div>
                        <Button
                            onClick={() => setShareDialogOpen(true)}
                            className="bg-cyan-600"
                        >
                            Share New Report
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {sharedReports.map(shared => (
                            <Card key={shared.id} className="bg-slate-800/50 border-slate-700">
                                <CardContent className="pt-4">
                                    <h4 className="text-white font-semibold mb-2">{shared.player_name}</h4>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex items-center justify-between">
                                            <span className="text-slate-400">Privacy:</span>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 flex items-center gap-1">
                                                {getPrivacyIcon(shared.privacy_level)}
                                                {shared.privacy_level}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-slate-400 flex items-center gap-1">
                                                <Eye className="w-3 h-3" />
                                                Views:
                                            </span>
                                            <span className="text-white">{shared.views || 0}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-slate-400 flex items-center gap-1">
                                                <ThumbsUp className="w-3 h-3" />
                                                Likes:
                                            </span>
                                            <span className="text-white">{shared.likes || 0}</span>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white">
                    <DialogHeader>
                        <DialogTitle>Share Report</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label className="text-slate-400">Select Report</Label>
                            <Select
                                value={selectedReport?.id}
                                onValueChange={(val) => setSelectedReport(reports.find(r => r.id === val))}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                    <SelectValue placeholder="Choose a report..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {reports.map(r => (
                                        <SelectItem key={r.id} value={r.id}>
                                            {r.player_name} - {new Date(r.created_date).toLocaleDateString()}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <Label className="text-slate-400">Privacy Level</Label>
                            <Select value={privacyLevel} onValueChange={setPrivacyLevel}>
                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="private">Private (Only Me)</SelectItem>
                                    <SelectItem value="connections">My Connections</SelectItem>
                                    <SelectItem value="network">Full Network</SelectItem>
                                    <SelectItem value="public">Public</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2">
                                <Checkbox
                                    checked={allowDownload}
                                    onCheckedChange={setAllowDownload}
                                />
                                <Label className="text-slate-300">Allow Download</Label>
                            </div>
                            <div className="flex items-center gap-2">
                                <Checkbox
                                    checked={allowReshare}
                                    onCheckedChange={setAllowReshare}
                                />
                                <Label className="text-slate-300">Allow Resharing</Label>
                            </div>
                        </div>

                        <Button onClick={handleShare} className="w-full bg-cyan-600">
                            Share Report
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}