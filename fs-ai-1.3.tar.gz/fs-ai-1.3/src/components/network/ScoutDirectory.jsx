import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    MapPin, Mail, Phone, Globe, Award, TrendingUp, 
    CheckCircle, XCircle, Clock, Search, Filter 
} from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ScoutDirectory({ scouts, onUpdate }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [regionFilter, setRegionFilter] = useState('all');

    const queryClient = useQueryClient();

    const updateStatusMutation = useMutation({
        mutationFn: ({ scoutId, status }) => 
            base44.entities.Scout.update(scoutId, { status }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouts'] });
            toast.success('Scout status updated');
        }
    });

    const filteredScouts = scouts.filter(scout => {
        const matchesSearch = scout.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            scout.region?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'all' || scout.status === statusFilter;
        const matchesRegion = regionFilter === 'all' || scout.region === regionFilter;
        return matchesSearch && matchesStatus && matchesRegion;
    });

    const getStatusColor = (status) => {
        const colors = {
            'Active': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Vetting': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Prospect': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Inactive': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Rejected': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[status] || '';
    };

    const regions = [...new Set(scouts.map(s => s.region).filter(Boolean))];

    const stats = {
        total: scouts.length,
        active: scouts.filter(s => s.status === 'Active').length,
        vetting: scouts.filter(s => s.status === 'Vetting').length,
        prospects: scouts.filter(s => s.status === 'Prospect').length
    };

    return (
        <div className="space-y-6">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm">Total Scouts</p>
                            <p className="text-white text-3xl font-bold">{stats.total}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-emerald-400 text-sm">Active</p>
                            <p className="text-emerald-400 text-3xl font-bold">{stats.active}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-amber-500/10 border-amber-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-amber-400 text-sm">Vetting</p>
                            <p className="text-amber-400 text-3xl font-bold">{stats.vetting}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-blue-500/10 border-blue-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-blue-400 text-sm">Prospects</p>
                            <p className="text-blue-400 text-3xl font-bold">{stats.prospects}</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Filters */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-4">
                    <div className="flex flex-wrap gap-4">
                        <div className="flex-1 min-w-[200px]">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <Input
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder="Search scouts..."
                                    className="bg-slate-800 border-slate-700 text-white pl-10"
                                />
                            </div>
                        </div>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-[180px] bg-slate-800 border-slate-700 text-white">
                                <Filter className="w-4 h-4 mr-2" />
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Statuses</SelectItem>
                                <SelectItem value="Active">Active</SelectItem>
                                <SelectItem value="Vetting">Vetting</SelectItem>
                                <SelectItem value="Prospect">Prospect</SelectItem>
                                <SelectItem value="Inactive">Inactive</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={regionFilter} onValueChange={setRegionFilter}>
                            <SelectTrigger className="w-[180px] bg-slate-800 border-slate-700 text-white">
                                <Globe className="w-4 h-4 mr-2" />
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Regions</SelectItem>
                                {regions.map(region => (
                                    <SelectItem key={region} value={region}>{region}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Scouts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredScouts.map((scout, idx) => (
                    <motion.div
                        key={scout.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/30 transition-all">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-white text-lg">{scout.full_name}</CardTitle>
                                        <div className="flex items-center gap-2 mt-1">
                                            <MapPin className="w-3 h-3 text-slate-400" />
                                            <span className="text-slate-400 text-sm">{scout.region}</span>
                                        </div>
                                    </div>
                                    <Badge className={getStatusColor(scout.status)}>
                                        {scout.status}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="flex items-center gap-2 text-sm">
                                    <Mail className="w-3 h-3 text-slate-400" />
                                    <span className="text-slate-300">{scout.email}</span>
                                </div>
                                {scout.phone && (
                                    <div className="flex items-center gap-2 text-sm">
                                        <Phone className="w-3 h-3 text-slate-400" />
                                        <span className="text-slate-300">{scout.phone}</span>
                                    </div>
                                )}
                                {scout.countries && scout.countries.length > 0 && (
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1">Countries:</p>
                                        <div className="flex flex-wrap gap-1">
                                            {scout.countries.slice(0, 3).map((country, i) => (
                                                <Badge key={i} className="bg-slate-800 text-slate-300 text-xs">
                                                    {country}
                                                </Badge>
                                            ))}
                                            {scout.countries.length > 3 && (
                                                <Badge className="bg-slate-800 text-slate-300 text-xs">
                                                    +{scout.countries.length - 3}
                                                </Badge>
                                            )}
                                        </div>
                                    </div>
                                )}
                                {scout.ai_vetting_score && (
                                    <div className="flex items-center justify-between bg-slate-800/50 rounded-lg p-2">
                                        <span className="text-slate-400 text-xs">AI Score</span>
                                        <Badge className={
                                            scout.ai_vetting_score >= 80 ? 'bg-emerald-500/20 text-emerald-400' :
                                            scout.ai_vetting_score >= 60 ? 'bg-amber-500/20 text-amber-400' :
                                            'bg-red-500/20 text-red-400'
                                        }>
                                            {scout.ai_vetting_score}/100
                                        </Badge>
                                    </div>
                                )}
                                {scout.performance_metrics && (
                                    <div className="grid grid-cols-3 gap-2 text-center">
                                        <div className="bg-slate-800/50 rounded p-2">
                                            <p className="text-slate-400 text-xs">Reports</p>
                                            <p className="text-white font-bold">{scout.performance_metrics.reports_submitted || 0}</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded p-2">
                                            <p className="text-slate-400 text-xs">Players</p>
                                            <p className="text-white font-bold">{scout.performance_metrics.players_discovered || 0}</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded p-2">
                                            <p className="text-slate-400 text-xs">Signings</p>
                                            <p className="text-white font-bold">{scout.performance_metrics.successful_signings || 0}</p>
                                        </div>
                                    </div>
                                )}
                                <div className="flex gap-2 pt-2">
                                    {scout.status === 'Vetting' && (
                                        <>
                                            <Button
                                                size="sm"
                                                onClick={() => updateStatusMutation.mutate({ scoutId: scout.id, status: 'Active' })}
                                                className="flex-1 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                                            >
                                                <CheckCircle className="w-3 h-3 mr-1" />
                                                Approve
                                            </Button>
                                            <Button
                                                size="sm"
                                                onClick={() => updateStatusMutation.mutate({ scoutId: scout.id, status: 'Rejected' })}
                                                className="flex-1 bg-red-500/20 text-red-400 hover:bg-red-500/30"
                                            >
                                                <XCircle className="w-3 h-3 mr-1" />
                                                Reject
                                            </Button>
                                        </>
                                    )}
                                    {scout.status === 'Active' && (
                                        <Button
                                            size="sm"
                                            onClick={() => updateStatusMutation.mutate({ scoutId: scout.id, status: 'Inactive' })}
                                            variant="outline"
                                            className="w-full border-slate-700 text-slate-400"
                                        >
                                            Deactivate
                                        </Button>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {filteredScouts.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <Users className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No scouts found matching your filters</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}