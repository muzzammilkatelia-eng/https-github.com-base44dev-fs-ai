import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
    MessageSquare, Send, Clock, CheckCircle, Archive, 
    AlertCircle, FileText, Paperclip 
} from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function ScoutMessaging({ scouts, messages, onUpdate }) {
    const [filter, setFilter] = useState('all');
    const [selectedMessage, setSelectedMessage] = useState(null);
    const [replyText, setReplyText] = useState('');

    const queryClient = useQueryClient();

    const replyMutation = useMutation({
        mutationFn: ({ messageId, reply }) => 
            base44.entities.ScoutMessage.update(messageId, {
                status: 'Replied',
                reply_content: reply,
                replied_at: new Date().toISOString()
            }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-messages'] });
            toast.success('Reply sent');
            setSelectedMessage(null);
            setReplyText('');
            onUpdate();
        }
    });

    const updateStatusMutation = useMutation({
        mutationFn: ({ messageId, status }) => 
            base44.entities.ScoutMessage.update(messageId, { status }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-messages'] });
            onUpdate();
        }
    });

    const filteredMessages = messages.filter(msg => {
        if (filter === 'all') return true;
        return msg.status === filter;
    });

    const getStatusColor = (status) => {
        const colors = {
            'Unread': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Read': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Replied': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Archived': 'bg-slate-700/20 text-slate-500 border-slate-700/30'
        };
        return colors[status] || '';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'Urgent': 'bg-red-500/20 text-red-400 border-red-500/30',
            'High': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Medium': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Low': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[priority] || '';
    };

    const stats = {
        unread: messages.filter(m => m.status === 'Unread').length,
        urgent: messages.filter(m => m.priority === 'Urgent' && m.status !== 'Replied').length,
        total: messages.length
    };

    return (
        <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-blue-500/10 border-blue-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-blue-400 text-sm">Unread Messages</p>
                            <p className="text-blue-400 text-3xl font-bold">{stats.unread}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-red-500/10 border-red-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-red-400 text-sm">Urgent</p>
                            <p className="text-red-400 text-3xl font-bold">{stats.urgent}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm">Total Messages</p>
                            <p className="text-white text-3xl font-bold">{stats.total}</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Filter */}
            <div className="flex gap-2">
                {['all', 'Unread', 'Read', 'Replied'].map(status => (
                    <Button
                        key={status}
                        onClick={() => setFilter(status)}
                        variant={filter === status ? 'default' : 'outline'}
                        size="sm"
                        className={filter === status ? 'bg-cyan-500/20 text-cyan-400' : 'border-slate-700 text-slate-400'}
                    >
                        {status === 'all' ? 'All' : status}
                    </Button>
                ))}
            </div>

            {/* Messages */}
            <div className="space-y-3">
                {filteredMessages.map((message, idx) => (
                    <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className={`border-slate-800 hover:border-cyan-500/30 transition-all cursor-pointer ${
                            message.status === 'Unread' ? 'bg-blue-500/5' : 'bg-slate-900/50'
                        }`}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h4 className="text-white font-semibold">{message.subject}</h4>
                                            <Badge className={getPriorityColor(message.priority)}>
                                                {message.priority}
                                            </Badge>
                                            <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                {message.message_type}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center gap-4 text-sm">
                                            <span className="text-slate-400">From: {message.scout_name}</span>
                                            <span className="text-slate-500">{moment(message.created_date).fromNow()}</span>
                                            {message.related_player && (
                                                <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                                                    Player: {message.related_player}
                                                </Badge>
                                            )}
                                        </div>
                                    </div>
                                    <Badge className={getStatusColor(message.status)}>
                                        {message.status}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <p className="text-slate-300 text-sm">{message.message}</p>
                                
                                {message.attachments && message.attachments.length > 0 && (
                                    <div className="flex items-center gap-2">
                                        <Paperclip className="w-3 h-3 text-slate-400" />
                                        <span className="text-slate-400 text-xs">
                                            {message.attachments.length} attachment(s)
                                        </span>
                                    </div>
                                )}

                                {message.reply_content && (
                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                                        <p className="text-emerald-400 text-xs font-semibold mb-1">Your Reply:</p>
                                        <p className="text-slate-300 text-sm">{message.reply_content}</p>
                                        <p className="text-slate-500 text-xs mt-1">
                                            {moment(message.replied_at).format('MMM D, YYYY h:mm A')}
                                        </p>
                                    </div>
                                )}

                                <div className="flex gap-2">
                                    {message.status !== 'Replied' && (
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button 
                                                    size="sm" 
                                                    onClick={() => {
                                                        setSelectedMessage(message);
                                                        if (message.status === 'Unread') {
                                                            updateStatusMutation.mutate({ messageId: message.id, status: 'Read' });
                                                        }
                                                    }}
                                                    className="bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                                                >
                                                    <Send className="w-3 h-3 mr-1" />
                                                    Reply
                                                </Button>
                                            </DialogTrigger>
                                            <DialogContent className="bg-slate-900 border-slate-800">
                                                <DialogHeader>
                                                    <DialogTitle className="text-white">Reply to {message.scout_name}</DialogTitle>
                                                </DialogHeader>
                                                <div className="space-y-4">
                                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                                        <p className="text-slate-400 text-sm mb-1">Original Message:</p>
                                                        <p className="text-slate-300 text-sm">{message.message}</p>
                                                    </div>
                                                    <div>
                                                        <Label className="text-slate-400">Your Reply</Label>
                                                        <Textarea
                                                            value={replyText}
                                                            onChange={(e) => setReplyText(e.target.value)}
                                                            placeholder="Type your reply..."
                                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                                            rows={5}
                                                        />
                                                    </div>
                                                    <Button
                                                        onClick={() => replyMutation.mutate({ messageId: message.id, reply: replyText })}
                                                        disabled={!replyText || replyMutation.isPending}
                                                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                                                    >
                                                        <Send className="w-4 h-4 mr-2" />
                                                        Send Reply
                                                    </Button>
                                                </div>
                                            </DialogContent>
                                        </Dialog>
                                    )}
                                    {message.status !== 'Archived' && (
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => updateStatusMutation.mutate({ messageId: message.id, status: 'Archived' })}
                                            className="border-slate-700 text-slate-400"
                                        >
                                            <Archive className="w-3 h-3 mr-1" />
                                            Archive
                                        </Button>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {filteredMessages.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <MessageSquare className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No messages found</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}