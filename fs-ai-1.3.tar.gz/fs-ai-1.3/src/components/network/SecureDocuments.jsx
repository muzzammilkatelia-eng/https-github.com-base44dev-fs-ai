import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
    FileText, Upload, Download, Lock, Share2, Eye, 
    Trash2, Search, Filter, Loader2, Shield, FolderUp, CheckCircle, ArrowUpDown 
} from 'lucide-react';
import DriveUploader from '../DriveUploader';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import moment from 'moment';

export default function SecureDocuments({ scouts }) {
    const [showUpload, setShowUpload] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [accessFilter, setAccessFilter] = useState('all');
    const [typeFilter, setTypeFilter] = useState('all');
    const [sortBy, setSortBy] = useState('date_desc');
    const [selectedFile, setSelectedFile] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [uploadProgress, setUploadProgress] = useState(false);

    const [formData, setFormData] = useState({
        title: '',
        document_type: 'Scouting Report',
        access_level: 'Internal',
        player_name: '',
        region: '',
        description: '',
        tags: '',
        allowed_scouts: []
    });

    const queryClient = useQueryClient();

    React.useEffect(() => {
        base44.auth.me().then(setCurrentUser).catch(() => {});
    }, []);

    const { data: documents = [], isLoading } = useQuery({
        queryKey: ['secure-documents'],
        queryFn: () => base44.entities.SecureDocument.list('-created_date')
    });

    const uploadMutation = useMutation({
        mutationFn: async (docData) => {
            setUploadProgress(true);
            
            // Upload file using Core.UploadPrivateFile for secure storage
            const uploadResult = await base44.integrations.Core.UploadPrivateFile({
                file: selectedFile
            });

            const documentData = {
                ...docData,
                file_uri: uploadResult.file_uri,
                file_type: selectedFile.type,
                file_size: selectedFile.size,
                tags: docData.tags.split(',').map(t => t.trim()).filter(Boolean),
                shared_with: [],
                download_count: 0
            };

            return base44.entities.SecureDocument.create(documentData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['secure-documents'] });
            setShowUpload(false);
            setSelectedFile(null);
            setUploadProgress(false);
            toast.success('Document uploaded securely');
            setFormData({
                title: '',
                document_type: 'Scouting Report',
                access_level: 'Internal',
                player_name: '',
                region: '',
                description: '',
                tags: '',
                allowed_scouts: []
            });
        },
        onError: () => {
            setUploadProgress(false);
            toast.error('Upload failed');
        }
    });

    const downloadMutation = useMutation({
        mutationFn: async (document) => {
            // Create signed URL for secure download
            const result = await base44.integrations.Core.CreateFileSignedUrl({
                file_uri: document.file_uri,
                expires_in: 300 // 5 minutes
            });

            // Update download count
            await base44.entities.SecureDocument.update(document.id, {
                download_count: (document.download_count || 0) + 1,
                last_accessed_by: currentUser.email,
                last_accessed_at: new Date().toISOString()
            });

            return result.signed_url;
        },
        onSuccess: (signedUrl) => {
            queryClient.invalidateQueries({ queryKey: ['secure-documents'] });
            window.open(signedUrl, '_blank');
            toast.success('Download started');
        },
        onError: () => {
            toast.error('Download failed. Enable backend functions first.');
        }
    });

    const shareMutation = useMutation({
        mutationFn: ({ documentId, scoutEmail, accessType }) => {
            const doc = documents.find(d => d.id === documentId);
            const scout = scouts.find(s => s.email === scoutEmail);
            
            const sharedWith = [
                ...(doc.shared_with || []),
                {
                    email: scoutEmail,
                    name: scout?.full_name || scoutEmail,
                    shared_at: new Date().toISOString(),
                    access_type: accessType
                }
            ];

            return base44.entities.SecureDocument.update(documentId, { shared_with: sharedWith });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['secure-documents'] });
            toast.success('Document shared');
        }
    });

    const approveMutation = useMutation({
        mutationFn: async (document) => {
            const result = await base44.entities.SecureDocument.update(document.id, {
                approval_status: 'Approved',
                approved_by: currentUser.email,
                approved_at: new Date().toISOString()
            });

            // Send Slack notification if approved
            try {
                const notifyResult = await base44.functions.notifyDocumentApproval({
                    documentId: document.id,
                    documentType: 'secure_document'
                });
                
                if (notifyResult.success) {
                    toast.success('Document approved & announced in Slack');
                }
            } catch (error) {
                console.log('Slack notification skipped:', error);
            }

            return result;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['secure-documents'] });
            toast.success('Document approved');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (documentId) => base44.entities.SecureDocument.delete(documentId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['secure-documents'] });
            toast.success('Document deleted');
        }
    });

    const filteredDocuments = documents
        .filter(doc => {
            // Full-text search across multiple fields
            const searchLower = searchQuery.toLowerCase();
            const matchesSearch = !searchQuery || 
                doc.title?.toLowerCase().includes(searchLower) ||
                doc.player_name?.toLowerCase().includes(searchLower) ||
                doc.description?.toLowerCase().includes(searchLower) ||
                doc.region?.toLowerCase().includes(searchLower) ||
                doc.document_type?.toLowerCase().includes(searchLower) ||
                doc.tags?.some(t => t.toLowerCase().includes(searchLower));
            
            const matchesAccess = accessFilter === 'all' || doc.access_level === accessFilter;
            const matchesType = typeFilter === 'all' || doc.document_type === typeFilter;
            
            return matchesSearch && matchesAccess && matchesType;
        })
        .sort((a, b) => {
            switch (sortBy) {
                case 'date_desc':
                    return new Date(b.created_date) - new Date(a.created_date);
                case 'date_asc':
                    return new Date(a.created_date) - new Date(b.created_date);
                case 'title_asc':
                    return (a.title || '').localeCompare(b.title || '');
                case 'title_desc':
                    return (b.title || '').localeCompare(a.title || '');
                case 'access_level':
                    const accessOrder = { 'Public': 0, 'Internal': 1, 'Confidential': 2, 'Restricted': 3 };
                    return (accessOrder[b.access_level] || 0) - (accessOrder[a.access_level] || 0);
                default:
                    return 0;
            }
        });

    const getAccessColor = (level) => {
        const colors = {
            'Public': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Internal': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Confidential': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Restricted': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[level] || '';
    };

    const getFileIcon = (type) => {
        if (type?.includes('pdf')) return '📄';
        if (type?.includes('video')) return '🎥';
        if (type?.includes('image')) return '🖼️';
        if (type?.includes('document')) return '📝';
        return '📁';
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                        <Shield className="w-6 h-6 text-cyan-400" />
                        Secure Document Vault
                    </h2>
                    <p className="text-slate-400 text-sm">Encrypted storage for player profiles and scouting materials</p>
                </div>
                <Dialog open={showUpload} onOpenChange={setShowUpload}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-cyan-500 to-blue-600">
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Document
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
                        <DialogHeader>
                            <DialogTitle className="text-white">Upload Secure Document</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                            <div>
                                <Label className="text-slate-400">Select File *</Label>
                                <Input
                                    type="file"
                                    onChange={(e) => setSelectedFile(e.target.files[0])}
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                                {selectedFile && (
                                    <p className="text-slate-400 text-xs mt-1">
                                        {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                                    </p>
                                )}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label className="text-slate-400">Document Title *</Label>
                                    <Input
                                        value={formData.title}
                                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>
                                <div>
                                    <Label className="text-slate-400">Document Type</Label>
                                    <Select 
                                        value={formData.document_type} 
                                        onValueChange={(v) => setFormData({...formData, document_type: v})}
                                    >
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Player Profile">Player Profile</SelectItem>
                                            <SelectItem value="Scouting Report">Scouting Report</SelectItem>
                                            <SelectItem value="Video Analysis">Video Analysis</SelectItem>
                                            <SelectItem value="Contract Document">Contract Document</SelectItem>
                                            <SelectItem value="Medical Report">Medical Report</SelectItem>
                                            <SelectItem value="Performance Data">Performance Data</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label className="text-slate-400">Player Name</Label>
                                    <Input
                                        value={formData.player_name}
                                        onChange={(e) => setFormData({...formData, player_name: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>
                                <div>
                                    <Label className="text-slate-400">Region</Label>
                                    <Input
                                        value={formData.region}
                                        onChange={(e) => setFormData({...formData, region: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>
                            </div>

                            <div>
                                <Label className="text-slate-400">Access Level *</Label>
                                <Select 
                                    value={formData.access_level} 
                                    onValueChange={(v) => setFormData({...formData, access_level: v})}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Public">Public</SelectItem>
                                        <SelectItem value="Internal">Internal</SelectItem>
                                        <SelectItem value="Confidential">Confidential</SelectItem>
                                        <SelectItem value="Restricted">Restricted</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div>
                                <Label className="text-slate-400">Description</Label>
                                <Textarea
                                    value={formData.description}
                                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                    rows={3}
                                />
                            </div>

                            <div>
                                <Label className="text-slate-400">Tags (comma-separated)</Label>
                                <Input
                                    value={formData.tags}
                                    onChange={(e) => setFormData({...formData, tags: e.target.value})}
                                    placeholder="e.g., striker, brazil, under-21"
                                    className="bg-slate-800 border-slate-700 text-white mt-1"
                                />
                            </div>

                            <Button
                                onClick={() => uploadMutation.mutate(formData)}
                                disabled={!selectedFile || !formData.title || uploadProgress}
                                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                            >
                                {uploadProgress ? (
                                    <>
                                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                        Encrypting and uploading...
                                    </>
                                ) : (
                                    <>
                                        <Upload className="w-4 h-4 mr-2" />
                                        Upload Securely
                                    </>
                                )}
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-slate-400 text-sm">Total Documents</p>
                            <p className="text-white text-3xl font-bold">{documents.length}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-blue-500/10 border-blue-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-blue-400 text-sm">Internal</p>
                            <p className="text-blue-400 text-3xl font-bold">
                                {documents.filter(d => d.access_level === 'Internal').length}
                            </p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-amber-500/10 border-amber-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-amber-400 text-sm">Confidential</p>
                            <p className="text-amber-400 text-3xl font-bold">
                                {documents.filter(d => d.access_level === 'Confidential').length}
                            </p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-red-500/10 border-red-500/30">
                    <CardContent className="py-4">
                        <div className="text-center">
                            <p className="text-red-400 text-sm">Restricted</p>
                            <p className="text-red-400 text-3xl font-bold">
                                {documents.filter(d => d.access_level === 'Restricted').length}
                            </p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Search & Filter */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="relative md:col-span-2">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                                placeholder="Search documents, players, descriptions, tags..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10 bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        
                        <Select value={accessFilter} onValueChange={setAccessFilter}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <Lock className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Access Level" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Access Levels</SelectItem>
                                <SelectItem value="Public">Public</SelectItem>
                                <SelectItem value="Internal">Internal</SelectItem>
                                <SelectItem value="Confidential">Confidential</SelectItem>
                                <SelectItem value="Restricted">Restricted</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={typeFilter} onValueChange={setTypeFilter}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <Filter className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Document Type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Types</SelectItem>
                                <SelectItem value="Player Profile">Player Profile</SelectItem>
                                <SelectItem value="Scouting Report">Scouting Report</SelectItem>
                                <SelectItem value="Video Analysis">Video Analysis</SelectItem>
                                <SelectItem value="Contract Document">Contract Document</SelectItem>
                                <SelectItem value="Medical Report">Medical Report</SelectItem>
                                <SelectItem value="Performance Data">Performance Data</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="mt-4 flex items-center gap-4">
                        <div className="flex items-center gap-2 text-slate-400 text-sm">
                            <ArrowUpDown className="w-4 h-4" />
                            <span>Sort by:</span>
                        </div>
                        <Select value={sortBy} onValueChange={setSortBy}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="date_desc">Newest First</SelectItem>
                                <SelectItem value="date_asc">Oldest First</SelectItem>
                                <SelectItem value="title_asc">Title (A-Z)</SelectItem>
                                <SelectItem value="title_desc">Title (Z-A)</SelectItem>
                                <SelectItem value="access_level">Access Level (High to Low)</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="text-slate-400 text-sm ml-auto">
                            Showing {filteredDocuments.length} of {documents.length} documents
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Documents Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <AnimatePresence>
                    {filteredDocuments.map((doc, idx) => (
                        <motion.div
                            key={doc.id}
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ delay: idx * 0.05 }}
                        >
                            <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/30 transition-all">
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-center gap-2">
                                            <span className="text-2xl">{getFileIcon(doc.file_type)}</span>
                                            <div className="flex-1 min-w-0">
                                                <CardTitle className="text-white text-sm truncate">{doc.title}</CardTitle>
                                                <p className="text-slate-400 text-xs">{doc.document_type}</p>
                                            </div>
                                        </div>
                                        <Badge className={getAccessColor(doc.access_level)}>
                                            <Lock className="w-3 h-3 mr-1" />
                                            {doc.access_level}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div className="flex flex-wrap gap-2">
                                        {doc.player_name && (
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                {doc.player_name}
                                            </Badge>
                                        )}
                                        {doc.approval_status && (
                                            <Badge className={
                                                doc.approval_status === 'Approved' ? 'bg-emerald-500/20 text-emerald-400' :
                                                doc.approval_status === 'Rejected' ? 'bg-red-500/20 text-red-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }>
                                                {doc.approval_status}
                                            </Badge>
                                        )}
                                    </div>
                                    
                                    {doc.description && (
                                        <p className="text-slate-400 text-xs line-clamp-2">{doc.description}</p>
                                    )}

                                    {doc.tags && doc.tags.length > 0 && (
                                        <div className="flex flex-wrap gap-1">
                                            {doc.tags.slice(0, 3).map((tag, i) => (
                                                <span key={i} className="px-2 py-0.5 bg-slate-700 text-slate-300 text-xs rounded">
                                                    {tag}
                                                </span>
                                            ))}
                                        </div>
                                    )}

                                    <div className="flex items-center justify-between text-xs text-slate-500">
                                        <div>
                                            <Download className="w-3 h-3 inline mr-1" />
                                            {doc.download_count || 0} downloads
                                        </div>
                                        <div>{moment(doc.created_date).fromNow()}</div>
                                    </div>

                                    {doc.shared_with && doc.shared_with.length > 0 && (
                                        <div className="text-xs text-slate-500">
                                            <Share2 className="w-3 h-3 inline mr-1" />
                                            Shared with {doc.shared_with.length} scout(s)
                                        </div>
                                    )}

                                    <div className="flex gap-2">
                                        <Button
                                            size="sm"
                                            onClick={() => downloadMutation.mutate(doc)}
                                            disabled={downloadMutation.isPending}
                                            className="flex-1 bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                                        >
                                            <Download className="w-3 h-3 mr-1" />
                                            Download
                                        </Button>
                                        {doc.approval_status !== 'Approved' && currentUser?.role === 'admin' && (
                                            <Button
                                                size="sm"
                                                onClick={() => approveMutation.mutate(doc)}
                                                disabled={approveMutation.isPending}
                                                className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                                            >
                                                <CheckCircle className="w-3 h-3" />
                                            </Button>
                                        )}
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => deleteMutation.mutate(doc.id)}
                                            className="border-red-500/30 text-red-400 hover:bg-red-500/20"
                                        >
                                            <Trash2 className="w-3 h-3" />
                                        </Button>
                                    </div>
                                    <Button
                                        size="sm"
                                        onClick={async () => {
                                            try {
                                                const signedUrl = await base44.integrations.Core.CreateFileSignedUrl({
                                                    file_uri: doc.file_uri,
                                                    expires_in: 300
                                                });
                                                const fileBlob = await fetch(signedUrl.signed_url).then(r => r.blob());
                                                const file = new File([fileBlob], doc.title, { type: doc.file_type });
                                                
                                                const result = await base44.functions.uploadToDrive({
                                                    file: file,
                                                    fileName: doc.title
                                                });
                                                
                                                if (result.success) {
                                                    toast.success('Uploaded to Google Drive!');
                                                    if (result.webViewLink) window.open(result.webViewLink, '_blank');
                                                }
                                            } catch (err) {
                                                toast.error('Drive upload failed. Enable backend functions first.');
                                            }
                                        }}
                                        className="w-full bg-blue-500/20 text-blue-400 hover:bg-blue-500/30"
                                    >
                                        <FolderUp className="w-3 h-3 mr-1" />
                                        Save to Drive
                                    </Button>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>

            {filteredDocuments.length === 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-12 text-center">
                        <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No documents found</p>
                    </CardContent>
                </Card>
            )}

            {/* Security Notice */}
            <Card className="bg-cyan-500/5 border-cyan-500/30">
                <CardContent className="py-4">
                    <div className="flex items-start gap-3">
                        <Shield className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                        <div>
                            <p className="text-cyan-400 font-semibold text-sm mb-1">🔒 End-to-End Encryption</p>
                            <p className="text-slate-400 text-xs">
                                All documents are encrypted during transit and at rest. Access is controlled via tiered permissions. 
                                Downloads generate temporary signed URLs that expire after 5 minutes.
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}