import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { User, Star, Edit, Save, X, ExternalLink } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import toast from 'react-hot-toast';

const specializations = [
    "Youth Scouting", "Senior Scouting", "Premier League", "La Liga", "Bundesliga",
    "Serie A", "Ligue 1", "Championship", "South America", "Africa", "Asia",
    "Data Analytics", "Video Analysis", "Agent Relations", "Contract Negotiation"
];

export default function UserNetworkProfile() {
    const [editing, setEditing] = useState(false);
    const [formData, setFormData] = useState({});
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: profile } = useQuery({
        queryKey: ['networkProfile', user?.email],
        queryFn: async () => {
            const profiles = await base44.entities.NetworkProfile.filter({ user_email: user.email });
            return profiles[0] || null;
        },
        enabled: !!user
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.NetworkProfile.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['networkProfile']);
            toast.success('Profile created!');
            setEditing(false);
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.NetworkProfile.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries(['networkProfile']);
            toast.success('Profile updated!');
            setEditing(false);
        }
    });

    const handleSave = () => {
        if (profile) {
            updateMutation.mutate({ id: profile.id, data: formData });
        } else {
            createMutation.mutate({ ...formData, user_email: user.email });
        }
    };

    const handleEdit = () => {
        setFormData(profile || { display_name: user?.full_name || '', specializations: [], bio: '' });
        setEditing(true);
    };

    const toggleSpecialization = (spec) => {
        const current = formData.specializations || [];
        if (current.includes(spec)) {
            setFormData({ ...formData, specializations: current.filter(s => s !== spec) });
        } else {
            setFormData({ ...formData, specializations: [...current, spec] });
        }
    };

    if (!user) return null;

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <User className="w-6 h-6 text-cyan-400" />
                        My Network Profile
                    </div>
                    {!editing && profile && (
                        <Button onClick={handleEdit} variant="outline" size="sm">
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                        </Button>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!profile && !editing ? (
                    <div className="text-center py-8">
                        <p className="text-slate-400 mb-4">Create your network profile to connect with scouts and agents</p>
                        <Button onClick={handleEdit} className="bg-cyan-600">
                            Create Profile
                        </Button>
                    </div>
                ) : editing ? (
                    <div className="space-y-4">
                        <div>
                            <Label className="text-slate-400">Display Name</Label>
                            <Input
                                value={formData.display_name || ''}
                                onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div>
                            <Label className="text-slate-400">Bio</Label>
                            <Textarea
                                value={formData.bio || ''}
                                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white"
                                rows={3}
                            />
                        </div>

                        <div>
                            <Label className="text-slate-400">Years of Experience</Label>
                            <Input
                                type="number"
                                value={formData.experience_years || ''}
                                onChange={(e) => setFormData({ ...formData, experience_years: parseInt(e.target.value) })}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div>
                            <Label className="text-slate-400 mb-2 block">Specializations (select multiple)</Label>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                {specializations.map(spec => (
                                    <Badge
                                        key={spec}
                                        onClick={() => toggleSpecialization(spec)}
                                        className={`cursor-pointer ${
                                            (formData.specializations || []).includes(spec)
                                                ? 'bg-cyan-600 text-white'
                                                : 'bg-slate-800 text-slate-400'
                                        }`}
                                    >
                                        {spec}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-400">InScout Profile URL (optional)</Label>
                            <Input
                                value={formData.inscout_profile_url || ''}
                                onChange={(e) => setFormData({ ...formData, inscout_profile_url: e.target.value })}
                                placeholder="https://inscoutnetwork.co.uk/..."
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>

                        <div className="flex gap-2">
                            <Button onClick={handleSave} className="bg-cyan-600 flex-1">
                                <Save className="w-4 h-4 mr-2" />
                                Save Profile
                            </Button>
                            <Button onClick={() => setEditing(false)} variant="outline">
                                <X className="w-4 h-4 mr-2" />
                                Cancel
                            </Button>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex items-start gap-4">
                            <div className="w-20 h-20 bg-gradient-to-br from-cyan-600 to-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
                                {profile.display_name?.[0]?.toUpperCase()}
                            </div>
                            <div className="flex-1">
                                <h3 className="text-white text-xl font-bold">{profile.display_name}</h3>
                                <p className="text-slate-400 text-sm">{user.email}</p>
                                {profile.inscout_verified && (
                                    <div className="flex items-center gap-2 mt-1">
                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                            InScout Verified
                                        </Badge>
                                        {profile.inscout_rating && (
                                            <div className="flex items-center gap-1">
                                                {[...Array(5)].map((_, i) => (
                                                    <Star
                                                        key={i}
                                                        className={`w-3 h-3 ${
                                                            i < profile.inscout_rating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                                                        }`}
                                                    />
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        {profile.bio && (
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Bio</p>
                                <p className="text-white">{profile.bio}</p>
                            </div>
                        )}

                        <div>
                            <p className="text-slate-400 text-sm mb-2">Specializations</p>
                            <div className="flex flex-wrap gap-2">
                                {profile.specializations?.map(spec => (
                                    <Badge key={spec} className="bg-cyan-500/20 text-cyan-400">
                                        {spec}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {profile.experience_years && (
                            <p className="text-slate-400 text-sm">
                                {profile.experience_years} years of experience
                            </p>
                        )}

                        {profile.inscout_profile_url && (
                            <a
                                href={profile.inscout_profile_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-cyan-400 hover:text-cyan-300 text-sm flex items-center gap-1"
                            >
                                View InScout Profile <ExternalLink className="w-3 h-3" />
                            </a>
                        )}

                        <div className="flex gap-4 pt-4 border-t border-slate-800">
                            <div className="text-center">
                                <p className="text-2xl font-bold text-white">{profile.connection_count || 0}</p>
                                <p className="text-slate-400 text-xs">Connections</p>
                            </div>
                            <div className="text-center">
                                <p className="text-2xl font-bold text-white">{profile.reports_shared || 0}</p>
                                <p className="text-slate-400 text-xs">Reports Shared</p>
                            </div>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}