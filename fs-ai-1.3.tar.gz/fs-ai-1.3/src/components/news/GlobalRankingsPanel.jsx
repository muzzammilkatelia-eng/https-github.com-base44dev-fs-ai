import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, ListOrdered, Globe2 } from 'lucide-react';

export default function GlobalRankingsPanel({ tag = 'fdb_global_2025_12_30' }) {
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['global-rankings', tag],
    queryFn: async () => {
      // Get latest rankings snapshot
      const snaps = await base44.entities.ExternalFootballSnapshot.filter(
        { source: 'footballdatabase.eu', snapshot_type: 'rankings', tag },
        '-timestamp',
        1
      );
      return snaps?.[0] || null;
    },
  });

  const scorers = data?.data?.scorers || data?.data?.top_scorers || [];
  const passers = data?.data?.passers || data?.data?.top_passers || [];

  return (
    <Card className="bg-slate-900/90 border-slate-800">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <Globe2 className="w-5 h-5 text-cyan-400" /> Global Rankings
        </CardTitle>
        {data?.timestamp && (
          <Badge className="bg-slate-800 text-slate-300">
            Updated {new Date(data.timestamp).toLocaleString()}
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[0,1].map(i => (
              <div key={i} className="space-y-2">
                {Array.from({ length: 6 }).map((_, j) => (
                  <div key={j} className="h-4 bg-slate-800 rounded" />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-slate-200 font-semibold mb-3 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400" /> 2025 Best Worldwide Scorers
              </h3>
              <div className="space-y-2">
                {scorers.slice(0, 15).map((p, idx) => (
                  <div key={idx} className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">
                      <Badge variant="outline" className="mr-2 border-slate-700">{idx + 1}</Badge>
                      {p.name || p.player}
                    </span>
                    <span className="text-cyan-400 font-semibold">{p.goals ?? p.value ?? p.count}</span>
                  </div>
                ))}
                {scorers.length === 0 && <p className="text-slate-500 text-sm">No scorer data available yet.</p>}
              </div>
            </div>

            <div>
              <h3 className="text-slate-200 font-semibold mb-3 flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-emerald-400" /> 2025 Best Worldwide Passers
              </h3>
              <div className="space-y-2">
                {passers.slice(0, 15).map((p, idx) => (
                  <div key={idx} className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">
                      <Badge variant="outline" className="mr-2 border-slate-700">{idx + 1}</Badge>
                      {p.name || p.player}
                    </span>
                    <span className="text-emerald-400 font-semibold">{p.assists ?? p.value ?? p.count}</span>
                  </div>
                ))}
                {passers.length === 0 && <p className="text-slate-500 text-sm">No passer data available yet.</p>}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}