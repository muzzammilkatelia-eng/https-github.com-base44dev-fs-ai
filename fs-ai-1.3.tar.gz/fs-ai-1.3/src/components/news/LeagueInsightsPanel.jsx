import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Trophy, CalendarDays, LineChart, TrendingUp, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

function Section({ title, children, icon: Icon }) {
  return (
    <Card className="bg-slate-900/80 border-slate-800">
      <CardHeader className="flex items-center gap-2">
        <CardTitle className="text-white text-lg flex items-center gap-2">
          {Icon && <Icon className="w-4 h-4 text-cyan-400" />} {title}
        </CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export default function LeagueInsightsPanel({ region = 'England', league = 'Premier League', season = '2025/2026' }) {
  const [gender, setGender] = React.useState('female');
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['leagueInsights', { region, league, season }],
    queryFn: async () => {
      const filter = { region, league, season };
      if (gender && gender !== 'all') filter.gender = gender;
      const items = await base44.entities.ExternalFootballSnapshot.filter(filter);
      const group = (type) => items.filter(i => i.snapshot_type === type)[0]?.data;
      return {
        overview: group('league_overview'),
        standings: group('standings'),
        fixtures: group('fixtures'),
        transfers: group('transfers'),
        rankings: group('rankings'),
        hot: group('hot_players'),
        streaks: group('streaks')
      };
    },
    refetchInterval: 300000
  });

  if (isLoading) return <div className="text-slate-400">Loading insights…</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="text-slate-300 text-sm">{region} • {league} • {season}</div>
        <div className="flex items-center gap-3">
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white h-8 px-2">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Men</SelectItem>
              <SelectItem value="female">Women</SelectItem>
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
          <button onClick={() => refetch()} className="text-cyan-400 text-sm flex items-center gap-1" disabled={isFetching}>
            <RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
          </button>
        </div>
      </div>

      {/* Overview */}
      {data?.overview && (
        <Section title="League Overview" icon={LineChart}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm text-slate-300">
            <div>Games played: <span className="text-white font-semibold">{data.overview.games_played}</span></div>
            <div>Goals: <span className="text-white font-semibold">{data.overview.goals} ({data.overview.goals_per_match}/match)</span></div>
            <div>Cards: <span className="text-white font-semibold">{data.overview.yellow_cards}Y / {data.overview.red_cards}R</span></div>
            <div>Home/Draw/Away: <span className="text-white font-semibold">{data.overview.home_pct}% / {data.overview.draw_pct}% / {data.overview.away_pct}%</span></div>
          </div>
        </Section>
      )}

      {/* Standings */}
      {data?.standings?.rows?.length > 0 && (
        <Section title="Standings" icon={Trophy}>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8">#</TableHead>
                <TableHead>Club</TableHead>
                <TableHead className="text-right">Pts</TableHead>
                <TableHead className="text-right">W-D-L</TableHead>
                <TableHead className="text-right">GF/GA</TableHead>
                <TableHead className="text-right">Diff</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.standings.rows.map((r, i) => (
                <TableRow key={i}>
                  <TableCell>{r.rank}</TableCell>
                  <TableCell className="text-white">{r.club}</TableCell>
                  <TableCell className="text-right">{r.pts}</TableCell>
                  <TableCell className="text-right">{r.w}-{r.d}-{r.l}</TableCell>
                  <TableCell className="text-right">{r.gf}/{r.ga}</TableCell>
                  <TableCell className="text-right">{r.diff}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Section>
      )}

      {/* Fixtures */}
      {data?.fixtures?.list?.length > 0 && (
        <Section title="Upcoming Fixtures" icon={CalendarDays}>
          <div className="space-y-2">
            {data.fixtures.list.map((fx, i) => (
              <div key={i} className="flex items-center justify-between text-sm text-slate-300">
                <div className="text-slate-400">{fx.datetime}</div>
                <div className="text-white">{fx.home} vs {fx.away}</div>
                {fx.status && <Badge className="bg-slate-800 text-slate-300">{fx.status}</Badge>}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Hot players */}
      {data?.hot?.players?.length > 0 && (
        <Section title="Hot Players" icon={TrendingUp}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {data.hot.players.map((p, i) => (
              <div key={i} className="flex items-center justify-between text-sm text-slate-300 bg-slate-800/50 p-2 rounded">
                <div className="text-white font-medium">{p.name}</div>
                <div>{p.form}</div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Transfers */}
      {data?.transfers?.entries?.length > 0 && (
        <Section title="Official Transfers" icon={TrendingUp}>
          <div className="space-y-2">
            {data.transfers.entries.slice(0, 15).map((t, i) => (
              <div key={i} className="flex items-center justify-between text-sm text-slate-300">
                <div className="text-white">{t.player}</div>
                <div>{t.from} → {t.to}</div>
                {t.fee && <Badge className="bg-emerald-500/20 text-emerald-400">{t.fee}</Badge>}
                {t.date && <span className="text-slate-500">{t.date}</span>}
              </div>
            ))}
          </div>
        </Section>
      )}
    </div>
  );
}