import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Trophy, Loader2, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function LocalFixtures() {
    const [fixtures, setFixtures] = useState([]);
    const [loading, setLoading] = useState(false);
    const [leagueInfo, setLeagueInfo] = useState(null);

    const fetchFixtures = async () => {
        setLoading(true);
        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `Scrape fixtures data from this FA website: https://fulltime.thefa.com/fixtures.html?league=5360640&selectedSeason=893777580&selectedFixtureGroupAgeGroup=1&previousSelectedFixtureGroupAgeGroup=1&selectedDivision=966572375&selectedCompetition=0&selectedFixtureGroupKey=1_514172893

Extract:
- League/Division name
- All upcoming fixtures with: date, time, home team, away team, venue
- Recent results with scores
- Current standings if visible

Return as structured JSON.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        league_name: { type: "string" },
                        division: { type: "string" },
                        fixtures: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    date: { type: "string" },
                                    time: { type: "string" },
                                    home_team: { type: "string" },
                                    away_team: { type: "string" },
                                    venue: { type: "string" },
                                    status: { type: "string" }
                                }
                            }
                        },
                        results: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    date: { type: "string" },
                                    home_team: { type: "string" },
                                    away_team: { type: "string" },
                                    home_score: { type: "number" },
                                    away_score: { type: "number" }
                                }
                            }
                        },
                        standings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "number" },
                                    team: { type: "string" },
                                    played: { type: "number" },
                                    won: { type: "number" },
                                    drawn: { type: "number" },
                                    lost: { type: "number" },
                                    points: { type: "number" }
                                }
                            }
                        }
                    }
                }
            });

            setLeagueInfo({
                name: response.league_name,
                division: response.division
            });
            setFixtures(response.fixtures || []);
            toast.success('Fixtures loaded');
        } catch (error) {
            console.error('Failed to fetch fixtures:', error);
            toast.error('Failed to load fixtures');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchFixtures();
    }, []);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Trophy className="w-5 h-5 text-cyan-400" />
                        <div>
                            <CardTitle className="text-white">
                                {leagueInfo?.name || 'Local Fixtures'}
                            </CardTitle>
                            {leagueInfo?.division && (
                                <p className="text-slate-400 text-sm">{leagueInfo.division}</p>
                            )}
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button
                            onClick={fetchFixtures}
                            disabled={loading}
                            size="sm"
                            variant="outline"
                            className="border-slate-700"
                        >
                            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Refresh'}
                        </Button>
                        <Button
                            onClick={() => window.open('https://fulltime.thefa.com/fixtures.html?league=5360640&selectedSeason=893777580&selectedFixtureGroupAgeGroup=1&previousSelectedFixtureGroupAgeGroup=1&selectedDivision=966572375&selectedCompetition=0&selectedFixtureGroupKey=1_514172893', '_blank')}
                            size="sm"
                            variant="ghost"
                            className="text-slate-400"
                        >
                            <ExternalLink className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-cyan-400" />
                    </div>
                ) : fixtures.length === 0 ? (
                    <p className="text-slate-400 text-center py-8">No fixtures available</p>
                ) : (
                    <div className="space-y-3">
                        {fixtures.slice(0, 10).map((fixture, idx) => (
                            <div
                                key={idx}
                                className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2 text-slate-400 text-xs">
                                        <Calendar className="w-3 h-3" />
                                        <span>{fixture.date} • {fixture.time}</span>
                                    </div>
                                    {fixture.status && (
                                        <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                            {fixture.status}
                                        </Badge>
                                    )}
                                </div>
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex-1">
                                        <p className="text-white font-semibold">{fixture.home_team}</p>
                                        <p className="text-slate-400 text-sm">vs</p>
                                        <p className="text-white font-semibold">{fixture.away_team}</p>
                                    </div>
                                </div>
                                {fixture.venue && (
                                    <div className="flex items-center gap-2 text-slate-500 text-xs mt-2">
                                        <MapPin className="w-3 h-3" />
                                        <span>{fixture.venue}</span>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}