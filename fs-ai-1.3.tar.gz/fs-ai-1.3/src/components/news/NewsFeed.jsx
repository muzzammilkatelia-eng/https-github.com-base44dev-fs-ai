import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Newspaper, Globe2, Shield, Trophy } from 'lucide-react';
import LeagueInsightsPanel from './LeagueInsightsPanel';

const LEAGUES = ['Premier League', 'La Liga', 'Bundesliga', 'Serie A', 'Ligue 1', 'MLS', 'Saudi Pro League', 'Champions League'];
const REGIONS = ['Europe', 'South America', 'North America', 'Asia', 'Africa', 'Middle East'];

export default function NewsFeed() {
  const [region, setRegion] = React.useState('');
  const [league, setLeague] = React.useState('');
  const [categories, setCategories] = React.useState(['transfers', 'injuries', 'results']);

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['footballNews', { region, league, categories }],
    queryFn: async () => {
      const res = await base44.functions.invoke('fetchFootballNews', { region, league, categories, limit: 30 });
      return res.data?.items || [];
    },
    refetchInterval: 120000 // 2 minutes
  });

  const toggleCategory = (cat) => {
    setCategories(prev => prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]);
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <Card className="bg-slate-900/90 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Newspaper className="w-5 h-5 text-cyan-400" /> Live Football News
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col md:flex-row gap-3">
          <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Region</label>
              <Select value={region} onValueChange={setRegion}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="All regions" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value={null}>All</SelectItem>
                  {REGIONS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">League</label>
              <Select value={league} onValueChange={setLeague}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="All leagues" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value={null}>All</SelectItem>
                  {LEAGUES.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1 block">Categories</label>
              <div className="flex flex-wrap gap-2">
                {['transfers', 'injuries', 'results'].map(cat => (
                  <Badge
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={`${categories.includes(cat) ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-700 text-slate-300'} cursor-pointer`}
                  >
                    {cat}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          <div className="flex items-end">
            <Button onClick={() => refetch()} className="bg-cyan-600 hover:bg-cyan-700" disabled={isFetching}>
              <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Insights for selected league/region */}
      {league === 'Premier League' && (
        <LeagueInsightsPanel region={region || 'England'} league={league} season={'2025/2026'} />
      )}

      {/* List */}
      <div className="grid grid-cols-1 gap-3">
        {(isLoading ? Array.from({ length: 6 }).map((_, i) => ({ skeleton: true, id: i })) : data)?.map((item, idx) => (
          <Card key={idx} className="bg-slate-900/80 border-slate-800">
            <CardContent className="p-4">
              {item.skeleton ? (
                <div className="animate-pulse space-y-3">
                  <div className="h-5 bg-slate-800 rounded w-2/3" />
                  <div className="h-4 bg-slate-800 rounded w-full" />
                  <div className="h-4 bg-slate-800 rounded w-4/5" />
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between gap-2">
                    <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-white font-semibold hover:text-cyan-400">
                      {item.title}
                    </a>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-slate-800 text-slate-300">{item.source_name || 'Source'}</Badge>
                      <Badge className={
                        item.category === 'injury' ? 'bg-red-500/20 text-red-400' :
                        item.category === 'transfers' ? 'bg-emerald-500/20 text-emerald-400' :
                        item.category === 'results' ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-700 text-slate-300'
                      }>
                        {item.category || 'news'}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-slate-300 text-sm">{item.summary}</p>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                    {item.league && <Badge variant="outline" className="border-slate-700">{item.league}</Badge>}
                    {item.region && <Badge variant="outline" className="border-slate-700">{item.region}</Badge>}
                    {item.published_at && <span>{new Date(item.published_at).toLocaleString()}</span>}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}