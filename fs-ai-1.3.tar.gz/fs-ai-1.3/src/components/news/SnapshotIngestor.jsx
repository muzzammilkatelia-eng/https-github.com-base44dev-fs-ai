import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { Upload, CheckCircle2, AlertCircle } from 'lucide-react';

export default function SnapshotIngestor() {
  const [region, setRegion] = useState('England');
  const [league, setLeague] = useState('Premier League');
  const [season, setSeason] = useState('2025/2026');
  const [tag, setTag] = useState('raw_dump_2025_12_30');
  const [gender, setGender] = useState('female');
  const [text, setText] = useState('');
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleIngest = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setStatus(null);
    try {
      const { data } = await base44.functions.invoke('ingestExternalSnapshots', {
        raw_text: text,
        region,
        league,
        season,
        tag,
        gender
      });
      if (data?.success) {
        setStatus({ ok: true, msg: `Ingested ${data.count} snapshot(s).` });
        setText('');
      } else {
        setStatus({ ok: false, msg: data?.error || 'Ingestion failed' });
      }
    } catch (e) {
      setStatus({ ok: false, msg: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-slate-900/80 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Upload className="w-4 h-4 text-cyan-400" /> Paste external snapshot → DB
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <Input value={region} onChange={(e) => setRegion(e.target.value)} placeholder="Region" className="bg-slate-800 border-slate-700 text-white" />
          <Input value={league} onChange={(e) => setLeague(e.target.value)} placeholder="League" className="bg-slate-800 border-slate-700 text-white" />
          <Input value={season} onChange={(e) => setSeason(e.target.value)} placeholder="Season" className="bg-slate-800 border-slate-700 text-white" />
          <Input value={tag} onChange={(e) => setTag(e.target.value)} placeholder="Tag" className="bg-slate-800 border-slate-700 text-white" />
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700 text-white">
              <SelectItem value="male">Men</SelectItem>
              <SelectItem value="female">Women</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} placeholder="Paste the raw text here (fixtures, standings, transfers, rankings, etc.)" className="bg-slate-800 border-slate-700 text-white" />
        <div className="flex items-center gap-3">
          <Button onClick={handleIngest} disabled={loading || !text.trim()} className="bg-cyan-600 hover:bg-cyan-700">
            {loading ? 'Ingesting…' : 'Ingest to Database'}
          </Button>
          {status && (
            <div className={`flex items-center gap-2 text-sm ${status.ok ? 'text-emerald-400' : 'text-red-400'}`}>
              {status.ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{status.msg}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}