import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import NotificationPanel from './NotificationPanel';

export default function NotificationBell() {
    const [open, setOpen] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
        retry: false
    });

    const { data: notifications = [] } = useQuery({
        queryKey: ['notifications', user?.email],
        queryFn: async () => {
            if (!user?.email) return [];
            return await base44.entities.Notification.filter(
                { user_email: user.email },
                '-created_date',
                50
            );
        },
        enabled: !!user?.email,
        refetchInterval: 30000 // Refetch every 30 seconds
    });

    const markAllAsReadMutation = useMutation({
        mutationFn: async () => {
            const unread = notifications.filter(n => !n.read);
            await Promise.all(
                unread.map(n => base44.entities.Notification.update(n.id, { read: true }))
            );
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
        }
    });

    const unreadCount = notifications.filter(n => !n.read).length;

    if (!user) return null;

    return (
        <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
                <Button 
                    variant="ghost" 
                    size="icon" 
                    className="relative text-slate-400 hover:text-cyan-400"
                    onClick={() => {
                        setOpen(true);
                        if (unreadCount > 0) {
                            setTimeout(() => markAllAsReadMutation.mutate(), 1000);
                        }
                    }}
                >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                        <Badge 
                            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs"
                        >
                            {unreadCount > 9 ? '9+' : unreadCount}
                        </Badge>
                    )}
                </Button>
            </SheetTrigger>
            <SheetContent className="w-full sm:max-w-md bg-slate-950 border-slate-800">
                <SheetHeader>
                    <SheetTitle className="text-white">Notifications</SheetTitle>
                </SheetHeader>
                <NotificationPanel notifications={notifications} onClose={() => setOpen(false)} />
            </SheetContent>
        </Sheet>
    );
}