import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
    Bell, 
    TrendingDown, 
    Calendar, 
    CheckCircle2, 
    CreditCard,
    Target,
    Trash2,
    ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const typeConfig = {
    talent_match: {
        icon: Target,
        color: 'text-cyan-400',
        bgColor: 'bg-cyan-500/10',
        borderColor: 'border-cyan-500/30'
    },
    price_drop: {
        icon: TrendingDown,
        color: 'text-emerald-400',
        bgColor: 'bg-emerald-500/10',
        borderColor: 'border-emerald-500/30'
    },
    contract_expiry: {
        icon: Calendar,
        color: 'text-amber-400',
        bgColor: 'bg-amber-500/10',
        borderColor: 'border-amber-500/30'
    },
    notion_update: {
        icon: CheckCircle2,
        color: 'text-purple-400',
        bgColor: 'bg-purple-500/10',
        borderColor: 'border-purple-500/30'
    },
    payment_reminder: {
        icon: CreditCard,
        color: 'text-red-400',
        bgColor: 'bg-red-500/10',
        borderColor: 'border-red-500/30'
    },
    payment_success: {
        icon: CheckCircle2,
        color: 'text-emerald-400',
        bgColor: 'bg-emerald-500/10',
        borderColor: 'border-emerald-500/30'
    }
};

const priorityColors = {
    low: 'text-slate-400',
    medium: 'text-blue-400',
    high: 'text-amber-400',
    urgent: 'text-red-400'
};

export default function NotificationPanel({ notifications, onClose }) {
    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Notification.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
        }
    });

    const handleNotificationClick = (notification) => {
        if (notification.action_url) {
            navigate(notification.action_url);
            onClose();
        }
    };

    const clearAllMutation = useMutation({
        mutationFn: async () => {
            await Promise.all(
                notifications.map(n => base44.entities.Notification.delete(n.id))
            );
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
        }
    });

    if (notifications.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-96 text-center">
                <Bell className="w-16 h-16 text-slate-600 mb-4" />
                <p className="text-slate-400 text-lg font-semibold mb-2">No notifications</p>
                <p className="text-slate-500 text-sm">You're all caught up!</p>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full">
            <div className="flex items-center justify-between mb-4">
                <p className="text-slate-400 text-sm">
                    {notifications.length} notification{notifications.length !== 1 ? 's' : ''}
                </p>
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => clearAllMutation.mutate()}
                    className="text-slate-400 hover:text-red-400"
                >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Clear All
                </Button>
            </div>

            <ScrollArea className="flex-1 -mx-6 px-6">
                <AnimatePresence>
                    {notifications.map((notification, index) => {
                        const config = typeConfig[notification.type] || typeConfig.talent_match;
                        const Icon = config.icon;

                        return (
                            <motion.div
                                key={notification.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                transition={{ delay: index * 0.05 }}
                                className={`mb-3 p-4 rounded-lg border ${config.borderColor} ${config.bgColor} ${
                                    notification.action_url ? 'cursor-pointer hover:bg-slate-800/50' : ''
                                } transition-all group relative`}
                                onClick={() => handleNotificationClick(notification)}
                            >
                                <div className="flex items-start gap-3">
                                    <div className={`w-10 h-10 rounded-full ${config.bgColor} flex items-center justify-center flex-shrink-0`}>
                                        <Icon className={`w-5 h-5 ${config.color}`} />
                                    </div>
                                    
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-start justify-between gap-2 mb-1">
                                            <h4 className="text-white font-semibold text-sm">{notification.title}</h4>
                                            <Badge 
                                                variant="outline" 
                                                className={`text-xs ${priorityColors[notification.priority]} border-current`}
                                            >
                                                {notification.priority}
                                            </Badge>
                                        </div>
                                        
                                        <p className="text-slate-300 text-sm mb-2 break-words">
                                            {notification.message}
                                        </p>
                                        
                                        <div className="flex items-center justify-between">
                                            <p className="text-slate-500 text-xs">
                                                {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                                            </p>
                                            
                                            {notification.action_url && (
                                                <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-cyan-400" />
                                            )}
                                        </div>
                                    </div>

                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500 hover:text-red-400 h-8 w-8"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            deleteMutation.mutate(notification.id);
                                        }}
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </Button>
                                </div>

                                {!notification.read && (
                                    <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cyan-500" />
                                )}
                            </motion.div>
                        );
                    })}
                </AnimatePresence>
            </ScrollArea>
        </div>
    );
}