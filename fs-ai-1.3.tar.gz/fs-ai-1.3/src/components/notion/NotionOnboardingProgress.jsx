import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, Circle, RefreshCw, Loader2, Users, Settings } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function NotionOnboardingProgress() {
    const [databaseId, setDatabaseId] = useState(localStorage.getItem('notion_db_id') || '');
    const [isConfiguring, setIsConfiguring] = useState(!localStorage.getItem('notion_db_id'));

    const { data, isLoading, refetch, isRefetching, error } = useQuery({
        queryKey: ['notion-onboarding', databaseId],
        queryFn: async () => {
            const response = await base44.functions.invoke('getNotionOnboarding', { databaseId });
            if (!response.data.success) {
                throw new Error(response.data.error);
            }
            return response.data;
        },
        enabled: !!databaseId,
        refetchInterval: 120000 // Refresh every 2 minutes
    });

    const handleSaveConfig = () => {
        if (!databaseId.trim()) {
            toast.error('Please enter a database ID');
            return;
        }
        localStorage.setItem('notion_db_id', databaseId);
        setIsConfiguring(false);
        toast.success('Configuration saved');
    };

    const handleRefresh = () => {
        toast.loading('Refreshing Notion data...', { id: 'refresh' });
        refetch().then(() => {
            toast.success('Data updated', { id: 'refresh' });
        });
    };

    const handleAuthorize = () => {
        toast.error('Please authorize Notion in your app settings to continue');
    };

    if (error) {
        return (
            <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-400" />
                        Team Onboarding Progress
                    </CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center py-8">
                    <Users className="w-12 h-12 text-purple-400/50 mb-3" />
                    <p className="text-slate-400 mb-4 text-center text-sm">{error.message}</p>
                    {error.message.includes('Unauthorized') || error.message.includes('authorized') ? (
                        <Button onClick={handleAuthorize} className="bg-purple-600 hover:bg-purple-700">
                            Connect Notion
                        </Button>
                    ) : (
                        <Button onClick={() => setIsConfiguring(true)} variant="outline">
                            <Settings className="w-4 h-4 mr-2" />
                            Configure
                        </Button>
                    )}
                </CardContent>
            </Card>
        );
    }

    if (isConfiguring) {
        return (
            <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Settings className="w-5 h-5 text-purple-400" />
                        Configure Notion Database
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm mb-4">
                        Enter your Notion database ID. You can find it in the database URL.
                    </p>
                    <div className="flex gap-2">
                        <Input
                            placeholder="Database ID (e.g., abc123def456...)"
                            value={databaseId}
                            onChange={(e) => setDatabaseId(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                        <Button onClick={handleSaveConfig} className="bg-purple-600 hover:bg-purple-700">
                            Save
                        </Button>
                    </div>
                </CardContent>
            </Card>
        );
    }

    if (isLoading) {
        return (
            <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
                <CardContent className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-slate-900/80 backdrop-blur-xl border-purple-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-400" />
                        Team Onboarding Progress
                    </CardTitle>
                    <div className="flex items-center gap-2">
                        <Badge className="bg-purple-500/20 text-purple-400">
                            {data?.completedTasks}/{data?.totalTasks} Complete
                        </Badge>
                        <Button
                            onClick={() => setIsConfiguring(true)}
                            size="sm"
                            variant="ghost"
                            className="text-slate-400"
                        >
                            <Settings className="w-4 h-4" />
                        </Button>
                        <Button
                            onClick={handleRefresh}
                            disabled={isRefetching}
                            size="sm"
                            variant="ghost"
                            className="text-slate-400 hover:text-purple-400"
                        >
                            <RefreshCw className={`w-4 h-4 ${isRefetching ? 'animate-spin' : ''}`} />
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                {/* Overall Progress */}
                <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-slate-400 text-sm">Overall Progress</span>
                        <span className="text-white font-bold text-lg">{data?.progressPercentage}%</span>
                    </div>
                    <Progress value={data?.progressPercentage} className="h-2" />
                </div>

                {/* By Category */}
                <div className="space-y-4">
                    {Object.entries(data?.byCategory || {}).map(([category, categoryData], idx) => {
                        const categoryProgress = Math.round((categoryData.completed / categoryData.total) * 100);
                        return (
                            <motion.div
                                key={category}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="bg-slate-800/50 rounded-lg p-3 border border-slate-700"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <h4 className="text-white font-semibold text-sm">{category}</h4>
                                    <Badge variant="outline" className="text-xs">
                                        {categoryData.completed}/{categoryData.total}
                                    </Badge>
                                </div>
                                <Progress value={categoryProgress} className="h-1.5 mb-2" />
                                <div className="space-y-1">
                                    {categoryData.tasks.map((task) => (
                                        <div key={task.id} className="flex items-center gap-2 text-sm">
                                            {task.completed ? (
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                                            ) : (
                                                <Circle className="w-4 h-4 text-slate-500 flex-shrink-0" />
                                            )}
                                            <span className={task.completed ? 'text-slate-500 line-through' : 'text-slate-300'}>
                                                {task.name}
                                            </span>
                                            {task.assignee && (
                                                <Badge variant="outline" className="text-xs ml-auto">
                                                    {task.assignee}
                                                </Badge>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}