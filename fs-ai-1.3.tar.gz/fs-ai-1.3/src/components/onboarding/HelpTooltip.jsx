import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle } from 'lucide-react';

export default function HelpTooltip({ content, position = 'top' }) {
    const [isVisible, setIsVisible] = useState(false);

    const positionClasses = {
        top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
        bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
        left: 'right-full top-1/2 -translate-y-1/2 mr-2',
        right: 'left-full top-1/2 -translate-y-1/2 ml-2'
    };

    const arrowClasses = {
        top: 'top-full left-1/2 -translate-x-1/2 border-t-slate-800',
        bottom: 'bottom-full left-1/2 -translate-x-1/2 border-b-slate-800',
        left: 'left-full top-1/2 -translate-y-1/2 border-l-slate-800',
        right: 'right-full top-1/2 -translate-y-1/2 border-r-slate-800'
    };

    return (
        <div className="relative inline-block">
            <button
                onMouseEnter={() => setIsVisible(true)}
                onMouseLeave={() => setIsVisible(false)}
                onClick={() => setIsVisible(!isVisible)}
                className="text-slate-400 hover:text-cyan-400 transition-colors"
            >
                <HelpCircle className="w-4 h-4" />
            </button>

            <AnimatePresence>
                {isVisible && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className={`absolute ${positionClasses[position]} z-50 w-64`}
                    >
                        <div className="bg-slate-800 border border-slate-700 rounded-lg shadow-xl p-3">
                            <p className="text-slate-200 text-sm leading-relaxed">
                                {content}
                            </p>
                            <div className={`absolute ${arrowClasses[position]} w-0 h-0 border-4 border-transparent`} />
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}