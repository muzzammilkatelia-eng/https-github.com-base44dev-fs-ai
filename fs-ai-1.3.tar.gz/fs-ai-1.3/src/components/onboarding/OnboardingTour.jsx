import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ChevronRight, ChevronLeft, Sparkles, Target, TrendingUp, Users, CheckCircle2, Globe2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

const tourSteps = [
    {
        title: "Welcome to FS-AI! ⚽",
        description: "Your intelligent football scouting platform powered by AI. Let's take a quick tour of the key features.",
        icon: Sparkles,
        color: "from-purple-500 to-blue-500",
        page: null
    },
    {
        title: "AI Scouting Automation",
        description: "Automatically scan thousands of players, generate scouting reports, and create tasks based on custom criteria. The AI works 24/7 to identify talent.",
        icon: Sparkles,
        color: "from-purple-500 to-pink-500",
        page: "AIScoutAutomation",
        action: "Navigate to AI Automation"
    },
    {
        title: "Predictive Analytics",
        description: "Forecast player performance, market value trajectories, and injury risks. Make data-driven decisions with AI-powered predictions.",
        icon: TrendingUp,
        color: "from-cyan-500 to-blue-500",
        page: "PredictiveAnalytics",
        action: "Explore Predictions"
    },
    {
        title: "Player Comparison",
        description: "Compare players side-by-side with detailed metrics, tactical analysis, and AI-generated insights. Find the perfect fit for your squad.",
        icon: Users,
        color: "from-emerald-500 to-teal-500",
        page: "PlayerComparison",
        action: "Compare Players"
    },
    {
        title: "Interactive Talent Globe",
        description: "Visualize global talent distribution on an interactive 3D globe. Discover emerging markets and track player movements worldwide.",
        icon: Globe2,
        color: "from-amber-500 to-orange-500",
        page: "Globe",
        action: "View Globe"
    },
    {
        title: "Unified Scouting Hub",
        description: "Your central command for all scouting operations. Manage reports, tasks, communications, and alerts in one place.",
        icon: Target,
        color: "from-blue-500 to-indigo-500",
        page: "ScoutingDashboard",
        action: "Open Scout Hub"
    },
    {
        title: "You're All Set! 🎉",
        description: "Start exploring the platform and leverage AI to revolutionize your scouting process. Need help? Look for the ? icons throughout the app.",
        icon: CheckCircle2,
        color: "from-green-500 to-emerald-500",
        page: null
    }
];

export default function OnboardingTour({ onComplete }) {
    const [currentStep, setCurrentStep] = useState(0);
    const [isVisible, setIsVisible] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        checkOnboardingStatus();
    }, []);

    const checkOnboardingStatus = async () => {
        try {
            const user = await base44.auth.me();
            if (!user.onboarding_completed) {
                setIsVisible(true);
            }
        } catch (error) {
            console.error('Error checking onboarding status:', error);
        }
    };

    const handleNext = () => {
        if (currentStep < tourSteps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            completeTour();
        }
    };

    const handlePrevious = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    const handleSkip = async () => {
        await completeTour();
    };

    const completeTour = async () => {
        try {
            await base44.auth.updateMe({ onboarding_completed: true });
            setIsVisible(false);
            if (onComplete) onComplete();
        } catch (error) {
            console.error('Error completing onboarding:', error);
        }
    };

    const handleNavigateToFeature = () => {
        const step = tourSteps[currentStep];
        if (step.page) {
            navigate(createPageUrl(step.page));
            setIsVisible(false);
        }
    };

    const step = tourSteps[currentStep];
    const Icon = step.icon;
    const progress = ((currentStep + 1) / tourSteps.length) * 100;

    if (!isVisible) return null;

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            >
                <motion.div
                    initial={{ scale: 0.9, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.9, y: 20 }}
                    className="relative max-w-2xl w-full"
                >
                    <Card className="bg-slate-900 border-slate-700 shadow-2xl">
                        <button
                            onClick={handleSkip}
                            className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <CardContent className="pt-8 pb-6">
                            {/* Progress Bar */}
                            <div className="mb-6">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-slate-400 text-sm">
                                        Step {currentStep + 1} of {tourSteps.length}
                                    </span>
                                    <span className="text-cyan-400 text-sm font-semibold">
                                        {Math.round(progress)}%
                                    </span>
                                </div>
                                <div className="w-full bg-slate-800 rounded-full h-2">
                                    <motion.div
                                        initial={{ width: 0 }}
                                        animate={{ width: `${progress}%` }}
                                        transition={{ duration: 0.3 }}
                                        className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full"
                                    />
                                </div>
                            </div>

                            {/* Icon */}
                            <motion.div
                                key={currentStep}
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                transition={{ delay: 0.1 }}
                                className="flex justify-center mb-6"
                            >
                                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg`}>
                                    <Icon className="w-10 h-10 text-white" />
                                </div>
                            </motion.div>

                            {/* Content */}
                            <motion.div
                                key={`content-${currentStep}`}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.2 }}
                                className="text-center mb-8"
                            >
                                <h2 className="text-2xl font-bold text-white mb-3">
                                    {step.title}
                                </h2>
                                <p className="text-slate-300 text-lg leading-relaxed">
                                    {step.description}
                                </p>
                            </motion.div>

                            {/* Navigation Buttons */}
                            <div className="flex items-center justify-between gap-4">
                                <Button
                                    onClick={handlePrevious}
                                    disabled={currentStep === 0}
                                    variant="outline"
                                    className="border-slate-600 hover:bg-slate-800"
                                >
                                    <ChevronLeft className="w-4 h-4 mr-2" />
                                    Previous
                                </Button>

                                <div className="flex gap-2">
                                    {tourSteps.map((_, idx) => (
                                        <div
                                            key={idx}
                                            className={`w-2 h-2 rounded-full transition-all ${
                                                idx === currentStep
                                                    ? 'bg-cyan-400 w-8'
                                                    : idx < currentStep
                                                    ? 'bg-emerald-400'
                                                    : 'bg-slate-700'
                                            }`}
                                        />
                                    ))}
                                </div>

                                <div className="flex gap-2">
                                    {step.page && (
                                        <Button
                                            onClick={handleNavigateToFeature}
                                            variant="outline"
                                            className="border-cyan-500/50 hover:bg-cyan-500/10 text-cyan-400"
                                        >
                                            {step.action}
                                        </Button>
                                    )}
                                    <Button
                                        onClick={handleNext}
                                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                                    >
                                        {currentStep === tourSteps.length - 1 ? 'Get Started' : 'Next'}
                                        <ChevronRight className="w-4 h-4 ml-2" />
                                    </Button>
                                </div>
                            </div>

                            {/* Skip Tour */}
                            {currentStep < tourSteps.length - 1 && (
                                <button
                                    onClick={handleSkip}
                                    className="w-full text-slate-400 hover:text-white text-sm mt-4 transition-colors"
                                >
                                    Skip tour
                                </button>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
}