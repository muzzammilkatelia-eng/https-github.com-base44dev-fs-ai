import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { HelpCircle } from 'lucide-react';
import OnboardingTour from './OnboardingTour';
import { base44 } from '@/api/base44Client';

export default function TourTrigger() {
    const [showTour, setShowTour] = useState(false);

    const handleRestartTour = async () => {
        try {
            await base44.auth.updateMe({ onboarding_completed: false });
            setShowTour(true);
        } catch (error) {
            console.error('Error restarting tour:', error);
        }
    };

    return (
        <>
            <Button
                onClick={handleRestartTour}
                variant="ghost"
                size="sm"
                className="text-slate-400 hover:text-cyan-400"
            >
                <HelpCircle className="w-4 h-4 mr-2" />
                Take Tour
            </Button>
            {showTour && <OnboardingTour onComplete={() => setShowTour(false)} />}
        </>
    );
}