import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function AITrendAnalysis({ player, reports }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzeTrends = async () => {
        setIsAnalyzing(true);
        toast.loading('AI analyzing trends...', { id: 'trend' });

        try {
            const reportsData = reports.map(r => ({
                date: r.created_date,
                overall_rating: r.overall_rating,
                technical_rating: r.technical_rating,
                physical_rating: r.physical_rating,
                mental_rating: r.mental_rating,
                strengths: r.strengths,
                weaknesses: r.weaknesses,
                recommendation: r.recommendation
            }));

            const prompt = `Analyze the performance trend for ${player.name} (${player.position}, ${player.age}y):

HISTORICAL REPORTS (${reports.length} reports):
${reportsData.map((r, i) => `
Report ${i + 1} (${new Date(r.date).toLocaleDateString()}):
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10 | Physical: ${r.physical_rating}/10 | Mental: ${r.mental_rating}/10
- Strengths: ${r.strengths}
- Weaknesses: ${r.weaknesses}
- Recommendation: ${r.recommendation}
`).join('\n')}

PLAYER CONTEXT:
- Current Club: ${player.current_club} (${player.league})
- Market Value: €${player.market_value}M
- Physical: ${JSON.stringify(player.physical_attributes)}
- Playing Style: ${JSON.stringify(player.playing_style)}

Provide:
1. Overall Trend: Improving/Declining/Stable with percentage
2. Key Improvements: Specific areas showing growth
3. Concerning Declines: Areas needing attention
4. Performance Consistency: How stable are the ratings
5. Future Trajectory: 6-month prediction
6. Statistical Prediction: Predict next 3 months ratings (technical, physical, mental)
7. Development Recommendations: Specific training focus
8. Market Value Projection: Predicted value change`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_trend: { type: "string" },
                        trend_percentage: { type: "number" },
                        key_improvements: { type: "array", items: { type: "string" } },
                        concerning_declines: { type: "array", items: { type: "string" } },
                        consistency_score: { type: "number" },
                        consistency_analysis: { type: "string" },
                        future_trajectory: { type: "string" },
                        predicted_ratings: {
                            type: "object",
                            properties: {
                                technical: { type: "number" },
                                physical: { type: "number" },
                                mental: { type: "number" },
                                overall: { type: "number" }
                            }
                        },
                        development_recommendations: { type: "array", items: { type: "string" } },
                        market_value_projection: { type: "string" }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Trend analysis complete!', { id: 'trend' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze trends', { id: 'trend' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getTrendIcon = () => {
        if (!analysis) return null;
        if (analysis.overall_trend?.toLowerCase().includes('improving')) {
            return <TrendingUp className="w-5 h-5 text-emerald-400" />;
        } else if (analysis.overall_trend?.toLowerCase().includes('declining')) {
            return <TrendingDown className="w-5 h-5 text-red-400" />;
        }
        return <Minus className="w-5 h-5 text-slate-400" />;
    };

    return (
        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Trend Analysis
                    </CardTitle>
                    {!analysis && (
                        <Button
                            onClick={analyzeTrends}
                            disabled={isAnalyzing || reports.length < 2}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                            size="sm"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Analyze Trends
                                </>
                            )}
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-8">
                        <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-3 opacity-50" />
                        <p className="text-slate-400 mb-4">
                            {reports.length < 2 
                                ? 'Need at least 2 reports for trend analysis'
                                : 'Click to generate AI-powered performance insights'}
                        </p>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {/* Overall Trend */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-center gap-3 mb-2">
                                {getTrendIcon()}
                                <h3 className="text-white font-bold">Overall Trend</h3>
                                <Badge className={
                                    analysis.overall_trend?.toLowerCase().includes('improving') 
                                        ? 'bg-emerald-500/20 text-emerald-400'
                                        : analysis.overall_trend?.toLowerCase().includes('declining')
                                        ? 'bg-red-500/20 text-red-400'
                                        : 'bg-slate-500/20 text-slate-400'
                                }>
                                    {analysis.trend_percentage > 0 ? '+' : ''}{analysis.trend_percentage}%
                                </Badge>
                            </div>
                            <p className="text-slate-300">{analysis.overall_trend}</p>
                        </div>

                        {/* Key Improvements */}
                        {analysis.key_improvements?.length > 0 && (
                            <div>
                                <h4 className="text-emerald-400 font-semibold mb-2 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4" />
                                    Key Improvements
                                </h4>
                                <ul className="space-y-2">
                                    {analysis.key_improvements.map((imp, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400">✓</span>
                                            {imp}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Concerning Declines */}
                        {analysis.concerning_declines?.length > 0 && (
                            <div>
                                <h4 className="text-amber-400 font-semibold mb-2 flex items-center gap-2">
                                    <TrendingDown className="w-4 h-4" />
                                    Areas Needing Attention
                                </h4>
                                <ul className="space-y-2">
                                    {analysis.concerning_declines.map((decline, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-amber-400">⚠</span>
                                            {decline}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Consistency */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-white font-semibold">Performance Consistency</h4>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {analysis.consistency_score}/100
                                </Badge>
                            </div>
                            <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                                <div 
                                    className="bg-cyan-500 h-2 rounded-full"
                                    style={{ width: `${analysis.consistency_score}%` }}
                                />
                            </div>
                            <p className="text-slate-300 text-sm">{analysis.consistency_analysis}</p>
                        </div>

                        {/* Predicted Ratings */}
                        {analysis.predicted_ratings && (
                            <div>
                                <h4 className="text-purple-400 font-semibold mb-3">3-Month Predictions</h4>
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Overall</p>
                                        <p className="text-white text-2xl font-bold">{analysis.predicted_ratings.overall}/10</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Technical</p>
                                        <p className="text-purple-400 text-2xl font-bold">{analysis.predicted_ratings.technical}/10</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Physical</p>
                                        <p className="text-amber-400 text-2xl font-bold">{analysis.predicted_ratings.physical}/10</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Mental</p>
                                        <p className="text-emerald-400 text-2xl font-bold">{analysis.predicted_ratings.mental}/10</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Future Trajectory */}
                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                            <h4 className="text-blue-400 font-semibold mb-2">6-Month Trajectory</h4>
                            <p className="text-slate-300 text-sm">{analysis.future_trajectory}</p>
                        </div>

                        {/* Development Recommendations */}
                        {analysis.development_recommendations?.length > 0 && (
                            <div>
                                <h4 className="text-cyan-400 font-semibold mb-2">Development Focus</h4>
                                <ul className="space-y-2">
                                    {analysis.development_recommendations.map((rec, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-cyan-400">→</span>
                                            {rec}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Market Value Projection */}
                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Market Value Outlook</h4>
                            <p className="text-slate-300 text-sm">{analysis.market_value_projection}</p>
                        </div>

                        <Button
                            onClick={analyzeTrends}
                            variant="outline"
                            className="w-full border-slate-700"
                            size="sm"
                        >
                            Refresh Analysis
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}