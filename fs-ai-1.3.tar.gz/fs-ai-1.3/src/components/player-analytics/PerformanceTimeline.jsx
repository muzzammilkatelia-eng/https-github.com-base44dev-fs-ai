import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

export default function PerformanceTimeline({ reports }) {
    if (!reports || reports.length === 0) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6 text-center">
                    <p className="text-slate-400">No performance data available</p>
                </CardContent>
            </Card>
        );
    }

    // Sort reports by date and prepare data
    const sortedReports = [...reports].sort((a, b) => 
        new Date(a.created_date) - new Date(b.created_date)
    );

    const performanceData = sortedReports.map(report => ({
        date: new Date(report.created_date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        overall: report.overall_rating || 0,
        technical: report.technical_rating || 0,
        physical: report.physical_rating || 0,
        mental: report.mental_rating || 0
    }));

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                    Performance Over Time
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="date" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                        <YAxis domain={[0, 10]} stroke="#94a3b8" style={{ fontSize: '12px' }} />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: '#1e293b', 
                                border: '1px solid #475569',
                                borderRadius: '8px',
                                color: '#fff'
                            }} 
                        />
                        <Legend />
                        <Area 
                            type="monotone" 
                            dataKey="overall" 
                            stroke="#06b6d4" 
                            fill="#06b6d4" 
                            fillOpacity={0.3}
                            name="Overall"
                        />
                        <Area 
                            type="monotone" 
                            dataKey="technical" 
                            stroke="#8b5cf6" 
                            fill="#8b5cf6" 
                            fillOpacity={0.2}
                            name="Technical"
                        />
                        <Area 
                            type="monotone" 
                            dataKey="physical" 
                            stroke="#f59e0b" 
                            fill="#f59e0b" 
                            fillOpacity={0.2}
                            name="Physical"
                        />
                        <Area 
                            type="monotone" 
                            dataKey="mental" 
                            stroke="#10b981" 
                            fill="#10b981" 
                            fillOpacity={0.2}
                            name="Mental"
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}