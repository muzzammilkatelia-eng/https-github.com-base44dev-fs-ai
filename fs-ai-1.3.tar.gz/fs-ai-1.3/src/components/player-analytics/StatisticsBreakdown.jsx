import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { BarChart3, Target } from 'lucide-react';

export default function StatisticsBreakdown({ latestReport }) {
    if (!latestReport) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6 text-center">
                    <p className="text-slate-400">No statistics available</p>
                </CardContent>
            </Card>
        );
    }

    const radarData = [
        { attribute: 'Technical', value: latestReport.technical_rating || 0, fullMark: 10 },
        { attribute: 'Physical', value: latestReport.physical_rating || 0, fullMark: 10 },
        { attribute: 'Mental', value: latestReport.mental_rating || 0, fullMark: 10 },
        { attribute: 'Tactical', value: latestReport.tactical_rating || 0, fullMark: 10 }
    ];

    const barData = [
        { category: 'Technical', value: latestReport.technical_rating || 0 },
        { category: 'Physical', value: latestReport.physical_rating || 0 },
        { category: 'Mental', value: latestReport.mental_rating || 0 },
        { category: 'Tactical', value: latestReport.tactical_rating || 0 }
    ];

    return (
        <div className="grid md:grid-cols-2 gap-6">
            {/* Radar Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-400" />
                        Attribute Radar
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <RadarChart data={radarData}>
                            <PolarGrid stroke="#475569" />
                            <PolarAngleAxis dataKey="attribute" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <PolarRadiusAxis angle={90} domain={[0, 10]} stroke="#94a3b8" />
                            <Radar 
                                name="Rating" 
                                dataKey="value" 
                                stroke="#06b6d4" 
                                fill="#06b6d4" 
                                fillOpacity={0.5}
                            />
                        </RadarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Bar Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-amber-400" />
                        Rating Breakdown
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={barData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="category" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <YAxis domain={[0, 10]} stroke="#94a3b8" style={{ fontSize: '12px' }} />
                            <Tooltip 
                                contentStyle={{ 
                                    backgroundColor: '#1e293b', 
                                    border: '1px solid #475569',
                                    borderRadius: '8px',
                                    color: '#fff'
                                }} 
                            />
                            <Bar dataKey="value" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
    );
}