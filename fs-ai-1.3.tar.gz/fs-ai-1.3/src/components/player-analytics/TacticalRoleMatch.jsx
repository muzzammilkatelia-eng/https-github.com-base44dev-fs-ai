import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Target, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function TacticalRoleMatch({ player, latestReport }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzeRoles = async () => {
        setIsAnalyzing(true);
        toast.loading('Matching tactical roles...', { id: 'tactical' });

        try {
            const prompt = `Analyze ${player.name}'s tactical role suitability:

PLAYER DATA:
- Position: ${player.position}
- Age: ${player.age}
- Physical: Height ${player.physical_attributes?.height}cm, Weight ${player.physical_attributes?.weight}kg
- Pace: ${player.physical_attributes?.pace}/100
- Strength: ${player.physical_attributes?.strength}/100
- Stamina: ${player.physical_attributes?.stamina}/100
- Work Rate: ${player.playing_style?.work_rate}
- Preferred Foot: ${player.playing_style?.preferred_foot}

${latestReport ? `
LATEST SCOUTING REPORT:
- Overall: ${latestReport.overall_rating}/10
- Technical: ${latestReport.technical_rating}/10
- Physical: ${latestReport.physical_rating}/10
- Mental: ${latestReport.mental_rating}/10
- Strengths: ${latestReport.strengths}
- Weaknesses: ${latestReport.weaknesses}
` : ''}

ANALYZE FIT FOR THESE TACTICAL ROLES:
1. Advanced Playmaker (4-2-3-1 CAM)
2. Deep-Lying Playmaker (4-3-3 CM)
3. Box-to-Box Midfielder (4-3-3 CM)
4. Defensive Midfielder / Destroyer (4-2-3-1 CDM)
5. Inverted Winger (4-3-3 Wings)
6. Target Man Striker (4-4-2)
7. False 9 (4-3-3)
8. Wing-Back (3-5-2)
9. Ball-Playing Centre-Back (4-3-3)
10. Complete Forward (4-2-3-1)

For each role, provide:
- Match percentage (0-100)
- Key attributes that fit
- Missing attributes or gaps
- Overall assessment`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        best_matches: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    role: { type: "string" },
                                    formation: { type: "string" },
                                    match_percentage: { type: "number" },
                                    fit_attributes: { type: "array", items: { type: "string" } },
                                    missing_attributes: { type: "array", items: { type: "string" } },
                                    assessment: { type: "string" }
                                }
                            }
                        },
                        recommended_primary_role: { type: "string" },
                        alternative_roles: { type: "array", items: { type: "string" } },
                        tactical_versatility_score: { type: "number" }
                    }
                }
            });

            // Sort by match percentage
            response.best_matches?.sort((a, b) => b.match_percentage - a.match_percentage);
            
            setAnalysis(response);
            toast.success('Tactical analysis complete!', { id: 'tactical' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze tactical fit', { id: 'tactical' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getMatchColor = (percentage) => {
        if (percentage >= 80) return 'text-emerald-400 bg-emerald-500/20';
        if (percentage >= 60) return 'text-cyan-400 bg-cyan-500/20';
        if (percentage >= 40) return 'text-amber-400 bg-amber-500/20';
        return 'text-red-400 bg-red-500/20';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Tactical Role Matching
                    </CardTitle>
                    {!analysis && (
                        <Button
                            onClick={analyzeRoles}
                            disabled={isAnalyzing}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                            size="sm"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Analyze Fit
                                </>
                            )}
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                {!analysis ? (
                    <div className="text-center py-8">
                        <Target className="w-12 h-12 text-cyan-400 mx-auto mb-3 opacity-50" />
                        <p className="text-slate-400">
                            Discover which tactical roles this player excels in
                        </p>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {/* Versatility Score */}
                        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-purple-400 font-semibold">Tactical Versatility</h4>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {analysis.tactical_versatility_score}/100
                                </Badge>
                            </div>
                            <Progress value={analysis.tactical_versatility_score} className="h-2" />
                        </div>

                        {/* Recommended Primary Role */}
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h4 className="text-emerald-400 font-semibold mb-1">Best Fit</h4>
                            <p className="text-white text-lg">{analysis.recommended_primary_role}</p>
                        </div>

                        {/* Alternative Roles */}
                        {analysis.alternative_roles?.length > 0 && (
                            <div>
                                <h4 className="text-slate-400 text-sm mb-2">Alternative Roles</h4>
                                <div className="flex flex-wrap gap-2">
                                    {analysis.alternative_roles.map((role, i) => (
                                        <Badge key={i} className="bg-slate-700 text-slate-300">
                                            {role}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Detailed Role Matches */}
                        <div className="space-y-3">
                            <h4 className="text-white font-semibold">Detailed Role Analysis</h4>
                            {analysis.best_matches?.slice(0, 5).map((match, i) => (
                                <div key={i} className="bg-slate-800/50 rounded-lg p-4 space-y-3">
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1">
                                            <h5 className="text-white font-semibold">{match.role}</h5>
                                            <p className="text-slate-400 text-sm">{match.formation}</p>
                                        </div>
                                        <Badge className={getMatchColor(match.match_percentage)}>
                                            {match.match_percentage}% Match
                                        </Badge>
                                    </div>

                                    <div className="w-full bg-slate-700 rounded-full h-2">
                                        <div 
                                            className={`h-2 rounded-full ${
                                                match.match_percentage >= 80 ? 'bg-emerald-500' :
                                                match.match_percentage >= 60 ? 'bg-cyan-500' :
                                                match.match_percentage >= 40 ? 'bg-amber-500' :
                                                'bg-red-500'
                                            }`}
                                            style={{ width: `${match.match_percentage}%` }}
                                        />
                                    </div>

                                    {match.fit_attributes?.length > 0 && (
                                        <div>
                                            <p className="text-emerald-400 text-xs font-semibold mb-1">
                                                ✓ Fitting Attributes:
                                            </p>
                                            <div className="flex flex-wrap gap-1">
                                                {match.fit_attributes.slice(0, 4).map((attr, j) => (
                                                    <span key={j} className="text-emerald-300 text-xs bg-emerald-500/10 px-2 py-1 rounded">
                                                        {attr}
                                                    </span>
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    {match.missing_attributes?.length > 0 && (
                                        <div>
                                            <p className="text-amber-400 text-xs font-semibold mb-1">
                                                ⚠ Development Areas:
                                            </p>
                                            <div className="flex flex-wrap gap-1">
                                                {match.missing_attributes.slice(0, 3).map((attr, j) => (
                                                    <span key={j} className="text-amber-300 text-xs bg-amber-500/10 px-2 py-1 rounded">
                                                        {attr}
                                                    </span>
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    <p className="text-slate-300 text-sm">{match.assessment}</p>
                                </div>
                            ))}
                        </div>

                        <Button
                            onClick={analyzeRoles}
                            variant="outline"
                            className="w-full border-slate-700"
                            size="sm"
                        >
                            Refresh Analysis
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}