import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Target, TrendingUp, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AIDevPlanGenerator({ player }) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedPlan, setGeneratedPlan] = useState(null);

    const queryClient = useQueryClient();

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scoutingReports', player.name],
        queryFn: () => base44.entities.ScoutingReport.filter({ player_name: player.name })
    });

    const savePlanMutation = useMutation({
        mutationFn: (planData) => base44.entities.DevelopmentPlan.create(planData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['developmentPlans', player.id] });
            toast.success('Development plan saved');
            setGeneratedPlan(null);
        }
    });

    const generatePlan = async () => {
        setIsGenerating(true);
        toast.loading('Generating personalized development plan...', { id: 'gen' });

        try {
            const prompt = `You are an elite football player development specialist. Create a comprehensive development plan:

Player Profile:
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Rating: ${player.fsai_proprietary_score || 'N/A'}
- Club: ${player.current_club}
- Contract Until: ${player.contract_expiry || 'N/A'}

Career History:
${player.career_history?.slice(0, 3).map(h => `- ${h.season}: ${h.club} - ${h.appearances} apps, ${h.goals} goals`).join('\n') || 'Limited history available'}

Physical Attributes:
- Height: ${player.physical_attributes?.height || 'N/A'}cm
- Pace: ${player.physical_attributes?.pace || 'N/A'}/100
- Strength: ${player.physical_attributes?.strength || 'N/A'}/100

Playing Style:
- Preferred Foot: ${player.playing_style?.preferred_foot || 'N/A'}
- Work Rate: ${player.playing_style?.work_rate || 'N/A'}

Team Strategy: ${activeStrategy ? `${activeStrategy.formation} - ${activeStrategy.playing_style}` : 'Not defined'}

Scout Reports: ${scoutingReports.length} available

Generate a JSON development plan:
{
  "plan_name": "Development plan title",
  "development_phase": "Foundation/Growth/Peak/Transition",
  "target_role": "Specific tactical role",
  "tactical_fit_analysis": "2 sentences on how player fits team strategy",
  "skill_focus_areas": [
    {
      "skill_name": "Specific skill",
      "current_level": 65,
      "target_level": 80,
      "priority": "Critical/High/Medium/Low"
    }
  ],
  "training_exercises": [
    {
      "exercise_name": "Exercise name",
      "category": "Technical/Physical/Tactical/Mental",
      "frequency": "Daily/3x week/Weekly",
      "description": "Brief exercise description"
    }
  ],
  "role_transition_path": {
    "current_role": "Current tactical role",
    "intermediate_roles": ["Role 1", "Role 2"],
    "target_role": "Long-term target role",
    "timeline": "12-18 months",
    "rationale": "Why this path makes sense"
  },
  "milestones": [
    {
      "milestone": "Milestone description",
      "target_date": "2025-06-01"
    }
  ],
  "weekly_plan": {
    "monday": "Training focus",
    "tuesday": "Training focus",
    "wednesday": "Training focus",
    "thursday": "Training focus",
    "friday": "Training focus"
  }
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        plan_name: { type: 'string' },
                        development_phase: { type: 'string' },
                        target_role: { type: 'string' },
                        tactical_fit_analysis: { type: 'string' },
                        skill_focus_areas: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    skill_name: { type: 'string' },
                                    current_level: { type: 'number' },
                                    target_level: { type: 'number' },
                                    priority: { type: 'string' }
                                }
                            }
                        },
                        training_exercises: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    exercise_name: { type: 'string' },
                                    category: { type: 'string' },
                                    frequency: { type: 'string' },
                                    description: { type: 'string' }
                                }
                            }
                        },
                        role_transition_path: {
                            type: 'object',
                            properties: {
                                current_role: { type: 'string' },
                                intermediate_roles: { type: 'array', items: { type: 'string' } },
                                target_role: { type: 'string' },
                                timeline: { type: 'string' },
                                rationale: { type: 'string' }
                            }
                        },
                        milestones: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    milestone: { type: 'string' },
                                    target_date: { type: 'string' }
                                }
                            }
                        },
                        weekly_plan: { type: 'object' }
                    }
                }
            });

            setGeneratedPlan(data);
            toast.success('Development plan generated', { id: 'gen' });
        } catch (error) {
            console.error('Generation error:', error);
            toast.error('Plan generation failed', { id: 'gen' });
        } finally {
            setIsGenerating(false);
        }
    };

    const savePlan = () => {
        savePlanMutation.mutate({
            player_id: player.id,
            player_name: player.name,
            current_position: player.position,
            start_date: new Date().toISOString().split('T')[0],
            ...generatedPlan
        });
    };

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 'Critical': return 'red';
            case 'High': return 'amber';
            case 'Medium': return 'cyan';
            case 'Low': return 'slate';
            default: return 'slate';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-cyan-400" />
                        AI Development Plan Generator
                    </CardTitle>
                    <Button
                        onClick={generatePlan}
                        disabled={isGenerating}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {isGenerating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Generating...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate Plan
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                {!generatedPlan && (
                    <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700 text-center">
                        <Target className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
                        <p className="text-slate-300 mb-2">
                            Generate a personalized development plan for {player.name}
                        </p>
                        <p className="text-slate-400 text-sm">
                            AI will analyze player stats, career history, and team strategy
                        </p>
                    </div>
                )}

                {generatedPlan && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="flex justify-between items-start p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                            <div>
                                <h3 className="text-white text-xl font-bold mb-2">{generatedPlan.plan_name}</h3>
                                <div className="flex gap-2">
                                    <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                        {generatedPlan.development_phase}
                                    </Badge>
                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                        Target: {generatedPlan.target_role}
                                    </Badge>
                                </div>
                            </div>
                            <Button onClick={savePlan} className="bg-emerald-600 hover:bg-emerald-700">
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Save Plan
                            </Button>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-2">Tactical Fit Analysis</h4>
                            <p className="text-slate-300 text-sm">{generatedPlan.tactical_fit_analysis}</p>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-4">Skill Focus Areas</h4>
                            <div className="space-y-3">
                                {generatedPlan.skill_focus_areas?.map((skill, i) => (
                                    <div key={i} className="p-3 bg-slate-900/50 rounded border border-slate-700">
                                        <div className="flex justify-between items-center mb-2">
                                            <div className="flex items-center gap-2">
                                                <h5 className="text-white font-medium">{skill.skill_name}</h5>
                                                <Badge className={`bg-${getPriorityColor(skill.priority)}-500/20 text-${getPriorityColor(skill.priority)}-400`}>
                                                    {skill.priority}
                                                </Badge>
                                            </div>
                                            <span className="text-slate-400 text-sm">
                                                {skill.current_level} → {skill.target_level}
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-800 rounded-full h-2">
                                            <div
                                                className="bg-cyan-500 h-2 rounded-full"
                                                style={{ width: `${(skill.current_level / skill.target_level) * 100}%` }}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-4">Training Exercises</h4>
                            <div className="grid md:grid-cols-2 gap-3">
                                {generatedPlan.training_exercises?.map((ex, i) => (
                                    <div key={i} className="p-3 bg-slate-900/50 rounded border border-slate-700">
                                        <div className="flex justify-between items-start mb-2">
                                            <h5 className="text-white font-medium text-sm">{ex.exercise_name}</h5>
                                            <Badge variant="outline" className="border-slate-600 text-slate-300 text-xs">
                                                {ex.frequency}
                                            </Badge>
                                        </div>
                                        <Badge className="bg-emerald-500/20 text-emerald-400 text-xs mb-2">
                                            {ex.category}
                                        </Badge>
                                        <p className="text-slate-400 text-xs">{ex.description}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-emerald-400" />
                                Career Path
                            </h4>
                            <div className="space-y-3">
                                <div className="flex items-center gap-3">
                                    <Badge className="bg-slate-700 text-white">
                                        {generatedPlan.role_transition_path?.current_role}
                                    </Badge>
                                    {generatedPlan.role_transition_path?.intermediate_roles?.map((role, i) => (
                                        <React.Fragment key={i}>
                                            <span className="text-slate-600">→</span>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                                {role}
                                            </Badge>
                                        </React.Fragment>
                                    ))}
                                    <span className="text-slate-600">→</span>
                                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                        {generatedPlan.role_transition_path?.target_role}
                                    </Badge>
                                </div>
                                <p className="text-slate-400 text-sm">
                                    Timeline: {generatedPlan.role_transition_path?.timeline}
                                </p>
                                <p className="text-slate-300 text-sm">
                                    {generatedPlan.role_transition_path?.rationale}
                                </p>
                            </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3">Milestones</h4>
                                <ul className="space-y-2">
                                    {generatedPlan.milestones?.map((m, i) => (
                                        <li key={i} className="flex items-start gap-2 text-sm">
                                            <CheckCircle className="w-4 h-4 text-cyan-400 mt-0.5" />
                                            <div className="flex-1">
                                                <p className="text-slate-300">{m.milestone}</p>
                                                <p className="text-slate-500 text-xs">{m.target_date}</p>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3">Weekly Plan</h4>
                                <div className="space-y-1 text-sm">
                                    {Object.entries(generatedPlan.weekly_plan || {}).map(([day, focus]) => (
                                        <div key={day} className="flex justify-between">
                                            <span className="text-slate-400 capitalize">{day}:</span>
                                            <span className="text-slate-300">{focus}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}