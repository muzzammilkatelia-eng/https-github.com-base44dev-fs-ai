import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, TrendingUp, Target, Edit2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function DevPlanTracker({ player }) {
    const [editingSkill, setEditingSkill] = useState(null);
    const queryClient = useQueryClient();

    const { data: plans = [] } = useQuery({
        queryKey: ['developmentPlans', player.id],
        queryFn: () => base44.entities.DevelopmentPlan.filter({ player_id: player.id, active: true })
    });

    const updatePlanMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.DevelopmentPlan.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['developmentPlans', player.id] });
            toast.success('Progress updated');
            setEditingSkill(null);
        }
    });

    const completeMilestoneMutation = useMutation({
        mutationFn: ({ planId, milestoneIndex }) => {
            const plan = plans.find(p => p.id === planId);
            const updatedMilestones = [...plan.milestones];
            updatedMilestones[milestoneIndex].achieved = true;
            updatedMilestones[milestoneIndex].achieved_date = new Date().toISOString().split('T')[0];
            return base44.entities.DevelopmentPlan.update(planId, { milestones: updatedMilestones });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['developmentPlans', player.id] });
            toast.success('Milestone completed!');
        }
    });

    const activePlan = plans[0];

    if (!activePlan) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-12 pb-12 text-center">
                    <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">No active development plan</p>
                    <p className="text-slate-500 text-sm">Generate a plan to start tracking progress</p>
                </CardContent>
            </Card>
        );
    }

    const overallProgress = activePlan.skill_focus_areas?.reduce((acc, skill) => {
        const skillProgress = ((skill.current_level / skill.target_level) * 100);
        return acc + skillProgress;
    }, 0) / (activePlan.skill_focus_areas?.length || 1);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                            Development Progress
                        </CardTitle>
                        <p className="text-slate-400 text-sm mt-1">{activePlan.plan_name}</p>
                    </div>
                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                        {overallProgress.toFixed(0)}% Complete
                    </Badge>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-300 text-sm">Overall Progress</span>
                        <span className="text-white font-semibold">{overallProgress.toFixed(0)}%</span>
                    </div>
                    <Progress value={overallProgress} className="h-3" />
                </div>

                <div>
                    <h4 className="text-white font-semibold mb-4">Skill Development</h4>
                    <div className="space-y-3">
                        {activePlan.skill_focus_areas?.map((skill, i) => {
                            const progress = ((skill.current_level / skill.target_level) * 100);
                            const isEditing = editingSkill === i;

                            return (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: i * 0.05 }}
                                    className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <h5 className="text-white font-medium mb-1">{skill.skill_name}</h5>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                {skill.priority} Priority
                                            </Badge>
                                        </div>
                                        {!isEditing ? (
                                            <Button
                                                onClick={() => setEditingSkill(i)}
                                                size="sm"
                                                variant="ghost"
                                                className="text-cyan-400"
                                            >
                                                <Edit2 className="w-4 h-4" />
                                            </Button>
                                        ) : (
                                            <Button
                                                onClick={() => {
                                                    updatePlanMutation.mutate({
                                                        id: activePlan.id,
                                                        data: { skill_focus_areas: activePlan.skill_focus_areas }
                                                    });
                                                }}
                                                size="sm"
                                                className="bg-emerald-600 hover:bg-emerald-700"
                                            >
                                                <Save className="w-4 h-4" />
                                            </Button>
                                        )}
                                    </div>

                                    {isEditing ? (
                                        <div className="space-y-2">
                                            <div className="flex gap-2">
                                                <input
                                                    type="number"
                                                    value={skill.current_level}
                                                    onChange={(e) => {
                                                        const updated = [...activePlan.skill_focus_areas];
                                                        updated[i].current_level = parseInt(e.target.value);
                                                        activePlan.skill_focus_areas = updated;
                                                    }}
                                                    className="w-20 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-white text-sm"
                                                    min="0"
                                                    max="100"
                                                />
                                                <span className="text-slate-500">/</span>
                                                <input
                                                    type="number"
                                                    value={skill.target_level}
                                                    className="w-20 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-white text-sm"
                                                    disabled
                                                />
                                            </div>
                                        </div>
                                    ) : (
                                        <>
                                            <div className="flex justify-between items-center mb-2">
                                                <span className="text-slate-400 text-sm">
                                                    Current: {skill.current_level} / Target: {skill.target_level}
                                                </span>
                                                <span className="text-white font-semibold text-sm">
                                                    {progress.toFixed(0)}%
                                                </span>
                                            </div>
                                            <Progress value={progress} className="h-2" />
                                        </>
                                    )}
                                </motion.div>
                            );
                        })}
                    </div>
                </div>

                <div>
                    <h4 className="text-white font-semibold mb-4">Development Milestones</h4>
                    <div className="space-y-2">
                        {activePlan.milestones?.map((milestone, i) => (
                            <div
                                key={i}
                                className={`p-3 rounded-lg border ${
                                    milestone.achieved 
                                        ? 'bg-emerald-500/10 border-emerald-500/30' 
                                        : 'bg-slate-800/50 border-slate-700'
                                }`}
                            >
                                <div className="flex justify-between items-start">
                                    <div className="flex items-start gap-2 flex-1">
                                        <CheckCircle 
                                            className={`w-5 h-5 mt-0.5 ${
                                                milestone.achieved ? 'text-emerald-400' : 'text-slate-600'
                                            }`}
                                        />
                                        <div className="flex-1">
                                            <p className={`text-sm ${
                                                milestone.achieved ? 'text-emerald-300' : 'text-slate-300'
                                            }`}>
                                                {milestone.milestone}
                                            </p>
                                            <p className="text-slate-500 text-xs mt-1">
                                                Target: {milestone.target_date}
                                                {milestone.achieved && milestone.achieved_date && 
                                                    ` • Achieved: ${milestone.achieved_date}`
                                                }
                                            </p>
                                        </div>
                                    </div>
                                    {!milestone.achieved && (
                                        <Button
                                            onClick={() => completeMilestoneMutation.mutate({ 
                                                planId: activePlan.id, 
                                                milestoneIndex: i 
                                            })}
                                            size="sm"
                                            className="bg-emerald-600 hover:bg-emerald-700"
                                        >
                                            Complete
                                        </Button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                        <h5 className="text-white font-semibold text-sm mb-2">Role Progression</h5>
                        <p className="text-slate-400 text-xs mb-2">
                            {activePlan.role_transition_path?.current_role} → {activePlan.role_transition_path?.target_role}
                        </p>
                        <Badge variant="outline" className="border-slate-600 text-slate-300 text-xs">
                            {activePlan.role_transition_path?.timeline}
                        </Badge>
                    </div>
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                        <h5 className="text-white font-semibold text-sm mb-2">Next Review</h5>
                        <p className="text-slate-300">{activePlan.review_date || 'Not scheduled'}</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}