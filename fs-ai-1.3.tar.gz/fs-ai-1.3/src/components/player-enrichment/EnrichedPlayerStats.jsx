import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, TrendingUp, Activity, AlertCircle } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function EnrichedPlayerStats({ player }) {
    const [enrichedData, setEnrichedData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const fetchEnrichedData = async () => {
        setIsLoading(true);
        toast.loading('Fetching comprehensive player data...', { id: 'enrich' });

        try {
            const { data } = await base44.functions.invoke('enrichPlayerData', {
                playerName: player.name,
                season: new Date().getFullYear()
            });

            if (data.success) {
                setEnrichedData(data.data);
                toast.success('Data loaded successfully', { id: 'enrich' });
            } else {
                toast.error('Failed to load data', { id: 'enrich' });
            }
        } catch (error) {
            console.error('Enrichment error:', error);
            toast.error('Failed to fetch data', { id: 'enrich' });
        } finally {
            setIsLoading(false);
        }
    };

    const formatPerformanceTrend = () => {
        if (!enrichedData?.historical_stats) return [];
        
        return enrichedData.historical_stats
            .map(season => {
                const stats = season.data.statistics?.[0];
                return {
                    season: `${season.season}/${season.season + 1}`,
                    goals: stats?.goals?.total || 0,
                    assists: stats?.goals?.assists || 0,
                    appearances: stats?.games?.appearences || 0,
                    rating: parseFloat(stats?.games?.rating || 0)
                };
            })
            .reverse();
    };

    if (!enrichedData) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center py-12">
                        <Sparkles className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                        <h3 className="text-white font-bold text-lg mb-2">
                            Get Comprehensive Player Data
                        </h3>
                        <p className="text-slate-400 mb-6 max-w-md mx-auto">
                            Access real-time statistics, historical performance, injury records, and transfer history from the API-Football database
                        </p>
                        <Button
                            onClick={fetchEnrichedData}
                            disabled={isLoading}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isLoading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Loading...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Load Comprehensive Data
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>
        );
    }

    const currentStats = enrichedData.current_season?.statistics?.[0];
    const performanceTrend = formatPerformanceTrend();

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
        >
            {/* Current Season Overview */}
            {currentStats && (
                <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Activity className="w-5 h-5 text-cyan-400" />
                            Current Season Performance
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                            <div className="bg-slate-900/50 rounded-lg p-4">
                                <p className="text-slate-400 text-xs mb-1">Appearances</p>
                                <p className="text-2xl font-bold text-white">{currentStats.games?.appearences || 0}</p>
                                <p className="text-xs text-slate-500 mt-1">
                                    {currentStats.games?.minutes || 0}' played
                                </p>
                            </div>
                            <div className="bg-slate-900/50 rounded-lg p-4">
                                <p className="text-slate-400 text-xs mb-1">Goals</p>
                                <p className="text-2xl font-bold text-emerald-400">{currentStats.goals?.total || 0}</p>
                                <p className="text-xs text-slate-500 mt-1">
                                    Penalties: {currentStats.penalty?.scored || 0}
                                </p>
                            </div>
                            <div className="bg-slate-900/50 rounded-lg p-4">
                                <p className="text-slate-400 text-xs mb-1">Assists</p>
                                <p className="text-2xl font-bold text-cyan-400">{currentStats.goals?.assists || 0}</p>
                            </div>
                            <div className="bg-slate-900/50 rounded-lg p-4">
                                <p className="text-slate-400 text-xs mb-1">Rating</p>
                                <p className="text-2xl font-bold text-amber-400">
                                    {parseFloat(currentStats.games?.rating || 0).toFixed(2)}
                                </p>
                            </div>
                            <div className="bg-slate-900/50 rounded-lg p-4">
                                <p className="text-slate-400 text-xs mb-1">Cards</p>
                                <div className="flex items-center gap-2">
                                    <Badge className="bg-yellow-500/20 text-yellow-400">
                                        {currentStats.cards?.yellow || 0} Y
                                    </Badge>
                                    <Badge className="bg-red-500/20 text-red-400">
                                        {currentStats.cards?.red || 0} R
                                    </Badge>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Performance Trend Chart */}
            {performanceTrend.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                            Multi-Season Performance Trend
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={performanceTrend}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="season" stroke="#94a3b8" />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    labelStyle={{ color: '#cbd5e1' }}
                                />
                                <Legend />
                                <Line type="monotone" dataKey="goals" stroke="#10b981" strokeWidth={2} name="Goals" />
                                <Line type="monotone" dataKey="assists" stroke="#06b6d4" strokeWidth={2} name="Assists" />
                                <Line type="monotone" dataKey="appearances" stroke="#f59e0b" strokeWidth={2} name="Appearances" />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            )}

            {/* Injury History */}
            {enrichedData.injuries?.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertCircle className="w-5 h-5 text-red-400" />
                            Injury History
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {enrichedData.injuries.slice(0, 10).map((injury, i) => (
                                <div key={i} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <p className="text-white font-semibold">{injury.type}</p>
                                            <p className="text-slate-400 text-sm">
                                                {new Date(injury.start).toLocaleDateString()} - {new Date(injury.end).toLocaleDateString()}
                                            </p>
                                        </div>
                                        <Badge className="bg-red-500/20 text-red-400">
                                            {Math.ceil((new Date(injury.end) - new Date(injury.start)) / (1000 * 60 * 60 * 24))} days
                                        </Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Transfer History */}
            {enrichedData.transfers?.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Transfer History</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {enrichedData.transfers[0]?.transfers?.slice(0, 8).map((transfer, i) => (
                                <div key={i} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                                    <div className="flex justify-between items-start">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-2">
                                                <p className="text-white font-semibold">{transfer.teams.out.name}</p>
                                                <span className="text-slate-500">→</span>
                                                <p className="text-cyan-400 font-semibold">{transfer.teams.in.name}</p>
                                            </div>
                                            <p className="text-slate-400 text-sm">{transfer.date}</p>
                                            <p className="text-slate-500 text-xs mt-1">{transfer.type}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </motion.div>
    );
}