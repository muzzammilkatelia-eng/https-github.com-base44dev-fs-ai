import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, AlertTriangle, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

export default function AIProjections({ player, reports }) {
    const [projections, setProjections] = useState(null);

    const generateProjectionsMutation = useMutation({
        mutationFn: async () => {
            const prompt = `Generate comprehensive AI-driven future projections for football player:

**Player Profile:**
- Name: ${player.name}
- Age: ${player.age}
- Position: ${player.position}
- Current Rating/Level: ${player.fsai_proprietary_score || 'N/A'}
- Current Club: ${player.current_club}
- Market Value: €${player.market_value}M
- Scouting Reports: ${reports.length}

**Generate 5-Year Projections:**

1. Performance Trajectory:
   - Year-by-year rating projections (current age to age+5)
   - Expected statistical output (goals, assists, etc.)
   - Peak performance prediction

2. Market Value Forecast:
   - Projected market value for each of next 5 years
   - Value growth percentage
   - Best transfer windows

3. Career Trajectory:
   - Most likely career path
   - Potential club moves
   - Expected achievements

4. Development Areas:
   - Key skills to improve
   - Training focus recommendations
   - Physical development needs

5. Risk Assessment:
   - Injury risk projection
   - Performance decline risks
   - Career-limiting factors

6. Peak Years Prediction:
   - When player will reach peak
   - How long peak will last
   - Post-peak trajectory

7. Investment Grade:
   - Overall investment rating (A+, A, B+, B, C)
   - ROI potential
   - Risk-adjusted recommendation

Return structured JSON with all projections.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        yearly_projections: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    age: { type: "number" },
                                    rating: { type: "number" },
                                    market_value: { type: "number" },
                                    goals_predicted: { type: "number" },
                                    assists_predicted: { type: "number" }
                                }
                            }
                        },
                        peak_prediction: {
                            type: "object",
                            properties: {
                                peak_age: { type: "number" },
                                peak_rating: { type: "number" },
                                peak_duration_years: { type: "number" }
                            }
                        },
                        career_trajectory: { type: "string" },
                        potential_moves: {
                            type: "array",
                            items: { type: "string" }
                        },
                        development_priorities: {
                            type: "array",
                            items: { type: "string" }
                        },
                        risk_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        investment_grade: { type: "string" },
                        roi_potential: { type: "string" },
                        recommendation: { type: "string" }
                    }
                }
            });

            return response;
        },
        onSuccess: (data) => {
            setProjections(data);
            toast.success('AI projections generated!');
        },
        onError: () => {
            toast.error('Failed to generate projections');
        }
    });

    const getGradeColor = (grade) => {
        if (grade?.startsWith('A')) return 'from-emerald-500 to-green-600';
        if (grade?.startsWith('B')) return 'from-blue-500 to-cyan-600';
        if (grade?.startsWith('C')) return 'from-amber-500 to-orange-600';
        return 'from-red-500 to-pink-600';
    };

    return (
        <div className="space-y-6">
            {!projections ? (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-24 text-center">
                        <Sparkles className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                        <h3 className="text-white text-xl font-semibold mb-2">AI-Driven Future Projections</h3>
                        <p className="text-slate-400 mb-6 max-w-md mx-auto">
                            Generate comprehensive 5-year career projections, market value forecasts, and development recommendations
                        </p>
                        <Button
                            onClick={() => generateProjectionsMutation.mutate()}
                            disabled={generateProjectionsMutation.isPending}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                            {generateProjectionsMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating Projections...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate AI Projections
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <>
                    {/* Overview Cards */}
                    <div className="grid md:grid-cols-3 gap-4">
                        <Card className={`bg-gradient-to-br ${getGradeColor(projections.investment_grade)} border-0`}>
                            <CardContent className="pt-6">
                                <p className="text-white/80 text-sm mb-2">Investment Grade</p>
                                <p className="text-4xl font-bold text-white">{projections.investment_grade}</p>
                                <p className="text-white/60 text-xs mt-2">{projections.roi_potential}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-cyan-500/30">
                            <CardContent className="pt-6">
                                <p className="text-slate-400 text-sm mb-2">Peak Age</p>
                                <p className="text-3xl font-bold text-white">{projections.peak_prediction?.peak_age} years</p>
                                <p className="text-cyan-400 text-xs mt-2">Rating: {projections.peak_prediction?.peak_rating}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-purple-500/30">
                            <CardContent className="pt-6">
                                <p className="text-slate-400 text-sm mb-2">Peak Duration</p>
                                <p className="text-3xl font-bold text-white">{projections.peak_prediction?.peak_duration_years} years</p>
                                <p className="text-purple-400 text-xs mt-2">Extended prime period</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Performance Projection Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-cyan-400" />
                                5-Year Performance Projection
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={projections.yearly_projections}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="age" stroke="#94a3b8" label={{ value: 'Age', position: 'insideBottom', offset: -5 }} />
                                    <YAxis stroke="#94a3b8" />
                                    <Tooltip
                                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    />
                                    <Line type="monotone" dataKey="rating" stroke="#06b6d4" strokeWidth={3} name="Rating" />
                                    <Line type="monotone" dataKey="market_value" stroke="#10b981" strokeWidth={2} name="Value (€M)" />
                                </LineChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    <div className="grid lg:grid-cols-2 gap-6">
                        {/* Career Trajectory */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Target className="w-5 h-5 text-emerald-400" />
                                    Career Trajectory
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <p className="text-slate-300 leading-relaxed">{projections.career_trajectory}</p>
                                
                                {projections.potential_moves?.length > 0 && (
                                    <div>
                                        <p className="text-slate-400 text-sm mb-2">Potential Club Moves:</p>
                                        <div className="space-y-2">
                                            {projections.potential_moves.map((move, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                    <p className="text-white text-sm">{move}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Development Priorities */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Development Priorities</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {projections.development_priorities?.map((priority, idx) => (
                                        <div key={idx} className="flex items-start gap-3 bg-cyan-500/10 rounded-lg p-3">
                                            <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                                <span className="text-cyan-400 text-xs font-bold">{idx + 1}</span>
                                            </div>
                                            <p className="text-slate-300 text-sm">{priority}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Risk Factors */}
                        <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                                    Risk Factors
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {projections.risk_factors?.map((risk, idx) => (
                                        <div key={idx} className="flex items-start gap-2 bg-slate-800/50 rounded-lg p-3">
                                            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                                            <p className="text-slate-300 text-sm">{risk}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Recommendation */}
                        <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-white">AI Recommendation</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 leading-relaxed">{projections.recommendation}</p>
                            </CardContent>
                        </Card>
                    </div>
                </>
            )}
        </div>
    );
}