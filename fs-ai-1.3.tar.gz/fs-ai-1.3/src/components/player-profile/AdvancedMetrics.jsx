import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Loader2, TrendingUp, TrendingDown, Minus, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AdvancedMetrics({ player, reports }) {
    const [metrics, setMetrics] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const fetchAdvancedMetrics = async () => {
        setIsLoading(true);
        toast.loading('Fetching advanced performance data...', { id: 'metrics' });

        try {
            const prompt = `Generate comprehensive advanced metrics for this player based on their profile and scouting data:

PLAYER: ${player.name}
Position: ${player.position}
Age: ${player.age}
Club: ${player.current_club}
League: ${player.league}

PHYSICAL DATA:
${player.physical_attributes ? JSON.stringify(player.physical_attributes, null, 2) : 'Not available'}

SCOUTING HISTORY (${reports.length} reports):
${reports.slice(0, 3).map((r, i) => `
Report ${i + 1} (${new Date(r.created_date).toLocaleDateString()}):
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10
- Physical: ${r.physical_rating}/10
- Mental: ${r.mental_rating}/10
- Tactical: ${r.tactical_rating}/10
`).join('\n')}

Generate detailed performance metrics including:
1. Per-90 statistics estimates (goals, assists, key passes, successful dribbles, tackles, interceptions)
2. Advanced metrics (xG, xA, progressive passes, ball recoveries)
3. Consistency score (0-100)
4. Form trend (improving/stable/declining)
5. Performance benchmarks vs position average
6. Expected development trajectory

Base estimates on position, age, ratings, and league context.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        per_90_stats: {
                            type: "object",
                            properties: {
                                goals: { type: "number" },
                                assists: { type: "number" },
                                key_passes: { type: "number" },
                                successful_dribbles: { type: "number" },
                                tackles: { type: "number" },
                                interceptions: { type: "number" },
                                pass_completion: { type: "number" }
                            }
                        },
                        advanced_metrics: {
                            type: "object",
                            properties: {
                                xG: { type: "number" },
                                xA: { type: "number" },
                                progressive_passes: { type: "number" },
                                ball_recoveries: { type: "number" },
                                pressures: { type: "number" },
                                duels_won_percent: { type: "number" }
                            }
                        },
                        consistency_score: { type: "number" },
                        form_trend: {
                            type: "string",
                            enum: ["Improving", "Stable", "Declining"]
                        },
                        benchmarks: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    metric: { type: "string" },
                                    player_value: { type: "number" },
                                    position_average: { type: "number" },
                                    percentile: { type: "number" }
                                }
                            }
                        },
                        strengths_analysis: { type: "string" },
                        weaknesses_analysis: { type: "string" },
                        development_notes: { type: "string" }
                    }
                }
            });

            setMetrics(response);
            toast.success('Advanced metrics loaded!', { id: 'metrics' });
        } catch (error) {
            console.error('Failed to fetch metrics:', error);
            toast.error('Failed to load advanced metrics', { id: 'metrics' });
        } finally {
            setIsLoading(false);
        }
    };

    const getTrendIcon = (trend) => {
        switch (trend) {
            case 'Improving': return <TrendingUp className="w-4 h-4 text-green-400" />;
            case 'Declining': return <TrendingDown className="w-4 h-4 text-red-400" />;
            default: return <Minus className="w-4 h-4 text-slate-400" />;
        }
    };

    const getPercentileColor = (percentile) => {
        if (percentile >= 90) return 'text-emerald-400';
        if (percentile >= 75) return 'text-cyan-400';
        if (percentile >= 50) return 'text-amber-400';
        return 'text-slate-400';
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <BarChart3 className="w-5 h-5 text-cyan-400" />
                            Advanced Performance Metrics
                        </CardTitle>
                        {!metrics && (
                            <Button
                                onClick={fetchAdvancedMetrics}
                                disabled={isLoading}
                                className="bg-gradient-to-r from-cyan-500 to-blue-600"
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Loading...
                                    </>
                                ) : (
                                    <>
                                        <BarChart3 className="w-4 h-4 mr-2" />
                                        Load Metrics
                                    </>
                                )}
                            </Button>
                        )}
                    </div>
                </CardHeader>
                {!metrics && !isLoading && (
                    <CardContent>
                        <p className="text-slate-400 text-sm">
                            Load AI-generated advanced performance metrics including per-90 stats, xG/xA, and position benchmarks.
                        </p>
                    </CardContent>
                )}
            </Card>

            {metrics && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Form & Consistency */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-slate-400">Form Trend</span>
                                    {getTrendIcon(metrics.form_trend)}
                                </div>
                                <p className="text-2xl font-bold text-white">{metrics.form_trend}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-slate-400">Consistency Score</span>
                                    <Activity className="w-5 h-5 text-purple-400" />
                                </div>
                                <div className="flex items-end gap-2">
                                    <p className="text-2xl font-bold text-white">{metrics.consistency_score}</p>
                                    <span className="text-slate-400 text-sm mb-1">/100</span>
                                </div>
                                <div className="mt-3 w-full bg-slate-700 rounded-full h-2">
                                    <div 
                                        className="bg-purple-500 h-2 rounded-full"
                                        style={{ width: `${metrics.consistency_score}%` }}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Per-90 Statistics */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Per-90 Statistics</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {Object.entries(metrics.per_90_stats || {}).map(([key, value]) => (
                                    <div key={key} className="bg-slate-800/50 rounded-lg p-3 text-center">
                                        <p className="text-slate-400 text-xs mb-1 capitalize">
                                            {key.replace(/_/g, ' ')}
                                        </p>
                                        <p className="text-white font-bold text-xl">{value.toFixed(2)}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Advanced Metrics */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Advanced Metrics</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                {Object.entries(metrics.advanced_metrics || {}).map(([key, value]) => (
                                    <div key={key} className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1 uppercase">
                                            {key.replace(/_/g, ' ')}
                                        </p>
                                        <p className="text-cyan-400 font-bold text-lg">
                                            {typeof value === 'number' ? value.toFixed(2) : value}
                                            {key.includes('percent') && '%'}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Position Benchmarks */}
                    {metrics.benchmarks && metrics.benchmarks.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Position Benchmarks</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {metrics.benchmarks.map((benchmark, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <span className="text-white font-semibold">{benchmark.metric}</span>
                                                <Badge className={`${
                                                    benchmark.percentile >= 90 ? 'bg-emerald-500/20 text-emerald-400' :
                                                    benchmark.percentile >= 75 ? 'bg-cyan-500/20 text-cyan-400' :
                                                    benchmark.percentile >= 50 ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-slate-500/20 text-slate-400'
                                                }`}>
                                                    {benchmark.percentile}th percentile
                                                </Badge>
                                            </div>
                                            <div className="flex items-center gap-4 text-sm">
                                                <div>
                                                    <span className="text-slate-400">Player: </span>
                                                    <span className={getPercentileColor(benchmark.percentile)}>
                                                        {benchmark.player_value.toFixed(2)}
                                                    </span>
                                                </div>
                                                <div>
                                                    <span className="text-slate-400">Avg: </span>
                                                    <span className="text-slate-300">
                                                        {benchmark.position_average.toFixed(2)}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="mt-2 w-full bg-slate-700 rounded-full h-2">
                                                <div 
                                                    className={`h-2 rounded-full ${
                                                        benchmark.percentile >= 90 ? 'bg-emerald-500' :
                                                        benchmark.percentile >= 75 ? 'bg-cyan-500' :
                                                        benchmark.percentile >= 50 ? 'bg-amber-500' :
                                                        'bg-slate-500'
                                                    }`}
                                                    style={{ width: `${benchmark.percentile}%` }}
                                                />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Analysis Sections */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 text-lg">Statistical Strengths</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {metrics.strengths_analysis}
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400 text-lg">Areas for Improvement</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {metrics.weaknesses_analysis}
                                </p>
                            </CardContent>
                        </Card>
                    </div>

                    <Card className="bg-blue-500/10 border-blue-500/30">
                        <CardHeader>
                            <CardTitle className="text-blue-400">Development Notes</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">
                                {metrics.development_notes}
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}