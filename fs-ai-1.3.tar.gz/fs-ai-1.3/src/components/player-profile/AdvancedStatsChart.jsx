import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

export default function AdvancedStatsChart({ player }) {
    const physicalAttributes = player.physical_attributes || {};
    
    const radarData = [
        { attribute: 'Pace', value: physicalAttributes.pace || 0 },
        { attribute: 'Strength', value: physicalAttributes.strength || 0 },
        { attribute: 'Stamina', value: physicalAttributes.stamina || 0 },
        { attribute: 'Technical', value: 75 },
        { attribute: 'Tactical', value: 70 },
        { attribute: 'Mental', value: 65 }
    ];

    const careerStats = player.career_history || [];
    const barData = careerStats.slice(-5).map(season => ({
        season: season.season,
        goals: season.goals || 0,
        assists: season.assists || 0,
        appearances: season.appearances || 0
    }));

    const advancedMetrics = [
        { label: 'xG per 90', value: '0.45', description: 'Expected goals per 90 minutes' },
        { label: 'xA per 90', value: '0.32', description: 'Expected assists per 90 minutes' },
        { label: 'Pass Completion', value: '87%', description: 'Overall pass accuracy' },
        { label: 'Progressive Passes', value: '6.2', description: 'Forward passes per 90' },
        { label: 'Defensive Actions', value: '12.4', description: 'Tackles + interceptions per 90' },
        { label: 'Pressures', value: '18.5', description: 'Pressing actions per 90' }
    ];

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
                {advancedMetrics.map((metric, i) => (
                    <Card key={i} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="text-center">
                                <p className="text-3xl font-bold text-cyan-400">{metric.value}</p>
                                <p className="text-white font-semibold mt-1">{metric.label}</p>
                                <p className="text-slate-400 text-xs mt-1">{metric.description}</p>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Attribute Radar</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                        <RadarChart data={radarData}>
                            <PolarGrid stroke="#475569" />
                            <PolarAngleAxis dataKey="attribute" tick={{ fill: '#94a3b8' }} />
                            <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#94a3b8' }} />
                            <Radar name="Player" dataKey="value" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
                        </RadarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {barData.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Career Statistics (Last 5 Seasons)</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={400}>
                            <BarChart data={barData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                                <XAxis dataKey="season" tick={{ fill: '#94a3b8' }} />
                                <YAxis tick={{ fill: '#94a3b8' }} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                    labelStyle={{ color: '#fff' }}
                                />
                                <Legend />
                                <Bar dataKey="goals" fill="#06b6d4" name="Goals" />
                                <Bar dataKey="assists" fill="#8b5cf6" name="Assists" />
                                <Bar dataKey="appearances" fill="#10b981" name="Appearances" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}