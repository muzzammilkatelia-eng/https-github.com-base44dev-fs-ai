import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { TrendingUp, Target, Shield, Zap } from 'lucide-react';

export default function AdvancedStatsSection({ player }) {
    // Extract physical attributes for radar chart
    const physicalData = player.physical_attributes ? [
        { attribute: 'Pace', value: player.physical_attributes.pace || 70 },
        { attribute: 'Strength', value: player.physical_attributes.strength || 70 },
        { attribute: 'Stamina', value: player.physical_attributes.stamina || 70 }
    ] : [];

    // Mock advanced stats - in production these would come from the player entity
    const advancedStats = {
        attacking: {
            xG: 0.28,
            xA: 0.22,
            shots_per_90: 2.4,
            key_passes_per_90: 1.8,
            dribbles_success: 68
        },
        passing: {
            pass_completion: 87.5,
            progressive_passes: 4.2,
            through_balls: 0.6,
            long_balls_accuracy: 62
        },
        defending: {
            tackles_per_90: 2.1,
            interceptions_per_90: 1.5,
            clearances_per_90: 1.2,
            aerial_duels_won: 58
        },
        discipline: {
            fouls_per_90: 1.3,
            yellow_cards: 4,
            red_cards: 0
        }
    };

    const statCategories = [
        { name: 'xG per 90', value: advancedStats.attacking.xG },
        { name: 'xA per 90', value: advancedStats.attacking.xA },
        { name: 'Tackles', value: advancedStats.defending.tackles_per_90 },
        { name: 'Interceptions', value: advancedStats.defending.interceptions_per_90 },
        { name: 'Key Passes', value: advancedStats.passing.progressive_passes }
    ];

    return (
        <div className="space-y-6">
            {/* Key Metrics Grid */}
            <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-cyan-500/20 rounded-lg">
                                <Target className="w-6 h-6 text-cyan-400" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-white">
                                    {advancedStats.attacking.xG.toFixed(2)}
                                </p>
                                <p className="text-slate-400 text-sm">xG per 90</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-purple-500/20 rounded-lg">
                                <Zap className="w-6 h-6 text-purple-400" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-white">
                                    {advancedStats.attacking.xA.toFixed(2)}
                                </p>
                                <p className="text-slate-400 text-sm">xA per 90</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-emerald-500/20 rounded-lg">
                                <TrendingUp className="w-6 h-6 text-emerald-400" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-white">
                                    {advancedStats.passing.pass_completion}%
                                </p>
                                <p className="text-slate-400 text-sm">Pass Completion</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-amber-500/20 rounded-lg">
                                <Shield className="w-6 h-6 text-amber-400" />
                            </div>
                            <div>
                                <p className="text-2xl font-bold text-white">
                                    {advancedStats.defending.tackles_per_90.toFixed(1)}
                                </p>
                                <p className="text-slate-400 text-sm">Tackles per 90</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Charts */}
            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Per 90 Minute Stats</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={statCategories}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="name" stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    labelStyle={{ color: '#e2e8f0' }}
                                />
                                <Bar dataKey="value" fill="#06b6d4" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {physicalData.length > 0 && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Physical Attributes</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <RadarChart data={physicalData}>
                                    <PolarGrid stroke="#334155" />
                                    <PolarAngleAxis dataKey="attribute" stroke="#94a3b8" />
                                    <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#94a3b8" />
                                    <Radar name="Physical" dataKey="value" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.6} />
                                    <Tooltip
                                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                        labelStyle={{ color: '#e2e8f0' }}
                                    />
                                </RadarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* Detailed Stats Tables */}
            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Attacking Stats</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(advancedStats.attacking).map(([key, value]) => (
                                <div key={key} className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg">
                                    <span className="text-slate-300 capitalize">{key.replace(/_/g, ' ')}</span>
                                    <span className="text-white font-semibold">{typeof value === 'number' ? value.toFixed(2) : value}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Defensive Stats</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(advancedStats.defending).map(([key, value]) => (
                                <div key={key} className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg">
                                    <span className="text-slate-300 capitalize">{key.replace(/_/g, ' ')}</span>
                                    <span className="text-white font-semibold">{typeof value === 'number' ? value.toFixed(2) : value}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}