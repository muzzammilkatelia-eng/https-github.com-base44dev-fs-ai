import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Award, Star, Medal } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AwardsHonours({ player }) {
    if (!player.awards_honours || player.awards_honours.length === 0) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-12">
                    <div className="text-center">
                        <Trophy className="w-12 h-12 text-slate-600 mx-auto mb-3 opacity-50" />
                        <p className="text-slate-400">No awards or honours recorded yet</p>
                    </div>
                </CardContent>
            </Card>
        );
    }

    const individualAwards = player.awards_honours.filter(a => 
        ['Individual', 'Golden Boot', 'Player of the Year', 'Young Player'].includes(a.award_type)
    );
    const teamHonours = player.awards_honours.filter(a => 
        ['Team', 'League Title', 'Cup Winner', 'Continental', 'International'].includes(a.award_type)
    );

    const getAwardIcon = (type) => {
        switch(type) {
            case 'Golden Boot': return Trophy;
            case 'Player of the Year': return Star;
            case 'Young Player': return Award;
            case 'League Title': return Medal;
            case 'Cup Winner': return Trophy;
            case 'Continental': return Star;
            case 'International': return Medal;
            default: return Award;
        }
    };

    const getAwardColor = (type) => {
        if (['Golden Boot', 'Player of the Year', 'Continental', 'International'].includes(type)) {
            return 'from-amber-500 to-yellow-600';
        }
        if (['League Title', 'Cup Winner'].includes(type)) {
            return 'from-emerald-500 to-teal-600';
        }
        if (type === 'Young Player') {
            return 'from-cyan-500 to-blue-600';
        }
        return 'from-purple-500 to-pink-600';
    };

    return (
        <div className="space-y-6">
            {/* Summary */}
            <Card className="bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border-amber-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-amber-400" />
                        Career Honours
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                            <Award className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                            <p className="text-3xl font-bold text-white">{individualAwards.length}</p>
                            <p className="text-slate-400 text-sm">Individual Awards</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                            <Medal className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                            <p className="text-3xl font-bold text-white">{teamHonours.length}</p>
                            <p className="text-slate-400 text-sm">Team Honours</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Individual Awards */}
            {individualAwards.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Star className="w-5 h-5 text-purple-400" />
                            Individual Awards
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4">
                            {individualAwards.map((award, idx) => {
                                const Icon = getAwardIcon(award.award_type);
                                return (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, scale: 0.95 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        transition={{ delay: idx * 0.05 }}
                                        className="bg-slate-800/50 rounded-lg p-4"
                                    >
                                        <div className="flex items-start gap-4">
                                            <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${getAwardColor(award.award_type)} flex items-center justify-center flex-shrink-0`}>
                                                <Icon className="w-6 h-6 text-white" />
                                            </div>
                                            <div className="flex-1">
                                                <div className="flex items-start justify-between mb-2">
                                                    <div>
                                                        <h4 className="text-white font-semibold">{award.award_name}</h4>
                                                        <p className="text-slate-400 text-sm">{award.competition}</p>
                                                    </div>
                                                    <Badge className="bg-amber-500/20 text-amber-400">
                                                        {award.year}
                                                    </Badge>
                                                </div>
                                                {award.description && (
                                                    <p className="text-slate-300 text-sm">{award.description}</p>
                                                )}
                                            </div>
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Team Honours */}
            {teamHonours.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Trophy className="w-5 h-5 text-emerald-400" />
                            Team Honours
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-3">
                            {teamHonours.map((honour, idx) => {
                                const Icon = getAwardIcon(honour.award_type);
                                return (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.05 }}
                                        className="bg-slate-800/50 rounded-lg p-3 flex items-center gap-4"
                                    >
                                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getAwardColor(honour.award_type)} flex items-center justify-center`}>
                                            <Icon className="w-5 h-5 text-white" />
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex items-center justify-between">
                                                <h4 className="text-white font-semibold text-sm">{honour.award_name}</h4>
                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                    {honour.year}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-xs">{honour.competition}</p>
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}