import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, TrendingUp, Users, Calendar } from 'lucide-react';

export default function CareerTimeline({ player }) {
    // Generate timeline events from player data
    const events = [];

    // Add current club
    if (player.current_club) {
        events.push({
            date: new Date().toISOString(),
            type: 'club',
            title: `Playing for ${player.current_club}`,
            description: `${player.position} in ${player.league}`,
            icon: Users
        });
    }

    // Add contract expiry
    if (player.contract_expiry) {
        events.push({
            date: player.contract_expiry,
            type: 'contract',
            title: 'Contract Expiry',
            description: `Contract ends on ${new Date(player.contract_expiry).toLocaleDateString()}`,
            icon: Calendar
        });
    }

    // Add market value milestone
    if (player.market_value) {
        events.push({
            date: new Date().toISOString(),
            type: 'value',
            title: `Market Value: €${player.market_value}M`,
            description: 'Current transfer valuation',
            icon: TrendingUp
        });
    }

    // Add injury milestones
    if (player.injury_history?.length > 0) {
        player.injury_history.forEach(injury => {
            if (injury.severity === 'Serious' || injury.severity === 'Severe') {
                events.push({
                    date: injury.date,
                    type: 'injury',
                    title: `${injury.injury_type}`,
                    description: `${injury.severity} injury - ${injury.recovery_time} recovery`,
                    icon: Calendar
                });
            }
        });
    }

    // Sort events by date (most recent first)
    events.sort((a, b) => new Date(b.date) - new Date(a.date));

    const getEventColor = (type) => {
        switch (type) {
            case 'club': return 'border-cyan-500/30 bg-cyan-500/10';
            case 'value': return 'border-emerald-500/30 bg-emerald-500/10';
            case 'contract': return 'border-amber-500/30 bg-amber-500/10';
            case 'injury': return 'border-red-500/30 bg-red-500/10';
            default: return 'border-slate-700 bg-slate-800/50';
        }
    };

    const getIconColor = (type) => {
        switch (type) {
            case 'club': return 'text-cyan-400';
            case 'value': return 'text-emerald-400';
            case 'contract': return 'text-amber-400';
            case 'injury': return 'text-red-400';
            default: return 'text-slate-400';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-amber-400" />
                    Career Timeline
                </CardTitle>
            </CardHeader>
            <CardContent>
                {events.length === 0 ? (
                    <p className="text-slate-400 text-center py-8">No timeline events available</p>
                ) : (
                    <div className="relative">
                        {/* Timeline line */}
                        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-slate-700" />
                        
                        <div className="space-y-6">
                            {events.map((event, idx) => {
                                const Icon = event.icon;
                                return (
                                    <div key={idx} className="relative flex gap-4">
                                        {/* Timeline dot */}
                                        <div className={`relative z-10 flex-shrink-0 w-12 h-12 rounded-full border-2 ${getEventColor(event.type)} flex items-center justify-center`}>
                                            <Icon className={`w-5 h-5 ${getIconColor(event.type)}`} />
                                        </div>
                                        
                                        {/* Event content */}
                                        <div className="flex-1 pb-6">
                                            <div className={`border ${getEventColor(event.type)} rounded-lg p-4`}>
                                                <div className="flex items-start justify-between mb-2">
                                                    <h4 className="text-white font-semibold">{event.title}</h4>
                                                    <Badge variant="outline" className="text-xs text-slate-400">
                                                        {new Date(event.date).toLocaleDateString()}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-300 text-sm">{event.description}</p>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}