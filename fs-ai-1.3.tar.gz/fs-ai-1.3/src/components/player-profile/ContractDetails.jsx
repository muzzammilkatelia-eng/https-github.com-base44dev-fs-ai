import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, DollarSign, Shield, AlertCircle, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

export default function ContractDetails({ player }) {
    const getDaysUntilExpiry = () => {
        if (!player.contract_expiry) return null;
        const expiry = new Date(player.contract_expiry);
        const now = new Date();
        const days = Math.floor((expiry - now) / (1000 * 60 * 60 * 24));
        return days;
    };

    const daysUntilExpiry = getDaysUntilExpiry();
    const isExpiringSoon = daysUntilExpiry !== null && daysUntilExpiry < 365;

    return (
        <div className="grid lg:grid-cols-2 gap-6">
            {/* Contract Overview */}
            <Card className={`border-slate-800 ${isExpiringSoon ? 'bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30' : 'bg-slate-900/50'}`}>
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-amber-400" />
                        Contract Information
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {player.contract_expiry && (
                        <div>
                            <span className="text-slate-400 text-sm">Contract Expiry</span>
                            <p className="text-white text-xl font-bold">
                                {format(new Date(player.contract_expiry), 'MMMM d, yyyy')}
                            </p>
                            {daysUntilExpiry !== null && (
                                <div className="flex items-center gap-2 mt-2">
                                    <Badge className={isExpiringSoon ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}>
                                        {daysUntilExpiry > 0 ? `${daysUntilExpiry} days remaining` : 'Contract expired'}
                                    </Badge>
                                    {isExpiringSoon && daysUntilExpiry > 0 && (
                                        <div className="flex items-center gap-1 text-amber-400">
                                            <AlertCircle className="w-4 h-4" />
                                            <span className="text-xs">Expiring soon</span>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}

                    {player.transfer_status && (
                        <div>
                            <span className="text-slate-400 text-sm">Transfer Status</span>
                            <div className="mt-2">
                                <Badge className={`${
                                    player.transfer_status === 'Available' ? 'bg-emerald-500/20 text-emerald-400' :
                                    player.transfer_status === 'Under Negotiation' ? 'bg-amber-500/20 text-amber-400' :
                                    player.transfer_status === 'Transfer Listed' ? 'bg-purple-500/20 text-purple-400' :
                                    'bg-slate-500/20 text-slate-400'
                                }`}>
                                    {player.transfer_status}
                                </Badge>
                            </div>
                        </div>
                    )}

                    {player.transfer_fee_estimate && (
                        <div>
                            <span className="text-slate-400 text-sm">Transfer Fee Estimate</span>
                            <div className="mt-2 bg-slate-800/50 rounded-lg p-3">
                                <p className="text-emerald-400 text-lg font-semibold">
                                    {player.transfer_fee_estimate.currency} {player.transfer_fee_estimate.minimum}M - {player.transfer_fee_estimate.maximum}M
                                </p>
                                <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
                                    <div className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-2 rounded-full" style={{ width: '75%' }} />
                                </div>
                            </div>
                        </div>
                    )}

                    {player.market_value && (
                        <div>
                            <span className="text-slate-400 text-sm">Current Market Value</span>
                            <p className="text-cyan-400 text-2xl font-bold">€{player.market_value}M</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Release Clause */}
            {player.release_clause && player.release_clause.exists && (
                <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-5 h-5 text-amber-400" />
                            Release Clause
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <span className="text-slate-400 text-sm">Activation Amount</span>
                            <p className="text-amber-400 text-3xl font-bold mt-1">
                                {player.release_clause.currency} {player.release_clause.amount}M
                            </p>
                        </div>

                        {player.release_clause.conditions && (
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <span className="text-slate-400 text-sm block mb-2">Conditions & Terms</span>
                                <p className="text-slate-300 text-sm leading-relaxed">{player.release_clause.conditions}</p>
                            </div>
                        )}

                        <div className="flex items-center gap-2 text-amber-400">
                            <TrendingUp className="w-4 h-4" />
                            <span className="text-sm">This clause can be triggered by any club meeting the amount</span>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Agent Details (if available) */}
            {player.agent_details && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <DollarSign className="w-5 h-5 text-emerald-400" />
                            Agent & Representation
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        {player.agent_details.agent_name && (
                            <div>
                                <span className="text-slate-400 text-sm">Agent Name</span>
                                <p className="text-white font-semibold">{player.agent_details.agent_name}</p>
                            </div>
                        )}
                        {player.agent_details.agency && (
                            <div>
                                <span className="text-slate-400 text-sm">Agency</span>
                                <p className="text-white">{player.agent_details.agency}</p>
                            </div>
                        )}
                        <div className="pt-3 border-t border-slate-700">
                            {player.agent_details.agent_email && (
                                <div className="mb-2">
                                    <span className="text-slate-400 text-xs">Email</span>
                                    <p className="text-cyan-400 text-sm">{player.agent_details.agent_email}</p>
                                </div>
                            )}
                            {player.agent_details.agent_phone && (
                                <div>
                                    <span className="text-slate-400 text-xs">Phone</span>
                                    <p className="text-white text-sm">{player.agent_details.agent_phone}</p>
                                </div>
                            )}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}