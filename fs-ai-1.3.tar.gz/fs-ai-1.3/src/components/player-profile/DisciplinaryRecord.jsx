import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Shield, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DisciplinaryRecord({ player }) {
    if (!player.disciplinary_record || player.disciplinary_record.length === 0) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-12">
                    <div className="text-center">
                        <Shield className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-50" />
                        <p className="text-white font-semibold mb-1">Clean Disciplinary Record</p>
                        <p className="text-slate-400 text-sm">No disciplinary incidents on record</p>
                    </div>
                </CardContent>
            </Card>
        );
    }

    const totalYellows = player.disciplinary_record.reduce((acc, r) => acc + (r.yellow_cards || 0), 0);
    const totalReds = player.disciplinary_record.reduce((acc, r) => acc + (r.red_cards || 0), 0);
    const totalSuspensions = player.disciplinary_record.reduce((acc, r) => acc + (r.suspensions || 0), 0);

    const disciplinaryScore = totalReds > 3 ? 'High Risk' : 
                              totalYellows > 20 ? 'Moderate Risk' : 
                              totalYellows > 10 ? 'Low Risk' : 'Clean';

    return (
        <div className="space-y-6">
            {/* Summary Card */}
            <Card className="bg-gradient-to-r from-amber-500/10 to-red-500/10 border-amber-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-amber-400" />
                        Disciplinary Overview
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <div className="w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-2">
                                <div className="w-4 h-6 bg-amber-400 rounded-sm" />
                            </div>
                            <p className="text-2xl font-bold text-amber-400">{totalYellows}</p>
                            <p className="text-slate-400 text-xs">Yellow Cards</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <div className="w-8 h-8 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-2">
                                <div className="w-4 h-6 bg-red-400 rounded-sm" />
                            </div>
                            <p className="text-2xl font-bold text-red-400">{totalReds}</p>
                            <p className="text-slate-400 text-xs">Red Cards</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <XCircle className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                            <p className="text-2xl font-bold text-purple-400">{totalSuspensions}</p>
                            <p className="text-slate-400 text-xs">Suspensions</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <Shield className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                            <p className={`text-lg font-bold ${
                                disciplinaryScore === 'High Risk' ? 'text-red-400' :
                                disciplinaryScore === 'Moderate Risk' ? 'text-amber-400' :
                                disciplinaryScore === 'Low Risk' ? 'text-cyan-400' :
                                'text-emerald-400'
                            }`}>
                                {disciplinaryScore}
                            </p>
                            <p className="text-slate-400 text-xs">Risk Level</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Season by Season */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Season-by-Season Record</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {player.disciplinary_record.map((record, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="bg-slate-800/50 rounded-lg p-4"
                            >
                                <div className="flex items-center justify-between mb-3">
                                    <div>
                                        <h4 className="text-white font-semibold">{record.season}</h4>
                                        <p className="text-slate-400 text-sm">{record.competition}</p>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        {record.yellow_cards > 0 && (
                                            <Badge className="bg-amber-500/20 text-amber-400">
                                                {record.yellow_cards} Yellow{record.yellow_cards !== 1 ? 's' : ''}
                                            </Badge>
                                        )}
                                        {record.red_cards > 0 && (
                                            <Badge className="bg-red-500/20 text-red-400">
                                                {record.red_cards} Red{record.red_cards !== 1 ? 's' : ''}
                                            </Badge>
                                        )}
                                        {record.suspensions > 0 && (
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                {record.suspensions} Suspension{record.suspensions !== 1 ? 's' : ''}
                                            </Badge>
                                        )}
                                    </div>
                                </div>

                                {record.notable_incidents && record.notable_incidents.length > 0 && (
                                    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mt-3">
                                        <p className="text-red-400 text-sm font-semibold mb-2">Notable Incidents:</p>
                                        <div className="space-y-2">
                                            {record.notable_incidents.map((incident, i) => (
                                                <div key={i} className="text-sm">
                                                    <div className="flex items-start justify-between mb-1">
                                                        <span className="text-slate-300">{incident.incident}</span>
                                                        <span className="text-slate-500 text-xs">{new Date(incident.date).toLocaleDateString()}</span>
                                                    </div>
                                                    <p className="text-amber-400 text-xs">Punishment: {incident.punishment}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}