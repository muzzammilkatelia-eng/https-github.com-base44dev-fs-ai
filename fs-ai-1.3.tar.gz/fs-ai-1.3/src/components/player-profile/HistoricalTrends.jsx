import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, TrendingDown, Sparkles, BarChart3 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function HistoricalTrends({ player, reports }) {
    const [analysis, setAnalysis] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const generateTrends = async () => {
        setAnalyzing(true);
        toast.loading('AI analyzing historical trends...', { id: 'trends' });

        try {
            const sortedReports = [...reports].sort((a, b) => 
                new Date(a.created_date) - new Date(b.created_date)
            );

            const prompt = `Analyze historical performance trends for ${player.name}:

PLAYER: ${player.name} (${player.age}y, ${player.position})
Current Value: €${player.market_value}M
League: ${player.league}

CAREER HISTORY:
${player.career_history?.map(h => `
${h.season}: ${h.club} (${h.league})
- Appearances: ${h.appearances || 0}
- Goals: ${h.goals || 0}
- Assists: ${h.assists || 0}
- Minutes: ${h.minutes_played || 0}
`).join('\n') || 'No career history available'}

SCOUTING REPORTS (${sortedReports.length}):
${sortedReports.map((r, i) => `
Report ${i + 1} (${new Date(r.created_date).toLocaleDateString()}):
- Overall: ${r.overall_rating}/10
- Technical: ${r.technical_rating}/10
- Physical: ${r.physical_rating}/10
- Mental: ${r.mental_rating}/10
- Recommendation: ${r.recommendation}
`).join('\n')}

INJURY HISTORY: ${player.injury_history?.length || 0} injuries
DISCIPLINARY: ${player.disciplinary_record?.reduce((acc, r) => acc + (r.yellow_cards || 0), 0)} yellows, ${player.disciplinary_record?.reduce((acc, r) => acc + (r.red_cards || 0), 0)} reds

GENERATE HISTORICAL TREND ANALYSIS:
1. Performance trajectory (improving/plateauing/declining)
2. Key turning points in career
3. Consistency analysis
4. Peak performance periods
5. Development velocity
6. Age-performance correlation
7. Injury impact on performance
8. Future trajectory prediction`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_trajectory: {
                            type: "object",
                            properties: {
                                direction: { type: "string" },
                                description: { type: "string" },
                                confidence: { type: "string" }
                            }
                        },
                        key_turning_points: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    period: { type: "string" },
                                    event: { type: "string" },
                                    impact: { type: "string" }
                                }
                            }
                        },
                        consistency_score: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                analysis: { type: "string" }
                            }
                        },
                        peak_periods: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    period: { type: "string" },
                                    performance_level: { type: "string" },
                                    stats: { type: "string" }
                                }
                            }
                        },
                        development_velocity: {
                            type: "object",
                            properties: {
                                pace: { type: "string" },
                                analysis: { type: "string" }
                            }
                        },
                        age_performance_insights: { type: "string" },
                        injury_impact_analysis: { type: "string" },
                        future_prediction: {
                            type: "object",
                            properties: {
                                trajectory: { type: "string" },
                                timeline: { type: "string" },
                                key_factors: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            }
                        },
                        strengths_over_time: {
                            type: "array",
                            items: { type: "string" }
                        },
                        weaknesses_addressed: {
                            type: "array",
                            items: { type: "string" }
                        },
                        persistent_concerns: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Historical analysis complete!', { id: 'trends' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze trends', { id: 'trends' });
        } finally {
            setAnalyzing(false);
        }
    };

    const chartData = player.career_history?.map(h => ({
        season: h.season,
        goals: h.goals || 0,
        assists: h.assists || 0,
        appearances: h.appearances || 0
    })) || [];

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-purple-400" />
                            AI Historical Performance Analysis
                        </CardTitle>
                        <Button
                            onClick={generateTrends}
                            disabled={analyzing}
                            className="bg-gradient-to-r from-purple-500 to-cyan-600"
                        >
                            {analyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Analysis
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm">
                        AI analyzes career progression, performance trends, and predicts future trajectory
                    </p>
                </CardContent>
            </Card>

            {/* Career Stats Chart */}
            {chartData.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <BarChart3 className="w-5 h-5 text-cyan-400" />
                            Career Statistics
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="season" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip 
                                    contentStyle={{ 
                                        backgroundColor: '#1e293b', 
                                        border: '1px solid #475569',
                                        borderRadius: '8px'
                                    }} 
                                />
                                <Legend />
                                <Line type="monotone" dataKey="goals" stroke="#10b981" strokeWidth={2} name="Goals" />
                                <Line type="monotone" dataKey="assists" stroke="#06b6d4" strokeWidth={2} name="Assists" />
                                <Line type="monotone" dataKey="appearances" stroke="#8b5cf6" strokeWidth={2} name="Appearances" />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            )}

            {analysis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Overall Trajectory */}
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Overall Trajectory</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-3 mb-3">
                                {analysis.overall_trajectory?.direction?.toLowerCase().includes('improving') || 
                                 analysis.overall_trajectory?.direction?.toLowerCase().includes('upward') ? (
                                    <TrendingUp className="w-8 h-8 text-emerald-400" />
                                ) : (
                                    <TrendingDown className="w-8 h-8 text-amber-400" />
                                )}
                                <div>
                                    <h3 className="text-white text-2xl font-bold">{analysis.overall_trajectory?.direction}</h3>
                                    <Badge className="bg-cyan-500/20 text-cyan-400 mt-1">
                                        {analysis.overall_trajectory?.confidence} Confidence
                                    </Badge>
                                </div>
                            </div>
                            <p className="text-slate-300">{analysis.overall_trajectory?.description}</p>
                        </CardContent>
                    </Card>

                    {/* Key Turning Points */}
                    {analysis.key_turning_points && analysis.key_turning_points.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Career Turning Points</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analysis.key_turning_points.map((point, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-purple-500">
                                            <div className="flex items-start justify-between mb-2">
                                                <Badge className="bg-purple-500/20 text-purple-400">{point.period}</Badge>
                                                <Badge className={
                                                    point.impact?.toLowerCase().includes('positive') ? 'bg-emerald-500/20 text-emerald-400' :
                                                    point.impact?.toLowerCase().includes('negative') ? 'bg-red-500/20 text-red-400' :
                                                    'bg-amber-500/20 text-amber-400'
                                                }>
                                                    {point.impact}
                                                </Badge>
                                            </div>
                                            <p className="text-white font-semibold mb-1">{point.event}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <div className="grid md:grid-cols-2 gap-6">
                        {/* Consistency */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Consistency Score</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-center mb-4">
                                    <p className={`text-5xl font-bold ${
                                        analysis.consistency_score?.rating >= 8 ? 'text-emerald-400' :
                                        analysis.consistency_score?.rating >= 6 ? 'text-cyan-400' :
                                        'text-amber-400'
                                    }`}>
                                        {analysis.consistency_score?.rating}/10
                                    </p>
                                </div>
                                <p className="text-slate-300 text-sm">{analysis.consistency_score?.analysis}</p>
                            </CardContent>
                        </Card>

                        {/* Development Velocity */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Development Velocity</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Badge className={`mb-3 ${
                                    analysis.development_velocity?.pace?.toLowerCase().includes('rapid') ? 'bg-emerald-500/20 text-emerald-400' :
                                    analysis.development_velocity?.pace?.toLowerCase().includes('steady') ? 'bg-cyan-500/20 text-cyan-400' :
                                    'bg-amber-500/20 text-amber-400'
                                }`}>
                                    {analysis.development_velocity?.pace}
                                </Badge>
                                <p className="text-slate-300 text-sm">{analysis.development_velocity?.analysis}</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Peak Periods */}
                    {analysis.peak_periods && analysis.peak_periods.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Peak Performance Periods</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-4">
                                    {analysis.peak_periods.map((peak, idx) => (
                                        <div key={idx} className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                            <h4 className="text-amber-400 font-semibold mb-1">{peak.period}</h4>
                                            <p className="text-white text-sm font-medium mb-2">{peak.performance_level}</p>
                                            <p className="text-slate-300 text-sm">{peak.stats}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Insights */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Age-Performance Insights</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.age_performance_insights}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Injury Impact</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{analysis.injury_impact_analysis}</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Future Prediction */}
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Future Trajectory Prediction</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="mb-4">
                                <Badge className="bg-cyan-500/20 text-cyan-400 mb-2">{analysis.future_prediction?.trajectory}</Badge>
                                <p className="text-slate-300 text-sm">{analysis.future_prediction?.timeline}</p>
                            </div>
                            {analysis.future_prediction?.key_factors && (
                                <div>
                                    <p className="text-slate-400 text-sm font-semibold mb-2">Key Factors:</p>
                                    <ul className="space-y-1">
                                        {analysis.future_prediction.key_factors.map((factor, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                {factor}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Strengths & Weaknesses */}
                    <div className="grid md:grid-cols-3 gap-6">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 text-sm">Strengths Over Time</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.strengths_over_time?.map((strength, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-emerald-400">+</span>
                                            {strength}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-cyan-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-cyan-400 text-sm">Weaknesses Addressed</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.weaknesses_addressed?.map((weakness, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-cyan-400">✓</span>
                                            {weakness}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400 text-sm">Persistent Concerns</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-1">
                                    {analysis.persistent_concerns?.map((concern, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                            <span className="text-amber-400">!</span>
                                            {concern}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>
                </motion.div>
            )}

            {!analysis && !analyzing && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <TrendingUp className="w-16 h-16 text-purple-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Historical Trend Analysis</h3>
                            <p className="text-slate-400 mb-6">
                                Generate AI-powered insights on career trajectory and performance evolution
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}