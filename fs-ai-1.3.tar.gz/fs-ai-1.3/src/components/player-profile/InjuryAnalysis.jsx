import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, TrendingUp, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function InjuryAnalysis({ player }) {
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const analyzeInjuries = async () => {
        setIsAnalyzing(true);
        toast.loading('AI analyzing injury patterns...', { id: 'injury-analysis' });

        try {
            const prompt = `Analyze injury history and patterns for this player:

PLAYER: ${player.name} (${player.age}y, ${player.position})
INJURY PRONE SCORE: ${player.injury_prone_score || 0}/100

INJURY HISTORY:
${player.injury_history?.length > 0 ? player.injury_history.map((inj, i) => `
${i + 1}. ${inj.injury_type} - ${inj.date}
   Severity: ${inj.severity}
   Recovery: ${inj.recovery_time}
   Notes: ${inj.notes || 'None'}
`).join('\n') : 'No recorded injuries'}

PHYSICAL ATTRIBUTES:
${JSON.stringify(player.physical_attributes)}

PLAYING STYLE:
${JSON.stringify(player.playing_style)}

ANALYZE:
1. Identify recurring injury patterns
2. Biomechanical risk factors
3. Play-style related injury risks
4. Recovery trends
5. Age-related concerns
6. Prevention recommendations
7. Career longevity projection
8. Training modifications needed`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        risk_level: { type: "string" },
                        risk_score: { type: "number" },
                        patterns_identified: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    pattern: { type: "string" },
                                    frequency: { type: "string" },
                                    severity: { type: "string" },
                                    analysis: { type: "string" }
                                }
                            }
                        },
                        injury_breakdown: {
                            type: "object",
                            properties: {
                                muscular: { type: "number" },
                                ligament: { type: "number" },
                                bone: { type: "number" },
                                other: { type: "number" }
                            }
                        },
                        biomechanical_factors: { type: "array", items: { type: "string" } },
                        play_style_risks: { type: "array", items: { type: "string" } },
                        recovery_analysis: { type: "string" },
                        age_concerns: { type: "string" },
                        prevention_plan: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    recommendation: { type: "string" },
                                    priority: { type: "string" }
                                }
                            }
                        },
                        career_longevity: {
                            type: "object",
                            properties: {
                                projection: { type: "string" },
                                risk_factors: { type: "array", items: { type: "string" } },
                                protective_factors: { type: "array", items: { type: "string" } }
                            }
                        },
                        monitoring_recommendations: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Analysis complete!', { id: 'injury-analysis' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze injuries', { id: 'injury-analysis' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getRiskColor = (risk) => {
        if (risk?.toLowerCase().includes('high')) return 'bg-red-500/20 text-red-400 border-red-500/30';
        if (risk?.toLowerCase().includes('medium')) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    };

    const chartData = analysis?.injury_breakdown ? [
        { type: 'Muscular', count: analysis.injury_breakdown.muscular },
        { type: 'Ligament', count: analysis.injury_breakdown.ligament },
        { type: 'Bone', count: analysis.injury_breakdown.bone },
        { type: 'Other', count: analysis.injury_breakdown.other }
    ] : [];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-amber-400" />
                            AI Injury Pattern Analysis
                        </CardTitle>
                        {!analysis && (
                            <Button
                                onClick={analyzeInjuries}
                                disabled={isAnalyzing}
                                className="bg-gradient-to-r from-amber-500 to-orange-600"
                            >
                                {isAnalyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Analyze Patterns
                                    </>
                                )}
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent>
                    {!analysis && !isAnalyzing && (
                        <div className="text-center py-8">
                            <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto mb-3 opacity-50" />
                            <p className="text-slate-400">
                                Get AI insights on injury patterns and prevention strategies
                            </p>
                        </div>
                    )}

                    {analysis && (
                        <div className="space-y-6">
                            {/* Risk Overview */}
                            <div className="bg-gradient-to-r from-amber-500/10 to-red-500/10 border border-amber-500/30 rounded-lg p-4">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-slate-300">Overall Risk Level</span>
                                    <Badge className={getRiskColor(analysis.risk_level)}>
                                        {analysis.risk_level}
                                    </Badge>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="flex-1 bg-slate-800 rounded-full h-2">
                                        <div 
                                            className={`h-2 rounded-full ${
                                                analysis.risk_score > 70 ? 'bg-red-500' :
                                                analysis.risk_score > 40 ? 'bg-amber-500' :
                                                'bg-emerald-500'
                                            }`}
                                            style={{ width: `${analysis.risk_score}%` }}
                                        />
                                    </div>
                                    <span className="text-white font-bold">{analysis.risk_score}/100</span>
                                </div>
                            </div>

                            {/* Injury Breakdown Chart */}
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm">Injury Type Distribution</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ResponsiveContainer width="100%" height={200}>
                                        <BarChart data={chartData}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                            <XAxis dataKey="type" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                                            <YAxis stroke="#94a3b8" />
                                            <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                                            <Bar dataKey="count" fill="#f59e0b" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>

                            {/* Patterns Identified */}
                            <div>
                                <h4 className="text-white font-semibold mb-3">Recurring Patterns</h4>
                                <div className="space-y-3">
                                    {analysis.patterns_identified?.map((pattern, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <h5 className="text-white font-medium">{pattern.pattern}</h5>
                                                <Badge className={getRiskColor(pattern.severity)}>
                                                    {pattern.severity}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm mb-1">Frequency: {pattern.frequency}</p>
                                            <p className="text-slate-300 text-sm">{pattern.analysis}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Risk Factors */}
                            <div className="grid md:grid-cols-2 gap-4">
                                <Card className="bg-red-500/10 border-red-500/30">
                                    <CardContent className="pt-4">
                                        <h5 className="text-red-400 font-semibold mb-2 text-sm">Biomechanical Risks</h5>
                                        <ul className="space-y-1">
                                            {analysis.biomechanical_factors?.map((factor, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-red-400">•</span>
                                                    {factor}
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>

                                <Card className="bg-amber-500/10 border-amber-500/30">
                                    <CardContent className="pt-4">
                                        <h5 className="text-amber-400 font-semibold mb-2 text-sm">Play-Style Risks</h5>
                                        <ul className="space-y-1">
                                            {analysis.play_style_risks?.map((risk, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400">•</span>
                                                    {risk}
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Prevention Plan */}
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-emerald-400 text-sm">Prevention Plan</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {analysis.prevention_plan?.map((plan, idx) => (
                                            <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-center justify-between mb-1">
                                                    <span className="text-white font-medium text-sm">{plan.area}</span>
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        {plan.priority}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-300 text-sm">{plan.recommendation}</p>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Career Longevity */}
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4 text-cyan-400" />
                                        Career Longevity Projection
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <p className="text-white font-medium">{analysis.career_longevity?.projection}</p>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <p className="text-slate-400 text-xs mb-2">Risk Factors:</p>
                                            <ul className="space-y-1">
                                                {analysis.career_longevity?.risk_factors?.map((factor, i) => (
                                                    <li key={i} className="text-slate-300 text-xs flex items-start gap-2">
                                                        <span className="text-red-400">⚠</span>
                                                        {factor}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs mb-2">Protective Factors:</p>
                                            <ul className="space-y-1">
                                                {analysis.career_longevity?.protective_factors?.map((factor, i) => (
                                                    <li key={i} className="text-slate-300 text-xs flex items-start gap-2">
                                                        <span className="text-emerald-400">✓</span>
                                                        {factor}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Button
                                onClick={analyzeInjuries}
                                variant="outline"
                                className="w-full border-slate-700"
                                size="sm"
                            >
                                Refresh Analysis
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}