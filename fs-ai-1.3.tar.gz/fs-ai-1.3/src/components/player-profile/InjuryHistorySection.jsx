import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertCircle, Plus, Calendar } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function InjuryHistorySection({ player }) {
    const [showAddDialog, setShowAddDialog] = useState(false);
    const [newInjury, setNewInjury] = useState({
        injury_type: '',
        date: '',
        severity: 'Moderate',
        recovery_time: '',
        notes: ''
    });

    const queryClient = useQueryClient();

    const addInjuryMutation = useMutation({
        mutationFn: async (injury) => {
            const updatedHistory = [...(player.injury_history || []), injury];
            return base44.entities.Player.update(player.id, { injury_history: updatedHistory });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['player', player.id] });
            toast.success('Injury record added');
            setShowAddDialog(false);
            setNewInjury({ injury_type: '', date: '', severity: 'Moderate', recovery_time: '', notes: '' });
        }
    });

    const injuryHistory = player.injury_history || [];
    const sortedInjuries = [...injuryHistory].sort((a, b) => new Date(b.date) - new Date(a.date));

    const severityColors = {
        Minor: 'bg-green-500/20 text-green-400 border-green-500/30',
        Moderate: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        Serious: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
        Severe: 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertCircle className="w-5 h-5 text-amber-400" />
                            Injury History ({injuryHistory.length} records)
                        </CardTitle>
                        <Button onClick={() => setShowAddDialog(true)} className="bg-cyan-600 hover:bg-cyan-700">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Injury
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    {player.injury_prone_score && (
                        <div className="mb-6 p-4 bg-slate-800/50 rounded-lg">
                            <div className="flex items-center justify-between">
                                <span className="text-slate-300">Overall Injury Risk Score</span>
                                <Badge className={
                                    player.injury_prone_score < 30 ? 'bg-green-500/20 text-green-400' :
                                    player.injury_prone_score < 60 ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-red-500/20 text-red-400'
                                }>
                                    {player.injury_prone_score}/100 - {
                                        player.injury_prone_score < 30 ? 'Low Risk' :
                                        player.injury_prone_score < 60 ? 'Medium Risk' : 'High Risk'
                                    }
                                </Badge>
                            </div>
                        </div>
                    )}

                    {sortedInjuries.length === 0 ? (
                        <div className="text-center py-12">
                            <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">No injury history recorded</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {sortedInjuries.map((injury, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                                        <div>
                                            <h4 className="text-white font-semibold">{injury.injury_type}</h4>
                                            <p className="text-slate-400 text-sm flex items-center gap-2 mt-1">
                                                <Calendar className="w-4 h-4" />
                                                {new Date(injury.date).toLocaleDateString()}
                                            </p>
                                        </div>
                                        <div className="flex gap-2">
                                            <Badge className={severityColors[injury.severity]}>
                                                {injury.severity}
                                            </Badge>
                                            {injury.recovery_time && (
                                                <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                    {injury.recovery_time}
                                                </Badge>
                                            )}
                                        </div>
                                    </div>
                                    {injury.notes && (
                                        <p className="text-slate-300 text-sm mt-2 pl-4 border-l-2 border-slate-700">
                                            {injury.notes}
                                        </p>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white">
                    <DialogHeader>
                        <DialogTitle>Add Injury Record</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label>Injury Type *</Label>
                            <Input
                                value={newInjury.injury_type}
                                onChange={(e) => setNewInjury({...newInjury, injury_type: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="e.g., Hamstring strain"
                            />
                        </div>
                        <div>
                            <Label>Date *</Label>
                            <Input
                                type="date"
                                value={newInjury.date}
                                onChange={(e) => setNewInjury({...newInjury, date: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Severity</Label>
                            <Select value={newInjury.severity} onValueChange={(v) => setNewInjury({...newInjury, severity: v})}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Minor">Minor</SelectItem>
                                    <SelectItem value="Moderate">Moderate</SelectItem>
                                    <SelectItem value="Serious">Serious</SelectItem>
                                    <SelectItem value="Severe">Severe</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Recovery Time</Label>
                            <Input
                                value={newInjury.recovery_time}
                                onChange={(e) => setNewInjury({...newInjury, recovery_time: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="e.g., 3-4 weeks"
                            />
                        </div>
                        <div>
                            <Label>Notes</Label>
                            <Input
                                value={newInjury.notes}
                                onChange={(e) => setNewInjury({...newInjury, notes: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="Additional details..."
                            />
                        </div>
                        <div className="flex justify-end gap-2">
                            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
                            <Button
                                onClick={() => addInjuryMutation.mutate(newInjury)}
                                disabled={!newInjury.injury_type || !newInjury.date}
                                className="bg-cyan-600 hover:bg-cyan-700"
                            >
                                Add Record
                            </Button>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}