import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import { AlertCircle, Calendar, Clock } from 'lucide-react';

export default function InjuryHistoryTimeline({ player }) {
    const [severityFilter, setSeverityFilter] = useState('all');
    
    const injuries = player.injury_history || [];
    
    const filteredInjuries = injuries.filter(injury => 
        severityFilter === 'all' || injury.severity === severityFilter
    );

    const sortedInjuries = [...filteredInjuries].sort((a, b) => 
        new Date(b.date) - new Date(a.date)
    );

    const severityColors = {
        Minor: 'bg-green-500/20 text-green-400 border-green-500/30',
        Moderate: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        Serious: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
        Severe: 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    const injuryStats = {
        total: injuries.length,
        avgRecovery: injuries.length > 0 
            ? Math.round(injuries.reduce((sum, i) => sum + (parseInt(i.recovery_time) || 0), 0) / injuries.length)
            : 0,
        mostCommon: injuries.length > 0
            ? injuries.reduce((acc, i) => {
                acc[i.injury_type] = (acc[i.injury_type] || 0) + 1;
                return acc;
            }, {})
            : {}
    };

    const mostCommonType = Object.entries(injuryStats.mostCommon).sort((a, b) => b[1] - a[1])[0];

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-cyan-500/20 rounded-lg">
                                <AlertCircle className="w-6 h-6 text-cyan-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">{injuryStats.total}</p>
                                <p className="text-slate-400 text-sm">Total Injuries</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-purple-500/20 rounded-lg">
                                <Clock className="w-6 h-6 text-purple-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">{injuryStats.avgRecovery}</p>
                                <p className="text-slate-400 text-sm">Avg Recovery (days)</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-amber-500/20 rounded-lg">
                                <AlertCircle className="w-6 h-6 text-amber-400" />
                            </div>
                            <div>
                                <p className="text-lg font-bold text-white">{mostCommonType ? mostCommonType[0] : 'N/A'}</p>
                                <p className="text-slate-400 text-sm">Most Common</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white">Injury Timeline</CardTitle>
                        <Select value={severityFilter} onValueChange={setSeverityFilter}>
                            <SelectTrigger className="w-[180px] bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Severities</SelectItem>
                                <SelectItem value="Minor">Minor</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Serious">Serious</SelectItem>
                                <SelectItem value="Severe">Severe</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardHeader>
                <CardContent>
                    {sortedInjuries.length === 0 ? (
                        <div className="text-center py-12">
                            <p className="text-slate-400">No injury records found</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {sortedInjuries.map((injury, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: i * 0.05 }}
                                    className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-cyan-500"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h4 className="text-white font-semibold text-lg">{injury.injury_type}</h4>
                                            <div className="flex items-center gap-2 mt-1">
                                                <Calendar className="w-4 h-4 text-slate-400" />
                                                <span className="text-slate-300 text-sm">
                                                    {new Date(injury.date).toLocaleDateString()}
                                                </span>
                                            </div>
                                        </div>
                                        <Badge className={severityColors[injury.severity]}>
                                            {injury.severity}
                                        </Badge>
                                    </div>
                                    <div className="grid md:grid-cols-2 gap-4 mt-3">
                                        <div>
                                            <span className="text-slate-400 text-sm">Recovery Time:</span>
                                            <span className="text-white ml-2">{injury.recovery_time}</span>
                                        </div>
                                        {injury.notes && (
                                            <div className="md:col-span-2">
                                                <p className="text-slate-300 text-sm">{injury.notes}</p>
                                            </div>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}