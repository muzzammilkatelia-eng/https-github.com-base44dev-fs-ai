import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Newspaper, ExternalLink, Sparkles, Loader2, TrendingUp } from 'lucide-react';
import toast from 'react-hot-toast';

export default function MediaMentions({ player }) {
    const [mentions, setMentions] = useState(null);

    const fetchMentionsMutation = useMutation({
        mutationFn: async () => {
            const prompt = `Search for recent media mentions and news about football player ${player.name} (${player.position}, ${player.current_club}).

Find:
1. Recent transfer news and rumors
2. Performance highlights and match reports
3. Contract negotiations or updates
4. Injury news or recovery updates
5. Social media buzz and trending topics

Return structured JSON with:
- headline (string)
- source (string)
- date (string)
- sentiment (Positive/Neutral/Negative)
- category (Transfer/Performance/Contract/Injury/General)
- summary (string, max 2 sentences)
- importance (High/Medium/Low)

Provide 8-10 most relevant recent mentions.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        mentions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    headline: { type: "string" },
                                    source: { type: "string" },
                                    date: { type: "string" },
                                    sentiment: { type: "string" },
                                    category: { type: "string" },
                                    summary: { type: "string" },
                                    importance: { type: "string" }
                                }
                            }
                        },
                        overall_media_sentiment: { type: "string" },
                        trending_topics: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            return response;
        },
        onSuccess: (data) => {
            setMentions(data);
            toast.success('Media mentions fetched!');
        },
        onError: () => {
            toast.error('Failed to fetch media mentions');
        }
    });

    const getCategoryColor = (category) => {
        switch (category) {
            case 'Transfer': return 'bg-purple-500/20 text-purple-400';
            case 'Performance': return 'bg-cyan-500/20 text-cyan-400';
            case 'Contract': return 'bg-amber-500/20 text-amber-400';
            case 'Injury': return 'bg-red-500/20 text-red-400';
            default: return 'bg-slate-500/20 text-slate-400';
        }
    };

    const getSentimentColor = (sentiment) => {
        if (sentiment?.includes('Positive')) return 'text-emerald-400';
        if (sentiment?.includes('Negative')) return 'text-red-400';
        return 'text-slate-400';
    };

    return (
        <div className="space-y-6">
            {!mentions ? (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-24 text-center">
                        <Newspaper className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                        <h3 className="text-white text-xl font-semibold mb-2">Media & News Mentions</h3>
                        <p className="text-slate-400 mb-6">
                            Fetch recent news, transfer rumors, and media coverage about {player.name}
                        </p>
                        <Button
                            onClick={() => fetchMentionsMutation.mutate()}
                            disabled={fetchMentionsMutation.isPending}
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                            {fetchMentionsMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Searching...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Fetch Media Mentions
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <>
                    {/* Overview */}
                    <div className="grid md:grid-cols-2 gap-4">
                        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-slate-400 text-sm">Overall Sentiment</p>
                                        <p className={`text-2xl font-bold ${getSentimentColor(mentions.overall_media_sentiment)}`}>
                                            {mentions.overall_media_sentiment}
                                        </p>
                                    </div>
                                    <TrendingUp className="w-10 h-10 text-purple-400" />
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardContent className="pt-6">
                                <p className="text-slate-400 text-sm mb-2">Trending Topics</p>
                                <div className="flex flex-wrap gap-2">
                                    {mentions.trending_topics?.map((topic, idx) => (
                                        <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                            {topic}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Mentions List */}
                    <div className="space-y-3">
                        {mentions.mentions?.map((mention, idx) => (
                            <Card key={idx} className="bg-slate-900/50 border-slate-800 hover:border-purple-500/50 transition-all">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-2">
                                                <Badge className={getCategoryColor(mention.category)}>
                                                    {mention.category}
                                                </Badge>
                                                {mention.importance === 'High' && (
                                                    <Badge className="bg-red-500/20 text-red-400">
                                                        High Priority
                                                    </Badge>
                                                )}
                                            </div>
                                            <h4 className="text-white font-semibold text-lg mb-2">{mention.headline}</h4>
                                            <p className="text-slate-300 text-sm leading-relaxed mb-3">{mention.summary}</p>
                                            <div className="flex items-center gap-4 text-xs text-slate-500">
                                                <span>{mention.source}</span>
                                                <span>•</span>
                                                <span>{mention.date}</span>
                                                <span>•</span>
                                                <span className={getSentimentColor(mention.sentiment)}>{mention.sentiment}</span>
                                            </div>
                                        </div>
                                        <ExternalLink className="w-5 h-5 text-slate-500 ml-4 flex-shrink-0" />
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <Button
                        onClick={() => fetchMentionsMutation.mutate()}
                        variant="outline"
                        className="w-full border-slate-700"
                        disabled={fetchMentionsMutation.isPending}
                    >
                        {fetchMentionsMutation.isPending ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Refreshing...
                            </>
                        ) : (
                            'Refresh Media Mentions'
                        )}
                    </Button>
                </>
            )}
        </div>
    );
}