import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { TrendingUp, Activity, BarChart3 } from 'lucide-react';

export default function PerformanceCharts({ player, reports }) {
    // Generate performance timeline data
    const timelineData = [
        { season: '2021/22', rating: 76, goals: 8, assists: 5, appearances: 32 },
        { season: '2022/23', rating: 79, goals: 12, assists: 7, appearances: 35 },
        { season: '2023/24', rating: 82, goals: 15, assists: 10, appearances: 38 },
        { season: '2024/25', rating: 85, goals: 10, assists: 8, appearances: 20 }
    ];

    // Market value progression
    const marketValueData = [
        { date: 'Jan 23', value: 15 },
        { date: 'Apr 23', value: 18 },
        { date: 'Jul 23', value: 22 },
        { date: 'Oct 23', value: 25 },
        { date: 'Jan 24', value: 28 },
        { date: 'Apr 24', value: 32 },
        { date: 'Jul 24', value: player.market_value || 35 }
    ];

    // Performance metrics radar
    const metricsData = [
        { metric: 'Technical', value: 85 },
        { metric: 'Physical', value: 78 },
        { metric: 'Mental', value: 82 },
        { metric: 'Tactical', value: 80 },
        { metric: 'Leadership', value: 75 }
    ];

    // Goals & Assists by competition
    const competitionData = [
        { competition: 'League', goals: 18, assists: 12 },
        { competition: 'Cup', goals: 5, assists: 3 },
        { competition: 'Europe', goals: 8, assists: 6 },
        { competition: 'Int.', goals: 4, assists: 2 }
    ];

    return (
        <div className="space-y-6">
            {/* Performance Timeline */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        Career Performance Progression
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={timelineData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="season" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                labelStyle={{ color: '#e2e8f0' }}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="rating" stroke="#06b6d4" strokeWidth={2} name="Overall Rating" />
                            <Line type="monotone" dataKey="goals" stroke="#10b981" strokeWidth={2} name="Goals" />
                            <Line type="monotone" dataKey="assists" stroke="#8b5cf6" strokeWidth={2} name="Assists" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid lg:grid-cols-2 gap-6">
                {/* Market Value Growth */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Activity className="w-5 h-5 text-emerald-400" />
                            Market Value Trajectory
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <AreaChart data={marketValueData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="date" stroke="#94a3b8" />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    formatter={(value) => `€${value}M`}
                                />
                                <Area type="monotone" dataKey="value" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                            </AreaChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* Performance Radar */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <BarChart3 className="w-5 h-5 text-purple-400" />
                            Performance Profile
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <RadarChart data={metricsData}>
                                <PolarGrid stroke="#334155" />
                                <PolarAngleAxis dataKey="metric" stroke="#94a3b8" />
                                <PolarRadiusAxis stroke="#94a3b8" domain={[0, 100]} />
                                <Radar dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
                            </RadarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            {/* Goals & Assists by Competition */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Goals & Assists by Competition</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={competitionData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="competition" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                            />
                            <Legend />
                            <Bar dataKey="goals" fill="#10b981" name="Goals" />
                            <Bar dataKey="assists" fill="#06b6d4" name="Assists" />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
    );
}