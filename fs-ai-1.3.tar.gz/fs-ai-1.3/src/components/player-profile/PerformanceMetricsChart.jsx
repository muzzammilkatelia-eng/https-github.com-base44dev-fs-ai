import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

export default function PerformanceMetricsChart({ player }) {
    const [metricView, setMetricView] = useState('goals');

    const careerHistory = player.career_history || [];
    
    const performanceData = careerHistory.map(season => ({
        season: season.season,
        goals: season.goals || 0,
        assists: season.assists || 0,
        appearances: season.appearances || 0,
        minutes: season.minutes_played || 0,
        goalsPerApp: season.appearances ? (season.goals / season.appearances).toFixed(2) : 0,
        assistsPerApp: season.appearances ? (season.assists / season.appearances).toFixed(2) : 0
    }));

    const chartConfig = {
        goals: {
            dataKey: 'goals',
            name: 'Goals',
            color: '#06b6d4'
        },
        assists: {
            dataKey: 'assists',
            name: 'Assists',
            color: '#8b5cf6'
        },
        appearances: {
            dataKey: 'appearances',
            name: 'Appearances',
            color: '#10b981'
        },
        goalsPerApp: {
            dataKey: 'goalsPerApp',
            name: 'Goals/Appearance',
            color: '#f59e0b'
        }
    };

    const currentConfig = chartConfig[metricView];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white">Performance Over Time</CardTitle>
                        <Select value={metricView} onValueChange={setMetricView}>
                            <SelectTrigger className="w-[200px] bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="goals">Goals</SelectItem>
                                <SelectItem value="assists">Assists</SelectItem>
                                <SelectItem value="appearances">Appearances</SelectItem>
                                <SelectItem value="goalsPerApp">Goals per Appearance</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardHeader>
                <CardContent>
                    {performanceData.length === 0 ? (
                        <div className="text-center py-12">
                            <p className="text-slate-400">No performance data available</p>
                        </div>
                    ) : (
                        <ResponsiveContainer width="100%" height={400}>
                            <AreaChart data={performanceData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                                <XAxis dataKey="season" tick={{ fill: '#94a3b8' }} />
                                <YAxis tick={{ fill: '#94a3b8' }} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                                    labelStyle={{ color: '#fff' }}
                                />
                                <Legend />
                                <Area 
                                    type="monotone" 
                                    dataKey={currentConfig.dataKey} 
                                    stroke={currentConfig.color} 
                                    fill={currentConfig.color}
                                    fillOpacity={0.3}
                                    name={currentConfig.name}
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Season-by-Season Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                    {careerHistory.length === 0 ? (
                        <div className="text-center py-12">
                            <p className="text-slate-400">No career history available</p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {careerHistory.map((season, i) => (
                                <div key={i} className="bg-slate-800/50 rounded-lg p-4">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h4 className="text-white font-semibold">{season.season}</h4>
                                            <p className="text-slate-400 text-sm">{season.club} - {season.league}</p>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
                                        <div>
                                            <p className="text-slate-400 text-xs">Appearances</p>
                                            <p className="text-white font-semibold">{season.appearances || 0}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs">Goals</p>
                                            <p className="text-cyan-400 font-semibold">{season.goals || 0}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs">Assists</p>
                                            <p className="text-purple-400 font-semibold">{season.assists || 0}</p>
                                        </div>
                                        <div>
                                            <p className="text-slate-400 text-xs">Minutes</p>
                                            <p className="text-emerald-400 font-semibold">{season.minutes_played || 0}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}