import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Calendar } from 'lucide-react';

export default function PerformanceTimelineSection({ player }) {
    const [viewMode, setViewMode] = useState('season');

    const careerHistory = player.career_history || [];
    const sortedHistory = [...careerHistory].sort((a, b) => a.season.localeCompare(b.season));

    // Calculate per-90 stats
    const performanceData = sortedHistory.map(season => ({
        season: season.season,
        goals: season.goals || 0,
        assists: season.assists || 0,
        appearances: season.appearances || 0,
        goals_per_90: season.minutes_played ? ((season.goals || 0) / (season.minutes_played / 90)).toFixed(2) : 0,
        assists_per_90: season.minutes_played ? ((season.assists || 0) / (season.minutes_played / 90)).toFixed(2) : 0,
        minutes: season.minutes_played || 0
    }));

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-cyan-400" />
                            Performance Timeline
                        </CardTitle>
                        <Select value={viewMode} onValueChange={setViewMode}>
                            <SelectTrigger className="w-40 bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="season">By Season</SelectItem>
                                <SelectItem value="per90">Per 90 Minutes</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardHeader>
                <CardContent>
                    {performanceData.length === 0 ? (
                        <div className="text-center py-12">
                            <Calendar className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">No performance history available</p>
                        </div>
                    ) : (
                        <ResponsiveContainer width="100%" height={400}>
                            <LineChart data={performanceData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="season" stroke="#94a3b8" />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    labelStyle={{ color: '#e2e8f0' }}
                                />
                                <Legend />
                                {viewMode === 'season' ? (
                                    <>
                                        <Line type="monotone" dataKey="goals" stroke="#06b6d4" strokeWidth={2} name="Goals" />
                                        <Line type="monotone" dataKey="assists" stroke="#8b5cf6" strokeWidth={2} name="Assists" />
                                        <Line type="monotone" dataKey="appearances" stroke="#10b981" strokeWidth={2} name="Appearances" />
                                    </>
                                ) : (
                                    <>
                                        <Line type="monotone" dataKey="goals_per_90" stroke="#06b6d4" strokeWidth={2} name="Goals/90" />
                                        <Line type="monotone" dataKey="assists_per_90" stroke="#8b5cf6" strokeWidth={2} name="Assists/90" />
                                    </>
                                )}
                            </LineChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>

            {/* Career Stats Table */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Season-by-Season Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                    {sortedHistory.length === 0 ? (
                        <p className="text-slate-400 text-center py-8">No career data available</p>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="border-b border-slate-700">
                                    <tr>
                                        <th className="text-slate-300 p-3">Season</th>
                                        <th className="text-slate-300 p-3">Club</th>
                                        <th className="text-slate-300 p-3">League</th>
                                        <th className="text-slate-300 p-3 text-center">Apps</th>
                                        <th className="text-slate-300 p-3 text-center">Goals</th>
                                        <th className="text-slate-300 p-3 text-center">Assists</th>
                                        <th className="text-slate-300 p-3 text-center">Minutes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sortedHistory.map((season, index) => (
                                        <tr key={index} className="border-b border-slate-800 hover:bg-slate-800/50">
                                            <td className="text-white p-3 font-semibold">{season.season}</td>
                                            <td className="text-slate-300 p-3">{season.club}</td>
                                            <td className="text-slate-400 p-3">{season.league}</td>
                                            <td className="text-white p-3 text-center">{season.appearances || 0}</td>
                                            <td className="text-cyan-400 p-3 text-center font-semibold">{season.goals || 0}</td>
                                            <td className="text-purple-400 p-3 text-center font-semibold">{season.assists || 0}</td>
                                            <td className="text-slate-300 p-3 text-center">{season.minutes_played || 0}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}