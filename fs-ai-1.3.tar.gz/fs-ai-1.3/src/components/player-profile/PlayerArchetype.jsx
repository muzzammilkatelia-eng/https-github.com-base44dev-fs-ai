import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, Target, Users, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function PlayerArchetype({ player, reports, projection }) {
    const [archetype, setArchetype] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const generateArchetype = async () => {
        setIsGenerating(true);
        toast.loading('AI analyzing player archetype...', { id: 'archetype' });

        try {
            const latestReport = reports?.[0];
            
            const prompt = `You are an elite football scout AI. Analyze this player's complete profile and generate a detailed Player Archetype classification.

PLAYER: ${player.name}
Position: ${player.position}
Age: ${player.age}
${player.secondary_positions ? `Secondary Positions: ${player.secondary_positions.join(', ')}` : ''}

PHYSICAL PROFILE:
${player.physical_attributes ? JSON.stringify(player.physical_attributes, null, 2) : 'Not available'}

PLAYING STYLE:
${player.playing_style ? JSON.stringify(player.playing_style, null, 2) : 'Not available'}

${player.preferred_formations ? `Preferred Formations: ${player.preferred_formations.join(', ')}` : ''}
${player.tactical_roles ? `Tactical Roles: ${player.tactical_roles.join(', ')}` : ''}

LATEST SCOUTING REPORT:
${latestReport ? `
- Overall Rating: ${latestReport.overall_rating}/10
- Technical: ${latestReport.technical_rating}/10
- Physical: ${latestReport.physical_rating}/10
- Mental: ${latestReport.mental_rating}/10
- Tactical: ${latestReport.tactical_rating}/10
- Strengths: ${latestReport.strengths}
- Weaknesses: ${latestReport.weaknesses}
- Recommendation: ${latestReport.recommendation}
` : 'No scouting data available'}

PROJECTION:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Rating: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
- Development Focus: ${projection.development_priorities?.map(d => d.area).join(', ')}
` : 'No projection data available'}

Based on this comprehensive analysis, determine:

1. **Primary Archetype**: What is the player's core playing identity? (e.g., "Elite Ball-Carrying Midfielder", "Clinical Box Predator", "Modern Sweeper-Keeper")

2. **Archetype Description**: 2-3 sentences explaining what defines this archetype and how the player embodies it.

3. **Similar Players**: 3-4 real-world players (past or present) who share this archetype.

4. **Key Attributes**: The 5 most critical attributes that define this archetype for this player.

5. **Ideal System**: What tactical system/formation best suits this archetype?

6. **Team Role**: How should this player be utilized? (e.g., "Primary creative outlet", "Goal-scoring focal point")

7. **Market Niche**: What makes this archetype valuable in the current transfer market?

8. **Development Path**: How should this archetype be developed to maximize potential?

Provide detailed, specific insights based on the actual data provided.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        primary_archetype: { type: "string" },
                        archetype_description: { type: "string" },
                        similar_players: {
                            type: "array",
                            items: { type: "string" }
                        },
                        key_attributes: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    attribute: { type: "string" },
                                    importance: { type: "string" },
                                    current_level: { type: "string" }
                                }
                            }
                        },
                        ideal_system: { type: "string" },
                        team_role: { type: "string" },
                        market_niche: { type: "string" },
                        development_path: { type: "string" },
                        archetype_strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        archetype_limitations: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setArchetype(response);
            toast.success('Archetype analysis complete!', { id: 'archetype' });
        } catch (error) {
            console.error('Failed to generate archetype:', error);
            toast.error('Failed to generate archetype', { id: 'archetype' });
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-purple-400" />
                            AI Player Archetype Analysis
                        </CardTitle>
                        {!archetype && (
                            <Button
                                onClick={generateArchetype}
                                disabled={isGenerating}
                                className="bg-gradient-to-r from-purple-500 to-blue-600"
                            >
                                {isGenerating ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Generate Archetype
                                    </>
                                )}
                            </Button>
                        )}
                    </div>
                </CardHeader>
                {!archetype && !isGenerating && (
                    <CardContent>
                        <p className="text-slate-400 text-sm">
                            Click to generate a comprehensive AI-powered player archetype analysis based on stats, playing style, and scouting data.
                        </p>
                    </CardContent>
                )}
            </Card>

            {archetype && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Primary Archetype */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="text-center mb-4">
                                <Badge className="bg-purple-500/20 text-purple-400 text-lg px-4 py-2 mb-3">
                                    {archetype.primary_archetype}
                                </Badge>
                                <p className="text-slate-300 leading-relaxed">
                                    {archetype.archetype_description}
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Similar Players */}
                    {archetype.similar_players && archetype.similar_players.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Users className="w-5 h-5 text-cyan-400" />
                                    Similar Player Profiles
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {archetype.similar_players.map((player, idx) => (
                                        <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                            {player}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Key Attributes */}
                    {archetype.key_attributes && archetype.key_attributes.length > 0 && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Zap className="w-5 h-5 text-amber-400" />
                                    Archetype-Defining Attributes
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {archetype.key_attributes.map((attr, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <h4 className="text-white font-semibold">{attr.attribute}</h4>
                                                <Badge className="bg-amber-500/20 text-amber-400">
                                                    {attr.current_level}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{attr.importance}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Tactical Analysis */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Target className="w-5 h-5 text-blue-400" />
                                    Ideal System
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 leading-relaxed">{archetype.ideal_system}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Users className="w-5 h-5 text-emerald-400" />
                                    Team Role
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 leading-relaxed">{archetype.team_role}</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Market Analysis */}
                    <Card className="bg-blue-500/10 border-blue-500/30">
                        <CardHeader>
                            <CardTitle className="text-blue-400">Market Niche & Value</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{archetype.market_niche}</p>
                        </CardContent>
                    </Card>

                    {/* Development Path */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-purple-400" />
                                Development Pathway
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{archetype.development_path}</p>
                        </CardContent>
                    </Card>

                    {/* Strengths & Limitations */}
                    <div className="grid md:grid-cols-2 gap-6">
                        {archetype.archetype_strengths && archetype.archetype_strengths.length > 0 && (
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-emerald-400 text-lg">Archetype Strengths</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {archetype.archetype_strengths.map((strength, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400 mt-0.5">✓</span>
                                                {strength}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        )}

                        {archetype.archetype_limitations && archetype.archetype_limitations.length > 0 && (
                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardHeader>
                                    <CardTitle className="text-amber-400 text-lg">Archetype Limitations</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {archetype.archetype_limitations.map((limitation, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-amber-400 mt-0.5">⚠</span>
                                                {limitation}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </motion.div>
            )}
        </div>
    );
}