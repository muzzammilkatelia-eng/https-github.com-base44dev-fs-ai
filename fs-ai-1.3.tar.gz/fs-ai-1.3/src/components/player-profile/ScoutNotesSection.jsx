import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { FileText, Save, Edit2, User } from 'lucide-react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function ScoutNotesSection({ player }) {
    const [isEditing, setIsEditing] = useState(false);
    const [notes, setNotes] = useState(player.notes || '');

    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scoutingReports', player.name],
        queryFn: () => base44.entities.ScoutingReport.filter({ player_name: player.name })
    });

    const updateNotesMutation = useMutation({
        mutationFn: async (newNotes) => {
            return base44.entities.Player.update(player.id, { notes: newNotes });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['player', player.id] });
            toast.success('Notes saved');
            setIsEditing(false);
        }
    });

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2">
                            <FileText className="w-5 h-5 text-cyan-400" />
                            General Scout Notes
                        </CardTitle>
                        {!isEditing ? (
                            <Button onClick={() => setIsEditing(true)} variant="outline">
                                <Edit2 className="w-4 h-4 mr-2" />
                                Edit
                            </Button>
                        ) : (
                            <Button
                                onClick={() => updateNotesMutation.mutate(notes)}
                                className="bg-cyan-600 hover:bg-cyan-700"
                            >
                                <Save className="w-4 h-4 mr-2" />
                                Save Notes
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent>
                    {isEditing ? (
                        <Textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white min-h-[200px]"
                            placeholder="Add your scouting observations, tactical notes, character assessments..."
                        />
                    ) : (
                        <div className="bg-slate-800/50 rounded-lg p-4 min-h-[200px]">
                            {notes ? (
                                <p className="text-slate-300 whitespace-pre-wrap">{notes}</p>
                            ) : (
                                <p className="text-slate-500 italic">No notes added yet</p>
                            )}
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Linked Scouting Reports */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">
                        Linked Scouting Reports ({scoutingReports.length})
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {scoutingReports.length === 0 ? (
                        <p className="text-slate-400 text-center py-8">No scouting reports available</p>
                    ) : (
                        <div className="space-y-4">
                            {scoutingReports.map((report, index) => (
                                <motion.div
                                    key={report.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <div className="flex items-center gap-2 mb-2">
                                                <User className="w-4 h-4 text-slate-400" />
                                                <span className="text-slate-300 text-sm">{report.created_by}</span>
                                                <span className="text-slate-500 text-sm">
                                                    {new Date(report.created_date).toLocaleDateString()}
                                                </span>
                                            </div>
                                            <div className="flex gap-2 flex-wrap">
                                                {report.modules_activated?.map((module, i) => (
                                                    <Badge key={i} className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                        {module}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                        <Badge className={
                                            report.recommendation === 'Strong Recommend' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                                            report.recommendation === 'Recommend' ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' :
                                            report.recommendation === 'Monitor' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                                            'bg-red-500/20 text-red-400 border-red-500/30'
                                        }>
                                            {report.recommendation}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-300 text-sm mt-2">
                                        {report.overall_verdict}
                                    </p>
                                    {report.notes && (
                                        <p className="text-slate-400 text-sm mt-2 pl-4 border-l-2 border-slate-700">
                                            {report.notes}
                                        </p>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}