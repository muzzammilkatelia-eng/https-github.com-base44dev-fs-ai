import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Sparkles, Loader2, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function ScoutReportSummary({ player, reports, projection, tasks, communications }) {
    const [summary, setSummary] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const generateSummary = async () => {
        setIsGenerating(true);
        toast.loading('AI synthesizing all data...', { id: 'summary' });

        try {
            const prompt = `Create a comprehensive executive scout report summary synthesizing all available data:

PLAYER PROFILE:
Name: ${player.name}
Age: ${player.age}
Position: ${player.position}
Club: ${player.current_club} (${player.league})
Market Value: €${player.market_value}M
Nationality: ${player.nationality}

SCOUTING REPORTS (${reports?.length || 0} total):
${reports?.slice(0, 3).map((r, i) => `
Report ${i + 1}:
- Overall: ${r.overall_rating}/10
- Recommendation: ${r.recommendation}
- Strengths: ${r.strengths}
- Weaknesses: ${r.weaknesses}
- Verdict: ${r.overall_verdict}
`).join('\n')}

PROJECTION DATA:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Rating: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
- Risk Factors: ${projection.risk_factors?.join(', ')}
` : 'No projection available'}

PHYSICAL & STYLE:
${JSON.stringify(player.physical_attributes)}
${JSON.stringify(player.playing_style)}

INJURY PROFILE:
- Injury Prone Score: ${player.injury_prone_score || 0}/100
- Recent Injuries: ${player.injury_history?.length || 0}

ACTIVE TASKS: ${tasks?.length || 0}
AGENT COMMUNICATIONS: ${communications?.length || 0}

CONTRACT STATUS:
- Expiry: ${player.contract_expiry || 'Unknown'}
- Release Clause: ${player.release_clause?.exists ? `€${player.release_clause.amount}M` : 'None'}

Create a CONCISE, ACTIONABLE executive summary with:
1. One-sentence profile
2. Overall verdict (Strong Recommend/Recommend/Monitor/Pass)
3. Key strengths (top 3)
4. Main concerns (top 3)
5. Transfer recommendation
6. Development potential
7. Risk assessment
8. Best tactical fit
9. Market value assessment
10. Next steps`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        executive_summary: { type: "string" },
                        overall_verdict: { type: "string" },
                        confidence_score: { type: "number" },
                        key_strengths: { type: "array", items: { type: "string" } },
                        main_concerns: { type: "array", items: { type: "string" } },
                        transfer_recommendation: {
                            type: "object",
                            properties: {
                                action: { type: "string" },
                                timing: { type: "string" },
                                max_fee: { type: "string" },
                                reasoning: { type: "string" }
                            }
                        },
                        development_outlook: {
                            type: "object",
                            properties: {
                                ceiling: { type: "string" },
                                timeline: { type: "string" },
                                areas_to_develop: { type: "array", items: { type: "string" } }
                            }
                        },
                        risk_assessment: {
                            type: "object",
                            properties: {
                                level: { type: "string" },
                                factors: { type: "array", items: { type: "string" } },
                                mitigation: { type: "string" }
                            }
                        },
                        tactical_fit: {
                            type: "object",
                            properties: {
                                best_formation: { type: "string" },
                                ideal_role: { type: "string" },
                                compatibility: { type: "number" }
                            }
                        },
                        market_analysis: {
                            type: "object",
                            properties: {
                                current_value_fair: { type: "boolean" },
                                analysis: { type: "string" },
                                value_trajectory: { type: "string" }
                            }
                        },
                        immediate_actions: { type: "array", items: { type: "string" } },
                        comparable_players: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setSummary(response);
            toast.success('Summary generated!', { id: 'summary' });
        } catch (error) {
            console.error('Failed to generate summary:', error);
            toast.error('Failed to generate summary', { id: 'summary' });
        } finally {
            setIsGenerating(false);
        }
    };

    const getVerdictColor = (verdict) => {
        if (verdict?.toLowerCase().includes('strong recommend')) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
        if (verdict?.toLowerCase().includes('recommend')) return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
        if (verdict?.toLowerCase().includes('monitor')) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-cyan-400" />
                        AI Scout Report Summary
                    </CardTitle>
                    {!summary && (
                        <Button
                            onClick={generateSummary}
                            disabled={isGenerating}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isGenerating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Summary
                                </>
                            )}
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                {!summary && !isGenerating && (
                    <div className="text-center py-8">
                        <FileText className="w-12 h-12 text-cyan-400 mx-auto mb-3 opacity-50" />
                        <p className="text-slate-400">
                            Generate an AI-powered executive summary of all available data
                        </p>
                    </div>
                )}

                {summary && (
                    <div className="space-y-6">
                        {/* Executive Summary */}
                        <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <Badge className={getVerdictColor(summary.overall_verdict)}>
                                    {summary.overall_verdict}
                                </Badge>
                                <div className="flex items-center gap-2">
                                    <span className="text-slate-400 text-sm">Confidence:</span>
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {summary.confidence_score}%
                                    </Badge>
                                </div>
                            </div>
                            <p className="text-white leading-relaxed">{summary.executive_summary}</p>
                        </div>

                        {/* Strengths & Concerns */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardContent className="pt-4">
                                    <h4 className="text-emerald-400 font-semibold mb-3 flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" />
                                        Key Strengths
                                    </h4>
                                    <ul className="space-y-2">
                                        {summary.key_strengths?.map((strength, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400 mt-0.5">✓</span>
                                                {strength}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>

                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardContent className="pt-4">
                                    <h4 className="text-amber-400 font-semibold mb-3 flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4" />
                                        Main Concerns
                                    </h4>
                                    <ul className="space-y-2">
                                        {summary.main_concerns?.map((concern, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-amber-400 mt-0.5">⚠</span>
                                                {concern}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Transfer Recommendation */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Transfer Recommendation</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Action:</span>
                                    <Badge className="bg-cyan-500/20 text-cyan-400">
                                        {summary.transfer_recommendation?.action}
                                    </Badge>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Timing:</span>
                                    <span className="text-white text-sm">{summary.transfer_recommendation?.timing}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-slate-400 text-sm">Max Fee:</span>
                                    <span className="text-amber-400 font-semibold">{summary.transfer_recommendation?.max_fee}</span>
                                </div>
                                <p className="text-slate-300 text-sm border-t border-slate-700 pt-3">
                                    {summary.transfer_recommendation?.reasoning}
                                </p>
                            </CardContent>
                        </Card>

                        {/* Development & Tactical */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4 text-purple-400" />
                                        Development Outlook
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Ceiling:</span>
                                        <span className="text-white">{summary.development_outlook?.ceiling}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Timeline:</span>
                                        <span className="text-white">{summary.development_outlook?.timeline}</span>
                                    </div>
                                    <div className="pt-2 border-t border-slate-700">
                                        <p className="text-slate-400 text-xs mb-1">Focus Areas:</p>
                                        <div className="flex flex-wrap gap-1">
                                            {summary.development_outlook?.areas_to_develop?.map((area, i) => (
                                                <Badge key={i} variant="outline" className="text-xs">
                                                    {area}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm">Tactical Fit</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Best Formation:</span>
                                        <span className="text-white">{summary.tactical_fit?.best_formation}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Ideal Role:</span>
                                        <span className="text-cyan-400">{summary.tactical_fit?.ideal_role}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-slate-400">Compatibility:</span>
                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                            {summary.tactical_fit?.compatibility}%
                                        </Badge>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Market Analysis */}
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Market Value Analysis</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge className={summary.market_analysis?.current_value_fair ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}>
                                        {summary.market_analysis?.current_value_fair ? 'Fair Value' : 'Overvalued'}
                                    </Badge>
                                    <span className="text-slate-400 text-sm">
                                        Trajectory: {summary.market_analysis?.value_trajectory}
                                    </span>
                                </div>
                                <p className="text-slate-300 text-sm">{summary.market_analysis?.analysis}</p>
                            </CardContent>
                        </Card>

                        {/* Next Steps */}
                        <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                            <CardHeader>
                                <CardTitle className="text-purple-400 text-sm">Immediate Actions Required</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ol className="space-y-2">
                                    {summary.immediate_actions?.map((action, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-3">
                                            <span className="text-purple-400 font-bold">{i + 1}.</span>
                                            {action}
                                        </li>
                                    ))}
                                </ol>
                            </CardContent>
                        </Card>

                        {/* Comparable Players */}
                        {summary.comparable_players?.length > 0 && (
                            <div>
                                <h4 className="text-slate-400 text-sm mb-2">Comparable Players:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {summary.comparable_players.map((player, i) => (
                                        <Badge key={i} variant="outline" className="text-slate-300">
                                            {player}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}

                        <Button
                            onClick={generateSummary}
                            variant="outline"
                            className="w-full border-slate-700"
                            size="sm"
                        >
                            Regenerate Summary
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}