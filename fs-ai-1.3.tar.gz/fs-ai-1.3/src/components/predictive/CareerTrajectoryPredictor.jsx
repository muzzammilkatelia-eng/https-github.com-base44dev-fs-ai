import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, TrendingUp, AlertCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function CareerTrajectoryPredictor({ players, projections, reports }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [prediction, setPrediction] = useState(null);
    const [predicting, setPredicting] = useState(false);

    const predict = async () => {
        if (!selectedPlayer) {
            toast.error('Select a player');
            return;
        }

        setPredicting(true);
        toast.loading('AI predicting career trajectory...', { id: 'predict' });

        try {
            const player = players.find(p => p.id === selectedPlayer);
            const projection = projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase());
            const playerReports = reports.filter(r => r.player_name?.toLowerCase() === player.name?.toLowerCase());

            const prompt = `Predict comprehensive career trajectory for: ${player.name} (${player.age}y, ${player.position})

CURRENT DATA:
- FS-AI Score: ${player.fsai_proprietary_score || 'N/A'}
- Market Value: €${player.market_value}M
- League: ${player.league}
- Club: ${player.current_club}

CAREER HISTORY:
${player.career_history?.map(h => `${h.season}: ${h.club} - ${h.appearances || 0} apps, ${h.goals || 0} goals`).join('\n') || 'No history'}

PROJECTION DATA:
${projection ? `
- Trajectory: ${projection.potential_trajectory}
- Peak Potential: ${projection.peak_potential_rating}/10
- Years to Peak: ${projection.years_to_peak}
` : 'No projection'}

REPORTS: ${playerReports.length} available

PREDICT:
1. Career peak age and rating
2. Development phases (yearly progression)
3. Optimal transfer windows
4. Risk factors and scenarios
5. Career longevity estimate
6. Performance milestones
7. Probability of different career paths`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        current_age: { type: "number" },
                        predicted_peak: {
                            type: "object",
                            properties: {
                                age: { type: "number" },
                                rating: { type: "number" },
                                market_value_peak: { type: "number" },
                                description: { type: "string" }
                            }
                        },
                        yearly_progression: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age: { type: "number" },
                                    year: { type: "string" },
                                    predicted_rating: { type: "number" },
                                    predicted_value: { type: "number" },
                                    phase: { type: "string" },
                                    key_developments: { type: "string" }
                                }
                            }
                        },
                        optimal_transfer_windows: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    window: { type: "string" },
                                    age_range: { type: "string" },
                                    reasoning: { type: "string" },
                                    estimated_value: { type: "string" }
                                }
                            }
                        },
                        career_scenarios: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    probability: { type: "number" },
                                    description: { type: "string" },
                                    outcome: { type: "string" }
                                }
                            }
                        },
                        risk_factors: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    factor: { type: "string" },
                                    severity: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        career_longevity: {
                            type: "object",
                            properties: {
                                peak_years: { type: "string" },
                                decline_starts: { type: "number" },
                                career_end_estimate: { type: "number" },
                                longevity_factors: { type: "array", items: { type: "string" } }
                            }
                        },
                        performance_milestones: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    milestone: { type: "string" },
                                    predicted_age: { type: "number" },
                                    likelihood: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setPrediction({ ...response, player_data: player });
            toast.success('Trajectory predicted!', { id: 'predict' });
        } catch (error) {
            console.error('Prediction failed:', error);
            toast.error('Failed to predict trajectory', { id: 'predict' });
        } finally {
            setPredicting(false);
        }
    };

    const chartData = prediction?.yearly_progression?.map(y => ({
        age: y.age,
        rating: y.predicted_rating,
        value: y.predicted_value
    })) || [];

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Career Trajectory Predictor
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="flex-1 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} - {p.position} ({p.age}y)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={predict}
                            disabled={predicting || !selectedPlayer}
                            className="bg-gradient-to-r from-purple-500 to-cyan-600"
                        >
                            {predicting ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Predicting...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Predict
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {prediction && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Peak Prediction */}
                    <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
                        <CardHeader>
                            <CardTitle className="text-amber-400">Predicted Career Peak</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                                    <p className="text-slate-400 text-sm mb-1">Peak Age</p>
                                    <p className="text-3xl font-bold text-white">{prediction.predicted_peak?.age}y</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                                    <p className="text-slate-400 text-sm mb-1">Peak Rating</p>
                                    <p className="text-3xl font-bold text-emerald-400">{prediction.predicted_peak?.rating}/10</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                                    <p className="text-slate-400 text-sm mb-1">Peak Value</p>
                                    <p className="text-3xl font-bold text-amber-400">€{prediction.predicted_peak?.market_value_peak}M</p>
                                </div>
                            </div>
                            <p className="text-slate-300">{prediction.predicted_peak?.description}</p>
                        </CardContent>
                    </Card>

                    {/* Trajectory Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Career Trajectory Forecast</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={400}>
                                <AreaChart data={chartData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="age" stroke="#94a3b8" label={{ value: 'Age', position: 'insideBottom', offset: -5 }} />
                                    <YAxis yAxisId="left" stroke="#94a3b8" label={{ value: 'Rating', angle: -90, position: 'insideLeft' }} />
                                    <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" label={{ value: 'Value (€M)', angle: 90, position: 'insideRight' }} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                                    <Legend />
                                    <Area yAxisId="left" type="monotone" dataKey="rating" stroke="#10b981" fill="#10b98120" name="Rating" />
                                    <Line yAxisId="right" type="monotone" dataKey="value" stroke="#f59e0b" strokeWidth={2} name="Market Value" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Yearly Progression */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Year-by-Year Progression</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {prediction.yearly_progression?.map((year, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex items-center gap-3">
                                                <Badge className="bg-purple-500/20 text-purple-400">Age {year.age}</Badge>
                                                <span className="text-white font-semibold">{year.year}</span>
                                                <Badge className="bg-cyan-500/20 text-cyan-400">{year.phase}</Badge>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <div className="text-right">
                                                    <p className="text-emerald-400 font-bold">{year.predicted_rating}/10</p>
                                                    <p className="text-slate-500 text-xs">Rating</p>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-amber-400 font-bold">€{year.predicted_value}M</p>
                                                    <p className="text-slate-500 text-xs">Value</p>
                                                </div>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{year.key_developments}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Transfer Windows */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Optimal Transfer Windows</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid gap-4">
                                {prediction.optimal_transfer_windows?.map((window, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-2">
                                            <div>
                                                <h4 className="text-emerald-400 font-semibold">{window.window}</h4>
                                                <p className="text-slate-400 text-sm">Age: {window.age_range}</p>
                                            </div>
                                            <Badge className="bg-amber-500/20 text-amber-400">{window.estimated_value}</Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{window.reasoning}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Career Scenarios */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Possible Career Paths</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {prediction.career_scenarios?.sort((a, b) => b.probability - a.probability).map((scenario, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-3">
                                            <h4 className="text-white font-semibold">{scenario.scenario}</h4>
                                            <Badge className={`${
                                                scenario.probability >= 60 ? 'bg-emerald-500/20 text-emerald-400' :
                                                scenario.probability >= 30 ? 'bg-cyan-500/20 text-cyan-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }`}>
                                                {scenario.probability}% Probability
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm mb-2">{scenario.description}</p>
                                        <p className="text-purple-400 text-sm font-medium">Outcome: {scenario.outcome}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Risk Factors */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-red-400 flex items-center gap-2">
                                <AlertCircle className="w-5 h-5" />
                                Risk Factors
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {prediction.risk_factors?.map((risk, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-start justify-between mb-2">
                                            <h5 className="text-white font-semibold text-sm">{risk.factor}</h5>
                                            <Badge className={
                                                risk.severity === 'High' ? 'bg-red-500/20 text-red-400' :
                                                risk.severity === 'Medium' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-slate-500/20 text-slate-400'
                                            }>
                                                {risk.severity}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">Mitigation: {risk.mitigation}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Career Longevity */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Career Longevity Estimate</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Peak Years</p>
                                    <p className="text-white font-semibold">{prediction.career_longevity?.peak_years}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Decline Starts</p>
                                    <p className="text-amber-400 font-semibold">Age {prediction.career_longevity?.decline_starts}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Career End</p>
                                    <p className="text-red-400 font-semibold">~Age {prediction.career_longevity?.career_end_estimate}</p>
                                </div>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Longevity Factors:</p>
                                <div className="flex flex-wrap gap-2">
                                    {prediction.career_longevity?.longevity_factors?.map((factor, i) => (
                                        <Badge key={i} variant="outline" className="text-slate-300">{factor}</Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Performance Milestones */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Predicted Performance Milestones</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                {prediction.performance_milestones?.map((milestone, idx) => (
                                    <div key={idx} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center gap-3">
                                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                                            <span className="text-white text-sm">{milestone.milestone}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Badge className="bg-purple-500/20 text-purple-400 text-xs">Age {milestone.predicted_age}</Badge>
                                            <Badge className={`text-xs ${
                                                milestone.likelihood?.toLowerCase().includes('high') ? 'bg-emerald-500/20 text-emerald-400' :
                                                milestone.likelihood?.toLowerCase().includes('medium') ? 'bg-cyan-500/20 text-cyan-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }`}>
                                                {milestone.likelihood}
                                            </Badge>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!prediction && !predicting && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <TrendingUp className="w-16 h-16 text-purple-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Career Trajectory Predictor</h3>
                            <p className="text-slate-400">Select a player to generate AI-powered career predictions</p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}