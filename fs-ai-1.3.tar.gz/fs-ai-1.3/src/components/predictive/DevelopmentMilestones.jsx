import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, TrendingUp, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function DevelopmentMilestones({ players, projections, reports }) {
    const [milestones, setMilestones] = useState([]);
    const queryClient = useQueryClient();

    useEffect(() => {
        analyzeMilestones();
    }, [players, projections, reports]);

    const analyzeMilestones = () => {
        const detected = [];

        players.forEach(player => {
            const playerReports = reports.filter(r => 
                r.player_name?.toLowerCase() === player.name?.toLowerCase()
            ).sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            // Rating breakthrough
            if (playerReports.length >= 2) {
                const latest = playerReports[playerReports.length - 1];
                const previous = playerReports[playerReports.length - 2];
                
                if (latest.overall_rating >= 8 && previous.overall_rating < 8) {
                    detected.push({
                        player_name: player.name,
                        type: 'Rating Breakthrough',
                        description: `Reached 8+ overall rating (from ${previous.overall_rating})`,
                        severity: 'High',
                        timestamp: latest.created_date,
                        action_required: 'Monitor closely - entering elite bracket'
                    });
                }

                // Rapid improvement
                const improvement = latest.overall_rating - previous.overall_rating;
                if (improvement >= 1.5) {
                    detected.push({
                        player_name: player.name,
                        type: 'Rapid Development',
                        description: `+${improvement} rating improvement detected`,
                        severity: 'Medium',
                        timestamp: latest.created_date,
                        action_required: 'Accelerated growth trajectory'
                    });
                }
            }

            // Age milestones
            if (player.age === 21 && player.fsai_proprietary_score >= 75) {
                detected.push({
                    player_name: player.name,
                    type: 'Prime Entry',
                    description: 'Entering prime years with high FS-AI score',
                    severity: 'High',
                    timestamp: new Date().toISOString(),
                    action_required: 'Optimal acquisition window approaching'
                });
            }

            // Market value shifts
            if (player.market_value && player.market_value >= 50 && player.age <= 23) {
                detected.push({
                    player_name: player.name,
                    type: 'Market Value Milestone',
                    description: `Reached €${player.market_value}M valuation at age ${player.age}`,
                    severity: 'Medium',
                    timestamp: new Date().toISOString(),
                    action_required: 'High-value young prospect'
                });
            }

            // Projection milestones
            if (projection) {
                if (projection.years_to_peak <= 2 && projection.peak_potential_rating >= 9) {
                    detected.push({
                        player_name: player.name,
                        type: 'Peak Approaching',
                        description: `Predicted to reach ${projection.peak_potential_rating}/10 in ${projection.years_to_peak} years`,
                        severity: 'Critical',
                        timestamp: new Date().toISOString(),
                        action_required: 'Secure before peak window'
                    });
                }
            }

            // Contract expiry
            if (player.contract_expiry) {
                const months = (new Date(player.contract_expiry) - new Date()) / (1000 * 60 * 60 * 24 * 30);
                if (months <= 6 && months > 0 && player.fsai_proprietary_score >= 70) {
                    detected.push({
                        player_name: player.name,
                        type: 'Contract Opportunity',
                        description: `Contract expires in ${Math.floor(months)} months`,
                        severity: 'Critical',
                        timestamp: new Date().toISOString(),
                        action_required: 'Pre-contract negotiation available'
                    });
                }
            }
        });

        setMilestones(detected.sort((a, b) => {
            const severityOrder = { 'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3 };
            return severityOrder[a.severity] - severityOrder[b.severity];
        }));
    };

    const createAlert = useMutation({
        mutationFn: (milestone) => base44.entities.Alert.create({
            player_name: milestone.player_name,
            alert_type: 'projection',
            criteria_name: milestone.type,
            player_details: { description: milestone.description }
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['alerts']);
            toast.success('Alert created');
        }
    });

    const getSeverityIcon = (severity) => {
        switch (severity) {
            case 'Critical': return <AlertCircle className="w-5 h-5 text-red-400" />;
            case 'High': return <TrendingUp className="w-5 h-5 text-amber-400" />;
            case 'Medium': return <Bell className="w-5 h-5 text-cyan-400" />;
            default: return <Clock className="w-5 h-5 text-slate-400" />;
        }
    };

    const getSeverityColor = (severity) => {
        switch (severity) {
            case 'Critical': return 'from-red-500/10 to-orange-500/10 border-red-500/30';
            case 'High': return 'from-amber-500/10 to-yellow-500/10 border-amber-500/30';
            case 'Medium': return 'from-cyan-500/10 to-blue-500/10 border-cyan-500/30';
            default: return 'from-slate-500/10 to-slate-500/10 border-slate-500/30';
        }
    };

    const criticalCount = milestones.filter(m => m.severity === 'Critical').length;
    const highCount = milestones.filter(m => m.severity === 'High').length;

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Bell className="w-5 h-5 text-purple-400" />
                        Development Milestones & Alerts
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <p className="text-slate-400 text-xs mb-1">Total Milestones</p>
                            <p className="text-3xl font-bold text-white">{milestones.length}</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <p className="text-slate-400 text-xs mb-1">Critical</p>
                            <p className="text-3xl font-bold text-red-400">{criticalCount}</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <p className="text-slate-400 text-xs mb-1">High Priority</p>
                            <p className="text-3xl font-bold text-amber-400">{highCount}</p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                            <p className="text-slate-400 text-xs mb-1">Active Tracking</p>
                            <p className="text-3xl font-bold text-emerald-400">{players.length}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="grid gap-4">
                {milestones.length === 0 ? (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="py-12">
                            <div className="text-center">
                                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-50" />
                                <p className="text-white font-semibold mb-1">No Critical Milestones</p>
                                <p className="text-slate-400 text-sm">All players on track with expected development</p>
                            </div>
                        </CardContent>
                    </Card>
                ) : (
                    milestones.map((milestone, idx) => (
                        <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.03 }}
                        >
                            <Card className={`bg-gradient-to-r ${getSeverityColor(milestone.severity)}`}>
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex items-start gap-3 flex-1">
                                            {getSeverityIcon(milestone.severity)}
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h4 className="text-white font-semibold">{milestone.player_name}</h4>
                                                    <Badge className={
                                                        milestone.severity === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                        milestone.severity === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                        milestone.severity === 'Medium' ? 'bg-cyan-500/20 text-cyan-400' :
                                                        'bg-slate-500/20 text-slate-400'
                                                    }>
                                                        {milestone.type}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-300 text-sm mb-2">{milestone.description}</p>
                                                <div className="bg-slate-800/50 rounded-lg p-2">
                                                    <p className="text-purple-400 text-xs font-semibold mb-1">Action Required:</p>
                                                    <p className="text-slate-300 text-xs">{milestone.action_required}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <Button
                                            size="sm"
                                            onClick={() => createAlert.mutate(milestone)}
                                            className="bg-purple-500 hover:bg-purple-600"
                                        >
                                            <Bell className="w-4 h-4 mr-1" />
                                            Alert
                                        </Button>
                                    </div>
                                    <p className="text-slate-500 text-xs">
                                        Detected: {new Date(milestone.timestamp).toLocaleString()}
                                    </p>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))
                )}
            </div>
        </div>
    );
}