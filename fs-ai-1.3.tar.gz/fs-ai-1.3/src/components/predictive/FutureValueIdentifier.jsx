import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Target, Sparkles, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function FutureValueIdentifier({ players, projections }) {
    const [identifying, setIdentifying] = useState(false);
    const [identifiedPlayers, setIdentifiedPlayers] = useState(null);
    const navigate = useNavigate();

    const identify = async () => {
        setIdentifying(true);
        toast.loading('AI identifying high future value players...', { id: 'identify' });

        try {
            const scoredPlayers = players.filter(p => p.fsai_proprietary_score);

            const prompt = `Identify players with highest FUTURE TRANSFER VALUE potential:

PLAYERS (${scoredPlayers.length}):
${scoredPlayers.slice(0, 100).map(p => `
- ${p.name} (${p.age}y, ${p.position})
  Current Value: €${p.market_value || 0}M
  FS-AI: ${p.fsai_proprietary_score}
  League: ${p.league}
  ${projections.find(pr => pr.player_name === p.name) ? `Projection: ${projections.find(pr => pr.player_name === p.name).potential_trajectory}` : ''}
`).join('\n')}

IDENTIFY TOP 15 based on:
1. Current undervaluation vs potential
2. Development velocity indicators
3. Age and peak timing
4. League progression potential
5. Market demand for position
6. Scarcity of profile
7. Transfer trajectory

For each, calculate:
- Future Value Multiple (current → peak)
- ROI Potential %
- Optimal exit window`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        high_value_prospects: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    age: { type: "number" },
                                    current_value: { type: "number" },
                                    predicted_peak_value: { type: "number" },
                                    value_multiple: { type: "number" },
                                    roi_potential: { type: "number" },
                                    investment_thesis: { type: "string" },
                                    key_value_drivers: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    optimal_buy_window: { type: "string" },
                                    optimal_sell_window: { type: "string" },
                                    risk_level: { type: "string" },
                                    market_timing: { type: "string" }
                                }
                            }
                        },
                        market_insights: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setIdentifiedPlayers(response);
            toast.success(`Identified ${response.high_value_prospects?.length || 0} high-value prospects!`, { id: 'identify' });
        } catch (error) {
            console.error('Identification failed:', error);
            toast.error('Failed to identify prospects', { id: 'identify' });
        } finally {
            setIdentifying(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-amber-400" />
                            High Future Value Identifier
                        </CardTitle>
                        <Button
                            onClick={identify}
                            disabled={identifying}
                            className="bg-gradient-to-r from-amber-500 to-orange-600"
                        >
                            {identifying ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Identify Prospects
                                </>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 text-sm">
                        AI identifies players with maximum future transfer value potential based on development trends and market analysis
                    </p>
                </CardContent>
            </Card>

            {identifiedPlayers && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {identifiedPlayers.market_insights && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Market Insights</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {identifiedPlayers.market_insights.map((insight, idx) => (
                                        <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                            {insight}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <div className="grid gap-4">
                        {identifiedPlayers.high_value_prospects?.sort((a, b) => b.roi_potential - a.roi_potential).map((prospect, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: idx * 0.05 }}
                            >
                                <Card className="bg-gradient-to-r from-amber-500/5 to-orange-500/5 border-amber-500/30 hover:border-amber-500/50 transition-colors">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                                                    <span className="text-white font-bold text-lg">#{idx + 1}</span>
                                                </div>
                                                <div>
                                                    <h3 className="text-white text-xl font-bold">{prospect.player_name}</h3>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Badge className="bg-slate-700 text-slate-300">{prospect.position}</Badge>
                                                        <Badge className="bg-slate-700 text-slate-300">{prospect.age}y</Badge>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-emerald-400 text-3xl font-bold">+{prospect.roi_potential}%</p>
                                                <p className="text-slate-500 text-xs">ROI Potential</p>
                                            </div>
                                        </div>

                                        <div className="grid md:grid-cols-4 gap-4 mb-4">
                                            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                                <p className="text-slate-400 text-xs mb-1">Current</p>
                                                <p className="text-white text-lg font-bold">€{prospect.current_value}M</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                                <p className="text-slate-400 text-xs mb-1">Peak Value</p>
                                                <p className="text-emerald-400 text-lg font-bold">€{prospect.predicted_peak_value}M</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                                <p className="text-slate-400 text-xs mb-1">Multiple</p>
                                                <p className="text-amber-400 text-lg font-bold">{prospect.value_multiple}x</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                                <p className="text-slate-400 text-xs mb-1">Risk</p>
                                                <Badge className={
                                                    prospect.risk_level?.toLowerCase().includes('low') ? 'bg-emerald-500/20 text-emerald-400' :
                                                    prospect.risk_level?.toLowerCase().includes('medium') ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-red-500/20 text-red-400'
                                                }>
                                                    {prospect.risk_level}
                                                </Badge>
                                            </div>
                                        </div>

                                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mb-4">
                                            <p className="text-amber-400 text-xs font-semibold mb-1">Investment Thesis</p>
                                            <p className="text-slate-300 text-sm">{prospect.investment_thesis}</p>
                                        </div>

                                        <div className="mb-4">
                                            <p className="text-slate-400 text-xs font-semibold mb-2">Key Value Drivers</p>
                                            <div className="flex flex-wrap gap-2">
                                                {prospect.key_value_drivers?.map((driver, i) => (
                                                    <Badge key={i} className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                        {driver}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="grid md:grid-cols-3 gap-3">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Optimal Buy</p>
                                                <p className="text-emerald-400 text-sm font-semibold">{prospect.optimal_buy_window}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Optimal Sell</p>
                                                <p className="text-cyan-400 text-sm font-semibold">{prospect.optimal_sell_window}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Market Timing</p>
                                                <p className="text-purple-400 text-sm font-semibold">{prospect.market_timing}</p>
                                            </div>
                                        </div>

                                        <Button
                                            onClick={() => {
                                                const player = players.find(p => p.name === prospect.player_name);
                                                if (player) {
                                                    navigate(createPageUrl('PlayerProfile') + `?id=${player.id}`);
                                                }
                                            }}
                                            className="w-full mt-4 bg-amber-500 hover:bg-amber-600"
                                        >
                                            View Full Profile
                                        </Button>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            )}

            {!identifiedPlayers && !identifying && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <Target className="w-16 h-16 text-amber-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Future Value Identifier</h3>
                            <p className="text-slate-400">
                                Discover players with maximum ROI potential and optimal investment timing
                            </p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}