import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, DollarSign, Sparkles, TrendingUp, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function MarketValuePredictor({ players }) {
    const [selectedPlayer, setSelectedPlayer] = useState('');
    const [forecast, setForecast] = useState(null);
    const [forecasting, setForecasting] = useState(false);

    const generateForecast = async () => {
        if (!selectedPlayer) {
            toast.error('Select a player');
            return;
        }

        setForecasting(true);
        toast.loading('AI forecasting market value...', { id: 'forecast' });

        try {
            const player = players.find(p => p.id === selectedPlayer);

            const prompt = `Forecast market value fluctuations for: ${player.name}

PLAYER: ${player.age}y, ${player.position}, ${player.league}
Current Value: €${player.market_value || 0}M
FS-AI Score: ${player.fsai_proprietary_score || 'N/A'}

CAREER HISTORY:
${player.career_history?.map(h => `${h.season}: ${h.appearances || 0} apps, ${h.goals || 0}G`).join('\n') || 'No history'}

FACTORS TO CONSIDER:
1. Age and development curve
2. League reputation and visibility
3. Performance trends
4. Position market demand
5. Contract situation
6. Injury history
7. Competition level
8. Recent form trajectory

FORECAST:
- Next 12 months (quarterly)
- Next 3 years (yearly)
- Market drivers and suppressors
- Best selling window
- Risk scenarios`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        player_name: { type: "string" },
                        current_value: { type: "number" },
                        quarterly_forecast: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    quarter: { type: "string" },
                                    predicted_value: { type: "number" },
                                    change_percentage: { type: "number" },
                                    drivers: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        yearly_forecast: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "string" },
                                    predicted_value: { type: "number" },
                                    low_estimate: { type: "number" },
                                    high_estimate: { type: "number" },
                                    confidence: { type: "string" }
                                }
                            }
                        },
                        value_drivers: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    factor: { type: "string" },
                                    impact: { type: "string" },
                                    explanation: { type: "string" }
                                }
                            }
                        },
                        value_suppressors: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    factor: { type: "string" },
                                    impact: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        optimal_selling_window: {
                            type: "object",
                            properties: {
                                timeframe: { type: "string" },
                                predicted_value: { type: "string" },
                                reasoning: { type: "string" }
                            }
                        },
                        market_scenarios: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    probability: { type: "number" },
                                    value_impact: { type: "string" },
                                    description: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setForecast({ ...response, player_data: player });
            toast.success('Market forecast generated!', { id: 'forecast' });
        } catch (error) {
            console.error('Forecast failed:', error);
            toast.error('Failed to forecast market value', { id: 'forecast' });
        } finally {
            setForecasting(false);
        }
    };

    const quarterlyData = forecast?.quarterly_forecast?.map(q => ({
        quarter: q.quarter,
        value: q.predicted_value,
        change: q.change_percentage
    })) || [];

    const yearlyData = forecast?.yearly_forecast?.map(y => ({
        year: y.year,
        value: y.predicted_value,
        low: y.low_estimate,
        high: y.high_estimate
    })) || [];

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-emerald-400" />
                        AI Market Value Forecaster
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-4">
                        <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="flex-1 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} - €{p.market_value || 0}M
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={generateForecast}
                            disabled={forecasting || !selectedPlayer}
                            className="bg-gradient-to-r from-emerald-500 to-cyan-600"
                        >
                            {forecasting ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Forecasting...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Forecast
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {forecast && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Current vs Forecast */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Current Market Value</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-4xl font-bold text-emerald-400 mb-2">€{forecast.current_value}M</p>
                                <p className="text-slate-400 text-sm">{forecast.player_name}</p>
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">12-Month Forecast</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {forecast.quarterly_forecast && forecast.quarterly_forecast.length > 0 && (
                                    <>
                                        <p className="text-4xl font-bold text-cyan-400 mb-2">
                                            €{forecast.quarterly_forecast[forecast.quarterly_forecast.length - 1].predicted_value}M
                                        </p>
                                        <div className="flex items-center gap-2">
                                            {forecast.quarterly_forecast[forecast.quarterly_forecast.length - 1].change_percentage > 0 ? (
                                                <>
                                                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                                                    <span className="text-emerald-400 text-sm font-semibold">
                                                        +{forecast.quarterly_forecast[forecast.quarterly_forecast.length - 1].change_percentage}%
                                                    </span>
                                                </>
                                            ) : (
                                                <>
                                                    <TrendingDown className="w-4 h-4 text-red-400" />
                                                    <span className="text-red-400 text-sm font-semibold">
                                                        {forecast.quarterly_forecast[forecast.quarterly_forecast.length - 1].change_percentage}%
                                                    </span>
                                                </>
                                            )}
                                        </div>
                                    </>
                                )}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Quarterly Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Quarterly Value Forecast (12 Months)</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={quarterlyData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="quarter" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" label={{ value: 'Value (€M)', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                                    <ReferenceLine y={forecast.current_value} stroke="#f59e0b" strokeDasharray="3 3" label="Current" />
                                    <Line type="monotone" dataKey="value" stroke="#06b6d4" strokeWidth={3} dot={{ fill: '#06b6d4', r: 6 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Yearly Forecast */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">3-Year Value Forecast</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={yearlyData}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="year" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                                    <Legend />
                                    <Line type="monotone" dataKey="high" stroke="#10b981" strokeDasharray="5 5" name="High Estimate" />
                                    <Line type="monotone" dataKey="value" stroke="#06b6d4" strokeWidth={3} name="Predicted" />
                                    <Line type="monotone" dataKey="low" stroke="#ef4444" strokeDasharray="5 5" name="Low Estimate" />
                                </LineChart>
                            </ResponsiveContainer>
                            <div className="grid md:grid-cols-3 gap-3 mt-4">
                                {forecast.yearly_forecast?.map((year, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">{year.year}</p>
                                        <p className="text-cyan-400 text-xl font-bold">€{year.predicted_value}M</p>
                                        <p className="text-slate-500 text-xs">Range: €{year.low_estimate}M - €{year.high_estimate}M</p>
                                        <Badge className="bg-purple-500/20 text-purple-400 text-xs mt-1">{year.confidence}</Badge>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Optimal Selling Window */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Optimal Selling Window</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="mb-3">
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-lg">{forecast.optimal_selling_window?.timeframe}</Badge>
                            </div>
                            <p className="text-white text-2xl font-bold mb-2">{forecast.optimal_selling_window?.predicted_value}</p>
                            <p className="text-slate-300">{forecast.optimal_selling_window?.reasoning}</p>
                        </CardContent>
                    </Card>

                    {/* Value Drivers & Suppressors */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-emerald-500/10 border-emerald-500/30">
                            <CardHeader>
                                <CardTitle className="text-emerald-400 flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5" />
                                    Value Drivers
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {forecast.value_drivers?.map((driver, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex items-center justify-between mb-1">
                                                <h5 className="text-white font-semibold text-sm">{driver.factor}</h5>
                                                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">{driver.impact}</Badge>
                                            </div>
                                            <p className="text-slate-300 text-sm">{driver.explanation}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-red-500/10 border-red-500/30">
                            <CardHeader>
                                <CardTitle className="text-red-400 flex items-center gap-2">
                                    <TrendingDown className="w-5 h-5" />
                                    Value Suppressors
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {forecast.value_suppressors?.map((suppressor, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex items-center justify-between mb-1">
                                                <h5 className="text-white font-semibold text-sm">{suppressor.factor}</h5>
                                                <Badge className="bg-red-500/20 text-red-400 text-xs">{suppressor.impact}</Badge>
                                            </div>
                                            <p className="text-slate-300 text-sm mb-1">{suppressor.mitigation}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Market Scenarios */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Market Scenarios</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {forecast.market_scenarios?.sort((a, b) => b.probability - a.probability).map((scenario, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-start justify-between mb-2">
                                            <h5 className="text-white font-semibold">{scenario.scenario}</h5>
                                            <Badge className={`${
                                                scenario.probability >= 50 ? 'bg-emerald-500/20 text-emerald-400' :
                                                scenario.probability >= 25 ? 'bg-cyan-500/20 text-cyan-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }`}>
                                                {scenario.probability}%
                                            </Badge>
                                        </div>
                                        <p className="text-purple-400 text-sm mb-1">Impact: {scenario.value_impact}</p>
                                        <p className="text-slate-300 text-sm">{scenario.description}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}

            {!forecast && !forecasting && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <DollarSign className="w-16 h-16 text-emerald-400 mx-auto mb-4 opacity-50" />
                            <h3 className="text-white text-xl font-semibold mb-2">Market Value Forecaster</h3>
                            <p className="text-slate-400">Select a player to generate AI-powered value predictions</p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}