import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calendar, Target, TrendingUp, Dumbbell, Brain, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DevelopmentPlan({ plan }) {
    if (!plan) return null;

    const getStatusColor = (status) => {
        const colors = {
            'On Track': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Pending': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'At Risk': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[status] || colors['Pending'];
    };

    return (
        <div className="space-y-6">
            {/* Training Schedule */}
            {plan.training_schedule && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Weekly Focus */}
                    {plan.training_schedule.weekly_focus && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Calendar className="w-5 h-5 text-cyan-400" />
                                    Weekly Training Focus
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {plan.training_schedule.weekly_focus.map((day, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.05 }}
                                            className="bg-slate-800/50 rounded-lg p-3"
                                        >
                                            <div className="flex justify-between items-start mb-1">
                                                <h4 className="text-white font-semibold text-sm">{day.day}</h4>
                                                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">
                                                    {day.duration}
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{day.focus}</p>
                                            {day.exercises && (
                                                <ul className="mt-2 space-y-1">
                                                    {day.exercises.slice(0, 3).map((ex, i) => (
                                                        <li key={i} className="text-slate-500 text-xs flex items-start gap-1">
                                                            <span className="text-cyan-400">•</span>
                                                            {ex}
                                                        </li>
                                                    ))}
                                                </ul>
                                            )}
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Monthly Objectives */}
                    {plan.training_schedule.monthly_objectives && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Target className="w-5 h-5 text-purple-400" />
                                    Monthly Objectives
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {plan.training_schedule.monthly_objectives.map((obj, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.05 }}
                                            className="bg-slate-800/50 rounded-lg p-3"
                                        >
                                            <h4 className="text-white font-semibold text-sm mb-2">{obj.month}</h4>
                                            <ul className="space-y-1">
                                                {obj.goals.map((goal, i) => (
                                                    <li key={i} className="text-slate-400 text-sm flex items-start gap-2">
                                                        <span className="text-purple-400 mt-1">✓</span>
                                                        {goal}
                                                    </li>
                                                ))}
                                            </ul>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </div>
            )}

            {/* Skill Focus Areas */}
            {plan.skill_focus_areas && plan.skill_focus_areas.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                            Skill Development Focus
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {plan.skill_focus_areas.map((skill, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.1 }}
                                    className="bg-slate-800/50 rounded-lg p-4"
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <div>
                                            <h4 className="text-white font-semibold">{skill.skill}</h4>
                                            <p className="text-slate-500 text-sm">{skill.timeline}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-slate-400 text-sm">
                                                {skill.current_level}/10 → {skill.target_level}/10
                                            </p>
                                        </div>
                                    </div>
                                    <Progress 
                                        value={(skill.current_level / skill.target_level) * 100} 
                                        className="h-2 mb-3"
                                    />
                                    {skill.exercises && skill.exercises.length > 0 && (
                                        <div className="mt-3">
                                            <p className="text-slate-500 text-xs mb-2">Recommended Exercises:</p>
                                            <ul className="space-y-1">
                                                {skill.exercises.map((ex, i) => (
                                                    <li key={i} className="text-slate-400 text-sm flex items-start gap-2">
                                                        <span className="text-emerald-400">→</span>
                                                        {ex}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Milestone Tracking */}
            {plan.milestone_tracking && plan.milestone_tracking.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Zap className="w-5 h-5 text-amber-400" />
                            Development Milestones
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {plan.milestone_tracking.map((milestone, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                    className="bg-slate-800/50 rounded-lg p-4"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="text-white font-semibold">{milestone.milestone}</h4>
                                        <Badge className={getStatusColor(milestone.status)}>
                                            {milestone.status}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-500 text-sm mb-2">Target: {milestone.target_date}</p>
                                    {milestone.metrics && milestone.metrics.length > 0 && (
                                        <div className="flex flex-wrap gap-2">
                                            {milestone.metrics.map((metric, i) => (
                                                <Badge key={i} className="bg-slate-700 text-slate-300 text-xs">
                                                    {metric}
                                                </Badge>
                                            ))}
                                        </div>
                                    )}
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Additional Development Areas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {plan.tactical_development && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2 text-base">
                                <Brain className="w-4 h-4 text-cyan-400" />
                                Tactical
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-400 text-sm">{plan.tactical_development}</p>
                        </CardContent>
                    </Card>
                )}

                {plan.physical_program && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2 text-base">
                                <Dumbbell className="w-4 h-4 text-emerald-400" />
                                Physical
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-400 text-sm">{plan.physical_program}</p>
                        </CardContent>
                    </Card>
                )}

                {plan.mental_coaching && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2 text-base">
                                <Brain className="w-4 h-4 text-purple-400" />
                                Mental
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-400 text-sm">{plan.mental_coaching}</p>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}