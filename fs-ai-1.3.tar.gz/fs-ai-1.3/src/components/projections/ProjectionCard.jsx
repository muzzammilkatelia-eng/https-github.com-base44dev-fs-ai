import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, AlertTriangle, Calendar, Award } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ProjectionCard({ projection }) {
    const getTrajectoryColor = (trajectory) => {
        switch (trajectory) {
            case 'Elite Tier Prospect':
            case 'Top Tier Prospect':
                return 'bg-gradient-to-r from-amber-500 to-orange-600 text-white';
            case 'Solid Professional':
                return 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white';
            case 'Late Bloomer':
                return 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white';
            case 'Average Professional':
                return 'bg-gradient-to-r from-slate-500 to-slate-600 text-white';
            case 'Potential Decline':
            case 'Decline Phase':
                return 'bg-gradient-to-r from-red-500 to-rose-600 text-white';
            default:
                return 'bg-slate-600 text-white';
        }
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'Critical':
                return 'bg-red-500/20 text-red-400 border-red-500/30';
            case 'High':
                return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
            case 'Medium':
                return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
            default:
                return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
        >
            {/* Header Card */}
            <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/30 shadow-lg shadow-cyan-500/10">
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="text-3xl text-white mb-2">{projection.player_name}</CardTitle>
                            <p className="text-slate-400">{projection.position} · {projection.current_age} years</p>
                            <p className="text-cyan-400 font-semibold mt-1">Current Rating: {projection.current_rating}</p>
                        </div>
                        <div className={`px-4 py-2 rounded-lg font-bold text-center shadow-lg ${getTrajectoryColor(projection.potential_trajectory)}`}>
                            <p className="text-sm opacity-90">Trajectory</p>
                            <p className="text-lg">{projection.potential_trajectory}</p>
                        </div>
                    </div>
                </CardHeader>
            </Card>

            {/* Peak Potential */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <Award className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">Peak Potential</p>
                        <p className="text-4xl font-bold text-amber-400">{projection.peak_potential_rating}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <Calendar className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">Years to Peak</p>
                        <p className="text-4xl font-bold text-cyan-400">{projection.years_to_peak}</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <TrendingUp className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">Growth Rate</p>
                        <p className="text-lg font-bold text-emerald-400">{projection.development_curve}</p>
                    </CardContent>
                </Card>
            </div>

            {/* Ceiling Analysis */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-400" />
                        Ceiling Analysis
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line">{projection.ceiling_analysis}</p>
                </CardContent>
            </Card>

            {/* Development Priorities */}
            {projection.development_priorities && projection.development_priorities.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Development Priorities
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {projection.development_priorities.map((priority, index) => (
                            <div key={index} className="bg-slate-800/50 rounded-lg p-4">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-white font-semibold">{priority.area}</h4>
                                    <Badge className={getPriorityColor(priority.priority)}>
                                        {priority.priority}
                                    </Badge>
                                </div>
                                <p className="text-slate-400 text-sm">{priority.description}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}

            {/* Recommended Pathway */}
            {projection.recommended_pathway && (
                <Card className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-400" />
                            Recommended Development Pathway
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 leading-relaxed whitespace-pre-line">{projection.recommended_pathway}</p>
                    </CardContent>
                </Card>
            )}

            {/* Risk Factors */}
            {projection.risk_factors && projection.risk_factors.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5 text-amber-400" />
                            Risk Factors
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {projection.risk_factors.map((risk, index) => (
                                <li key={index} className="flex items-start gap-2 text-slate-300">
                                    <span className="text-amber-400 mt-1">•</span>
                                    <span>{risk}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            )}

            {/* Age Milestones */}
            {projection.age_milestones && projection.age_milestones.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-cyan-400" />
                            Projected Development Timeline
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {projection.age_milestones.map((milestone, index) => (
                                <div key={index} className="flex items-center gap-4 bg-slate-800/50 rounded-lg p-3">
                                    <div className="flex-shrink-0 w-16 text-center">
                                        <p className="text-2xl font-bold text-cyan-400">{milestone.age}</p>
                                        <p className="text-xs text-slate-500">years</p>
                                    </div>
                                    <div className="h-12 w-px bg-slate-700"></div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-center mb-1">
                                            <p className="text-white font-semibold">{milestone.milestone}</p>
                                            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                                Rating: {milestone.projected_rating}
                                            </Badge>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Comparative Trajectory */}
            {projection.comparative_trajectory && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Comparative Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 leading-relaxed whitespace-pre-line">{projection.comparative_trajectory}</p>
                    </CardContent>
                </Card>
            )}
        </motion.div>
    );
}