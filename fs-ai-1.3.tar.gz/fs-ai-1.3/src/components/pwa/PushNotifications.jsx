import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Bell, BellOff } from 'lucide-react';
import toast from 'react-hot-toast';
import { base44 } from '@/api/base44Client';

export default function PushNotifications() {
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        checkSubscription();
    }, []);

    const checkSubscription = async () => {
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
            return;
        }

        try {
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            setIsSubscribed(!!subscription);
        } catch (error) {
            console.error('Error checking subscription:', error);
        }
    };

    const urlBase64ToUint8Array = (base64String) => {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');

        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);

        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    };

    const subscribeToPush = async () => {
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
            toast.error('Push notifications not supported');
            return;
        }

        try {
            setLoading(true);
            const permission = await Notification.requestPermission();
            
            if (permission !== 'granted') {
                toast.error('Notification permission denied');
                return;
            }

            const registration = await navigator.serviceWorker.ready;
            
            // You'll need to replace this with your actual VAPID public key
            const vapidPublicKey = 'YOUR_VAPID_PUBLIC_KEY';
            const convertedVapidKey = urlBase64ToUint8Array(vapidPublicKey);

            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: convertedVapidKey
            });

            // Store subscription on backend
            await base44.auth.updateMe({
                push_subscription: JSON.stringify(subscription)
            });

            setIsSubscribed(true);
            toast.success('Push notifications enabled');
        } catch (error) {
            console.error('Error subscribing to push:', error);
            toast.error('Failed to enable notifications');
        } finally {
            setLoading(false);
        }
    };

    const unsubscribeFromPush = async () => {
        try {
            setLoading(true);
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            
            if (subscription) {
                await subscription.unsubscribe();
            }

            await base44.auth.updateMe({
                push_subscription: null
            });

            setIsSubscribed(false);
            toast.success('Push notifications disabled');
        } catch (error) {
            console.error('Error unsubscribing:', error);
            toast.error('Failed to disable notifications');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Button
            onClick={isSubscribed ? unsubscribeFromPush : subscribeToPush}
            disabled={loading}
            variant="ghost"
            size="icon"
            className="text-slate-400 hover:text-white"
        >
            {isSubscribed ? <Bell className="w-5 h-5 text-cyan-400" /> : <BellOff className="w-5 h-5" />}
        </Button>
    );
}