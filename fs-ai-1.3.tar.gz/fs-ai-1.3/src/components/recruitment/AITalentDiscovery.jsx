import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, Eye, CheckCircle2, XCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import toast from 'react-hot-toast';

export default function AITalentDiscovery() {
    const queryClient = useQueryClient();

    const { data: alerts = [] } = useQuery({
        queryKey: ['ai-talent-alerts'],
        queryFn: () => base44.entities.Alert.filter({ alert_type: 'scouting_report' })
    });

    const markReadMutation = useMutation({
        mutationFn: (id) => base44.entities.Alert.update(id, { read: true }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ai-talent-alerts'] });
            toast.success('Alert marked as read');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Alert.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ai-talent-alerts'] });
            toast.success('Alert dismissed');
        }
    });

    const unreadAlerts = alerts.filter(a => !a.read);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Bell className="w-5 h-5 text-amber-400" />
                    AI Talent Discovery Alerts
                    {unreadAlerts.length > 0 && (
                        <Badge className="bg-red-500/20 text-red-400 ml-auto">
                            {unreadAlerts.length} New
                        </Badge>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                {alerts.length === 0 ? (
                    <div className="text-center py-8">
                        <Bell className="w-12 h-12 mx-auto mb-3 text-slate-600" />
                        <p className="text-slate-400">No talent alerts yet</p>
                        <p className="text-slate-500 text-sm mt-1">
                            Run the AI agent to discover new talent
                        </p>
                    </div>
                ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                        {alerts.map((alert, idx) => (
                            <motion.div
                                key={alert.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className={`p-4 rounded-lg border ${
                                    alert.read 
                                        ? 'bg-slate-800/30 border-slate-700/50' 
                                        : 'bg-amber-500/5 border-amber-500/30'
                                }`}
                            >
                                <div className="flex items-start justify-between mb-2">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <Link
                                                to={createPageUrl('PlayerProfile') + `?id=${alert.player_details?.player_id}`}
                                                className="text-white font-semibold hover:text-cyan-400 transition-colors"
                                            >
                                                {alert.player_name}
                                            </Link>
                                            {!alert.read && (
                                                <Badge className="bg-red-500/20 text-red-400 text-xs">
                                                    New
                                                </Badge>
                                            )}
                                        </div>
                                        <p className="text-slate-400 text-xs">
                                            Discovered by: {alert.criteria_name}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                            {alert.player_details?.match_score || 0}/100
                                        </Badge>
                                    </div>
                                </div>

                                {alert.player_details?.summary && (
                                    <p className="text-slate-300 text-sm mb-3 italic">
                                        "{alert.player_details.summary}"
                                    </p>
                                )}

                                <div className="flex items-center gap-2 mb-3 text-xs text-slate-400">
                                    <span>{alert.player_details?.age}y</span>
                                    <span>•</span>
                                    <span>{alert.player_details?.position}</span>
                                    <span>•</span>
                                    <span>{alert.player_details?.club}</span>
                                    {alert.player_details?.market_value && (
                                        <>
                                            <span>•</span>
                                            <span>€{alert.player_details.market_value}M</span>
                                        </>
                                    )}
                                </div>

                                {alert.player_details?.verdict && (
                                    <Badge className={
                                        alert.player_details.verdict === 'Immediate target'
                                            ? 'bg-emerald-500/20 text-emerald-400'
                                            : 'bg-amber-500/20 text-amber-400'
                                    }>
                                        {alert.player_details.verdict}
                                    </Badge>
                                )}

                                <div className="flex gap-2 mt-3 pt-3 border-t border-slate-700">
                                    {!alert.read && (
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => markReadMutation.mutate(alert.id)}
                                            className="text-xs"
                                        >
                                            <Eye className="w-3 h-3 mr-1" />
                                            Mark Read
                                        </Button>
                                    )}
                                    <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => deleteMutation.mutate(alert.id)}
                                        className="text-xs text-slate-400 hover:text-red-400"
                                    >
                                        <XCircle className="w-3 h-3 mr-1" />
                                        Dismiss
                                    </Button>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}