import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { base44 } from '@/api/base44Client';
import { Briefcase, TrendingUp, Shield, DollarSign, Loader2, ArrowRight, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function AgentFinisherPanel() {
    const [playerName, setPlayerName] = useState('');
    const [age, setAge] = useState('');
    const [position, setPosition] = useState('');
    const [currentClub, setCurrentClub] = useState('');
    const [contractYears, setContractYears] = useState('');
    const [estimatedValue, setEstimatedValue] = useState('');
    const [wageCurrent, setWageCurrent] = useState('');
    const [wageTarget, setWageTarget] = useState('');

    const [ceiling, setCeiling] = useState(75);
    const [floor, setFloor] = useState(60);
    const [fit, setFit] = useState(70);
    const [risk, setRisk] = useState(30);
    const [finalRating, setFinalRating] = useState(72);

    const [clubName, setClubName] = useState('');
    const [league, setLeague] = useState('');
    const [projectLevel, setProjectLevel] = useState('contender');
    const [wageCeiling, setWageCeiling] = useState('');
    const [transferBudget, setTransferBudget] = useState('');
    const [roleImportance, setRoleImportance] = useState('starter');

    const [riskTolerance, setRiskTolerance] = useState(0.5);

    const [decision, setDecision] = useState(null);
    const [loading, setLoading] = useState(false);

    const runFinisher = async () => {
        if (!playerName || !clubName || !estimatedValue) {
            toast.error('Player name, club name, and estimated value are required');
            return;
        }

        setLoading(true);
        try {
            const { data } = await base44.functions.invoke('agentFinisherMove', {
                player_profile: {
                    name: playerName,
                    age: age ? parseInt(age) : null,
                    position,
                    current_club: currentClub,
                    contract_years_left: contractYears ? parseFloat(contractYears) : null,
                    estimated_value: parseFloat(estimatedValue),
                    wage_current: wageCurrent ? parseFloat(wageCurrent) : 0,
                    wage_target: wageTarget ? parseFloat(wageTarget) : 0
                },
                scout_summary: {
                    ceiling,
                    floor,
                    fit,
                    risk,
                    final_rating: finalRating
                },
                club_context: {
                    club_name: clubName,
                    league,
                    project_level: projectLevel,
                    wage_ceiling: wageCeiling ? parseFloat(wageCeiling) : 0,
                    transfer_budget: transferBudget ? parseFloat(transferBudget) : 0,
                    role_importance: roleImportance
                },
                risk_tolerance: riskTolerance
            });

            setDecision(data);
            toast.success('Agent finisher decision complete');
        } catch (error) {
            toast.error('Decision failed: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const moveTypeConfig = {
        push_move: {
            color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            icon: TrendingUp,
            label: 'PUSH MOVE'
        },
        monitor: {
            color: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            icon: Shield,
            label: 'MONITOR'
        },
        wait: {
            color: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            icon: AlertCircle,
            label: 'WAIT'
        },
        stay: {
            color: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            icon: Shield,
            label: 'STAY'
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Briefcase className="w-6 h-6 text-purple-400" />
                        Agent Finisher Move
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Turn scouting intelligence into clear agent decisions with fee/wage recommendations
                    </p>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* Player Profile */}
                    <div>
                        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-cyan-400" />
                            Player Market Profile
                        </h3>
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <Input
                                placeholder="Player Name *"
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Age"
                                value={age}
                                onChange={(e) => setAge(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                placeholder="Position"
                                value={position}
                                onChange={(e) => setPosition(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                placeholder="Current Club"
                                value={currentClub}
                                onChange={(e) => setCurrentClub(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Contract Years Left"
                                value={contractYears}
                                onChange={(e) => setContractYears(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Estimated Value (£M) *"
                                value={estimatedValue}
                                onChange={(e) => setEstimatedValue(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Current Wage (£K/week)"
                                value={wageCurrent}
                                onChange={(e) => setWageCurrent(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Target Wage (£K/week)"
                                value={wageTarget}
                                onChange={(e) => setWageTarget(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                    </div>

                    {/* Scout Summary */}
                    <div>
                        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-purple-400" />
                            Scout Summary
                        </h3>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Ceiling: {ceiling}</label>
                                <Slider
                                    value={[ceiling]}
                                    onValueChange={(v) => setCeiling(v[0])}
                                    min={0}
                                    max={100}
                                    step={1}
                                    className="mb-4"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Floor: {floor}</label>
                                <Slider
                                    value={[floor]}
                                    onValueChange={(v) => setFloor(v[0])}
                                    min={0}
                                    max={100}
                                    step={1}
                                    className="mb-4"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Fit: {fit}</label>
                                <Slider
                                    value={[fit]}
                                    onValueChange={(v) => setFit(v[0])}
                                    min={0}
                                    max={100}
                                    step={1}
                                    className="mb-4"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Risk: {risk}</label>
                                <Slider
                                    value={[risk]}
                                    onValueChange={(v) => setRisk(v[0])}
                                    min={0}
                                    max={100}
                                    step={1}
                                    className="mb-4"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Final Rating: {finalRating}</label>
                                <Slider
                                    value={[finalRating]}
                                    onValueChange={(v) => setFinalRating(v[0])}
                                    min={0}
                                    max={100}
                                    step={1}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Club Context */}
                    <div>
                        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-400" />
                            Club Context
                        </h3>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <Input
                                placeholder="Club Name *"
                                value={clubName}
                                onChange={(e) => setClubName(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                placeholder="League"
                                value={league}
                                onChange={(e) => setLeague(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Select value={projectLevel} onValueChange={setProjectLevel}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="rebuild">Rebuild</SelectItem>
                                    <SelectItem value="contender">Contender</SelectItem>
                                    <SelectItem value="elite">Elite</SelectItem>
                                </SelectContent>
                            </Select>
                            <Input
                                type="number"
                                placeholder="Wage Ceiling (£K/week)"
                                value={wageCeiling}
                                onChange={(e) => setWageCeiling(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Input
                                type="number"
                                placeholder="Transfer Budget (£M)"
                                value={transferBudget}
                                onChange={(e) => setTransferBudget(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Select value={roleImportance} onValueChange={setRoleImportance}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="rotation">Rotation</SelectItem>
                                    <SelectItem value="starter">Starter</SelectItem>
                                    <SelectItem value="key piece">Key Piece</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {/* Risk Tolerance */}
                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">
                            Risk Tolerance: {(riskTolerance * 100).toFixed(0)}%
                        </label>
                        <Slider
                            value={[riskTolerance * 100]}
                            onValueChange={(v) => setRiskTolerance(v[0] / 100)}
                            min={0}
                            max={100}
                            step={5}
                        />
                    </div>

                    <Button
                        onClick={runFinisher}
                        disabled={loading}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Calculating finisher move...
                            </>
                        ) : (
                            <>
                                <Briefcase className="w-4 h-4 mr-2" />
                                Run Agent Finisher
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {decision && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-2 border-purple-500/50">
                        <CardHeader>
                            <CardTitle className="text-white text-2xl">Agent Decision</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {/* Decision Badge */}
                            <div className="flex items-center gap-4 flex-wrap">
                                <Badge className={`text-xl px-6 py-3 ${moveTypeConfig[decision.move_type].color}`}>
                                    {moveTypeConfig[decision.move_type].label}
                                </Badge>
                                <div className="flex items-center gap-2">
                                    <span className="text-slate-400">To:</span>
                                    <span className="text-2xl font-bold text-white">{decision.target_club}</span>
                                </div>
                            </div>

                            {/* Headline */}
                            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                <p className="text-white text-lg font-semibold">{decision.headline}</p>
                            </div>

                            {/* Financial Recommendations */}
                            <div className="grid md:grid-cols-2 gap-4">
                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-6">
                                        <div className="flex items-center gap-2 mb-2">
                                            <DollarSign className="w-5 h-5 text-emerald-400" />
                                            <span className="text-slate-400">Transfer Fee</span>
                                        </div>
                                        <p className="text-3xl font-bold text-emerald-400">
                                            £{decision.recommended_fee}M
                                        </p>
                                        <p className="text-slate-500 text-sm mt-1">
                                            Floor: £{decision.negotiation_floor_fee}M
                                        </p>
                                    </CardContent>
                                </Card>

                                <Card className="bg-slate-800/50 border-slate-700">
                                    <CardContent className="pt-6">
                                        <div className="flex items-center gap-2 mb-2">
                                            <TrendingUp className="w-5 h-5 text-cyan-400" />
                                            <span className="text-slate-400">Weekly Wage</span>
                                        </div>
                                        <p className="text-3xl font-bold text-cyan-400">
                                            £{decision.recommended_wage}K
                                        </p>
                                        <p className="text-slate-500 text-sm mt-1">
                                            Floor: £{decision.negotiation_floor_wage}K
                                        </p>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Analysis Scores */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Upside</p>
                                    <p className="text-2xl font-bold text-purple-400">{decision.analysis.upside}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Safety</p>
                                    <p className="text-2xl font-bold text-cyan-400">{decision.analysis.safety}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Risk OK</p>
                                    <p className={`text-2xl font-bold ${decision.analysis.safe_enough ? 'text-emerald-400' : 'text-red-400'}`}>
                                        {decision.analysis.safe_enough ? 'YES' : 'NO'}
                                    </p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Tolerance</p>
                                    <p className="text-2xl font-bold text-amber-400">
                                        {(decision.analysis.risk_tolerance * 100).toFixed(0)}%
                                    </p>
                                </div>
                            </div>

                            {/* Notes */}
                            <div className="bg-slate-800/30 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-3">Decision Notes</h4>
                                <div className="space-y-2">
                                    {decision.notes.map((note, idx) => (
                                        <div key={idx} className="flex items-start gap-2">
                                            <ArrowRight className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                                            <span className="text-slate-300 text-sm">{note}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}