import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Brain, Sparkles, Shield, CheckCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function MultiBrainAnalyzer() {
    const [playerName, setPlayerName] = useState('');
    const [age, setAge] = useState('');
    const [position, setPosition] = useState('');
    const [metrics, setMetrics] = useState('');
    const [clubStyle, setClubStyle] = useState('');
    const [targetRole, setTargetRole] = useState('');
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);

    const runAnalysis = async () => {
        if (!playerName || !position) {
            toast.error('Player name and position are required');
            return;
        }

        setLoading(true);
        try {
            const { data } = await base44.functions.invoke('multiBrainScout', {
                player_profile: {
                    name: playerName,
                    age: age ? parseInt(age) : null,
                    position,
                    metrics: metrics ? JSON.parse(metrics) : {}
                },
                context: {
                    club_style: clubStyle,
                    role: targetRole
                }
            });

            setAnalysis(data);
            toast.success('Multi-brain analysis complete');
        } catch (error) {
            toast.error('Analysis failed: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const brainConfig = {
        deep: {
            icon: Brain,
            color: 'text-cyan-400',
            bgColor: 'bg-cyan-500/20',
            borderColor: 'border-cyan-500/30',
            name: 'Deep Pattern Brain',
            description: 'Tactical intelligence & pattern recognition'
        },
        creative: {
            icon: Sparkles,
            color: 'text-purple-400',
            bgColor: 'bg-purple-500/20',
            borderColor: 'border-purple-500/30',
            name: 'Creative Vision Brain',
            description: 'Future potential & role projection'
        },
        risk: {
            icon: Shield,
            color: 'text-amber-400',
            bgColor: 'bg-amber-500/20',
            borderColor: 'border-amber-500/30',
            name: 'Cautious Risk Brain',
            description: 'Risk assessment & floor analysis'
        },
        summary: {
            icon: CheckCircle,
            color: 'text-emerald-400',
            bgColor: 'bg-emerald-500/20',
            borderColor: 'border-emerald-500/30',
            name: 'Sharp Summary Brain',
            description: 'Clear decision & key points'
        }
    };

    const decisionColors = {
        sign: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        monitor: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
        pass: 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Brain className="w-6 h-6 text-cyan-400" />
                        Multi-Brain Scouting Analysis
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Four distinct AI perspectives: Deep tactical, Creative projection, Risk assessment, and Sharp summary
                    </p>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-slate-300 text-sm mb-2 block">Player Name *</label>
                            <Input
                                placeholder="e.g., João Felix"
                                value={playerName}
                                onChange={(e) => setPlayerName(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <label className="text-slate-300 text-sm mb-2 block">Age</label>
                            <Input
                                type="number"
                                placeholder="e.g., 23"
                                value={age}
                                onChange={(e) => setAge(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Position *</label>
                        <Input
                            placeholder="e.g., Left sided eight"
                            value={position}
                            onChange={(e) => setPosition(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>

                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Metrics (JSON)</label>
                        <Textarea
                            placeholder='{"xG": 0.25, "xA": 0.22, "pressures": 19}'
                            value={metrics}
                            onChange={(e) => setMetrics(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white h-20"
                        />
                    </div>

                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Club Style</label>
                        <Input
                            placeholder="e.g., High press, aggressive counter"
                            value={clubStyle}
                            onChange={(e) => setClubStyle(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>

                    <div>
                        <label className="text-slate-300 text-sm mb-2 block">Target Role</label>
                        <Input
                            placeholder="e.g., Left eight with licence to arrive in box"
                            value={targetRole}
                            onChange={(e) => setTargetRole(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>

                    <Button
                        onClick={runAnalysis}
                        disabled={loading}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing with 4 AI brains...
                            </>
                        ) : (
                            <>
                                <Brain className="w-4 h-4 mr-2" />
                                Run Multi-Brain Analysis
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {analysis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Final Report */}
                    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-2 border-cyan-500/50">
                        <CardHeader>
                            <CardTitle className="text-white text-2xl">Final Report</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center gap-4 flex-wrap">
                                <Badge className={`text-lg px-4 py-2 ${decisionColors[analysis.final.decision]}`}>
                                    {analysis.final.decision.toUpperCase()}
                                </Badge>
                                <div className="flex items-center gap-2">
                                    <span className="text-slate-400">Rating:</span>
                                    <span className="text-3xl font-bold text-cyan-400">
                                        {analysis.final.average_rating}
                                    </span>
                                    <span className="text-slate-500">/10</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-slate-400">Confidence:</span>
                                    <span className="text-xl font-bold text-emerald-400">
                                        {(analysis.final.confidence * 100).toFixed(0)}%
                                    </span>
                                </div>
                            </div>

                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <p className="text-white text-lg font-semibold mb-2">
                                    {analysis.final.headline}
                                </p>
                                <p className="text-slate-300">
                                    {analysis.final.consensus}
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Individual Brain Views */}
                    <div className="grid md:grid-cols-2 gap-6">
                        {Object.entries(analysis.views).map(([key, view]) => {
                            const config = brainConfig[key];
                            const Icon = config.icon;

                            return (
                                <motion.div
                                    key={key}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                >
                                    <Card className={`bg-slate-900/50 border-2 ${config.borderColor}`}>
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2">
                                                <div className={`p-2 rounded-lg ${config.bgColor}`}>
                                                    <Icon className={`w-5 h-5 ${config.color}`} />
                                                </div>
                                                <div>
                                                    <p className="text-white">{config.name}</p>
                                                    <p className="text-slate-400 text-xs font-normal">
                                                        {config.description}
                                                    </p>
                                                </div>
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-3">
                                            <div className="flex items-center justify-between">
                                                <span className="text-slate-400">Rating</span>
                                                <span className={`text-2xl font-bold ${config.color}`}>
                                                    {view.rating?.toFixed(1) || 'N/A'}/10
                                                </span>
                                            </div>

                                            <div className={`p-3 rounded-lg ${config.bgColor}`}>
                                                <p className="text-slate-200 text-sm">{view.summary}</p>
                                            </div>

                                            {view.notes && view.notes.length > 0 && (
                                                <div className="space-y-1">
                                                    {view.notes.map((note, idx) => (
                                                        <div key={idx} className="flex items-start gap-2">
                                                            <span className={`text-xs ${config.color} mt-1`}>•</span>
                                                            <span className="text-slate-300 text-sm">{note}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}

                                            {/* Extra fields */}
                                            {view.tactical_iq && (
                                                <div className="pt-2 border-t border-slate-700">
                                                    <span className="text-slate-400 text-xs">Tactical IQ: </span>
                                                    <span className="text-white font-semibold">{view.tactical_iq}/10</span>
                                                </div>
                                            )}
                                            {view.ceiling && (
                                                <div className="pt-2 border-t border-slate-700">
                                                    <span className="text-slate-400 text-xs">Ceiling: </span>
                                                    <span className="text-white font-semibold">{view.ceiling}/10</span>
                                                </div>
                                            )}
                                            {view.risk_level && (
                                                <div className="pt-2 border-t border-slate-700">
                                                    <span className="text-slate-400 text-xs">Risk: </span>
                                                    <Badge className={
                                                        view.risk_level === 'low' ? 'bg-emerald-500/20 text-emerald-400' :
                                                        view.risk_level === 'medium' ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-red-500/20 text-red-400'
                                                    }>
                                                        {view.risk_level}
                                                    </Badge>
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            );
                        })}
                    </div>
                </motion.div>
            )}
        </div>
    );
}