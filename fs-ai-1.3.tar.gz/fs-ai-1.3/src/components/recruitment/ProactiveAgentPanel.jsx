import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Sparkles, Loader2, Target, TrendingUp, AlertCircle, CheckCircle2, Play } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ProactiveAgentPanel() {
    const [running, setRunning] = useState(false);
    const [results, setResults] = useState(null);

    const runAgent = async () => {
        setRunning(true);
        toast.loading('AI Agent scanning player database...', { id: 'agent' });

        try {
            const response = await base44.functions.invoke('proactiveRecruitmentAgent');
            
            if (response.data.success) {
                setResults(response.data);
                toast.success(`Found ${response.data.shortlist.length} high-priority targets!`, { id: 'agent' });
            } else {
                toast.error('Agent scan completed with no matches', { id: 'agent' });
            }
        } catch (error) {
            toast.error('Agent failed to complete scan', { id: 'agent' });
            console.error(error);
        } finally {
            setRunning(false);
        }
    };

    const verdictColors = {
        'Immediate target': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Monitor': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Pass': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Recruitment Agent
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-slate-300 text-sm">
                        Automated AI agent that scans your player database against active recruitment criteria, 
                        generates reports, and creates tasks for promising targets.
                    </p>

                    <Button
                        onClick={runAgent}
                        disabled={running}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                        size="lg"
                    >
                        {running ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                AI Agent Running...
                            </>
                        ) : (
                            <>
                                <Play className="w-5 h-5 mr-2" />
                                Run AI Recruitment Agent
                            </>
                        )}
                    </Button>

                    {results && (
                        <div className="grid grid-cols-3 gap-4 pt-4">
                            <div className="text-center">
                                <p className="text-2xl font-bold text-white">{results.players_analyzed}</p>
                                <p className="text-slate-400 text-xs">Players Analyzed</p>
                            </div>
                            <div className="text-center">
                                <p className="text-2xl font-bold text-emerald-400">{results.shortlist.length}</p>
                                <p className="text-slate-400 text-xs">Shortlisted</p>
                            </div>
                            <div className="text-center">
                                <p className="text-2xl font-bold text-purple-400">{results.criteria_processed}</p>
                                <p className="text-slate-400 text-xs">Criteria Used</p>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {results?.shortlist && results.shortlist.length > 0 && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                >
                    <div className="flex items-center justify-between">
                        <h3 className="text-white font-semibold text-lg">High Priority Shortlist</h3>
                        <Badge className="bg-emerald-500/20 text-emerald-400">
                            <Target className="w-3 h-3 mr-1" />
                            {results.shortlist.length} Targets
                        </Badge>
                    </div>

                    {results.shortlist.map((player, idx) => (
                        <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 }}
                        >
                            <Card className="bg-slate-900/50 border-slate-800 hover:border-purple-500/50 transition-colors">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-4">
                                        <div>
                                            <h4 className="text-white font-bold text-lg">{player.player_name}</h4>
                                            <p className="text-slate-400 text-sm">Criteria: {player.criterion}</p>
                                        </div>
                                        <div className="text-right">
                                            <div className="flex items-center gap-2 mb-1">
                                                <TrendingUp className="w-4 h-4 text-emerald-400" />
                                                <span className="text-2xl font-bold text-white">{player.match_score}</span>
                                            </div>
                                            <p className="text-slate-400 text-xs">Match Score</p>
                                        </div>
                                    </div>

                                    <div className="mb-3">
                                        <Progress value={player.match_score} className="h-2" />
                                    </div>

                                    <div className="flex items-center gap-2 mb-3">
                                        <Badge className={verdictColors[player.verdict]}>
                                            {player.verdict}
                                        </Badge>
                                        {player.task_created && (
                                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                                Task Created
                                            </Badge>
                                        )}
                                        {player.alert_created && (
                                            <Badge className="bg-amber-500/20 text-amber-400">
                                                <AlertCircle className="w-3 h-3 mr-1" />
                                                Alert Sent
                                            </Badge>
                                        )}
                                    </div>

                                    <p className="text-slate-300 text-sm mb-3 italic">"{player.summary}"</p>

                                    <div className="grid md:grid-cols-2 gap-3">
                                        <div>
                                            <p className="text-emerald-400 text-xs font-semibold mb-1">Strengths:</p>
                                            <ul className="space-y-1">
                                                {player.strengths.map((strength, i) => (
                                                    <li key={i} className="text-slate-300 text-xs flex items-start gap-1">
                                                        <span className="text-emerald-400">✓</span>
                                                        {strength}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div>
                                            <p className="text-amber-400 text-xs font-semibold mb-1">Concerns:</p>
                                            <ul className="space-y-1">
                                                {player.concerns.map((concern, i) => (
                                                    <li key={i} className="text-slate-300 text-xs flex items-start gap-1">
                                                        <span className="text-amber-400">⚠</span>
                                                        {concern}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </motion.div>
            )}
        </div>
    );
}