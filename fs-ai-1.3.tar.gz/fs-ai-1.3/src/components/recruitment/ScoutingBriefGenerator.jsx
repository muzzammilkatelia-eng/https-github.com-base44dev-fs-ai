import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FileText, Loader2, Download, Calendar, UserPlus } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import toast from 'react-hot-toast';

export default function ScoutingBriefGenerator() {
    const [profile, setProfile] = useState({
        position: '',
        age_range: '',
        key_attributes: '',
        tactical_requirements: '',
        budget_range: '',
        target_leagues: '',
        player_archetype: '',
        club_style: '',
        priority_traits: '',
        custom_criteria: ''
    });
    const [brief, setBrief] = useState(null);
    const [loading, setLoading] = useState(false);
    const [showScheduling, setShowScheduling] = useState(false);
    const [schedulingData, setSchedulingData] = useState({
        follow_up_type: 'Live Match',
        assigned_to: '',
        due_date: '',
        priority: 'Medium'
    });

    const generateBrief = async () => {
        if (!profile.position) {
            toast.error('Position is required');
            return;
        }

        setLoading(true);
        toast.loading('AI generating scouting brief...', { id: 'brief' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football recruitment analyst. Generate a comprehensive scouting brief for the following player profile:

**Position:** ${profile.position}
**Age Range:** ${profile.age_range || 'Any'}
**Player Archetype:** ${profile.player_archetype || 'Versatile'}
**Club Style:** ${profile.club_style || 'Flexible tactical approach'}
**Key Attributes Required:** ${profile.key_attributes || 'General excellence'}
**Priority Traits:** ${profile.priority_traits || 'Well-rounded'}
**Tactical Requirements:** ${profile.tactical_requirements || 'Versatile'}
**Budget Range:** €${profile.budget_range || 'Flexible'}M
**Target Leagues:** ${profile.target_leagues || 'Top European leagues'}
**Custom Criteria:** ${profile.custom_criteria || 'None specified'}

Generate a professional scouting brief document with these sections:

# Scouting Brief: ${profile.position}

## 1. Player Profile Overview
- Position and role requirements
- Age profile and experience level
- Physical and technical requirements

## 2. Key Performance Indicators
- Essential technical skills to evaluate
- Physical attributes to assess
- Tactical intelligence markers
- Mental/character traits to look for

## 3. Ideal Player Archetype
- Playing style description based on: ${profile.player_archetype || 'versatile profile'}
- Tactical versatility requirements
- System compatibility with: ${profile.club_style || 'multiple systems'}
- DNA fit with club identity

## 4. Scouting Checklist
Specific things scouts should observe:
- In possession behaviors
- Out of possession work
- Decision-making patterns
- Leadership and communication

## 5. Red Flags to Avoid
- Technical limitations that are dealbreakers
- Tactical incompatibilities
- Character/behavioral concerns
- Injury history warnings

## 6. Market Intelligence
- Target leagues and clubs to monitor
- Expected price range
- Contract situation preferences
- Competition for similar profiles

## 7. Recommended Assessment Process
- Number of live viewings suggested
- Key matches/situations to observe
- Data points to collect
- Timeline for decision

## 8. Follow-Up Actions
- Recommended scouting task type (Initial Assessment / Deep Dive / Live Match)
- Suggested priority level
- Ideal timeframe for completion
- Monitoring frequency recommendations

Be detailed, professional, and actionable. Use markdown formatting. Consider the custom criteria: ${profile.custom_criteria || 'None'}.`,
                add_context_from_internet: false
            });

            setBrief(result);
            setShowScheduling(true);
            toast.success('Brief generated!', { id: 'brief' });
        } catch (error) {
            toast.error('Generation failed', { id: 'brief' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const scheduleFollowUp = async () => {
        try {
            await base44.entities.ScoutingTask.create({
                player_name: `${profile.position} Target`,
                assigned_to: schedulingData.assigned_to,
                task_type: schedulingData.follow_up_type,
                priority: schedulingData.priority,
                status: 'Pending',
                source: 'AI Flag',
                criteria_met: [
                    `Position: ${profile.position}`,
                    `Age: ${profile.age_range}`,
                    `Archetype: ${profile.player_archetype}`
                ].filter(c => !c.includes('undefined')),
                player_data: {
                    position: profile.position,
                    age: profile.age_range ? parseInt(profile.age_range.split('-')[0]) : null
                },
                due_date: schedulingData.due_date,
                notes: `Generated from scouting brief. Key attributes: ${profile.key_attributes}`
            });
            
            toast.success('Follow-up task scheduled!');
            setShowScheduling(false);
        } catch (error) {
            toast.error('Failed to schedule task');
            console.error(error);
        }
    };

    const downloadBrief = () => {
        if (!brief) return;
        
        const blob = new Blob([brief], { type: 'text/markdown' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `scouting-brief-${profile.position}-${Date.now()}.md`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success('Brief downloaded!');
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-amber-400" />
                    AI Scouting Brief Generator
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                    <div>
                        <Label className="text-slate-300">Position *</Label>
                        <Input
                            value={profile.position}
                            onChange={(e) => setProfile({...profile, position: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Central Midfielder"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Age Range</Label>
                        <Input
                            value={profile.age_range}
                            onChange={(e) => setProfile({...profile, age_range: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 20-25"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Player Archetype</Label>
                        <Input
                            value={profile.player_archetype}
                            onChange={(e) => setProfile({...profile, player_archetype: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Deep-lying playmaker, Box-to-box"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Club Style</Label>
                        <Input
                            value={profile.club_style}
                            onChange={(e) => setProfile({...profile, club_style: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., High press, possession-based"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Budget Range (€M)</Label>
                        <Input
                            value={profile.budget_range}
                            onChange={(e) => setProfile({...profile, budget_range: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 15-30"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Target Leagues</Label>
                        <Input
                            value={profile.target_leagues}
                            onChange={(e) => setProfile({...profile, target_leagues: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Bundesliga, Ligue 1"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Key Attributes</Label>
                        <Textarea
                            value={profile.key_attributes}
                            onChange={(e) => setProfile({...profile, key_attributes: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Excellent passing, high work rate"
                            rows={2}
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Priority Traits</Label>
                        <Textarea
                            value={profile.priority_traits}
                            onChange={(e) => setProfile({...profile, priority_traits: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Leadership, adaptability"
                            rows={2}
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Tactical Requirements</Label>
                        <Textarea
                            value={profile.tactical_requirements}
                            onChange={(e) => setProfile({...profile, tactical_requirements: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Must fit 4-3-3, pressing system"
                            rows={2}
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Custom Criteria</Label>
                        <Textarea
                            value={profile.custom_criteria}
                            onChange={(e) => setProfile({...profile, custom_criteria: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Must be available on free transfer, speaks English"
                            rows={2}
                        />
                    </div>
                </div>

                <Button
                    onClick={generateBrief}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating...
                        </>
                    ) : (
                        <>
                            <FileText className="w-4 h-4 mr-2" />
                            Generate Scouting Brief
                        </>
                    )}
                </Button>

                {brief && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4 pt-4"
                    >
                        <div className="flex justify-end gap-2">
                            <Button
                                onClick={downloadBrief}
                                variant="outline"
                                className="border-slate-700"
                            >
                                <Download className="w-4 h-4 mr-2" />
                                Download Brief
                            </Button>
                            <Button
                                onClick={() => setShowScheduling(!showScheduling)}
                                className="bg-cyan-600 hover:bg-cyan-700"
                            >
                                <Calendar className="w-4 h-4 mr-2" />
                                Schedule Follow-Up
                            </Button>
                        </div>

                        {showScheduling && (
                            <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-4"
                            >
                                <h4 className="text-white font-semibold flex items-center gap-2">
                                    <UserPlus className="w-4 h-4 text-cyan-400" />
                                    Schedule Scouting Task
                                </h4>
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <Label className="text-slate-300">Task Type</Label>
                                        <Select 
                                            value={schedulingData.follow_up_type}
                                            onValueChange={(v) => setSchedulingData({...schedulingData, follow_up_type: v})}
                                        >
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Initial Assessment">Initial Assessment</SelectItem>
                                                <SelectItem value="Deep Dive">Deep Dive</SelectItem>
                                                <SelectItem value="Live Match">Live Match</SelectItem>
                                                <SelectItem value="Contract Negotiation">Contract Negotiation</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Priority</Label>
                                        <Select 
                                            value={schedulingData.priority}
                                            onValueChange={(v) => setSchedulingData({...schedulingData, priority: v})}
                                        >
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Critical">Critical</SelectItem>
                                                <SelectItem value="High">High</SelectItem>
                                                <SelectItem value="Medium">Medium</SelectItem>
                                                <SelectItem value="Low">Low</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Assign To (Email)</Label>
                                        <Input
                                            value={schedulingData.assigned_to}
                                            onChange={(e) => setSchedulingData({...schedulingData, assigned_to: e.target.value})}
                                            className="bg-slate-800 border-slate-700 text-white"
                                            placeholder="scout@club.com"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Due Date</Label>
                                        <Input
                                            type="date"
                                            value={schedulingData.due_date}
                                            onChange={(e) => setSchedulingData({...schedulingData, due_date: e.target.value})}
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>
                                </div>
                                <Button
                                    onClick={scheduleFollowUp}
                                    className="w-full bg-emerald-600 hover:bg-emerald-700"
                                >
                                    <Calendar className="w-4 h-4 mr-2" />
                                    Create Scouting Task
                                </Button>
                            </motion.div>
                        )}

                        <div className="bg-slate-800/50 rounded-lg p-6 max-h-[600px] overflow-y-auto">
                            <ReactMarkdown className="prose prose-invert prose-sm max-w-none">
                                {brief}
                            </ReactMarkdown>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}