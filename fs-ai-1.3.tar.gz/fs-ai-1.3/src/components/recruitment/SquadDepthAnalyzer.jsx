import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Loader2, AlertTriangle, CheckCircle2, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function SquadDepthAnalyzer() {
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-squad'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const analyzeSquad = async () => {
        if (players.length === 0) {
            toast.error('No players in database');
            return;
        }

        setLoading(true);
        toast.loading('AI analyzing squad depth...', { id: 'analyze' });

        try {
            // Group players by position
            const positionGroups = players.reduce((acc, player) => {
                const pos = player.position || 'Unknown';
                if (!acc[pos]) acc[pos] = [];
                acc[pos].push({
                    name: player.name,
                    age: player.age,
                    rating: player.fsai_proprietary_score || 75,
                    injury_risk: player.injury_prone_score || 0
                });
                return acc;
            }, {});

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football squad analyst. Analyze this squad's depth across all positions:

${Object.entries(positionGroups).map(([pos, players]) => 
    `**${pos}** (${players.length} players):\n${players.map(p => 
        `- ${p.name} (${p.age}y, Rating: ${p.rating}/100, Injury Risk: ${p.injury_risk}/100)`
    ).join('\n')}`
).join('\n\n')}

Provide:
1. **Position-by-Position Assessment**: For each position, assess if depth is "Excellent", "Good", "Adequate", "Weak", or "Critical"
2. **Priority Needs**: Top 3 positions that need reinforcement
3. **Strengths**: Top 3 positions with excellent depth
4. **Age Profile Concerns**: Positions with aging squads (avg age > 29)
5. **Injury Risk Areas**: Positions with high collective injury risk
6. **Recommendations**: 3-5 specific recruitment recommendations

Return as JSON with these keys: position_assessments (array of {position, depth_rating, player_count, avg_age, concerns}), priority_needs (array), strengths (array), age_concerns (array), injury_risks (array), recommendations (array of strings)`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: "object",
                    properties: {
                        position_assessments: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    depth_rating: { type: "string" },
                                    player_count: { type: "number" },
                                    avg_age: { type: "number" },
                                    concerns: { type: "string" }
                                }
                            }
                        },
                        priority_needs: { type: "array", items: { type: "string" } },
                        strengths: { type: "array", items: { type: "string" } },
                        age_concerns: { type: "array", items: { type: "string" } },
                        injury_risks: { type: "array", items: { type: "string" } },
                        recommendations: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis(result);
            toast.success('Analysis complete!', { id: 'analyze' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'analyze' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const depthColors = {
        'Excellent': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Good': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        'Adequate': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Weak': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
        'Critical': 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-400" />
                    Squad Depth Analysis
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <p className="text-slate-400">
                        Analyzing {players.length} players across all positions
                    </p>
                    <Button
                        onClick={analyzeSquad}
                        disabled={loading || players.length === 0}
                        className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Users className="w-4 h-4 mr-2" />
                                Analyze Squad
                            </>
                        )}
                    </Button>
                </div>

                {analysis && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6 pt-4"
                    >
                        {/* Position Assessments */}
                        <div className="space-y-3">
                            <h3 className="text-white font-semibold">Position-by-Position Assessment</h3>
                            <div className="grid md:grid-cols-2 gap-3">
                                {analysis.position_assessments?.map((pos, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: 0.05 * idx }}
                                        className="bg-slate-800/50 rounded-lg p-4"
                                    >
                                        <div className="flex items-start justify-between mb-2">
                                            <h4 className="text-white font-semibold">{pos.position}</h4>
                                            <Badge className={depthColors[pos.depth_rating]}>
                                                {pos.depth_rating}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center gap-3 text-sm text-slate-400 mb-2">
                                            <span>{pos.player_count} players</span>
                                            <span>•</span>
                                            <span>Avg age: {pos.avg_age}y</span>
                                        </div>
                                        {pos.concerns && (
                                            <p className="text-slate-300 text-xs">{pos.concerns}</p>
                                        )}
                                    </motion.div>
                                ))}
                            </div>
                        </div>

                        {/* Priority Needs */}
                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                            <h4 className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4" />
                                Priority Recruitment Needs
                            </h4>
                            <ul className="space-y-1">
                                {analysis.priority_needs?.map((need, idx) => (
                                    <li key={idx} className="text-red-300 text-sm">• {need}</li>
                                ))}
                            </ul>
                        </div>

                        {/* Strengths */}
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h4 className="text-emerald-400 font-semibold mb-2 flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4" />
                                Squad Strengths
                            </h4>
                            <ul className="space-y-1">
                                {analysis.strengths?.map((strength, idx) => (
                                    <li key={idx} className="text-emerald-300 text-sm">• {strength}</li>
                                ))}
                            </ul>
                        </div>

                        {/* Age & Injury Concerns */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                <h4 className="text-amber-400 font-semibold mb-2 text-sm">Age Profile Concerns</h4>
                                <ul className="space-y-1">
                                    {analysis.age_concerns?.map((concern, idx) => (
                                        <li key={idx} className="text-amber-300 text-xs">• {concern}</li>
                                    ))}
                                </ul>
                            </div>
                            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                                <h4 className="text-orange-400 font-semibold mb-2 text-sm">Injury Risk Areas</h4>
                                <ul className="space-y-1">
                                    {analysis.injury_risks?.map((risk, idx) => (
                                        <li key={idx} className="text-orange-300 text-xs">• {risk}</li>
                                    ))}
                                </ul>
                            </div>
                        </div>

                        {/* Recommendations */}
                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <h4 className="text-cyan-400 font-semibold mb-3 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4" />
                                Strategic Recommendations
                            </h4>
                            <ul className="space-y-2">
                                {analysis.recommendations?.map((rec, idx) => (
                                    <li key={idx} className="text-slate-300 text-sm leading-relaxed">
                                        {idx + 1}. {rec}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}