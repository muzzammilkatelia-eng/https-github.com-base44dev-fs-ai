import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Play, Loader2, TrendingUp, Users, DollarSign, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TransferScenarioSimulator() {
    const [scenario, setScenario] = useState({
        incoming: [],
        outgoing: [],
        budget_impact: 0
    });
    const [simulation, setSimulation] = useState(null);
    const [loading, setLoading] = useState(false);
    const [selectedIn, setSelectedIn] = useState('');
    const [selectedOut, setSelectedOut] = useState('');
    const [incomingFee, setIncomingFee] = useState('');
    const [outgoingFee, setOutgoingFee] = useState('');

    const { data: players = [] } = useQuery({
        queryKey: ['players-scenario'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const addIncoming = () => {
        if (!selectedIn || !incomingFee) {
            toast.error('Select player and enter fee');
            return;
        }
        const player = players.find(p => p.id === selectedIn);
        setScenario({
            ...scenario,
            incoming: [...scenario.incoming, { player, fee: parseFloat(incomingFee) }],
            budget_impact: scenario.budget_impact - parseFloat(incomingFee)
        });
        setSelectedIn('');
        setIncomingFee('');
    };

    const addOutgoing = () => {
        if (!selectedOut || !outgoingFee) {
            toast.error('Select player and enter fee');
            return;
        }
        const player = players.find(p => p.id === selectedOut);
        setScenario({
            ...scenario,
            outgoing: [...scenario.outgoing, { player, fee: parseFloat(outgoingFee) }],
            budget_impact: scenario.budget_impact + parseFloat(outgoingFee)
        });
        setSelectedOut('');
        setOutgoingFee('');
    };

    const simulateImpact = async () => {
        if (scenario.incoming.length === 0 && scenario.outgoing.length === 0) {
            toast.error('Add at least one transfer');
            return;
        }

        setLoading(true);
        toast.loading('AI simulating impact...', { id: 'sim' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football squad analyst. Simulate the impact of these transfers:

**INCOMING TRANSFERS:**
${scenario.incoming.map(t => 
    `- ${t.player.name} (${t.player.position}, ${t.player.age}y) for €${t.fee}M from ${t.player.current_club}`
).join('\n') || 'None'}

**OUTGOING TRANSFERS:**
${scenario.outgoing.map(t => 
    `- ${t.player.name} (${t.player.position}, ${t.player.age}y) for €${t.fee}M`
).join('\n') || 'None'}

**Net Budget Impact:** ${scenario.budget_impact >= 0 ? '+' : ''}€${scenario.budget_impact}M

Analyze:
1. **Squad Balance Impact**: How does this affect squad depth and balance?
2. **Tactical Impact**: Formation flexibility, tactical options gained/lost
3. **Financial Assessment**: Value for money, financial sustainability
4. **Age Profile**: Impact on squad age and experience
5. **Risk Analysis**: Potential issues with these moves
6. **Overall Rating**: Rate the transfer window 0-100
7. **Recommendations**: 2-3 suggestions to improve the window

Return as JSON with these keys: squad_balance, tactical_impact, financial_assessment, age_profile, risk_analysis, overall_rating, recommendations (array)`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: "object",
                    properties: {
                        squad_balance: { type: "string" },
                        tactical_impact: { type: "string" },
                        financial_assessment: { type: "string" },
                        age_profile: { type: "string" },
                        risk_analysis: { type: "string" },
                        overall_rating: { type: "number" },
                        recommendations: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setSimulation(result);
            toast.success('Simulation complete!', { id: 'sim' });
        } catch (error) {
            toast.error('Simulation failed', { id: 'sim' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Play className="w-5 h-5 text-emerald-400" />
                    Transfer Scenario Simulator
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Incoming Transfers */}
                <div className="bg-slate-800/30 rounded-lg p-4 space-y-3">
                    <h4 className="text-emerald-400 font-semibold">Incoming Transfers</h4>
                    <div className="grid md:grid-cols-3 gap-3">
                        <Select value={selectedIn} onValueChange={setSelectedIn}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} ({p.position})
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Input
                            type="number"
                            value={incomingFee}
                            onChange={(e) => setIncomingFee(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="Transfer fee (€M)"
                        />
                        <Button onClick={addIncoming} className="bg-emerald-600">Add</Button>
                    </div>
                    {scenario.incoming.length > 0 && (
                        <div className="space-y-2">
                            {scenario.incoming.map((t, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-slate-700/50 rounded p-2">
                                    <span className="text-white text-sm">{t.player.name}</span>
                                    <Badge className="bg-emerald-500/20 text-emerald-400">€{t.fee}M</Badge>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Outgoing Transfers */}
                <div className="bg-slate-800/30 rounded-lg p-4 space-y-3">
                    <h4 className="text-red-400 font-semibold">Outgoing Transfers</h4>
                    <div className="grid md:grid-cols-3 gap-3">
                        <Select value={selectedOut} onValueChange={setSelectedOut}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} ({p.position})
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Input
                            type="number"
                            value={outgoingFee}
                            onChange={(e) => setOutgoingFee(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="Sale price (€M)"
                        />
                        <Button onClick={addOutgoing} className="bg-red-600">Add</Button>
                    </div>
                    {scenario.outgoing.length > 0 && (
                        <div className="space-y-2">
                            {scenario.outgoing.map((t, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-slate-700/50 rounded p-2">
                                    <span className="text-white text-sm">{t.player.name}</span>
                                    <Badge className="bg-red-500/20 text-red-400">€{t.fee}M</Badge>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Budget Impact */}
                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                        <span className="text-slate-300">Net Budget Impact</span>
                        <span className={`text-2xl font-bold ${scenario.budget_impact >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                            {scenario.budget_impact >= 0 ? '+' : ''}€{scenario.budget_impact}M
                        </span>
                    </div>
                </div>

                <Button
                    onClick={simulateImpact}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Simulating...
                        </>
                    ) : (
                        <>
                            <Play className="w-4 h-4 mr-2" />
                            Simulate Impact
                        </>
                    )}
                </Button>

                {simulation && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4 pt-4"
                    >
                        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
                            <h3 className="text-white font-semibold mb-2">Overall Window Rating</h3>
                            <div className="flex items-center gap-3">
                                <div className="text-4xl font-bold text-purple-400">{simulation.overall_rating}/100</div>
                                <Badge className={
                                    simulation.overall_rating >= 80 ? 'bg-emerald-500/20 text-emerald-400' :
                                    simulation.overall_rating >= 60 ? 'bg-blue-500/20 text-blue-400' :
                                    'bg-amber-500/20 text-amber-400'
                                }>
                                    {simulation.overall_rating >= 80 ? 'Excellent' : simulation.overall_rating >= 60 ? 'Good' : 'Needs Work'}
                                </Badge>
                            </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
                                    <Users className="w-4 h-4" />
                                    Squad Balance
                                </h4>
                                <p className="text-slate-300 text-sm">{simulation.squad_balance}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-blue-400 font-semibold mb-2 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4" />
                                    Tactical Impact
                                </h4>
                                <p className="text-slate-300 text-sm">{simulation.tactical_impact}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-amber-400 font-semibold mb-2 flex items-center gap-2">
                                    <DollarSign className="w-4 h-4" />
                                    Financial Assessment
                                </h4>
                                <p className="text-slate-300 text-sm">{simulation.financial_assessment}</p>
                            </div>
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-purple-400 font-semibold mb-2">Age Profile</h4>
                                <p className="text-slate-300 text-sm">{simulation.age_profile}</p>
                            </div>
                        </div>

                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                            <h4 className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4" />
                                Risk Analysis
                            </h4>
                            <p className="text-slate-300 text-sm">{simulation.risk_analysis}</p>
                        </div>

                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h4 className="text-emerald-400 font-semibold mb-2">Recommendations</h4>
                            <ul className="space-y-1">
                                {simulation.recommendations?.map((rec, idx) => (
                                    <li key={idx} className="text-slate-300 text-sm">• {rec}</li>
                                ))}
                            </ul>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}