import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Target, Loader2, TrendingUp, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TransferTargetEngine() {
    const [criteria, setCriteria] = useState({
        position: '',
        max_budget: '',
        max_age: '',
        min_rating: '',
        playstyle: '',
        tactical_role: ''
    });
    const [recommendations, setRecommendations] = useState(null);
    const [loading, setLoading] = useState(false);

    const findTargets = async () => {
        if (!criteria.position || !criteria.max_budget) {
            toast.error('Position and budget are required');
            return;
        }

        setLoading(true);
        toast.loading('AI searching for targets...', { id: 'search' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football recruitment director. Find the best transfer targets based on these requirements:

**Position Needed:** ${criteria.position}
**Maximum Budget:** €${criteria.max_budget}M
**Maximum Age:** ${criteria.max_age || 'No limit'}
**Minimum Rating:** ${criteria.min_rating || 'Any'}/100
**Preferred Playstyle:** ${criteria.playstyle || 'Any'}
**Tactical Role:** ${criteria.tactical_role || 'Any'}

Based on current football knowledge (Premier League, La Liga, Serie A, Bundesliga, Ligue 1, and other top leagues), recommend 5 realistic transfer targets.

For each player provide:
- name: Full name
- age: Current age
- current_club: Club they play for
- league: Current league
- estimated_value: Market value in millions
- rating: Overall rating out of 100
- strengths: Array of 3-4 key strengths
- fit_score: How well they fit the requirements (0-100)
- transfer_feasibility: "Easy", "Moderate", "Difficult", or "Very Difficult"
- why_ideal: 2-3 sentences explaining why they're a great fit

Return as JSON array of 5 players.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            name: { type: "string" },
                            age: { type: "number" },
                            current_club: { type: "string" },
                            league: { type: "string" },
                            estimated_value: { type: "number" },
                            rating: { type: "number" },
                            strengths: { type: "array", items: { type: "string" } },
                            fit_score: { type: "number" },
                            transfer_feasibility: { type: "string" },
                            why_ideal: { type: "string" }
                        }
                    }
                }
            });

            setRecommendations(result);
            toast.success(`Found ${result.length} targets!`, { id: 'search' });
        } catch (error) {
            toast.error('Search failed', { id: 'search' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const feasibilityColors = {
        'Easy': 'bg-emerald-500/20 text-emerald-400',
        'Moderate': 'bg-blue-500/20 text-blue-400',
        'Difficult': 'bg-amber-500/20 text-amber-400',
        'Very Difficult': 'bg-red-500/20 text-red-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-cyan-400" />
                    Transfer Target Recommendation Engine
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                    <div>
                        <Label className="text-slate-300">Position Needed *</Label>
                        <Select value={criteria.position} onValueChange={(v) => setCriteria({...criteria, position: v})}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select position..." />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                <SelectItem value="Full-Back">Full-Back</SelectItem>
                                <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                <SelectItem value="Winger">Winger</SelectItem>
                                <SelectItem value="Striker">Striker</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div>
                        <Label className="text-slate-300">Max Budget (€M) *</Label>
                        <Input
                            type="number"
                            value={criteria.max_budget}
                            onChange={(e) => setCriteria({...criteria, max_budget: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 50"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-300">Max Age</Label>
                        <Input
                            type="number"
                            value={criteria.max_age}
                            onChange={(e) => setCriteria({...criteria, max_age: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 25"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-300">Preferred Playstyle</Label>
                        <Input
                            value={criteria.playstyle}
                            onChange={(e) => setCriteria({...criteria, playstyle: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Possession-based"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-300">Tactical Role</Label>
                        <Input
                            value={criteria.tactical_role}
                            onChange={(e) => setCriteria({...criteria, tactical_role: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Deep-lying playmaker"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-300">Min Rating (/100)</Label>
                        <Input
                            type="number"
                            value={criteria.min_rating}
                            onChange={(e) => setCriteria({...criteria, min_rating: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 75"
                        />
                    </div>
                </div>

                <Button
                    onClick={findTargets}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Searching...
                        </>
                    ) : (
                        <>
                            <Target className="w-4 h-4 mr-2" />
                            Find Transfer Targets
                        </>
                    )}
                </Button>

                {recommendations && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-3 pt-4"
                    >
                        <h3 className="text-white font-semibold">Recommended Targets ({recommendations.length})</h3>
                        {recommendations.map((player, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h4 className="text-white font-bold text-lg">{player.name}</h4>
                                        <p className="text-slate-400 text-sm">
                                            {player.age}y • {player.current_club} • {player.league}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <Badge className="bg-cyan-500/20 text-cyan-400 mb-1">
                                            Fit: {player.fit_score}/100
                                        </Badge>
                                        <p className="text-amber-400 font-bold text-lg">€{player.estimated_value}M</p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Badge className={feasibilityColors[player.transfer_feasibility]}>
                                        {player.transfer_feasibility}
                                    </Badge>
                                    <Badge className="bg-blue-500/20 text-blue-400">
                                        Rating: {player.rating}/100
                                    </Badge>
                                </div>

                                <div>
                                    <p className="text-emerald-400 text-xs font-semibold mb-1">Key Strengths:</p>
                                    <div className="flex flex-wrap gap-1">
                                        {player.strengths?.map((strength, i) => (
                                            <span key={i} className="text-xs text-slate-300 bg-slate-700/50 px-2 py-1 rounded">
                                                {strength}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <p className="text-slate-300 text-sm leading-relaxed">{player.why_ideal}</p>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}