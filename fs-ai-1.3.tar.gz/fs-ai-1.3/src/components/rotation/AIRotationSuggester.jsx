import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Users, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AIRotationSuggester() {
    const [isGenerating, setIsGenerating] = useState(false);
    const [suggestions, setSuggestions] = useState(null);
    const [selectedFixture, setSelectedFixture] = useState(null);

    const { data: fixtures = [] } = useQuery({
        queryKey: ['fixtures'],
        queryFn: () => base44.entities.Fixture.list()
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: workloads = [] } = useQuery({
        queryKey: ['workloads'],
        queryFn: () => base44.entities.PlayerWorkload.list()
    });

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const upcomingFixtures = fixtures
        .filter(f => f.status !== 'Completed' && new Date(f.match_date) >= new Date())
        .sort((a, b) => new Date(a.match_date) - new Date(b.match_date))
        .slice(0, 5);

    const generateRotationPlan = async (fixture) => {
        setIsGenerating(true);
        setSelectedFixture(fixture);
        toast.loading('Generating optimal rotation plan...', { id: 'rotation' });

        try {
            const playersWithWorkload = players.map(p => {
                const workload = workloads.find(w => w.player_id === p.id);
                return { ...p, workload };
            });

            const prompt = `You are an elite football rotation and squad management AI. Generate an optimal lineup and rotation strategy:

Upcoming Match:
- Opponent: ${fixture.opponent}
- Competition: ${fixture.competition}
- Importance: ${fixture.importance}
- Venue: ${fixture.venue}
- Date: ${new Date(fixture.match_date).toLocaleDateString()}

Team Strategy: ${activeStrategy ? `${activeStrategy.formation} - ${activeStrategy.playing_style}` : 'Not defined'}

Available Squad (${playersWithWorkload.length} players):
${playersWithWorkload.slice(0, 25).map(p => `
- ${p.name} (${p.position}, Age: ${p.age}, Rating: ${p.fsai_proprietary_score || 'N/A'})
  Availability: ${p.workload?.availability || 'Available'}
  Fatigue: ${p.workload?.fatigue_level || 0}%
  Minutes (7d): ${p.workload?.minutes_played_7d || 0}
  Injury Risk: ${p.workload?.injury_risk || 'Low'}
`).join('')}

Next 3 Fixtures after this:
${upcomingFixtures.slice(1, 4).map(f => `- ${f.opponent} (${f.competition}, ${f.importance})`).join('\n')}

Generate JSON rotation plan:
{
  "recommended_lineup": {
    "formation": "Formation",
    "starting_xi": [
      {
        "player_name": "Name",
        "position": "Position",
        "rationale": "Why selected"
      }
    ],
    "bench": ["Player 1", "Player 2", "Player 3"]
  },
  "rotation_strategy": "Overall rotation philosophy for this match",
  "key_decisions": [
    {
      "decision": "Decision description",
      "reasoning": "Why this decision"
    }
  ],
  "substitution_plan": [
    {
      "minute": 60,
      "player_out": "Player name",
      "player_in": "Player name",
      "reason": "Tactical reason"
    }
  ],
  "rest_recommendations": [
    {
      "player": "Player name",
      "reason": "Why they need rest",
      "urgency": "High/Medium/Low"
    }
  ],
  "risk_warnings": ["Warning 1", "Warning 2"]
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        recommended_lineup: {
                            type: 'object',
                            properties: {
                                formation: { type: 'string' },
                                starting_xi: {
                                    type: 'array',
                                    items: {
                                        type: 'object',
                                        properties: {
                                            player_name: { type: 'string' },
                                            position: { type: 'string' },
                                            rationale: { type: 'string' }
                                        }
                                    }
                                },
                                bench: { type: 'array', items: { type: 'string' } }
                            }
                        },
                        rotation_strategy: { type: 'string' },
                        key_decisions: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    decision: { type: 'string' },
                                    reasoning: { type: 'string' }
                                }
                            }
                        },
                        substitution_plan: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    minute: { type: 'number' },
                                    player_out: { type: 'string' },
                                    player_in: { type: 'string' },
                                    reason: { type: 'string' }
                                }
                            }
                        },
                        rest_recommendations: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player: { type: 'string' },
                                    reason: { type: 'string' },
                                    urgency: { type: 'string' }
                                }
                            }
                        },
                        risk_warnings: { type: 'array', items: { type: 'string' } }
                    }
                }
            });

            setSuggestions(data);
            toast.success('Rotation plan generated', { id: 'rotation' });
        } catch (error) {
            console.error('Generation error:', error);
            toast.error('Plan generation failed', { id: 'rotation' });
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    AI Rotation Suggester
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {!suggestions && (
                    <div>
                        <h4 className="text-white font-semibold mb-4">Select Match for Rotation Plan</h4>
                        {upcomingFixtures.length === 0 ? (
                            <p className="text-slate-500 text-center py-8">No upcoming fixtures</p>
                        ) : (
                            <div className="space-y-2">
                                {upcomingFixtures.map((fixture) => (
                                    <div
                                        key={fixture.id}
                                        className="p-3 bg-slate-800/50 rounded-lg border border-slate-700 flex justify-between items-center"
                                    >
                                        <div>
                                            <p className="text-white font-medium">{fixture.opponent}</p>
                                            <p className="text-slate-400 text-sm">
                                                {fixture.competition} • {new Date(fixture.match_date).toLocaleDateString()}
                                            </p>
                                        </div>
                                        <Button
                                            onClick={() => generateRotationPlan(fixture)}
                                            disabled={isGenerating}
                                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                                        >
                                            {isGenerating ? (
                                                <Loader2 className="w-4 h-4 animate-spin" />
                                            ) : (
                                                <>
                                                    <Sparkles className="w-4 h-4 mr-2" />
                                                    Generate Plan
                                                </>
                                            )}
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {suggestions && selectedFixture && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-white text-xl font-bold">
                                    Rotation Plan: {selectedFixture.opponent}
                                </h3>
                                <p className="text-slate-400 text-sm">
                                    {selectedFixture.competition} • {new Date(selectedFixture.match_date).toLocaleDateString()}
                                </p>
                            </div>
                            <Button onClick={() => setSuggestions(null)} variant="outline" className="border-slate-700">
                                Back
                            </Button>
                        </div>

                        <div className="p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                            <h4 className="text-cyan-300 font-semibold mb-2">Rotation Strategy</h4>
                            <p className="text-slate-300 text-sm">{suggestions.rotation_strategy}</p>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                                <Users className="w-5 h-5 text-emerald-400" />
                                Recommended Starting XI ({suggestions.recommended_lineup?.formation})
                            </h4>
                            <div className="grid md:grid-cols-2 gap-3">
                                {suggestions.recommended_lineup?.starting_xi?.map((player, i) => (
                                    <div key={i} className="p-3 bg-slate-900/50 rounded border border-slate-700">
                                        <div className="flex justify-between items-start mb-2">
                                            <p className="text-white font-medium">{player.player_name}</p>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                {player.position}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-400 text-xs">{player.rationale}</p>
                                    </div>
                                ))}
                            </div>
                            {suggestions.recommended_lineup?.bench?.length > 0 && (
                                <div className="mt-4 pt-4 border-t border-slate-700">
                                    <p className="text-slate-400 text-sm mb-2">Bench:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {suggestions.recommended_lineup.bench.map((player, i) => (
                                            <Badge key={i} variant="outline" className="border-slate-600 text-slate-300">
                                                {player}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3">Key Decisions</h4>
                                <ul className="space-y-2">
                                    {suggestions.key_decisions?.map((kd, i) => (
                                        <li key={i} className="text-sm">
                                            <p className="text-slate-300 font-medium">{kd.decision}</p>
                                            <p className="text-slate-500 text-xs">{kd.reasoning}</p>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3">Substitution Plan</h4>
                                <div className="space-y-2">
                                    {suggestions.substitution_plan?.map((sub, i) => (
                                        <div key={i} className="text-sm">
                                            <Badge className="bg-amber-500/20 text-amber-400 text-xs mb-1">
                                                {sub.minute}'
                                            </Badge>
                                            <p className="text-slate-300">
                                                {sub.player_out} → {sub.player_in}
                                            </p>
                                            <p className="text-slate-500 text-xs">{sub.reason}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {suggestions.rest_recommendations?.length > 0 && (
                            <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/30">
                                <h4 className="text-amber-300 font-semibold mb-3">Rest Recommendations</h4>
                                <div className="space-y-2">
                                    {suggestions.rest_recommendations.map((rec, i) => (
                                        <div key={i} className="flex items-start gap-2 text-sm">
                                            <Badge className={`${
                                                rec.urgency === 'High' ? 'bg-red-500/20 text-red-400' :
                                                rec.urgency === 'Medium' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-cyan-500/20 text-cyan-400'
                                            } text-xs`}>
                                                {rec.urgency}
                                            </Badge>
                                            <div>
                                                <p className="text-amber-300 font-medium">{rec.player}</p>
                                                <p className="text-amber-400/80 text-xs">{rec.reason}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {suggestions.risk_warnings?.length > 0 && (
                            <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                                <h4 className="text-red-300 font-semibold mb-2">Risk Warnings</h4>
                                <ul className="space-y-1">
                                    {suggestions.risk_warnings.map((warning, i) => (
                                        <li key={i} className="text-red-400 text-sm flex items-center gap-2">
                                            <div className="w-1 h-1 bg-red-400 rounded-full" />
                                            {warning}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}