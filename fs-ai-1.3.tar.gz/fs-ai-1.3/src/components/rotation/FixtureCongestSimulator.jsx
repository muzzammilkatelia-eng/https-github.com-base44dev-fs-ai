import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, Plus, Trash2, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function FixtureCongestSimulator() {
    const [showForm, setShowForm] = useState(false);
    const [newFixture, setNewFixture] = useState({
        opponent: '',
        competition: 'League',
        match_date: '',
        importance: 'Medium',
        venue: 'Home'
    });

    const queryClient = useQueryClient();

    const { data: fixtures = [] } = useQuery({
        queryKey: ['fixtures'],
        queryFn: () => base44.entities.Fixture.list()
    });

    const createFixtureMutation = useMutation({
        mutationFn: (data) => base44.entities.Fixture.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['fixtures'] });
            toast.success('Fixture added');
            setShowForm(false);
            setNewFixture({ opponent: '', competition: 'League', match_date: '', importance: 'Medium', venue: 'Home' });
        }
    });

    const deleteFixtureMutation = useMutation({
        mutationFn: (id) => base44.entities.Fixture.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['fixtures'] });
            toast.success('Fixture removed');
        }
    });

    const upcomingFixtures = fixtures
        .filter(f => f.status !== 'Completed' && new Date(f.match_date) >= new Date())
        .sort((a, b) => new Date(a.match_date) - new Date(b.match_date));

    const analyzeCongestion = () => {
        const now = new Date();
        const next7days = upcomingFixtures.filter(f => {
            const diff = (new Date(f.match_date) - now) / (1000 * 60 * 60 * 24);
            return diff <= 7;
        });
        const next14days = upcomingFixtures.filter(f => {
            const diff = (new Date(f.match_date) - now) / (1000 * 60 * 60 * 24);
            return diff <= 14;
        });

        return {
            next7: next7days.length,
            next14: next14days.length,
            severity: next7days.length >= 3 ? 'Critical' : next7days.length >= 2 ? 'High' : 'Normal'
        };
    };

    const congestion = analyzeCongestion();

    const getImportanceColor = (importance) => {
        switch(importance) {
            case 'Critical': return 'red';
            case 'High': return 'orange';
            case 'Medium': return 'cyan';
            case 'Low': return 'slate';
            default: return 'slate';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-cyan-400" />
                            Fixture Congestion Simulator
                        </CardTitle>
                        <p className="text-slate-400 text-sm mt-1">
                            {upcomingFixtures.length} upcoming matches
                        </p>
                    </div>
                    <Button
                        onClick={() => setShowForm(!showForm)}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Fixture
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                        <p className="text-slate-400 text-sm mb-1">Next 7 Days</p>
                        <p className="text-white text-2xl font-bold">{congestion.next7}</p>
                        <p className="text-slate-500 text-xs">matches</p>
                    </div>
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                        <p className="text-slate-400 text-sm mb-1">Next 14 Days</p>
                        <p className="text-white text-2xl font-bold">{congestion.next14}</p>
                        <p className="text-slate-500 text-xs">matches</p>
                    </div>
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                        <p className="text-slate-400 text-sm mb-1">Congestion Level</p>
                        <Badge className={`${
                            congestion.severity === 'Critical' ? 'bg-red-500/20 text-red-400' :
                            congestion.severity === 'High' ? 'bg-orange-500/20 text-orange-400' :
                            'bg-emerald-500/20 text-emerald-400'
                        }`}>
                            {congestion.severity}
                        </Badge>
                    </div>
                </div>

                {congestion.severity === 'Critical' && (
                    <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5" />
                        <div>
                            <p className="text-red-300 font-semibold">Critical Fixture Congestion</p>
                            <p className="text-red-400 text-sm">Heavy rotation recommended. Monitor player workload closely.</p>
                        </div>
                    </div>
                )}

                {showForm && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                        <h4 className="text-white font-semibold mb-4">Add New Fixture</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-300">Opponent</Label>
                                <Input
                                    value={newFixture.opponent}
                                    onChange={(e) => setNewFixture({...newFixture, opponent: e.target.value})}
                                    className="bg-slate-900 border-slate-700 text-white"
                                    placeholder="e.g., Liverpool"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-300">Match Date & Time</Label>
                                <Input
                                    type="datetime-local"
                                    value={newFixture.match_date}
                                    onChange={(e) => setNewFixture({...newFixture, match_date: e.target.value})}
                                    className="bg-slate-900 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-300">Competition</Label>
                                <Select value={newFixture.competition} onValueChange={(v) => setNewFixture({...newFixture, competition: v})}>
                                    <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="League">League</SelectItem>
                                        <SelectItem value="Cup">Cup</SelectItem>
                                        <SelectItem value="European Competition">European Competition</SelectItem>
                                        <SelectItem value="Friendly">Friendly</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label className="text-slate-300">Importance</Label>
                                <Select value={newFixture.importance} onValueChange={(v) => setNewFixture({...newFixture, importance: v})}>
                                    <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Critical">Critical</SelectItem>
                                        <SelectItem value="High">High</SelectItem>
                                        <SelectItem value="Medium">Medium</SelectItem>
                                        <SelectItem value="Low">Low</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label className="text-slate-300">Venue</Label>
                                <Select value={newFixture.venue} onValueChange={(v) => setNewFixture({...newFixture, venue: v})}>
                                    <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Home">Home</SelectItem>
                                        <SelectItem value="Away">Away</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <div className="flex gap-2 mt-4">
                            <Button onClick={() => createFixtureMutation.mutate(newFixture)} className="bg-emerald-600 hover:bg-emerald-700">
                                Add Fixture
                            </Button>
                            <Button onClick={() => setShowForm(false)} variant="outline" className="border-slate-700">
                                Cancel
                            </Button>
                        </div>
                    </motion.div>
                )}

                <div>
                    <h4 className="text-white font-semibold mb-4">Upcoming Fixtures</h4>
                    {upcomingFixtures.length === 0 ? (
                        <p className="text-slate-500 text-center py-8">No upcoming fixtures</p>
                    ) : (
                        <div className="space-y-2">
                            {upcomingFixtures.map((fixture, i) => {
                                const importanceColor = getImportanceColor(fixture.importance);
                                const matchDate = new Date(fixture.match_date);
                                const daysUntil = Math.ceil((matchDate - new Date()) / (1000 * 60 * 60 * 24));

                                return (
                                    <motion.div
                                        key={fixture.id}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: i * 0.05 }}
                                        className="p-3 bg-slate-800/50 rounded-lg border border-slate-700 flex justify-between items-center"
                                    >
                                        <div className="flex items-center gap-3">
                                            <Badge className={`bg-${importanceColor}-500/20 text-${importanceColor}-400`}>
                                                {fixture.importance}
                                            </Badge>
                                            <div>
                                                <p className="text-white font-medium">{fixture.opponent}</p>
                                                <div className="flex gap-2 text-xs text-slate-400 mt-1">
                                                    <span>{fixture.competition}</span>
                                                    <span>•</span>
                                                    <span>{fixture.venue}</span>
                                                    <span>•</span>
                                                    <span>{matchDate.toLocaleDateString()}</span>
                                                    <span>•</span>
                                                    <Badge variant="outline" className="border-slate-600 text-slate-300 text-xs">
                                                        {daysUntil}d
                                                    </Badge>
                                                </div>
                                            </div>
                                        </div>
                                        <Button
                                            onClick={() => deleteFixtureMutation.mutate(fixture.id)}
                                            size="icon"
                                            variant="ghost"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </motion.div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}