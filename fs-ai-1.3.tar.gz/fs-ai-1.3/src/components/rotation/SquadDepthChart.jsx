import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SquadDepthChart() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: workloads = [] } = useQuery({
        queryKey: ['workloads'],
        queryFn: () => base44.entities.PlayerWorkload.list()
    });

    const positions = [
        { name: 'Goalkeeper', short: 'GK' },
        { name: 'Centre-Back', short: 'CB' },
        { name: 'Full-Back', short: 'FB' },
        { name: 'Defensive Midfielder', short: 'DM' },
        { name: 'Central Midfielder', short: 'CM' },
        { name: 'Attacking Midfielder', short: 'AM' },
        { name: 'Winger', short: 'W' },
        { name: 'Striker', short: 'ST' }
    ];

    const getPositionPlayers = (position) => {
        return players
            .filter(p => p.position === position)
            .map(p => {
                const workload = workloads.find(w => w.player_id === p.id);
                return { ...p, workload };
            })
            .sort((a, b) => (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0));
    };

    const getAvailabilityColor = (status) => {
        switch(status) {
            case 'Available': return 'emerald';
            case 'Fatigued': return 'amber';
            case 'Minor Knock': return 'orange';
            case 'Injured': return 'red';
            case 'Suspended': return 'red';
            default: return 'slate';
        }
    };

    const getDepthQuality = (players) => {
        if (players.length === 0) return { color: 'red', label: 'Critical' };
        if (players.length === 1) return { color: 'orange', label: 'Thin' };
        if (players.length === 2) return { color: 'amber', label: 'Adequate' };
        return { color: 'emerald', label: 'Strong' };
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-cyan-400" />
                    Squad Depth Analysis
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {positions.map((position, i) => {
                        const posPlayers = getPositionPlayers(position.name);
                        const depth = getDepthQuality(posPlayers);
                        const available = posPlayers.filter(p => p.workload?.availability === 'Available').length;

                        return (
                            <motion.div
                                key={position.name}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.05 }}
                                className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                            >
                                <div className="flex justify-between items-center mb-3">
                                    <div className="flex items-center gap-3">
                                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                            {position.short}
                                        </Badge>
                                        <h4 className="text-white font-semibold">{position.name}</h4>
                                        <Badge className={`bg-${depth.color}-500/20 text-${depth.color}-400`}>
                                            {depth.label}
                                        </Badge>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-slate-400 text-xs">Available</p>
                                        <p className="text-white font-semibold">{available}/{posPlayers.length}</p>
                                    </div>
                                </div>

                                {posPlayers.length === 0 ? (
                                    <p className="text-slate-500 text-sm italic">No players in this position</p>
                                ) : (
                                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-2">
                                        {posPlayers.map((player) => {
                                            const availColor = getAvailabilityColor(player.workload?.availability || 'Available');
                                            
                                            return (
                                                <div
                                                    key={player.id}
                                                    className="p-2 bg-slate-900/50 rounded border border-slate-700 hover:border-cyan-500/50 transition-all"
                                                >
                                                    <div className="flex justify-between items-start mb-1">
                                                        <p className="text-white text-sm font-medium">{player.name}</p>
                                                        {player.fsai_proprietary_score && (
                                                            <Badge className="bg-amber-500/20 text-amber-400 text-xs">
                                                                {player.fsai_proprietary_score.toFixed(0)}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <Badge 
                                                            variant="outline" 
                                                            className={`border-${availColor}-500/30 text-${availColor}-400 text-xs`}
                                                        >
                                                            {player.workload?.availability || 'Available'}
                                                        </Badge>
                                                        {player.workload?.fatigue_level > 60 && (
                                                            <span className="text-amber-400 text-xs">
                                                                {player.workload.fatigue_level}% fatigue
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </motion.div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}