import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Activity, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function WorkloadTracker() {
    const queryClient = useQueryClient();

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: workloads = [] } = useQuery({
        queryKey: ['workloads'],
        queryFn: () => base44.entities.PlayerWorkload.list()
    });

    const playersWithWorkload = players.map(p => {
        const workload = workloads.find(w => w.player_id === p.id);
        return { ...p, workload };
    }).sort((a, b) => (b.workload?.fatigue_level || 0) - (a.workload?.fatigue_level || 0));

    const getFatigueColor = (level) => {
        if (level >= 80) return 'red';
        if (level >= 60) return 'orange';
        if (level >= 40) return 'amber';
        return 'emerald';
    };

    const getAvailabilityColor = (status) => {
        switch(status) {
            case 'Available': return 'emerald';
            case 'Fatigued': return 'amber';
            case 'Minor Knock': return 'orange';
            case 'Injured': return 'red';
            case 'Suspended': return 'red';
            default: return 'slate';
        }
    };

    const getRiskColor = (risk) => {
        switch(risk) {
            case 'Critical': return 'red';
            case 'High': return 'orange';
            case 'Medium': return 'amber';
            case 'Low': return 'emerald';
            default: return 'slate';
        }
    };

    const highRiskPlayers = playersWithWorkload.filter(p => 
        p.workload?.fatigue_level >= 70 || 
        ['High', 'Critical'].includes(p.workload?.injury_risk)
    );

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Activity className="w-5 h-5 text-cyan-400" />
                        Player Workload Tracker
                    </CardTitle>
                    {highRiskPlayers.length > 0 && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                            {highRiskPlayers.length} at risk
                        </Badge>
                    )}
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {highRiskPlayers.length > 0 && (
                    <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                        <div className="flex items-start gap-3">
                            <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5" />
                            <div>
                                <p className="text-red-300 font-semibold">High Workload Alert</p>
                                <p className="text-red-400 text-sm">
                                    {highRiskPlayers.length} player{highRiskPlayers.length > 1 ? 's' : ''} showing high fatigue or injury risk
                                </p>
                            </div>
                        </div>
                    </div>
                )}

                <div className="space-y-3">
                    {playersWithWorkload.slice(0, 20).map((player, i) => {
                        const fatigueLevel = player.workload?.fatigue_level || 0;
                        const fatigueColor = getFatigueColor(fatigueLevel);
                        const availColor = getAvailabilityColor(player.workload?.availability || 'Available');
                        const riskColor = getRiskColor(player.workload?.injury_risk || 'Low');

                        return (
                            <motion.div
                                key={player.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.03 }}
                                className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                            >
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <h4 className="text-white font-semibold">{player.name}</h4>
                                        <p className="text-slate-400 text-sm">{player.position} • {player.age} years</p>
                                    </div>
                                    <div className="flex gap-2">
                                        <Badge className={`bg-${availColor}-500/20 text-${availColor}-400 text-xs`}>
                                            {player.workload?.availability || 'Available'}
                                        </Badge>
                                        <Badge className={`bg-${riskColor}-500/20 text-${riskColor}-400 text-xs`}>
                                            {player.workload?.injury_risk || 'Low'} Risk
                                        </Badge>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <div>
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-slate-400 text-xs">Fatigue Level</span>
                                            <span className={`text-${fatigueColor}-400 font-semibold text-sm`}>
                                                {fatigueLevel}%
                                            </span>
                                        </div>
                                        <Progress value={fatigueLevel} className="h-2" />
                                    </div>

                                    <div className="grid grid-cols-3 gap-2 text-xs">
                                        <div>
                                            <span className="text-slate-500">7d Minutes</span>
                                            <p className="text-white font-medium">{player.workload?.minutes_played_7d || 0}</p>
                                        </div>
                                        <div>
                                            <span className="text-slate-500">30d Minutes</span>
                                            <p className="text-white font-medium">{player.workload?.minutes_played_30d || 0}</p>
                                        </div>
                                        <div>
                                            <span className="text-slate-500">Rest Needed</span>
                                            <p className="text-white font-medium">{player.workload?.rest_needed_days || 0} days</p>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}