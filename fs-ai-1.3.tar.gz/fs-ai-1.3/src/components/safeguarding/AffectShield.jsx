import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Heart, Phone, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';

export default function AffectShield({ userInput, onSafeguardingCheck }) {
    const [checking, setChecking] = useState(false);
    const [safeguardingResponse, setSafeguardingResponse] = useState(null);

    const checkSafeguarding = async () => {
        if (!userInput || userInput.trim().length === 0) {
            onSafeguardingCheck?.({ allow_continue: true });
            return;
        }

        setChecking(true);

        try {
            const response = await base44.functions.invoke('safeguardingMonitor', {
                user_text: userInput,
                context: { page: window.location.pathname }
            });

            setSafeguardingResponse(response.data);
            onSafeguardingCheck?.(response.data);

            // If safeguarding mode triggered, show response
            if (response.data.safeguarding_mode) {
                return response.data;
            }

        } catch (error) {
            console.error('Safeguarding check failed:', error);
            onSafeguardingCheck?.({ allow_continue: true });
        } finally {
            setChecking(false);
        }
    };

    React.useEffect(() => {
        if (userInput) {
            checkSafeguarding();
        }
    }, [userInput]);

    if (!safeguardingResponse?.safeguarding_mode) {
        return null;
    }

    const { response_level, supportive_response } = safeguardingResponse;

    return (
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
        >
            <Alert className={
                response_level === 'CRITICAL' 
                    ? 'bg-red-500/10 border-red-500/50' 
                    : 'bg-amber-500/10 border-amber-500/50'
            }>
                <div className="flex items-start gap-3">
                    <Shield className={`w-6 h-6 mt-1 ${
                        response_level === 'CRITICAL' ? 'text-red-400' : 'text-amber-400'
                    }`} />
                    <div className="flex-1">
                        <AlertDescription className="text-white space-y-4">
                            <p className="font-semibold text-lg">
                                {response_level === 'CRITICAL' ? 'We\'re here for you' : 'Support available'}
                            </p>
                            
                            <div className="prose prose-invert prose-sm max-w-none">
                                <p className="whitespace-pre-line">{supportive_response?.message}</p>
                            </div>

                            <div className="flex flex-col sm:flex-row gap-3 pt-2">
                                <Button
                                    variant="outline"
                                    className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
                                    onClick={() => window.open('tel:116123', '_blank')}
                                >
                                    <Phone className="w-4 h-4 mr-2" />
                                    Call Samaritans
                                </Button>
                                <Button
                                    variant="outline"
                                    className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                                    onClick={() => window.open('sms:85258&body=SHOUT', '_blank')}
                                >
                                    <Heart className="w-4 h-4 mr-2" />
                                    Text Crisis Line
                                </Button>
                            </div>

                            {!supportive_response?.halt_interaction && (
                                <Button
                                    variant="ghost"
                                    className="text-slate-400"
                                    onClick={() => setSafeguardingResponse(null)}
                                >
                                    Continue anyway
                                </Button>
                            )}
                        </AlertDescription>
                    </div>
                </div>
            </Alert>
        </motion.div>
    );
}