import React from 'react';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { CreditCard, Lock } from 'lucide-react';
import { toast } from "sonner";

export default function PayPalSupport({ amount, tags = [] }) {
  const [loading, setLoading] = React.useState(false);

  const handlePayment = async () => {
    setLoading(true);
    try {
        const { data } = await base44.functions.invoke('triggerPayment', {
            amount: amount,
            tags: tags
        });
        
        if (data.link) {
            window.open(data.link, '_blank');
            toast.success("Payment link opened");
        }
    } catch (error) {
        console.error("Payment trigger error:", error);
        toast.error(error.response?.data?.error || "Failed to generate payment link");
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="mt-4 p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-white font-semibold flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-cyan-400" />
            Support Football Scout AI
        </h4>
        <Lock className="w-3 h-3 text-green-400" />
      </div>
      <p className="text-slate-400 text-sm mb-4">
        Secure payments powered by PayPal. Safeguarding protocols active.
      </p>
      <Button 
        onClick={handlePayment} 
        disabled={loading}
        className="w-full bg-[#0070ba] hover:bg-[#003087] text-white"
      >
        {loading ? 'Generating Secure Link...' : `Pay with PayPal ${amount ? `(£${amount})` : ''}`}
      </Button>
    </div>
  );
}