import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, AlertTriangle, Eye, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function SafeguardingMonitor() {
    const queryClient = useQueryClient();

    const { data: incidents = [], isLoading } = useQuery({
        queryKey: ['safeguarding-incidents'],
        queryFn: () => base44.entities.SafeguardingIncident.list('-created_date', 50)
    });

    const reviewMutation = useMutation({
        mutationFn: ({ id, notes }) => base44.entities.SafeguardingIncident.update(id, {
            reviewed: true,
            reviewer_notes: notes
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['safeguarding-incidents'] });
            toast.success('Incident reviewed');
        }
    });

    const unreviewed = incidents.filter(i => !i.reviewed);

    const levelColors = {
        CRITICAL: 'bg-red-500/20 text-red-400 border-red-500/30',
        MODERATE: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        LOW: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-cyan-500"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border-red-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Shield className="w-5 h-5 text-red-400" />
                        Safeguarding Monitor
                        {unreviewed.length > 0 && (
                            <Badge className="bg-red-500/20 text-red-400 ml-auto">
                                {unreviewed.length} Pending
                            </Badge>
                        )}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                        <div className="text-center">
                            <p className="text-2xl font-bold text-red-400">
                                {incidents.filter(i => i.incident_type === 'CRITICAL').length}
                            </p>
                            <p className="text-slate-400 text-xs">Critical</p>
                        </div>
                        <div className="text-center">
                            <p className="text-2xl font-bold text-amber-400">
                                {incidents.filter(i => i.incident_type === 'MODERATE').length}
                            </p>
                            <p className="text-slate-400 text-xs">Moderate</p>
                        </div>
                        <div className="text-center">
                            <p className="text-2xl font-bold text-emerald-400">
                                {incidents.filter(i => i.reviewed).length}
                            </p>
                            <p className="text-slate-400 text-xs">Reviewed</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="space-y-3">
                {incidents.map((incident, idx) => (
                    <motion.div
                        key={incident.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                    >
                        <Card className={`${
                            incident.reviewed 
                                ? 'bg-slate-900/30 border-slate-800' 
                                : 'bg-slate-900/50 border-slate-700'
                        }`}>
                            <CardContent className="pt-6">
                                <div className="flex items-start justify-between mb-3">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Badge className={levelColors[incident.incident_type]}>
                                                {incident.incident_type}
                                            </Badge>
                                            <span className="text-slate-400 text-sm">
                                                {incident.user_email}
                                            </span>
                                            {incident.reviewed && (
                                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                                    <CheckCircle2 className="w-3 h-3 mr-1" />
                                                    Reviewed
                                                </Badge>
                                            )}
                                        </div>
                                        <p className="text-slate-300 text-sm mb-2">
                                            <strong>Message:</strong> {incident.user_message}
                                        </p>
                                        <p className="text-slate-400 text-xs mb-1">
                                            <strong>Risk:</strong> {incident.risk_level} | 
                                            <strong> Tone:</strong> {incident.emotional_tone}
                                        </p>
                                        <p className="text-slate-400 text-xs italic">
                                            {incident.ai_assessment}
                                        </p>
                                    </div>
                                </div>

                                <div className="text-xs text-slate-500 mb-3">
                                    {new Date(incident.timestamp).toLocaleString()}
                                </div>

                                {!incident.reviewed && (
                                    <Button
                                        size="sm"
                                        onClick={() => {
                                            const notes = prompt('Add review notes (optional):');
                                            reviewMutation.mutate({ 
                                                id: incident.id, 
                                                notes: notes || 'Reviewed'
                                            });
                                        }}
                                        className="bg-emerald-600"
                                    >
                                        <Eye className="w-3 h-3 mr-1" />
                                        Mark as Reviewed
                                    </Button>
                                )}

                                {incident.reviewer_notes && (
                                    <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded">
                                        <p className="text-emerald-300 text-xs">
                                            <strong>Review Notes:</strong> {incident.reviewer_notes}
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}

                {incidents.length === 0 && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="py-12 text-center">
                            <Shield className="w-12 h-12 mx-auto mb-3 text-slate-600" />
                            <p className="text-slate-400">No safeguarding incidents recorded</p>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}