import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Target, Loader2, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIMissionGenerator() {
    const [missions, setMissions] = useState(null);
    const [loading, setLoading] = useState(false);
    const queryClient = useQueryClient();

    const { data: players = [] } = useQuery({
        queryKey: ['players-needs'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts-available'],
        queryFn: () => base44.entities.Scout.filter({ status: 'Active' })
    });

    const createTaskMutation = useMutation({
        mutationFn: (taskData) => base44.entities.ScoutingTask.create(taskData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
        }
    });

    const generateMissions = async () => {
        setLoading(true);
        toast.loading('AI generating scouting missions...', { id: 'missions' });

        try {
            // Analyze squad needs and market gaps
            const positionCounts = players.reduce((acc, p) => {
                acc[p.position] = (acc[p.position] || 0) + 1;
                return acc;
            }, {});

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a football scouting director. Generate strategic scouting missions based on current squad analysis.

**Current Squad Breakdown:**
${Object.entries(positionCounts).map(([pos, count]) => `- ${pos}: ${count} players`).join('\n')}

**Available Scouts:**
${scouts.slice(0, 10).map(s => `- ${s.full_name} (${s.region}, ${s.specializations?.join(', ') || 'General'})`).join('\n')}

Generate 5-7 scouting missions that address:
1. Positions with weak depth (< 3 players)
2. Emerging talent hotspots
3. Undervalued markets
4. Specific tactical needs

For each mission provide:
- mission_name: Clear mission title
- objective: What to find (2-3 sentences)
- target_region: Geographic focus
- target_positions: Array of positions
- age_range: "U21", "21-25", "25-29", or "Any"
- budget_range: "Budget", "Mid-range", or "Premium"
- timeline: "Urgent", "Short-term", "Long-term"
- recommended_scout: Name of best-suited scout from the list
- success_criteria: How to measure success

Return as JSON array.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            mission_name: { type: "string" },
                            objective: { type: "string" },
                            target_region: { type: "string" },
                            target_positions: { type: "array", items: { type: "string" } },
                            age_range: { type: "string" },
                            budget_range: { type: "string" },
                            timeline: { type: "string" },
                            recommended_scout: { type: "string" },
                            success_criteria: { type: "string" }
                        }
                    }
                }
            });

            setMissions(result);
            toast.success(`${result.length} missions generated!`, { id: 'missions' });
        } catch (error) {
            toast.error('Mission generation failed', { id: 'missions' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const deployMission = async (mission) => {
        const scout = scouts.find(s => s.full_name === mission.recommended_scout);
        
        await createTaskMutation.mutateAsync({
            player_name: mission.mission_name,
            assigned_to: scout?.email || scouts[0]?.email,
            task_type: 'Deep Dive',
            priority: mission.timeline === 'Urgent' ? 'Critical' : 'High',
            status: 'Pending',
            source: 'AI Flag',
            notes: `${mission.objective}\n\nRegion: ${mission.target_region}\nPositions: ${mission.target_positions.join(', ')}\nAge: ${mission.age_range}\nBudget: ${mission.budget_range}\n\nSuccess Criteria: ${mission.success_criteria}`
        });

        toast.success('Mission deployed!');
        setMissions(missions.filter(m => m !== mission));
    };

    const timelineColors = {
        'Urgent': 'bg-red-500/20 text-red-400',
        'Short-term': 'bg-amber-500/20 text-amber-400',
        'Long-term': 'bg-blue-500/20 text-blue-400'
    };

    const budgetColors = {
        'Budget': 'bg-emerald-500/20 text-emerald-400',
        'Mid-range': 'bg-cyan-500/20 text-cyan-400',
        'Premium': 'bg-purple-500/20 text-purple-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-emerald-400" />
                    AI Mission Generator
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <Button
                    onClick={generateMissions}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating Missions...
                        </>
                    ) : (
                        <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Generate Strategic Missions
                        </>
                    )}
                </Button>

                {missions && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-3"
                    >
                        <h3 className="text-white font-semibold">Recommended Missions ({missions.length})</h3>
                        {missions.map((mission, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h4 className="text-white font-bold">{mission.mission_name}</h4>
                                        <p className="text-slate-400 text-sm">Scout: {mission.recommended_scout}</p>
                                    </div>
                                    <Button
                                        onClick={() => deployMission(mission)}
                                        size="sm"
                                        className="bg-emerald-600"
                                    >
                                        Deploy
                                    </Button>
                                </div>

                                <p className="text-slate-300 text-sm leading-relaxed">{mission.objective}</p>

                                <div className="flex flex-wrap gap-2">
                                    <Badge className={timelineColors[mission.timeline]}>
                                        {mission.timeline}
                                    </Badge>
                                    <Badge className={budgetColors[mission.budget_range]}>
                                        {mission.budget_range}
                                    </Badge>
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {mission.target_region}
                                    </Badge>
                                    <Badge className="bg-cyan-500/20 text-cyan-400">
                                        {mission.age_range}
                                    </Badge>
                                </div>

                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Target Positions:</p>
                                    <div className="flex flex-wrap gap-1">
                                        {mission.target_positions.map((pos, i) => (
                                            <span key={i} className="text-xs bg-slate-700/50 text-slate-300 px-2 py-1 rounded">
                                                {pos}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded p-2">
                                    <p className="text-cyan-300 text-xs">
                                        <strong>Success Criteria:</strong> {mission.success_criteria}
                                    </p>
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}