import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIReportAnalyzer() {
    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: findings = [] } = useQuery({
        queryKey: ['findings-recent'],
        queryFn: () => base44.entities.ScoutFinding.list('-created_date', 50)
    });

    const analyzeReports = async () => {
        if (findings.length === 0) {
            toast.error('No reports to analyze');
            return;
        }

        setLoading(true);
        toast.loading('AI analyzing scout reports...', { id: 'analyze' });

        try {
            const recentFindings = findings.slice(0, 20);
            
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football talent analyst. Analyze these scout reports and identify the most promising talents.

**Recent Scout Reports:**
${recentFindings.map((f, i) => `
${i + 1}. ${f.player_name} (${f.player_age}y, ${f.position})
   - Club: ${f.current_club}
   - Region: ${f.region}
   - Priority: ${f.priority}
   - Finding Type: ${f.finding_type}
   - Summary: ${f.summary}
   - Strengths: ${f.key_strengths?.join(', ') || 'N/A'}
   - Recommendation: ${f.recommendation}
`).join('\n')}

Provide:
1. **Top 5 Talents**: Ranked list of most promising players with reasoning
2. **Hidden Gems**: 2-3 underrated players who might be overlooked
3. **Urgent Actions**: Players requiring immediate follow-up
4. **Market Insights**: Trends or patterns across reports (regions, positions, etc.)
5. **Scout Performance**: Which scouts are submitting highest quality reports
6. **Red Flags**: Any concerning patterns or potential issues

Return as JSON with these keys: top_talents (array of {player_name, age, position, score, reasoning}), hidden_gems (array), urgent_actions (array of strings), market_insights (string), scout_performance (string), red_flags (array of strings)`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: "object",
                    properties: {
                        top_talents: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    score: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        hidden_gems: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    why_underrated: { type: "string" }
                                }
                            }
                        },
                        urgent_actions: { type: "array", items: { type: "string" } },
                        market_insights: { type: "string" },
                        scout_performance: { type: "string" },
                        red_flags: { type: "array", items: { type: "string" } }
                    }
                }
            });

            setAnalysis(result);
            toast.success('Analysis complete!', { id: 'analyze' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'analyze' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    AI Report Analyzer
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <p className="text-slate-400">
                        {findings.length} recent reports available for analysis
                    </p>
                    <Button
                        onClick={analyzeReports}
                        disabled={loading || findings.length === 0}
                        className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Analyze Reports
                            </>
                        )}
                    </Button>
                </div>

                {analysis && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Top Talents */}
                        <div className="space-y-3">
                            <h3 className="text-white font-semibold flex items-center gap-2">
                                <TrendingUp className="w-4 h-4 text-emerald-400" />
                                Top 5 Identified Talents
                            </h3>
                            {analysis.top_talents?.map((talent, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.1 * idx }}
                                    className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4"
                                >
                                    <div className="flex items-start justify-between mb-2">
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">#{idx + 1}</Badge>
                                                <h4 className="text-white font-bold">{talent.player_name}</h4>
                                            </div>
                                            <p className="text-slate-400 text-sm">
                                                {talent.age}y • {talent.position}
                                            </p>
                                        </div>
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            Score: {talent.score}/100
                                        </Badge>
                                    </div>
                                    <p className="text-slate-300 text-sm">{talent.reasoning}</p>
                                </motion.div>
                            ))}
                        </div>

                        {/* Hidden Gems */}
                        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                            <h4 className="text-blue-400 font-semibold mb-3">💎 Hidden Gems</h4>
                            <div className="space-y-2">
                                {analysis.hidden_gems?.map((gem, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded p-3">
                                        <h5 className="text-white font-semibold text-sm mb-1">{gem.player_name}</h5>
                                        <p className="text-slate-300 text-xs">{gem.why_underrated}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Urgent Actions */}
                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                            <h4 className="text-red-400 font-semibold mb-2 flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4" />
                                Urgent Follow-Up Required
                            </h4>
                            <ul className="space-y-1">
                                {analysis.urgent_actions?.map((action, idx) => (
                                    <li key={idx} className="text-red-300 text-sm">• {action}</li>
                                ))}
                            </ul>
                        </div>

                        {/* Market Insights */}
                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <h4 className="text-cyan-400 font-semibold mb-2">📊 Market Insights</h4>
                            <p className="text-slate-300 text-sm leading-relaxed">{analysis.market_insights}</p>
                        </div>

                        {/* Scout Performance */}
                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                            <h4 className="text-amber-400 font-semibold mb-2">👥 Scout Performance Review</h4>
                            <p className="text-slate-300 text-sm leading-relaxed">{analysis.scout_performance}</p>
                        </div>

                        {/* Red Flags */}
                        {analysis.red_flags?.length > 0 && (
                            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                                <h4 className="text-orange-400 font-semibold mb-2">⚠️ Red Flags</h4>
                                <ul className="space-y-1">
                                    {analysis.red_flags.map((flag, idx) => (
                                        <li key={idx} className="text-orange-300 text-sm">• {flag}</li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}