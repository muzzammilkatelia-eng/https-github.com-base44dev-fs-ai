import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Play, Loader2, TrendingUp, Target, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIScoutAgent({ network, players }) {
    const [isRunning, setIsRunning] = useState(false);
    const [results, setResults] = useState(null);
    const queryClient = useQueryClient();

    const runAutomatedScouting = async () => {
        if (!network || players.length === 0) {
            toast.error('No players available for scouting');
            return;
        }

        setIsRunning(true);
        setResults(null);
        toast.loading('AI scouts analyzing players...', { id: 'ai-scout' });

        try {
            // Filter players based on network criteria
            let targetPlayers = players;

            // Apply region filters
            if (network.target_regions && network.target_regions.length > 0) {
                targetPlayers = targetPlayers.filter(p => 
                    network.target_regions.some(region => 
                        p.nationality?.includes(region) || p.league?.includes(region)
                    )
                );
            }

            // Apply position filters
            if (network.target_positions && network.target_positions.length > 0) {
                targetPlayers = targetPlayers.filter(p => 
                    network.target_positions.includes(p.position) ||
                    p.secondary_positions?.some(pos => network.target_positions.includes(pos))
                );
            }

            // Apply age range filters
            if (network.target_age_range) {
                targetPlayers = targetPlayers.filter(p => {
                    const age = p.age || 0;
                    return age >= (network.target_age_range.min || 0) && 
                           age <= (network.target_age_range.max || 99);
                });
            }

            // Apply attribute criteria
            if (network.attribute_criteria && network.attribute_criteria.length > 0) {
                targetPlayers = targetPlayers.filter(p => {
                    return network.attribute_criteria.every(criterion => {
                        const attrValue = p.physical_attributes?.[criterion.attribute_name] || 
                                        p.fsai_score_breakdown?.[criterion.attribute_name] || 0;
                        return attrValue >= criterion.min_value;
                    });
                });
            }

            // Apply transfer criteria
            if (network.transfer_criteria) {
                if (network.transfer_criteria.max_market_value) {
                    targetPlayers = targetPlayers.filter(p => 
                        (p.market_value || 0) <= network.transfer_criteria.max_market_value
                    );
                }
                if (network.transfer_criteria.transfer_listed_only) {
                    targetPlayers = targetPlayers.filter(p => 
                        p.transfer_status === 'Transfer Listed'
                    );
                }
                if (network.transfer_criteria.release_clause_required) {
                    targetPlayers = targetPlayers.filter(p => 
                        p.release_clause?.exists === true
                    );
                }
            }

            // Apply breakout flags
            if (network.breakout_flags?.enabled) {
                targetPlayers = targetPlayers.filter(p => {
                    const meetsAge = !network.breakout_flags.age_threshold || 
                                   p.age <= network.breakout_flags.age_threshold;
                    const meetsPotential = !network.breakout_flags.min_potential_rating || 
                                         (p.fsai_proprietary_score || 0) >= network.breakout_flags.min_potential_rating;
                    return meetsAge && meetsPotential;
                });
            }

            if (targetPlayers.length === 0) {
                toast.error('No players match network criteria', { id: 'ai-scout' });
                setIsRunning(false);
                return;
            }

            // Take top 20 for AI analysis
            const samplePlayers = targetPlayers.slice(0, 20);

            // Use AI to identify top prospects
            const prompt = `You are an elite AI football scout analyzing players for the "${network.network_name}" scouting network.

Network Goals: ${network.description}
Target Regions: ${network.target_regions?.join(', ') || 'All regions'}
Target Positions: ${network.target_positions?.join(', ') || 'All positions'}
Age Range: ${network.target_age_range?.min || 0}-${network.target_age_range?.max || 99} years
${network.tactical_roles?.length > 0 ? `Tactical Roles: ${network.tactical_roles.join(', ')}` : ''}
${network.attribute_criteria?.length > 0 ? `Attribute Requirements: ${network.attribute_criteria.map(a => `${a.attribute_name} > ${a.min_value}`).join(', ')}` : ''}
${network.performance_criteria?.goals_per_game ? `Performance: Goals/game > ${network.performance_criteria.goals_per_game}` : ''}
${network.transfer_criteria?.max_market_value ? `Max Market Value: €${network.transfer_criteria.max_market_value}M` : ''}
${network.breakout_flags?.enabled ? `Breakout Detection: Enabled (potential > ${network.breakout_flags.min_potential_rating}, age < ${network.breakout_flags.age_threshold})` : ''}

Analyze these ${samplePlayers.length} players and identify the TOP 5 most promising prospects:

${samplePlayers.map((p, i) => `
${i + 1}. ${p.name}
- Age: ${p.age} | Position: ${p.position}
- Club: ${p.current_club} (${p.league})
- Value: €${p.market_value}M
- Nationality: ${p.nationality}
${p.fsai_proprietary_score ? `- FS-AI Score: ${p.fsai_proprietary_score}` : ''}
`).join('\n')}

For each of the TOP 5 prospects, provide:
1. **Player Name**: Exact name from the list
2. **Priority**: Critical/High/Medium/Low based on potential
3. **Finding Type**: New Discovery/Progress Update/Performance Alert
4. **Summary**: 2-3 sentence overview of why they stand out
5. **Detailed Analysis**: Comprehensive scouting report (strengths, weaknesses, potential)
6. **Key Strengths**: Array of 3-5 specific strengths
7. **Development Areas**: Array of 2-3 areas for improvement
8. **Recommendation**: Immediate Action/Monitor Closely/Continue Watching
9. **Reasoning**: Why this recommendation is appropriate`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        prospects: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    priority: { type: "string", enum: ["Critical", "High", "Medium", "Low"] },
                                    finding_type: { type: "string", enum: ["New Discovery", "Progress Update", "Performance Alert"] },
                                    summary: { type: "string" },
                                    detailed_analysis: { type: "string" },
                                    key_strengths: { type: "array", items: { type: "string" } },
                                    development_areas: { type: "array", items: { type: "string" } },
                                    recommendation: { type: "string", enum: ["Immediate Action", "Monitor Closely", "Continue Watching"] },
                                    reasoning: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            // Create findings for each identified prospect
            const createdFindings = [];
            for (const prospect of response.prospects) {
                const player = samplePlayers.find(p => 
                    p.name.toLowerCase() === prospect.player_name.toLowerCase()
                );

                if (player) {
                    const finding = await base44.entities.ScoutFinding.create({
                        network_id: network.id,
                        scout_id: 'ai-agent',
                        scout_name: 'AI Scout Agent',
                        player_name: player.name,
                        player_age: player.age,
                        position: player.position,
                        current_club: player.current_club,
                        league: player.league,
                        region: player.nationality || 'Unknown',
                        finding_type: prospect.finding_type,
                        priority: prospect.priority,
                        summary: prospect.summary,
                        detailed_report: prospect.detailed_analysis,
                        key_strengths: prospect.key_strengths,
                        areas_for_development: prospect.development_areas,
                        recommendation: prospect.recommendation,
                        status: 'New'
                    });
                    createdFindings.push(finding);
                }
            }

            setResults({
                total_analyzed: samplePlayers.length,
                prospects_identified: createdFindings.length,
                findings: createdFindings
            });

            queryClient.invalidateQueries({ queryKey: ['scout-findings'] });
            toast.success(`AI identified ${createdFindings.length} prospects!`, { id: 'ai-scout' });
        } catch (error) {
            console.error('AI scouting failed:', error);
            toast.error('AI scouting failed', { id: 'ai-scout' });
        } finally {
            setIsRunning(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI-Powered Automated Scouting
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-slate-300">
                        Deploy AI scouts to automatically analyze {players.length} players in the database
                        and identify prospects matching your network criteria.
                    </p>

                    <div className="bg-slate-900/50 rounded-lg p-4 space-y-2">
                        <h4 className="text-cyan-400 font-semibold text-sm mb-3">Network Criteria:</h4>
                        
                        {network.target_regions && network.target_regions.length > 0 && (
                            <div>
                                <span className="text-slate-400 text-xs">Regions:</span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                    {network.target_regions.map((region, idx) => (
                                        <Badge key={idx} className="bg-purple-500/20 text-purple-400 text-xs">
                                            {region}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}

                        {network.target_positions && network.target_positions.length > 0 && (
                            <div>
                                <span className="text-slate-400 text-xs">Positions:</span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                    {network.target_positions.map((pos, idx) => (
                                        <Badge key={idx} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                            {pos}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}

                        {network.target_age_range && (
                            <div>
                                <span className="text-slate-400 text-xs">Age Range:</span>
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-xs ml-2">
                                    {network.target_age_range.min}-{network.target_age_range.max} years
                                </Badge>
                            </div>
                        )}
                    </div>

                    <Button
                        onClick={runAutomatedScouting}
                        disabled={isRunning || players.length === 0}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500"
                        size="lg"
                    >
                        {isRunning ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                AI Scouts Analyzing...
                            </>
                        ) : (
                            <>
                                <Play className="w-5 h-5 mr-2" />
                                Run AI Scout Agent
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {results && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                Scouting Results
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                    <div className="flex items-center gap-3">
                                        <Target className="w-8 h-8 text-cyan-400" />
                                        <div>
                                            <p className="text-slate-400 text-sm">Players Analyzed</p>
                                            <p className="text-3xl font-bold text-white">{results.total_analyzed}</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                    <div className="flex items-center gap-3">
                                        <TrendingUp className="w-8 h-8 text-emerald-400" />
                                        <div>
                                            <p className="text-slate-400 text-sm">Prospects Identified</p>
                                            <p className="text-3xl font-bold text-white">{results.prospects_identified}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <h4 className="text-white font-semibold">Identified Prospects:</h4>
                                {results.findings.map((finding, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1">
                                                <p className="text-white font-semibold">{finding.player_name}</p>
                                                <p className="text-slate-400 text-sm">
                                                    {finding.position} • {finding.player_age}y • {finding.current_club}
                                                </p>
                                                <p className="text-slate-300 text-sm mt-1">{finding.summary}</p>
                                            </div>
                                            <Badge className={
                                                finding.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                finding.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-blue-500/20 text-blue-400'
                                            }>
                                                {finding.priority}
                                            </Badge>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                <p className="text-cyan-400 text-sm">
                                    ✓ Findings have been automatically created and are available in the "Findings" tab
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}