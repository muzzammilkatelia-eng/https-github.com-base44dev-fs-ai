import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, MapPin, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AIScoutAssigner({ networkId }) {
    const [assignments, setAssignments] = useState(null);
    const [loading, setLoading] = useState(false);
    const queryClient = useQueryClient();

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts-active'],
        queryFn: () => base44.entities.Scout.filter({ status: 'Active' })
    });

    const { data: network } = useQuery({
        queryKey: ['network', networkId],
        queryFn: () => base44.entities.ScoutNetwork.filter({ id: networkId }).then(r => r[0]),
        enabled: !!networkId
    });

    const updateNetworkMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ScoutNetwork.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['network', networkId] });
            toast.success('Scouts assigned successfully!');
        }
    });

    const generateAssignments = async () => {
        if (!network) {
            toast.error('No network selected');
            return;
        }

        setLoading(true);
        toast.loading('AI analyzing optimal assignments...', { id: 'assign' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football scouting coordinator. Assign scouts to optimal regions and player types based on their expertise and network requirements.

**Network Requirements:**
- Name: ${network.network_name}
- Target Regions: ${network.target_regions?.join(', ') || 'Any'}
- Target Positions: ${network.target_positions?.join(', ') || 'Any'}
- Age Range: ${network.target_age_range?.min || 0}-${network.target_age_range?.max || 99}

**Available Scouts:**
${scouts.map(s => `
- ${s.full_name}
  - Primary Region: ${s.region}
  - Countries: ${s.countries?.join(', ') || 'Any'}
  - Specializations: ${s.specializations?.join(', ') || 'General'}
  - Experience: ${s.experience_years || 0} years
  - Languages: ${s.languages?.join(', ') || 'English'}
  - Performance: ${s.performance_metrics?.accuracy_rating || 0}/100
`).join('\n')}

Recommend the best scout assignments for this network. For each assignment provide:
- scout_id: Scout's ID
- scout_name: Scout's name
- assigned_regions: Array of specific regions/countries to focus on
- assigned_positions: Array of positions to prioritize
- reasoning: Why this scout is ideal for this assignment (2-3 sentences)
- priority_level: "High", "Medium", or "Low"

Return as JSON array of assignments. Include 3-5 scouts maximum.`,
                add_context_from_internet: false,
                response_json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            scout_id: { type: "string" },
                            scout_name: { type: "string" },
                            assigned_regions: { type: "array", items: { type: "string" } },
                            assigned_positions: { type: "array", items: { type: "string" } },
                            reasoning: { type: "string" },
                            priority_level: { type: "string" }
                        }
                    }
                }
            });

            setAssignments(result);
            toast.success('AI assignments generated!', { id: 'assign' });
        } catch (error) {
            toast.error('Assignment generation failed', { id: 'assign' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const applyAssignments = async () => {
        if (!assignments || !network) return;

        const scoutIds = assignments.map(a => a.scout_id);
        
        await updateNetworkMutation.mutateAsync({
            id: networkId,
            data: {
                assigned_scouts: scoutIds
            }
        });

        // Create scouting tasks for each assignment
        for (const assignment of assignments) {
            await base44.entities.ScoutingTask.create({
                scout_id: assignment.scout_id,
                task_type: 'AI Generated',
                priority: assignment.priority_level,
                status: 'Pending',
                source: 'AI Assignment',
                player_name: `${assignment.assigned_positions.join('/')} scout in ${assignment.assigned_regions.join(', ')}`,
                notes: assignment.reasoning
            });
        }

        setAssignments(null);
    };

    const priorityColors = {
        'High': 'bg-red-500/20 text-red-400 border-red-500/30',
        'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Low': 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    AI Scout Assignment
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <p className="text-slate-400">
                        {scouts.length} active scouts available for assignment
                    </p>
                    <Button
                        onClick={generateAssignments}
                        disabled={loading || !network || scouts.length === 0}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate AI Assignments
                            </>
                        )}
                    </Button>
                </div>

                {assignments && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <div className="flex justify-between items-center">
                            <h3 className="text-white font-semibold">Recommended Assignments</h3>
                            <Button
                                onClick={applyAssignments}
                                className="bg-emerald-600"
                            >
                                Apply All Assignments
                            </Button>
                        </div>

                        {assignments.map((assignment, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h4 className="text-white font-bold">{assignment.scout_name}</h4>
                                        <Badge className={priorityColors[assignment.priority_level]}>
                                            {assignment.priority_level} Priority
                                        </Badge>
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-3">
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                            <MapPin className="w-3 h-3" />
                                            Assigned Regions:
                                        </p>
                                        <div className="flex flex-wrap gap-1">
                                            {assignment.assigned_regions.map((region, i) => (
                                                <Badge key={i} className="bg-purple-500/20 text-purple-400 text-xs">
                                                    {region}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                                            <Users className="w-3 h-3" />
                                            Focus Positions:
                                        </p>
                                        <div className="flex flex-wrap gap-1">
                                            {assignment.assigned_positions.map((pos, i) => (
                                                <Badge key={i} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                    {pos}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <p className="text-slate-300 text-sm leading-relaxed">
                                    {assignment.reasoning}
                                </p>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}