import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Target, CheckCircle, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AIScoutAssignmentEngine() {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [recommendations, setRecommendations] = useState(null);
    const queryClient = useQueryClient();

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const { data: assignments = [] } = useQuery({
        queryKey: ['scoutAssignments'],
        queryFn: () => base44.entities.ScoutAssignment.list()
    });

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const createAssignmentMutation = useMutation({
        mutationFn: (assignmentData) => base44.entities.ScoutAssignment.create(assignmentData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scoutAssignments'] });
            toast.success('Assignment created');
        }
    });

    const analyzeAndRecommend = async () => {
        if (scouts.length === 0) {
            toast.error('Add scouts to your network first');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing team needs and generating scout assignments...', { id: 'analyze' });

        try {
            const positionCounts = players.reduce((acc, p) => {
                acc[p.position] = (acc[p.position] || 0) + 1;
                return acc;
            }, {});

            const currentCoverage = assignments.reduce((acc, a) => {
                if (a.region) acc[a.region] = (acc[a.region] || 0) + 1;
                return acc;
            }, {});

            const prompt = `You are an elite scouting director. Optimize scout assignments for maximum efficiency.

Current Scouting Network:
${scouts.map(s => `- ${s.name}: Expertise - ${s.expertise?.join(', ') || 'General'}, Languages - ${s.languages?.join(', ') || 'Unknown'}, Regions covered - ${s.regions_covered?.join(', ') || 'None'}`).join('\n')}

Team Strategy: ${activeStrategy ? `${activeStrategy.formation} - ${activeStrategy.playing_style}` : 'Not defined'}

Current Squad Analysis:
${Object.entries(positionCounts).map(([pos, count]) => `- ${pos}: ${count} player(s)`).join('\n')}

Current Regional Coverage:
${Object.entries(currentCoverage).map(([region, count]) => `- ${region}: ${count} scout(s)`).join('\n')}

Based on squad gaps and team needs, recommend optimal scout assignments. Prioritize:
1. Positions with low squad depth
2. Uncovered or undercovered regions with high talent density
3. Alignment with team strategy

Return JSON:
{
  "analysis": "Brief analysis of current coverage gaps and team needs",
  "recommendations": [
    {
      "scout_name": "Scout name (from list above)",
      "assignment_type": "Regional Coverage/Position Focus/Player Type Specialist",
      "region": "Geographic region",
      "countries": ["Country 1", "Country 2"],
      "position_focus": ["Position 1", "Position 2"],
      "priority": "Critical/High/Medium/Low",
      "objectives": ["Objective 1", "Objective 2"],
      "rationale": "Why this assignment makes sense"
    }
  ]
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        analysis: { type: 'string' },
                        recommendations: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    scout_name: { type: 'string' },
                                    assignment_type: { type: 'string' },
                                    region: { type: 'string' },
                                    countries: { type: 'array', items: { type: 'string' } },
                                    position_focus: { type: 'array', items: { type: 'string' } },
                                    priority: { type: 'string' },
                                    objectives: { type: 'array', items: { type: 'string' } },
                                    rationale: { type: 'string' }
                                }
                            }
                        }
                    }
                }
            });

            setRecommendations(data);
            toast.success('Assignment recommendations generated', { id: 'analyze' });
        } catch (error) {
            console.error('Analysis error:', error);
            toast.error('Analysis failed', { id: 'analyze' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const applyRecommendation = (rec) => {
        const scout = scouts.find(s => s.name === rec.scout_name);
        if (!scout) {
            toast.error('Scout not found');
            return;
        }

        createAssignmentMutation.mutate({
            scout_id: scout.id,
            scout_name: scout.name,
            assignment_type: rec.assignment_type,
            region: rec.region,
            countries: rec.countries,
            position_focus: rec.position_focus,
            priority: rec.priority,
            objectives: rec.objectives,
            status: 'Active',
            start_date: new Date().toISOString().split('T')[0]
        });
    };

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 'Critical': return 'red';
            case 'High': return 'amber';
            case 'Medium': return 'cyan';
            case 'Low': return 'slate';
            default: return 'slate';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        AI Scout Assignment Engine
                    </CardTitle>
                    <Button
                        onClick={analyzeAndRecommend}
                        disabled={isAnalyzing || scouts.length === 0}
                        className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Optimize Assignments
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                {scouts.length === 0 && (
                    <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/30">
                        <p className="text-amber-300 text-sm">
                            Add scouts to your network to enable AI assignment optimization.
                        </p>
                    </div>
                )}

                {!recommendations && scouts.length > 0 && (
                    <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700 text-center">
                        <Target className="w-12 h-12 text-purple-400 mx-auto mb-3" />
                        <p className="text-slate-300 mb-2">
                            AI will analyze your {scouts.length} scout{scouts.length !== 1 ? 's' : ''} and team needs
                        </p>
                        <p className="text-slate-400 text-sm">
                            Click "Optimize Assignments" to get intelligent scout allocation recommendations
                        </p>
                    </div>
                )}

                {recommendations && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                            <h4 className="text-purple-300 font-semibold mb-2">Coverage Analysis</h4>
                            <p className="text-slate-300 text-sm">{recommendations.analysis}</p>
                        </div>

                        <div>
                            <h4 className="text-white font-semibold mb-4">
                                Recommended Assignments ({recommendations.recommendations?.length})
                            </h4>
                            <div className="space-y-4">
                                {recommendations.recommendations?.map((rec, i) => {
                                    const priorityColor = getPriorityColor(rec.priority);
                                    return (
                                        <motion.div
                                            key={i}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: i * 0.1 }}
                                            className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                        >
                                            <div className="flex justify-between items-start mb-3">
                                                <div>
                                                    <h5 className="text-white font-semibold text-lg mb-1">
                                                        {rec.scout_name}
                                                    </h5>
                                                    <div className="flex gap-2 flex-wrap">
                                                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                            {rec.assignment_type}
                                                        </Badge>
                                                        <Badge className={`bg-${priorityColor}-500/20 text-${priorityColor}-400 border-${priorityColor}-500/30`}>
                                                            {rec.priority} Priority
                                                        </Badge>
                                                        <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                            <MapPin className="w-3 h-3 mr-1" />
                                                            {rec.region}
                                                        </Badge>
                                                    </div>
                                                </div>
                                                <Button
                                                    onClick={() => applyRecommendation(rec)}
                                                    size="sm"
                                                    className="bg-emerald-600 hover:bg-emerald-700"
                                                >
                                                    <CheckCircle className="w-4 h-4 mr-2" />
                                                    Apply
                                                </Button>
                                            </div>

                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Rationale</p>
                                                    <p className="text-slate-300 text-sm">{rec.rationale}</p>
                                                </div>

                                                <div className="grid md:grid-cols-2 gap-3">
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Countries</p>
                                                        <div className="flex flex-wrap gap-1">
                                                            {rec.countries?.map((c, j) => (
                                                                <Badge key={j} variant="outline" className="border-slate-600 text-slate-300 text-xs">
                                                                    {c}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Position Focus</p>
                                                        <div className="flex flex-wrap gap-1">
                                                            {rec.position_focus?.map((p, j) => (
                                                                <Badge key={j} className="bg-purple-500/20 text-purple-400 text-xs">
                                                                    {p}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Objectives</p>
                                                    <ul className="space-y-1">
                                                        {rec.objectives?.map((obj, j) => (
                                                            <li key={j} className="text-slate-300 text-sm flex items-start gap-2">
                                                                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                                                {obj}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            </div>
                                        </motion.div>
                                    );
                                })}
                            </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}