import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Target, Users, ArrowRight, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function CollaborativeMissionGenerator({ trends }) {
    const [missions, setMissions] = useState(null);
    const [loading, setLoading] = useState(false);

    const generateMissions = async () => {
        if (!trends) return;
        setLoading(true);
        try {
            const { data } = await base44.functions.invoke('generateCollaborativeMissions', {
                trends: trends.trends,
                focus_areas: trends.recommended_focus_areas
            });
            setMissions(data.missions);
        } catch (error) {
            console.error(error);
            toast.error("Failed to generate missions");
        } finally {
            setLoading(false);
        }
    };

    const launchMission = async (mission) => {
        toast.success(`Mission "${mission.title}" launched to network!`);
        // In a real app, this would create ScoutAssignment entities
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-emerald-400" />
                    Collaborative Missions
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!missions ? (
                    <div className="text-center py-6">
                        <p className="text-slate-400 text-sm mb-4">
                            Generate collaborative scouting missions based on current AI insights.
                        </p>
                        <Button 
                            onClick={generateMissions} 
                            disabled={!trends || loading}
                            className="bg-emerald-600 hover:bg-emerald-700"
                        >
                            {loading ? 'Generating...' : 'Generate Missions'}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {missions.map((mission, i) => (
                            <div key={i} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <div className="flex justify-between items-start mb-2">
                                    <h5 className="text-white font-bold">{mission.title}</h5>
                                    <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded">
                                        {mission.priority} Priority
                                    </span>
                                </div>
                                <p className="text-slate-300 text-sm mb-3">{mission.description}</p>
                                <div className="flex justify-between items-center">
                                    <div className="text-xs text-slate-500">
                                        Target: {mission.region_focus} • {mission.target_positions.join(', ')}
                                    </div>
                                    <Button 
                                        size="sm" 
                                        variant="outline"
                                        className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
                                        onClick={() => launchMission(mission)}
                                    >
                                        Launch <ArrowRight className="w-3 h-3 ml-1" />
                                    </Button>
                                </div>
                            </div>
                        ))}
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setMissions(null)}
                            className="w-full text-slate-500"
                        >
                            Reset
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}