import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Brain, TrendingUp, Target, Users, Award, RefreshCw, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function CollectiveIntelligencePanel() {
    const [trends, setTrends] = useState([]);
    const [missions, setMissions] = useState([]);
    const [topScouts, setTopScouts] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            // Parallel fetch for efficiency
            const [analysisRes, scoutsRes] = await Promise.all([
                base44.functions.invoke('analyzeScoutNetwork', { action: 'analyze_trends' }),
                base44.entities.Scout.list('-performance_metrics.accuracy_rating', 5)
            ]);

            if (analysisRes.data) {
                setTrends(analysisRes.data.trends || []);
                setMissions(analysisRes.data.missions || []);
            }
            
            setTopScouts(scoutsRes || []);
            
        } catch (error) {
            console.error("Failed to fetch intelligence:", error);
            toast.error("Failed to load collective intelligence");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleCreateMission = async (mission) => {
        toast.promise(
            base44.entities.ScoutNetwork.create({
                network_name: `Mission: ${mission.title}`,
                description: mission.objective,
                target_regions: [mission.target_region],
                target_players: [], 
                status: 'Active'
            }),
            {
                loading: 'Creating mission...',
                success: 'Mission created successfully',
                error: 'Failed to create mission'
            }
        );
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Trends Column */}
            <Card className="bg-slate-900/50 border-slate-800 md:col-span-1">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        Emerging Patterns
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {isLoading ? (
                        <div className="flex justify-center p-4"><Loader2 className="animate-spin text-slate-500" /></div>
                    ) : trends.length > 0 ? (
                        trends.map((trend, i) => (
                            <motion.div 
                                key={i}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                                className="bg-slate-800/50 p-3 rounded-lg border border-slate-700"
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <h4 className="text-white font-medium text-sm">{trend.title}</h4>
                                    <Badge variant="outline" className={trend.impact === 'High' ? 'text-red-400 border-red-500/30' : 'text-blue-400 border-blue-500/30'}>
                                        {trend.impact} Impact
                                    </Badge>
                                </div>
                                <p className="text-slate-400 text-xs">{trend.description}</p>
                            </motion.div>
                        ))
                    ) : (
                        <p className="text-slate-500 text-sm text-center">No trends detected yet.</p>
                    )}
                </CardContent>
            </Card>

            {/* Collaborative Missions Column */}
            <Card className="bg-slate-900/50 border-slate-800 md:col-span-1">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-400" />
                        Collaborative Missions
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {isLoading ? (
                        <div className="flex justify-center p-4"><Loader2 className="animate-spin text-slate-500" /></div>
                    ) : missions.length > 0 ? (
                        missions.map((mission, i) => (
                            <motion.div 
                                key={i}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.1 }}
                                className="bg-purple-900/10 p-3 rounded-lg border border-purple-500/20"
                            >
                                <h4 className="text-purple-300 font-medium text-sm mb-1">{mission.title}</h4>
                                <p className="text-slate-400 text-xs mb-2">{mission.objective}</p>
                                <div className="flex justify-between items-center">
                                    <Badge className="bg-purple-500/20 text-purple-300 text-[10px]">{mission.target_region}</Badge>
                                    <Button 
                                        size="sm" 
                                        className="h-7 text-xs bg-purple-600 hover:bg-purple-700"
                                        onClick={() => handleCreateMission(mission)}
                                    >
                                        Launch
                                    </Button>
                                </div>
                            </motion.div>
                        ))
                    ) : (
                        <p className="text-slate-500 text-sm text-center">No mission suggestions.</p>
                    )}
                </CardContent>
            </Card>

            {/* Reputation Leaderboard */}
            <Card className="bg-slate-900/50 border-slate-800 md:col-span-1">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-400" />
                        Top Contributors
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {isLoading ? (
                        <div className="flex justify-center p-4"><Loader2 className="animate-spin text-slate-500" /></div>
                    ) : topScouts.length > 0 ? (
                        topScouts.map((scout, i) => (
                            <motion.div 
                                key={scout.id}
                                initial={{ opacity: 0, x: 10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                                className="flex items-center gap-3 bg-slate-800/30 p-2 rounded-lg"
                            >
                                <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
                                    i === 0 ? 'bg-amber-500 text-black' : 
                                    i === 1 ? 'bg-slate-300 text-black' :
                                    i === 2 ? 'bg-amber-700 text-white' : 'bg-slate-700 text-white'
                                }`}>
                                    {i + 1}
                                </div>
                                <div className="flex-1">
                                    <h4 className="text-white text-sm font-medium">{scout.full_name}</h4>
                                    <div className="flex items-center gap-2">
                                        <span className="text-xs text-slate-400">{scout.region}</span>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-amber-400 font-bold text-sm">
                                        {scout.performance_metrics?.accuracy_rating || 0}
                                    </div>
                                    <div className="text-[10px] text-slate-500">Reputation</div>
                                </div>
                            </motion.div>
                        ))
                    ) : (
                        <p className="text-slate-500 text-sm text-center">No data available.</p>
                    )}
                    
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full text-slate-500 hover:text-white mt-2"
                        onClick={() => fetchData()}
                    >
                        <RefreshCw className="w-3 h-3 mr-2" /> Refresh Leaderboard
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}