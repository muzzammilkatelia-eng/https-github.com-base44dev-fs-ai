import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, CheckCircle2, Eye, Archive, MapPin, Calendar } from 'lucide-react';

export default function FindingDetails({ finding, onClose, onUpdate }) {
    const priorityColor = (priority) => {
        switch (priority) {
            case 'Critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
            case 'High': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
            case 'Medium': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
            default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={onClose}
        >
            <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
                <Card className="bg-slate-900 border-slate-700">
                    <CardHeader className="flex flex-row items-start justify-between">
                        <div className="flex-1">
                            <CardTitle className="text-white text-2xl mb-2">
                                {finding.player_name}
                            </CardTitle>
                            <p className="text-slate-400">
                                {finding.position} • {finding.player_age}y • {finding.current_club}
                            </p>
                            <div className="flex gap-2 mt-3">
                                <Badge className={priorityColor(finding.priority)}>
                                    {finding.priority}
                                </Badge>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    {finding.finding_type}
                                </Badge>
                                <Badge className={
                                    finding.status === 'New' ? 'bg-amber-500/20 text-amber-400' :
                                    finding.status === 'Under Review' ? 'bg-blue-500/20 text-blue-400' :
                                    finding.status === 'Actioned' ? 'bg-emerald-500/20 text-emerald-400' :
                                    'bg-slate-500/20 text-slate-400'
                                }>
                                    {finding.status}
                                </Badge>
                            </div>
                        </div>
                        <button onClick={onClose} className="text-slate-400 hover:text-white">
                            <X className="w-6 h-6" />
                        </button>
                    </CardHeader>

                    <CardContent className="space-y-6">
                        {/* Scout Info */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-2">Submitted by</p>
                            <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                                    <span className="text-cyan-400 font-bold text-sm">
                                        {finding.scout_name?.charAt(0)}
                                    </span>
                                </div>
                                <div>
                                    <p className="text-white font-medium">{finding.scout_name}</p>
                                    <div className="flex items-center gap-2 text-slate-400 text-xs">
                                        <MapPin className="w-3 h-3" />
                                        {finding.region}
                                        <Calendar className="w-3 h-3 ml-2" />
                                        {new Date(finding.created_date).toLocaleDateString()}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Summary */}
                        <div>
                            <h4 className="text-white font-semibold mb-2">Summary</h4>
                            <p className="text-slate-300 leading-relaxed">{finding.summary}</p>
                        </div>

                        {/* Detailed Report */}
                        {finding.detailed_report && (
                            <div>
                                <h4 className="text-white font-semibold mb-2">Detailed Report</h4>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-300 whitespace-pre-line leading-relaxed">
                                        {finding.detailed_report}
                                    </p>
                                </div>
                            </div>
                        )}

                        {/* Strengths & Weaknesses */}
                        {(finding.key_strengths?.length > 0 || finding.areas_for_development?.length > 0) && (
                            <div className="grid md:grid-cols-2 gap-4">
                                {finding.key_strengths?.length > 0 && (
                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <h4 className="text-emerald-400 font-semibold mb-3">Key Strengths</h4>
                                        <ul className="space-y-2">
                                            {finding.key_strengths.map((strength, idx) => (
                                                <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                                    {strength}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {finding.areas_for_development?.length > 0 && (
                                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                        <h4 className="text-amber-400 font-semibold mb-3">Areas for Development</h4>
                                        <ul className="space-y-2">
                                            {finding.areas_for_development.map((area, idx) => (
                                                <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <span className="text-amber-400 mt-0.5">•</span>
                                                    {area}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Match Data */}
                        {finding.match_data && (
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-3">Match Performance</h4>
                                <div className="grid md:grid-cols-4 gap-3">
                                    <div>
                                        <p className="text-slate-400 text-xs">Opponent</p>
                                        <p className="text-white font-semibold">{finding.match_data.opponent}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs">Rating</p>
                                        <p className="text-cyan-400 font-bold text-lg">{finding.match_data.performance_rating}/10</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs">Goals</p>
                                        <p className="text-white font-semibold">{finding.match_data.goals || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs">Assists</p>
                                        <p className="text-white font-semibold">{finding.match_data.assists || 0}</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Market Intelligence */}
                        {finding.market_intelligence && (
                            <div className="bg-slate-800/50 rounded-lg p-4">
                                <h4 className="text-white font-semibold mb-3">Market Intelligence</h4>
                                <div className="space-y-3">
                                    {finding.market_intelligence.estimated_value && (
                                        <div>
                                            <p className="text-slate-400 text-xs">Estimated Value</p>
                                            <p className="text-amber-400 font-bold text-lg">
                                                €{finding.market_intelligence.estimated_value}M
                                            </p>
                                        </div>
                                    )}
                                    {finding.market_intelligence.contract_expiry && (
                                        <div>
                                            <p className="text-slate-400 text-xs">Contract Expiry</p>
                                            <p className="text-white">{finding.market_intelligence.contract_expiry}</p>
                                        </div>
                                    )}
                                    {finding.market_intelligence.interested_clubs?.length > 0 && (
                                        <div>
                                            <p className="text-slate-400 text-xs mb-2">Interested Clubs</p>
                                            <div className="flex flex-wrap gap-2">
                                                {finding.market_intelligence.interested_clubs.map((club, idx) => (
                                                    <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                                        {club}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Actions */}
                        <div className="flex gap-3 pt-4 border-t border-slate-700">
                            {finding.status === 'New' && (
                                <>
                                    <Button
                                        onClick={() => onUpdate({ status: 'Under Review' })}
                                        className="flex-1 bg-blue-500 hover:bg-blue-600"
                                    >
                                        <Eye className="w-4 h-4 mr-2" />
                                        Mark as Reviewing
                                    </Button>
                                    <Button
                                        onClick={() => onUpdate({ status: 'Actioned' })}
                                        className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                                    >
                                        <CheckCircle2 className="w-4 h-4 mr-2" />
                                        Mark as Actioned
                                    </Button>
                                </>
                            )}
                            {finding.status === 'Under Review' && (
                                <Button
                                    onClick={() => onUpdate({ status: 'Actioned' })}
                                    className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                                >
                                    <CheckCircle2 className="w-4 h-4 mr-2" />
                                    Mark as Actioned
                                </Button>
                            )}
                            <Button
                                onClick={() => onUpdate({ status: 'Archived' })}
                                variant="outline"
                                className="border-slate-700"
                            >
                                <Archive className="w-4 h-4 mr-2" />
                                Archive
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        </motion.div>
    );
}