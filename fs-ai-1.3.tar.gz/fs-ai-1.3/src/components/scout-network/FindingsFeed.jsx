import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { MessageSquare, ThumbsUp, Plus, User, Eye, EyeOff, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function FindingsFeed() {
    const [findings, setFindings] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [user, setUser] = useState(null);
    const [newFinding, setNewFinding] = useState({
        player_name: '',
        finding_type: 'New Discovery',
        summary: '',
        is_anonymous: false
    });

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
        loadFindings();
    }, []);

    const loadFindings = async () => {
        try {
            const data = await base44.entities.ScoutFinding.list('-created_date', 20);
            setFindings(data);
        } catch (error) {
            console.error("Error loading findings:", error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!user) return toast.error("You must be logged in");

        try {
            await base44.entities.ScoutFinding.create({
                ...newFinding,
                network_id: 'global', // Defaulting to global for this implementation
                scout_id: user.id,
                scout_name: user.full_name,
                status: 'New',
                priority: 'Medium'
            });
            toast.success("Finding shared successfully!");
            setShowForm(false);
            setNewFinding({ player_name: '', finding_type: 'New Discovery', summary: '', is_anonymous: false });
            loadFindings();
        } catch (error) {
            toast.error("Failed to share finding");
        }
    };

    const handleVote = async (finding) => {
        try {
            await base44.entities.ScoutFinding.update(finding.id, {
                upvotes: (finding.upvotes || 0) + 1
            });
            setFindings(prev => prev.map(f => f.id === finding.id ? { ...f, upvotes: (f.upvotes || 0) + 1 } : f));
        } catch (error) {
            toast.error("Failed to upvote");
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-cyan-400" />
                    Live Findings Feed
                </h2>
                <Button onClick={() => setShowForm(!showForm)} className="bg-cyan-600 hover:bg-cyan-700">
                    <Plus className="w-4 h-4 mr-2" /> Share Finding
                </Button>
            </div>

            <AnimatePresence>
                {showForm && (
                    <motion.div 
                        initial={{ opacity: 0, height: 0 }} 
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6"
                    >
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <Input 
                                    placeholder="Player Name" 
                                    value={newFinding.player_name}
                                    onChange={(e) => setNewFinding({...newFinding, player_name: e.target.value})}
                                    required
                                    className="bg-slate-800 border-slate-700"
                                />
                                <Select 
                                    value={newFinding.finding_type} 
                                    onValueChange={(v) => setNewFinding({...newFinding, finding_type: v})}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700">
                                        <SelectValue placeholder="Type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="New Discovery">New Discovery</SelectItem>
                                        <SelectItem value="Performance Alert">Performance Alert</SelectItem>
                                        <SelectItem value="Transfer Intelligence">Transfer Intelligence</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <Textarea 
                                placeholder="What did you spot? (Summary)" 
                                value={newFinding.summary}
                                onChange={(e) => setNewFinding({...newFinding, summary: e.target.value})}
                                required
                                className="bg-slate-800 border-slate-700"
                            />
                            <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                    <Switch 
                                        id="anonymous-mode"
                                        checked={newFinding.is_anonymous}
                                        onCheckedChange={(c) => setNewFinding({...newFinding, is_anonymous: c})}
                                    />
                                    <Label htmlFor="anonymous-mode" className="text-slate-300 flex items-center gap-2">
                                        {newFinding.is_anonymous ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                        Share Anonymously
                                    </Label>
                                </div>
                                <Button type="submit" className="bg-green-600 hover:bg-green-700">
                                    <Send className="w-4 h-4 mr-2" /> Submit
                                </Button>
                            </div>
                        </form>
                    </motion.div>
                )}
            </AnimatePresence>

            <div className="space-y-4">
                {findings.map((finding) => (
                    <motion.div 
                        key={finding.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="bg-slate-900/50 border border-slate-800 rounded-lg p-4"
                    >
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                                    {finding.is_anonymous ? <EyeOff className="w-4 h-4 text-slate-400" /> : <User className="w-4 h-4 text-cyan-400" />}
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-white">
                                        {finding.is_anonymous ? "Anonymous Scout" : finding.scout_name}
                                    </p>
                                    <p className="text-xs text-slate-500">
                                        {new Date(finding.created_date).toLocaleDateString()}
                                    </p>
                                </div>
                            </div>
                            <Badge variant="outline" className="text-cyan-400 border-cyan-500/30">
                                {finding.finding_type}
                            </Badge>
                        </div>
                        
                        <h4 className="text-lg font-semibold text-white mb-1">{finding.player_name}</h4>
                        <p className="text-slate-300 text-sm mb-3">{finding.summary}</p>
                        
                        <div className="flex items-center gap-4 pt-2 border-t border-slate-800">
                            <button 
                                onClick={() => handleVote(finding)}
                                className="flex items-center gap-1 text-slate-400 hover:text-green-400 transition-colors text-sm"
                            >
                                <ThumbsUp className="w-4 h-4" />
                                <span>{finding.upvotes || 0}</span>
                            </button>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
    );
}