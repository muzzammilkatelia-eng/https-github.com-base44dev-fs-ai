import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Eye, CheckCircle2, Archive, TrendingUp, AlertCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import FindingDetails from './FindingDetails';

export default function FindingsManager({ network }) {
    const [selectedFinding, setSelectedFinding] = useState(null);
    const queryClient = useQueryClient();

    const { data: findings = [], isLoading } = useQuery({
        queryKey: ['scout-findings', network.id],
        queryFn: () => base44.entities.ScoutFinding.filter({ network_id: network.id })
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ScoutFinding.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-findings'] });
            toast.success('Finding updated');
        }
    });

    const shareFinding = async (finding) => {
        if (finding.is_shared) return;
        toast.loading('Sharing to network...', { id: 'share' });
        try {
            await updateMutation.mutateAsync({
                id: finding.id,
                data: { 
                    is_shared: true,
                    is_anonymized: true // Default to anonymized for safety
                }
            });
            toast.success('Shared anonymized finding to network!', { id: 'share' });
        } catch (error) {
            toast.error('Failed to share', { id: 'share' });
        }
    };

    const createScoutingReport = async (finding) => {
        toast.loading('Creating scouting report...', { id: 'create-report' });
        
        try {
            await base44.entities.ScoutingReport.create({
                player_name: finding.player_name,
                player_age: finding.player_age,
                position: finding.position,
                modules_activated: ['Scout Network Import'],
                overall_verdict: finding.detailed_report,
                recommendation: finding.recommendation,
                notes: `Auto-imported from ${network.network_name} - Scout: ${finding.scout_name}`
            });

            await updateMutation.mutateAsync({
                id: finding.id,
                data: { status: 'Actioned' }
            });

            toast.success('Scouting report created!', { id: 'create-report' });
        } catch (error) {
            toast.error('Failed to create report', { id: 'create-report' });
        }
    };

    const newFindings = findings.filter(f => f.status === 'New');
    const underReview = findings.filter(f => f.status === 'Under Review');
    const actioned = findings.filter(f => f.status === 'Actioned');
    const archived = findings.filter(f => f.status === 'Archived');

    const priorityColor = (priority) => {
        switch (priority) {
            case 'Critical': return 'bg-red-500/20 text-red-400';
            case 'High': return 'bg-amber-500/20 text-amber-400';
            case 'Medium': return 'bg-blue-500/20 text-blue-400';
            default: return 'bg-slate-500/20 text-slate-400';
        }
    };

    const FindingCard = ({ finding }) => (
        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
        >
            <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-all">
                <CardContent className="pt-4">
                    <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                            <h4 className="text-white font-bold">{finding.player_name}</h4>
                            <p className="text-slate-400 text-sm">
                                {finding.position} • {finding.player_age}y • {finding.current_club}
                            </p>
                            <p className="text-slate-500 text-xs mt-1">
                                Scout: {finding.scout_name} • {finding.region}
                            </p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                            <Badge className={priorityColor(finding.priority)}>
                                {finding.priority}
                            </Badge>
                            <Badge className="bg-purple-500/20 text-purple-400">
                                {finding.finding_type}
                            </Badge>
                        </div>
                    </div>

                    <p className="text-slate-300 text-sm mb-3 line-clamp-2">
                        {finding.summary}
                    </p>

                    {finding.recommendation && (
                        <div className="bg-slate-900/50 rounded p-2 mb-3">
                            <p className="text-cyan-400 text-xs font-semibold mb-1">Recommendation:</p>
                            <p className="text-slate-300 text-xs">{finding.recommendation}</p>
                        </div>
                    )}

                    <div className="flex gap-2">
                        <Button
                            onClick={() => setSelectedFinding(finding)}
                            variant="outline"
                            size="sm"
                            className="flex-1 border-slate-700"
                        >
                            <Eye className="w-3 h-3 mr-2" />
                            View
                        </Button>
                        <Button
                            onClick={() => shareFinding(finding)}
                            variant="outline"
                            size="sm"
                            disabled={finding.is_shared}
                            className={`flex-1 border-slate-700 ${finding.is_shared ? 'text-cyan-400' : ''}`}
                        >
                            <TrendingUp className="w-3 h-3 mr-2" />
                            {finding.is_shared ? 'Shared' : 'Share'}
                        </Button>
                        {finding.status === 'New' && (
                            <Button
                                onClick={() => createScoutingReport(finding)}
                                size="sm"
                                className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            >
                                <CheckCircle2 className="w-3 h-3 mr-2" />
                                Create Report
                            </Button>
                        )}
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );

    if (isLoading) {
        return (
            <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-amber-500/10 border-amber-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">New</p>
                                <p className="text-3xl font-bold text-white">{newFindings.length}</p>
                            </div>
                            <AlertCircle className="w-6 h-6 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-blue-500/10 border-blue-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Review</p>
                                <p className="text-3xl font-bold text-white">{underReview.length}</p>
                            </div>
                            <Eye className="w-6 h-6 text-blue-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-emerald-500/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Actioned</p>
                                <p className="text-3xl font-bold text-white">{actioned.length}</p>
                            </div>
                            <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-500/10 border-slate-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Archived</p>
                                <p className="text-3xl font-bold text-white">{archived.length}</p>
                            </div>
                            <Archive className="w-6 h-6 text-slate-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Tabs defaultValue="new" className="space-y-6">
                <TabsList className="bg-slate-900 border border-slate-800">
                    <TabsTrigger value="new">
                        New ({newFindings.length})
                    </TabsTrigger>
                    <TabsTrigger value="review">
                        Under Review ({underReview.length})
                    </TabsTrigger>
                    <TabsTrigger value="actioned">
                        Actioned ({actioned.length})
                    </TabsTrigger>
                    <TabsTrigger value="archived">
                        Archived ({archived.length})
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="new" className="space-y-4">
                    {newFindings.length === 0 ? (
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="py-12 text-center">
                                <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                <p className="text-slate-400">No new findings</p>
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid gap-4">
                            {newFindings.map(finding => <FindingCard key={finding.id} finding={finding} />)}
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="review" className="space-y-4">
                    {underReview.length === 0 ? (
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="py-12 text-center">
                                <Eye className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                <p className="text-slate-400">No findings under review</p>
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid gap-4">
                            {underReview.map(finding => <FindingCard key={finding.id} finding={finding} />)}
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="actioned" className="space-y-4">
                    {actioned.length === 0 ? (
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="py-12 text-center">
                                <CheckCircle2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                <p className="text-slate-400">No actioned findings</p>
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid gap-4">
                            {actioned.map(finding => <FindingCard key={finding.id} finding={finding} />)}
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="archived" className="space-y-4">
                    {archived.length === 0 ? (
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="py-12 text-center">
                                <Archive className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                <p className="text-slate-400">No archived findings</p>
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid gap-4">
                            {archived.map(finding => <FindingCard key={finding.id} finding={finding} />)}
                        </div>
                    )}
                </TabsContent>
            </Tabs>

            <AnimatePresence>
                {selectedFinding && (
                    <FindingDetails
                        finding={selectedFinding}
                        onClose={() => setSelectedFinding(null)}
                        onUpdate={(data) => {
                            updateMutation.mutate({ id: selectedFinding.id, data });
                            setSelectedFinding(null);
                        }}
                    />
                )}
            </AnimatePresence>
        </div>
    );
}