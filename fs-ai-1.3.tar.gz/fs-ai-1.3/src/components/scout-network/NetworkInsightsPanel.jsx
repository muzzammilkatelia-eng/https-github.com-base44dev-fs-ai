import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Globe, Target, RefreshCw, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';

export default function NetworkInsightsPanel({ onTrendsLoaded }) {
    const [trends, setTrends] = useState(null);
    const [loading, setLoading] = useState(false);

    const analyzeTrends = async () => {
        setLoading(true);
        try {
            const { data } = await base44.functions.invoke('analyzeNetworkTrends');
            setTrends(data);
            if (onTrendsLoaded) onTrendsLoaded(data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        analyzeTrends();
    }, []);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-purple-400" />
                    AI Network Insights
                </CardTitle>
                <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={analyzeTrends}
                    disabled={loading}
                    className="text-slate-400"
                >
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
            </CardHeader>
            <CardContent>
                {loading && !trends ? (
                    <div className="py-8 text-center text-slate-500">
                        Analyzing network patterns...
                    </div>
                ) : trends ? (
                    <div className="space-y-6">
                        {/* Emerging Hotspots */}
                        <div>
                            <h4 className="text-slate-400 text-xs font-semibold uppercase mb-3 flex items-center gap-2">
                                <Globe className="w-3 h-3" /> Emerging Hotspots
                            </h4>
                            <div className="flex flex-wrap gap-2">
                                {trends.emerging_hotspots?.map((hotspot, i) => (
                                    <Badge key={i} variant="outline" className="border-cyan-500/30 text-cyan-400">
                                        {hotspot}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {/* AI Trends */}
                        <div className="space-y-3">
                            <h4 className="text-slate-400 text-xs font-semibold uppercase mb-2 flex items-center gap-2">
                                <Zap className="w-3 h-3" /> Detected Patterns
                            </h4>
                            {trends.trends?.map((trend, i) => (
                                <motion.div 
                                    key={i}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: i * 0.1 }}
                                    className="bg-slate-800/50 rounded-lg p-3 border border-slate-700"
                                >
                                    <div className="flex justify-between items-start mb-1">
                                        <h5 className="text-white font-medium text-sm">{trend.title}</h5>
                                        <Badge className="bg-purple-500/20 text-purple-400 text-[10px]">
                                            {trend.confidence}% Conf.
                                        </Badge>
                                    </div>
                                    <p className="text-slate-400 text-xs">{trend.description}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="py-8 text-center text-slate-500">
                        No insights available.
                    </div>
                )}
            </CardContent>
        </Card>
    );
}