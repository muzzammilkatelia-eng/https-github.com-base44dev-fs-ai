import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Network, Plus, Edit, Trash2, Users, MapPin, Target, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function NetworkManager({ onNetworkSelect }) {
    const [isCreating, setIsCreating] = useState(false);
    const [editingNetwork, setEditingNetwork] = useState(null);
    const [formData, setFormData] = useState({
        network_name: '',
        description: '',
        status: 'Active'
    });

    const queryClient = useQueryClient();

    const { data: networks = [], isLoading } = useQuery({
        queryKey: ['scout-networks'],
        queryFn: () => base44.entities.ScoutNetwork.list('-created_date', 100)
    });

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['scout-findings'],
        queryFn: () => base44.entities.ScoutFinding.list('-created_date', 100)
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.ScoutNetwork.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-networks'] });
            resetForm();
            toast.success('Network created!');
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ScoutNetwork.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-networks'] });
            resetForm();
            toast.success('Network updated!');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.ScoutNetwork.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-networks'] });
            toast.success('Network deleted');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingNetwork) {
            updateMutation.mutate({ id: editingNetwork.id, data: formData });
        } else {
            createMutation.mutate(formData);
        }
    };

    const handleEdit = (network) => {
        setEditingNetwork(network);
        setFormData({
            network_name: network.network_name,
            description: network.description || '',
            status: network.status
        });
        setIsCreating(true);
    };

    const resetForm = () => {
        setIsCreating(false);
        setEditingNetwork(null);
        setFormData({
            network_name: '',
            description: '',
            status: 'Active'
        });
    };

    const getNetworkFindings = (networkId) => {
        return findings.filter(f => f.network_id === networkId);
    };

    const getNetworkScouts = (network) => {
        if (!network.assigned_scouts) return [];
        return scouts.filter(s => network.assigned_scouts.includes(s.id));
    };

    if (isLoading) {
        return (
            <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                        <Network className="w-6 h-6 text-cyan-400" />
                        Scouting Networks
                    </h2>
                    <p className="text-slate-400 text-sm mt-1">
                        {networks.length} networks • {scouts.length} scouts • {findings.length} findings
                    </p>
                </div>
                <Button
                    onClick={() => setIsCreating(!isCreating)}
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Network
                </Button>
            </div>

            <AnimatePresence>
                {isCreating && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">
                                    {editingNetwork ? 'Edit Network' : 'Create New Network'}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Network Name</label>
                                        <Input
                                            value={formData.network_name}
                                            onChange={(e) => setFormData({ ...formData, network_name: e.target.value })}
                                            placeholder="e.g., South American Wonderkids Network"
                                            className="bg-slate-800 border-slate-700 text-white"
                                            required
                                        />
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Description</label>
                                        <Textarea
                                            value={formData.description}
                                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                            placeholder="Network purpose and objectives..."
                                            className="bg-slate-800 border-slate-700 text-white h-24"
                                        />
                                    </div>

                                    <div className="flex gap-3">
                                        <Button
                                            type="submit"
                                            disabled={createMutation.isPending || updateMutation.isPending}
                                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                                        >
                                            {editingNetwork ? 'Update' : 'Create'} Network
                                        </Button>
                                        <Button
                                            type="button"
                                            onClick={resetForm}
                                            variant="outline"
                                            className="border-slate-700"
                                        >
                                            Cancel
                                        </Button>
                                    </div>
                                </form>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>

            {networks.length === 0 ? (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-16 text-center">
                        <Network className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No networks created yet</p>
                        <p className="text-slate-500 text-sm mt-2">Create your first scouting network to get started</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {networks.map((network) => {
                        const networkScouts = getNetworkScouts(network);
                        const networkFindings = getNetworkFindings(network.id);
                        const newFindings = networkFindings.filter(f => f.status === 'New').length;

                        return (
                            <motion.div
                                key={network.id}
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer group">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex-1" onClick={() => onNetworkSelect?.(network)}>
                                                <h3 className="text-white font-bold mb-1 group-hover:text-cyan-400 transition-colors">
                                                    {network.network_name}
                                                </h3>
                                                <p className="text-slate-400 text-sm line-clamp-2">
                                                    {network.description || 'No description'}
                                                </p>
                                            </div>
                                            <Badge className={
                                                network.status === 'Active' 
                                                    ? 'bg-emerald-500/20 text-emerald-400'
                                                    : 'bg-slate-500/20 text-slate-400'
                                            }>
                                                {network.status}
                                            </Badge>
                                        </div>

                                        <div className="space-y-3 mb-4">
                                            <div className="flex items-center justify-between text-sm">
                                                <div className="flex items-center gap-2 text-slate-400">
                                                    <Users className="w-4 h-4" />
                                                    <span>{networkScouts.length} Scouts</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-slate-400">
                                                    <Target className="w-4 h-4" />
                                                    <span>{networkFindings.length} Findings</span>
                                                </div>
                                            </div>

                                            {newFindings > 0 && (
                                                <Badge className="bg-amber-500/20 text-amber-400 w-full justify-center">
                                                    {newFindings} New Findings
                                                </Badge>
                                            )}

                                            {network.target_regions && network.target_regions.length > 0 && (
                                                <div className="flex items-start gap-2">
                                                    <MapPin className="w-4 h-4 text-purple-400 mt-0.5" />
                                                    <div className="flex flex-wrap gap-1">
                                                        {network.target_regions.slice(0, 3).map((region, idx) => (
                                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400 text-xs">
                                                                {region}
                                                            </Badge>
                                                        ))}
                                                        {network.target_regions.length > 3 && (
                                                            <Badge className="bg-slate-700 text-slate-400 text-xs">
                                                                +{network.target_regions.length - 3}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <div className="flex gap-2 pt-3 border-t border-slate-700">
                                            <Button
                                                onClick={() => handleEdit(network)}
                                                variant="outline"
                                                size="sm"
                                                className="flex-1 border-slate-700 hover:bg-slate-800"
                                            >
                                                <Edit className="w-3 h-3 mr-2" />
                                                Edit
                                            </Button>
                                            <Button
                                                onClick={() => {
                                                    if (confirm('Delete this network?')) {
                                                        deleteMutation.mutate(network.id);
                                                    }
                                                }}
                                                variant="outline"
                                                size="sm"
                                                className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                                            >
                                                <Trash2 className="w-3 h-3" />
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}