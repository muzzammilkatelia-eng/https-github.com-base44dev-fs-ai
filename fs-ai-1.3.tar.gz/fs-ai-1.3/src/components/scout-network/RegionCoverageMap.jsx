import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Globe2, Users, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RegionCoverageMap() {
    const { data: assignments = [] } = useQuery({
        queryKey: ['scoutAssignments'],
        queryFn: () => base44.entities.ScoutAssignment.filter({ status: 'Active' })
    });

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const regionCoverage = assignments.reduce((acc, assignment) => {
        const region = assignment.region || 'Unassigned';
        if (!acc[region]) {
            acc[region] = {
                scouts: 0,
                assignments: 0,
                countries: new Set(),
                playersIdentified: 0
            };
        }
        acc[region].scouts += 1;
        acc[region].assignments += 1;
        acc[region].playersIdentified += assignment.players_identified || 0;
        assignment.countries?.forEach(c => acc[region].countries.add(c));
        return acc;
    }, {});

    const regions = Object.keys(regionCoverage);

    const getCoverageColor = (scouts) => {
        if (scouts === 0) return 'bg-red-500/20 text-red-400 border-red-500/30';
        if (scouts === 1) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Globe2 className="w-5 h-5 text-cyan-400" />
                    Regional Coverage ({regions.length} Regions)
                </CardTitle>
            </CardHeader>
            <CardContent>
                {regions.length === 0 ? (
                    <div className="text-center py-12 text-slate-400">
                        <MapPin className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p>No active scout assignments. Create assignments to track coverage.</p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {regions.map((region) => {
                            const coverage = regionCoverage[region];
                            return (
                                <motion.div
                                    key={region}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <div className="flex items-center justify-between mb-3">
                                        <h3 className="text-white font-semibold">{region}</h3>
                                        <Badge className={getCoverageColor(coverage.scouts)}>
                                            {coverage.scouts} Scout{coverage.scouts !== 1 ? 's' : ''}
                                        </Badge>
                                    </div>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Countries:</span>
                                            <span className="text-white">{coverage.countries.size}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Players Found:</span>
                                            <span className="text-emerald-400">{coverage.playersIdentified}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Assignments:</span>
                                            <span className="text-cyan-400">{coverage.assignments}</span>
                                        </div>
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}