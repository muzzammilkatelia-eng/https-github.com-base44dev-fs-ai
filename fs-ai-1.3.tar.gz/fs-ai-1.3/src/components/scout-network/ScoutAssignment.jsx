import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Send, FileText } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ScoutAssignment({ network, scouts }) {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [findingData, setFindingData] = useState({
        player_name: '',
        player_age: null,
        position: '',
        current_club: '',
        league: '',
        region: '',
        finding_type: 'New Discovery',
        priority: 'Medium',
        summary: '',
        detailed_report: '',
        recommendation: 'Continue Watching'
    });

    const queryClient = useQueryClient();

    const createFindingMutation = useMutation({
        mutationFn: (data) => base44.entities.ScoutFinding.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-findings'] });
            queryClient.invalidateQueries({ queryKey: ['scout-networks'] });
            toast.success('Finding submitted successfully!');
            resetForm();
        }
    });

    const resetForm = () => {
        setFindingData({
            player_name: '',
            player_age: null,
            position: '',
            current_club: '',
            league: '',
            region: '',
            finding_type: 'New Discovery',
            priority: 'Medium',
            summary: '',
            detailed_report: '',
            recommendation: 'Continue Watching'
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Get current user to use as scout
        const user = await base44.auth.me();
        
        createFindingMutation.mutate({
            network_id: network.id,
            scout_id: user.id,
            scout_name: user.full_name || user.email,
            ...findingData
        });
    };

    const networkScouts = scouts.filter(s => network.assigned_scouts?.includes(s.id));

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Network Scouts</CardTitle>
                </CardHeader>
                <CardContent>
                    {networkScouts.length === 0 ? (
                        <p className="text-slate-400 text-center py-4">No scouts assigned to this network</p>
                    ) : (
                        <div className="grid md:grid-cols-2 gap-3">
                            {networkScouts.map(scout => (
                                <div key={scout.id} className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-white font-medium">{scout.full_name}</p>
                                    <p className="text-slate-400 text-xs mb-2">{scout.region}</p>
                                    <div className="flex gap-2 flex-wrap">
                                        {scout.specializations?.map((spec, idx) => (
                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400 text-xs">
                                                {spec}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-cyan-400" />
                        Submit Finding
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Player Name *</label>
                                <Input
                                    value={findingData.player_name}
                                    onChange={(e) => setFindingData({ ...findingData, player_name: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    required
                                />
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Age</label>
                                <Input
                                    type="number"
                                    value={findingData.player_age || ''}
                                    onChange={(e) => setFindingData({ ...findingData, player_age: parseInt(e.target.value) })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Position</label>
                                <Select
                                    value={findingData.position}
                                    onValueChange={(v) => setFindingData({ ...findingData, position: v })}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Select position..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                        <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                        <SelectItem value="Full-Back">Full-Back</SelectItem>
                                        <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                        <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                        <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                        <SelectItem value="Winger">Winger</SelectItem>
                                        <SelectItem value="Striker">Striker</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Current Club</label>
                                <Input
                                    value={findingData.current_club}
                                    onChange={(e) => setFindingData({ ...findingData, current_club: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">League</label>
                                <Input
                                    value={findingData.league}
                                    onChange={(e) => setFindingData({ ...findingData, league: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Region</label>
                                <Input
                                    value={findingData.region}
                                    onChange={(e) => setFindingData({ ...findingData, region: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Finding Type</label>
                                <Select
                                    value={findingData.finding_type}
                                    onValueChange={(v) => setFindingData({ ...findingData, finding_type: v })}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="New Discovery">New Discovery</SelectItem>
                                        <SelectItem value="Progress Update">Progress Update</SelectItem>
                                        <SelectItem value="Performance Alert">Performance Alert</SelectItem>
                                        <SelectItem value="Transfer Intelligence">Transfer Intelligence</SelectItem>
                                        <SelectItem value="Match Report">Match Report</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Priority</label>
                                <Select
                                    value={findingData.priority}
                                    onValueChange={(v) => setFindingData({ ...findingData, priority: v })}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Critical">Critical</SelectItem>
                                        <SelectItem value="High">High</SelectItem>
                                        <SelectItem value="Medium">Medium</SelectItem>
                                        <SelectItem value="Low">Low</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div>
                            <label className="text-slate-300 text-sm mb-2 block">Summary *</label>
                            <Textarea
                                value={findingData.summary}
                                onChange={(e) => setFindingData({ ...findingData, summary: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white h-20"
                                placeholder="Brief summary of the finding..."
                                required
                            />
                        </div>

                        <div>
                            <label className="text-slate-300 text-sm mb-2 block">Detailed Report</label>
                            <Textarea
                                value={findingData.detailed_report}
                                onChange={(e) => setFindingData({ ...findingData, detailed_report: e.target.value })}
                                className="bg-slate-800 border-slate-700 text-white h-32"
                                placeholder="Comprehensive scouting report..."
                            />
                        </div>

                        <div>
                            <label className="text-slate-300 text-sm mb-2 block">Recommendation</label>
                            <Select
                                value={findingData.recommendation}
                                onValueChange={(v) => setFindingData({ ...findingData, recommendation: v })}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Immediate Action">Immediate Action</SelectItem>
                                    <SelectItem value="Monitor Closely">Monitor Closely</SelectItem>
                                    <SelectItem value="Continue Watching">Continue Watching</SelectItem>
                                    <SelectItem value="No Further Action">No Further Action</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <Button
                            type="submit"
                            disabled={createFindingMutation.isPending}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                        >
                            <Send className="w-4 h-4 mr-2" />
                            Submit Finding
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}