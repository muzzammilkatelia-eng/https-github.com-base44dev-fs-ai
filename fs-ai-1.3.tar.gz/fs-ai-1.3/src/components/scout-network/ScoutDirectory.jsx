import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { createPageUrl } from '../../utils';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Search, MapPin, Award, User, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ScoutDirectory() {
    const [searchQuery, setSearchQuery] = useState('');
    const [regionFilter, setRegionFilter] = useState('all');
    const [statusFilter, setStatusFilter] = useState('all');

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list('-created_date', 500)
    });

    const filteredScouts = scouts.filter(scout => {
        const matchesSearch = scout.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            scout.region?.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesRegion = regionFilter === 'all' || scout.region === regionFilter;
        const matchesStatus = statusFilter === 'all' || scout.status === statusFilter;
        return matchesSearch && matchesRegion && matchesStatus;
    });

    const regions = [...new Set(scouts.map(s => s.region).filter(Boolean))];

    return (
        <div className="space-y-6">
            {/* Filters */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Scout Directory</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                                placeholder="Search scouts..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10 bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <Select value={regionFilter} onValueChange={setRegionFilter}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Region" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Regions</SelectItem>
                                {regions.map(region => (
                                    <SelectItem key={region} value={region}>{region}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Status</SelectItem>
                                <SelectItem value="Active">Active</SelectItem>
                                <SelectItem value="Vetting">Vetting</SelectItem>
                                <SelectItem value="Inactive">Inactive</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Scout Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredScouts.map((scout) => (
                    <motion.div
                        key={scout.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                    >
                        <Link to={createPageUrl(`ScoutProfile?id=${scout.id}`)}>
                            <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer group">
                                <CardContent className="pt-6">
                                    <div className="flex items-start gap-4 mb-4">
                                        <Avatar className="w-12 h-12">
                                            <AvatarFallback className="bg-gradient-to-br from-cyan-500 to-blue-600 text-white">
                                                {scout.full_name?.split(' ').map(n => n[0]).join('')}
                                            </AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <h3 className="text-white font-bold group-hover:text-cyan-400 transition-colors">
                                                        {scout.full_name}
                                                    </h3>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <MapPin className="w-3 h-3 text-slate-500" />
                                                        <span className="text-slate-400 text-xs">{scout.region}</span>
                                                    </div>
                                                </div>
                                                <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition-colors" />
                                            </div>
                                            <div className="flex items-center gap-2 mt-3">
                                                <Badge className={
                                                    scout.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400' :
                                                    scout.status === 'Vetting' ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-slate-500/20 text-slate-400'
                                                }>
                                                    {scout.status}
                                                </Badge>
                                                {scout.verification_status === 'Verified' && (
                                                    <Badge className="bg-blue-500/20 text-blue-400">
                                                        <Award className="w-3 h-3 mr-1" />
                                                        Verified
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    {scout.specializations && scout.specializations.length > 0 && (
                                        <div className="space-y-2">
                                            <p className="text-slate-400 text-xs">Specializations:</p>
                                            <div className="flex flex-wrap gap-1">
                                                {scout.specializations.slice(0, 3).map((spec, idx) => (
                                                    <Badge key={idx} className="bg-purple-500/20 text-purple-400 text-xs">
                                                        {spec}
                                                    </Badge>
                                                ))}
                                                {scout.specializations.length > 3 && (
                                                    <Badge className="bg-slate-700 text-slate-400 text-xs">
                                                        +{scout.specializations.length - 3}
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    {scout.performance_metrics && (
                                        <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-700">
                                            <div className="text-center">
                                                <p className="text-slate-400 text-xs">Reports</p>
                                                <p className="text-white font-bold">{scout.performance_metrics.reports_submitted || 0}</p>
                                            </div>
                                            <div className="text-center">
                                                <p className="text-slate-400 text-xs">Success Rate</p>
                                                <p className="text-emerald-400 font-bold">{scout.performance_metrics.accuracy_rating || 0}%</p>
                                            </div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </Link>
                    </motion.div>
                ))}
            </div>

            {filteredScouts.length === 0 && (
                <Card className="bg-slate-800/30 border-slate-700">
                    <CardContent className="py-12 text-center">
                        <User className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No scouts found</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}