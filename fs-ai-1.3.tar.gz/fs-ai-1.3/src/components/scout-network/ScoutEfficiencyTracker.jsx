import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Award, Target, FileText } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ScoutEfficiencyTracker() {
    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const { data: assignments = [] } = useQuery({
        queryKey: ['scoutAssignments'],
        queryFn: () => base44.entities.ScoutAssignment.list()
    });

    const scoutPerformance = scouts.map(scout => {
        const scoutAssignments = assignments.filter(a => a.scout_id === scout.id);
        const totalPlayers = scoutAssignments.reduce((sum, a) => sum + (a.players_identified || 0), 0);
        const totalReports = scoutAssignments.reduce((sum, a) => sum + (a.reports_submitted || 0), 0);
        const avgEfficiency = scoutAssignments.length > 0
            ? scoutAssignments.reduce((sum, a) => sum + (a.efficiency_score || 0), 0) / scoutAssignments.length
            : 0;

        return {
            ...scout,
            assignments: scoutAssignments.length,
            playersIdentified: totalPlayers,
            reportsSubmitted: totalReports,
            efficiency: avgEfficiency
        };
    }).sort((a, b) => b.efficiency - a.efficiency);

    const getEfficiencyColor = (score) => {
        if (score >= 80) return 'emerald';
        if (score >= 60) return 'cyan';
        if (score >= 40) return 'amber';
        return 'red';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    Scout Performance & Efficiency
                </CardTitle>
            </CardHeader>
            <CardContent>
                {scoutPerformance.length === 0 ? (
                    <div className="text-center py-12 text-slate-400">
                        <Award className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p>No scouts in the network yet</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {scoutPerformance.map((scout, i) => {
                            const efficiencyColor = getEfficiencyColor(scout.efficiency);
                            return (
                                <motion.div
                                    key={scout.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 0.05 }}
                                    className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h4 className="text-white font-semibold text-lg">{scout.name}</h4>
                                            <p className="text-slate-400 text-sm">{scout.email}</p>
                                        </div>
                                        <Badge className={`bg-${efficiencyColor}-500/20 text-${efficiencyColor}-400 border-${efficiencyColor}-500/30`}>
                                            {scout.efficiency.toFixed(0)}% Efficiency
                                        </Badge>
                                    </div>

                                    <div className="grid grid-cols-3 gap-4 mb-4">
                                        <div className="text-center p-3 bg-slate-900/50 rounded">
                                            <Target className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                                            <p className="text-2xl font-bold text-white">{scout.assignments}</p>
                                            <p className="text-slate-400 text-xs">Assignments</p>
                                        </div>
                                        <div className="text-center p-3 bg-slate-900/50 rounded">
                                            <Users className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                                            <p className="text-2xl font-bold text-white">{scout.playersIdentified}</p>
                                            <p className="text-slate-400 text-xs">Players Found</p>
                                        </div>
                                        <div className="text-center p-3 bg-slate-900/50 rounded">
                                            <FileText className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                                            <p className="text-2xl font-bold text-white">{scout.reportsSubmitted}</p>
                                            <p className="text-slate-400 text-xs">Reports</p>
                                        </div>
                                    </div>

                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-slate-400 text-sm">Overall Performance</span>
                                            <span className="text-white font-semibold text-sm">{scout.efficiency.toFixed(0)}%</span>
                                        </div>
                                        <Progress value={scout.efficiency} className="h-2" />
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}