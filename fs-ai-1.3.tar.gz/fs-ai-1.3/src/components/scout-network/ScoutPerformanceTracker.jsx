import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, CheckCircle2, Star } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ScoutPerformanceTracker() {
    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts-perf'],
        queryFn: () => base44.entities.Scout.filter({ status: 'Active' })
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['findings-all'],
        queryFn: () => base44.entities.ScoutFinding.list('-created_date', 200)
    });

    // Calculate performance metrics for each scout
    const scoutPerformance = scouts.map(scout => {
        const scoutFindings = findings.filter(f => f.scout_id === scout.id);
        const highPriorityFindings = scoutFindings.filter(f => f.priority === 'Critical' || f.priority === 'High').length;
        const actionedFindings = scoutFindings.filter(f => f.status === 'Actioned').length;
        
        return {
            ...scout,
            total_reports: scoutFindings.length,
            high_priority_reports: highPriorityFindings,
            actioned_reports: actionedFindings,
            success_rate: scoutFindings.length > 0 ? Math.round((actionedFindings / scoutFindings.length) * 100) : 0,
            avg_priority_score: highPriorityFindings / Math.max(scoutFindings.length, 1) * 100
        };
    }).sort((a, b) => b.success_rate - a.success_rate);

    const getRatingBadge = (successRate) => {
        if (successRate >= 80) return { label: 'Elite', color: 'bg-emerald-500/20 text-emerald-400' };
        if (successRate >= 60) return { label: 'Excellent', color: 'bg-blue-500/20 text-blue-400' };
        if (successRate >= 40) return { label: 'Good', color: 'bg-cyan-500/20 text-cyan-400' };
        if (successRate >= 20) return { label: 'Fair', color: 'bg-amber-500/20 text-amber-400' };
        return { label: 'Developing', color: 'bg-slate-500/20 text-slate-400' };
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Star className="w-5 h-5 text-amber-400" />
                    Scout Performance Dashboard
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-slate-800/50 rounded-lg p-4">
                        <p className="text-slate-400 text-sm mb-1">Active Scouts</p>
                        <p className="text-3xl font-bold text-white">{scouts.length}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-4">
                        <p className="text-slate-400 text-sm mb-1">Total Reports</p>
                        <p className="text-3xl font-bold text-cyan-400">{findings.length}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-4">
                        <p className="text-slate-400 text-sm mb-1">Actioned Reports</p>
                        <p className="text-3xl font-bold text-emerald-400">
                            {findings.filter(f => f.status === 'Actioned').length}
                        </p>
                    </div>
                </div>

                <h3 className="text-white font-semibold mb-3">Scout Rankings</h3>
                <div className="space-y-3">
                    {scoutPerformance.map((scout, idx) => {
                        const rating = getRatingBadge(scout.success_rate);
                        
                        return (
                            <motion.div
                                key={scout.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.05 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4"
                            >
                                <div className="flex items-start justify-between mb-3">
                                    <div>
                                        <div className="flex items-center gap-2 mb-1">
                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                #{idx + 1}
                                            </Badge>
                                            <h4 className="text-white font-semibold">{scout.full_name}</h4>
                                        </div>
                                        <p className="text-slate-400 text-sm">
                                            {scout.region} • {scout.specializations?.join(', ') || 'General'}
                                        </p>
                                    </div>
                                    <Badge className={rating.color}>
                                        {rating.label}
                                    </Badge>
                                </div>

                                <div className="grid grid-cols-4 gap-3">
                                    <div>
                                        <p className="text-slate-500 text-xs mb-1">Reports</p>
                                        <div className="flex items-center gap-1">
                                            <Target className="w-3 h-3 text-cyan-400" />
                                            <span className="text-white font-semibold">{scout.total_reports}</span>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs mb-1">High Priority</p>
                                        <div className="flex items-center gap-1">
                                            <TrendingUp className="w-3 h-3 text-red-400" />
                                            <span className="text-white font-semibold">{scout.high_priority_reports}</span>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs mb-1">Actioned</p>
                                        <div className="flex items-center gap-1">
                                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                            <span className="text-white font-semibold">{scout.actioned_reports}</span>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs mb-1">Success Rate</p>
                                        <span className="text-white font-semibold">{scout.success_rate}%</span>
                                    </div>
                                </div>

                                {/* Success Rate Bar */}
                                <div className="mt-3">
                                    <div className="w-full bg-slate-700 rounded-full h-2">
                                        <div
                                            className={`h-2 rounded-full transition-all ${
                                                scout.success_rate >= 80 ? 'bg-emerald-500' :
                                                scout.success_rate >= 60 ? 'bg-blue-500' :
                                                scout.success_rate >= 40 ? 'bg-cyan-500' :
                                                'bg-amber-500'
                                            }`}
                                            style={{ width: `${scout.success_rate}%` }}
                                        />
                                    </div>
                                </div>

                                {/* AI Vetting Score if available */}
                                {scout.ai_vetting_score && (
                                    <div className="mt-2 flex items-center gap-2">
                                        <span className="text-slate-400 text-xs">AI Quality Score:</span>
                                        <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                                            {scout.ai_vetting_score}/100
                                        </Badge>
                                    </div>
                                )}
                            </motion.div>
                        );
                    })}
                </div>

                {scoutPerformance.length === 0 && (
                    <div className="text-center py-12">
                        <p className="text-slate-400">No scout performance data available yet</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}