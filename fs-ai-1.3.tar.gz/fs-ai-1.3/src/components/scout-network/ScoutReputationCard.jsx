import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Award, Star, TrendingUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ScoutReputationCard() {
    const [scouts, setScouts] = useState([]);

    useEffect(() => {
        const loadScouts = async () => {
            const data = await base44.entities.Scout.list();
            // Sort by efficiency/accuracy
            const sorted = data.sort((a, b) => 
                (b.performance_metrics?.accuracy_rating || 0) - (a.performance_metrics?.accuracy_rating || 0)
            ).slice(0, 5);
            setScouts(sorted);
        };
        loadScouts();
    }, []);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-400" />
                    Top Contributors
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {scouts.map((scout, i) => (
                        <div key={scout.id} className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 text-slate-400 font-bold text-xs">
                                    {i + 1}
                                </div>
                                <div>
                                    <p className="text-white font-medium text-sm">{scout.full_name}</p>
                                    <p className="text-slate-500 text-xs">{scout.region}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="flex items-center gap-1 justify-end text-amber-400 text-sm font-bold">
                                    {scout.performance_metrics?.accuracy_rating || 0}%
                                    <Star className="w-3 h-3 fill-current" />
                                </div>
                                <p className="text-slate-500 text-xs">Accuracy</p>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}