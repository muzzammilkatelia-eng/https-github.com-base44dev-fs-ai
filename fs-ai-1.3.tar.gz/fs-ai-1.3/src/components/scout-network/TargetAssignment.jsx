import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Target, MapPin, Users as UsersIcon, Plus, X } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TargetAssignment({ network }) {
    const [targetType, setTargetType] = useState('regions');
    const [selectedRegions, setSelectedRegions] = useState(network?.target_regions || []);
    const [selectedPositions, setSelectedPositions] = useState(network?.target_positions || []);
    const [ageMin, setAgeMin] = useState(network?.target_age_range?.min || 16);
    const [ageMax, setAgeMax] = useState(network?.target_age_range?.max || 23);
    const [selectedScouts, setSelectedScouts] = useState(network?.assigned_scouts || []);
    const [selectedPlayers, setSelectedPlayers] = useState(network?.target_players || []);
    const [newPlayerName, setNewPlayerName] = useState('');
    const [playerPriority, setPlayerPriority] = useState('Medium');
    
    // Advanced Criteria
    const [tacticalRoles, setTacticalRoles] = useState(network?.tactical_roles || []);
    const [attributeCriteria, setAttributeCriteria] = useState(network?.attribute_criteria || []);
    const [performanceCriteria, setPerformanceCriteria] = useState(network?.performance_criteria || {});
    const [transferCriteria, setTransferCriteria] = useState(network?.transfer_criteria || {});
    const [breakoutFlags, setBreakoutFlags] = useState(network?.breakout_flags || { enabled: false });

    const queryClient = useQueryClient();

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const updateMutation = useMutation({
        mutationFn: (data) => base44.entities.ScoutNetwork.update(network.id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout-networks'] });
            toast.success('Targets updated!');
        }
    });

    const regions = ['South America', 'Europe', 'Africa', 'Asia', 'North America', 'Oceania', 
                     'Brazil', 'Argentina', 'Portugal', 'Spain', 'France', 'England', 'Germany', 
                     'Italy', 'Netherlands', 'Belgium', 'Nigeria', 'Ghana', 'Senegal', 'Japan'];

    const positions = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 
                       'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    const toggleRegion = (region) => {
        setSelectedRegions(prev =>
            prev.includes(region) ? prev.filter(r => r !== region) : [...prev, region]
        );
    };

    const togglePosition = (position) => {
        setSelectedPositions(prev =>
            prev.includes(position) ? prev.filter(p => p !== position) : [...prev, position]
        );
    };

    const toggleScout = (scoutId) => {
        setSelectedScouts(prev =>
            prev.includes(scoutId) ? prev.filter(s => s !== scoutId) : [...prev, scoutId]
        );
    };

    const addPlayerTarget = () => {
        if (!newPlayerName) return;
        
        const player = players.find(p => p.name.toLowerCase().includes(newPlayerName.toLowerCase()));
        
        setSelectedPlayers(prev => [...prev, {
            player_name: newPlayerName,
            player_id: player?.id || null,
            priority: playerPriority,
            notes: ''
        }]);
        setNewPlayerName('');
    };

    const removePlayerTarget = (idx) => {
        setSelectedPlayers(prev => prev.filter((_, i) => i !== idx));
    };

    const handleSaveTargets = () => {
        updateMutation.mutate({
            target_regions: selectedRegions,
            target_positions: selectedPositions,
            target_age_range: { min: ageMin, max: ageMax },
            assigned_scouts: selectedScouts,
            target_players: selectedPlayers,
            tactical_roles: tacticalRoles,
            attribute_criteria: attributeCriteria,
            performance_criteria: performanceCriteria,
            transfer_criteria: transferCriteria,
            breakout_flags: breakoutFlags
        });
    };

    const addAttributeCriterion = (attribute, minValue) => {
        if (!attribute || !minValue) return;
        setAttributeCriteria(prev => [...prev, {
            attribute_name: attribute,
            min_value: parseInt(minValue),
            priority: 'High'
        }]);
    };

    const removeAttributeCriterion = (idx) => {
        setAttributeCriteria(prev => prev.filter((_, i) => i !== idx));
    };

    const toggleTacticalRole = (role) => {
        setTacticalRoles(prev =>
            prev.includes(role) ? prev.filter(r => r !== role) : [...prev, role]
        );
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Assign Targets & Scouts
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* Scout Assignment */}
                    <div>
                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                            <UsersIcon className="w-4 h-4 text-purple-400" />
                            Assign Scouts ({selectedScouts.length})
                        </h4>
                        <div className="grid md:grid-cols-2 gap-3">
                            {scouts.map(scout => (
                                <label
                                    key={scout.id}
                                    className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg cursor-pointer hover:bg-slate-800 transition-colors"
                                >
                                    <Checkbox
                                        checked={selectedScouts.includes(scout.id)}
                                        onCheckedChange={() => toggleScout(scout.id)}
                                    />
                                    <div className="flex-1">
                                        <p className="text-white font-medium">{scout.full_name}</p>
                                        <p className="text-slate-400 text-xs">
                                            {scout.region} • {scout.specializations?.join(', ')}
                                        </p>
                                        <Badge className={
                                            scout.status === 'Active'
                                                ? 'bg-emerald-500/20 text-emerald-400 mt-1'
                                                : 'bg-slate-500/20 text-slate-400 mt-1'
                                        }>
                                            {scout.status}
                                        </Badge>
                                    </div>
                                </label>
                            ))}
                        </div>
                        {scouts.length === 0 && (
                            <p className="text-slate-500 text-sm text-center py-4">
                                No scouts available. Add scouts to assign them to networks.
                            </p>
                        )}
                    </div>

                    {/* Target Type Selector */}
                    <div className="flex gap-2 border-b border-slate-700 pb-2">
                        <Button
                            onClick={() => setTargetType('regions')}
                            variant={targetType === 'regions' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'regions' ? 'bg-cyan-500' : ''}
                        >
                            <MapPin className="w-4 h-4 mr-2" />
                            Regions
                        </Button>
                        <Button
                            onClick={() => setTargetType('positions')}
                            variant={targetType === 'positions' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'positions' ? 'bg-purple-500' : ''}
                        >
                            <Target className="w-4 h-4 mr-2" />
                            Positions
                        </Button>
                        <Button
                            onClick={() => setTargetType('players')}
                            variant={targetType === 'players' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'players' ? 'bg-emerald-500' : ''}
                        >
                            <UsersIcon className="w-4 h-4 mr-2" />
                            Specific Players
                        </Button>
                        <Button
                            onClick={() => setTargetType('attributes')}
                            variant={targetType === 'attributes' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'attributes' ? 'bg-amber-500' : ''}
                        >
                            Attributes
                        </Button>
                        <Button
                            onClick={() => setTargetType('tactical')}
                            variant={targetType === 'tactical' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'tactical' ? 'bg-indigo-500' : ''}
                        >
                            Tactical Roles
                        </Button>
                        <Button
                            onClick={() => setTargetType('performance')}
                            variant={targetType === 'performance' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'performance' ? 'bg-pink-500' : ''}
                        >
                            Performance
                        </Button>
                        <Button
                            onClick={() => setTargetType('transfer')}
                            variant={targetType === 'transfer' ? 'default' : 'ghost'}
                            size="sm"
                            className={targetType === 'transfer' ? 'bg-orange-500' : ''}
                        >
                            Transfer Flags
                        </Button>
                    </div>

                    {/* Regions */}
                    {targetType === 'regions' && (
                        <div>
                            <h4 className="text-white font-semibold mb-3">
                                Target Regions ({selectedRegions.length})
                            </h4>
                            <div className="flex flex-wrap gap-2">
                                {regions.map(region => (
                                    <button
                                        key={region}
                                        onClick={() => toggleRegion(region)}
                                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                                            selectedRegions.includes(region)
                                                ? 'bg-cyan-500 text-white'
                                                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                        }`}
                                    >
                                        {region}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Positions */}
                    {targetType === 'positions' && (
                        <div>
                            <h4 className="text-white font-semibold mb-3">
                                Target Positions ({selectedPositions.length})
                            </h4>
                            <div className="grid md:grid-cols-2 gap-2">
                                {positions.map(position => (
                                    <button
                                        key={position}
                                        onClick={() => togglePosition(position)}
                                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                                            selectedPositions.includes(position)
                                                ? 'bg-purple-500 text-white'
                                                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                        }`}
                                    >
                                        {position}
                                    </button>
                                ))}
                            </div>

                            <div className="mt-4">
                                <h4 className="text-white font-semibold mb-3">Age Range</h4>
                                <div className="flex items-center gap-4">
                                    <div className="flex-1">
                                        <label className="text-slate-400 text-xs mb-1 block">Min Age</label>
                                        <Input
                                            type="number"
                                            value={ageMin}
                                            onChange={(e) => setAgeMin(parseInt(e.target.value))}
                                            className="bg-slate-800 border-slate-700 text-white"
                                            min={15}
                                            max={35}
                                        />
                                    </div>
                                    <div className="flex-1">
                                        <label className="text-slate-400 text-xs mb-1 block">Max Age</label>
                                        <Input
                                            type="number"
                                            value={ageMax}
                                            onChange={(e) => setAgeMax(parseInt(e.target.value))}
                                            className="bg-slate-800 border-slate-700 text-white"
                                            min={15}
                                            max={35}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Specific Players */}
                    {targetType === 'players' && (
                        <div>
                            <h4 className="text-white font-semibold mb-3">
                                Specific Player Targets ({selectedPlayers.length})
                            </h4>
                            
                            <div className="bg-slate-800/50 rounded-lg p-4 mb-4">
                                <div className="flex gap-2 mb-3">
                                    <Input
                                        placeholder="Player name..."
                                        value={newPlayerName}
                                        onChange={(e) => setNewPlayerName(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && addPlayerTarget()}
                                        className="bg-slate-900 border-slate-700 text-white flex-1"
                                    />
                                    <Select value={playerPriority} onValueChange={setPlayerPriority}>
                                        <SelectTrigger className="w-32 bg-slate-900 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Critical">Critical</SelectItem>
                                            <SelectItem value="High">High</SelectItem>
                                            <SelectItem value="Medium">Medium</SelectItem>
                                            <SelectItem value="Low">Low</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Button onClick={addPlayerTarget} size="icon" className="bg-emerald-500">
                                        <Plus className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>

                            <div className="space-y-2">
                                {selectedPlayers.map((target, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 flex items-center justify-between">
                                        <div>
                                            <p className="text-white font-medium">{target.player_name}</p>
                                            <Badge className={
                                                target.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                target.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                target.priority === 'Medium' ? 'bg-blue-500/20 text-blue-400' :
                                                'bg-slate-500/20 text-slate-400'
                                            }>
                                                {target.priority}
                                            </Badge>
                                        </div>
                                        <Button
                                            onClick={() => removePlayerTarget(idx)}
                                            variant="ghost"
                                            size="sm"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Player Attributes */}
                    {targetType === 'attributes' && (
                        <div>
                            <h4 className="text-white font-semibold mb-3">
                                Player Attribute Requirements ({attributeCriteria.length})
                            </h4>
                            
                            <div className="bg-slate-800/50 rounded-lg p-4 mb-4">
                                <div className="flex gap-2">
                                    <Input
                                        placeholder="Attribute (e.g., pace, dribbling)"
                                        id="attr-name"
                                        className="bg-slate-900 border-slate-700 text-white flex-1"
                                    />
                                    <Input
                                        placeholder="Min value"
                                        type="number"
                                        id="attr-value"
                                        className="bg-slate-900 border-slate-700 text-white w-28"
                                    />
                                    <Button 
                                        onClick={() => {
                                            const name = document.getElementById('attr-name').value;
                                            const value = document.getElementById('attr-value').value;
                                            addAttributeCriterion(name, value);
                                            document.getElementById('attr-name').value = '';
                                            document.getElementById('attr-value').value = '';
                                        }}
                                        size="icon"
                                        className="bg-amber-500"
                                    >
                                        <Plus className="w-4 h-4" />
                                    </Button>
                                </div>
                                <p className="text-slate-500 text-xs mt-2">
                                    Examples: pace &gt; 85, dribbling &gt; 80, aerial ability &gt; 75
                                </p>
                            </div>

                            <div className="space-y-2">
                                {attributeCriteria.map((criterion, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 flex items-center justify-between">
                                        <div>
                                            <p className="text-white font-medium capitalize">{criterion.attribute_name}</p>
                                            <p className="text-slate-400 text-sm">Min value: {criterion.min_value}</p>
                                        </div>
                                        <Button
                                            onClick={() => removeAttributeCriterion(idx)}
                                            variant="ghost"
                                            size="sm"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Tactical Roles */}
                    {targetType === 'tactical' && (
                        <div>
                            <h4 className="text-white font-semibold mb-3">
                                Tactical Role Requirements ({tacticalRoles.length})
                            </h4>
                            <div className="flex flex-wrap gap-2">
                                {['Ball-Playing Defender', 'Sweeper Keeper', 'Inverted Full-Back', 'Deep-Lying Playmaker',
                                  'Box-to-Box Midfielder', 'Advanced Playmaker', 'Inverted Winger', 'False Nine',
                                  'Target Man', 'Complete Forward', 'Pressing Forward'].map(role => (
                                    <button
                                        key={role}
                                        onClick={() => toggleTacticalRole(role)}
                                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                                            tacticalRoles.includes(role)
                                                ? 'bg-indigo-500 text-white'
                                                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                        }`}
                                    >
                                        {role}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Performance Criteria */}
                    {targetType === 'performance' && (
                        <div className="space-y-4">
                            <h4 className="text-white font-semibold mb-3">Performance Trend Requirements</h4>
                            
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label className="text-slate-400 text-xs mb-1 block">Min Goals per Game</label>
                                    <Input
                                        type="number"
                                        step="0.1"
                                        value={performanceCriteria.goals_per_game || ''}
                                        onChange={(e) => setPerformanceCriteria({...performanceCriteria, goals_per_game: parseFloat(e.target.value)})}
                                        className="bg-slate-800 border-slate-700 text-white"
                                        placeholder="0.5"
                                    />
                                </div>
                                <div>
                                    <label className="text-slate-400 text-xs mb-1 block">Min Assists per Game</label>
                                    <Input
                                        type="number"
                                        step="0.1"
                                        value={performanceCriteria.assists_per_game || ''}
                                        onChange={(e) => setPerformanceCriteria({...performanceCriteria, assists_per_game: parseFloat(e.target.value)})}
                                        className="bg-slate-800 border-slate-700 text-white"
                                        placeholder="0.3"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="text-slate-400 text-xs mb-2 block">Recent Form Required</label>
                                <Select 
                                    value={performanceCriteria.recent_form || 'Any'}
                                    onValueChange={(v) => setPerformanceCriteria({...performanceCriteria, recent_form: v})}
                                >
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Any">Any</SelectItem>
                                        <SelectItem value="Excellent">Excellent</SelectItem>
                                        <SelectItem value="Good">Good</SelectItem>
                                        <SelectItem value="Average">Average or Better</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <label className="flex items-center gap-2 text-white cursor-pointer">
                                <Checkbox
                                    checked={performanceCriteria.consistency_required || false}
                                    onCheckedChange={(checked) => setPerformanceCriteria({...performanceCriteria, consistency_required: checked})}
                                />
                                <span className="text-sm">Require consistent performance</span>
                            </label>
                        </div>
                    )}

                    {/* Transfer & Breakout Flags */}
                    {targetType === 'transfer' && (
                        <div className="space-y-6">
                            <div>
                                <h4 className="text-white font-semibold mb-3">Transfer Criteria Flags</h4>
                                <div className="space-y-4">
                                    <div>
                                        <label className="text-slate-400 text-xs mb-1 block">Max Market Value (€M)</label>
                                        <Input
                                            type="number"
                                            value={transferCriteria.max_market_value || ''}
                                            onChange={(e) => setTransferCriteria({...transferCriteria, max_market_value: parseFloat(e.target.value)})}
                                            className="bg-slate-800 border-slate-700 text-white"
                                            placeholder="50"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-slate-400 text-xs mb-1 block">Contract Expiry Within (Months)</label>
                                        <Input
                                            type="number"
                                            value={transferCriteria.contract_expiry_within_months || ''}
                                            onChange={(e) => setTransferCriteria({...transferCriteria, contract_expiry_within_months: parseInt(e.target.value)})}
                                            className="bg-slate-800 border-slate-700 text-white"
                                            placeholder="12"
                                        />
                                    </div>
                                    <label className="flex items-center gap-2 text-white cursor-pointer">
                                        <Checkbox
                                            checked={transferCriteria.release_clause_required || false}
                                            onCheckedChange={(checked) => setTransferCriteria({...transferCriteria, release_clause_required: checked})}
                                        />
                                        <span className="text-sm">Only players with release clause</span>
                                    </label>
                                    <label className="flex items-center gap-2 text-white cursor-pointer">
                                        <Checkbox
                                            checked={transferCriteria.transfer_listed_only || false}
                                            onCheckedChange={(checked) => setTransferCriteria({...transferCriteria, transfer_listed_only: checked})}
                                        />
                                        <span className="text-sm">Only transfer-listed players</span>
                                    </label>
                                </div>
                            </div>

                            <div>
                                <h4 className="text-white font-semibold mb-3">Potential Breakout Detection</h4>
                                <div className="space-y-4">
                                    <label className="flex items-center gap-2 text-white cursor-pointer">
                                        <Checkbox
                                            checked={breakoutFlags.enabled || false}
                                            onCheckedChange={(checked) => setBreakoutFlags({...breakoutFlags, enabled: checked})}
                                        />
                                        <span className="text-sm font-semibold">Enable Breakout Player Detection</span>
                                    </label>

                                    {breakoutFlags.enabled && (
                                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3 pl-6">
                                            <div>
                                                <label className="text-slate-400 text-xs mb-1 block">Min Potential Rating</label>
                                                <Input
                                                    type="number"
                                                    value={breakoutFlags.min_potential_rating || ''}
                                                    onChange={(e) => setBreakoutFlags({...breakoutFlags, min_potential_rating: parseFloat(e.target.value)})}
                                                    className="bg-slate-800 border-slate-700 text-white"
                                                    placeholder="85"
                                                />
                                            </div>
                                            <div>
                                                <label className="text-slate-400 text-xs mb-1 block">Age Threshold (Under)</label>
                                                <Input
                                                    type="number"
                                                    value={breakoutFlags.age_threshold || ''}
                                                    onChange={(e) => setBreakoutFlags({...breakoutFlags, age_threshold: parseInt(e.target.value)})}
                                                    className="bg-slate-800 border-slate-700 text-white"
                                                    placeholder="23"
                                                />
                                            </div>
                                            <div>
                                                <label className="text-slate-400 text-xs mb-2 block">Value Trajectory</label>
                                                <Select 
                                                    value={breakoutFlags.value_trajectory || 'Any'}
                                                    onValueChange={(v) => setBreakoutFlags({...breakoutFlags, value_trajectory: v})}
                                                >
                                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="Any">Any</SelectItem>
                                                        <SelectItem value="Rapid Growth">Rapid Growth</SelectItem>
                                                        <SelectItem value="Steady Growth">Steady Growth</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </motion.div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    <Button
                        onClick={handleSaveTargets}
                        disabled={updateMutation.isPending}
                        className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500"
                    >
                        Save Assignments
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}