import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageSquare, Send, User, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function TeamChat({ network }) {
    const [message, setMessage] = useState('');
    const [user, setUser] = useState(null);
    const messagesEndRef = useRef(null);
    const queryClient = useQueryClient();

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
    }, []);

    const { data: messages = [] } = useQuery({
        queryKey: ['network-messages', network.id],
        queryFn: async () => {
            const allMessages = await base44.entities.ScoutMessage.list('-created_date', 500);
            return allMessages.filter(m => m.scout_id && network.assigned_scouts?.includes(m.scout_id));
        },
        refetchInterval: 5000 // Poll every 5 seconds
    });

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const sendMessageMutation = useMutation({
        mutationFn: async (messageText) => {
            // Find current user's scout profile
            const userScout = scouts.find(s => s.email === user.email);
            
            if (!userScout) {
                throw new Error('Scout profile not found');
            }

            return base44.entities.ScoutMessage.create({
                scout_id: userScout.id,
                scout_name: userScout.full_name,
                subject: `Team Chat - ${network.network_name}`,
                message: messageText,
                message_type: 'General',
                priority: 'Medium',
                status: 'Sent'
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['network-messages'] });
            setMessage('');
            scrollToBottom();
        },
        onError: () => {
            toast.error('Failed to send message');
        }
    });

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = (e) => {
        e.preventDefault();
        if (message.trim()) {
            sendMessageMutation.mutate(message);
        }
    };

    const getScoutInitials = (scoutName) => {
        return scoutName?.split(' ').map(n => n[0]).join('') || '??';
    };

    const isMyMessage = (msg) => {
        const myScout = scouts.find(s => s.email === user?.email);
        return msg.scout_id === myScout?.id;
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800 h-[600px] flex flex-col">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-cyan-400" />
                    Team Chat
                    <Badge className="ml-auto bg-emerald-500/20 text-emerald-400">
                        <Users className="w-3 h-3 mr-1" />
                        {network.assigned_scouts?.length || 0} scouts
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col overflow-hidden">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
                    {messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-center">
                            <MessageSquare className="w-12 h-12 text-slate-600 mb-3" />
                            <p className="text-slate-400">No messages yet</p>
                            <p className="text-slate-500 text-sm">Start the conversation with your team</p>
                        </div>
                    ) : (
                        <AnimatePresence>
                            {messages.map((msg) => {
                                const isMine = isMyMessage(msg);
                                return (
                                    <motion.div
                                        key={msg.id}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className={`flex gap-3 ${isMine ? 'flex-row-reverse' : 'flex-row'}`}
                                    >
                                        <Avatar className="w-8 h-8 flex-shrink-0">
                                            <AvatarFallback className={isMine ? 'bg-cyan-500' : 'bg-purple-500'}>
                                                <User className="w-4 h-4 text-white" />
                                            </AvatarFallback>
                                        </Avatar>
                                        <div className={`flex-1 ${isMine ? 'text-right' : 'text-left'}`}>
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className={`text-xs font-semibold ${isMine ? 'text-cyan-400' : 'text-purple-400'}`}>
                                                    {msg.scout_name}
                                                </span>
                                                <span className="text-xs text-slate-500">
                                                    {format(new Date(msg.created_date), 'HH:mm')}
                                                </span>
                                            </div>
                                            <div className={`inline-block max-w-[80%] rounded-lg px-4 py-2 ${
                                                isMine 
                                                    ? 'bg-cyan-500/20 text-white' 
                                                    : 'bg-slate-800 text-slate-200'
                                            }`}>
                                                <p className="text-sm leading-relaxed">{msg.message}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                );
                            })}
                        </AnimatePresence>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <form onSubmit={handleSend} className="flex gap-2">
                    <Input
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 bg-slate-800 border-slate-700 text-white"
                        disabled={sendMessageMutation.isPending}
                    />
                    <Button
                        type="submit"
                        disabled={!message.trim() || sendMessageMutation.isPending}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        <Send className="w-4 h-4" />
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}