import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Send, Loader2, TrendingUp, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AIAssistant({ onPlayerSelect, existingReports = [] }) {
    const [query, setQuery] = useState('');
    const [suggestions, setSuggestions] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const quickPrompts = [
        "Find a young striker with high potential for a Premier League club",
        "Suggest undervalued midfielders from South American leagues",
        "Identify technical wingers suitable for possession-based systems",
        "Find defenders with leadership qualities for Championship level"
    ];

    const handleAskAssistant = async (customQuery = null) => {
        const searchQuery = customQuery || query;
        if (!searchQuery.trim()) return;

        setIsLoading(true);
        setSuggestions(null);

        try {
            // Build context from existing reports
            const reportsContext = existingReports.length > 0 
                ? `\n\nExisting scouting reports for reference:\n${existingReports.slice(0, 5).map(r => 
                    `- ${r.player_name} (${r.position}, ${r.player_age}yo): ${r.recommendation}`
                  ).join('\n')}`
                : '';

            const prompt = `You are FS-AI, an elite football scouting assistant. 

User Request: "${searchQuery}"
${reportsContext}

Based on current market trends and scouting intelligence, suggest 3-5 specific players that match this criteria. For each player provide:

1. Name (realistic existing or realistic fictional players)
2. Age
3. Current Club
4. League
5. Position
6. Nationality
7. Key Strengths (3-4 points)
8. Why They Fit (2-3 sentences explaining match to criteria)
9. Estimated Market Value (in millions)
10. FS-AI Suitability Score (0-100)

Focus on realistic, actionable recommendations a scout could pursue.`;

            const { data: response } = await base44.functions.invoke('invokeGemini', {
                prompt: prompt,
                // Gemini function doesn't support add_context_from_internet directly in this simple wrapper, 
                // but Gemini models have vast knowledge. We'll rely on the model's training.
                response_json_schema: {
                    type: "object",
                    properties: {
                        summary: { type: "string" },
                        players: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    name: { type: "string" },
                                    age: { type: "number" },
                                    current_club: { type: "string" },
                                    league: { type: "string" },
                                    position: { type: "string" },
                                    nationality: { type: "string" },
                                    key_strengths: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    why_fit: { type: "string" },
                                    market_value: { type: "number" },
                                    suitability_score: { type: "number" }
                                }
                            }
                        }
                    }
                }
            });

            setSuggestions(response);
        } catch (error) {
            console.error("AI Assistant error:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleQuickPrompt = (prompt) => {
        setQuery(prompt);
        handleAskAssistant(prompt);
    };

    return (
        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-white" />
                    </div>
                    AI Scouting Assistant
                </CardTitle>
                <p className="text-slate-400 text-sm mt-2">
                    Describe what you're looking for and I'll suggest players based on market intelligence
                </p>
            </CardHeader>
            <CardContent className="space-y-4">
                {/* Quick Prompts */}
                <div className="space-y-2">
                    <p className="text-slate-400 text-xs font-medium">Quick Searches:</p>
                    <div className="flex flex-wrap gap-2">
                        {quickPrompts.map((prompt, index) => (
                            <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                onClick={() => handleQuickPrompt(prompt)}
                                className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-cyan-500/20 hover:border-cyan-500/30 hover:text-cyan-400 text-xs"
                            >
                                {prompt}
                            </Button>
                        ))}
                    </div>
                </div>

                {/* Custom Query */}
                <div className="space-y-2">
                    <Textarea
                        placeholder="E.g., 'Find a creative midfielder under 23 with good passing range for a top-5 league club...'"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white min-h-24"
                    />
                    <Button
                        onClick={() => handleAskAssistant()}
                        disabled={isLoading || !query.trim()}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Market...
                            </>
                        ) : (
                            <>
                                <Send className="w-4 h-4 mr-2" />
                                Get Suggestions
                            </>
                        )}
                    </Button>
                </div>

                {/* Suggestions */}
                <AnimatePresence mode="wait">
                    {suggestions && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            className="space-y-4 mt-6"
                        >
                            {/* Summary */}
                            {suggestions.summary && (
                                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                    <p className="text-slate-300 text-sm leading-relaxed">
                                        {suggestions.summary}
                                    </p>
                                </div>
                            )}

                            {/* Player Suggestions */}
                            <div className="space-y-3">
                                {suggestions.players?.map((player, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                        className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 hover:border-cyan-500/30 transition-all cursor-pointer group"
                                        onClick={() => onPlayerSelect(player)}
                                    >
                                        <div className="flex justify-between items-start mb-3">
                                            <div>
                                                <h4 className="text-white font-bold text-lg group-hover:text-cyan-400 transition-colors">
                                                    {player.name}
                                                </h4>
                                                <p className="text-slate-400 text-sm">
                                                    {player.position} · {player.age} years · {player.nationality}
                                                </p>
                                                <p className="text-slate-500 text-xs mt-1">
                                                    {player.current_club} ({player.league})
                                                </p>
                                            </div>
                                            <div className="text-right">
                                                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 mb-2">
                                                    {player.suitability_score}/100
                                                </Badge>
                                                <p className="text-amber-400 font-bold text-sm">
                                                    €{player.market_value}M
                                                </p>
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            {/* Key Strengths */}
                                            <div>
                                                <p className="text-slate-400 text-xs font-semibold mb-1">Key Strengths:</p>
                                                <div className="flex flex-wrap gap-1">
                                                    {player.key_strengths?.map((strength, i) => (
                                                        <span key={i} className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                                                            {strength}
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>

                                            {/* Why They Fit */}
                                            <div>
                                                <p className="text-slate-400 text-xs font-semibold mb-1">Why They Fit:</p>
                                                <p className="text-slate-300 text-xs leading-relaxed">
                                                    {player.why_fit}
                                                </p>
                                            </div>
                                        </div>

                                        <Button
                                            size="sm"
                                            className="w-full mt-3 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                onPlayerSelect(player);
                                            }}
                                        >
                                            <User className="w-3 h-3 mr-2" />
                                            Scout This Player
                                        </Button>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </CardContent>
        </Card>
    );
}