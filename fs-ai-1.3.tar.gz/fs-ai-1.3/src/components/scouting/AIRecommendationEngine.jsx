import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, TrendingUp, Target, Star, MapPin, DollarSign, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function AIRecommendationEngine() {
    const [recommendations, setRecommendations] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 50)
    });

    const generateRecommendations = async () => {
        setIsGenerating(true);
        toast.loading('AI analyzing scouting database...', { id: 'recommend' });

        try {
            // Analyze current team composition
            const positionCounts = players.reduce((acc, p) => {
                acc[p.position] = (acc[p.position] || 0) + 1;
                return acc;
            }, {});

            const highRatedPlayers = reports
                .filter(r => r.overall_rating >= 7)
                .map(r => r.player_name);

            const watchedPlayers = players.filter(p => p.watch_status === 'Watching' || p.watch_status === 'High Priority');

            const recentSearches = players
                .slice(0, 10)
                .map(p => ({ position: p.position, league: p.league, age: p.age }));

            const prompt = `You are an elite AI scouting recommendation engine analyzing a football database.

CURRENT DATABASE OVERVIEW:
- Total Players Tracked: ${players.length}
- High-Rated Players (7+): ${highRatedPlayers.length}
- Players Under Watch: ${watchedPlayers.length}
- Recent Activity: ${recentSearches.length} recent player profiles viewed

TEAM COMPOSITION (Position Distribution):
${Object.entries(positionCounts).map(([pos, count]) => `- ${pos}: ${count} players`).join('\n')}

RECENT SEARCH PATTERNS:
${recentSearches.slice(0, 5).map(s => `- ${s.position}, Age ${s.age}, ${s.league || 'Various leagues'}`).join('\n')}

TOP PROJECTED TALENTS:
${projections.slice(0, 5).map(p => `- ${p.player_name} (${p.position}): ${p.potential_trajectory}, Peak ${p.peak_potential_rating}/10`).join('\n')}

MARKET INSIGHTS:
- Average Market Value: €${(players.reduce((sum, p) => sum + (p.market_value || 0), 0) / players.length).toFixed(1)}M
- Leagues Covered: ${[...new Set(players.map(p => p.league).filter(Boolean))].join(', ')}

Based on this comprehensive analysis, provide strategic scouting recommendations:

1. **Position Gaps**: Which positions need reinforcement based on current squad depth?
2. **Hidden Gems**: Undervalued players with high potential (low market value, high projection)
3. **Trending Targets**: Players gaining attention (multiple reports, watch status changes)
4. **Market Opportunities**: Players with contract situations or release clauses
5. **Future Stars**: Young talents with elite trajectories worth early tracking
6. **Tactical Fits**: Players matching the preferred playing styles in the database

For EACH recommendation category, suggest 2-3 SPECIFIC players from the database with detailed reasoning.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        position_gaps: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    priority: { type: "string" },
                                    reasoning: { type: "string" },
                                    suggested_players: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        hidden_gems: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    value_score: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        trending_targets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    trend_indicator: { type: "string" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        market_opportunities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    opportunity_type: { type: "string" },
                                    urgency: { type: "string" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        future_stars: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    potential_rating: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        tactical_fits: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    style_match: { type: "string" },
                                    reasoning: { type: "string" }
                                }
                            }
                        },
                        overall_strategy: { type: "string" }
                    }
                }
            });

            setRecommendations(result);
            toast.success('Strategic recommendations generated!', { id: 'recommend' });
        } catch (error) {
            console.error('Recommendation failed:', error);
            toast.error('Failed to generate recommendations', { id: 'recommend' });
        } finally {
            setIsGenerating(false);
        }
    };

    const findPlayerByName = (name) => {
        return players.find(p => p.name.toLowerCase().includes(name.toLowerCase()));
    };

    const priorityColors = {
        'High': 'bg-red-500/20 text-red-400 border-red-500/30',
        'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        'Low': 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    AI Scouting Recommendations
                </CardTitle>
                <p className="text-slate-400 text-sm">
                    Strategic player suggestions based on your database and scouting patterns
                </p>
            </CardHeader>
            <CardContent className="space-y-6">
                {!recommendations ? (
                    <div className="text-center py-12">
                        <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Sparkles className="w-8 h-8 text-purple-400" />
                        </div>
                        <h3 className="text-white font-semibold mb-2">AI-Powered Scouting Intelligence</h3>
                        <p className="text-slate-400 text-sm mb-4 max-w-md mx-auto">
                            AI analyzes your {players.length} player{players.length !== 1 ? 's' : ''}, {reports.length} scouting report{reports.length !== 1 ? 's' : ''}, and {projections.length} projection{projections.length !== 1 ? 's' : ''} to recommend strategic targets
                        </p>
                        {players.length > 0 && (
                            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 mb-6 max-w-md mx-auto">
                                <p className="text-cyan-400 text-xs">
                                    ✓ Database ready with {players.length} player profiles
                                </p>
                            </div>
                        )}
                        <Button
                            onClick={generateRecommendations}
                            disabled={isGenerating || players.length === 0}
                            className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500"
                        >
                            {isGenerating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing Database...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate Recommendations from {players.length} Players
                                </>
                            )}
                        </Button>
                        {players.length === 0 && (
                            <p className="text-amber-400 text-xs mt-4">Import or add players to start generating AI recommendations</p>
                        )}
                    </div>
                ) : (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-6"
                    >
                        {/* Overall Strategy */}
                        <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-lg p-4">
                            <h4 className="text-purple-400 font-semibold mb-2 flex items-center gap-2">
                                <Target className="w-4 h-4" />
                                Strategic Overview
                            </h4>
                            <p className="text-slate-300 text-sm leading-relaxed">{recommendations.overall_strategy}</p>
                        </div>

                        {/* Position Gaps */}
                        {recommendations.position_gaps?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <Users className="w-4 h-4 text-cyan-400" />
                                    Position Gaps & Priorities
                                </h4>
                                <div className="space-y-3">
                                    {recommendations.position_gaps.map((gap, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                            <div className="flex items-start justify-between mb-2">
                                                <div>
                                                    <h5 className="text-white font-semibold">{gap.position}</h5>
                                                    <p className="text-slate-400 text-sm mt-1">{gap.reasoning}</p>
                                                </div>
                                                <Badge className={priorityColors[gap.priority] || priorityColors['Medium']}>
                                                    {gap.priority} Priority
                                                </Badge>
                                            </div>
                                            {gap.suggested_players?.length > 0 && (
                                                <div className="mt-3 flex flex-wrap gap-2">
                                                    {gap.suggested_players.map((name, i) => {
                                                        const player = findPlayerByName(name);
                                                        return player ? (
                                                            <Link key={i} to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                                <Badge className="bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 cursor-pointer">
                                                                    {name}
                                                                </Badge>
                                                            </Link>
                                                        ) : (
                                                            <Badge key={i} className="bg-slate-700 text-slate-300">{name}</Badge>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Hidden Gems */}
                        {recommendations.hidden_gems?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <Star className="w-4 h-4 text-amber-400" />
                                    Hidden Gems
                                </h4>
                                <div className="grid md:grid-cols-2 gap-3">
                                    {recommendations.hidden_gems.map((gem, idx) => {
                                        const player = findPlayerByName(gem.player_name);
                                        return (
                                            <div key={idx} className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                                <div className="flex items-start justify-between mb-2">
                                                    <h5 className="text-white font-semibold">{gem.player_name}</h5>
                                                    <div className="text-amber-400 font-bold">{gem.value_score}/10</div>
                                                </div>
                                                <p className="text-slate-300 text-xs mb-2">{gem.reasoning}</p>
                                                {player && (
                                                    <Link to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                        <Button size="sm" variant="outline" className="w-full text-xs">
                                                            View Profile
                                                        </Button>
                                                    </Link>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* Trending Targets */}
                        {recommendations.trending_targets?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-green-400" />
                                    Trending Targets
                                </h4>
                                <div className="space-y-2">
                                    {recommendations.trending_targets.map((target, idx) => {
                                        const player = findPlayerByName(target.player_name);
                                        return (
                                            <div key={idx} className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 flex items-center justify-between">
                                                <div className="flex-1">
                                                    <h5 className="text-white font-semibold text-sm">{target.player_name}</h5>
                                                    <p className="text-slate-400 text-xs mt-1">{target.reasoning}</p>
                                                    <Badge className="bg-green-500/20 text-green-400 mt-2 text-xs">
                                                        {target.trend_indicator}
                                                    </Badge>
                                                </div>
                                                {player && (
                                                    <Link to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                        <Button size="sm" variant="ghost" className="text-green-400">
                                                            View
                                                        </Button>
                                                    </Link>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* Market Opportunities */}
                        {recommendations.market_opportunities?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <DollarSign className="w-4 h-4 text-emerald-400" />
                                    Market Opportunities
                                </h4>
                                <div className="space-y-3">
                                    {recommendations.market_opportunities.map((opp, idx) => {
                                        const player = findPlayerByName(opp.player_name);
                                        return (
                                            <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                                <div className="flex items-start justify-between mb-2">
                                                    <div>
                                                        <h5 className="text-white font-semibold">{opp.player_name}</h5>
                                                        <p className="text-slate-300 text-xs mt-1">{opp.reasoning}</p>
                                                    </div>
                                                    <Badge className={opp.urgency === 'High' ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'}>
                                                        {opp.urgency} Urgency
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center justify-between mt-3">
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        {opp.opportunity_type}
                                                    </Badge>
                                                    {player && (
                                                        <Link to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                            <Button size="sm" variant="outline" className="text-xs">
                                                                Investigate
                                                            </Button>
                                                        </Link>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* Future Stars */}
                        {recommendations.future_stars?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <Star className="w-4 h-4 text-yellow-400" />
                                    Future Stars
                                </h4>
                                <div className="grid md:grid-cols-2 gap-3">
                                    {recommendations.future_stars.map((star, idx) => {
                                        const player = findPlayerByName(star.player_name);
                                        return (
                                            <div key={idx} className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                                                <div className="flex items-center justify-between mb-2">
                                                    <h5 className="text-white font-semibold">{star.player_name}</h5>
                                                    <div className="text-yellow-400 font-bold">{star.potential_rating}/10</div>
                                                </div>
                                                <p className="text-slate-300 text-xs mb-3">{star.reasoning}</p>
                                                {player && (
                                                    <Link to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                        <Button size="sm" variant="outline" className="w-full text-xs">
                                                            Track Talent
                                                        </Button>
                                                    </Link>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* Tactical Fits */}
                        {recommendations.tactical_fits?.length > 0 && (
                            <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <Target className="w-4 h-4 text-purple-400" />
                                    Tactical Fits
                                </h4>
                                <div className="space-y-2">
                                    {recommendations.tactical_fits.map((fit, idx) => {
                                        const player = findPlayerByName(fit.player_name);
                                        return (
                                            <div key={idx} className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3">
                                                <div className="flex items-start justify-between">
                                                    <div className="flex-1">
                                                        <h5 className="text-white font-semibold text-sm">{fit.player_name}</h5>
                                                        <Badge className="bg-purple-500/20 text-purple-400 mt-1 text-xs">
                                                            {fit.style_match}
                                                        </Badge>
                                                        <p className="text-slate-400 text-xs mt-2">{fit.reasoning}</p>
                                                    </div>
                                                    {player && (
                                                        <Link to={createPageUrl('PlayerProfile') + `?id=${player.id}`}>
                                                            <Button size="sm" variant="ghost" className="text-purple-400">
                                                                View
                                                            </Button>
                                                        </Link>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        <Button
                            onClick={() => setRecommendations(null)}
                            variant="outline"
                            className="w-full"
                        >
                            Generate New Recommendations
                        </Button>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}