import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';

export default function BenchmarkBarChart({ comparisons, moduleKey, moduleName }) {
    if (!comparisons[moduleKey] || Object.keys(comparisons[moduleKey]).length === 0) {
        return null;
    }

    const data = Object.entries(comparisons[moduleKey]).map(([field, data]) => ({
        name: field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        current: data.current,
        average: data.average,
        diff: data.diff
    }));

    return (
        <div className="space-y-2">
            <h4 className="text-white font-semibold text-sm">{moduleName}</h4>
            <ResponsiveContainer width="100%" height={200}>
                <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis 
                        dataKey="name" 
                        tick={{ fill: '#94a3b8', fontSize: 10 }}
                        angle={-15}
                        textAnchor="end"
                        height={60}
                    />
                    <YAxis 
                        domain={[0, 100]}
                        tick={{ fill: '#94a3b8', fontSize: 10 }}
                    />
                    <Tooltip 
                        contentStyle={{ 
                            backgroundColor: '#1e293b', 
                            border: '1px solid #334155',
                            borderRadius: '8px',
                            color: '#e2e8f0'
                        }}
                    />
                    <Legend 
                        wrapperStyle={{ color: '#94a3b8', fontSize: 11 }}
                    />
                    <Bar dataKey="current" fill="#06b6d4" name="Player Score" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="average" fill="#64748b" name="Position Avg" radius={[4, 4, 0, 0]} />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
}