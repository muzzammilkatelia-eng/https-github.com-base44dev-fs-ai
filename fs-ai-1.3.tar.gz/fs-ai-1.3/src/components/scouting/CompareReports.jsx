import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, TrendingUp, Target, Users, FileText, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';
import MetricDisplay from './MetricDisplay';
import ComparisonBarChart from './ComparisonBarChart';

export default function CompareReports({ reports, onClose }) {
    if (!reports || reports.length < 2) return null;

    const modules = [
        { key: 'calafat_analysis', name: 'Calafat', icon: Sparkles, color: 'from-purple-500 to-pink-600', fields: ['ceiling_score', 'risk_score'] },
        { key: 'brighton_analysis', name: 'Brighton', icon: TrendingUp, color: 'from-cyan-500 to-blue-600', fields: ['hidden_gem_score', 'roi_score'] },
        { key: 'portuguese_analysis', name: 'Portuguese', icon: Target, color: 'from-emerald-500 to-teal-600', fields: ['flip_potential', 'adaptation_score', 'versatility_index'] },
        { key: 'dortmund_analysis', name: 'Dortmund', icon: Users, color: 'from-amber-500 to-orange-600', fields: ['readiness_score', 'resilience_index'] },
        { key: 'ajax_analysis', name: 'Ajax', icon: FileText, color: 'from-red-500 to-rose-600', fields: ['technical_purity', 'positional_iq', 'academy_fit'] }
    ];

    const getRecommendationColor = (rec) => {
        const colors = {
            "Strong Recommend": "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
            "Recommend": "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
            "Monitor": "bg-amber-500/20 text-amber-400 border-amber-500/30",
            "Pass": "bg-slate-500/20 text-slate-400 border-slate-500/30"
        };
        return colors[rec] || colors["Pass"];
    };

    const getHighestScore = (field, reports) => {
        const scores = reports.map(r => {
            const parts = field.split('.');
            let value = r;
            for (const part of parts) {
                value = value?.[part];
            }
            return typeof value === 'number' ? value : 0;
        });
        return Math.max(...scores);
    };

    const formatFieldName = (field) => {
        return field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800">
                <DialogHeader>
                    <div className="flex justify-between items-center">
                        <DialogTitle className="text-2xl text-white">Player Comparison</DialogTitle>
                        <button onClick={onClose} className="text-slate-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                </DialogHeader>

                <div className="space-y-6 mt-6">
                    {/* Player Headers */}
                    <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${reports.length}, 1fr)` }}>
                        {reports.map((report, idx) => (
                            <motion.div
                                key={report.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.1 }}
                            >
                                <Card className="bg-slate-800/50 border-cyan-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-white text-lg">{report.player_name}</CardTitle>
                                        <p className="text-slate-400 text-sm">{report.position} · {report.player_age} years</p>
                                        <Badge className={`mt-2 ${getRecommendationColor(report.recommendation)}`}>
                                            {report.recommendation}
                                        </Badge>
                                    </CardHeader>
                                </Card>
                            </motion.div>
                        ))}
                    </div>

                    {/* Radar Chart Comparison */}
                    <div>
                        <h3 className="text-cyan-400 font-bold mb-3 text-lg">Visual Comparison</h3>
                        <Card className="bg-slate-800/30 border-slate-700">
                            <CardContent className="pt-6">
                                <ResponsiveContainer width="100%" height={400}>
                                    {(() => {
                                        // Build unified metrics across all players
                                        const allMetrics = new Set();
                                        reports.forEach(report => {
                                            if (report.calafat_analysis?.ceiling_score) allMetrics.add('Ceiling');
                                            if (report.brighton_analysis?.hidden_gem_score) allMetrics.add('Hidden Gem');
                                            if (report.brighton_analysis?.roi_score) allMetrics.add('ROI');
                                            if (report.portuguese_analysis?.flip_potential) allMetrics.add('Flip');
                                            if (report.dortmund_analysis?.readiness_score) allMetrics.add('Readiness');
                                            if (report.ajax_analysis?.technical_purity) allMetrics.add('Technical');
                                        });

                                        const chartData = Array.from(allMetrics).map(metric => {
                                            const dataPoint = { metric };
                                            reports.forEach(report => {
                                                let value = 0;
                                                if (metric === 'Ceiling') value = report.calafat_analysis?.ceiling_score || 0;
                                                if (metric === 'Hidden Gem') value = report.brighton_analysis?.hidden_gem_score || 0;
                                                if (metric === 'ROI') value = report.brighton_analysis?.roi_score || 0;
                                                if (metric === 'Flip') value = report.portuguese_analysis?.flip_potential || 0;
                                                if (metric === 'Readiness') value = report.dortmund_analysis?.readiness_score || 0;
                                                if (metric === 'Technical') value = report.ajax_analysis?.technical_purity || 0;
                                                dataPoint[report.player_name] = value;
                                            });
                                            return dataPoint;
                                        });

                                        const colors = ['#06b6d4', '#8b5cf6', '#f59e0b'];

                                        return (
                                            <RadarChart data={chartData}>
                                                <PolarGrid stroke="#334155" />
                                                <PolarAngleAxis 
                                                    dataKey="metric" 
                                                    tick={{ fill: '#94a3b8', fontSize: 11 }}
                                                />
                                                <PolarRadiusAxis 
                                                    angle={90} 
                                                    domain={[0, 100]} 
                                                    tick={{ fill: '#64748b', fontSize: 10 }}
                                                />
                                                {reports.map((report, idx) => (
                                                    <Radar
                                                        key={report.id}
                                                        name={report.player_name}
                                                        dataKey={report.player_name}
                                                        stroke={colors[idx]}
                                                        fill={colors[idx]}
                                                        fillOpacity={0.2}
                                                    />
                                                ))}
                                                <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 12 }} />
                                            </RadarChart>
                                        );
                                    })()}
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Overall Verdict Comparison */}
                    <div>
                        <h3 className="text-cyan-400 font-bold mb-3 text-lg">FS-AI Verdict</h3>
                        <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${reports.length}, 1fr)` }}>
                            {reports.map(report => (
                                <Card key={report.id} className="bg-slate-800/30 border-slate-700">
                                    <CardContent className="pt-4">
                                        <p className="text-slate-300 text-sm leading-relaxed">{report.overall_verdict}</p>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </div>

                    {/* Module Comparisons */}
                    {modules.map(module => {
                        const hasData = reports.some(r => r[module.key]);
                        if (!hasData) return null;

                        return (
                            <div key={module.key}>
                                <div className="flex items-center gap-3 mb-4">
                                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center`}>
                                        <module.icon className="w-5 h-5 text-white" />
                                    </div>
                                    <h3 className="text-white font-bold text-lg">{module.name} Mode</h3>
                                </div>

                                <div className="space-y-6">
                                    {/* Bar Chart for this module */}
                                    {module.fields.map(field => (
                                        <div key={field}>
                                            <p className="text-slate-400 text-sm mb-3 font-medium">{formatFieldName(field)}</p>
                                            <ComparisonBarChart 
                                                reports={reports} 
                                                metric={field} 
                                                moduleKey={module.key}
                                            />
                                        </div>
                                    ))}

                                    {/* Detailed numeric comparison */}
                                    {module.fields.map(field => {
                                        const fieldPath = `${module.key}.${field}`;
                                        const highestScore = getHighestScore(fieldPath, reports);

                                        return (
                                            <div key={`${field}-detail`}>
                                                <p className="text-slate-400 text-sm mb-2 font-medium">{formatFieldName(field)} - Details</p>
                                                <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${reports.length}, 1fr)` }}>
                                                    {reports.map(report => {
                                                        const value = report[module.key]?.[field];
                                                        const isHighest = typeof value === 'number' && value === highestScore && highestScore > 0;
                                                        
                                                        return (
                                                            <Card 
                                                                key={report.id} 
                                                                className={`bg-slate-800/30 border-slate-700 ${isHighest ? 'ring-2 ring-cyan-500/50' : ''}`}
                                                            >
                                                                <CardContent className="pt-4">
                                                                    {typeof value === 'number' ? (
                                                                        <div className="space-y-2">
                                                                            <div className="flex justify-between items-center">
                                                                                <span className="text-white font-bold text-xl">{value}</span>
                                                                                {isHighest && (
                                                                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">
                                                                                        Highest
                                                                                    </Badge>
                                                                                )}
                                                                            </div>
                                                                            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                                                                                <div 
                                                                                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full transition-all"
                                                                                    style={{ width: `${value}%` }}
                                                                                />
                                                                            </div>
                                                                        </div>
                                                                    ) : typeof value === 'string' ? (
                                                                        <p className="text-slate-300 text-sm">{value}</p>
                                                                    ) : (
                                                                        <p className="text-slate-500 text-sm">N/A</p>
                                                                    )}
                                                                </CardContent>
                                                            </Card>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        );
                    })}

                    {/* Key Insights */}
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Key Insights</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2 text-slate-300 text-sm">
                                {reports.filter(r => r.recommendation === "Strong Recommend").length > 0 && (
                                    <li>• <span className="text-emerald-400 font-semibold">{reports.filter(r => r.recommendation === "Strong Recommend").map(r => r.player_name).join(', ')}</span> marked as strong recommendations</li>
                                )}
                                {reports.some(r => r.player_age < 21) && (
                                    <li>• {reports.filter(r => r.player_age < 21).map(r => r.player_name).join(', ')} in development age (U21)</li>
                                )}
                                <li>• Position spread: {[...new Set(reports.map(r => r.position))].join(', ')}</li>
                            </ul>
                        </CardContent>
                    </Card>
                </div>
            </DialogContent>
        </Dialog>
    );
}