import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function ComparisonBarChart({ reports, metric, moduleKey }) {
    const data = reports.map(report => {
        const value = report[moduleKey]?.[metric];
        return {
            name: report.player_name,
            score: typeof value === 'number' ? value : 0
        };
    });

    const colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444'];

    return (
        <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                    dataKey="name" 
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                    angle={-15}
                    textAnchor="end"
                    height={60}
                />
                <YAxis 
                    domain={[0, 100]}
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                />
                <Tooltip 
                    contentStyle={{ 
                        backgroundColor: '#1e293b', 
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#e2e8f0'
                    }}
                />
                <Bar 
                    dataKey="score" 
                    fill="#06b6d4"
                    radius={[8, 8, 0, 0]}
                >
                    {data.map((entry, index) => (
                        <Bar key={index} fill={colors[index % colors.length]} />
                    ))}
                </Bar>
            </BarChart>
        </ResponsiveContainer>
    );
}