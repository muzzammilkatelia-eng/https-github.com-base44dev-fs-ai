import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText, Loader2, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function ExportToDocsButton({ reportId, playerName }) {
    const [isExporting, setIsExporting] = useState(false);
    const [docUrl, setDocUrl] = useState(null);

    const handleExport = async () => {
        setIsExporting(true);
        try {
            const response = await base44.functions.invoke('exportToGoogleDocs', { reportId });
            
            if (response.data.success) {
                setDocUrl(response.data.documentUrl);
                toast.success('Report exported to Google Docs!');
                window.open(response.data.documentUrl, '_blank');
            } else {
                toast.error('Failed to export report');
            }
        } catch (error) {
            toast.error('Export failed: ' + error.message);
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div className="flex items-center gap-2">
            <Button
                onClick={handleExport}
                disabled={isExporting}
                variant="outline"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
            >
                {isExporting ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Exporting...
                    </>
                ) : (
                    <>
                        <FileText className="w-4 h-4 mr-2" />
                        Export to Google Docs
                    </>
                )}
            </Button>
            {docUrl && (
                <a href={docUrl} target="_blank" rel="noopener noreferrer">
                    <Button variant="ghost" size="icon">
                        <ExternalLink className="w-4 h-4" />
                    </Button>
                </a>
            )}
        </div>
    );
}