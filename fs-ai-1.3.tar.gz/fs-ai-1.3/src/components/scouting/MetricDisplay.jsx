import React from "react";
import { motion } from "framer-motion";

export default function MetricDisplay({ label, value, maxValue = 100, color = "cyan" }) {
    const percentage = (value / maxValue) * 100;
    
    const colorClasses = {
        cyan: "from-cyan-500 to-blue-600",
        emerald: "from-emerald-500 to-teal-600",
        amber: "from-amber-500 to-orange-600",
        purple: "from-purple-500 to-pink-600",
        red: "from-red-500 to-rose-600"
    };

    return (
        <div className="space-y-2">
            <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">{label}</span>
                <span className="text-white font-bold">{value}/{maxValue}</span>
            </div>
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full bg-gradient-to-r ${colorClasses[color]} rounded-full`}
                />
            </div>
        </div>
    );
}