import React from "react";
import { motion } from "framer-motion";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function ModuleCard({ title, icon: Icon, color, metrics, description, isActive, onToggle }) {
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
        >
            <Card className={`relative overflow-hidden transition-all cursor-pointer ${
                isActive 
                    ? 'bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/20' 
                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
            }`}
            onClick={onToggle}>
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${color}`}></div>
                
                <CardHeader>
                    <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${color} flex items-center justify-center`}>
                                <Icon className="w-5 h-5 text-white" />
                            </div>
                            <div>
                                <CardTitle className="text-white text-lg">{title}</CardTitle>
                                <p className="text-slate-400 text-xs mt-1">{description}</p>
                            </div>
                        </div>
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                            isActive ? 'border-cyan-500 bg-cyan-500' : 'border-slate-600'
                        }`}>
                            {isActive && (
                                <motion.div
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    className="w-2 h-2 rounded-full bg-white"
                                />
                            )}
                        </div>
                    </div>
                </CardHeader>

                {isActive && metrics && (
                    <CardContent>
                        <div className="grid grid-cols-1 gap-3">
                            {Object.entries(metrics).map(([key, value]) => (
                                <div key={key} className="flex justify-between items-center">
                                    <span className="text-slate-400 text-sm capitalize">{key.replace(/_/g, ' ')}</span>
                                    <span className="text-white font-semibold">{value}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                )}
            </Card>
        </motion.div>
    );
}