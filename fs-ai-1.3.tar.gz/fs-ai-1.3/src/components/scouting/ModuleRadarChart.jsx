import React from 'react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';

export default function ModuleRadarChart({ report, showLegend = true }) {
    const data = [];

    if (report.calafat_analysis) {
        data.push({
            metric: 'Ceiling',
            value: report.calafat_analysis.ceiling_score || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Risk',
            value: 100 - (report.calafat_analysis.risk_score || 0), // Invert for visualization
            fullMark: 100
        });
    }

    if (report.brighton_analysis) {
        data.push({
            metric: 'Hidden Gem',
            value: report.brighton_analysis.hidden_gem_score || 0,
            fullMark: 100
        });
        data.push({
            metric: 'ROI',
            value: report.brighton_analysis.roi_score || 0,
            fullMark: 100
        });
    }

    if (report.portuguese_analysis) {
        data.push({
            metric: 'Flip Potential',
            value: report.portuguese_analysis.flip_potential || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Adaptation',
            value: report.portuguese_analysis.adaptation_score || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Versatility',
            value: report.portuguese_analysis.versatility_index || 0,
            fullMark: 100
        });
    }

    if (report.dortmund_analysis) {
        data.push({
            metric: 'Readiness',
            value: report.dortmund_analysis.readiness_score || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Resilience',
            value: report.dortmund_analysis.resilience_index || 0,
            fullMark: 100
        });
    }

    if (report.ajax_analysis) {
        data.push({
            metric: 'Technical',
            value: report.ajax_analysis.technical_purity || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Positional IQ',
            value: report.ajax_analysis.positional_iq || 0,
            fullMark: 100
        });
        data.push({
            metric: 'Academy Fit',
            value: report.ajax_analysis.academy_fit || 0,
            fullMark: 100
        });
    }

    if (data.length === 0) {
        return <p className="text-slate-400 text-sm text-center py-8">No module data available</p>;
    }

    return (
        <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={data}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis 
                    dataKey="metric" 
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                />
                <PolarRadiusAxis 
                    angle={90} 
                    domain={[0, 100]} 
                    tick={{ fill: '#64748b', fontSize: 10 }}
                />
                <Radar 
                    name={report.player_name || 'Player'} 
                    dataKey="value" 
                    stroke="#06b6d4" 
                    fill="#06b6d4" 
                    fillOpacity={0.3} 
                />
                {showLegend && (
                    <Legend 
                        wrapperStyle={{ color: '#94a3b8', fontSize: 12 }}
                    />
                )}
            </RadarChart>
        </ResponsiveContainer>
    );
}