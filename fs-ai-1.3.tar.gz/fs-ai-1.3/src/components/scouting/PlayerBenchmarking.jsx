import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import BenchmarkBarChart from './BenchmarkBarChart';

export default function PlayerBenchmarking({ currentReport, allReports }) {
    const benchmarkData = useMemo(() => {
        // Filter reports by same position
        const positionReports = allReports.filter(r => 
            r.position === currentReport.position && r.id !== currentReport.id
        );

        if (positionReports.length === 0) {
            return null;
        }

        // Calculate averages for each module field
        const modules = [
            { key: 'calafat_analysis', fields: ['ceiling_score', 'risk_score'] },
            { key: 'brighton_analysis', fields: ['hidden_gem_score', 'roi_score'] },
            { key: 'portuguese_analysis', fields: ['flip_potential', 'adaptation_score', 'versatility_index'] },
            { key: 'dortmund_analysis', fields: ['readiness_score', 'resilience_index'] },
            { key: 'ajax_analysis', fields: ['technical_purity', 'positional_iq', 'academy_fit'] }
        ];

        const averages = {};
        const comparisons = {};

        modules.forEach(module => {
            averages[module.key] = {};
            comparisons[module.key] = {};

            module.fields.forEach(field => {
                const values = positionReports
                    .map(r => r[module.key]?.[field])
                    .filter(v => typeof v === 'number');

                if (values.length > 0) {
                    const avg = values.reduce((a, b) => a + b, 0) / values.length;
                    averages[module.key][field] = Math.round(avg * 10) / 10;

                    const currentValue = currentReport[module.key]?.[field];
                    if (typeof currentValue === 'number') {
                        const diff = currentValue - avg;
                        const diffPercent = ((diff / avg) * 100).toFixed(1);
                        comparisons[module.key][field] = {
                            current: currentValue,
                            average: averages[module.key][field],
                            diff: Math.round(diff * 10) / 10,
                            diffPercent: parseFloat(diffPercent),
                            status: Math.abs(diff) < 2 ? 'average' : diff > 0 ? 'above' : 'below'
                        };
                    }
                }
            });
        });

        return {
            sampleSize: positionReports.length,
            comparisons,
            position: currentReport.position
        };
    }, [currentReport, allReports]);

    if (!benchmarkData) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Position Benchmarking
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-400 text-sm">
                        Not enough {currentReport.position} reports for benchmarking (need at least 2)
                    </p>
                </CardContent>
            </Card>
        );
    }

    const formatFieldName = (field) => {
        return field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'above': return <TrendingUp className="w-4 h-4 text-emerald-400" />;
            case 'below': return <TrendingDown className="w-4 h-4 text-red-400" />;
            default: return <Minus className="w-4 h-4 text-slate-400" />;
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'above': return 'text-emerald-400';
            case 'below': return 'text-red-400';
            default: return 'text-slate-400';
        }
    };

    const moduleNames = {
        calafat_analysis: 'Calafat Mode',
        brighton_analysis: 'Brighton Mode',
        portuguese_analysis: 'Portuguese Pipeline',
        dortmund_analysis: 'Dortmund Mode',
        ajax_analysis: 'Ajax Mode'
    };

    // Calculate standout strengths and weaknesses
    const allComparisons = Object.values(benchmarkData.comparisons)
        .flatMap(module => Object.entries(module).map(([field, data]) => ({ field, ...data })));
    
    const strengths = allComparisons
        .filter(c => c.status === 'above')
        .sort((a, b) => b.diffPercent - a.diffPercent)
        .slice(0, 3);

    const weaknesses = allComparisons
        .filter(c => c.status === 'below')
        .sort((a, b) => a.diffPercent - b.diffPercent)
        .slice(0, 3);

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Position Benchmarking: {benchmarkData.position}
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        Compared against {benchmarkData.sampleSize} {benchmarkData.position} player{benchmarkData.sampleSize !== 1 ? 's' : ''} in database
                    </p>
                </CardHeader>
                <CardContent className="space-y-4">
                    {strengths.length > 0 && (
                        <div>
                            <h4 className="text-emerald-400 font-semibold mb-2 text-sm">Standout Strengths</h4>
                            <div className="space-y-2">
                                {strengths.map((item, idx) => (
                                    <div key={idx} className="flex justify-between items-center text-sm">
                                        <span className="text-slate-300">{formatFieldName(item.field)}</span>
                                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                            +{item.diffPercent}% vs avg
                                        </Badge>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    {weaknesses.length > 0 && (
                        <div>
                            <h4 className="text-amber-400 font-semibold mb-2 text-sm">Development Areas</h4>
                            <div className="space-y-2">
                                {weaknesses.map((item, idx) => (
                                    <div key={idx} className="flex justify-between items-center text-sm">
                                        <span className="text-slate-300">{formatFieldName(item.field)}</span>
                                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                            {item.diffPercent}% vs avg
                                        </Badge>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {Object.entries(benchmarkData.comparisons).map(([moduleKey, fields]) => {
                if (Object.keys(fields).length === 0) return null;

                return (
                    <Card key={moduleKey} className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white text-lg">{moduleNames[moduleKey]}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {/* Bar Chart Visualization */}
                            <BenchmarkBarChart 
                                comparisons={benchmarkData.comparisons}
                                moduleKey={moduleKey}
                                moduleName={moduleNames[moduleKey]}
                            />

                            {/* Detailed Metrics */}
                            <div className="space-y-4 pt-4 border-t border-slate-700">
                            {Object.entries(fields).map(([field, data]) => (
                                <motion.div
                                    key={field}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    className="space-y-2"
                                >
                                    <div className="flex justify-between items-center">
                                        <span className="text-slate-400 text-sm">{formatFieldName(field)}</span>
                                        <div className="flex items-center gap-2">
                                            {getStatusIcon(data.status)}
                                            <span className={`font-bold ${getStatusColor(data.status)}`}>
                                                {data.diff > 0 ? '+' : ''}{data.diff}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="relative">
                                        {/* Average line */}
                                        <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-600 z-10" />
                                        <div className="absolute left-1/2 -top-6 transform -translate-x-1/2 text-xs text-slate-500">
                                            Avg: {data.average}
                                        </div>
                                        
                                        {/* Progress bar */}
                                        <div className="h-8 bg-slate-800 rounded-lg overflow-hidden flex items-center">
                                            <div 
                                                className={`h-full transition-all ${
                                                    data.status === 'above' 
                                                        ? 'bg-gradient-to-r from-emerald-500 to-teal-600' 
                                                        : data.status === 'below'
                                                        ? 'bg-gradient-to-r from-red-500 to-rose-600'
                                                        : 'bg-gradient-to-r from-slate-500 to-slate-600'
                                                }`}
                                                style={{ width: `${data.current}%` }}
                                            />
                                            <span className="ml-2 text-white font-bold text-sm">{data.current}</span>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                            </div>
                        </CardContent>
                    </Card>
                );
            })}
        </div>
    );
}