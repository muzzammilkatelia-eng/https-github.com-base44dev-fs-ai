import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

export default function RecommendationDistribution({ reports }) {
    const recommendationCounts = reports.reduce((acc, report) => {
        acc[report.recommendation] = (acc[report.recommendation] || 0) + 1;
        return acc;
    }, {});

    const data = Object.entries(recommendationCounts).map(([name, value]) => ({
        name,
        value
    }));

    const COLORS = {
        'Strong Recommend': '#10b981',
        'Recommend': '#06b6d4',
        'Monitor': '#f59e0b',
        'Pass': '#64748b'
    };

    return (
        <ResponsiveContainer width="100%" height={300}>
            <PieChart>
                <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                >
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[entry.name] || '#64748b'} />
                    ))}
                </Pie>
                <Tooltip 
                    contentStyle={{ 
                        backgroundColor: '#1e293b', 
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#e2e8f0'
                    }}
                />
                <Legend 
                    wrapperStyle={{ color: '#94a3b8', fontSize: 12 }}
                />
            </PieChart>
        </ResponsiveContainer>
    );
}