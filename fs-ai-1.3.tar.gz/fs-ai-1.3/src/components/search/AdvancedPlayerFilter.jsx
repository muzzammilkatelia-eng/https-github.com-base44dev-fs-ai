import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Filter, X, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdvancedPlayerFilter({ players, onFilteredResults }) {
    const [showFilters, setShowFilters] = useState(false);
    const [filters, setFilters] = useState({
        name: '',
        positions: [],
        ageMin: 16,
        ageMax: 40,
        valueMin: 0,
        valueMax: 200,
        nationalities: [],
        contractExpiry: '',
        injuryRiskMax: 100,
        leagues: []
    });

    const positions = [
        'Goalkeeper', 'Centre-Back', 'Full-Back', 
        'Defensive Midfielder', 'Central Midfielder', 
        'Attacking Midfielder', 'Winger', 'Striker'
    ];

    const uniqueNationalities = [...new Set(players.map(p => p.nationality).filter(Boolean))].sort();
    const uniqueLeagues = [...new Set(players.map(p => p.league).filter(Boolean))].sort();

    const toggleArrayFilter = (field, value) => {
        setFilters(prev => ({
            ...prev,
            [field]: prev[field].includes(value)
                ? prev[field].filter(v => v !== value)
                : [...prev[field], value]
        }));
    };

    const applyFilters = () => {
        let filtered = players;

        // Name search
        if (filters.name.trim()) {
            const lowerQuery = filters.name.toLowerCase();
            filtered = filtered.filter(p => 
                p.name?.toLowerCase().includes(lowerQuery) ||
                p.current_club?.toLowerCase().includes(lowerQuery)
            );
        }

        // Positions
        if (filters.positions.length > 0) {
            filtered = filtered.filter(p => 
                filters.positions.includes(p.position) ||
                p.secondary_positions?.some(sp => filters.positions.includes(sp))
            );
        }

        // Age range
        filtered = filtered.filter(p => 
            p.age >= filters.ageMin && p.age <= filters.ageMax
        );

        // Market value range
        filtered = filtered.filter(p => 
            (p.market_value || 0) >= filters.valueMin && 
            (p.market_value || 0) <= filters.valueMax
        );

        // Nationalities
        if (filters.nationalities.length > 0) {
            filtered = filtered.filter(p => 
                filters.nationalities.includes(p.nationality)
            );
        }

        // Leagues
        if (filters.leagues.length > 0) {
            filtered = filtered.filter(p => 
                filters.leagues.includes(p.league)
            );
        }

        // Contract expiry
        if (filters.contractExpiry) {
            const targetDate = new Date(filters.contractExpiry);
            filtered = filtered.filter(p => {
                if (!p.contract_expiry) return false;
                const contractDate = new Date(p.contract_expiry);
                return contractDate <= targetDate;
            });
        }

        // Injury risk
        filtered = filtered.filter(p => 
            (p.injury_prone_score || 0) <= filters.injuryRiskMax
        );

        onFilteredResults(filtered);
    };

    const resetFilters = () => {
        setFilters({
            name: '',
            positions: [],
            ageMin: 16,
            ageMax: 40,
            valueMin: 0,
            valueMax: 200,
            nationalities: [],
            contractExpiry: '',
            injuryRiskMax: 100,
            leagues: []
        });
        onFilteredResults(players);
    };

    const activeFilterCount = 
        (filters.name ? 1 : 0) +
        filters.positions.length +
        filters.nationalities.length +
        filters.leagues.length +
        (filters.contractExpiry ? 1 : 0) +
        (filters.ageMin > 16 || filters.ageMax < 40 ? 1 : 0) +
        (filters.valueMin > 0 || filters.valueMax < 200 ? 1 : 0) +
        (filters.injuryRiskMax < 100 ? 1 : 0);

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Search className="w-5 h-5 text-cyan-400" />
                        Advanced Player Search
                        {activeFilterCount > 0 && (
                            <Badge className="bg-cyan-500/20 text-cyan-400 ml-2">
                                {activeFilterCount} active
                            </Badge>
                        )}
                    </CardTitle>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowFilters(!showFilters)}
                        className="border-slate-700"
                    >
                        <Filter className="w-4 h-4 mr-2" />
                        {showFilters ? 'Hide' : 'Show'} Filters
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {/* Quick Search */}
                <div className="mb-4">
                    <Input
                        value={filters.name}
                        onChange={(e) => setFilters({ ...filters, name: e.target.value })}
                        onKeyDown={(e) => e.key === 'Enter' && applyFilters()}
                        placeholder="Quick search by name or club..."
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                </div>

                <AnimatePresence>
                    {showFilters && (
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="space-y-6"
                        >
                            {/* Positions */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">Positions</Label>
                                <div className="flex flex-wrap gap-2">
                                    {positions.map(pos => (
                                        <Badge
                                            key={pos}
                                            onClick={() => toggleArrayFilter('positions', pos)}
                                            className={`cursor-pointer ${
                                                filters.positions.includes(pos)
                                                    ? 'bg-cyan-500 text-white'
                                                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                            }`}
                                        >
                                            {pos}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Age Range */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">
                                    Age Range: {filters.ageMin} - {filters.ageMax} years
                                </Label>
                                <div className="flex items-center gap-4">
                                    <Slider
                                        value={[filters.ageMin]}
                                        onValueChange={([val]) => setFilters({ ...filters, ageMin: val })}
                                        min={16}
                                        max={40}
                                        step={1}
                                        className="flex-1"
                                    />
                                    <Slider
                                        value={[filters.ageMax]}
                                        onValueChange={([val]) => setFilters({ ...filters, ageMax: val })}
                                        min={16}
                                        max={40}
                                        step={1}
                                        className="flex-1"
                                    />
                                </div>
                            </div>

                            {/* Market Value */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">
                                    Market Value: €{filters.valueMin}M - €{filters.valueMax}M
                                </Label>
                                <div className="flex items-center gap-4">
                                    <Slider
                                        value={[filters.valueMin]}
                                        onValueChange={([val]) => setFilters({ ...filters, valueMin: val })}
                                        min={0}
                                        max={200}
                                        step={5}
                                        className="flex-1"
                                    />
                                    <Slider
                                        value={[filters.valueMax]}
                                        onValueChange={([val]) => setFilters({ ...filters, valueMax: val })}
                                        min={0}
                                        max={200}
                                        step={5}
                                        className="flex-1"
                                    />
                                </div>
                            </div>

                            {/* Nationalities */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">Nationalities</Label>
                                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                                    {uniqueNationalities.map(nat => (
                                        <Badge
                                            key={nat}
                                            onClick={() => toggleArrayFilter('nationalities', nat)}
                                            className={`cursor-pointer ${
                                                filters.nationalities.includes(nat)
                                                    ? 'bg-purple-500 text-white'
                                                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                            }`}
                                        >
                                            {nat}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Leagues */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">Leagues</Label>
                                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                                    {uniqueLeagues.map(league => (
                                        <Badge
                                            key={league}
                                            onClick={() => toggleArrayFilter('leagues', league)}
                                            className={`cursor-pointer ${
                                                filters.leagues.includes(league)
                                                    ? 'bg-amber-500 text-white'
                                                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                            }`}
                                        >
                                            {league}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            {/* Contract Expiry */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">
                                    Contract Expiring Before
                                </Label>
                                <Input
                                    type="date"
                                    value={filters.contractExpiry}
                                    onChange={(e) => setFilters({ ...filters, contractExpiry: e.target.value })}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>

                            {/* Injury Risk */}
                            <div>
                                <Label className="text-slate-300 mb-2 block">
                                    Max Injury Risk: {filters.injuryRiskMax}/100
                                </Label>
                                <Slider
                                    value={[filters.injuryRiskMax]}
                                    onValueChange={([val]) => setFilters({ ...filters, injuryRiskMax: val })}
                                    min={0}
                                    max={100}
                                    step={10}
                                />
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Action Buttons */}
                <div className="flex gap-3 mt-6">
                    <Button
                        onClick={applyFilters}
                        className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        <Search className="w-4 h-4 mr-2" />
                        Apply Filters
                    </Button>
                    {activeFilterCount > 0 && (
                        <Button
                            onClick={resetFilters}
                            variant="outline"
                            className="border-slate-700"
                        >
                            <X className="w-4 h-4 mr-2" />
                            Reset
                        </Button>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}