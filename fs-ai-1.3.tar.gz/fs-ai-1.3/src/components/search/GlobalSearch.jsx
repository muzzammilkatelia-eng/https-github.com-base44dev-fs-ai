import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, User, FileText, TrendingUp, Clock, Loader2, Filter, X, SlidersHorizontal } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function GlobalSearch({ open, onClose }) {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState({ players: [], reports: [], projections: [] });
    const [isSearching, setIsSearching] = useState(false);
    const [showFilters, setShowFilters] = useState(false);
    const [recentSearches, setRecentSearches] = useState([]);
    const [sortBy, setSortBy] = useState('relevance');
    const [filters, setFilters] = useState({
        position: '',
        league: '',
        minAge: '',
        maxAge: '',
        minValue: '',
        maxValue: '',
        nationality: ''
    });
    const navigate = useNavigate();

    // Load recent searches from localStorage
    useEffect(() => {
        const saved = localStorage.getItem('recentSearches');
        if (saved) {
            setRecentSearches(JSON.parse(saved));
        }
    }, []);

    // Save search to recent
    const saveRecentSearch = (searchQuery) => {
        if (!searchQuery.trim()) return;
        const updated = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
        setRecentSearches(updated);
        localStorage.setItem('recentSearches', JSON.stringify(updated));
    };

    const clearRecentSearches = () => {
        setRecentSearches([]);
        localStorage.removeItem('recentSearches');
    };

    useEffect(() => {
        if (!query.trim() || query.length < 2) {
            setResults({ players: [], reports: [], projections: [] });
            return;
        }

        const searchTimeout = setTimeout(async () => {
            setIsSearching(true);
            saveRecentSearch(query);
            
            try {
                const [players, reports, projections] = await Promise.all([
                    base44.entities.Player.list('-updated_date', 200),
                    base44.entities.ScoutingReport.list('-created_date', 50),
                    base44.entities.PlayerProjection.list('-created_date', 30)
                ]);

                const lowerQuery = query.toLowerCase();

                let filteredPlayers = players.filter(p => {
                    const matchesQuery = 
                        p.name?.toLowerCase().includes(lowerQuery) ||
                        p.position?.toLowerCase().includes(lowerQuery) ||
                        p.current_club?.toLowerCase().includes(lowerQuery) ||
                        p.nationality?.toLowerCase().includes(lowerQuery) ||
                        p.league?.toLowerCase().includes(lowerQuery);

                    if (!matchesQuery) return false;

                    // Apply filters
                    if (filters.position && p.position !== filters.position) return false;
                    if (filters.league && p.league !== filters.league) return false;
                    if (filters.nationality && p.nationality !== filters.nationality) return false;
                    if (filters.minAge && p.age < parseInt(filters.minAge)) return false;
                    if (filters.maxAge && p.age > parseInt(filters.maxAge)) return false;
                    if (filters.minValue && p.market_value < parseInt(filters.minValue)) return false;
                    if (filters.maxValue && p.market_value > parseInt(filters.maxValue)) return false;

                    return true;
                });

                // Sort results
                if (sortBy === 'name') {
                    filteredPlayers.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
                } else if (sortBy === 'age') {
                    filteredPlayers.sort((a, b) => (a.age || 0) - (b.age || 0));
                } else if (sortBy === 'value') {
                    filteredPlayers.sort((a, b) => (b.market_value || 0) - (a.market_value || 0));
                } else if (sortBy === 'rating') {
                    filteredPlayers.sort((a, b) => (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0));
                }

                filteredPlayers = filteredPlayers.slice(0, 20);

                const filteredReports = reports.filter(r =>
                    r.player_name?.toLowerCase().includes(lowerQuery) ||
                    r.recommendation?.toLowerCase().includes(lowerQuery)
                ).slice(0, 5);

                const filteredProjections = projections.filter(p =>
                    p.player_name?.toLowerCase().includes(lowerQuery) ||
                    p.potential_trajectory?.toLowerCase().includes(lowerQuery)
                ).slice(0, 5);

                setResults({
                    players: filteredPlayers,
                    reports: filteredReports,
                    projections: filteredProjections
                });
            } catch (error) {
                console.error('Search failed:', error);
            } finally {
                setIsSearching(false);
            }
        }, 300);

        return () => clearTimeout(searchTimeout);
    }, [query, filters, sortBy]);

    const handlePlayerClick = (playerId) => {
        navigate(createPageUrl('PlayerProfile') + `?id=${playerId}`);
        onClose();
    };

    const handleRecentSearchClick = (search) => {
        setQuery(search);
    };

    const clearFilters = () => {
        setFilters({
            position: '',
            league: '',
            minAge: '',
            maxAge: '',
            minValue: '',
            maxValue: '',
            nationality: ''
        });
    };

    const hasActiveFilters = Object.values(filters).some(v => v !== '');
    const totalResults = results.players.length + results.reports.length + results.projections.length;

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-4xl max-h-[90vh]">
                <div className="space-y-3">
                    {/* Search Input */}
                    <div className="relative">
                        <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                        <Input
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search players by name, position, club, league, nationality..."
                            className="pl-10 pr-24 bg-slate-800 border-slate-700 text-white h-12 text-lg"
                            autoFocus
                        />
                        <div className="absolute right-2 top-2 flex items-center gap-2">
                            <Button
                                onClick={() => setShowFilters(!showFilters)}
                                variant="ghost"
                                size="sm"
                                className={`${hasActiveFilters ? 'text-cyan-400' : 'text-slate-400'}`}
                            >
                                <SlidersHorizontal className="w-4 h-4 mr-1" />
                                Filters
                            </Button>
                        </div>
                    </div>

                    {/* Advanced Filters */}
                    {showFilters && (
                        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700 space-y-3">
                            <div className="flex items-center justify-between mb-2">
                                <h3 className="text-white font-semibold text-sm flex items-center gap-2">
                                    <Filter className="w-4 h-4 text-cyan-400" />
                                    Advanced Filters
                                </h3>
                                {hasActiveFilters && (
                                    <Button onClick={clearFilters} variant="ghost" size="sm" className="text-red-400 text-xs">
                                        <X className="w-3 h-3 mr-1" />
                                        Clear
                                    </Button>
                                )}
                            </div>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <Select value={filters.position} onValueChange={(v) => setFilters({...filters, position: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white h-9 text-sm">
                                        <SelectValue placeholder="Position" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value={null}>Any Position</SelectItem>
                                        <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                        <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                        <SelectItem value="Full-Back">Full-Back</SelectItem>
                                        <SelectItem value="Defensive Midfielder">Def. Midfielder</SelectItem>
                                        <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                        <SelectItem value="Attacking Midfielder">Att. Midfielder</SelectItem>
                                        <SelectItem value="Winger">Winger</SelectItem>
                                        <SelectItem value="Striker">Striker</SelectItem>
                                    </SelectContent>
                                </Select>

                                <Input
                                    placeholder="League"
                                    value={filters.league}
                                    onChange={(e) => setFilters({...filters, league: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />

                                <Input
                                    placeholder="Nationality"
                                    value={filters.nationality}
                                    onChange={(e) => setFilters({...filters, nationality: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />

                                <Select value={sortBy} onValueChange={setSortBy}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white h-9 text-sm">
                                        <SelectValue placeholder="Sort by" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="relevance">Relevance</SelectItem>
                                        <SelectItem value="name">Name (A-Z)</SelectItem>
                                        <SelectItem value="age">Age</SelectItem>
                                        <SelectItem value="value">Market Value</SelectItem>
                                        <SelectItem value="rating">FS-AI Rating</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <Input
                                    type="number"
                                    placeholder="Min Age"
                                    value={filters.minAge}
                                    onChange={(e) => setFilters({...filters, minAge: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />
                                <Input
                                    type="number"
                                    placeholder="Max Age"
                                    value={filters.maxAge}
                                    onChange={(e) => setFilters({...filters, maxAge: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />
                                <Input
                                    type="number"
                                    placeholder="Min Value (€M)"
                                    value={filters.minValue}
                                    onChange={(e) => setFilters({...filters, minValue: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />
                                <Input
                                    type="number"
                                    placeholder="Max Value (€M)"
                                    value={filters.maxValue}
                                    onChange={(e) => setFilters({...filters, maxValue: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white h-9 text-sm"
                                />
                            </div>
                        </div>
                    )}

                    {/* Recent Searches */}
                    {!query && recentSearches.length > 0 && (
                        <div className="bg-slate-800/30 rounded-lg p-3 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-2">
                                <h3 className="text-slate-400 text-xs font-semibold flex items-center gap-2">
                                    <Clock className="w-3 h-3" />
                                    Recent Searches
                                </h3>
                                <Button onClick={clearRecentSearches} variant="ghost" size="sm" className="text-slate-500 text-xs h-6">
                                    Clear
                                </Button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {recentSearches.map((search, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => handleRecentSearchClick(search)}
                                        className="bg-slate-700/50 hover:bg-slate-700 px-3 py-1 rounded-full text-slate-300 text-xs transition-colors"
                                    >
                                        {search}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                <div className="mt-4 max-h-[60vh] overflow-y-auto">
                    {isSearching && (
                        <div className="text-center py-8">
                            <Loader2 className="w-8 h-8 animate-spin text-cyan-400 mx-auto" />
                        </div>
                    )}

                    {!isSearching && query.length >= 2 && totalResults === 0 && (
                        <div className="text-center py-8">
                            <p className="text-slate-400">No results found for "{query}"</p>
                        </div>
                    )}

                    {!isSearching && totalResults > 0 && (
                        <div className="space-y-6">
                            {/* Players */}
                            {results.players.length > 0 && (
                                <div>
                                    <h3 className="text-slate-400 text-sm font-semibold mb-2 flex items-center gap-2">
                                        <User className="w-4 h-4" />
                                        Players ({results.players.length})
                                    </h3>
                                    <div className="space-y-2">
                                        {results.players.map(player => (
                                            <button
                                                key={player.id}
                                                onClick={() => handlePlayerClick(player.id)}
                                                className="w-full text-left bg-slate-800/50 hover:bg-slate-800 rounded-lg p-3 transition-colors"
                                            >
                                                <div className="flex items-center justify-between">
                                                    <div className="flex-1 min-w-0">
                                                        <p className="text-white font-semibold">{player.name}</p>
                                                        <p className="text-slate-400 text-sm">
                                                            {player.position} • {player.age}y • {player.current_club}
                                                        </p>
                                                        {player.league && (
                                                            <p className="text-slate-500 text-xs">{player.league}</p>
                                                        )}
                                                    </div>
                                                    <div className="flex flex-col items-end gap-1">
                                                        <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                            {player.nationality}
                                                        </Badge>
                                                        {player.market_value && (
                                                            <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                                €{player.market_value}M
                                                            </Badge>
                                                        )}
                                                        {player.fsai_proprietary_score && (
                                                            <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                                                                FS-AI: {player.fsai_proprietary_score}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Reports */}
                            {results.reports.length > 0 && (
                                <div>
                                    <h3 className="text-slate-400 text-sm font-semibold mb-2 flex items-center gap-2">
                                        <FileText className="w-4 h-4" />
                                        Reports ({results.reports.length})
                                    </h3>
                                    <div className="space-y-2">
                                        {results.reports.map(report => (
                                            <div
                                                key={report.id}
                                                className="bg-slate-800/50 rounded-lg p-3"
                                            >
                                                <div className="flex items-center justify-between mb-1">
                                                    <p className="text-white font-semibold">{report.player_name}</p>
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        {report.overall_rating}/10
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">
                                                    {report.recommendation} • {new Date(report.created_date).toLocaleDateString()}
                                                </p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Projections */}
                            {results.projections.length > 0 && (
                                <div>
                                    <h3 className="text-slate-400 text-sm font-semibold mb-2 flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4" />
                                        Projections ({results.projections.length})
                                    </h3>
                                    <div className="space-y-2">
                                        {results.projections.map(proj => (
                                            <div
                                                key={proj.id}
                                                className="bg-slate-800/50 rounded-lg p-3"
                                            >
                                                <div className="flex items-center justify-between mb-1">
                                                    <p className="text-white font-semibold">{proj.player_name}</p>
                                                    <Badge className="bg-purple-500/20 text-purple-400">
                                                        {proj.potential_trajectory}
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">
                                                    Peak: {proj.peak_potential_rating}/10 • {proj.years_to_peak} years
                                                </p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className="mt-4 pt-4 border-t border-slate-800 text-xs text-slate-500 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <span>Press <kbd className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700">ESC</kbd> to close</span>
                        <span>•</span>
                        <span>Press <kbd className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700">Ctrl+K</kbd> to search</span>
                    </div>
                    <div className="flex items-center gap-2">
                        {hasActiveFilters && (
                            <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                {Object.values(filters).filter(v => v !== '').length} filters active
                            </Badge>
                        )}
                        {totalResults > 0 && <span className="font-semibold text-white">{totalResults} results</span>}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}