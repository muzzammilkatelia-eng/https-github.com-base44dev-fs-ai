import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { Trophy, Target, TrendingUp, Clock, Activity } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export default function SimulationResults({ simulation }) {
    if (!simulation) return null;

    const [homeScore, awayScore] = simulation.final_score.split('-').map(Number);

    return (
        <div className="space-y-6">
            {/* Final Score */}
            <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardContent className="pt-6">
                    <div className="flex items-center justify-center gap-8">
                        <div className="text-center">
                            <h3 className="text-2xl font-bold text-white mb-2">{simulation.home_team}</h3>
                            <p className="text-6xl font-bold text-cyan-400">{homeScore}</p>
                        </div>
                        <div className="text-4xl font-bold text-slate-600">-</div>
                        <div className="text-center">
                            <h3 className="text-2xl font-bold text-white mb-2">{simulation.away_team}</h3>
                            <p className="text-6xl font-bold text-blue-400">{awayScore}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Match Statistics */}
            {simulation.match_statistics && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Activity className="w-5 h-5 text-cyan-400" />
                            Match Statistics
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {simulation.match_statistics.possession && (
                            <div>
                                <div className="flex justify-between text-sm text-slate-400 mb-2">
                                    <span>Possession</span>
                                    <span>{simulation.match_statistics.possession.home}% - {simulation.match_statistics.possession.away}%</span>
                                </div>
                                <Progress value={simulation.match_statistics.possession.home} className="h-2" />
                            </div>
                        )}
                        {simulation.match_statistics.shots && (
                            <div className="grid grid-cols-3 gap-4 text-center">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-2xl font-bold text-cyan-400">{simulation.match_statistics.shots.home}</p>
                                    <p className="text-xs text-slate-400">Home Shots</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-lg text-slate-400">Shots</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-2xl font-bold text-blue-400">{simulation.match_statistics.shots.away}</p>
                                    <p className="text-xs text-slate-400">Away Shots</p>
                                </div>
                            </div>
                        )}
                        {simulation.match_statistics.passes && (
                            <div className="grid grid-cols-3 gap-4 text-center">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-2xl font-bold text-cyan-400">{simulation.match_statistics.passes.home}</p>
                                    <p className="text-xs text-slate-400">Home Passes</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-lg text-slate-400">Passes</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-2xl font-bold text-blue-400">{simulation.match_statistics.passes.away}</p>
                                    <p className="text-xs text-slate-400">Away Passes</p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}

            {/* Match Events */}
            {simulation.match_events && simulation.match_events.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Clock className="w-5 h-5 text-amber-400" />
                            Match Events
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {simulation.match_events.map((event, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3"
                                >
                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 min-w-[50px]">
                                        {event.minute}'
                                    </Badge>
                                    <div className="flex-1">
                                        <p className="text-white font-semibold">{event.player}</p>
                                        <p className="text-slate-400 text-sm">{event.description}</p>
                                    </div>
                                    <span className="text-amber-400 text-sm font-semibold">{event.event_type}</span>
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Player Ratings */}
            {simulation.player_ratings && simulation.player_ratings.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Trophy className="w-5 h-5 text-amber-400" />
                            Player Ratings
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {simulation.player_ratings.map((rating, index) => (
                                <div key={index} className="bg-slate-800/50 rounded-lg p-3">
                                    <div className="flex justify-between items-center mb-2">
                                        <div>
                                            <p className="text-white font-semibold">{rating.player}</p>
                                            <p className="text-slate-400 text-xs">{rating.team}</p>
                                        </div>
                                        <Badge className={`${
                                            rating.rating >= 8 ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                                            rating.rating >= 7 ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' :
                                            'bg-slate-500/20 text-slate-400 border-slate-500/30'
                                        }`}>
                                            {rating.rating.toFixed(1)}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-300 text-sm">{rating.performance}</p>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Tactical Analysis */}
            {simulation.tactical_analysis && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-purple-400" />
                            Tactical Analysis
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 leading-relaxed whitespace-pre-line">
                            {simulation.tactical_analysis}
                        </p>
                    </CardContent>
                </Card>
            )}

            {/* Key Moments */}
            {simulation.key_moments && (
                <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-purple-400" />
                            Key Moments
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 leading-relaxed whitespace-pre-line">
                            {simulation.key_moments}
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}