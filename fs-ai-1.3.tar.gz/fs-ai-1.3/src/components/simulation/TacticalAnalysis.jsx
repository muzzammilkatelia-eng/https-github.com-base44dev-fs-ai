import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { Swords, Target, TrendingUp, AlertCircle, Lightbulb, CheckCircle2 } from 'lucide-react';

export default function TacticalAnalysis({ analysis }) {
    if (!analysis) return null;

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
        >
            {/* Match Overview */}
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-purple-400" />
                        Tactical Overview
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line">
                        {analysis.tactical_overview}
                    </p>
                </CardContent>
            </Card>

            {/* Key Tactical Battles */}
            {analysis.key_battles && analysis.key_battles.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Swords className="w-5 h-5 text-amber-400" />
                            Key Tactical Battles
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {analysis.key_battles.map((battle, index) => (
                            <div key={index} className="bg-slate-800/50 rounded-lg p-4">
                                <div className="flex justify-between items-start mb-3">
                                    <h4 className="text-white font-semibold">{battle.area}</h4>
                                    <Badge className={`${
                                        battle.winner === 'Home' 
                                            ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                                            : battle.winner === 'Away'
                                            ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                                            : 'bg-slate-500/20 text-slate-400 border-slate-500/30'
                                    }`}>
                                        {battle.winner} Won
                                    </Badge>
                                </div>
                                <p className="text-slate-300 text-sm mb-2">{battle.description}</p>
                                <p className="text-slate-400 text-xs italic">{battle.impact}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}

            {/* Home Team Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-cyan-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-cyan-400" />
                            Home Team: Tactical Successes
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {analysis.home_team_successes?.map((success, index) => (
                                <li key={index} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-emerald-400 mt-1">✓</span>
                                    <span>{success}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-blue-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-blue-400" />
                            Away Team: Tactical Successes
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {analysis.away_team_successes?.map((success, index) => (
                                <li key={index} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-emerald-400 mt-1">✓</span>
                                    <span>{success}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-red-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertCircle className="w-5 h-5 text-red-400" />
                            Home Team: Tactical Failures
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {analysis.home_team_failures?.map((failure, index) => (
                                <li key={index} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-red-400 mt-1">✗</span>
                                    <span>{failure}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-red-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <AlertCircle className="w-5 h-5 text-red-400" />
                            Away Team: Tactical Failures
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {analysis.away_team_failures?.map((failure, index) => (
                                <li key={index} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-red-400 mt-1">✗</span>
                                    <span>{failure}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            </div>

            {/* Recommended Adjustments */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-cyan-400" />
                            Home Team: Recommended Adjustments
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line">
                            {analysis.home_team_adjustments}
                        </p>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-blue-400" />
                            Away Team: Recommended Adjustments
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line">
                            {analysis.away_team_adjustments}
                        </p>
                    </CardContent>
                </Card>
            </div>

            {/* Future Preparation */}
            <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-amber-400" />
                        Future Match Preparation Insights
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line">
                        {analysis.future_preparation}
                    </p>
                </CardContent>
            </Card>
        </motion.div>
    );
}