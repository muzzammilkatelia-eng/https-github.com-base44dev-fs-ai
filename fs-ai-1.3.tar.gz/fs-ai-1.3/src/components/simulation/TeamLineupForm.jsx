import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Plus, Trash2 } from 'lucide-react';

export default function TeamLineupForm({ team, onUpdate }) {
    const [players, setPlayers] = useState(team.lineup || []);
    
    const addPlayer = () => {
        setPlayers([...players, { name: '', position: 'Forward', rating: 75 }]);
    };

    const removePlayer = (index) => {
        const newPlayers = players.filter((_, i) => i !== index);
        setPlayers(newPlayers);
        onUpdate({ ...team, lineup: newPlayers });
    };

    const updatePlayer = (index, field, value) => {
        const newPlayers = [...players];
        newPlayers[index][field] = value;
        setPlayers(newPlayers);
        onUpdate({ ...team, lineup: newPlayers });
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white">{team.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <Label className="text-slate-400">Team Name</Label>
                    <Input
                        value={team.name}
                        onChange={(e) => onUpdate({ ...team, name: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                </div>

                <div>
                    <Label className="text-slate-400">Formation</Label>
                    <Select value={team.formation} onValueChange={(v) => onUpdate({ ...team, formation: v })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="4-3-3">4-3-3</SelectItem>
                            <SelectItem value="4-4-2">4-4-2</SelectItem>
                            <SelectItem value="3-5-2">3-5-2</SelectItem>
                            <SelectItem value="4-2-3-1">4-2-3-1</SelectItem>
                            <SelectItem value="3-4-3">3-4-3</SelectItem>
                            <SelectItem value="5-3-2">5-3-2</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                <div>
                    <Label className="text-slate-400">Tactical Instructions</Label>
                    <Textarea
                        value={team.tactics}
                        onChange={(e) => onUpdate({ ...team, tactics: e.target.value })}
                        placeholder="E.g., High press, fast counter-attacks, possession-based..."
                        className="bg-slate-800 border-slate-700 text-white"
                        rows={3}
                    />
                </div>

                <div>
                    <div className="flex justify-between items-center mb-3">
                        <Label className="text-slate-400">Lineup ({players.length}/11)</Label>
                        <Button
                            onClick={addPlayer}
                            disabled={players.length >= 11}
                            size="sm"
                            className="bg-cyan-500 hover:bg-cyan-600"
                        >
                            <Plus className="w-4 h-4 mr-1" />
                            Add Player
                        </Button>
                    </div>

                    <div className="space-y-3">
                        {players.map((player, index) => (
                            <div key={index} className="bg-slate-800 rounded-lg p-3 space-y-2">
                                <div className="grid grid-cols-12 gap-2">
                                    <div className="col-span-5">
                                        <Input
                                            placeholder="Player name"
                                            value={player.name}
                                            onChange={(e) => updatePlayer(index, 'name', e.target.value)}
                                            className="bg-slate-700 border-slate-600 text-white text-sm"
                                        />
                                    </div>
                                    <div className="col-span-4">
                                        <Select value={player.position} onValueChange={(v) => updatePlayer(index, 'position', v)}>
                                            <SelectTrigger className="bg-slate-700 border-slate-600 text-white text-sm">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Goalkeeper">GK</SelectItem>
                                                <SelectItem value="Defender">DEF</SelectItem>
                                                <SelectItem value="Midfielder">MID</SelectItem>
                                                <SelectItem value="Forward">FWD</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="col-span-2">
                                        <Input
                                            type="number"
                                            min="50"
                                            max="99"
                                            value={player.rating}
                                            onChange={(e) => updatePlayer(index, 'rating', parseInt(e.target.value))}
                                            className="bg-slate-700 border-slate-600 text-white text-sm"
                                        />
                                    </div>
                                    <div className="col-span-1 flex items-center justify-center">
                                        <Button
                                            onClick={() => removePlayer(index)}
                                            size="sm"
                                            variant="ghost"
                                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}