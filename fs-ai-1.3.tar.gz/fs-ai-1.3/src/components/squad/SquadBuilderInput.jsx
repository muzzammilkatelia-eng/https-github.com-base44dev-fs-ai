import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Loader2 } from 'lucide-react';

export default function SquadBuilderInput({ onSubmit, isLoading }) {
    const [requirements, setRequirements] = useState({
        formation: '4-3-3',
        playingStyle: '',
        budget: '',
        priorityPositions: '',
        squadSize: '25',
        ageBalance: 'Balanced',
        additionalNotes: ''
    });

    const formations = [
        '4-3-3', '4-2-3-1', '3-5-2', '4-4-2', '3-4-3', 
        '4-1-4-1', '5-3-2', '4-5-1', '3-4-2-1', '4-3-2-1'
    ];

    const playingStyles = [
        'Possession-based (Tiki-Taka)',
        'High-pressing (Gegenpressing)',
        'Counter-attacking',
        'Direct / Long-ball',
        'Wing-play focused',
        'Central dominance',
        'Defensive / Low-block',
        'Total Football',
        'Catenaccio (Defensive)',
        'Modern fluid system'
    ];

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(requirements);
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-400" />
                    Define Squad Requirements
                </CardTitle>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <Label className="text-slate-400">Formation</Label>
                            <Select 
                                value={requirements.formation} 
                                onValueChange={(v) => setRequirements({...requirements, formation: v})}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {formations.map(f => (
                                        <SelectItem key={f} value={f}>{f}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-slate-400">Total Budget</Label>
                            <Input
                                value={requirements.budget}
                                onChange={(e) => setRequirements({...requirements, budget: e.target.value})}
                                placeholder="e.g., €150M"
                                className="bg-slate-800 border-slate-700 text-white"
                                required
                            />
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-400">Playing Style</Label>
                        <Select 
                            value={requirements.playingStyle} 
                            onValueChange={(v) => setRequirements({...requirements, playingStyle: v})}
                        >
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Select playing style" />
                            </SelectTrigger>
                            <SelectContent>
                                {playingStyles.map(style => (
                                    <SelectItem key={style} value={style}>{style}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <Label className="text-slate-400">Squad Size Target</Label>
                            <Select 
                                value={requirements.squadSize} 
                                onValueChange={(v) => setRequirements({...requirements, squadSize: v})}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="20">20 players</SelectItem>
                                    <SelectItem value="25">25 players</SelectItem>
                                    <SelectItem value="30">30 players</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-slate-400">Age Balance</Label>
                            <Select 
                                value={requirements.ageBalance} 
                                onValueChange={(v) => setRequirements({...requirements, ageBalance: v})}
                            >
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Young (U23 focus)">Young (U23 focus)</SelectItem>
                                    <SelectItem value="Balanced">Balanced</SelectItem>
                                    <SelectItem value="Experienced (25+)">Experienced (25+)</SelectItem>
                                    <SelectItem value="Win-now (27+)">Win-now (27+)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-slate-400">Priority Positions</Label>
                            <Input
                                value={requirements.priorityPositions}
                                onChange={(e) => setRequirements({...requirements, priorityPositions: e.target.value})}
                                placeholder="e.g., ST, CM"
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-400">Additional Requirements / Philosophy</Label>
                        <Textarea
                            value={requirements.additionalNotes}
                            onChange={(e) => setRequirements({...requirements, additionalNotes: e.target.value})}
                            placeholder="e.g., Must have homegrown players, prefer technical players over physical, need leadership in defense..."
                            className="bg-slate-800 border-slate-700 text-white"
                            rows={4}
                        />
                    </div>

                    <Button
                        type="submit"
                        disabled={isLoading || !requirements.playingStyle || !requirements.budget}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Building Squad...
                            </>
                        ) : (
                            <>
                                <Users className="w-4 h-4 mr-2" />
                                Build Optimal Squad
                            </>
                        )}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}