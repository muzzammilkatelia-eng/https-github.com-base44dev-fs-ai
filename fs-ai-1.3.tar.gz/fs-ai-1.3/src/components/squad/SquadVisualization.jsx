import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Users, TrendingUp, AlertTriangle, CheckCircle, Target, 
    DollarSign, BarChart3, Shield, ChevronDown, ChevronUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function SquadVisualization({ squadData }) {
    const [expandedPlayer, setExpandedPlayer] = useState(null);

    const getPositionColor = (position) => {
        if (position.includes('GK')) return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
        if (position.includes('B') || position.includes('D')) return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
        if (position.includes('M')) return 'bg-green-500/20 text-green-400 border-green-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };

    return (
        <div className="space-y-6">
            {/* Summary */}
            {squadData.summary && (
                <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <p className="text-slate-300 text-sm">{squadData.summary}</p>
                    </CardContent>
                </Card>
            )}

            {/* Key Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <Users className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">
                            {squadData.starting_xi.length + (squadData.key_substitutes?.length || 0)}
                        </p>
                        <p className="text-slate-400 text-xs">Total Players</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <DollarSign className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">
                            {squadData.budget_breakdown?.total_spent || 'N/A'}
                        </p>
                        <p className="text-slate-400 text-xs">Total Cost</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <BarChart3 className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{squadData.chemistry_score || 'N/A'}/100</p>
                        <p className="text-slate-400 text-xs">Chemistry</p>
                    </CardContent>
                </Card>
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6 text-center">
                        <Shield className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">
                            {Math.round(squadData.starting_xi.reduce((sum, p) => sum + p.age, 0) / squadData.starting_xi.length)}y
                        </p>
                        <p className="text-slate-400 text-xs">Avg Age</p>
                    </CardContent>
                </Card>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="starting-xi" className="space-y-6">
                <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    <TabsTrigger value="starting-xi">Starting XI</TabsTrigger>
                    <TabsTrigger value="substitutes">Substitutes</TabsTrigger>
                    <TabsTrigger value="analysis">Analysis</TabsTrigger>
                    <TabsTrigger value="budget">Budget</TabsTrigger>
                </TabsList>

                <TabsContent value="starting-xi">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Starting XI</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {squadData.starting_xi.map((player, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: idx * 0.05 }}
                                    >
                                        <Card className="bg-slate-800/50 border-slate-700">
                                            <CardContent className="pt-4">
                                                <div className="flex justify-between items-start mb-3">
                                                    <div className="flex-1">
                                                        <div className="flex items-center gap-2 mb-2">
                                                            <Badge className={getPositionColor(player.position)}>
                                                                {player.position}
                                                            </Badge>
                                                            <h3 className="text-white font-bold">{player.player_name}</h3>
                                                            <span className="text-slate-400 text-sm">
                                                                {player.age}y • {player.current_club}
                                                            </span>
                                                        </div>
                                                        <p className="text-slate-400 text-sm mb-2">
                                                            <span className="text-purple-400 font-semibold">Role:</span> {player.tactical_role}
                                                        </p>
                                                        <p className="text-slate-300 text-sm">{player.style_contribution}</p>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-emerald-400 font-bold">{player.estimated_fee}</p>
                                                    </div>
                                                </div>

                                                {player.key_attributes && (
                                                    <div className="flex gap-2 flex-wrap mb-3">
                                                        {player.key_attributes.map((attr, i) => (
                                                            <Badge key={i} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                                {attr}
                                                            </Badge>
                                                        ))}
                                                    </div>
                                                )}

                                                {player.alternatives && player.alternatives.length > 0 && (
                                                    <div>
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => setExpandedPlayer(expandedPlayer === idx ? null : idx)}
                                                            className="text-slate-400 hover:text-white text-xs"
                                                        >
                                                            {expandedPlayer === idx ? <ChevronUp className="w-3 h-3 mr-1" /> : <ChevronDown className="w-3 h-3 mr-1" />}
                                                            Show {player.alternatives.length} alternatives
                                                        </Button>
                                                        <AnimatePresence>
                                                            {expandedPlayer === idx && (
                                                                <motion.div
                                                                    initial={{ height: 0, opacity: 0 }}
                                                                    animate={{ height: 'auto', opacity: 1 }}
                                                                    exit={{ height: 0, opacity: 0 }}
                                                                    className="mt-2 space-y-2"
                                                                >
                                                                    {player.alternatives.map((alt, i) => (
                                                                        <div key={i} className="bg-slate-900/50 rounded p-2">
                                                                            <div className="flex justify-between items-start">
                                                                                <div>
                                                                                    <p className="text-white text-sm font-semibold">{alt.name}</p>
                                                                                    <p className="text-slate-400 text-xs">{alt.rationale}</p>
                                                                                </div>
                                                                                <p className="text-emerald-400 text-xs font-semibold">{alt.fee}</p>
                                                                            </div>
                                                                        </div>
                                                                    ))}
                                                                </motion.div>
                                                            )}
                                                        </AnimatePresence>
                                                    </div>
                                                )}
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="substitutes">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Key Substitutes</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {squadData.key_substitutes?.map((player, idx) => (
                                    <Card key={idx} className="bg-slate-800/50 border-slate-700">
                                        <CardContent className="pt-4">
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <Badge className={getPositionColor(player.position)}>
                                                            {player.position}
                                                        </Badge>
                                                        <h3 className="text-white font-bold">{player.player_name}</h3>
                                                        <span className="text-slate-400 text-sm">
                                                            {player.age}y • {player.current_club}
                                                        </span>
                                                    </div>
                                                    <p className="text-slate-400 text-sm">{player.tactical_role}</p>
                                                </div>
                                                <p className="text-emerald-400 font-bold">{player.estimated_fee}</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="analysis">
                    <div className="space-y-4">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Tactical Analysis</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-300 text-sm">{squadData.tactical_analysis}</p>
                            </CardContent>
                        </Card>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-emerald-400 text-sm flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" />
                                        Squad Strengths
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {squadData.squad_strengths?.map((strength, i) => (
                                            <li key={i} className="text-slate-300 text-sm">✓ {strength}</li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>

                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardHeader>
                                    <CardTitle className="text-amber-400 text-sm flex items-center gap-2">
                                        <AlertTriangle className="w-4 h-4" />
                                        Areas to Address
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {squadData.squad_weaknesses?.map((weakness, i) => (
                                            <li key={i} className="text-slate-300 text-sm">⚠ {weakness}</li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </div>

                        <Card className="bg-cyan-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-cyan-400 text-sm flex items-center gap-2">
                                    <Target className="w-4 h-4" />
                                    Training Focus
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {squadData.training_focus?.map((focus, i) => (
                                        <li key={i} className="text-slate-300 text-sm">• {focus}</li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="budget">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-emerald-400" />
                                Budget Breakdown
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {squadData.budget_breakdown && (
                                    <>
                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Goalkeepers</p>
                                                <p className="text-white font-bold">{squadData.budget_breakdown.goalkeepers}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Defenders</p>
                                                <p className="text-white font-bold">{squadData.budget_breakdown.defenders}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Midfielders</p>
                                                <p className="text-white font-bold">{squadData.budget_breakdown.midfielders}</p>
                                            </div>
                                            <div className="bg-slate-800/50 rounded-lg p-3">
                                                <p className="text-slate-400 text-xs mb-1">Attackers</p>
                                                <p className="text-white font-bold">{squadData.budget_breakdown.attackers}</p>
                                            </div>
                                        </div>

                                        <div className="border-t border-slate-700 pt-4">
                                            <div className="flex justify-between items-center mb-2">
                                                <p className="text-slate-400">Total Spent</p>
                                                <p className="text-white font-bold text-lg">{squadData.budget_breakdown.total_spent}</p>
                                            </div>
                                            <div className="flex justify-between items-center">
                                                <p className="text-slate-400">Remaining Budget</p>
                                                <p className="text-emerald-400 font-bold text-lg">{squadData.budget_breakdown.remaining}</p>
                                            </div>
                                        </div>
                                    </>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}