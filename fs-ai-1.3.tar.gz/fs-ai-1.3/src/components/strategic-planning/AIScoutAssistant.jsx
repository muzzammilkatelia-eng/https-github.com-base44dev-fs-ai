import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, Target, Eye, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AIScoutAssistant({ context = 'database' }) {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [recommendations, setRecommendations] = useState(null);

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scoutingReports'],
        queryFn: () => base44.entities.ScoutingReport.list()
    });

    const analyzeAndRecommend = async () => {
        if (!activeStrategy) {
            toast.error('Please set an active team strategy first');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing squad and identifying targets...', { id: 'scout' });

        try {
            const topPlayers = players
                .filter(p => p.fsai_proprietary_score)
                .sort((a, b) => (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0))
                .slice(0, 20);

            const prompt = `You are an elite AI scouting assistant. Analyze the following:

Current Team Strategy:
- Formation: ${activeStrategy.formation}
- Playing Style: ${activeStrategy.playing_style}
- Pressing Intensity: ${activeStrategy.pressing_intensity}
- Tempo: ${activeStrategy.tempo}
- Width: ${activeStrategy.width}

Available Players in Database (${topPlayers.length} top-rated):
${topPlayers.map(p => `- ${p.name} (${p.position}, ${p.age} years, Rating: ${p.fsai_proprietary_score?.toFixed(1)}, Club: ${p.current_club}, Value: €${p.market_value}M)`).join('\n')}

Recent Scouting Reports: ${scoutingReports.length} available

Task: Identify the 5 best transfer targets that fit this tactical strategy. Provide automated summaries.

Return this JSON structure:
{
  "strategic_fit_analysis": "Brief analysis of what types of players suit this strategy",
  "priority_positions": ["Position 1", "Position 2", "Position 3"],
  "recommendations": [
    {
      "player_name": "Player name",
      "position": "Position",
      "age": 25,
      "current_club": "Club name",
      "fit_score": 95,
      "tactical_fit_reason": "Why they fit the strategy (2 sentences max)",
      "key_strengths": ["Strength 1", "Strength 2", "Strength 3"],
      "estimated_value": "€XM",
      "urgency": "High/Medium/Low",
      "quick_summary": "One-sentence profile summary"
    }
  ],
  "squad_gaps": ["Gap 1", "Gap 2"],
  "alternative_targets": ["Player 1", "Player 2"]
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        strategic_fit_analysis: { type: 'string' },
                        priority_positions: { type: 'array', items: { type: 'string' } },
                        recommendations: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    position: { type: 'string' },
                                    age: { type: 'number' },
                                    current_club: { type: 'string' },
                                    fit_score: { type: 'number' },
                                    tactical_fit_reason: { type: 'string' },
                                    key_strengths: { type: 'array', items: { type: 'string' } },
                                    estimated_value: { type: 'string' },
                                    urgency: { type: 'string' },
                                    quick_summary: { type: 'string' }
                                }
                            }
                        },
                        squad_gaps: { type: 'array', items: { type: 'string' } },
                        alternative_targets: { type: 'array', items: { type: 'string' } }
                    }
                }
            });

            setRecommendations(data);
            toast.success('Scout analysis complete', { id: 'scout' });
        } catch (error) {
            console.error('Scout analysis error:', error);
            toast.error('Analysis failed', { id: 'scout' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getUrgencyColor = (urgency) => {
        switch(urgency) {
            case 'High': return 'red';
            case 'Medium': return 'amber';
            case 'Low': return 'cyan';
            default: return 'slate';
        }
    };

    const getFitColor = (score) => {
        if (score >= 90) return 'emerald';
        if (score >= 75) return 'cyan';
        if (score >= 60) return 'amber';
        return 'slate';
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-cyan-400" />
                        AI Scout Assistant
                    </CardTitle>
                    <Button
                        onClick={analyzeAndRecommend}
                        disabled={isAnalyzing || !activeStrategy}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Find Targets
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                {!activeStrategy && (
                    <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/30">
                        <p className="text-amber-300 text-sm">
                            Set an active team strategy in Strategic Planning to enable AI recommendations.
                        </p>
                    </div>
                )}

                {activeStrategy && !recommendations && (
                    <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700 text-center">
                        <Target className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
                        <p className="text-slate-300 mb-2">
                            Ready to analyze {players.length} players against your {activeStrategy.formation} {activeStrategy.playing_style} strategy
                        </p>
                        <p className="text-slate-400 text-sm">
                            Click "Find Targets" to get AI-powered transfer recommendations
                        </p>
                    </div>
                )}

                {recommendations && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        <div className="p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                            <h4 className="text-cyan-300 font-semibold mb-2">Strategic Fit Analysis</h4>
                            <p className="text-slate-300 text-sm">{recommendations.strategic_fit_analysis}</p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                    <Target className="w-4 h-4 text-cyan-400" />
                                    Priority Positions
                                </h4>
                                <div className="flex flex-wrap gap-2">
                                    {recommendations.priority_positions?.map((pos, i) => (
                                        <Badge key={i} className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                            {pos}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-3">Squad Gaps</h4>
                                <ul className="space-y-1">
                                    {recommendations.squad_gaps?.map((gap, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-center gap-2">
                                            <div className="w-1 h-1 bg-red-400 rounded-full" />
                                            {gap}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>

                        <div>
                            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-emerald-400" />
                                Top Transfer Targets ({recommendations.recommendations?.length})
                            </h4>
                            <div className="space-y-4">
                                {recommendations.recommendations?.map((rec, i) => {
                                    const player = players.find(p => p.name.toLowerCase().includes(rec.player_name.toLowerCase()));
                                    const fitColor = getFitColor(rec.fit_score);
                                    const urgencyColor = getUrgencyColor(rec.urgency);

                                    return (
                                        <motion.div
                                            key={i}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: i * 0.1 }}
                                            className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-all"
                                        >
                                            <div className="flex justify-between items-start mb-3">
                                                <div>
                                                    <h5 className="text-white font-semibold text-lg mb-1">{rec.player_name}</h5>
                                                    <div className="flex items-center gap-2 flex-wrap">
                                                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                            {rec.position}
                                                        </Badge>
                                                        <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                            {rec.age} years
                                                        </Badge>
                                                        <Badge className={`bg-${fitColor}-500/20 text-${fitColor}-400 border-${fitColor}-500/30`}>
                                                            {rec.fit_score}% Fit
                                                        </Badge>
                                                        <Badge className={`bg-${urgencyColor}-500/20 text-${urgencyColor}-400 border-${urgencyColor}-500/30`}>
                                                            {rec.urgency} Priority
                                                        </Badge>
                                                    </div>
                                                </div>
                                                {player && (
                                                    <Link to={createPageUrl('PlayerProfileDetail') + '?id=' + player.id}>
                                                        <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                                                            <Eye className="w-4 h-4 mr-2" />
                                                            View
                                                        </Button>
                                                    </Link>
                                                )}
                                            </div>

                                            <div className="space-y-3">
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Quick Summary</p>
                                                    <p className="text-slate-300 text-sm italic">{rec.quick_summary}</p>
                                                </div>

                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Tactical Fit</p>
                                                    <p className="text-slate-300 text-sm">{rec.tactical_fit_reason}</p>
                                                </div>

                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Key Strengths</p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {rec.key_strengths?.map((strength, j) => (
                                                            <Badge key={j} variant="outline" className="border-emerald-500/30 text-emerald-400">
                                                                <CheckCircle className="w-3 h-3 mr-1" />
                                                                {strength}
                                                            </Badge>
                                                        ))}
                                                    </div>
                                                </div>

                                                <div className="flex justify-between items-center pt-2 border-t border-slate-700">
                                                    <div>
                                                        <p className="text-slate-400 text-xs">Current Club</p>
                                                        <p className="text-white text-sm font-medium">{rec.current_club}</p>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-slate-400 text-xs">Estimated Value</p>
                                                        <p className="text-emerald-400 text-lg font-bold">{rec.estimated_value}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    );
                                })}
                            </div>
                        </div>

                        {recommendations.alternative_targets?.length > 0 && (
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-2">Alternative Targets</h4>
                                <div className="flex flex-wrap gap-2">
                                    {recommendations.alternative_targets.map((alt, i) => (
                                        <Badge key={i} variant="outline" className="border-slate-600 text-slate-300">
                                            {alt}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}