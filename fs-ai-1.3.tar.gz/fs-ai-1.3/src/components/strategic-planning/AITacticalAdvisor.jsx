import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function AITacticalAdvisor() {
    const [opponentName, setOpponentName] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [recommendations, setRecommendations] = useState(null);

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const generateRecommendations = async () => {
        if (!opponentName.trim()) {
            toast.error('Please enter opponent name');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing opponent and player form...', { id: 'analysis' });

        try {
            const playerForms = players.slice(0, 5).map(p => ({
                name: p.name,
                position: p.position,
                rating: p.fsai_proprietary_score || 70,
                recent_form: Math.random() > 0.5 ? 'Good' : 'Average'
            }));

            const prompt = `You are an elite football tactical analyst. Analyze the following:

Current Team Setup:
- Formation: ${activeStrategy?.formation || '4-3-3'}
- Playing Style: ${activeStrategy?.playing_style || 'Balanced'}
- Pressing Intensity: ${activeStrategy?.pressing_intensity || 'Medium'}

Upcoming Opponent: ${opponentName}

Key Players & Form:
${playerForms.map(p => `- ${p.name} (${p.position}) - Rating: ${p.rating}, Form: ${p.recent_form}`).join('\n')}

Provide tactical recommendations in this exact JSON structure:
{
  "opponent_analysis": "Brief analysis of typical opponent strengths/weaknesses",
  "formation_recommendation": "Recommended formation with reason",
  "tactical_adjustments": [
    {"adjustment": "Specific tactical change", "reason": "Why it helps", "priority": "High/Medium/Low"}
  ],
  "player_instructions": [
    {"player_role": "Position/role", "instruction": "Specific instruction"}
  ],
  "risk_assessment": "Overall risk level of this match (Low/Medium/High)",
  "key_battles": ["Area 1", "Area 2"],
  "predicted_outcome": "Brief prediction"
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        opponent_analysis: { type: 'string' },
                        formation_recommendation: { type: 'string' },
                        tactical_adjustments: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    adjustment: { type: 'string' },
                                    reason: { type: 'string' },
                                    priority: { type: 'string' }
                                }
                            }
                        },
                        player_instructions: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_role: { type: 'string' },
                                    instruction: { type: 'string' }
                                }
                            }
                        },
                        risk_assessment: { type: 'string' },
                        key_battles: { type: 'array', items: { type: 'string' } },
                        predicted_outcome: { type: 'string' }
                    }
                }
            });

            setRecommendations(data);
            toast.success('Analysis complete', { id: 'analysis' });
        } catch (error) {
            console.error('Analysis error:', error);
            toast.error('Analysis failed', { id: 'analysis' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 'High': return 'red';
            case 'Medium': return 'amber';
            case 'Low': return 'cyan';
            default: return 'slate';
        }
    };

    const getRiskColor = (risk) => {
        switch(risk) {
            case 'High': return 'red';
            case 'Medium': return 'amber';
            case 'Low': return 'emerald';
            default: return 'slate';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    AI Tactical Advisor
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                    <p className="text-cyan-300 text-sm">
                        Get AI-powered tactical recommendations based on opponent analysis and current player form.
                    </p>
                </div>

                <div className="flex gap-3">
                    <Input
                        placeholder="Enter opponent name (e.g., Manchester United)"
                        value={opponentName}
                        onChange={(e) => setOpponentName(e.target.value)}
                        className="bg-slate-800 border-slate-700 text-white"
                        onKeyPress={(e) => e.key === 'Enter' && generateRecommendations()}
                    />
                    <Button
                        onClick={generateRecommendations}
                        disabled={isAnalyzing}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Analyze
                            </>
                        )}
                    </Button>
                </div>

                {recommendations && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4 text-cyan-400" />
                                Opponent Analysis
                            </h4>
                            <p className="text-slate-300 text-sm">{recommendations.opponent_analysis}</p>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-2">Formation Recommendation</h4>
                            <p className="text-slate-300 text-sm">{recommendations.formation_recommendation}</p>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <div className="flex justify-between items-center mb-3">
                                <h4 className="text-white font-semibold">Tactical Adjustments</h4>
                                <Badge className={`bg-${getRiskColor(recommendations.risk_assessment)}-500/20 text-${getRiskColor(recommendations.risk_assessment)}-400`}>
                                    {recommendations.risk_assessment} Risk
                                </Badge>
                            </div>
                            <div className="space-y-3">
                                {recommendations.tactical_adjustments?.map((adj, i) => (
                                    <div key={i} className="p-3 bg-slate-900/50 rounded border border-slate-700">
                                        <div className="flex items-start gap-3">
                                            <Badge className={`bg-${getPriorityColor(adj.priority)}-500/20 text-${getPriorityColor(adj.priority)}-400 border-${getPriorityColor(adj.priority)}-500/30`}>
                                                {adj.priority}
                                            </Badge>
                                            <div className="flex-1">
                                                <p className="text-white font-medium text-sm mb-1">{adj.adjustment}</p>
                                                <p className="text-slate-400 text-xs">{adj.reason}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                            <h4 className="text-white font-semibold mb-3">Player Instructions</h4>
                            <div className="grid md:grid-cols-2 gap-3">
                                {recommendations.player_instructions?.map((inst, i) => (
                                    <div key={i} className="p-3 bg-slate-900/50 rounded border border-slate-700">
                                        <p className="text-cyan-400 font-medium text-sm mb-1">{inst.player_role}</p>
                                        <p className="text-slate-300 text-xs">{inst.instruction}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                                <h4 className="text-white font-semibold mb-2">Key Battles</h4>
                                <ul className="space-y-1">
                                    {recommendations.key_battles?.map((battle, i) => (
                                        <li key={i} className="text-slate-300 text-sm flex items-center gap-2">
                                            <CheckCircle className="w-3 h-3 text-cyan-400" />
                                            {battle}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="p-4 bg-emerald-500/10 rounded-lg border border-emerald-500/30">
                                <h4 className="text-emerald-400 font-semibold mb-2">Predicted Outcome</h4>
                                <p className="text-slate-300 text-sm">{recommendations.predicted_outcome}</p>
                            </div>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}