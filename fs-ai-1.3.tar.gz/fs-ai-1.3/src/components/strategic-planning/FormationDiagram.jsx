import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users } from 'lucide-react';

// Formation position data
const FORMATIONS = {
    '4-3-3': {
        name: '4-3-3',
        description: 'Attacking formation with width and creative freedom',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 20, y: 70, role: 'LB' },
            { x: 40, y: 72, role: 'CB' },
            { x: 60, y: 72, role: 'CB' },
            { x: 80, y: 70, role: 'RB' },
            { x: 30, y: 50, role: 'CM' },
            { x: 50, y: 45, role: 'CM' },
            { x: 70, y: 50, role: 'CM' },
            { x: 20, y: 25, role: 'LW' },
            { x: 50, y: 20, role: 'ST' },
            { x: 80, y: 25, role: 'RW' }
        ]
    },
    '4-2-3-1': {
        name: '4-2-3-1',
        description: 'Balanced formation with defensive stability and attacking options',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 20, y: 70, role: 'LB' },
            { x: 40, y: 72, role: 'CB' },
            { x: 60, y: 72, role: 'CB' },
            { x: 80, y: 70, role: 'RB' },
            { x: 35, y: 55, role: 'DM' },
            { x: 65, y: 55, role: 'DM' },
            { x: 20, y: 35, role: 'LM' },
            { x: 50, y: 35, role: 'AM' },
            { x: 80, y: 35, role: 'RM' },
            { x: 50, y: 15, role: 'ST' }
        ]
    },
    '3-5-2': {
        name: '3-5-2',
        description: 'Wing-back focused with strong midfield control',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 30, y: 72, role: 'CB' },
            { x: 50, y: 75, role: 'CB' },
            { x: 70, y: 72, role: 'CB' },
            { x: 15, y: 50, role: 'LWB' },
            { x: 35, y: 55, role: 'CM' },
            { x: 50, y: 50, role: 'CM' },
            { x: 65, y: 55, role: 'CM' },
            { x: 85, y: 50, role: 'RWB' },
            { x: 40, y: 22, role: 'ST' },
            { x: 60, y: 22, role: 'ST' }
        ]
    },
    '4-4-2': {
        name: '4-4-2',
        description: 'Classic balanced formation with dual strikers',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 20, y: 70, role: 'LB' },
            { x: 40, y: 72, role: 'CB' },
            { x: 60, y: 72, role: 'CB' },
            { x: 80, y: 70, role: 'RB' },
            { x: 20, y: 45, role: 'LM' },
            { x: 40, y: 50, role: 'CM' },
            { x: 60, y: 50, role: 'CM' },
            { x: 80, y: 45, role: 'RM' },
            { x: 40, y: 22, role: 'ST' },
            { x: 60, y: 22, role: 'ST' }
        ]
    },
    '3-4-3': {
        name: '3-4-3',
        description: 'Ultra-attacking with three forwards and wing-backs',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 30, y: 72, role: 'CB' },
            { x: 50, y: 75, role: 'CB' },
            { x: 70, y: 72, role: 'CB' },
            { x: 15, y: 50, role: 'LWB' },
            { x: 40, y: 52, role: 'CM' },
            { x: 60, y: 52, role: 'CM' },
            { x: 85, y: 50, role: 'RWB' },
            { x: 25, y: 22, role: 'LW' },
            { x: 50, y: 18, role: 'ST' },
            { x: 75, y: 22, role: 'RW' }
        ]
    },
    '5-3-2': {
        name: '5-3-2',
        description: 'Defensive formation with three center-backs',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 15, y: 68, role: 'LWB' },
            { x: 35, y: 72, role: 'CB' },
            { x: 50, y: 75, role: 'CB' },
            { x: 65, y: 72, role: 'CB' },
            { x: 85, y: 68, role: 'RWB' },
            { x: 30, y: 48, role: 'CM' },
            { x: 50, y: 45, role: 'CM' },
            { x: 70, y: 48, role: 'CM' },
            { x: 40, y: 22, role: 'ST' },
            { x: 60, y: 22, role: 'ST' }
        ]
    },
    '4-1-4-1': {
        name: '4-1-4-1',
        description: 'Defensive midfield anchor with wide coverage',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 20, y: 70, role: 'LB' },
            { x: 40, y: 72, role: 'CB' },
            { x: 60, y: 72, role: 'CB' },
            { x: 80, y: 70, role: 'RB' },
            { x: 50, y: 58, role: 'DM' },
            { x: 20, y: 40, role: 'LM' },
            { x: 40, y: 42, role: 'CM' },
            { x: 60, y: 42, role: 'CM' },
            { x: 80, y: 40, role: 'RM' },
            { x: 50, y: 18, role: 'ST' }
        ]
    },
    '3-4-2-1': {
        name: '3-4-2-1',
        description: 'Christmas tree formation with dual playmakers',
        positions: [
            { x: 50, y: 90, role: 'GK' },
            { x: 30, y: 72, role: 'CB' },
            { x: 50, y: 75, role: 'CB' },
            { x: 70, y: 72, role: 'CB' },
            { x: 15, y: 50, role: 'LWB' },
            { x: 40, y: 55, role: 'CM' },
            { x: 60, y: 55, role: 'CM' },
            { x: 85, y: 50, role: 'RWB' },
            { x: 35, y: 32, role: 'AM' },
            { x: 65, y: 32, role: 'AM' },
            { x: 50, y: 15, role: 'ST' }
        ]
    }
};

export default function FormationDiagram({ formation = '4-3-3', showDetails = true }) {
    const formationData = FORMATIONS[formation] || FORMATIONS['4-3-3'];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                    <Users className="w-5 h-5 text-cyan-400" />
                    {formationData.name} Formation
                </CardTitle>
                {showDetails && (
                    <p className="text-slate-400 text-sm">{formationData.description}</p>
                )}
            </CardHeader>
            <CardContent>
                <div className="relative bg-gradient-to-b from-emerald-900/30 to-emerald-800/20 rounded-lg border border-emerald-500/20 aspect-[3/4] max-w-xs mx-auto overflow-hidden">
                    {/* Pitch markings */}
                    <div className="absolute inset-0">
                        {/* Center line */}
                        <div className="absolute top-1/2 left-0 right-0 h-px bg-white/20" />
                        {/* Center circle */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full border border-white/20" />
                        {/* Goal areas */}
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-8 border-b border-l border-r border-white/20" />
                        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-24 h-8 border-t border-l border-r border-white/20" />
                        {/* Penalty areas */}
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-16 border-b border-l border-r border-white/15" />
                        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-40 h-16 border-t border-l border-r border-white/15" />
                    </div>

                    {/* Player positions */}
                    {formationData.positions.map((pos, i) => (
                        <div
                            key={i}
                            className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
                            style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                        >
                            <div className={`
                                w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold
                                transition-all duration-200 group-hover:scale-110
                                ${pos.role === 'GK' 
                                    ? 'bg-amber-500 text-black' 
                                    : pos.y > 60 
                                        ? 'bg-cyan-500 text-white' 
                                        : pos.y > 40 
                                            ? 'bg-emerald-500 text-white'
                                            : 'bg-red-500 text-white'
                                }
                                shadow-lg
                            `}>
                                {pos.role}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Position legend */}
                <div className="flex justify-center gap-4 mt-4 text-xs">
                    <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded-full bg-amber-500" />
                        <span className="text-slate-400">GK</span>
                    </div>
                    <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded-full bg-cyan-500" />
                        <span className="text-slate-400">Defense</span>
                    </div>
                    <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded-full bg-emerald-500" />
                        <span className="text-slate-400">Midfield</span>
                    </div>
                    <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="text-slate-400">Attack</span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}