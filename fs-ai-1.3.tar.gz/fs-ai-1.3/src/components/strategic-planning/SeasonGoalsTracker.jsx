import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Target, Plus, TrendingUp, AlertCircle, CheckCircle, Edit2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function SeasonGoalsTracker() {
    const [isAdding, setIsAdding] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [formData, setFormData] = useState({
        season: '2024/25',
        goal_type: 'Points Total',
        target_value: 0,
        current_value: 0,
        priority: 'Medium',
        deadline: '',
        notes: ''
    });

    const queryClient = useQueryClient();

    const { data: goals = [] } = useQuery({
        queryKey: ['seasonGoals'],
        queryFn: () => base44.entities.SeasonGoal.list()
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.SeasonGoal.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['seasonGoals'] });
            toast.success('Goal created');
            setIsAdding(false);
            resetForm();
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.SeasonGoal.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['seasonGoals'] });
            toast.success('Goal updated');
            setEditingId(null);
        }
    });

    const resetForm = () => {
        setFormData({
            season: '2024/25',
            goal_type: 'Points Total',
            target_value: 0,
            current_value: 0,
            priority: 'Medium',
            deadline: '',
            notes: ''
        });
    };

    const getStatusColor = (status) => {
        switch(status) {
            case 'Achieved': return 'emerald';
            case 'On Track': return 'cyan';
            case 'At Risk': return 'amber';
            case 'Behind': return 'red';
            default: return 'slate';
        }
    };

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 'Critical': return 'red';
            case 'High': return 'amber';
            case 'Medium': return 'cyan';
            case 'Low': return 'slate';
            default: return 'slate';
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Season Goals Tracker
                    </CardTitle>
                    <Button onClick={() => setIsAdding(!isAdding)} className="bg-cyan-600 hover:bg-cyan-700">
                        <Plus className="w-4 h-4 mr-2" />
                        {isAdding ? 'Cancel' : 'Add Goal'}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-6">
                {isAdding && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-6 bg-slate-800/50 rounded-lg border border-slate-700"
                    >
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Season</label>
                                <Input
                                    value={formData.season}
                                    onChange={(e) => setFormData({...formData, season: e.target.value})}
                                    placeholder="2024/25"
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Goal Type</label>
                                <Select value={formData.goal_type} onValueChange={(v) => setFormData({...formData, goal_type: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {['League Position', 'Points Total', 'Goals Scored', 'Goals Conceded', 'Clean Sheets', 'Win Rate', 'Possession Average', 'Pass Accuracy', 'Trophy'].map(t => (
                                            <SelectItem key={t} value={t}>{t}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Target Value</label>
                                <Input
                                    type="number"
                                    value={formData.target_value}
                                    onChange={(e) => setFormData({...formData, target_value: parseFloat(e.target.value)})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Priority</label>
                                <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {['Critical', 'High', 'Medium', 'Low'].map(p => (
                                            <SelectItem key={p} value={p}>{p}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-slate-300 text-sm mb-2 block">Deadline</label>
                                <Input
                                    type="date"
                                    value={formData.deadline}
                                    onChange={(e) => setFormData({...formData, deadline: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                        </div>
                        <div className="flex justify-end mt-4">
                            <Button onClick={() => createMutation.mutate(formData)} className="bg-emerald-600 hover:bg-emerald-700">
                                <Save className="w-4 h-4 mr-2" />
                                Create Goal
                            </Button>
                        </div>
                    </motion.div>
                )}

                <div className="space-y-4">
                    {goals.map((goal, i) => {
                        const progress = Math.min((goal.current_value / goal.target_value) * 100, 100);
                        const statusColor = getStatusColor(goal.status);
                        const priorityColor = getPriorityColor(goal.priority);
                        const isEditing = editingId === goal.id;

                        return (
                            <motion.div
                                key={goal.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.05 }}
                                className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                            >
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <h4 className="text-white font-semibold mb-1">{goal.goal_type}</h4>
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <Badge className={`bg-${priorityColor}-500/20 text-${priorityColor}-400 border-${priorityColor}-500/30`}>
                                                {goal.priority}
                                            </Badge>
                                            <Badge className={`bg-${statusColor}-500/20 text-${statusColor}-400 border-${statusColor}-500/30`}>
                                                {goal.status || 'On Track'}
                                            </Badge>
                                            <span className="text-slate-400 text-sm">{goal.season}</span>
                                        </div>
                                    </div>
                                    <Button
                                        onClick={() => setEditingId(isEditing ? null : goal.id)}
                                        size="sm"
                                        variant="ghost"
                                        className="text-cyan-400"
                                    >
                                        <Edit2 className="w-4 h-4" />
                                    </Button>
                                </div>

                                {isEditing ? (
                                    <div className="grid grid-cols-2 gap-3 mb-3">
                                        <div>
                                            <label className="text-slate-400 text-xs mb-1 block">Current Value</label>
                                            <Input
                                                type="number"
                                                defaultValue={goal.current_value}
                                                onChange={(e) => {
                                                    const newValue = parseFloat(e.target.value);
                                                    updateMutation.mutate({
                                                        id: goal.id,
                                                        data: { current_value: newValue }
                                                    });
                                                }}
                                                className="bg-slate-800 border-slate-700 text-white"
                                            />
                                        </div>
                                        <div>
                                            <label className="text-slate-400 text-xs mb-1 block">Status</label>
                                            <Select
                                                defaultValue={goal.status}
                                                onValueChange={(v) => {
                                                    updateMutation.mutate({
                                                        id: goal.id,
                                                        data: { status: v }
                                                    });
                                                }}
                                            >
                                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {['On Track', 'At Risk', 'Behind', 'Achieved'].map(s => (
                                                        <SelectItem key={s} value={s}>{s}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-slate-400 text-sm">Progress</span>
                                            <span className="text-white font-semibold">
                                                {goal.current_value} / {goal.target_value}
                                            </span>
                                        </div>
                                        <Progress value={progress} className="h-2" />
                                        <p className="text-slate-400 text-xs mt-2">{progress.toFixed(1)}% complete</p>
                                    </>
                                )}
                            </motion.div>
                        );
                    })}
                </div>

                {goals.length === 0 && !isAdding && (
                    <div className="text-center py-12">
                        <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                        <p className="text-slate-400">No season goals set yet</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}