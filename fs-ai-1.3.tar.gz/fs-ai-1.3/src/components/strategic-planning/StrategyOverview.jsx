import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Target } from 'lucide-react';
import FormationDiagram from './FormationDiagram';
import TacticalTooltips from './TacticalTooltips';

export default function StrategyOverview() {
    const { data: strategies = [] } = useQuery({
        queryKey: ['strategies'],
        queryFn: () => base44.entities.TeamStrategy.list()
    });

    const activeStrategy = strategies.find(s => s.active);

    if (!activeStrategy) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-12 text-center">
                    <Target className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <h3 className="text-white text-xl font-semibold mb-2">No Active Strategy</h3>
                    <p className="text-slate-400">
                        Create and activate a team strategy in Tactical Setup to see the overview
                    </p>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            {/* Active Strategy Header */}
            <Card className="bg-gradient-to-r from-emerald-900/30 to-cyan-900/30 border-emerald-500/30">
                <CardContent className="py-6">
                    <div className="flex items-center justify-between flex-wrap gap-4">
                        <div>
                            <div className="flex items-center gap-3 mb-2">
                                <h2 className="text-2xl font-bold text-white">{activeStrategy.strategy_name}</h2>
                                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Active
                                </Badge>
                            </div>
                            <p className="text-slate-400">
                                {activeStrategy.formation} · {activeStrategy.playing_style} · {activeStrategy.pressing_intensity} Press
                            </p>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                            <Badge variant="outline" className="border-cyan-500/30 text-cyan-400">
                                {activeStrategy.tempo} Tempo
                            </Badge>
                            <Badge variant="outline" className="border-purple-500/30 text-purple-400">
                                {activeStrategy.width} Width
                            </Badge>
                            <Badge variant="outline" className="border-amber-500/30 text-amber-400">
                                {activeStrategy.passing_style} Passing
                            </Badge>
                        </div>
                    </div>
                    {activeStrategy.notes && (
                        <div className="mt-4 p-3 bg-slate-900/50 rounded-lg">
                            <p className="text-slate-300 text-sm italic">"{activeStrategy.notes}"</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Formation and Insights Grid */}
            <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                    <FormationDiagram formation={activeStrategy.formation} />
                </div>
                <div className="lg:col-span-2">
                    <TacticalTooltips strategy={activeStrategy} />
                </div>
            </div>

            {/* Other Saved Strategies */}
            {strategies.length > 1 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-lg">
                            Other Saved Strategies ({strategies.length - 1})
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                            {strategies.filter(s => !s.active).map(strategy => (
                                <div 
                                    key={strategy.id}
                                    className="p-3 bg-slate-800/50 rounded-lg border border-slate-700"
                                >
                                    <h4 className="text-white font-medium mb-2">{strategy.strategy_name}</h4>
                                    <div className="flex flex-wrap gap-1">
                                        <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                                            {strategy.formation}
                                        </Badge>
                                        <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                                            {strategy.playing_style}
                                        </Badge>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}