import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Save, Target, Edit2, Trash2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function TacticalConfiguration() {
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState({
        strategy_name: '',
        formation: '4-3-3',
        playing_style: 'Balanced',
        pressing_intensity: 'Medium',
        defensive_line: 'Medium',
        tempo: 'Medium',
        width: 'Balanced',
        passing_style: 'Mixed',
        notes: ''
    });

    const queryClient = useQueryClient();

    const { data: strategies = [] } = useQuery({
        queryKey: ['strategies'],
        queryFn: () => base44.entities.TeamStrategy.list()
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.TeamStrategy.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy saved');
            setIsEditing(false);
            setFormData({
                strategy_name: '',
                formation: '4-3-3',
                playing_style: 'Balanced',
                pressing_intensity: 'Medium',
                defensive_line: 'Medium',
                tempo: 'Medium',
                width: 'Balanced',
                passing_style: 'Mixed',
                notes: ''
            });
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.TeamStrategy.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy deleted');
        }
    });

    const setActiveMutation = useMutation({
        mutationFn: async (id) => {
            await Promise.all([
                ...strategies.map(s => base44.entities.TeamStrategy.update(s.id, { active: false })),
                base44.entities.TeamStrategy.update(id, { active: true })
            ]);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy activated');
        }
    });

    const activeStrategy = strategies.find(s => s.active);

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Tactical Configuration
                        </CardTitle>
                        <Button onClick={() => setIsEditing(!isEditing)} className="bg-cyan-600 hover:bg-cyan-700">
                            {isEditing ? 'Cancel' : 'Create Strategy'}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    {isEditing && (
                        <motion.div
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="p-6 bg-slate-800/50 rounded-lg border border-slate-700"
                        >
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Strategy Name</label>
                                    <Input
                                        value={formData.strategy_name}
                                        onChange={(e) => setFormData({...formData, strategy_name: e.target.value})}
                                        placeholder="e.g., Home High Press"
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Formation</label>
                                    <Select value={formData.formation} onValueChange={(v) => setFormData({...formData, formation: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['4-3-3', '4-2-3-1', '3-5-2', '4-4-2', '3-4-3', '5-3-2', '4-1-4-1', '3-4-2-1'].map(f => (
                                                <SelectItem key={f} value={f}>{f}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Playing Style</label>
                                    <Select value={formData.playing_style} onValueChange={(v) => setFormData({...formData, playing_style: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Possession', 'Counter-Attack', 'High Press', 'Direct', 'Balanced', 'Defensive'].map(s => (
                                                <SelectItem key={s} value={s}>{s}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Pressing Intensity</label>
                                    <Select value={formData.pressing_intensity} onValueChange={(v) => setFormData({...formData, pressing_intensity: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Very High', 'High', 'Medium', 'Low'].map(p => (
                                                <SelectItem key={p} value={p}>{p}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Defensive Line</label>
                                    <Select value={formData.defensive_line} onValueChange={(v) => setFormData({...formData, defensive_line: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Very High', 'High', 'Medium', 'Low'].map(d => (
                                                <SelectItem key={d} value={d}>{d}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Tempo</label>
                                    <Select value={formData.tempo} onValueChange={(v) => setFormData({...formData, tempo: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Very Fast', 'Fast', 'Medium', 'Slow'].map(t => (
                                                <SelectItem key={t} value={t}>{t}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Width</label>
                                    <Select value={formData.width} onValueChange={(v) => setFormData({...formData, width: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Very Wide', 'Wide', 'Balanced', 'Narrow'].map(w => (
                                                <SelectItem key={w} value={w}>{w}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <label className="text-slate-300 text-sm mb-2 block">Passing Style</label>
                                    <Select value={formData.passing_style} onValueChange={(v) => setFormData({...formData, passing_style: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {['Short', 'Mixed', 'Long'].map(p => (
                                                <SelectItem key={p} value={p}>{p}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="md:col-span-2">
                                    <label className="text-slate-300 text-sm mb-2 block">Tactical Notes</label>
                                    <Textarea
                                        value={formData.notes}
                                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                                        placeholder="Additional tactical instructions..."
                                        className="bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </div>
                            <div className="flex justify-end mt-4">
                                <Button onClick={() => createMutation.mutate(formData)} className="bg-emerald-600 hover:bg-emerald-700">
                                    <Save className="w-4 h-4 mr-2" />
                                    Save Strategy
                                </Button>
                            </div>
                        </motion.div>
                    )}

                    {activeStrategy && (
                        <div className="p-6 bg-emerald-500/10 rounded-lg border border-emerald-500/30">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <h3 className="text-white text-lg font-semibold">{activeStrategy.strategy_name}</h3>
                                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                            <CheckCircle className="w-3 h-3 mr-1" />
                                            Active
                                        </Badge>
                                    </div>
                                    <p className="text-slate-400 text-sm">Current tactical setup</p>
                                </div>
                            </div>
                            <div className="grid md:grid-cols-4 gap-3">
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Formation</p>
                                    <p className="text-white font-semibold">{activeStrategy.formation}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Playing Style</p>
                                    <p className="text-white font-semibold">{activeStrategy.playing_style}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Press Intensity</p>
                                    <p className="text-white font-semibold">{activeStrategy.pressing_intensity}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Tempo</p>
                                    <p className="text-white font-semibold">{activeStrategy.tempo}</p>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="space-y-3">
                        <h4 className="text-white font-semibold">Saved Strategies ({strategies.length})</h4>
                        {strategies.map((strategy, i) => (
                            <motion.div
                                key={strategy.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.05 }}
                                className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                            >
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <h5 className="text-white font-semibold mb-2">{strategy.strategy_name}</h5>
                                        <div className="flex flex-wrap gap-2">
                                            <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                {strategy.formation}
                                            </Badge>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                {strategy.playing_style}
                                            </Badge>
                                            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                                Press: {strategy.pressing_intensity}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {!strategy.active && (
                                            <Button
                                                onClick={() => setActiveMutation.mutate(strategy.id)}
                                                size="sm"
                                                className="bg-emerald-600 hover:bg-emerald-700"
                                            >
                                                Activate
                                            </Button>
                                        )}
                                        <Button
                                            onClick={() => deleteMutation.mutate(strategy.id)}
                                            size="sm"
                                            variant="ghost"
                                            className="text-red-400 hover:text-red-300"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}