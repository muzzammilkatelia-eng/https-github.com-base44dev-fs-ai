import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info, Target, Zap, Timer, ArrowLeftRight, ShieldCheck, ArrowUpDown } from 'lucide-react';

const TACTICAL_INFO = {
    playing_style: {
        icon: Target,
        title: 'Playing Style',
        options: {
            'Possession': {
                description: 'Dominate the ball, patient build-up, high pass completion required',
                strengths: ['Ball retention', 'Control tempo', 'Tire opponents'],
                weaknesses: ['Vulnerable to press', 'Can be predictable'],
                idealPlayers: ['Technical midfielders', 'Ball-playing defenders']
            },
            'Counter-Attack': {
                description: 'Quick transitions from defense to attack, exploit spaces',
                strengths: ['Deadly on break', 'Energy efficient', 'Exploit high lines'],
                weaknesses: ['Less possession', 'Relies on opposition mistakes'],
                idealPlayers: ['Pacy forwards', 'Strong defenders', 'Quick passers']
            },
            'High Press': {
                description: 'Aggressive pressing high up the pitch to win ball back quickly',
                strengths: ['Win ball in dangerous areas', 'Dominate territory', 'Psychological pressure'],
                weaknesses: ['High fitness demand', 'Space behind if beaten'],
                idealPlayers: ['High work-rate players', 'Athletic squad', 'Smart pressers']
            },
            'Direct': {
                description: 'Long balls and quick forward passes to bypass midfield',
                strengths: ['Quick attacks', 'Exploit aerial ability', 'Less complex'],
                weaknesses: ['Lower possession', 'Predictable patterns'],
                idealPlayers: ['Target men', 'Physical midfielders', 'Strong defenders']
            },
            'Balanced': {
                description: 'Adaptable approach mixing possession with direct play',
                strengths: ['Versatile', 'Harder to read', 'Adaptable to situations'],
                weaknesses: ['Jack of all trades', 'Requires smart players'],
                idealPlayers: ['Versatile players', 'Good decision makers']
            },
            'Defensive': {
                description: 'Solid defensive structure, minimize risks, hit on counter',
                strengths: ['Hard to break down', 'Preserve leads', 'Frustrate opponents'],
                weaknesses: ['Limited attacking output', 'Can invite pressure'],
                idealPlayers: ['Disciplined defenders', 'Clinical finishers']
            }
        }
    },
    pressing_intensity: {
        icon: Zap,
        title: 'Pressing Intensity',
        options: {
            'Very High': {
                description: 'Gegenpressing - immediate pressure after losing ball anywhere on pitch',
                fitness: '95%+ squad fitness required',
                energy: 'Extremely high energy expenditure',
                risk: 'High risk if press is beaten'
            },
            'High': {
                description: 'Active pressing in opposition half, triggered press in own half',
                fitness: '85%+ squad fitness required',
                energy: 'High energy expenditure',
                risk: 'Moderate risk if bypassed'
            },
            'Medium': {
                description: 'Balanced approach - press in certain zones, drop in others',
                fitness: '75%+ squad fitness required',
                energy: 'Moderate energy expenditure',
                risk: 'Lower risk, organized shape'
            },
            'Low': {
                description: 'Deep block, compact shape, only press when ball enters zone',
                fitness: '65%+ squad fitness required',
                energy: 'Low energy expenditure',
                risk: 'Minimal pressing risk'
            }
        }
    },
    tempo: {
        icon: Timer,
        title: 'Team Tempo',
        options: {
            'Very Fast': {
                description: 'Lightning quick passing and movement, first-time football',
                passSpeed: 'One-touch passing priority',
                decisionTime: '<1 second decision making',
                suitability: 'Best for athletic, technical squads'
            },
            'Fast': {
                description: 'Quick transitions and passing with occasional slowdowns',
                passSpeed: 'Two-touch maximum',
                decisionTime: '1-2 second decisions',
                suitability: 'Suits most modern squads'
            },
            'Medium': {
                description: 'Controlled tempo with freedom to speed up or slow down',
                passSpeed: 'Mixed passing rhythm',
                decisionTime: 'Time on ball allowed',
                suitability: 'Versatile, adaptable approach'
            },
            'Slow': {
                description: 'Patient build-up, hold ball, wait for perfect moment',
                passSpeed: 'Extended possession phases',
                decisionTime: 'Multiple touches allowed',
                suitability: 'Technical teams vs low blocks'
            }
        }
    },
    width: {
        icon: ArrowLeftRight,
        title: 'Team Width',
        options: {
            'Very Wide': {
                description: 'Maximum pitch coverage, stretch opposition to create gaps',
                spacing: 'Full-backs high and wide, wingers touchline',
                advantage: 'Creates 1v1 situations, space in middle',
                weakness: 'Transitions can be slow, vulnerable centrally'
            },
            'Wide': {
                description: 'Use width to create space but maintain connections',
                spacing: 'Wide players stay wide, compact center',
                advantage: 'Good crossing opportunities, stretch defense',
                weakness: 'Can be isolated wide'
            },
            'Balanced': {
                description: 'Flexible width depending on game situation',
                spacing: 'Width when attacking, compact when defending',
                advantage: 'Adaptable to any situation',
                weakness: 'Requires intelligent movement'
            },
            'Narrow': {
                description: 'Compact shape, overload central areas',
                spacing: 'Inverted wingers, underlapping full-backs',
                advantage: 'Numerical superiority centrally, quick combinations',
                weakness: 'Easier to defend, predictable attack angles'
            }
        }
    },
    defensive_line: {
        icon: ShieldCheck,
        title: 'Defensive Line Height',
        options: {
            'Very High': {
                description: 'Extremely high line to compress play into opposition half',
                offside: 'Aggressive offside trap',
                coverage: 'GK as sweeper-keeper essential',
                risk: 'Very vulnerable to through balls'
            },
            'High': {
                description: 'Push up to support press and reduce space for opposition',
                offside: 'Active offside line',
                coverage: 'GK comfortable off line',
                risk: 'Pace behind can hurt'
            },
            'Medium': {
                description: 'Balanced position offering protection and support',
                offside: 'Situational offside trap',
                coverage: 'Standard GK positioning',
                risk: 'Balanced risk profile'
            },
            'Low': {
                description: 'Deep block protecting the goal, absorb pressure',
                offside: 'Minimal offside attempts',
                coverage: 'GK stays on line',
                risk: 'Invites pressure but solid'
            }
        }
    },
    passing_style: {
        icon: ArrowUpDown,
        title: 'Passing Style',
        options: {
            'Short': {
                description: 'Build from the back with short, precise passes',
                ballMovement: 'Patient circulation',
                progression: 'Gradual through thirds',
                ideal: 'Technical players throughout'
            },
            'Mixed': {
                description: 'Variety of pass lengths based on situation',
                ballMovement: 'Adaptive to game state',
                progression: 'Both short and long options',
                ideal: 'Versatile passers'
            },
            'Long': {
                description: 'Direct balls forward to target players',
                ballMovement: 'Quick vertical progression',
                progression: 'Bypass midfield when possible',
                ideal: 'Target man, aerial presence'
            }
        }
    }
};

const TacticalOptionCard = ({ category, value }) => {
    const info = TACTICAL_INFO[category];
    const optionInfo = info?.options[value];
    const Icon = info?.icon || Info;

    if (!optionInfo) return null;

    return (
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
            <div className="flex items-center gap-2 mb-3">
                <Icon className="w-5 h-5 text-cyan-400" />
                <h4 className="text-white font-semibold">{info.title}</h4>
                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 ml-auto">
                    {value}
                </Badge>
            </div>
            <p className="text-slate-300 text-sm mb-3">{optionInfo.description}</p>
            
            <div className="space-y-2 text-xs">
                {optionInfo.strengths && (
                    <div>
                        <span className="text-emerald-400 font-medium">Strengths: </span>
                        <span className="text-slate-400">{optionInfo.strengths.join(', ')}</span>
                    </div>
                )}
                {optionInfo.weaknesses && (
                    <div>
                        <span className="text-red-400 font-medium">Weaknesses: </span>
                        <span className="text-slate-400">{optionInfo.weaknesses.join(', ')}</span>
                    </div>
                )}
                {optionInfo.idealPlayers && (
                    <div>
                        <span className="text-amber-400 font-medium">Ideal Players: </span>
                        <span className="text-slate-400">{optionInfo.idealPlayers.join(', ')}</span>
                    </div>
                )}
                {optionInfo.fitness && (
                    <div>
                        <span className="text-purple-400 font-medium">Fitness: </span>
                        <span className="text-slate-400">{optionInfo.fitness}</span>
                    </div>
                )}
                {optionInfo.risk && (
                    <div>
                        <span className="text-orange-400 font-medium">Risk: </span>
                        <span className="text-slate-400">{optionInfo.risk}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default function TacticalTooltips({ strategy }) {
    if (!strategy) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-8 text-center text-slate-500">
                    Select or create a strategy to see tactical insights
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Info className="w-5 h-5 text-cyan-400" />
                    Tactical Analysis: {strategy.strategy_name}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <TacticalOptionCard category="playing_style" value={strategy.playing_style} />
                    <TacticalOptionCard category="pressing_intensity" value={strategy.pressing_intensity} />
                    <TacticalOptionCard category="tempo" value={strategy.tempo} />
                    <TacticalOptionCard category="width" value={strategy.width} />
                    <TacticalOptionCard category="defensive_line" value={strategy.defensive_line} />
                    <TacticalOptionCard category="passing_style" value={strategy.passing_style} />
                </div>
            </CardContent>
        </Card>
    );
}

export { TACTICAL_INFO, TacticalOptionCard };