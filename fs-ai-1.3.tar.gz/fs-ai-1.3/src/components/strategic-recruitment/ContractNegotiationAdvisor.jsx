import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Loader2, FileText, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ContractNegotiationAdvisor() {
    const [formData, setFormData] = useState({
        playerName: '',
        currentClub: '',
        age: '',
        position: '',
        currentSalary: '',
        askingSalary: '',
        transferFee: '',
        contractLength: '',
        specialClauses: '',
        budget: ''
    });
    const [strategy, setStrategy] = useState(null);
    const [generating, setGenerating] = useState(false);

    const generateStrategy = async () => {
        if (!formData.playerName || !formData.transferFee || !formData.budget) {
            toast.error('Please fill in player name, transfer fee, and budget');
            return;
        }

        setGenerating(true);
        toast.loading('Generating negotiation strategy...', { id: 'strategy' });

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football transfer negotiation consultant. Create a comprehensive contract negotiation strategy:

NEGOTIATION PARAMETERS:
Player: ${formData.playerName}
Current Club: ${formData.currentClub || 'Unknown'}
Age: ${formData.age || 'Unknown'}
Position: ${formData.position || 'Unknown'}
Transfer Fee: €${formData.transferFee}M
Current Salary: ${formData.currentSalary ? `€${formData.currentSalary}k/week` : 'Unknown'}
Asking Salary: ${formData.askingSalary ? `€${formData.askingSalary}k/week` : 'Unknown'}
Desired Contract Length: ${formData.contractLength ? `${formData.contractLength} years` : 'Flexible'}
Special Clauses Requested: ${formData.specialClauses || 'None specified'}
Available Budget: €${formData.budget}M

Provide comprehensive negotiation strategy:

1. **Deal Assessment**: Overall feasibility (0-100)
2. **Negotiation Position**: Your leverage (Strong/Moderate/Weak)
3. **Opening Offer Strategy**: What to offer initially
4. **Salary Structure**: Base + bonuses recommendation
5. **Contract Terms**: Optimal length and clauses
6. **Negotiation Tactics**: Step-by-step approach
7. **Compromise Points**: Where to be flexible
8. **Red Lines**: Non-negotiables
9. **Risk Assessment**: Deal-breaker scenarios
10. **Alternative Structures**: Creative solutions
11. **Timeline Strategy**: When to push, when to wait
12. **Final Recommendation**: Go/No-go decision`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        deal_assessment: {
                            type: "object",
                            properties: {
                                feasibility_score: { type: "number" },
                                verdict: { type: "string" },
                                summary: { type: "string" }
                            }
                        },
                        negotiation_position: {
                            type: "object",
                            properties: {
                                leverage: { type: "string" },
                                strengths: { type: "array", items: { type: "string" } },
                                weaknesses: { type: "array", items: { type: "string" } }
                            }
                        },
                        opening_offer: {
                            type: "object",
                            properties: {
                                transfer_fee: { type: "number" },
                                base_salary: { type: "number" },
                                contract_years: { type: "number" },
                                rationale: { type: "string" }
                            }
                        },
                        salary_structure: {
                            type: "object",
                            properties: {
                                base_salary: { type: "number" },
                                performance_bonuses: { type: "array", items: { type: "object" } },
                                signing_bonus: { type: "number" },
                                total_package: { type: "number" }
                            }
                        },
                        contract_terms: {
                            type: "object",
                            properties: {
                                recommended_length: { type: "string" },
                                release_clause: { type: "object" },
                                sell_on_percentage: { type: "string" },
                                other_clauses: { type: "array", items: { type: "string" } }
                            }
                        },
                        negotiation_tactics: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    phase: { type: "string" },
                                    action: { type: "string" },
                                    objective: { type: "string" }
                                }
                            }
                        },
                        compromise_points: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    flexibility: { type: "string" },
                                    trade_off: { type: "string" }
                                }
                            }
                        },
                        red_lines: {
                            type: "array",
                            items: { type: "string" }
                        },
                        risk_assessment: {
                            type: "object",
                            properties: {
                                overall_risk: { type: "string" },
                                deal_breakers: { type: "array", items: { type: "string" } },
                                mitigation_strategies: { type: "array", items: { type: "string" } }
                            }
                        },
                        alternative_structures: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    structure: { type: "string" },
                                    benefits: { type: "string" }
                                }
                            }
                        },
                        timeline_strategy: {
                            type: "object",
                            properties: {
                                ideal_duration: { type: "string" },
                                key_milestones: { type: "array", items: { type: "string" } },
                                pressure_points: { type: "string" }
                            }
                        },
                        final_recommendation: {
                            type: "object",
                            properties: {
                                decision: { type: "string" },
                                confidence_level: { type: "string" },
                                summary: { type: "string" }
                            }
                        }
                    }
                }
            });

            setStrategy(response);
            toast.success('Negotiation strategy generated!', { id: 'strategy' });
        } catch (error) {
            console.error('Strategy generation failed:', error);
            toast.error('Failed to generate strategy', { id: 'strategy' });
        } finally {
            setGenerating(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-purple-400" />
                        Contract Negotiation Advisor
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label className="text-slate-400">Player Name</Label>
                            <Input
                                value={formData.playerName}
                                onChange={(e) => setFormData({...formData, playerName: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="e.g., Erling Haaland"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Current Club</Label>
                            <Input
                                value={formData.currentClub}
                                onChange={(e) => setFormData({...formData, currentClub: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="e.g., Manchester City"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Age</Label>
                            <Input
                                type="number"
                                value={formData.age}
                                onChange={(e) => setFormData({...formData, age: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="25"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Position</Label>
                            <Input
                                value={formData.position}
                                onChange={(e) => setFormData({...formData, position: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="Striker"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Transfer Fee (€M) *</Label>
                            <Input
                                type="number"
                                value={formData.transferFee}
                                onChange={(e) => setFormData({...formData, transferFee: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="100"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Your Budget (€M) *</Label>
                            <Input
                                type="number"
                                value={formData.budget}
                                onChange={(e) => setFormData({...formData, budget: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="150"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Current Salary (€k/week)</Label>
                            <Input
                                type="number"
                                value={formData.currentSalary}
                                onChange={(e) => setFormData({...formData, currentSalary: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="350"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Asking Salary (€k/week)</Label>
                            <Input
                                type="number"
                                value={formData.askingSalary}
                                onChange={(e) => setFormData({...formData, askingSalary: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="400"
                            />
                        </div>
                        <div>
                            <Label className="text-slate-400">Contract Length (years)</Label>
                            <Input
                                type="number"
                                value={formData.contractLength}
                                onChange={(e) => setFormData({...formData, contractLength: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="5"
                            />
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-400">Special Clauses Requested</Label>
                        <Textarea
                            value={formData.specialClauses}
                            onChange={(e) => setFormData({...formData, specialClauses: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., €150M release clause, 20% sell-on fee..."
                        />
                    </div>

                    <Button
                        onClick={generateStrategy}
                        disabled={generating}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {generating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Generating Strategy...
                            </>
                        ) : (
                            <>
                                <FileText className="w-4 h-4 mr-2" />
                                Generate Negotiation Strategy
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {strategy && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Deal Assessment */}
                    <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="text-center mb-4">
                                <p className="text-slate-400 text-sm mb-2">Deal Feasibility</p>
                                <div className="text-6xl font-bold text-purple-400 mb-2">
                                    {strategy.deal_assessment?.feasibility_score}/100
                                </div>
                                <Badge className={
                                    strategy.deal_assessment?.feasibility_score >= 70 ? 'bg-emerald-500/20 text-emerald-400' :
                                    strategy.deal_assessment?.feasibility_score >= 50 ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-red-500/20 text-red-400'
                                }>
                                    {strategy.deal_assessment?.verdict}
                                </Badge>
                            </div>
                            <p className="text-slate-300 text-center">{strategy.deal_assessment?.summary}</p>
                        </CardContent>
                    </Card>

                    {/* Negotiation Position */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                Your Negotiation Position
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {strategy.negotiation_position?.leverage}
                                </Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <p className="text-emerald-400 font-semibold mb-2">Strengths</p>
                                    <ul className="space-y-1">
                                        {strategy.negotiation_position?.strengths?.map((s, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                <span className="text-emerald-400">✓</span>
                                                <span>{s}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <p className="text-red-400 font-semibold mb-2">Weaknesses</p>
                                    <ul className="space-y-1">
                                        {strategy.negotiation_position?.weaknesses?.map((w, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                <span className="text-red-400">✗</span>
                                                <span>{w}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Opening Offer */}
                    <Card className="bg-cyan-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Opening Offer Strategy</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-3 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Transfer Fee</p>
                                    <p className="text-white text-xl font-bold">€{strategy.opening_offer?.transfer_fee}M</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Base Salary</p>
                                    <p className="text-white text-xl font-bold">€{strategy.opening_offer?.base_salary}k/w</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Contract</p>
                                    <p className="text-white text-xl font-bold">{strategy.opening_offer?.contract_years}y</p>
                                </div>
                            </div>
                            <p className="text-slate-300 text-sm">{strategy.opening_offer?.rationale}</p>
                        </CardContent>
                    </Card>

                    {/* Negotiation Tactics */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Negotiation Tactics (Step-by-Step)</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {strategy.negotiation_tactics?.map((tactic, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded p-4 border-l-4 border-purple-500">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Badge className="bg-purple-500/20 text-purple-400">{tactic.phase}</Badge>
                                        </div>
                                        <p className="text-white font-semibold mb-1">{tactic.action}</p>
                                        <p className="text-slate-400 text-sm">{tactic.objective}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Red Lines */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-red-400 flex items-center gap-2">
                                <AlertCircle className="w-5 h-5" />
                                Non-Negotiable Red Lines
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2">
                                {strategy.red_lines?.map((line, idx) => (
                                    <li key={idx} className="flex items-start gap-2 text-slate-300">
                                        <span className="text-red-400 font-bold">{idx + 1}.</span>
                                        <span>{line}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Final Recommendation */}
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                Final Recommendation
                                <Badge className={
                                    strategy.final_recommendation?.decision?.toLowerCase().includes('proceed') ? 'bg-emerald-500/20 text-emerald-400' :
                                    strategy.final_recommendation?.decision?.toLowerCase().includes('caution') ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-red-500/20 text-red-400'
                                }>
                                    {strategy.final_recommendation?.decision}
                                </Badge>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {strategy.final_recommendation?.confidence_level}
                                </Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{strategy.final_recommendation?.summary}</p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}