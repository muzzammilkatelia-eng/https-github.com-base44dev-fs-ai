import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Loader2, Users, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function DreamXIGenerator() {
    const [formation, setFormation] = useState('');
    const [budget, setBudget] = useState('');
    const [style, setStyle] = useState('');
    const [constraints, setConstraints] = useState('');
    const [dreamXI, setDreamXI] = useState(null);
    const [generating, setGenerating] = useState(false);

    const formations = ['4-3-3', '4-2-3-1', '3-5-2', '4-4-2', '3-4-3', '5-3-2'];

    const generateDreamXI = async () => {
        if (!formation || !budget) {
            toast.error('Please select formation and budget');
            return;
        }

        setGenerating(true);
        toast.loading('Building your dream XI...', { id: 'dream' });

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football squad builder. Create a dream XI lineup:

PARAMETERS:
Formation: ${formation}
Budget: €${budget}M total
Playing Style: ${style || 'Not specified'}
Constraints: ${constraints || 'None'}

Build the perfect starting XI:

1. **Formation Visualization**: Position-by-position layout
2. **Player Selection**: Best player for each position within budget
3. **Player Details**: Age, club, value, key strengths
4. **Budget Breakdown**: Cost per player
5. **Tactical Fit**: How the XI works together
6. **Squad Chemistry**: Player compatibility
7. **Strengths**: What this XI excels at
8. **Weaknesses**: Potential vulnerabilities
9. **Alternative Options**: Backup choices per position
10. **Overall Rating**: Team strength (0-100)`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        formation_layout: {
                            type: "object",
                            properties: {
                                goalkeeper: { type: "array", items: { type: "string" } },
                                defenders: { type: "array", items: { type: "string" } },
                                midfielders: { type: "array", items: { type: "string" } },
                                forwards: { type: "array", items: { type: "string" } }
                            }
                        },
                        starting_xi: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    club: { type: "string" },
                                    value: { type: "number" },
                                    key_strengths: { type: "array", items: { type: "string" } },
                                    rating: { type: "number" }
                                }
                            }
                        },
                        budget_breakdown: {
                            type: "object",
                            properties: {
                                total_spent: { type: "number" },
                                remaining_budget: { type: "number" },
                                most_expensive: { type: "string" },
                                bargains: { type: "array", items: { type: "string" } }
                            }
                        },
                        tactical_analysis: {
                            type: "object",
                            properties: {
                                playing_style: { type: "string" },
                                tactical_strengths: { type: "array", items: { type: "string" } },
                                system_fit: { type: "string" }
                            }
                        },
                        chemistry: {
                            type: "object",
                            properties: {
                                chemistry_score: { type: "number" },
                                key_partnerships: { type: "array", items: { type: "string" } },
                                leadership: { type: "string" }
                            }
                        },
                        strengths: { type: "array", items: { type: "string" } },
                        weaknesses: { type: "array", items: { type: "string" } },
                        alternative_options: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    alternatives: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        overall_rating: { type: "number" },
                        final_verdict: { type: "string" }
                    }
                }
            });

            setDreamXI(response);
            toast.success('Dream XI created!', { id: 'dream' });
        } catch (error) {
            console.error('Generation failed:', error);
            toast.error('Failed to generate Dream XI', { id: 'dream' });
        } finally {
            setGenerating(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-400" />
                        Dream XI Generator
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label className="text-slate-400">Formation</Label>
                            <Select value={formation} onValueChange={setFormation}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Select formation..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {formations.map(f => (
                                        <SelectItem key={f} value={f}>{f}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label className="text-slate-400">Total Budget (€M)</Label>
                            <Input
                                type="number"
                                value={budget}
                                onChange={(e) => setBudget(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="500"
                            />
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-400">Playing Style (Optional)</Label>
                        <Input
                            value={style}
                            onChange={(e) => setStyle(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Possession-based, Counter-attacking, High-pressing..."
                        />
                    </div>

                    <div>
                        <Label className="text-slate-400">Constraints (Optional)</Label>
                        <Textarea
                            value={constraints}
                            onChange={(e) => setConstraints(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Must include at least 3 players under 23, Premier League players only..."
                        />
                    </div>

                    <Button
                        onClick={generateDreamXI}
                        disabled={generating}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        {generating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Building Dream XI...
                            </>
                        ) : (
                            <>
                                <Users className="w-4 h-4 mr-2" />
                                Generate Dream XI
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {dreamXI && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Overall Rating */}
                    <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="text-center">
                                <p className="text-slate-400 text-sm mb-2">Squad Overall Rating</p>
                                <div className="text-6xl font-bold text-purple-400 mb-2">
                                    {dreamXI.overall_rating}/100
                                </div>
                                <Badge className="bg-purple-500/20 text-purple-400 text-lg">
                                    Dream XI {formation}
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Formation Pitch View */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Formation View</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="bg-gradient-to-b from-emerald-900/20 to-emerald-950/20 rounded-lg p-6 border-2 border-emerald-700/30 relative" style={{ minHeight: '500px' }}>
                                {/* Forwards */}
                                <div className="flex justify-center gap-4 mb-12">
                                    {dreamXI.formation_layout?.forwards?.map((player, idx) => (
                                        <div key={idx} className="bg-purple-600 text-white rounded-lg px-4 py-2 text-sm font-bold shadow-lg">
                                            {player}
                                        </div>
                                    ))}
                                </div>
                                {/* Midfielders */}
                                <div className="flex justify-center gap-4 mb-12">
                                    {dreamXI.formation_layout?.midfielders?.map((player, idx) => (
                                        <div key={idx} className="bg-cyan-600 text-white rounded-lg px-4 py-2 text-sm font-bold shadow-lg">
                                            {player}
                                        </div>
                                    ))}
                                </div>
                                {/* Defenders */}
                                <div className="flex justify-center gap-4 mb-12">
                                    {dreamXI.formation_layout?.defenders?.map((player, idx) => (
                                        <div key={idx} className="bg-amber-600 text-white rounded-lg px-4 py-2 text-sm font-bold shadow-lg">
                                            {player}
                                        </div>
                                    ))}
                                </div>
                                {/* Goalkeeper */}
                                <div className="flex justify-center">
                                    {dreamXI.formation_layout?.goalkeeper?.map((player, idx) => (
                                        <div key={idx} className="bg-red-600 text-white rounded-lg px-4 py-2 text-sm font-bold shadow-lg">
                                            {player}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Player Cards */}
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {dreamXI.starting_xi?.map((player, idx) => (
                            <Card key={idx} className="bg-slate-800/50 border-slate-700">
                                <CardContent className="pt-6">
                                    <div className="flex items-start justify-between mb-3">
                                        <div>
                                            <Badge className="bg-purple-500/20 text-purple-400 mb-2">
                                                {player.position}
                                            </Badge>
                                            <h3 className="text-white font-bold">{player.player_name}</h3>
                                            <p className="text-slate-400 text-sm">{player.club} • {player.age}y</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-emerald-400 font-bold">€{player.value}M</p>
                                            <Badge className="bg-cyan-500/20 text-cyan-400 mt-1">
                                                {player.rating}/10
                                            </Badge>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-xs mb-2">Key Strengths:</p>
                                        <div className="flex flex-wrap gap-1">
                                            {player.key_strengths?.map((strength, i) => (
                                                <Badge key={i} className="bg-slate-700 text-slate-300 text-xs">
                                                    {strength}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    {/* Budget Breakdown */}
                    <Card className="bg-emerald-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Budget Breakdown</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-3 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Total Spent</p>
                                    <p className="text-white text-xl font-bold">€{dreamXI.budget_breakdown?.total_spent}M</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Remaining</p>
                                    <p className="text-emerald-400 text-xl font-bold">€{dreamXI.budget_breakdown?.remaining_budget}M</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Most Expensive</p>
                                    <p className="text-white text-sm font-bold">{dreamXI.budget_breakdown?.most_expensive}</p>
                                </div>
                            </div>
                            {dreamXI.budget_breakdown?.bargains && dreamXI.budget_breakdown.bargains.length > 0 && (
                                <div>
                                    <p className="text-emerald-400 text-sm font-semibold mb-2">Best Value Signings:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {dreamXI.budget_breakdown.bargains.map((bargain, idx) => (
                                            <Badge key={idx} className="bg-emerald-500/20 text-emerald-400">
                                                {bargain}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Tactical Analysis */}
                    <Card className="bg-cyan-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Tactical Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">Playing Style</p>
                                    <p className="text-white font-semibold">{dreamXI.tactical_analysis?.playing_style}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Tactical Strengths</p>
                                    <div className="flex flex-wrap gap-2">
                                        {dreamXI.tactical_analysis?.tactical_strengths?.map((strength, idx) => (
                                            <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                                {strength}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">System Fit</p>
                                    <p className="text-slate-300 text-sm">{dreamXI.tactical_analysis?.system_fit}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Chemistry */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">Squad Chemistry</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="text-center mb-4">
                                    <p className="text-slate-400 text-sm mb-2">Chemistry Score</p>
                                    <div className="text-4xl font-bold text-purple-400">
                                        {dreamXI.chemistry?.chemistry_score}/100
                                    </div>
                                </div>
                                <div>
                                    <p className="text-purple-400 text-sm font-semibold mb-2">Key Partnerships</p>
                                    <ul className="space-y-1">
                                        {dreamXI.chemistry?.key_partnerships?.map((partnership, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <TrendingUp className="w-4 h-4 text-purple-400 mt-0.5" />
                                                <span>{partnership}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">Leadership</p>
                                    <p className="text-slate-300 text-sm">{dreamXI.chemistry?.leadership}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Strengths & Weaknesses */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-emerald-400">Squad Strengths</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {dreamXI.strengths?.map((strength, idx) => (
                                        <li key={idx} className="flex items-start gap-2 text-slate-300">
                                            <span className="text-emerald-400 font-bold">✓</span>
                                            <span>{strength}</span>
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>

                        <Card className="bg-amber-500/10 border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="text-amber-400">Potential Weaknesses</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {dreamXI.weaknesses?.map((weakness, idx) => (
                                        <li key={idx} className="flex items-start gap-2 text-slate-300">
                                            <span className="text-amber-400">⚠</span>
                                            <span>{weakness}</span>
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Final Verdict */}
                    <Card className="bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-white">Final Assessment</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{dreamXI.final_verdict}</p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}