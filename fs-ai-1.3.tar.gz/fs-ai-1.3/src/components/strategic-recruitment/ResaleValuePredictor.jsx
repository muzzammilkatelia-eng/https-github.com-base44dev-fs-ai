import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import toast from 'react-hot-toast';

export default function ResaleValuePredictor() {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [prediction, setPrediction] = useState(null);
    const [predicting, setPredicting] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const predictResaleValue = async () => {
        if (!selectedPlayer) {
            toast.error('Please select a player');
            return;
        }

        const player = players.find(p => p.id === selectedPlayer);
        if (!player) return;

        setPredicting(true);
        toast.loading('Predicting resale value...', { id: 'predict' });

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football investment analyst. Predict the resale value trajectory for this player:

PLAYER: ${player.name}
Current Age: ${player.age}
Position: ${player.position}
Current Club: ${player.current_club} (${player.league})
Current Market Value: €${player.market_value || 'N/A'}M
Contract Expiry: ${player.contract_expiry || 'N/A'}
FS-AI Score: ${player.fsai_proprietary_score || 'N/A'}
Investment Grade: ${player.fsai_investment_grade || 'N/A'}

Career Stats (Recent): ${player.career_history?.slice(-3).map(s => `${s.season}: ${s.appearances}apps, ${s.goals}G, ${s.assists}A`).join('; ')}

Provide comprehensive resale value analysis:

1. **Current Investment Score**: Rate investment potential (0-100)
2. **5-Year Value Projection**: Predict market value over next 5 years
3. **Peak Resale Window**: When is the optimal time to sell?
4. **ROI Potential**: Expected return on investment (%)
5. **Value Drivers**: What factors will increase value?
6. **Risk Factors**: What could decrease value?
7. **Market Demand Forecast**: Expected buyer interest
8. **Comparable Sales**: Similar players' transfer trajectories
9. **Exit Strategy**: Recommended selling approach
10. **Investment Verdict**: Buy, hold, or avoid?`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        investment_score: { type: "number" },
                        investment_grade: { type: "string" },
                        value_projection: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    year: { type: "number" },
                                    age: { type: "number" },
                                    projected_value: { type: "number" },
                                    confidence: { type: "string" }
                                }
                            }
                        },
                        peak_resale_window: {
                            type: "object",
                            properties: {
                                optimal_age: { type: "number" },
                                optimal_year: { type: "string" },
                                peak_value: { type: "number" },
                                reasoning: { type: "string" }
                            }
                        },
                        roi_potential: {
                            type: "object",
                            properties: {
                                percentage: { type: "number" },
                                category: { type: "string" },
                                timeframe: { type: "string" }
                            }
                        },
                        value_drivers: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    driver: { type: "string" },
                                    impact: { type: "string" },
                                    likelihood: { type: "string" }
                                }
                            }
                        },
                        risk_factors: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    risk: { type: "string" },
                                    severity: { type: "string" },
                                    mitigation: { type: "string" }
                                }
                            }
                        },
                        demand_forecast: {
                            type: "object",
                            properties: {
                                current_demand: { type: "string" },
                                future_demand: { type: "string" },
                                target_clubs: { type: "array", items: { type: "string" } }
                            }
                        },
                        comparable_sales: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player: { type: "string" },
                                    transfer_value: { type: "number" },
                                    lessons: { type: "string" }
                                }
                            }
                        },
                        exit_strategy: {
                            type: "object",
                            properties: {
                                approach: { type: "string" },
                                target_market: { type: "string" },
                                negotiation_tips: { type: "array", items: { type: "string" } }
                            }
                        },
                        investment_verdict: {
                            type: "object",
                            properties: {
                                recommendation: { type: "string" },
                                summary: { type: "string" }
                            }
                        }
                    }
                }
            });

            setPrediction({ ...response, player });
            toast.success('Resale prediction complete!', { id: 'predict' });
        } catch (error) {
            console.error('Prediction failed:', error);
            toast.error('Failed to predict resale value', { id: 'predict' });
        } finally {
            setPredicting(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-emerald-400" />
                        Resale Value Predictor
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <label className="text-slate-400 text-sm mb-2 block">Select Player</label>
                        <Select value={selectedPlayer || ''} onValueChange={setSelectedPlayer}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue placeholder="Choose a player..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.slice(0, 200).map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                        {p.name} - {p.position} ({p.age}y) - €{p.market_value || '?'}M
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <Button
                        onClick={predictResaleValue}
                        disabled={predicting}
                        className="w-full bg-gradient-to-r from-emerald-500 to-green-600"
                    >
                        {predicting ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Predicting...
                            </>
                        ) : (
                            <>
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Predict Resale Value
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {prediction && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Investment Score */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="text-center">
                                <p className="text-slate-400 text-sm mb-2">Investment Score</p>
                                <div className="text-6xl font-bold text-emerald-400 mb-2">
                                    {prediction.investment_score}
                                </div>
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-lg">
                                    {prediction.investment_grade}
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Value Projection Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">5-Year Value Projection</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <AreaChart data={prediction.value_projection}>
                                    <XAxis dataKey="year" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" label={{ value: '€ Millions', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                                    <Area type="monotone" dataKey="projected_value" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Peak Resale Window */}
                    <Card className="bg-amber-500/10 border-amber-500/30">
                        <CardHeader>
                            <CardTitle className="text-amber-400">Peak Resale Window</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Optimal Age</p>
                                    <p className="text-white text-2xl font-bold">{prediction.peak_resale_window?.optimal_age}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Optimal Year</p>
                                    <p className="text-white text-xl font-bold">{prediction.peak_resale_window?.optimal_year}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3 text-center">
                                    <p className="text-slate-400 text-xs mb-1">Peak Value</p>
                                    <p className="text-emerald-400 text-2xl font-bold">€{prediction.peak_resale_window?.peak_value}M</p>
                                </div>
                            </div>
                            <p className="text-slate-300">{prediction.peak_resale_window?.reasoning}</p>
                        </CardContent>
                    </Card>

                    {/* ROI Potential */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">ROI Potential</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Expected Return</p>
                                    <p className="text-purple-400 text-4xl font-bold">+{prediction.roi_potential?.percentage}%</p>
                                    <p className="text-slate-400 text-sm mt-1">{prediction.roi_potential?.timeframe}</p>
                                </div>
                                <Badge className="bg-purple-500/20 text-purple-400 text-lg">
                                    {prediction.roi_potential?.category}
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Value Drivers & Risks */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-emerald-400">Value Drivers</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {prediction.value_drivers?.map((driver, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded p-3">
                                            <div className="flex items-center justify-between mb-1">
                                                <h5 className="text-white font-semibold text-sm">{driver.driver}</h5>
                                                <div className="flex gap-2">
                                                    <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">{driver.impact}</Badge>
                                                    <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">{driver.likelihood}</Badge>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-red-500/10 border-red-500/30">
                            <CardHeader>
                                <CardTitle className="text-red-400">Risk Factors</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {prediction.risk_factors?.map((risk, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded p-3">
                                            <div className="flex items-center justify-between mb-2">
                                                <h5 className="text-white font-semibold text-sm">{risk.risk}</h5>
                                                <Badge className={
                                                    risk.severity?.toLowerCase().includes('high') ? 'bg-red-500/20 text-red-400' :
                                                    'bg-amber-500/20 text-amber-400'
                                                }>
                                                    {risk.severity}
                                                </Badge>
                                            </div>
                                            <p className="text-cyan-400 text-xs">Mitigation: {risk.mitigation}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Demand Forecast */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Market Demand Forecast</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-4 mb-4">
                                <div className="bg-slate-800/50 rounded p-3">
                                    <p className="text-slate-400 text-xs mb-1">Current Demand</p>
                                    <p className="text-white font-semibold">{prediction.demand_forecast?.current_demand}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3">
                                    <p className="text-slate-400 text-xs mb-1">Future Demand</p>
                                    <p className="text-cyan-400 font-semibold">{prediction.demand_forecast?.future_demand}</p>
                                </div>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Potential Buyers:</p>
                                <div className="flex flex-wrap gap-2">
                                    {prediction.demand_forecast?.target_clubs?.map((club, idx) => (
                                        <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                            {club}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Exit Strategy */}
                    <Card className="bg-cyan-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Exit Strategy</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div>
                                    <p className="text-slate-400 text-sm">Approach</p>
                                    <p className="text-white font-semibold">{prediction.exit_strategy?.approach}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm">Target Market</p>
                                    <p className="text-white font-semibold">{prediction.exit_strategy?.target_market}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Negotiation Tips</p>
                                    <ul className="space-y-1">
                                        {prediction.exit_strategy?.negotiation_tips?.map((tip, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                                <span className="text-cyan-400">•</span>
                                                <span>{tip}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Investment Verdict */}
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-purple-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                Investment Verdict
                                <Badge className={
                                    prediction.investment_verdict?.recommendation?.toLowerCase().includes('buy') ? 'bg-emerald-500/20 text-emerald-400' :
                                    prediction.investment_verdict?.recommendation?.toLowerCase().includes('hold') ? 'bg-amber-500/20 text-amber-400' :
                                    'bg-red-500/20 text-red-400'
                                }>
                                    {prediction.investment_verdict?.recommendation}
                                </Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{prediction.investment_verdict?.summary}</p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}