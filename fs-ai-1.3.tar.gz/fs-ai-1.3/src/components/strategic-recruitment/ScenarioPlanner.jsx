import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, GitBranch, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ScenarioPlanner() {
    const [scenarioType, setScenarioType] = useState('');
    const [budget, setBudget] = useState('');
    const [objectives, setObjectives] = useState('');
    const [constraints, setConstraints] = useState('');
    const [plan, setPlan] = useState(null);
    const [planning, setPlanning] = useState(false);

    const generatePlan = async () => {
        if (!scenarioType || !budget || !objectives) {
            toast.error('Please fill in scenario type, budget, and objectives');
            return;
        }

        setPlanning(true);
        toast.loading('Creating strategic plan...', { id: 'plan' });

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football sporting director. Create a comprehensive recruitment scenario plan:

SCENARIO PARAMETERS:
Scenario Type: ${scenarioType}
Available Budget: €${budget}M
Objectives: ${objectives}
Constraints: ${constraints || 'None specified'}

Create a detailed strategic plan:

1. **Situation Analysis**: Current context assessment
2. **Priority Positions**: Positions to strengthen (ranked)
3. **Target Profiles**: Ideal player characteristics per position
4. **Transfer Targets**: Recommended players (3-5 per position)
5. **Budget Allocation**: How to split the budget
6. **Timeline**: Month-by-month execution plan
7. **Risk Mitigation**: Backup plans and alternatives
8. **Success Metrics**: KPIs to measure success
9. **Squad Impact**: Expected transformation
10. **Contingency Scenarios**: What-if planning`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        situation_analysis: {
                            type: "object",
                            properties: {
                                current_state: { type: "string" },
                                challenges: { type: "array", items: { type: "string" } },
                                opportunities: { type: "array", items: { type: "string" } }
                            }
                        },
                        priority_positions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    priority_level: { type: "string" },
                                    reasoning: { type: "string" },
                                    budget_allocation: { type: "number" }
                                }
                            }
                        },
                        target_profiles: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    age_range: { type: "string" },
                                    key_attributes: { type: "array", items: { type: "string" } },
                                    style: { type: "string" }
                                }
                            }
                        },
                        transfer_targets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    primary_target: { type: "string" },
                                    alternative_targets: { type: "array", items: { type: "string" } },
                                    estimated_cost: { type: "string" }
                                }
                            }
                        },
                        budget_allocation: {
                            type: "object",
                            properties: {
                                breakdown: { type: "array", items: { type: "object" } },
                                contingency_fund: { type: "number" },
                                flexibility: { type: "string" }
                            }
                        },
                        timeline: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    phase: { type: "string" },
                                    period: { type: "string" },
                                    actions: { type: "array", items: { type: "string" } },
                                    targets: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        risk_mitigation: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    risk: { type: "string" },
                                    probability: { type: "string" },
                                    backup_plan: { type: "string" }
                                }
                            }
                        },
                        success_metrics: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    metric: { type: "string" },
                                    target: { type: "string" },
                                    measurement: { type: "string" }
                                }
                            }
                        },
                        squad_impact: {
                            type: "object",
                            properties: {
                                predicted_improvement: { type: "string" },
                                new_strengths: { type: "array", items: { type: "string" } },
                                tactical_flexibility: { type: "string" }
                            }
                        },
                        contingency_scenarios: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    scenario: { type: "string" },
                                    response: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setPlan(response);
            toast.success('Strategic plan created!', { id: 'plan' });
        } catch (error) {
            console.error('Planning failed:', error);
            toast.error('Failed to create plan', { id: 'plan' });
        } finally {
            setPlanning(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <GitBranch className="w-5 h-5 text-cyan-400" />
                        Scenario Planner
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label className="text-slate-400">Scenario Type</Label>
                        <Input
                            value={scenarioType}
                            onChange={(e) => setScenarioType(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Complete Squad Overhaul, Summer Rebuild, Midseason Reinforcement..."
                        />
                    </div>

                    <div>
                        <Label className="text-slate-400">Available Budget (€M)</Label>
                        <Input
                            type="number"
                            value={budget}
                            onChange={(e) => setBudget(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="200"
                        />
                    </div>

                    <div>
                        <Label className="text-slate-400">Objectives & Goals</Label>
                        <Textarea
                            value={objectives}
                            onChange={(e) => setObjectives(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Build a title-winning squad, improve defense, add goal-scoring threat..."
                        />
                    </div>

                    <div>
                        <Label className="text-slate-400">Constraints (Optional)</Label>
                        <Textarea
                            value={constraints}
                            onChange={(e) => setConstraints(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., FFP restrictions, must sell before buying, academy promotion targets..."
                        />
                    </div>

                    <Button
                        onClick={generatePlan}
                        disabled={planning}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {planning ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Creating Plan...
                            </>
                        ) : (
                            <>
                                <GitBranch className="w-4 h-4 mr-2" />
                                Generate Strategic Plan
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {plan && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Situation Analysis */}
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Situation Analysis</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <p className="text-slate-400 text-sm mb-2">Current State</p>
                                <p className="text-slate-300">{plan.situation_analysis?.current_state}</p>
                            </div>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <p className="text-red-400 font-semibold mb-2">Challenges</p>
                                    <ul className="space-y-1">
                                        {plan.situation_analysis?.challenges?.map((c, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-red-400">•</span>
                                                <span>{c}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <p className="text-emerald-400 font-semibold mb-2">Opportunities</p>
                                    <ul className="space-y-1">
                                        {plan.situation_analysis?.opportunities?.map((o, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400">•</span>
                                                <span>{o}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Priority Positions */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Priority Positions (Ranked)</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {plan.priority_positions?.map((pos, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex items-center gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400 text-lg">
                                                    #{idx + 1}
                                                </Badge>
                                                <h4 className="text-white font-bold">{pos.position}</h4>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className={
                                                    pos.priority_level?.toLowerCase().includes('critical') ? 'bg-red-500/20 text-red-400' :
                                                    pos.priority_level?.toLowerCase().includes('high') ? 'bg-amber-500/20 text-amber-400' :
                                                    'bg-slate-500/20 text-slate-400'
                                                }>
                                                    {pos.priority_level}
                                                </Badge>
                                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                                    €{pos.budget_allocation}M
                                                </Badge>
                                            </div>
                                        </div>
                                        <p className="text-slate-300 text-sm">{pos.reasoning}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Transfer Targets */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400 flex items-center gap-2">
                                <Target className="w-5 h-5" />
                                Recommended Transfer Targets
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {plan.transfer_targets?.map((target, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-3">
                                            <h4 className="text-white font-bold">{target.position}</h4>
                                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                                {target.estimated_cost}
                                            </Badge>
                                        </div>
                                        <div className="space-y-2">
                                            <div>
                                                <p className="text-purple-400 text-xs font-semibold mb-1">Primary Target</p>
                                                <p className="text-white">{target.primary_target}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 text-xs font-semibold mb-1">Alternatives</p>
                                                <div className="flex flex-wrap gap-2">
                                                    {target.alternative_targets?.map((alt, i) => (
                                                        <Badge key={i} className="bg-slate-700 text-slate-300">
                                                            {alt}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Timeline */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Execution Timeline</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {plan.timeline?.map((phase, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-cyan-500">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Badge className="bg-cyan-500/20 text-cyan-400">{phase.phase}</Badge>
                                            <Badge className="bg-slate-700 text-slate-300">{phase.period}</Badge>
                                        </div>
                                        <div className="space-y-2">
                                            <div>
                                                <p className="text-slate-400 text-xs mb-1">Actions</p>
                                                <ul className="space-y-1">
                                                    {phase.actions?.map((action, i) => (
                                                        <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                            <span className="text-cyan-400">→</span>
                                                            <span>{action}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <p className="text-slate-400 text-xs mb-1">Target Players</p>
                                                <div className="flex flex-wrap gap-2">
                                                    {phase.targets?.map((t, i) => (
                                                        <Badge key={i} className="bg-purple-500/20 text-purple-400 text-xs">
                                                            {t}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Squad Impact */}
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Predicted Squad Impact</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">Expected Improvement</p>
                                    <p className="text-white font-semibold">{plan.squad_impact?.predicted_improvement}</p>
                                </div>
                                <div>
                                    <p className="text-emerald-400 text-sm font-semibold mb-2">New Strengths</p>
                                    <div className="flex flex-wrap gap-2">
                                        {plan.squad_impact?.new_strengths?.map((strength, idx) => (
                                            <Badge key={idx} className="bg-emerald-500/20 text-emerald-400">
                                                {strength}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-1">Tactical Flexibility</p>
                                    <p className="text-slate-300">{plan.squad_impact?.tactical_flexibility}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}