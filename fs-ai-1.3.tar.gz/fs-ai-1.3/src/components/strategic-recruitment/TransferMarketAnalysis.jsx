import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import toast from 'react-hot-toast';

export default function TransferMarketAnalysis() {
    const [position, setPosition] = useState('');
    const [league, setLeague] = useState('');
    const [budget, setBudget] = useState('');
    const [analysis, setAnalysis] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const positions = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];
    const leagues = ['Premier League', 'La Liga', 'Serie A', 'Bundesliga', 'Ligue 1', 'Eredivisie', 'Championship'];

    const analyzeMarket = async () => {
        if (!position || !budget) {
            toast.error('Please select position and budget');
            return;
        }

        setAnalyzing(true);
        toast.loading('Analyzing transfer market...', { id: 'analyze' });

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite transfer market analyst. Provide comprehensive market analysis for the following recruitment parameters:

RECRUITMENT PARAMETERS:
- Position: ${position}
- Target League: ${league || 'Any'}
- Available Budget: €${budget}M

Analyze current transfer market conditions and provide:

1. **Market Overview**: Current state of the market for this position
2. **Price Trends**: How prices are moving (up/down/stable) with percentage changes
3. **Hot Zones**: Leagues/regions with best value opportunities
4. **Emerging Markets**: Undervalued leagues to scout
5. **Market Timing**: Best time to buy (now vs summer/winter)
6. **Inflation Factors**: What's driving prices up/down
7. **Value Opportunities**: Where to find bargains
8. **Risk Areas**: Overpriced markets to avoid
9. **Competition Analysis**: How much competition for targets
10. **Strategic Recommendations**: 3-5 actionable insights

Include hypothetical data for:
- Price evolution chart (last 3 transfer windows)
- Market value distribution by league
- Supply vs demand metrics`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        market_overview: { type: "string" },
                        price_trends: {
                            type: "object",
                            properties: {
                                direction: { type: "string" },
                                percentage_change: { type: "number" },
                                explanation: { type: "string" }
                            }
                        },
                        hot_zones: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    region: { type: "string" },
                                    value_rating: { type: "number" },
                                    reason: { type: "string" }
                                }
                            }
                        },
                        emerging_markets: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    league: { type: "string" },
                                    opportunity_score: { type: "number" },
                                    description: { type: "string" }
                                }
                            }
                        },
                        market_timing: {
                            type: "object",
                            properties: {
                                recommendation: { type: "string" },
                                urgency: { type: "string" },
                                explanation: { type: "string" }
                            }
                        },
                        inflation_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        value_opportunities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    strategy: { type: "string" },
                                    potential_savings: { type: "string" }
                                }
                            }
                        },
                        risk_areas: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    risk_level: { type: "string" },
                                    warning: { type: "string" }
                                }
                            }
                        },
                        competition_analysis: {
                            type: "object",
                            properties: {
                                intensity: { type: "string" },
                                major_competitors: { type: "array", items: { type: "string" } },
                                strategy: { type: "string" }
                            }
                        },
                        price_evolution: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    window: { type: "string" },
                                    avg_price: { type: "number" }
                                }
                            }
                        },
                        league_distribution: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    league: { type: "string" },
                                    avg_value: { type: "number" },
                                    supply: { type: "number" }
                                }
                            }
                        },
                        strategic_recommendations: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Market analysis complete!', { id: 'analyze' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze market', { id: 'analyze' });
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-cyan-400" />
                        Transfer Market Analysis
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Position</label>
                            <Select value={position} onValueChange={setPosition}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Select position..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {positions.map(pos => (
                                        <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Target League (Optional)</label>
                            <Select value={league} onValueChange={setLeague}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Any league..." />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value={null}>Any League</SelectItem>
                                    {leagues.map(lg => (
                                        <SelectItem key={lg} value={lg}>{lg}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Available Budget (€M)</label>
                            <Select value={budget} onValueChange={setBudget}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue placeholder="Select budget..." />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="10">€10M</SelectItem>
                                    <SelectItem value="25">€25M</SelectItem>
                                    <SelectItem value="50">€50M</SelectItem>
                                    <SelectItem value="75">€75M</SelectItem>
                                    <SelectItem value="100">€100M</SelectItem>
                                    <SelectItem value="150">€150M+</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <Button
                        onClick={analyzeMarket}
                        disabled={analyzing}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {analyzing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Market...
                            </>
                        ) : (
                            <>
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Analyze Transfer Market
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {analysis && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Market Overview */}
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Market Overview</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-300 leading-relaxed">{analysis.market_overview}</p>
                        </CardContent>
                    </Card>

                    {/* Price Trends */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Price Trends</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-4 mb-4">
                                <Badge className={
                                    analysis.price_trends?.direction?.toLowerCase().includes('up') ? 'bg-red-500/20 text-red-400' :
                                    analysis.price_trends?.direction?.toLowerCase().includes('down') ? 'bg-emerald-500/20 text-emerald-400' :
                                    'bg-amber-500/20 text-amber-400'
                                }>
                                    {analysis.price_trends?.direction} ({analysis.price_trends?.percentage_change > 0 ? '+' : ''}{analysis.price_trends?.percentage_change}%)
                                </Badge>
                            </div>
                            <p className="text-slate-300 text-sm mb-4">{analysis.price_trends?.explanation}</p>
                            
                            {analysis.price_evolution && (
                                <ResponsiveContainer width="100%" height={200}>
                                    <LineChart data={analysis.price_evolution}>
                                        <XAxis dataKey="window" stroke="#94a3b8" />
                                        <YAxis stroke="#94a3b8" />
                                        <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                                        <Line type="monotone" dataKey="avg_price" stroke="#06b6d4" strokeWidth={2} />
                                    </LineChart>
                                </ResponsiveContainer>
                            )}
                        </CardContent>
                    </Card>

                    {/* Hot Zones & Emerging Markets */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Hot Zones</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.hot_zones?.map((zone, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex items-center justify-between mb-2">
                                                <h4 className="text-white font-semibold">{zone.region}</h4>
                                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                                    {zone.value_rating}/10
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{zone.reason}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Emerging Markets</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.emerging_markets?.map((market, idx) => (
                                        <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                            <div className="flex items-center justify-between mb-2">
                                                <h4 className="text-white font-semibold">{market.league}</h4>
                                                <Badge className="bg-purple-500/20 text-purple-400">
                                                    {market.opportunity_score}/10
                                                </Badge>
                                            </div>
                                            <p className="text-slate-400 text-sm">{market.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Market Timing */}
                    <Card className={`border ${
                        analysis.market_timing?.urgency?.toLowerCase().includes('high') ? 'bg-red-500/10 border-red-500/30' :
                        'bg-amber-500/10 border-amber-500/30'
                    }`}>
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5 text-amber-400" />
                                Market Timing
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-3 mb-3">
                                <Badge className="bg-amber-500/20 text-amber-400">
                                    {analysis.market_timing?.recommendation}
                                </Badge>
                                <Badge className={
                                    analysis.market_timing?.urgency?.toLowerCase().includes('high') ? 'bg-red-500/20 text-red-400' :
                                    'bg-cyan-500/20 text-cyan-400'
                                }>
                                    {analysis.market_timing?.urgency}
                                </Badge>
                            </div>
                            <p className="text-slate-300">{analysis.market_timing?.explanation}</p>
                        </CardContent>
                    </Card>

                    {/* League Distribution Chart */}
                    {analysis.league_distribution && (
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Market Value by League</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <BarChart data={analysis.league_distribution}>
                                        <XAxis dataKey="league" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
                                        <YAxis stroke="#94a3b8" />
                                        <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                                        <Legend />
                                        <Bar dataKey="avg_value" fill="#06b6d4" name="Avg Value (€M)" />
                                        <Bar dataKey="supply" fill="#10b981" name="Supply" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    )}

                    {/* Value Opportunities */}
                    <Card className="bg-emerald-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Value Opportunities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-2 gap-3">
                                {analysis.value_opportunities?.map((opp, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <h4 className="text-white font-semibold mb-1">{opp.strategy}</h4>
                                        <p className="text-emerald-400 text-sm">{opp.potential_savings}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Risk Areas */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardHeader>
                            <CardTitle className="text-red-400 flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5" />
                                Risk Areas
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {analysis.risk_areas?.map((risk, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4 className="text-white font-semibold">{risk.area}</h4>
                                            <Badge className={
                                                risk.risk_level?.toLowerCase().includes('high') ? 'bg-red-500/20 text-red-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }>
                                                {risk.risk_level}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-400 text-sm">{risk.warning}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Competition Analysis */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Competition Analysis</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="flex items-center gap-3">
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {analysis.competition_analysis?.intensity}
                                    </Badge>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Major Competitors:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {analysis.competition_analysis?.major_competitors?.map((comp, idx) => (
                                            <Badge key={idx} className="bg-slate-700 text-slate-300">
                                                {comp}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                                <div className="bg-slate-800/50 rounded p-3">
                                    <p className="text-slate-300 text-sm">{analysis.competition_analysis?.strategy}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Strategic Recommendations */}
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-purple-500/10 border-cyan-500/30">
                        <CardHeader>
                            <CardTitle className="text-cyan-400">Strategic Recommendations</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="space-y-2">
                                {analysis.strategic_recommendations?.map((rec, idx) => (
                                    <li key={idx} className="flex items-start gap-2 text-slate-300">
                                        <span className="text-cyan-400 font-bold">{idx + 1}.</span>
                                        <span>{rec}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}