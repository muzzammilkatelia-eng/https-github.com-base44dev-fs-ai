import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users } from 'lucide-react';
import { motion } from 'framer-motion';

export default function LineupRecommendation({ data }) {
    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <CardTitle className="text-white">Recommended Formation</CardTitle>
                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xl px-4 py-2">
                            {data.formation}
                        </Badge>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300">{data.reasoning}</p>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5 text-cyan-400" />
                        Starting XI
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {data.starting_xi?.map((player, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: idx * 0.05 }}
                                className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-cyan-500"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                        {player.position}
                                    </Badge>
                                </div>
                                <h4 className="text-white font-semibold mb-1">{player.role}</h4>
                                <p className="text-slate-400 text-sm">{player.instructions}</p>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}