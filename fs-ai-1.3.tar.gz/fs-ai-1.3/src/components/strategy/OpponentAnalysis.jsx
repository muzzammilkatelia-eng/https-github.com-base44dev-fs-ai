import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, AlertTriangle, Shield, Swords } from 'lucide-react';
import { motion } from 'framer-motion';

export default function OpponentAnalysis({ data, keyBattles }) {
    const getThreatColor = (level) => {
        const colors = {
            'High': 'bg-red-500/20 text-red-400 border-red-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
        };
        return colors[level] || colors['Medium'];
    };

    return (
        <div className="space-y-6">
            {/* Recent Form & Formation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-cyan-400" />
                            Recent Form
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300">{data.recent_form}</p>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-5 h-5 text-purple-400" />
                            Formation & Style
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-lg px-3 py-1">
                            {data.preferred_formation}
                        </Badge>
                        <p className="text-slate-300 text-sm mt-3">{data.tactical_tendencies}</p>
                    </CardContent>
                </Card>
            </div>

            {/* Key Players */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Key Threats</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {data.key_players?.map((player, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-slate-800/50 rounded-lg p-4"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h4 className="text-white font-semibold">{player.name}</h4>
                                        <p className="text-slate-400 text-sm">{player.position}</p>
                                    </div>
                                    <Badge className={getThreatColor(player.threat_level)}>
                                        {player.threat_level}
                                    </Badge>
                                </div>
                                <p className="text-slate-300 text-sm">{player.description}</p>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Strengths & Weaknesses */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-emerald-500/5 border-emerald-500/20">
                    <CardHeader>
                        <CardTitle className="text-emerald-400 flex items-center gap-2">
                            <Shield className="w-5 h-5" />
                            Strengths
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {data.strengths?.map((strength, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-slate-300">
                                    <span className="text-emerald-400 mt-1">•</span>
                                    <span>{strength}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>

                <Card className="bg-red-500/5 border-red-500/20">
                    <CardHeader>
                        <CardTitle className="text-red-400 flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5" />
                            Weaknesses
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {data.weaknesses?.map((weakness, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-slate-300">
                                    <span className="text-red-400 mt-1">•</span>
                                    <span>{weakness}</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            </div>

            {/* Key Battles */}
            {keyBattles && keyBattles.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Swords className="w-5 h-5 text-amber-400" />
                            Key Battles
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {keyBattles.map((battle, idx) => (
                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="text-white font-semibold">{battle.battle}</h4>
                                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                            {battle.importance}
                                        </Badge>
                                    </div>
                                    <p className="text-slate-300 text-sm">{battle.tactical_approach}</p>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}