import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Target, Flag, Send } from 'lucide-react';

export default function SetPieceStrategy({ data }) {
    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-cyan-400" />
                        Corners
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 whitespace-pre-line">{data.corners}</p>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Flag className="w-5 h-5 text-amber-400" />
                        Free Kicks
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 whitespace-pre-line">{data.free_kicks}</p>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Send className="w-5 h-5 text-emerald-400" />
                        Throw-Ins
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-slate-300 whitespace-pre-line">{data.throw_ins}</p>
                </CardContent>
            </Card>
        </div>
    );
}