import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, AlertCircle, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TacticalPlan({ recommendations }) {
    const getPriorityIcon = (priority) => {
        if (priority === 'High') return <AlertCircle className="w-4 h-4 text-red-400" />;
        if (priority === 'Medium') return <Zap className="w-4 h-4 text-amber-400" />;
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'High': 'bg-red-500/20 text-red-400 border-red-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Low': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
        };
        return colors[priority] || colors['Medium'];
    };

    const groupedRecommendations = recommendations?.reduce((acc, rec) => {
        if (!acc[rec.priority]) acc[rec.priority] = [];
        acc[rec.priority].push(rec);
        return acc;
    }, {});

    return (
        <div className="space-y-6">
            {['High', 'Medium', 'Low'].map((priority) => {
                const recs = groupedRecommendations?.[priority];
                if (!recs || recs.length === 0) return null;

                return (
                    <Card key={priority} className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center gap-2">
                                {getPriorityIcon(priority)}
                                {priority} Priority
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {recs.map((rec, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.1 }}
                                        className="bg-slate-800/50 rounded-lg p-4 border-l-4"
                                        style={{
                                            borderColor: priority === 'High' ? 'rgb(239 68 68)' :
                                                        priority === 'Medium' ? 'rgb(245 158 11)' :
                                                        'rgb(16 185 129)'
                                        }}
                                    >
                                        <div className="flex justify-between items-start mb-2">
                                            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                                {rec.category}
                                            </Badge>
                                            <Badge className={getPriorityColor(rec.priority)}>
                                                {rec.priority}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300">{rec.recommendation}</p>
                                    </motion.div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                );
            })}
        </div>
    );
}