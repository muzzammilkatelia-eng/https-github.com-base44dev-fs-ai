import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle2, AlertCircle, RefreshCw, FileSpreadsheet, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';

export default function GoogleSheetsSyncManager() {
    const [syncing, setSyncing] = useState(false);
    const [spreadsheetId, setSpreadsheetId] = useState('');
    const [lastSync, setLastSync] = useState(null);
    const [autoSync, setAutoSync] = useState(false);

    const syncPlayers = async (createNew = false) => {
        setSyncing(true);
        toast.loading('Syncing player database to Google Sheets...', { id: 'sync' });

        try {
            const { data: result } = await base44.functions.invoke('syncPlayersToSheets', {
                spreadsheet_id: createNew ? null : spreadsheetId
            });

            if (result.success) {
                setLastSync({
                    timestamp: new Date().toISOString(),
                    rows: result.rows_synced,
                    type: 'players'
                });
                
                if (result.spreadsheet_id && !spreadsheetId) {
                    setSpreadsheetId(result.spreadsheet_id);
                    localStorage.setItem('fsai_sheets_id', result.spreadsheet_id);
                }

                toast.success(`${result.rows_synced} players synced!`, { id: 'sync' });

                if (result.spreadsheet_url) {
                    window.open(result.spreadsheet_url, '_blank');
                }
            } else {
                toast.error(result.error || 'Sync failed', { id: 'sync' });
            }
        } catch (error) {
            console.error('Sync error:', error);
            toast.error('Failed to sync. Enable backend functions first.', { id: 'sync' });
        } finally {
            setSyncing(false);
        }
    };

    const syncReports = async () => {
        if (!spreadsheetId) {
            toast.error('Create player spreadsheet first');
            return;
        }

        setSyncing(true);
        toast.loading('Syncing scouting reports...', { id: 'sync' });

        try {
            const { data: result } = await base44.functions.invoke('syncScoutingReportsToSheets', {
                spreadsheet_id: spreadsheetId
            });

            if (result.success) {
                setLastSync({
                    timestamp: new Date().toISOString(),
                    rows: result.rows_synced,
                    type: 'reports'
                });
                toast.success(`${result.rows_synced} reports synced!`, { id: 'sync' });
            } else {
                toast.error(result.error || 'Sync failed', { id: 'sync' });
            }
        } catch (error) {
            console.error('Sync error:', error);
            toast.error('Failed to sync reports', { id: 'sync' });
        } finally {
            setSyncing(false);
        }
    };

    React.useEffect(() => {
        const savedId = localStorage.getItem('fsai_sheets_id');
        if (savedId) setSpreadsheetId(savedId);
    }, []);

    return (
        <div className="space-y-6">
            <Card className="bg-gradient-to-r from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                <CardHeader>
                    <CardTitle className="text-emerald-400 flex items-center gap-2">
                        <FileSpreadsheet className="w-5 h-5" />
                        Google Sheets Auto-Sync
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label className="text-slate-300">Spreadsheet ID (optional)</Label>
                        <div className="flex gap-2">
                            <Input
                                value={spreadsheetId}
                                onChange={(e) => setSpreadsheetId(e.target.value)}
                                placeholder="Leave empty to create new spreadsheet"
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            {spreadsheetId && (
                                <Button
                                    onClick={() => window.open(`https://docs.google.com/spreadsheets/d/${spreadsheetId}`, '_blank')}
                                    variant="outline"
                                    size="icon"
                                >
                                    <ExternalLink className="w-4 h-4" />
                                </Button>
                            )}
                        </div>
                        <p className="text-slate-500 text-xs mt-1">
                            Get ID from spreadsheet URL: docs.google.com/spreadsheets/d/<strong>SPREADSHEET_ID</strong>/edit
                        </p>
                    </div>

                    <div className="flex gap-3">
                        <Button
                            onClick={() => syncPlayers(false)}
                            disabled={syncing || !spreadsheetId}
                            className="bg-emerald-600 hover:bg-emerald-700"
                        >
                            {syncing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Syncing...
                                </>
                            ) : (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2" />
                                    Update Existing
                                </>
                            )}
                        </Button>

                        <Button
                            onClick={() => syncPlayers(true)}
                            disabled={syncing}
                            variant="outline"
                        >
                            Create New Spreadsheet
                        </Button>

                        {spreadsheetId && (
                            <Button
                                onClick={syncReports}
                                disabled={syncing}
                                className="bg-cyan-600 hover:bg-cyan-700"
                            >
                                Sync Reports Too
                            </Button>
                        )}
                    </div>

                    {lastSync && (
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                <span className="text-emerald-400 font-semibold">Last Sync</span>
                            </div>
                            <p className="text-slate-300 text-sm">
                                {lastSync.rows} {lastSync.type} synced
                            </p>
                            <p className="text-slate-500 text-xs">
                                {new Date(lastSync.timestamp).toLocaleString()}
                            </p>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card className="bg-amber-500/10 border-amber-500/30">
                <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                        <div>
                            <h4 className="text-amber-400 font-semibold mb-1">Setup Requirements</h4>
                            <ol className="text-slate-300 text-sm space-y-1 list-decimal list-inside">
                                <li>Enable backend functions in Dashboard → Settings</li>
                                <li>Authorize Google Sheets connector (OAuth)</li>
                                <li>Run "Create New Spreadsheet" or provide existing ID</li>
                                <li>Data syncs on-demand (click button to update)</li>
                            </ol>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white text-sm">What Gets Synced</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                            <Badge className="bg-emerald-500/20 text-emerald-400">Players Sheet</Badge>
                            <span className="text-slate-300">All player data with FS-AI scores</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <Badge className="bg-cyan-500/20 text-cyan-400">Reports Sheet</Badge>
                            <span className="text-slate-300">All scouting reports and ratings</span>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}