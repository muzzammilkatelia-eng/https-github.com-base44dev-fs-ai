import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Target, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function AIAcquisitionSuggestions() {
    const [suggestions, setSuggestions] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const analyzeSuggestions = async () => {
        setLoading(true);
        toast.loading('AI analyzing squad gaps...', { id: 'ai-suggest' });

        try {
            const positionCounts = players.reduce((acc, p) => {
                acc[p.position] = (acc[p.position] || 0) + 1;
                return acc;
            }, {});

            const avgAge = players.length > 0 
                ? players.reduce((sum, p) => sum + (p.age || 0), 0) / players.length 
                : 0;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite football recruitment AI. Analyze this squad and suggest 5 priority player acquisitions.

**Current Squad Analysis:**
- Total Players: ${players.length}
- Average Age: ${avgAge.toFixed(1)}
- Position Distribution: ${JSON.stringify(positionCounts, null, 2)}

**Squad Details:**
${players.map(p => `- ${p.name} (${p.age} yrs, ${p.position}, €${p.market_value}M, Rating: ${p.fsai_proprietary_score || 'N/A'})`).join('\n')}

Based on this squad, identify:
1. **Positional gaps** - which positions need reinforcement
2. **Age balance** - are there age groups that need attention
3. **Quality upgrades** - positions where better players are needed
4. **Tactical versatility** - missing player profiles

Generate exactly 5 player acquisition recommendations in this JSON format:
{
  "squad_analysis": {
    "key_gaps": ["list 3-4 main gaps"],
    "strengths": ["list 2-3 strengths"],
    "priority_areas": ["list priority positions"]
  },
  "recommendations": [
    {
      "priority": 1,
      "position": "position name",
      "profile": "detailed player archetype description",
      "reasoning": "why this is needed",
      "target_age": "age range",
      "budget_estimate": "in millions",
      "urgency": "Critical/High/Medium",
      "alternative_options": "brief alternatives"
    }
  ]
}`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        squad_analysis: {
                            type: "object",
                            properties: {
                                key_gaps: { type: "array", items: { type: "string" } },
                                strengths: { type: "array", items: { type: "string" } },
                                priority_areas: { type: "array", items: { type: "string" } }
                            }
                        },
                        recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    priority: { type: "number" },
                                    position: { type: "string" },
                                    profile: { type: "string" },
                                    reasoning: { type: "string" },
                                    target_age: { type: "string" },
                                    budget_estimate: { type: "string" },
                                    urgency: { type: "string" },
                                    alternative_options: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setSuggestions(result);
            toast.success('AI analysis complete', { id: 'ai-suggest' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'ai-suggest' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const urgencyColors = {
        Critical: 'bg-red-500/20 text-red-400 border-red-500/30',
        High: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        Medium: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-cyan-400" />
                        AI-Powered Acquisition Recommendations
                    </CardTitle>
                    <p className="text-slate-400 text-sm">
                        AI analyzes your squad to identify gaps and suggest priority signings
                    </p>
                </CardHeader>
                <CardContent>
                    <Button
                        onClick={analyzeSuggestions}
                        disabled={loading || players.length === 0}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Squad...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate AI Suggestions
                            </>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {suggestions && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Squad Analysis</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <h4 className="text-cyan-400 font-semibold mb-2">Key Gaps</h4>
                                <div className="flex flex-wrap gap-2">
                                    {suggestions.squad_analysis.key_gaps.map((gap, i) => (
                                        <Badge key={i} className="bg-red-500/20 text-red-400 border-red-500/30">
                                            {gap}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h4 className="text-emerald-400 font-semibold mb-2">Strengths</h4>
                                <div className="flex flex-wrap gap-2">
                                    {suggestions.squad_analysis.strengths.map((strength, i) => (
                                        <Badge key={i} className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                            {strength}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h4 className="text-amber-400 font-semibold mb-2">Priority Areas</h4>
                                <div className="flex flex-wrap gap-2">
                                    {suggestions.squad_analysis.priority_areas.map((area, i) => (
                                        <Badge key={i} className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                            {area}
                                        </Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <div className="space-y-4">
                        <h3 className="text-xl font-bold text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Top 5 Acquisition Recommendations
                        </h3>
                        {suggestions.recommendations.map((rec, i) => (
                            <motion.div
                                key={i}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                            >
                                <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                                                    <span className="text-cyan-400 font-bold">#{rec.priority}</span>
                                                </div>
                                                <div>
                                                    <h4 className="text-white font-semibold text-lg">{rec.position}</h4>
                                                    <p className="text-slate-400 text-sm">{rec.target_age}</p>
                                                </div>
                                            </div>
                                            <Badge className={urgencyColors[rec.urgency]}>
                                                {rec.urgency}
                                            </Badge>
                                        </div>

                                        <div className="space-y-3">
                                            <div>
                                                <h5 className="text-slate-400 text-sm mb-1">Player Profile</h5>
                                                <p className="text-white">{rec.profile}</p>
                                            </div>

                                            <div>
                                                <h5 className="text-slate-400 text-sm mb-1">Reasoning</h5>
                                                <p className="text-slate-300">{rec.reasoning}</p>
                                            </div>

                                            <div className="grid md:grid-cols-2 gap-4 pt-2 border-t border-slate-700">
                                                <div>
                                                    <span className="text-slate-400 text-sm">Budget Estimate:</span>
                                                    <span className="text-emerald-400 font-semibold ml-2">
                                                        €{rec.budget_estimate}M
                                                    </span>
                                                </div>
                                                <div>
                                                    <span className="text-slate-400 text-sm">Alternatives:</span>
                                                    <span className="text-white ml-2">{rec.alternative_options}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            )}
        </div>
    );
}