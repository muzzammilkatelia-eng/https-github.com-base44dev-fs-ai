import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

export default function PlayerFormDialog({ open, onClose, player }) {
    const [formData, setFormData] = useState({
        name: '',
        age: '',
        position: 'Central Midfielder',
        current_club: '',
        league: '',
        nationality: '',
        market_value: '',
        contract_expiry: '',
        injury_prone_score: '',
        notes: ''
    });

    const queryClient = useQueryClient();

    useEffect(() => {
        if (player) {
            setFormData({
                name: player.name || '',
                age: player.age || '',
                position: player.position || 'Central Midfielder',
                current_club: player.current_club || '',
                league: player.league || '',
                nationality: player.nationality || '',
                market_value: player.market_value || '',
                contract_expiry: player.contract_expiry || '',
                injury_prone_score: player.injury_prone_score || '',
                notes: player.notes || ''
            });
        } else {
            setFormData({
                name: '',
                age: '',
                position: 'Central Midfielder',
                current_club: '',
                league: '',
                nationality: '',
                market_value: '',
                contract_expiry: '',
                injury_prone_score: '',
                notes: ''
            });
        }
    }, [player, open]);

    const saveMutation = useMutation({
        mutationFn: async (data) => {
            if (player) {
                return base44.entities.Player.update(player.id, data);
            }
            return base44.entities.Player.create(data);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['players'] });
            toast.success(player ? 'Player updated' : 'Player created');
            onClose();
        },
        onError: (error) => {
            toast.error('Save failed: ' + error.message);
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        const submitData = {
            ...formData,
            age: formData.age ? parseInt(formData.age) : null,
            market_value: formData.market_value ? parseFloat(formData.market_value) : null,
            injury_prone_score: formData.injury_prone_score ? parseFloat(formData.injury_prone_score) : null
        };
        saveMutation.mutate(submitData);
    };

    const positions = [
        'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder',
        'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'
    ];

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>{player ? 'Edit Player' : 'Add New Player'}</DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <Label>Player Name *</Label>
                            <Input
                                required
                                value={formData.name}
                                onChange={(e) => setFormData({...formData, name: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Age</Label>
                            <Input
                                type="number"
                                value={formData.age}
                                onChange={(e) => setFormData({...formData, age: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Position *</Label>
                            <Select value={formData.position} onValueChange={(v) => setFormData({...formData, position: v})}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {positions.map(pos => (
                                        <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Current Club</Label>
                            <Input
                                value={formData.current_club}
                                onChange={(e) => setFormData({...formData, current_club: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>League</Label>
                            <Input
                                value={formData.league}
                                onChange={(e) => setFormData({...formData, league: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Nationality</Label>
                            <Input
                                value={formData.nationality}
                                onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Market Value (€M)</Label>
                            <Input
                                type="number"
                                step="0.1"
                                value={formData.market_value}
                                onChange={(e) => setFormData({...formData, market_value: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Contract Expiry</Label>
                            <Input
                                type="date"
                                value={formData.contract_expiry}
                                onChange={(e) => setFormData({...formData, contract_expiry: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <div>
                            <Label>Injury Risk Score (0-100)</Label>
                            <Input
                                type="number"
                                min="0"
                                max="100"
                                value={formData.injury_prone_score}
                                onChange={(e) => setFormData({...formData, injury_prone_score: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                    </div>

                    <div>
                        <Label>Notes</Label>
                        <Textarea
                            value={formData.notes}
                            onChange={(e) => setFormData({...formData, notes: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            rows={3}
                        />
                    </div>

                    <div className="flex justify-end gap-2">
                        <Button type="button" variant="outline" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={saveMutation.isPending} className="bg-cyan-600 hover:bg-cyan-700">
                            {saveMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Saving...
                                </>
                            ) : (
                                'Save Player'
                            )}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}