import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Edit2, Trash2, Filter, SortAsc, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import PlayerFormDialog from './PlayerFormDialog';

export default function PlayerManagementGrid() {
    const [searchTerm, setSearchTerm] = useState('');
    const [positionFilter, setPositionFilter] = useState('all');
    const [sortBy, setSortBy] = useState('name');
    const [showForm, setShowForm] = useState(false);
    const [editingPlayer, setEditingPlayer] = useState(null);

    const queryClient = useQueryClient();

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Player.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['players'] });
            toast.success('Player deleted');
        }
    });

    const filteredPlayers = players
        .filter(p => {
            const matchesSearch = p.name?.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesPosition = positionFilter === 'all' || p.position === positionFilter;
            return matchesSearch && matchesPosition;
        })
        .sort((a, b) => {
            if (sortBy === 'name') return (a.name || '').localeCompare(b.name || '');
            if (sortBy === 'age') return (a.age || 0) - (b.age || 0);
            if (sortBy === 'value') return (b.market_value || 0) - (a.market_value || 0);
            if (sortBy === 'rating') return (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0);
            return 0;
        });

    const positions = ['all', 'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <CardTitle className="text-white flex items-center gap-2">
                            <Search className="w-5 h-5 text-cyan-400" />
                            Player Database ({filteredPlayers.length})
                        </CardTitle>
                        <Button
                            onClick={() => {
                                setEditingPlayer(null);
                                setShowForm(true);
                            }}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            <Plus className="w-4 h-4 mr-2" />
                            Add Player
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-4 gap-4">
                        <div className="md:col-span-2">
                            <Input
                                placeholder="Search players..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <Select value={positionFilter} onValueChange={setPositionFilter}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <Filter className="w-4 h-4 mr-2" />
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {positions.map(pos => (
                                    <SelectItem key={pos} value={pos}>
                                        {pos === 'all' ? 'All Positions' : pos}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Select value={sortBy} onValueChange={setSortBy}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SortAsc className="w-4 h-4 mr-2" />
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="name">Name</SelectItem>
                                <SelectItem value="age">Age</SelectItem>
                                <SelectItem value="value">Market Value 🔒 Pro</SelectItem>
                                <SelectItem value="rating">FS-AI Rating 🔒 Pro</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {isLoading ? (
                        <div className="text-center py-12 text-slate-400">Loading players...</div>
                    ) : filteredPlayers.length === 0 ? (
                        <div className="text-center py-12 text-slate-400">No players found</div>
                    ) : (
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {filteredPlayers.map((player) => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="bg-slate-800/50 rounded-lg p-4 border border-slate-700 hover:border-cyan-500/50 transition-all"
                                >
                                    <div className="flex justify-between items-start mb-3">
                                        <div 
                                            className="cursor-pointer"
                                            onClick={() => window.location.href = `${window.location.origin}${window.location.pathname.split('/')[0]}/PlayerProfile?id=${player.id}`}
                                        >
                                            <h3 className="text-white font-semibold hover:text-cyan-400 transition-colors">{player.name}</h3>
                                            <p className="text-slate-400 text-sm">{player.current_club}</p>
                                        </div>
                                        <div className="flex gap-1">
                                            <Link to={createPageUrl('PlayerProfileDetail') + '?id=' + player.id}>
                                                <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    className="h-8 w-8 text-blue-400 hover:text-blue-300"
                                                >
                                                    <Eye className="w-4 h-4" />
                                                </Button>
                                            </Link>
                                            <Button
                                                size="icon"
                                                variant="ghost"
                                                onClick={() => {
                                                    setEditingPlayer(player);
                                                    setShowForm(true);
                                                }}
                                                className="h-8 w-8 text-cyan-400 hover:text-cyan-300"
                                            >
                                                <Edit2 className="w-4 h-4" />
                                            </Button>
                                            <Button
                                                size="icon"
                                                variant="ghost"
                                                onClick={() => deleteMutation.mutate(player.id)}
                                                className="h-8 w-8 text-red-400 hover:text-red-300"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                {player.position}
                                            </Badge>
                                            <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                {player.age} yrs
                                            </Badge>
                                            {player.fsai_proprietary_score && (
                                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                    ⭐ {player.fsai_proprietary_score.toFixed(1)}
                                                </Badge>
                                            )}
                                        </div>

                                        <div className="grid grid-cols-2 gap-2 text-sm">
                                            <div>
                                                <span className="text-slate-400">Value:</span>
                                                <span className="text-white ml-1">
                                                    €{player.market_value ? `${player.market_value}M` : 'N/A'}
                                                </span>
                                            </div>
                                            <div>
                                                <span className="text-slate-400">League:</span>
                                                <span className="text-white ml-1">{player.league || 'N/A'}</span>
                                            </div>
                                        </div>

                                        {player.injury_prone_score && (
                                            <div className="pt-2 border-t border-slate-700">
                                                <div className="flex items-center justify-between text-sm">
                                                    <span className="text-slate-400">Injury Risk:</span>
                                                    <Badge className={
                                                        player.injury_prone_score < 30 ? 'bg-green-500/20 text-green-400' :
                                                        player.injury_prone_score < 60 ? 'bg-amber-500/20 text-amber-400' :
                                                        'bg-red-500/20 text-red-400'
                                                    }>
                                                        {player.injury_prone_score < 30 ? 'Low' :
                                                         player.injury_prone_score < 60 ? 'Medium' : 'High'}
                                                    </Badge>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            <PlayerFormDialog
                open={showForm}
                onClose={() => {
                    setShowForm(false);
                    setEditingPlayer(null);
                }}
                player={editingPlayer}
            />
        </div>
    );
}