import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, TrendingUp, DollarSign, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TeamOverview() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const stats = {
        totalPlayers: players.length,
        avgAge: players.length > 0 ? (players.reduce((sum, p) => sum + (p.age || 0), 0) / players.length).toFixed(1) : 0,
        totalValue: players.reduce((sum, p) => sum + (p.market_value || 0), 0).toFixed(1),
        avgRating: players.filter(p => p.fsai_proprietary_score).length > 0 
            ? (players.filter(p => p.fsai_proprietary_score).reduce((sum, p) => sum + p.fsai_proprietary_score, 0) / 
               players.filter(p => p.fsai_proprietary_score).length).toFixed(1)
            : 'N/A'
    };

    const positionGroups = players.reduce((acc, player) => {
        const pos = player.position || 'Unknown';
        if (!acc[pos]) acc[pos] = [];
        acc[pos].push(player);
        return acc;
    }, {});

    const upcomingContracts = players
        .filter(p => p.contract_expiry)
        .sort((a, b) => new Date(a.contract_expiry) - new Date(b.contract_expiry))
        .slice(0, 5);

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-cyan-500/20 rounded-lg">
                                <Users className="w-6 h-6 text-cyan-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">{stats.totalPlayers}</p>
                                <p className="text-slate-400 text-sm">Total Players</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-purple-500/20 rounded-lg">
                                <Activity className="w-6 h-6 text-purple-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">{stats.avgAge}</p>
                                <p className="text-slate-400 text-sm">Avg Age</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-emerald-500/20 rounded-lg">
                                <DollarSign className="w-6 h-6 text-emerald-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">€{stats.totalValue}M</p>
                                <p className="text-slate-400 text-sm">Squad Value</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-amber-500/20 rounded-lg">
                                <TrendingUp className="w-6 h-6 text-amber-400" />
                            </div>
                            <div>
                                <p className="text-3xl font-bold text-white">{stats.avgRating}</p>
                                <p className="text-slate-400 text-sm">Avg Rating</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Squad by Position</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {Object.entries(positionGroups).map(([position, playerList]) => (
                                <motion.div
                                    key={position}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg"
                                >
                                    <div className="flex items-center gap-3">
                                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                            {position}
                                        </Badge>
                                        <span className="text-slate-300 text-sm">
                                            {playerList.map(p => p.name).join(', ')}
                                        </span>
                                    </div>
                                    <Badge variant="outline" className="border-slate-600 text-slate-300">
                                        {playerList.length}
                                    </Badge>
                                </motion.div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Contract Expiries</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {upcomingContracts.length === 0 ? (
                            <p className="text-slate-400 text-center py-8">No contract data available</p>
                        ) : (
                            <div className="space-y-3">
                                {upcomingContracts.map((player) => (
                                    <motion.div
                                        key={player.id}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg"
                                    >
                                        <div>
                                            <p className="text-white font-medium">{player.name}</p>
                                            <p className="text-slate-400 text-sm">{player.position}</p>
                                        </div>
                                        <Badge className={
                                            new Date(player.contract_expiry) < new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
                                                ? 'bg-red-500/20 text-red-400 border-red-500/30'
                                                : 'bg-green-500/20 text-green-400 border-green-500/30'
                                        }>
                                            {new Date(player.contract_expiry).toLocaleDateString()}
                                        </Badge>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}