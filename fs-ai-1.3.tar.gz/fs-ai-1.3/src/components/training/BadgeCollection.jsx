import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Award, Lock, Star, Trophy, Shield, Target, Brain } from 'lucide-react';

const allBadges = [
    { id: 'first_scenario', name: 'First Steps', icon: Star, description: 'Complete your first scenario' },
    { id: 'talent_spotter', name: 'Talent Spotter', icon: Target, description: 'Identify 10 players correctly' },
    { id: 'fa_ethics', name: 'FA Ethics & Compliance', icon: Shield, description: 'Pass ethics certification' },
    { id: 'master_scout', name: 'Master Scout', icon: Trophy, description: 'Achieve 90% accuracy' },
    { id: 'report_writer', name: 'Report Writer', icon: Brain, description: 'Complete 5 report simulations' },
    { id: 'perfect_score', name: 'Perfect Score', icon: Award, description: 'Get 100/100 on a scenario' }
];

export default function BadgeCollection() {
    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: progress } = useQuery({
        queryKey: ['trainingProgress', user?.email],
        queryFn: async () => {
            const records = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            return records[0] || null;
        },
        enabled: !!user
    });

    const earnedBadgeIds = progress?.badges_earned?.map(b => b.badge_id) || [];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-400" />
                    Badge Collection
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                    {allBadges.map(badge => {
                        const earned = earnedBadgeIds.includes(badge.id);
                        const Icon = badge.icon;
                        
                        return (
                            <Card
                                key={badge.id}
                                className={`${
                                    earned
                                        ? 'bg-gradient-to-br from-amber-900/30 to-yellow-900/30 border-amber-500/50'
                                        : 'bg-slate-800/30 border-slate-700'
                                }`}
                            >
                                <CardContent className="pt-6 text-center">
                                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 ${
                                        earned ? 'bg-amber-500/20' : 'bg-slate-700/50'
                                    }`}>
                                        {earned ? (
                                            <Icon className="w-8 h-8 text-amber-400" />
                                        ) : (
                                            <Lock className="w-8 h-8 text-slate-500" />
                                        )}
                                    </div>
                                    <h3 className={`font-semibold mb-2 ${earned ? 'text-amber-400' : 'text-slate-500'}`}>
                                        {badge.name}
                                    </h3>
                                    <p className="text-slate-400 text-sm">{badge.description}</p>
                                    {earned && (
                                        <Badge className="bg-emerald-500/20 text-emerald-400 mt-3">
                                            Earned ✓
                                        </Badge>
                                    )}
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}