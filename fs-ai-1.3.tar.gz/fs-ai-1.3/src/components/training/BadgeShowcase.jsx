import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Award, Lock } from 'lucide-react';

const allBadges = [
    { id: 'first_scenario', name: 'First Steps', description: 'Complete your first scenario', icon: '🎯' },
    { id: 'ten_scenarios', name: 'Dedicated Scout', description: 'Complete 10 scenarios', icon: '🔥' },
    { id: 'fifty_scenarios', name: 'Expert Analyst', description: 'Complete 50 scenarios', icon: '⭐' },
    { id: 'fa_master', name: 'FA Compliance Master', description: 'Score 100% on FA compliance', icon: '🛡️' },
    { id: 'ethics_champion', name: 'Ethics Champion', description: 'Score 100% on ethics training', icon: '💚' },
    { id: 'accuracy_ace', name: 'Accuracy Ace', description: 'Maintain 90% accuracy rate', icon: '🎪' },
    { id: 'level_5', name: 'Level 5 Scout', description: 'Reach level 5', icon: '🏆' },
    { id: 'level_10', name: 'Master Scout', description: 'Reach level 10', icon: '👑' }
];

export default function BadgeShowcase() {
    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: progress } = useQuery({
        queryKey: ['trainingProgress', user?.email],
        queryFn: async () => {
            const results = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            return results[0] || null;
        },
        enabled: !!user
    });

    const earnedBadges = progress?.badges_earned || [];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Award className="w-6 h-6 text-amber-400" />
                        Your Badge Collection
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {allBadges.map(badge => {
                            const earned = earnedBadges.includes(badge.id);
                            return (
                                <Card
                                    key={badge.id}
                                    className={`${
                                        earned
                                            ? 'bg-gradient-to-br from-amber-500/20 to-amber-600/10 border-amber-500/30'
                                            : 'bg-slate-800/30 border-slate-700'
                                    }`}
                                >
                                    <CardContent className="pt-6 text-center">
                                        <div className="text-5xl mb-3">
                                            {earned ? badge.icon : <Lock className="w-12 h-12 text-slate-600 mx-auto" />}
                                        </div>
                                        <h3 className={`font-bold mb-2 ${earned ? 'text-white' : 'text-slate-500'}`}>
                                            {badge.name}
                                        </h3>
                                        <p className="text-slate-400 text-xs">{badge.description}</p>
                                        {earned && (
                                            <Badge className="bg-amber-500/20 text-amber-400 mt-3">
                                                Earned!
                                            </Badge>
                                        )}
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <div className="text-center">
                        <p className="text-slate-400 mb-2">Badges Earned</p>
                        <p className="text-4xl font-bold text-white">
                            {earnedBadges.length} / {allBadges.length}
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}