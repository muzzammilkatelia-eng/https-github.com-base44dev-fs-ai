import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const ethicsQuestions = [
    {
        id: 1,
        question: "You discover a talented 15-year-old player. What is the correct FA-compliant approach?",
        options: [
            "Immediately offer a contract",
            "Contact parents, follow FA safeguarding protocols, DBS checks required",
            "Scout them secretly without parental knowledge",
            "Offer financial incentives to the family"
        ],
        correct: 1,
        explanation: "FA regulations require parental consent, safeguarding protocols, and DBS-cleared personnel when working with minors."
    },
    {
        id: 2,
        question: "A player's agent offers you money to recommend their client. What do you do?",
        options: [
            "Accept it as normal practice",
            "Decline and report the incident to club management",
            "Accept but don't tell anyone",
            "Negotiate for more money"
        ],
        correct: 1,
        explanation: "This is unethical and potentially illegal. Report immediately to maintain integrity and FA compliance."
    },
    {
        id: 3,
        question: "What is the maximum squad size for Premier League registration?",
        options: [
            "20 players",
            "25 players",
            "30 players",
            "No limit"
        ],
        correct: 1,
        explanation: "Premier League rules require a maximum 25-player squad, with at least 8 homegrown players."
    },
    {
        id: 4,
        question: "You notice a young player showing signs of distress. Your priority is:",
        options: [
            "Ignore it, focus on their football ability",
            "Immediately report to designated safeguarding officer",
            "Tell them to toughen up",
            "Wait and see if it continues"
        ],
        correct: 1,
        explanation: "Safeguarding is paramount. Any concerns must be immediately reported to the designated safeguarding officer."
    },
    {
        id: 5,
        question: "When scouting internationally, you must consider:",
        options: [
            "Only the player's ability",
            "Work permits, FIFA regulations, transfer window compliance",
            "How to avoid regulations",
            "None of the above"
        ],
        correct: 1,
        explanation: "International transfers require strict compliance with FIFA TMS, work permits, and transfer window regulations."
    }
];

export default function EthicsModule() {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [answers, setAnswers] = useState({});
    const [showResults, setShowResults] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const updateProgressMutation = useMutation({
        mutationFn: async ({ data }) => {
            const existing = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            if (existing[0]) {
                return base44.entities.ScoutTrainingProgress.update(existing[0].id, data);
            } else {
                return base44.entities.ScoutTrainingProgress.create({ ...data, user_email: user.email });
            }
        },
        onSuccess: () => queryClient.invalidateQueries(['trainingProgress'])
    });

    const handleAnswer = (optionIndex) => {
        setAnswers({ ...answers, [currentQuestion]: optionIndex });
        
        if (currentQuestion < ethicsQuestions.length - 1) {
            setTimeout(() => setCurrentQuestion(currentQuestion + 1), 500);
        } else {
            setTimeout(() => calculateResults(), 500);
        }
    };

    const calculateResults = async () => {
        const correctAnswers = ethicsQuestions.filter((q, idx) => answers[idx] === q.correct).length;
        const score = (correctAnswers / ethicsQuestions.length) * 100;
        
        setShowResults(true);

        if (score >= 80) {
            const existing = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            const progress = existing[0] || {};
            
            updateProgressMutation.mutate({
                data: {
                    fa_compliance_certified: true,
                    ethical_score: score,
                    badges_earned: [
                        ...(progress.badges_earned || []),
                        {
                            badge_id: 'fa_ethics',
                            badge_name: 'FA Ethics & Compliance',
                            earned_date: new Date().toISOString()
                        }
                    ]
                }
            });
            
            toast.success('FA Compliance Certification Earned! 🏅');
        }
    };

    const resetQuiz = () => {
        setCurrentQuestion(0);
        setAnswers({});
        setShowResults(false);
    };

    if (showResults) {
        const correctAnswers = ethicsQuestions.filter((q, idx) => answers[idx] === q.correct).length;
        const score = (correctAnswers / ethicsQuestions.length) * 100;

        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Shield className="w-5 h-5 text-emerald-400" />
                        Ethics & FA Regulations - Results
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="text-center py-6">
                        <div className={`text-6xl font-bold mb-4 ${score >= 80 ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {score.toFixed(0)}%
                        </div>
                        <p className="text-slate-400 text-lg">
                            {correctAnswers} out of {ethicsQuestions.length} correct
                        </p>
                        {score >= 80 ? (
                            <Badge className="bg-emerald-500/20 text-emerald-400 mt-4">
                                FA Compliance Certified ✓
                            </Badge>
                        ) : (
                            <p className="text-amber-400 mt-4">80% required for certification. Keep learning!</p>
                        )}
                    </div>

                    <div className="space-y-4">
                        {ethicsQuestions.map((q, idx) => (
                            <Card key={q.id} className="bg-slate-800/50 border-slate-700">
                                <CardContent className="pt-4">
                                    <div className="flex items-start gap-3">
                                        {answers[idx] === q.correct ? (
                                            <CheckCircle className="w-5 h-5 text-emerald-400 mt-1" />
                                        ) : (
                                            <XCircle className="w-5 h-5 text-red-400 mt-1" />
                                        )}
                                        <div className="flex-1">
                                            <p className="text-white font-semibold mb-2">{q.question}</p>
                                            <p className="text-slate-400 text-sm mb-2">
                                                Your answer: {q.options[answers[idx]]}
                                            </p>
                                            <p className="text-emerald-400 text-sm mb-2">
                                                Correct: {q.options[q.correct]}
                                            </p>
                                            <p className="text-slate-500 text-xs">{q.explanation}</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <Button onClick={resetQuiz} className="w-full bg-cyan-600">
                        Retake Quiz
                    </Button>
                </CardContent>
            </Card>
        );
    }

    const question = ethicsQuestions[currentQuestion];

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-emerald-400" />
                        Ethics & FA Regulations
                    </div>
                    <Badge className="bg-cyan-500/20 text-cyan-400">
                        Question {currentQuestion + 1} / {ethicsQuestions.length}
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-6">
                    <p className="text-white text-lg font-semibold">{question.question}</p>
                </div>

                <div className="grid gap-3">
                    {question.options.map((option, idx) => (
                        <Button
                            key={idx}
                            onClick={() => handleAnswer(idx)}
                            variant="outline"
                            className={`h-auto py-4 px-6 text-left justify-start ${
                                answers[currentQuestion] === idx
                                    ? 'bg-cyan-600 text-white border-cyan-500'
                                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-600'
                            }`}
                        >
                            <span className="font-semibold mr-3">{String.fromCharCode(65 + idx)}.</span>
                            {option}
                        </Button>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}