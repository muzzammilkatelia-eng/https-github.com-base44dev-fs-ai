import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const faQuestions = [
    {
        id: 1,
        question: 'What is the maximum squad size for Premier League clubs?',
        options: ['20 players', '23 players', '25 players', '30 players'],
        correct: 2,
        explanation: '25 players is the maximum squad size for Premier League clubs.'
    },
    {
        id: 2,
        question: 'How many homegrown players must be in a 25-man Premier League squad?',
        options: ['4 players', '6 players', '8 players', '10 players'],
        correct: 2,
        explanation: 'Minimum 8 homegrown players required in a 25-man squad.'
    },
    {
        id: 3,
        question: 'At what age do players stop counting toward squad limits?',
        options: ['Under-18', 'Under-19', 'Under-21', 'Under-23'],
        correct: 2,
        explanation: 'Under-21 players do not count toward the 25-man squad limit.'
    },
    {
        id: 4,
        question: 'Which is NOT a key FA safeguarding requirement?',
        options: ['DBS checks', 'Social media monitoring', 'Safeguarding training', 'Age verification'],
        correct: 1,
        explanation: 'Social media monitoring is not a mandatory FA safeguarding requirement.'
    },
    {
        id: 5,
        question: 'When are the Premier League transfer windows?',
        options: ['June-July & December', 'June-August & January', 'July-September & December', 'All year round'],
        correct: 1,
        explanation: 'Transfer windows: June-August (summer) and January (winter).'
    }
];

export default function FAComplianceModule() {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState(null);
    const [score, setScore] = useState(0);
    const [completed, setCompleted] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const handleAnswer = async (answerIndex) => {
        setSelectedAnswer(answerIndex);
        const isCorrect = answerIndex === faQuestions[currentQuestion].correct;
        
        if (isCorrect) {
            setScore(score + 20);
            toast.success('Correct! ✅');
        } else {
            toast.error('Incorrect ❌');
        }

        setTimeout(() => {
            if (currentQuestion < faQuestions.length - 1) {
                setCurrentQuestion(currentQuestion + 1);
                setSelectedAnswer(null);
            } else {
                completeModule();
            }
        }, 2000);
    };

    const completeModule = async () => {
        setCompleted(true);
        const finalScore = score + (selectedAnswer === faQuestions[currentQuestion].correct ? 20 : 0);

        try {
            const progressData = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            const progress = progressData[0];

            if (progress) {
                await base44.entities.ScoutTrainingProgress.update(progress.id, {
                    total_score: (progress.total_score || 0) + finalScore,
                    fa_compliance_score: finalScore,
                    modules_completed: [
                        ...(progress.modules_completed || []),
                        {
                            module_id: 'FA Compliance',
                            score: finalScore,
                            completed_date: new Date().toISOString()
                        }
                    ]
                });
            } else {
                await base44.entities.ScoutTrainingProgress.create({
                    user_email: user.email,
                    total_score: finalScore,
                    fa_compliance_score: finalScore,
                    modules_completed: [{
                        module_id: 'FA Compliance',
                        score: finalScore,
                        completed_date: new Date().toISOString()
                    }]
                });
            }

            queryClient.invalidateQueries(['trainingProgress']);
        } catch (error) {
            console.error('Failed to save progress:', error);
        }
    };

    const restart = () => {
        setCurrentQuestion(0);
        setSelectedAnswer(null);
        setScore(0);
        setCompleted(false);
    };

    const question = faQuestions[currentQuestion];

    return (
        <Card className="bg-slate-900/50 border-slate-800 max-w-3xl mx-auto">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="w-6 h-6 text-cyan-400" />
                    FA Regulations & Compliance Training
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!completed ? (
                    <div className="space-y-6">
                        <div className="flex items-center justify-between mb-4">
                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                Question {currentQuestion + 1} of {faQuestions.length}
                            </Badge>
                            <Badge className="bg-purple-500/20 text-purple-400">
                                Score: {score}
                            </Badge>
                        </div>

                        <div className="bg-slate-800/50 rounded-lg p-6">
                            <h3 className="text-white text-xl font-semibold mb-6">{question.question}</h3>
                            <div className="space-y-3">
                                {question.options.map((option, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => handleAnswer(idx)}
                                        disabled={selectedAnswer !== null}
                                        className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                                            selectedAnswer === null
                                                ? 'border-slate-700 hover:border-cyan-500 bg-slate-800'
                                                : selectedAnswer === idx
                                                ? idx === question.correct
                                                    ? 'border-emerald-500 bg-emerald-500/20'
                                                    : 'border-red-500 bg-red-500/20'
                                                : idx === question.correct
                                                ? 'border-emerald-500 bg-emerald-500/20'
                                                : 'border-slate-700 bg-slate-800'
                                        }`}
                                    >
                                        <div className="flex items-center justify-between">
                                            <span className="text-white">{option}</span>
                                            {selectedAnswer !== null && idx === question.correct && (
                                                <CheckCircle className="w-5 h-5 text-emerald-400" />
                                            )}
                                            {selectedAnswer === idx && idx !== question.correct && (
                                                <XCircle className="w-5 h-5 text-red-400" />
                                            )}
                                        </div>
                                    </button>
                                ))}
                            </div>

                            {selectedAnswer !== null && (
                                <div className="mt-4 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                                    <p className="text-cyan-400 text-sm">{question.explanation}</p>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <div className="mb-6">
                            {score >= 80 ? (
                                <CheckCircle className="w-20 h-20 text-emerald-400 mx-auto mb-4" />
                            ) : (
                                <Shield className="w-20 h-20 text-amber-400 mx-auto mb-4" />
                            )}
                            <h3 className="text-white text-2xl font-bold mb-2">
                                Module Complete!
                            </h3>
                            <p className="text-slate-400 mb-4">
                                Your FA Compliance Score: {score}/100
                            </p>
                            {score >= 80 ? (
                                <Badge className="bg-emerald-500/20 text-emerald-400 text-lg py-2 px-4">
                                    Passed! 🎉
                                </Badge>
                            ) : (
                                <Badge className="bg-amber-500/20 text-amber-400 text-lg py-2 px-4">
                                    Needs Improvement
                                </Badge>
                            )}
                        </div>
                        <Button onClick={restart} className="bg-cyan-600">
                            Retake Training
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}