import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { BarChart3, Loader2, CheckCircle, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function PerformanceAnalysisModule() {
    const [currentScenario, setCurrentScenario] = useState(null);
    const [userAnalysis, setUserAnalysis] = useState('');
    const [feedback, setFeedback] = useState(null);
    const [loading, setLoading] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: players = [] } = useQuery({
        queryKey: ['trainingPlayers'],
        queryFn: () => base44.entities.Player.list('-updated_date', 50)
    });

    const generateScenario = () => {
        const player = players[Math.floor(Math.random() * players.length)];
        if (!player) return;

        setCurrentScenario({
            player,
            task: 'Analyze this player\'s performance data and provide a scouting recommendation. Consider their stats, potential, and suitability for different tactical roles.'
        });
        setUserAnalysis('');
        setFeedback(null);
    };

    const submitAnalysis = async () => {
        if (!userAnalysis.trim()) {
            toast.error('Please provide your analysis');
            return;
        }

        setLoading(true);
        try {
            const aiResponse = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an expert scout trainer evaluating a trainee's player analysis.

**PLAYER DATA:**
Name: ${currentScenario.player.name}
Age: ${currentScenario.player.age}
Position: ${currentScenario.player.position}
Club: ${currentScenario.player.current_club}
Market Value: €${currentScenario.player.market_value}M
FS-AI Score: ${currentScenario.player.fsai_proprietary_score || 'N/A'}

**TRAINEE ANALYSIS:**
${userAnalysis}

**YOUR TASK:**
Evaluate the trainee's analysis on:
1. Accuracy of assessment (0-100)
2. Depth of tactical understanding
3. Consideration of key attributes
4. Recommendation quality
5. Professional writing

Provide:
- Overall score (0-100)
- Strengths (2-3 points)
- Areas for improvement (2-3 points)
- Correct professional analysis example

Format as JSON:
{
  "score": number,
  "strengths": ["point1", "point2"],
  "improvements": ["point1", "point2"],
  "example": "Professional analysis...",
  "passed": boolean
}`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        score: { type: "number" },
                        strengths: { type: "array", items: { type: "string" } },
                        improvements: { type: "array", items: { type: "string" } },
                        example: { type: "string" },
                        passed: { type: "boolean" }
                    }
                }
            });

            setFeedback(aiResponse);

            // Update progress
            const progressData = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            const progress = progressData[0];
            
            if (progress) {
                await base44.entities.ScoutTrainingProgress.update(progress.id, {
                    total_score: (progress.total_score || 0) + aiResponse.score,
                    scenarios_completed: (progress.scenarios_completed || 0) + 1,
                    accuracy_rate: ((progress.accuracy_rate || 0) * (progress.scenarios_completed || 0) + aiResponse.score) / ((progress.scenarios_completed || 0) + 1),
                    modules_completed: [
                        ...(progress.modules_completed || []),
                        {
                            module_id: 'Performance Analysis',
                            score: aiResponse.score,
                            completed_date: new Date().toISOString(),
                            feedback: aiResponse.passed ? 'Passed' : 'Needs improvement'
                        }
                    ]
                });
            } else {
                await base44.entities.ScoutTrainingProgress.create({
                    user_email: user.email,
                    total_score: aiResponse.score,
                    scenarios_completed: 1,
                    accuracy_rate: aiResponse.score,
                    modules_completed: [{
                        module_id: 'Performance Analysis',
                        score: aiResponse.score,
                        completed_date: new Date().toISOString()
                    }]
                });
            }

            queryClient.invalidateQueries(['trainingProgress']);
            toast.success(aiResponse.passed ? 'Great work! 🎉' : 'Keep practicing! 💪');
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to evaluate analysis');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <BarChart3 className="w-6 h-6 text-cyan-400" />
                        Performance Analysis Training
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {!currentScenario ? (
                        <div className="text-center py-12">
                            <p className="text-slate-400 mb-4">
                                Test your ability to analyze player performance and provide professional scouting recommendations
                            </p>
                            <Button onClick={generateScenario} className="bg-cyan-600">
                                Start Training Scenario
                            </Button>
                        </div>
                    ) : (
                        <>
                            <div className="bg-slate-800/50 rounded-lg p-6">
                                <h3 className="text-white font-bold text-xl mb-4">{currentScenario.player.name}</h3>
                                <div className="grid md:grid-cols-3 gap-4 mb-4">
                                    <div>
                                        <p className="text-slate-400 text-sm">Age</p>
                                        <p className="text-white font-semibold">{currentScenario.player.age}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-sm">Position</p>
                                        <p className="text-white font-semibold">{currentScenario.player.position}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-400 text-sm">Club</p>
                                        <p className="text-white font-semibold">{currentScenario.player.current_club}</p>
                                    </div>
                                </div>
                                <Badge className="bg-purple-500/20 text-purple-400">
                                    Market Value: €{currentScenario.player.market_value}M
                                </Badge>
                            </div>

                            <div>
                                <p className="text-slate-400 mb-2">Your Analysis:</p>
                                <Textarea
                                    value={userAnalysis}
                                    onChange={(e) => setUserAnalysis(e.target.value)}
                                    placeholder="Provide your professional scouting analysis here..."
                                    className="bg-slate-800 border-slate-700 text-white min-h-[200px]"
                                    disabled={loading || feedback}
                                />
                            </div>

                            {!feedback && (
                                <div className="flex gap-3">
                                    <Button onClick={submitAnalysis} disabled={loading} className="bg-cyan-600 flex-1">
                                        {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                        Submit Analysis
                                    </Button>
                                    <Button onClick={generateScenario} variant="outline">
                                        New Scenario
                                    </Button>
                                </div>
                            )}

                            {feedback && (
                                <Card className={`border-2 ${feedback.passed ? 'border-emerald-500' : 'border-amber-500'}`}>
                                    <CardContent className="pt-6">
                                        <div className="flex items-center gap-3 mb-4">
                                            {feedback.passed ? (
                                                <CheckCircle className="w-8 h-8 text-emerald-400" />
                                            ) : (
                                                <XCircle className="w-8 h-8 text-amber-400" />
                                            )}
                                            <div>
                                                <h3 className="text-white font-bold text-xl">Score: {feedback.score}/100</h3>
                                                <p className="text-slate-400 text-sm">
                                                    {feedback.passed ? 'Excellent work!' : 'Keep practicing!'}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="space-y-4">
                                            <div>
                                                <p className="text-emerald-400 font-semibold mb-2">Strengths:</p>
                                                <ul className="list-disc list-inside text-slate-300 space-y-1">
                                                    {feedback.strengths?.map((s, i) => <li key={i}>{s}</li>)}
                                                </ul>
                                            </div>

                                            <div>
                                                <p className="text-amber-400 font-semibold mb-2">Areas for Improvement:</p>
                                                <ul className="list-disc list-inside text-slate-300 space-y-1">
                                                    {feedback.improvements?.map((i, idx) => <li key={idx}>{i}</li>)}
                                                </ul>
                                            </div>

                                            <div>
                                                <p className="text-cyan-400 font-semibold mb-2">Example Professional Analysis:</p>
                                                <p className="text-slate-300 bg-slate-800/50 p-4 rounded-lg">{feedback.example}</p>
                                            </div>

                                            <Button onClick={generateScenario} className="w-full bg-cyan-600">
                                                Next Scenario
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            )}
                        </>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}