import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Target, Award, CheckCircle } from 'lucide-react';

export default function PerformanceFeedback() {
    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: progress } = useQuery({
        queryKey: ['trainingProgress', user?.email],
        queryFn: async () => {
            const records = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            return records[0] || null;
        },
        enabled: !!user
    });

    const metrics = [
        { label: 'Scenarios Completed', value: progress?.scenarios_completed || 0, target: 20, icon: Target },
        { label: 'Accuracy Rate', value: progress?.accuracy_rate || 0, target: 100, icon: TrendingUp, suffix: '%' },
        { label: 'Ethical Score', value: progress?.ethical_score || 0, target: 100, icon: CheckCircle, suffix: '%' },
        { label: 'Badges Earned', value: progress?.badges_earned?.length || 0, target: 6, icon: Award }
    ];

    return (
        <div className="grid md:grid-cols-2 gap-6">
            {metrics.map((metric) => {
                const Icon = metric.icon;
                const percentage = (metric.value / metric.target) * 100;
                
                return (
                    <Card key={metric.label} className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white text-lg flex items-center gap-2">
                                <Icon className="w-5 h-5 text-cyan-400" />
                                {metric.label}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="flex items-baseline gap-2">
                                    <span className="text-4xl font-bold text-white">
                                        {metric.value}
                                    </span>
                                    {metric.suffix && (
                                        <span className="text-2xl text-slate-400">{metric.suffix}</span>
                                    )}
                                    <span className="text-slate-400 ml-auto">/ {metric.target}{metric.suffix || ''}</span>
                                </div>
                                <Progress value={Math.min(percentage, 100)} className="h-2" />
                            </div>
                        </CardContent>
                    </Card>
                );
            })}
        </div>
    );
}