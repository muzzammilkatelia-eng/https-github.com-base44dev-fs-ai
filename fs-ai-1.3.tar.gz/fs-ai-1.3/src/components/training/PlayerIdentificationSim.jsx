import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Target, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function PlayerIdentificationSim() {
    const [scenario, setScenario] = useState(null);
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [feedback, setFeedback] = useState(null);
    const [loading, setLoading] = useState(false);
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players-training'],
        queryFn: () => base44.entities.Player.list('-fsai_proprietary_score', 100)
    });

    const updateProgressMutation = useMutation({
        mutationFn: async ({ data }) => {
            const existing = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            if (existing[0]) {
                return base44.entities.ScoutTrainingProgress.update(existing[0].id, data);
            } else {
                return base44.entities.ScoutTrainingProgress.create({ ...data, user_email: user.email });
            }
        },
        onSuccess: () => queryClient.invalidateQueries(['trainingProgress'])
    });

    const generateScenario = async () => {
        setLoading(true);
        setFeedback(null);
        setSelectedPlayers([]);
        
        try {
            const criteria = [
                { type: 'Young Prospect', desc: 'Find 3 players under 23 with high potential', filter: p => p.age < 23 && p.fsai_proprietary_score > 75 },
                { type: 'Value Signing', desc: 'Find 3 undervalued players (market value < 10M, rating > 80)', filter: p => p.market_value < 10 && p.fsai_proprietary_score > 80 },
                { type: 'Position Need', desc: 'Find 3 top-rated Strikers', filter: p => p.position === 'Striker' && p.fsai_proprietary_score > 75 },
                { type: 'League Specialist', desc: 'Find 3 Premier League players with rating > 80', filter: p => p.league === 'Premier League' && p.fsai_proprietary_score > 80 }
            ];

            const selectedCriteria = criteria[Math.floor(Math.random() * criteria.length)];
            const candidates = players.filter(selectedCriteria.filter).slice(0, 10);
            
            setScenario({
                ...selectedCriteria,
                candidates: candidates,
                correctAnswers: candidates.slice(0, 3).map(p => p.id)
            });
        } catch (error) {
            toast.error('Failed to generate scenario');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        if (selectedPlayers.length !== 3) {
            toast.error('Please select exactly 3 players');
            return;
        }

        setLoading(true);
        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an FA-certified scout training AI evaluator.

**SCENARIO:** ${scenario.desc}

**PLAYERS SELECTED:**
${selectedPlayers.map((id, i) => {
    const player = scenario.candidates.find(p => p.id === id);
    return `${i + 1}. ${player.name} (Age: ${player.age}, Position: ${player.position}, Value: €${player.market_value}M, Rating: ${player.fsai_proprietary_score})`;
}).join('\n')}

**EVALUATION CRITERIA:**
- Suitability for scenario requirements
- Value for money
- Potential vs current ability
- FA compliance considerations
- Ethical scouting practices

Provide:
1. Overall Score (0-100)
2. Individual player feedback
3. What was done well
4. Areas for improvement
5. FA compliance notes`,
                add_context_from_internet: false
            });

            const score = Math.floor(Math.random() * 30) + 70; // Demo scoring
            setFeedback({
                score,
                analysis: response,
                passed: score >= 70
            });

            // Update progress
            const currentProgress = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            const progress = currentProgress[0] || {};
            
            updateProgressMutation.mutate({
                data: {
                    scenarios_completed: (progress.scenarios_completed || 0) + 1,
                    total_score: (progress.total_score || 0) + score,
                    accuracy_rate: Math.min(100, (progress.accuracy_rate || 0) + 5)
                }
            });

            if (score >= 90) {
                toast.success('Excellent work! Badge earned! 🏆');
            }
        } catch (error) {
            toast.error('Failed to evaluate');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Player Identification Simulation
                        </div>
                        <Button onClick={generateScenario} disabled={loading} className="bg-cyan-600">
                            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'New Scenario'}
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {!scenario ? (
                        <div className="text-center py-12">
                            <Target className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                            <p className="text-slate-400">Click "New Scenario" to start training</p>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                <h3 className="text-white font-semibold mb-2">{scenario.type}</h3>
                                <p className="text-slate-300">{scenario.desc}</p>
                                <p className="text-slate-400 text-sm mt-2">Select 3 players that best meet the criteria</p>
                            </div>

                            <div className="grid md:grid-cols-2 gap-4">
                                {scenario.candidates.map(player => (
                                    <Card
                                        key={player.id}
                                        onClick={() => {
                                            if (selectedPlayers.includes(player.id)) {
                                                setSelectedPlayers(selectedPlayers.filter(id => id !== player.id));
                                            } else if (selectedPlayers.length < 3) {
                                                setSelectedPlayers([...selectedPlayers, player.id]);
                                            }
                                        }}
                                        className={`cursor-pointer transition-all ${
                                            selectedPlayers.includes(player.id)
                                                ? 'bg-cyan-900/50 border-cyan-500'
                                                : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                                        }`}
                                    >
                                        <CardContent className="pt-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <h4 className="text-white font-semibold">{player.name}</h4>
                                                {selectedPlayers.includes(player.id) && (
                                                    <CheckCircle className="w-5 h-5 text-cyan-400" />
                                                )}
                                            </div>
                                            <div className="space-y-1 text-sm text-slate-400">
                                                <p>Age: {player.age} • {player.position}</p>
                                                <p>Value: €{player.market_value}M</p>
                                                <p>Rating: {player.fsai_proprietary_score}/100</p>
                                                <p>League: {player.league}</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>

                            <Button
                                onClick={handleSubmit}
                                disabled={selectedPlayers.length !== 3 || loading}
                                className="w-full bg-cyan-600"
                            >
                                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                Submit Selection
                            </Button>

                            {feedback && (
                                <Card className={`border-2 ${feedback.passed ? 'border-emerald-500 bg-emerald-900/20' : 'border-amber-500 bg-amber-900/20'}`}>
                                    <CardContent className="pt-6">
                                        <div className="flex items-center gap-3 mb-4">
                                            {feedback.passed ? (
                                                <CheckCircle className="w-8 h-8 text-emerald-400" />
                                            ) : (
                                                <XCircle className="w-8 h-8 text-amber-400" />
                                            )}
                                            <div>
                                                <p className="text-white font-bold text-xl">Score: {feedback.score}/100</p>
                                                <p className="text-slate-400 text-sm">
                                                    {feedback.passed ? 'Passed!' : 'Keep practicing!'}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="prose prose-invert max-w-none">
                                            <p className="text-slate-300 whitespace-pre-wrap">{feedback.analysis}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}