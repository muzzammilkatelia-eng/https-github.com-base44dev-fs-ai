import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { FileText, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ReportWritingSim() {
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [report, setReport] = useState('');
    const [feedback, setFeedback] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-report-training'],
        queryFn: () => base44.entities.Player.list('-updated_date', 20)
    });

    const selectRandomPlayer = () => {
        const player = players[Math.floor(Math.random() * players.length)];
        setSelectedPlayer(player);
        setReport('');
        setFeedback(null);
    };

    const handleSubmit = async () => {
        if (!report.trim()) {
            toast.error('Please write a report');
            return;
        }

        setLoading(true);
        try {
            const evaluation = await base44.integrations.Core.InvokeLLM({
                prompt: `You are evaluating a scout training report for FA compliance and quality.

**PLAYER:** ${selectedPlayer.name} (${selectedPlayer.age}y, ${selectedPlayer.position})

**SCOUT REPORT:**
${report}

**EVALUATION CRITERIA:**
1. Professional structure and clarity
2. Objective vs subjective observations
3. Technical detail and specificity
4. FA compliance (no discriminatory language)
5. Ethical considerations mentioned
6. Actionable recommendations

Provide:
- Score (0-100)
- Strengths
- Areas for improvement
- FA compliance notes
- Professional tips`,
                add_context_from_internet: false
            });

            setFeedback(evaluation);
            toast.success('Report evaluated!');
        } catch (error) {
            toast.error('Evaluation failed');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-cyan-400" />
                        Report Writing Simulation
                    </div>
                    <Button onClick={selectRandomPlayer} className="bg-cyan-600">
                        Random Player
                    </Button>
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {selectedPlayer ? (
                    <>
                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                            <h3 className="text-white font-semibold text-lg mb-2">{selectedPlayer.name}</h3>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                <div>
                                    <span className="text-slate-400">Age:</span>
                                    <p className="text-white">{selectedPlayer.age}</p>
                                </div>
                                <div>
                                    <span className="text-slate-400">Position:</span>
                                    <p className="text-white">{selectedPlayer.position}</p>
                                </div>
                                <div>
                                    <span className="text-slate-400">Club:</span>
                                    <p className="text-white">{selectedPlayer.current_club}</p>
                                </div>
                                <div>
                                    <span className="text-slate-400">Value:</span>
                                    <p className="text-white">€{selectedPlayer.market_value}M</p>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">
                                Write your scouting report (consider technical ability, tactical awareness, physical attributes, mental strength)
                            </label>
                            <Textarea
                                value={report}
                                onChange={(e) => setReport(e.target.value)}
                                placeholder="Begin your professional scouting report..."
                                className="bg-slate-800 border-slate-700 text-white min-h-[200px]"
                            />
                        </div>

                        <Button onClick={handleSubmit} disabled={loading} className="w-full bg-cyan-600">
                            {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                            Submit Report
                        </Button>

                        {feedback && (
                            <Card className="bg-slate-800/50 border-slate-700">
                                <CardContent className="pt-6">
                                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                        <FileText className="w-5 h-5 text-cyan-400" />
                                        AI Evaluation
                                    </h4>
                                    <div className="prose prose-invert max-w-none">
                                        <p className="text-slate-300 whitespace-pre-wrap">{feedback}</p>
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                    </>
                ) : (
                    <div className="text-center py-12">
                        <FileText className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400">Select a random player to begin writing a report</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}