import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Trophy, Star, Shield } from 'lucide-react';

export default function TrainingCourseBanner() {
    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: progress } = useQuery({
        queryKey: ['trainingProgress', user?.email],
        queryFn: async () => {
            const records = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            return records[0] || null;
        },
        enabled: !!user
    });

    const completionRate = progress ? (progress.modules_completed?.length || 0) / 10 * 100 : 0;

    return (
        <Card className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 border-cyan-500/30">
            <CardContent className="pt-6">
                <div className="grid md:grid-cols-4 gap-6">
                    <div className="text-center">
                        <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{progress?.total_score || 0}</p>
                        <p className="text-slate-400 text-sm">Total Score</p>
                    </div>
                    <div className="text-center">
                        <Star className="w-12 h-12 text-cyan-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{progress?.badges_earned?.length || 0}</p>
                        <p className="text-slate-400 text-sm">Badges Earned</p>
                    </div>
                    <div className="text-center">
                        <Shield className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{progress?.accuracy_rate || 0}%</p>
                        <p className="text-slate-400 text-sm">Accuracy Rate</p>
                    </div>
                    <div className="text-center">
                        <div className="mb-3">
                            <p className="text-2xl font-bold text-white">{completionRate.toFixed(0)}%</p>
                            <p className="text-slate-400 text-sm">Completion</p>
                        </div>
                        <Progress value={completionRate} className="h-2" />
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}