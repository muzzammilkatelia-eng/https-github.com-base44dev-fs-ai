import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Award, Target, CheckCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export default function TrainingDashboard() {
    const { data: user } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: progress } = useQuery({
        queryKey: ['trainingProgress', user?.email],
        queryFn: async () => {
            const results = await base44.entities.ScoutTrainingProgress.filter({ user_email: user.email });
            return results[0] || null;
        },
        enabled: !!user
    });

    const stats = [
        { label: 'Total Score', value: progress?.total_score || 0, icon: TrendingUp, color: 'text-cyan-400' },
        { label: 'Level', value: progress?.level || 1, icon: Award, color: 'text-amber-400' },
        { label: 'Scenarios', value: progress?.scenarios_completed || 0, icon: Target, color: 'text-purple-400' },
        { label: 'Badges', value: progress?.badges_earned?.length || 0, icon: CheckCircle, color: 'text-emerald-400' }
    ];

    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
                {stats.map(stat => (
                    <Card key={stat.label} className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                                <p className="text-3xl font-bold text-white">{stat.value}</p>
                            </div>
                            <p className="text-slate-400 text-sm">{stat.label}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Skill Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <div className="flex justify-between mb-2">
                                <span className="text-slate-400 text-sm">Accuracy Rate</span>
                                <span className="text-white font-semibold">{progress?.accuracy_rate || 0}%</span>
                            </div>
                            <Progress value={progress?.accuracy_rate || 0} className="h-2" />
                        </div>
                        <div>
                            <div className="flex justify-between mb-2">
                                <span className="text-slate-400 text-sm">FA Compliance</span>
                                <span className="text-white font-semibold">{progress?.fa_compliance_score || 0}%</span>
                            </div>
                            <Progress value={progress?.fa_compliance_score || 0} className="h-2" />
                        </div>
                        <div>
                            <div className="flex justify-between mb-2">
                                <span className="text-slate-400 text-sm">Ethics Score</span>
                                <span className="text-white font-semibold">{progress?.ethics_score || 0}%</span>
                            </div>
                            <Progress value={progress?.ethics_score || 0} className="h-2" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Recent Achievements</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {progress?.modules_completed && progress.modules_completed.length > 0 ? (
                            <div className="space-y-3">
                                {progress.modules_completed.slice(-5).reverse().map((module, idx) => (
                                    <div key={idx} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                                        <div>
                                            <p className="text-white font-semibold">{module.module_id}</p>
                                            <p className="text-slate-400 text-xs">
                                                {new Date(module.completed_date).toLocaleDateString()}
                                            </p>
                                        </div>
                                        <Badge className="bg-cyan-500/20 text-cyan-400">
                                            {module.score} pts
                                        </Badge>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-slate-400 text-center py-8">
                                No training completed yet. Start your first scenario!
                            </p>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}