import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award } from 'lucide-react';

export default function TrainingLeaderboard() {
    const { data: allProgress = [] } = useQuery({
        queryKey: ['allTrainingProgress'],
        queryFn: () => base44.entities.ScoutTrainingProgress.list('-total_score', 20)
    });

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-amber-400" />
                    Training Leaderboard
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    {allProgress.map((progress, idx) => (
                        <div
                            key={progress.id}
                            className={`flex items-center gap-4 p-4 rounded-lg ${
                                idx === 0 ? 'bg-amber-500/10 border border-amber-500/30' :
                                idx === 1 ? 'bg-slate-500/10 border border-slate-500/30' :
                                idx === 2 ? 'bg-orange-500/10 border border-orange-500/30' :
                                'bg-slate-800/50'
                            }`}
                        >
                            <div className="w-12 text-center">
                                {idx === 0 ? <Trophy className="w-8 h-8 text-amber-400 mx-auto" /> :
                                 idx === 1 ? <Medal className="w-8 h-8 text-slate-400 mx-auto" /> :
                                 idx === 2 ? <Award className="w-8 h-8 text-orange-400 mx-auto" /> :
                                 <span className="text-2xl font-bold text-slate-500">{idx + 1}</span>}
                            </div>
                            <div className="flex-1">
                                <p className="text-white font-semibold">{progress.user_email}</p>
                                <div className="flex gap-3 mt-1">
                                    <span className="text-slate-400 text-sm">
                                        Score: {progress.total_score || 0}
                                    </span>
                                    <span className="text-slate-400 text-sm">•</span>
                                    <span className="text-slate-400 text-sm">
                                        Accuracy: {progress.accuracy_rate || 0}%
                                    </span>
                                    <span className="text-slate-400 text-sm">•</span>
                                    <span className="text-slate-400 text-sm">
                                        Scenarios: {progress.scenarios_completed || 0}
                                    </span>
                                </div>
                            </div>
                            {progress.fa_compliance_certified && (
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    FA Certified
                                </Badge>
                            )}
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}