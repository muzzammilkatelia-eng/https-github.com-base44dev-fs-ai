import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function AIValuePredictor() {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [prediction, setPrediction] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const filteredPlayers = players.filter(p =>
        p.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const predictTransferValue = async () => {
        if (!selectedPlayer) return;

        setIsAnalyzing(true);
        toast.loading('AI analyzing transfer value...', { id: 'predict' });

        try {
            const prompt = `You are an expert football transfer market analyst. Analyze this player and predict their realistic transfer value.

Player Profile:
- Name: ${selectedPlayer.name}
- Age: ${selectedPlayer.age}
- Position: ${selectedPlayer.position}
- Current Club: ${selectedPlayer.current_club}
- League: ${selectedPlayer.league}
- Current Market Value: €${selectedPlayer.market_value}M
- Contract Expiry: ${selectedPlayer.contract_expiry || 'Unknown'}
- FS-AI Rating: ${selectedPlayer.fsai_proprietary_score?.toFixed(1) || 'N/A'}

Career Stats (if available):
${selectedPlayer.career_history ? JSON.stringify(selectedPlayer.career_history.slice(0, 3)) : 'Limited data'}

Analyze and predict:
1. Realistic transfer value in current market
2. Value in 6 months
3. Value in 12 months
4. Key factors affecting value
5. Market demand indicators

Return this JSON:
{
  "current_predicted_value": 45.5,
  "value_6_months": 48.0,
  "value_12_months": 50.0,
  "confidence": 85,
  "key_factors": [
    "Factor 1 affecting value",
    "Factor 2 affecting value",
    "Factor 3 affecting value"
  ],
  "market_demand": "High/Medium/Low",
  "peak_value_timing": "Description of when to sell for max value",
  "risk_factors": ["Risk 1", "Risk 2"],
  "recommendation": "Buy/Sell/Hold recommendation with reasoning"
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        current_predicted_value: { type: 'number' },
                        value_6_months: { type: 'number' },
                        value_12_months: { type: 'number' },
                        confidence: { type: 'number' },
                        key_factors: { type: 'array', items: { type: 'string' } },
                        market_demand: { type: 'string' },
                        peak_value_timing: { type: 'string' },
                        risk_factors: { type: 'array', items: { type: 'string' } },
                        recommendation: { type: 'string' }
                    }
                }
            });

            setPrediction(data);
            toast.success('Analysis complete', { id: 'predict' });
        } catch (error) {
            console.error('Prediction error:', error);
            toast.error('Prediction failed', { id: 'predict' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const getDemandColor = (demand) => {
        switch(demand) {
            case 'High': return 'emerald';
            case 'Medium': return 'amber';
            case 'Low': return 'red';
            default: return 'slate';
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-cyan-400" />
                        AI Transfer Value Predictor
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex gap-3">
                        <Input
                            placeholder="Search player..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                        <Button
                            onClick={predictTransferValue}
                            disabled={!selectedPlayer || isAnalyzing}
                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Predict Value
                                </>
                            )}
                        </Button>
                    </div>

                    {searchTerm && (
                        <div className="grid md:grid-cols-4 gap-3 max-h-64 overflow-y-auto">
                            {filteredPlayers.slice(0, 12).map(player => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    onClick={() => setSelectedPlayer(player)}
                                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                        selectedPlayer?.id === player.id
                                            ? 'bg-cyan-500/20 border-cyan-500/50'
                                            : 'bg-slate-800/50 border-slate-700 hover:border-cyan-500/30'
                                    }`}
                                >
                                    <p className="text-white font-semibold text-sm">{player.name}</p>
                                    <p className="text-slate-400 text-xs">{player.position}</p>
                                    <p className="text-emerald-400 text-sm mt-1">€{player.market_value}M</p>
                                </motion.div>
                            ))}
                        </div>
                    )}

                    {prediction && selectedPlayer && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-4"
                        >
                            <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-lg p-6 border border-cyan-500/30">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-2xl font-bold text-white">{selectedPlayer.name}</h3>
                                        <p className="text-slate-300">{selectedPlayer.position} • {selectedPlayer.current_club}</p>
                                    </div>
                                    <Badge className={`bg-${getDemandColor(prediction.market_demand)}-500/20 text-${getDemandColor(prediction.market_demand)}-400`}>
                                        {prediction.market_demand} Demand
                                    </Badge>
                                </div>

                                <div className="grid md:grid-cols-3 gap-4 mb-4">
                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">Predicted Now</p>
                                        <p className="text-3xl font-bold text-cyan-400">€{prediction.current_predicted_value}M</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">In 6 Months</p>
                                        <p className="text-2xl font-bold text-white">€{prediction.value_6_months}M</p>
                                        <p className={`text-xs mt-1 ${
                                            prediction.value_6_months > prediction.current_predicted_value
                                                ? 'text-emerald-400'
                                                : 'text-red-400'
                                        }`}>
                                            {((prediction.value_6_months - prediction.current_predicted_value) / prediction.current_predicted_value * 100).toFixed(1)}%
                                        </p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <p className="text-slate-400 text-sm mb-1">In 12 Months</p>
                                        <p className="text-2xl font-bold text-white">€{prediction.value_12_months}M</p>
                                        <p className={`text-xs mt-1 ${
                                            prediction.value_12_months > prediction.current_predicted_value
                                                ? 'text-emerald-400'
                                                : 'text-red-400'
                                        }`}>
                                            {((prediction.value_12_months - prediction.current_predicted_value) / prediction.current_predicted_value * 100).toFixed(1)}%
                                        </p>
                                    </div>
                                </div>

                                <div className="bg-slate-900/50 rounded-lg p-4 mb-4">
                                    <div className="flex items-center justify-between mb-2">
                                        <p className="text-white font-semibold">Confidence Score</p>
                                        <Badge className="bg-cyan-500/20 text-cyan-400">{prediction.confidence}%</Badge>
                                    </div>
                                    <div className="w-full bg-slate-700 rounded-full h-2">
                                        <div
                                            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full"
                                            style={{ width: `${prediction.confidence}%` }}
                                        />
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-4">
                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                            <TrendingUp className="w-4 h-4 text-emerald-400" />
                                            Key Value Factors
                                        </h4>
                                        <ul className="space-y-2">
                                            {prediction.key_factors?.map((factor, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full mt-1.5" />
                                                    {factor}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <div className="bg-slate-900/50 rounded-lg p-4">
                                        <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                            <AlertCircle className="w-4 h-4 text-red-400" />
                                            Risk Factors
                                        </h4>
                                        <ul className="space-y-2">
                                            {prediction.risk_factors?.map((risk, i) => (
                                                <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                    <div className="w-1.5 h-1.5 bg-red-400 rounded-full mt-1.5" />
                                                    {risk}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>

                                <div className="bg-cyan-500/10 rounded-lg p-4 mt-4 border border-cyan-500/30">
                                    <h4 className="text-cyan-300 font-semibold mb-2">Peak Value Timing</h4>
                                    <p className="text-slate-300 text-sm">{prediction.peak_value_timing}</p>
                                </div>

                                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg p-4 mt-4 border border-purple-500/30">
                                    <h4 className="text-purple-300 font-semibold mb-2">AI Recommendation</h4>
                                    <p className="text-slate-300 text-sm">{prediction.recommendation}</p>
                                </div>
                            </div>
                        </motion.div>
                    )}

                    {!selectedPlayer && (
                        <div className="text-center py-12">
                            <Sparkles className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">Select a player to predict their transfer value</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}