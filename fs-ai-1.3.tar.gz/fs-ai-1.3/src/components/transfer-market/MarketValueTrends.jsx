import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Search, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MarketValueTrends() {
    const [searchTerm, setSearchTerm] = useState('');
    const [positionFilter, setPositionFilter] = useState('all');
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const filteredPlayers = players.filter(p => {
        const matchesSearch = p.name?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesPosition = positionFilter === 'all' || p.position === positionFilter;
        return matchesSearch && matchesPosition;
    });

    const generateTrendData = (player) => {
        if (!player?.market_value) return [];
        
        const currentValue = player.market_value;
        const months = 12;
        const data = [];
        
        for (let i = months; i >= 0; i--) {
            const fluctuation = (Math.random() - 0.5) * 0.15;
            const ageEffect = (player.age < 24) ? 1.02 : (player.age > 30) ? 0.98 : 1;
            const baseValue = currentValue * Math.pow(ageEffect, i / 12);
            const value = baseValue * (1 + fluctuation);
            
            data.push({
                month: new Date(Date.now() - i * 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short' }),
                value: parseFloat(value.toFixed(1))
            });
        }
        
        return data;
    };

    const calculateTrend = (trendData) => {
        if (trendData.length < 2) return 0;
        const firstValue = trendData[0].value;
        const lastValue = trendData[trendData.length - 1].value;
        return ((lastValue - firstValue) / firstValue) * 100;
    };

    const trendData = selectedPlayer ? generateTrendData(selectedPlayer) : [];
    const trendPercentage = trendData.length > 0 ? calculateTrend(trendData) : 0;

    const positions = ['all', 'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                        Market Value Trends
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                            <Input
                                placeholder="Search players..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                        </div>
                        <Select value={positionFilter} onValueChange={setPositionFilter}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {positions.map(pos => (
                                    <SelectItem key={pos} value={pos}>
                                        {pos === 'all' ? 'All Positions' : pos}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {searchTerm && (
                        <div className="grid md:grid-cols-3 gap-3 max-h-64 overflow-y-auto">
                            {filteredPlayers.slice(0, 12).map(player => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    onClick={() => setSelectedPlayer(player)}
                                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                        selectedPlayer?.id === player.id
                                            ? 'bg-emerald-500/20 border-emerald-500/50'
                                            : 'bg-slate-800/50 border-slate-700 hover:border-emerald-500/30'
                                    }`}
                                >
                                    <p className="text-white font-semibold text-sm">{player.name}</p>
                                    <p className="text-slate-400 text-xs">{player.position}</p>
                                    <p className="text-emerald-400 text-sm mt-1">€{player.market_value}M</p>
                                </motion.div>
                            ))}
                        </div>
                    )}

                    {selectedPlayer && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-4"
                        >
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-xl font-bold text-white">{selectedPlayer.name}</h3>
                                        <p className="text-slate-400">{selectedPlayer.current_club} • {selectedPlayer.position}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-2xl font-bold text-emerald-400">€{selectedPlayer.market_value}M</p>
                                        <div className="flex items-center gap-1 justify-end mt-1">
                                            {trendPercentage > 0 ? (
                                                <TrendingUp className="w-4 h-4 text-emerald-400" />
                                            ) : (
                                                <TrendingDown className="w-4 h-4 text-red-400" />
                                            )}
                                            <span className={`text-sm font-semibold ${
                                                trendPercentage > 0 ? 'text-emerald-400' : 'text-red-400'
                                            }`}>
                                                {trendPercentage > 0 ? '+' : ''}{trendPercentage.toFixed(1)}%
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <ResponsiveContainer width="100%" height={300}>
                                    <LineChart data={trendData}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                        <XAxis dataKey="month" stroke="#94a3b8" />
                                        <YAxis stroke="#94a3b8" />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                            labelStyle={{ color: '#cbd5e1' }}
                                        />
                                        <Legend />
                                        <Line
                                            type="monotone"
                                            dataKey="value"
                                            stroke="#10b981"
                                            strokeWidth={2}
                                            dot={{ fill: '#10b981' }}
                                            name="Market Value (€M)"
                                        />
                                    </LineChart>
                                </ResponsiveContainer>

                                <div className="grid grid-cols-3 gap-4 mt-4">
                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs">Age</p>
                                        <p className="text-white font-bold">{selectedPlayer.age} years</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs">Contract Until</p>
                                        <p className="text-white font-bold">
                                            {selectedPlayer.contract_expiry 
                                                ? new Date(selectedPlayer.contract_expiry).getFullYear()
                                                : 'N/A'}
                                        </p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs">League</p>
                                        <p className="text-white font-bold text-sm">{selectedPlayer.league || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    )}

                    {!selectedPlayer && !searchTerm && (
                        <div className="text-center py-12">
                            <Search className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">Search for a player to view market value trends</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}