import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, TrendingUp, AlertTriangle, ArrowRight, RefreshCw, Zap, Brain } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

export default function ProactiveMarketBrief() {
    const [data, setData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const loadBrief = async () => {
        setIsLoading(true);
        try {
            const { data: response } = await base44.functions.invoke('proactiveMarketIntelligence');
            setData(response);
            if (response.alerts?.length > 0) {
                toast.success(`AI identified ${response.alerts.length} new market opportunities`);
            }
        } catch (error) {
            console.error(error);
            toast.error('Failed to generate market brief');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        // Auto-load on mount if not loaded
        loadBrief();
    }, []);

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 'urgent': return 'bg-red-500/20 text-red-400 border-red-500/30';
            case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
            default: return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
        }
    };

    return (
        <Card className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/30 border-slate-800 overflow-hidden relative">
            {/* Background Accent */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-xl">
                    <Brain className="w-6 h-6 text-indigo-400" />
                    AI Proactive Market Intelligence
                </CardTitle>
                <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={loadBrief} 
                    disabled={isLoading}
                    className="text-slate-400 hover:text-indigo-400"
                >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                </Button>
            </CardHeader>

            <CardContent className="space-y-6">
                <AnimatePresence mode="wait">
                    {isLoading ? (
                        <motion.div 
                            initial={{ opacity: 0 }} 
                            animate={{ opacity: 1 }} 
                            exit={{ opacity: 0 }}
                            className="space-y-4"
                        >
                            <div className="h-20 bg-slate-800/50 rounded-lg animate-pulse" />
                            <div className="h-32 bg-slate-800/50 rounded-lg animate-pulse" />
                        </motion.div>
                    ) : data ? (
                        <motion.div 
                            initial={{ opacity: 0, y: 10 }} 
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-6"
                        >
                            {/* Briefing Section */}
                            <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-lg p-4">
                                <div className="flex items-start gap-3">
                                    <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                                    <div>
                                        <h4 className="text-indigo-300 font-medium text-sm mb-1">Daily Market Briefing</h4>
                                        <p className="text-slate-300 text-sm leading-relaxed">
                                            {data.briefing}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Alerts Grid */}
                            <div>
                                <h4 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <Zap className="w-3 h-3" /> Proactive Alerts & Opportunities
                                </h4>
                                <div className="grid md:grid-cols-2 gap-3">
                                    {data.alerts?.map((alert, i) => (
                                        <motion.div 
                                            key={i}
                                            initial={{ opacity: 0, x: -10 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: i * 0.1 }}
                                            className="bg-slate-800/40 border border-slate-700/50 rounded-lg p-3 hover:border-indigo-500/30 transition-colors"
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <Badge variant="outline" className={`${getPriorityColor(alert.priority)} text-[10px] px-2 py-0 h-5`}>
                                                    {alert.type.replace('_', ' ')}
                                                </Badge>
                                                <span className="text-[10px] text-slate-500">Just now</span>
                                            </div>
                                            <h5 className="text-white font-medium text-sm mb-1">{alert.title}</h5>
                                            <p className="text-slate-400 text-xs line-clamp-2">{alert.message}</p>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>

                            {/* Quick Action */}
                            {data.quick_action && (
                                <div className="flex items-center justify-between bg-gradient-to-r from-emerald-900/20 to-teal-900/20 border border-emerald-500/20 rounded-lg p-3">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                                            <TrendingUp className="w-4 h-4 text-emerald-400" />
                                        </div>
                                        <div>
                                            <p className="text-xs text-emerald-300 font-medium">Recommended Action</p>
                                            <p className="text-sm text-white">{data.quick_action}</p>
                                        </div>
                                    </div>
                                    <Button size="sm" variant="ghost" className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10">
                                        Execute <ArrowRight className="w-4 h-4 ml-1" />
                                    </Button>
                                </div>
                            )}
                        </motion.div>
                    ) : (
                        <div className="text-center py-8 text-slate-500">
                            Failed to load intelligence.
                        </div>
                    )}
                </AnimatePresence>
            </CardContent>
        </Card>
    );
}