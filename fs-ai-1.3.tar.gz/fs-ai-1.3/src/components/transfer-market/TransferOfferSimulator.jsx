import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Handshake, Loader2, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

export default function TransferOfferSimulator() {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPlayer, setSelectedPlayer] = useState(null);
    const [offerAmount, setOfferAmount] = useState('');
    const [addOns, setAddOns] = useState('');
    const [paymentStructure, setPaymentStructure] = useState('upfront');
    const [negotiationHistory, setNegotiationHistory] = useState([]);
    const [isNegotiating, setIsNegotiating] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const filteredPlayers = players.filter(p =>
        p.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const simulateOffer = async () => {
        if (!selectedPlayer || !offerAmount) {
            toast.error('Select a player and enter an offer amount');
            return;
        }

        setIsNegotiating(true);
        toast.loading('Simulating negotiation...', { id: 'negotiate' });

        try {
            const prompt = `You are simulating a transfer negotiation for ${selectedPlayer.name}.

Player Details:
- Age: ${selectedPlayer.age}
- Position: ${selectedPlayer.position}
- Current Club: ${selectedPlayer.current_club}
- Market Value: €${selectedPlayer.market_value}M
- Contract Expiry: ${selectedPlayer.contract_expiry || 'Unknown'}

Offer Details:
- Initial Offer: €${offerAmount}M
- Add-ons: €${addOns || 0}M
- Payment Structure: ${paymentStructure}
- Previous Negotiations: ${negotiationHistory.length} rounds

Selling Club Perspective:
- Player importance to squad
- Financial situation
- Replacement availability
- Contract length remaining

Simulate the selling club's response:
1. Accept, Reject, or Counter-offer
2. Reasoning for decision
3. Counter-offer amount (if applicable)
4. Negotiation tactics/demands
5. Probability of deal success

Return this JSON:
{
  "response": "Accept/Reject/Counter-offer",
  "reasoning": "Detailed reasoning for decision",
  "counter_offer": 45.0,
  "demands": ["Demand 1", "Demand 2"],
  "success_probability": 75,
  "next_steps": "What to do next in negotiation",
  "selling_club_strategy": "Their overall strategy",
  "deal_breakers": ["Deal breaker 1", "Deal breaker 2"],
  "negotiation_tips": ["Tip 1", "Tip 2"]
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        response: { type: 'string' },
                        reasoning: { type: 'string' },
                        counter_offer: { type: 'number' },
                        demands: { type: 'array', items: { type: 'string' } },
                        success_probability: { type: 'number' },
                        next_steps: { type: 'string' },
                        selling_club_strategy: { type: 'string' },
                        deal_breakers: { type: 'array', items: { type: 'string' } },
                        negotiation_tips: { type: 'array', items: { type: 'string' } }
                    }
                }
            });

            const negotiationRound = {
                round: negotiationHistory.length + 1,
                yourOffer: parseFloat(offerAmount),
                addOns: parseFloat(addOns || 0),
                structure: paymentStructure,
                clubResponse: data,
                timestamp: new Date().toISOString()
            };

            setNegotiationHistory(prev => [negotiationRound, ...prev]);
            
            if (data.response === 'Counter-offer' && data.counter_offer) {
                setOfferAmount(data.counter_offer.toString());
            }

            toast.success('Negotiation round complete', { id: 'negotiate' });
        } catch (error) {
            console.error('Simulation error:', error);
            toast.error('Simulation failed', { id: 'negotiate' });
        } finally {
            setIsNegotiating(false);
        }
    };

    const resetNegotiation = () => {
        setNegotiationHistory([]);
        setOfferAmount('');
        setAddOns('');
        setPaymentStructure('upfront');
    };

    const getResponseColor = (response) => {
        switch(response) {
            case 'Accept': return 'emerald';
            case 'Reject': return 'red';
            case 'Counter-offer': return 'amber';
            default: return 'slate';
        }
    };

    const getResponseIcon = (response) => {
        switch(response) {
            case 'Accept': return CheckCircle;
            case 'Reject': return AlertCircle;
            case 'Counter-offer': return TrendingUp;
            default: return Handshake;
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Handshake className="w-5 h-5 text-purple-400" />
                        Transfer Offer Simulator
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Select Player</label>
                            <Input
                                placeholder="Search player..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            {searchTerm && (
                                <div className="mt-2 max-h-48 overflow-y-auto space-y-2">
                                    {filteredPlayers.slice(0, 8).map(player => (
                                        <div
                                            key={player.id}
                                            onClick={() => {
                                                setSelectedPlayer(player);
                                                setSearchTerm('');
                                                resetNegotiation();
                                            }}
                                            className="p-2 bg-slate-800 rounded cursor-pointer hover:bg-slate-700 transition-all"
                                        >
                                            <p className="text-white font-semibold text-sm">{player.name}</p>
                                            <p className="text-slate-400 text-xs">
                                                {player.position} • €{player.market_value}M
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {selectedPlayer && (
                            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                <h4 className="text-white font-bold mb-2">{selectedPlayer.name}</h4>
                                <div className="space-y-1 text-sm">
                                    <p className="text-slate-400">
                                        <span className="text-slate-500">Position:</span> {selectedPlayer.position}
                                    </p>
                                    <p className="text-slate-400">
                                        <span className="text-slate-500">Club:</span> {selectedPlayer.current_club}
                                    </p>
                                    <p className="text-emerald-400 font-bold">
                                        <span className="text-slate-500">Market Value:</span> €{selectedPlayer.market_value}M
                                    </p>
                                </div>
                            </div>
                        )}
                    </div>

                    {selectedPlayer && (
                        <div className="grid md:grid-cols-4 gap-4">
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Offer Amount (€M)</label>
                                <Input
                                    type="number"
                                    value={offerAmount}
                                    onChange={(e) => setOfferAmount(e.target.value)}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder={selectedPlayer.market_value}
                                />
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Add-ons (€M)</label>
                                <Input
                                    type="number"
                                    value={addOns}
                                    onChange={(e) => setAddOns(e.target.value)}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    placeholder="0"
                                />
                            </div>
                            <div>
                                <label className="text-slate-400 text-sm mb-2 block">Payment Structure</label>
                                <Select value={paymentStructure} onValueChange={setPaymentStructure}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="upfront">100% Upfront</SelectItem>
                                        <SelectItem value="installments">Installments</SelectItem>
                                        <SelectItem value="mixed">Mixed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="flex items-end gap-2">
                                <Button
                                    onClick={simulateOffer}
                                    disabled={isNegotiating || !offerAmount}
                                    className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600"
                                >
                                    {isNegotiating ? (
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                        'Submit Offer'
                                    )}
                                </Button>
                                {negotiationHistory.length > 0 && (
                                    <Button
                                        onClick={resetNegotiation}
                                        variant="outline"
                                        className="border-slate-700"
                                    >
                                        Reset
                                    </Button>
                                )}
                            </div>
                        </div>
                    )}

                    <AnimatePresence>
                        {negotiationHistory.length > 0 && (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-4"
                            >
                                <div className="flex items-center justify-between">
                                    <h4 className="text-white font-bold">Negotiation History</h4>
                                    <Badge className="bg-purple-500/20 text-purple-400">
                                        {negotiationHistory.length} Rounds
                                    </Badge>
                                </div>

                                {negotiationHistory.map((round, i) => {
                                    const ResponseIcon = getResponseIcon(round.clubResponse.response);
                                    const responseColor = getResponseColor(round.clubResponse.response);

                                    return (
                                        <motion.div
                                            key={i}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                                        >
                                            <div className="flex justify-between items-start mb-4">
                                                <div>
                                                    <Badge variant="outline" className="border-slate-600 text-slate-300 mb-2">
                                                        Round {round.round}
                                                    </Badge>
                                                    <p className="text-white font-semibold">
                                                        Your Offer: €{round.yourOffer}M 
                                                        {round.addOns > 0 && ` + €${round.addOns}M add-ons`}
                                                    </p>
                                                    <p className="text-slate-400 text-xs">
                                                        Structure: {round.structure}
                                                    </p>
                                                </div>
                                                <div className="text-right">
                                                    <Badge className={`bg-${responseColor}-500/20 text-${responseColor}-400 border-${responseColor}-500/30`}>
                                                        <ResponseIcon className="w-3 h-3 mr-1" />
                                                        {round.clubResponse.response}
                                                    </Badge>
                                                    {round.clubResponse.success_probability && (
                                                        <p className="text-xs text-slate-400 mt-1">
                                                            Success: {round.clubResponse.success_probability}%
                                                        </p>
                                                    )}
                                                </div>
                                            </div>

                                            <div className="space-y-3">
                                                <div className="bg-slate-900/50 rounded-lg p-3">
                                                    <p className="text-slate-400 text-xs mb-1">Club Response</p>
                                                    <p className="text-slate-300 text-sm">{round.clubResponse.reasoning}</p>
                                                </div>

                                                {round.clubResponse.counter_offer && (
                                                    <div className="bg-amber-500/10 rounded-lg p-3 border border-amber-500/30">
                                                        <p className="text-amber-300 font-semibold text-sm">
                                                            Counter-offer: €{round.clubResponse.counter_offer}M
                                                        </p>
                                                    </div>
                                                )}

                                                {round.clubResponse.demands?.length > 0 && (
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-2">Club Demands</p>
                                                        <div className="space-y-1">
                                                            {round.clubResponse.demands.map((demand, j) => (
                                                                <p key={j} className="text-slate-300 text-sm flex items-start gap-2">
                                                                    <span className="text-amber-400">•</span>
                                                                    {demand}
                                                                </p>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}

                                                <div className="grid md:grid-cols-2 gap-3">
                                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                                        <p className="text-slate-400 text-xs mb-1">Next Steps</p>
                                                        <p className="text-slate-300 text-sm">{round.clubResponse.next_steps}</p>
                                                    </div>
                                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                                        <p className="text-slate-400 text-xs mb-1">Club Strategy</p>
                                                        <p className="text-slate-300 text-sm">{round.clubResponse.selling_club_strategy}</p>
                                                    </div>
                                                </div>

                                                {round.clubResponse.negotiation_tips?.length > 0 && (
                                                    <div className="bg-cyan-500/10 rounded-lg p-3 border border-cyan-500/30">
                                                        <p className="text-cyan-300 font-semibold text-xs mb-2">Negotiation Tips</p>
                                                        <div className="space-y-1">
                                                            {round.clubResponse.negotiation_tips.map((tip, j) => (
                                                                <p key={j} className="text-slate-300 text-xs flex items-start gap-2">
                                                                    <span className="text-cyan-400">→</span>
                                                                    {tip}
                                                                </p>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </motion.div>
                                    );
                                })}
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {!selectedPlayer && (
                        <div className="text-center py-12">
                            <Handshake className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">Select a player to start simulating transfer offers</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}