import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, Loader2, TrendingUp, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function UndervaluedScanner() {
    const [isScanning, setIsScanning] = useState(false);
    const [bargains, setBargains] = useState(null);
    const [maxBudget, setMaxBudget] = useState('50');
    const [targetPosition, setTargetPosition] = useState('all');

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: activeStrategy } = useQuery({
        queryKey: ['activeStrategy'],
        queryFn: async () => {
            const strategies = await base44.entities.TeamStrategy.filter({ active: true });
            return strategies[0];
        }
    });

    const scanForBargains = async () => {
        setIsScanning(true);
        toast.loading('Scanning market for bargains...', { id: 'scan' });

        try {
            const eligiblePlayers = players.filter(p =>
                p.market_value &&
                p.market_value <= parseFloat(maxBudget) &&
                (targetPosition === 'all' || p.position === targetPosition)
            );

            const topPlayers = eligiblePlayers
                .sort((a, b) => (b.fsai_proprietary_score || 0) - (a.fsai_proprietary_score || 0))
                .slice(0, 15);

            const prompt = `You are an expert transfer market analyst. Identify the best bargain signings from these players.

Budget: €${maxBudget}M
Target Position: ${targetPosition === 'all' ? 'Any' : targetPosition}
Team Strategy: ${activeStrategy ? `${activeStrategy.formation} ${activeStrategy.playing_style}` : 'Not specified'}

Available Players:
${topPlayers.map(p => `- ${p.name}, ${p.age}y, ${p.position}, €${p.market_value}M, Rating: ${p.fsai_proprietary_score?.toFixed(1) || 'N/A'}, Club: ${p.current_club}`).join('\n')}

Identify 5 best bargains based on:
1. Value for money (performance vs price)
2. Age and potential
3. Tactical fit with team strategy
4. Contract situation
5. Resale value potential

Return this JSON:
{
  "total_budget": ${maxBudget},
  "position_focus": "${targetPosition}",
  "market_analysis": "Brief market overview for this position/budget",
  "bargains": [
    {
      "player_name": "Name",
      "current_value": 15.5,
      "true_value_estimate": 25.0,
      "bargain_score": 95,
      "reasoning": "Why this is a bargain (2 sentences)",
      "tactical_fit": "How they fit team strategy",
      "key_strengths": ["Strength 1", "Strength 2"],
      "resale_potential": "High/Medium/Low",
      "urgency": "Act now/Monitor/No rush"
    }
  ],
  "alternative_strategies": ["Strategy 1", "Strategy 2"]
}`;

            const { data } = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    properties: {
                        total_budget: { type: 'number' },
                        position_focus: { type: 'string' },
                        market_analysis: { type: 'string' },
                        bargains: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    player_name: { type: 'string' },
                                    current_value: { type: 'number' },
                                    true_value_estimate: { type: 'number' },
                                    bargain_score: { type: 'number' },
                                    reasoning: { type: 'string' },
                                    tactical_fit: { type: 'string' },
                                    key_strengths: { type: 'array', items: { type: 'string' } },
                                    resale_potential: { type: 'string' },
                                    urgency: { type: 'string' }
                                }
                            }
                        },
                        alternative_strategies: { type: 'array', items: { type: 'string' } }
                    }
                }
            });

            setBargains(data);
            toast.success('Scan complete', { id: 'scan' });
        } catch (error) {
            console.error('Scan error:', error);
            toast.error('Scan failed', { id: 'scan' });
        } finally {
            setIsScanning(false);
        }
    };

    const getResaleColor = (potential) => {
        switch(potential) {
            case 'High': return 'emerald';
            case 'Medium': return 'amber';
            case 'Low': return 'red';
            default: return 'slate';
        }
    };

    const positions = ['all', 'Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-emerald-400" />
                        Undervalued Player Scanner
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Maximum Budget (€M)</label>
                            <Input
                                type="number"
                                value={maxBudget}
                                onChange={(e) => setMaxBudget(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="50"
                            />
                        </div>
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Target Position</label>
                            <Select value={targetPosition} onValueChange={setTargetPosition}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {positions.map(pos => (
                                        <SelectItem key={pos} value={pos}>
                                            {pos === 'all' ? 'Any Position' : pos}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="flex items-end">
                            <Button
                                onClick={scanForBargains}
                                disabled={isScanning}
                                className="w-full bg-gradient-to-r from-emerald-500 to-cyan-600"
                            >
                                {isScanning ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Scanning...
                                    </>
                                ) : (
                                    <>
                                        <Target className="w-4 h-4 mr-2" />
                                        Find Bargains
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>

                    {bargains && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-4"
                        >
                            <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-lg p-4 border border-emerald-500/30">
                                <h4 className="text-emerald-300 font-semibold mb-2">Market Analysis</h4>
                                <p className="text-slate-300 text-sm">{bargains.market_analysis}</p>
                            </div>

                            <div>
                                <h4 className="text-white font-bold text-lg mb-4">
                                    Top {bargains.bargains?.length} Bargains (Budget: €{bargains.total_budget}M)
                                </h4>
                                <div className="space-y-4">
                                    {bargains.bargains?.map((bargain, i) => {
                                        const player = players.find(p => 
                                            p.name.toLowerCase().includes(bargain.player_name.toLowerCase())
                                        );
                                        const savings = bargain.true_value_estimate - bargain.current_value;
                                        const savingsPercent = (savings / bargain.true_value_estimate) * 100;

                                        return (
                                            <motion.div
                                                key={i}
                                                initial={{ opacity: 0, x: -20 }}
                                                animate={{ opacity: 1, x: 0 }}
                                                transition={{ delay: i * 0.1 }}
                                                className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
                                            >
                                                <div className="flex justify-between items-start mb-3">
                                                    <div>
                                                        <h5 className="text-xl font-bold text-white">{bargain.player_name}</h5>
                                                        <div className="flex items-center gap-2 mt-1">
                                                            <Badge className="bg-emerald-500/20 text-emerald-400">
                                                                {bargain.bargain_score}% Bargain Score
                                                            </Badge>
                                                            <Badge className={`bg-${getResaleColor(bargain.resale_potential)}-500/20 text-${getResaleColor(bargain.resale_potential)}-400`}>
                                                                {bargain.resale_potential} Resale
                                                            </Badge>
                                                            <Badge variant="outline" className="border-slate-600 text-slate-300">
                                                                {bargain.urgency}
                                                            </Badge>
                                                        </div>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-2xl font-bold text-emerald-400">€{bargain.current_value}M</p>
                                                        <p className="text-xs text-slate-400">True value: €{bargain.true_value_estimate}M</p>
                                                        <Badge className="bg-emerald-500/20 text-emerald-400 mt-1">
                                                            Save €{savings.toFixed(1)}M ({savingsPercent.toFixed(0)}%)
                                                        </Badge>
                                                    </div>
                                                </div>

                                                <div className="space-y-3">
                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Why This Is a Bargain</p>
                                                        <p className="text-slate-300 text-sm">{bargain.reasoning}</p>
                                                    </div>

                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Tactical Fit</p>
                                                        <p className="text-slate-300 text-sm">{bargain.tactical_fit}</p>
                                                    </div>

                                                    <div>
                                                        <p className="text-slate-400 text-xs mb-1">Key Strengths</p>
                                                        <div className="flex flex-wrap gap-2">
                                                            {bargain.key_strengths?.map((strength, j) => (
                                                                <Badge key={j} variant="outline" className="border-emerald-500/30 text-emerald-400">
                                                                    {strength}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    {player && (
                                                        <div className="flex justify-between items-center pt-3 border-t border-slate-700">
                                                            <div className="flex gap-4 text-sm">
                                                                <div>
                                                                    <span className="text-slate-400">Age:</span>
                                                                    <span className="text-white ml-1">{player.age}</span>
                                                                </div>
                                                                <div>
                                                                    <span className="text-slate-400">Club:</span>
                                                                    <span className="text-white ml-1">{player.current_club}</span>
                                                                </div>
                                                                <div>
                                                                    <span className="text-slate-400">Position:</span>
                                                                    <span className="text-white ml-1">{player.position}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </motion.div>
                                        );
                                    })}
                                </div>
                            </div>

                            {bargains.alternative_strategies?.length > 0 && (
                                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                        <DollarSign className="w-4 h-4 text-amber-400" />
                                        Alternative Strategies
                                    </h4>
                                    <ul className="space-y-2">
                                        {bargains.alternative_strategies.map((strategy, i) => (
                                            <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                                                <div className="w-1.5 h-1.5 bg-amber-400 rounded-full mt-1.5" />
                                                {strategy}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </motion.div>
                    )}

                    {!bargains && (
                        <div className="text-center py-12">
                            <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">Set your budget and position to scan for bargains</p>
                            <p className="text-slate-500 text-sm mt-2">
                                {players.length} players in database
                            </p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}