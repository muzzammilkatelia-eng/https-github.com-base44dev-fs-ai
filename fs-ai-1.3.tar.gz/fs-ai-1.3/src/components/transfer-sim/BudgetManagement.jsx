import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { DollarSign, Save } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import toast from 'react-hot-toast';

export default function BudgetManagement({ budget, setBudget, activeSimulation }) {
    const [tempBudget, setTempBudget] = React.useState(budget.total);

    const saveBudget = () => {
        setBudget({
            ...budget,
            total: tempBudget,
            remaining: tempBudget - (budget.total - budget.remaining)
        });
        toast.success('Budget updated');
    };

    const budgetData = [
        { name: 'Spent', value: budget.total - budget.remaining },
        { name: 'Remaining', value: budget.remaining }
    ];

    const COLORS = ['#8b5cf6', '#06b6d4'];

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-emerald-400" />
                        Transfer Budget Configuration
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div>
                        <Label className="text-slate-300">Total Transfer Budget (€M)</Label>
                        <div className="flex gap-3 mt-2">
                            <Input
                                type="number"
                                value={tempBudget}
                                onChange={(e) => setTempBudget(Number(e.target.value))}
                                className="bg-slate-800 border-slate-700 text-white"
                            />
                            <Button onClick={saveBudget} className="bg-emerald-600">
                                <Save className="w-4 h-4 mr-2" />
                                Save
                            </Button>
                        </div>
                    </div>

                    <div>
                        <Label className="text-slate-300 mb-3 block">Quick Budget Presets</Label>
                        <div className="grid grid-cols-4 gap-2">
                            {[50, 100, 200, 500].map(amount => (
                                <Button
                                    key={amount}
                                    onClick={() => setTempBudget(amount)}
                                    variant="outline"
                                    className="border-slate-700"
                                >
                                    €{amount}M
                                </Button>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Budget Allocation</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <PieChart>
                                <Pie
                                    data={budgetData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {budgetData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                        <div className="mt-4 space-y-2">
                            <div className="flex justify-between">
                                <span className="text-slate-400">Spent</span>
                                <span className="text-purple-400 font-bold">€{budget.total - budget.remaining}M</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-slate-400">Remaining</span>
                                <span className="text-cyan-400 font-bold">€{budget.remaining}M</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Budget Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-slate-400 text-sm mb-1">Total Budget</p>
                            <p className="text-white text-3xl font-bold">€{budget.total}M</p>
                        </div>
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <p className="text-emerald-400 text-sm mb-1">Available for Transfers</p>
                            <p className="text-white text-2xl font-bold">€{budget.remaining}M</p>
                        </div>
                        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                            <p className="text-purple-400 text-sm mb-1">Committed to Targets</p>
                            <p className="text-white text-2xl font-bold">€{budget.total - budget.remaining}M</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {activeSimulation && (
                <Card className="bg-amber-500/10 border-amber-500/30">
                    <CardHeader>
                        <CardTitle className="text-amber-400">Active Scenario Budget Impact</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-3 gap-4">
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Scenario Cost</p>
                                <p className="text-white text-2xl font-bold">€{activeSimulation.totalCost}M</p>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Budget Impact</p>
                                <p className="text-amber-400 text-2xl font-bold">
                                    {Math.round((activeSimulation.totalCost / budget.total) * 100)}%
                                </p>
                            </div>
                            <div>
                                <p className="text-slate-400 text-sm mb-1">Players</p>
                                <p className="text-white text-2xl font-bold">{activeSimulation.players.length}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}