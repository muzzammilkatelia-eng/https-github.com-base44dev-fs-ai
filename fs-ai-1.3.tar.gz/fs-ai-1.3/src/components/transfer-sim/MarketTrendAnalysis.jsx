import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

export default function MarketTrendAnalysis({ players, projections }) {
    const [trends, setTrends] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);

    const analyzeTrends = async () => {
        setAnalyzing(true);
        toast.loading('Analyzing market trends...', { id: 'trends' });

        try {
            const prompt = `You are a transfer market intelligence analyst. Analyze current market conditions and trends:

MARKET DATA:
- Total Players: ${players.length}
- Avg Market Value: €${(players.reduce((sum, p) => sum + (p.market_value || 0), 0) / players.length).toFixed(1)}M
- Top 10 Most Valuable: ${players.sort((a, b) => (b.market_value || 0) - (a.market_value || 0)).slice(0, 10).map(p => `${p.name} (€${p.market_value}M)`).join(', ')}

PROJECTIONS:
${projections.slice(0, 20).map(p => `- ${p.player_name}: ${p.potential_trajectory}, peak ${p.peak_potential_rating}/10 in ${p.years_to_peak}y`).join('\n')}

Provide market intelligence:

1. **Position Value Trends**: Which positions are most/least valuable now?
2. **Age Premium Analysis**: Which age brackets command highest premiums?
3. **League Market Dynamics**: Value trends by league
4. **Inflation Indicators**: Is market inflating or stabilizing?
5. **Best Value Windows**: When to buy for different player types?
6. **Emerging Opportunities**: Undervalued segments to target now
7. **Price Predictions**: Expected market movements next 6-12 months`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        position_trends: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    avg_value: { type: "number" },
                                    trend: { type: "string" },
                                    demand_level: { type: "string" }
                                }
                            }
                        },
                        age_premium: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age_bracket: { type: "string" },
                                    premium_percent: { type: "number" },
                                    investment_rating: { type: "string" }
                                }
                            }
                        },
                        market_sentiment: {
                            type: "object",
                            properties: {
                                direction: { type: "string" },
                                inflation_rate: { type: "number" },
                                stability: { type: "string" }
                            }
                        },
                        best_value_windows: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    period: { type: "string" },
                                    player_type: { type: "string" },
                                    rationale: { type: "string" }
                                }
                            }
                        },
                        emerging_opportunities: {
                            type: "array",
                            items: { type: "string" }
                        },
                        price_predictions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    segment: { type: "string" },
                                    expected_change: { type: "string" },
                                    confidence: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setTrends(response);
            toast.success('Market analysis complete!', { id: 'trends' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze trends', { id: 'trends' });
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            {!trends ? (
                <Card className="bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-purple-500/30">
                    <CardContent className="py-16">
                        <div className="text-center">
                            <TrendingUp className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                            <h3 className="text-white text-xl font-semibold mb-2">Market Intelligence Engine</h3>
                            <p className="text-slate-400 mb-6">
                                Generate AI-powered market trend analysis and price predictions
                            </p>
                            <Button
                                onClick={analyzeTrends}
                                disabled={analyzing}
                                className="bg-gradient-to-r from-purple-500 to-cyan-600"
                            >
                                {analyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Analyze Market Trends
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            ) : (
                <>
                    {/* Market Sentiment */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Market Sentiment</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid md:grid-cols-3 gap-4">
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-400 text-sm mb-1">Direction</p>
                                    <p className="text-white text-2xl font-bold">{trends.market_sentiment?.direction}</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-400 text-sm mb-1">Inflation Rate</p>
                                    <p className="text-white text-2xl font-bold">{trends.market_sentiment?.inflation_rate}%</p>
                                </div>
                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <p className="text-slate-400 text-sm mb-1">Stability</p>
                                    <p className="text-white text-2xl font-bold">{trends.market_sentiment?.stability}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Position Trends Chart */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Position Value Trends</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={trends.position_trends}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                    <XAxis dataKey="position" stroke="#94a3b8" />
                                    <YAxis stroke="#94a3b8" label={{ value: 'Avg Value (€M)', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip
                                        contentStyle={{
                                            backgroundColor: '#1e293b',
                                            border: '1px solid #475569',
                                            borderRadius: '8px'
                                        }}
                                    />
                                    <Bar dataKey="avg_value" fill="#06b6d4" />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>

                    {/* Best Value Windows */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Best Value Windows</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {trends.best_value_windows?.map((window, idx) => (
                                    <div key={idx} className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <div className="flex items-center gap-3 mb-2">
                                            <Badge className="bg-emerald-500/20 text-emerald-400">{window.period}</Badge>
                                            <Badge className="bg-cyan-500/20 text-cyan-400">{window.player_type}</Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{window.rationale}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Emerging Opportunities */}
                    <Card className="bg-purple-500/10 border-purple-500/30">
                        <CardHeader>
                            <CardTitle className="text-purple-400">Emerging Opportunities</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                {trends.emerging_opportunities?.map((opp, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3 text-slate-300">
                                        <span className="text-purple-400 font-bold mr-2">{idx + 1}.</span>
                                        {opp}
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Button onClick={() => setTrends(null)} variant="outline" className="w-full">
                        Generate New Analysis
                    </Button>
                </>
            )}
        </div>
    );
}