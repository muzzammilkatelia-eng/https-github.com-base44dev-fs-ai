import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Calendar, DollarSign, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function ROIAnalysis({ players, projections, activeSimulation }) {
    if (!activeSimulation) {
        return (
            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="py-16 text-center">
                    <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">Run a transfer simulation to see ROI analysis</p>
                </CardContent>
            </Card>
        );
    }

    const { analysis } = activeSimulation;

    // Generate value projection data
    const projectionYears = 5;
    const valueProjectionData = Array.from({ length: projectionYears + 1 }, (_, i) => {
        const year = new Date().getFullYear() + i;
        const growthRate = analysis.roi_timeline?.expected_return_percent || 20;
        const initialValue = activeSimulation.totalCost;
        const projectedValue = initialValue * Math.pow(1 + growthRate / 100, i);
        
        return {
            year: `Year ${i}`,
            investment: initialValue,
            projected_value: Math.round(projectedValue)
        };
    });

    return (
        <div className="space-y-6">
            {/* ROI Overview */}
            <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Expected ROI</p>
                                <p className="text-4xl font-bold text-emerald-400">
                                    +{analysis.roi_timeline?.expected_return_percent || 0}%
                                </p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Breakeven Time</p>
                                <p className="text-4xl font-bold text-cyan-400">
                                    {analysis.roi_timeline?.breakeven_months || 0}mo
                                </p>
                            </div>
                            <Calendar className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Peak Value</p>
                                <p className="text-4xl font-bold text-purple-400">
                                    {analysis.roi_timeline?.peak_value_years || 0}y
                                </p>
                            </div>
                            <Target className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Value Projection Chart */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">5-Year Value Projection</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={valueProjectionData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="year" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" label={{ value: 'Value (€M)', angle: -90, position: 'insideLeft' }} />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: '#1e293b',
                                    border: '1px solid #475569',
                                    borderRadius: '8px'
                                }}
                            />
                            <Legend />
                            <Line type="monotone" dataKey="investment" stroke="#94a3b8" strokeWidth={2} name="Initial Investment" strokeDasharray="5 5" />
                            <Line type="monotone" dataKey="projected_value" stroke="#10b981" strokeWidth={3} name="Projected Value" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Financial Risk */}
            <Card className={`${
                analysis.financial_risk?.risk_level?.toLowerCase() === 'high' ? 'bg-red-500/10 border-red-500/30' :
                analysis.financial_risk?.risk_level?.toLowerCase() === 'medium' ? 'bg-amber-500/10 border-amber-500/30' :
                'bg-emerald-500/10 border-emerald-500/30'
            }`}>
                <CardHeader>
                    <CardTitle className={
                        analysis.financial_risk?.risk_level?.toLowerCase() === 'high' ? 'text-red-400' :
                        analysis.financial_risk?.risk_level?.toLowerCase() === 'medium' ? 'text-amber-400' :
                        'text-emerald-400'
                    }>
                        Financial Risk Assessment: {analysis.financial_risk?.risk_level}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <h5 className="text-white font-semibold mb-2">Risk Factors</h5>
                        <div className="space-y-1">
                            {analysis.financial_risk?.risk_factors?.map((factor, idx) => (
                                <div key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-amber-400">•</span>
                                    {factor}
                                </div>
                            ))}
                        </div>
                    </div>
                    <div>
                        <h5 className="text-white font-semibold mb-2">Mitigation Strategies</h5>
                        <div className="space-y-1">
                            {analysis.financial_risk?.mitigation_strategies?.map((strategy, idx) => (
                                <div key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                    <span className="text-emerald-400">✓</span>
                                    {strategy}
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Squad Balance */}
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Squad Balance Impact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <div className="flex items-center justify-between mb-3">
                            <h5 className="text-slate-300 font-semibold">Balance Score</h5>
                            <div className="text-3xl font-bold text-cyan-400">
                                {analysis.squad_balance?.balance_score}/10
                            </div>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-3">
                            <div
                                className="bg-gradient-to-r from-cyan-500 to-emerald-500 h-3 rounded-full"
                                style={{ width: `${(analysis.squad_balance?.balance_score / 10) * 100}%` }}
                            />
                        </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                            <h5 className="text-emerald-400 font-semibold mb-2">Strengths Added</h5>
                            <div className="space-y-1">
                                {analysis.squad_balance?.strengths_added?.map((strength, idx) => (
                                    <div key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-emerald-400">+</span>
                                        {strength}
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                            <h5 className="text-amber-400 font-semibold mb-2">Gaps Remaining</h5>
                            <div className="space-y-1">
                                {analysis.squad_balance?.gaps_remaining?.map((gap, idx) => (
                                    <div key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                        <span className="text-amber-400">!</span>
                                        {gap}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Alternative Recommendations */}
            {analysis.alternatives && analysis.alternatives.length > 0 && (
                <Card className="bg-cyan-500/10 border-cyan-500/30">
                    <CardHeader>
                        <CardTitle className="text-cyan-400">Alternative Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            {analysis.alternatives.map((alt, idx) => (
                                <div key={idx} className="bg-slate-800/50 rounded-lg p-3 text-slate-300 text-sm">
                                    {idx + 1}. {alt}
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}