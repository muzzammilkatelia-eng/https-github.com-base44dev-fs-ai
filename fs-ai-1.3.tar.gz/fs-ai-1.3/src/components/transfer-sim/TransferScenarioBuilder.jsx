import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, Trash2, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TransferScenarioBuilder({ players, projections, budget, setBudget, activeSimulation, setActiveSimulation }) {
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [analyzing, setAnalyzing] = useState(false);

    const addPlayer = (playerId) => {
        const player = players.find(p => p.id === playerId);
        if (!player) return;

        if (selectedPlayers.find(p => p.id === playerId)) {
            toast.error('Player already added');
            return;
        }

        if (player.market_value > budget.remaining) {
            toast.error('Insufficient budget');
            return;
        }

        setSelectedPlayers([...selectedPlayers, player]);
        setBudget(prev => ({ ...prev, remaining: prev.remaining - player.market_value }));
        toast.success(`${player.name} added to scenario`);
    };

    const removePlayer = (playerId) => {
        const player = selectedPlayers.find(p => p.id === playerId);
        if (!player) return;

        setSelectedPlayers(selectedPlayers.filter(p => p.id !== playerId));
        setBudget(prev => ({ ...prev, remaining: prev.remaining + player.market_value }));
    };

    const simulateScenario = async () => {
        if (selectedPlayers.length === 0) {
            toast.error('Add players to simulate');
            return;
        }

        setAnalyzing(true);
        toast.loading('AI analyzing transfer scenario...', { id: 'sim' });

        try {
            const prompt = `You are an elite transfer market analyst. Analyze this potential transfer scenario:

BUDGET: €${budget.total}M (€${budget.remaining}M remaining after transfers)
TOTAL INVESTMENT: €${budget.total - budget.remaining}M

TRANSFER TARGETS:
${selectedPlayers.map((p, idx) => {
    const projection = projections.find(pr => pr.player_name?.toLowerCase() === p.name?.toLowerCase());
    return `
${idx + 1}. ${p.name} - ${p.position} (${p.age}y)
   - Cost: €${p.market_value}M
   - League: ${p.league}
   - FS-AI Score: ${p.fsai_proprietary_score || 'N/A'}
   - Investment Grade: ${p.fsai_investment_grade || 'N/A'}
   - Projection: ${projection ? `${projection.potential_trajectory}, peak ${projection.peak_potential_rating}/10 in ${projection.years_to_peak}y` : 'None'}
`;
}).join('\n')}

Provide comprehensive transfer scenario analysis:

1. **Overall Strategic Assessment**: Is this a good transfer window strategy?
2. **Individual Transfer Ratings**: Rate each transfer (0-10)
3. **Squad Balance Analysis**: How would these signings affect team balance?
4. **Financial Risk Assessment**: What are the financial risks?
5. **Expected ROI Timeline**: When would these transfers pay off?
6. **Alternative Recommendations**: Better options or adjustments?
7. **Success Probability**: Overall likelihood of successful integration
8. **Final Verdict**: Approve, adjust, or reject this scenario?`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        strategic_assessment: {
                            type: "object",
                            properties: {
                                rating: { type: "number" },
                                summary: { type: "string" }
                            }
                        },
                        individual_ratings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    rating: { type: "number" },
                                    analysis: { type: "string" }
                                }
                            }
                        },
                        squad_balance: {
                            type: "object",
                            properties: {
                                strengths_added: { type: "array", items: { type: "string" } },
                                gaps_remaining: { type: "array", items: { type: "string" } },
                                balance_score: { type: "number" }
                            }
                        },
                        financial_risk: {
                            type: "object",
                            properties: {
                                risk_level: { type: "string" },
                                risk_factors: { type: "array", items: { type: "string" } },
                                mitigation_strategies: { type: "array", items: { type: "string" } }
                            }
                        },
                        roi_timeline: {
                            type: "object",
                            properties: {
                                breakeven_months: { type: "number" },
                                peak_value_years: { type: "number" },
                                expected_return_percent: { type: "number" }
                            }
                        },
                        alternatives: {
                            type: "array",
                            items: { type: "string" }
                        },
                        success_probability: { type: "number" },
                        final_verdict: {
                            type: "object",
                            properties: {
                                decision: { type: "string" },
                                reasoning: { type: "string" }
                            }
                        }
                    }
                }
            });

            setActiveSimulation({
                players: selectedPlayers,
                analysis: response,
                totalCost: budget.total - budget.remaining,
                timestamp: new Date().toISOString()
            });

            toast.success('Scenario analysis complete!', { id: 'sim' });
        } catch (error) {
            console.error('Simulation failed:', error);
            toast.error('Failed to simulate scenario', { id: 'sim' });
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Add Players to Scenario</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-3">
                        <Select onValueChange={addPlayer}>
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white flex-1">
                                <SelectValue placeholder="Select player to add..." />
                            </SelectTrigger>
                            <SelectContent>
                                {players.map(p => (
                                    <SelectItem key={p.id} value={p.id} disabled={p.market_value > budget.remaining}>
                                        {p.name} - {p.position} (€{p.market_value}M)
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Button
                            onClick={simulateScenario}
                            disabled={analyzing || selectedPlayers.length === 0}
                            className="bg-gradient-to-r from-emerald-500 to-cyan-600"
                        >
                            {analyzing ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Simulate Scenario
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Selected Players */}
            {selectedPlayers.length > 0 && (
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Transfer Targets ({selectedPlayers.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <AnimatePresence>
                                {selectedPlayers.map(player => (
                                    <motion.div
                                        key={player.id}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        exit={{ opacity: 0, x: 20 }}
                                        className="bg-slate-800/50 rounded-lg p-4 flex items-center justify-between"
                                    >
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center">
                                                <span className="text-white font-bold text-lg">
                                                    {player.name.charAt(0)}
                                                </span>
                                            </div>
                                            <div>
                                                <h4 className="text-white font-semibold">{player.name}</h4>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <Badge className="bg-slate-700 text-slate-300">{player.position}</Badge>
                                                    <Badge className="bg-slate-700 text-slate-300">{player.age}y</Badge>
                                                    {player.fsai_investment_grade && (
                                                        <Badge className="bg-purple-500/20 text-purple-400">
                                                            {player.fsai_investment_grade}
                                                        </Badge>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <div className="text-right">
                                                <p className="text-emerald-400 text-2xl font-bold">€{player.market_value}M</p>
                                                <p className="text-slate-400 text-xs">Transfer Fee</p>
                                            </div>
                                            <Button
                                                onClick={() => removePlayer(player.id)}
                                                variant="ghost"
                                                size="icon"
                                                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Analysis Results */}
            {activeSimulation && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                >
                    {/* Strategic Assessment */}
                    <Card className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border-emerald-500/30">
                        <CardHeader>
                            <CardTitle className="text-emerald-400">Strategic Assessment</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between mb-3">
                                <p className="text-slate-300">Overall Strategy Rating</p>
                                <div className="text-4xl font-bold text-emerald-400">
                                    {activeSimulation.analysis.strategic_assessment?.rating}/10
                                </div>
                            </div>
                            <p className="text-slate-300">{activeSimulation.analysis.strategic_assessment?.summary}</p>
                        </CardContent>
                    </Card>

                    {/* Individual Ratings */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardHeader>
                            <CardTitle className="text-white">Individual Transfer Ratings</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                {activeSimulation.analysis.individual_ratings?.map((rating, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <h5 className="text-white font-semibold">{rating.player_name}</h5>
                                            <Badge className={
                                                rating.rating >= 8 ? 'bg-emerald-500/20 text-emerald-400' :
                                                rating.rating >= 6 ? 'bg-cyan-500/20 text-cyan-400' :
                                                'bg-amber-500/20 text-amber-400'
                                            }>
                                                {rating.rating}/10
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{rating.analysis}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Final Verdict */}
                    <Card className={`border-2 ${
                        activeSimulation.analysis.final_verdict?.decision?.toLowerCase().includes('approve') ? 
                        'bg-emerald-500/10 border-emerald-500/50' :
                        activeSimulation.analysis.final_verdict?.decision?.toLowerCase().includes('adjust') ?
                        'bg-amber-500/10 border-amber-500/50' :
                        'bg-red-500/10 border-red-500/50'
                    }`}>
                        <CardHeader>
                            <CardTitle className={
                                activeSimulation.analysis.final_verdict?.decision?.toLowerCase().includes('approve') ?
                                'text-emerald-400' :
                                activeSimulation.analysis.final_verdict?.decision?.toLowerCase().includes('adjust') ?
                                'text-amber-400' : 'text-red-400'
                            }>
                                Final Verdict: {activeSimulation.analysis.final_verdict?.decision}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-white text-lg">{activeSimulation.analysis.final_verdict?.reasoning}</p>
                            <div className="mt-4 flex items-center gap-2">
                                <Badge className="bg-white/10 text-white">
                                    Success Probability: {activeSimulation.analysis.success_probability}%
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </div>
    );
}