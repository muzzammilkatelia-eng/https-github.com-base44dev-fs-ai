import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mic, MicOff, Volume2, VolumeX, Loader2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function EVIVoiceInterface({ onClose, context = '' }) {
    const [isConnected, setIsConnected] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [transcript, setTranscript] = useState([]);
    
    const socketRef = useRef(null);
    const mediaRecorderRef = useRef(null);
    const audioContextRef = useRef(null);
    const audioQueueRef = useRef([]);
    const isPlayingRef = useRef(false);

    useEffect(() => {
        return () => {
            disconnect();
        };
    }, []);

    const connect = async () => {
        setIsLoading(true);
        try {
            // Get access token from backend
            const { data } = await base44.functions.invoke('getHumeAccessToken');
            
            if (!data.access_token) {
                throw new Error('Failed to get access token');
            }

            // Connect to Hume EVI WebSocket
            const wsUrl = `wss://api.hume.ai/v0/evi/chat?access_token=${data.access_token}${data.config_id ? `&config_id=${data.config_id}` : ''}`;
            
            const socket = new WebSocket(wsUrl);
            socketRef.current = socket;

            socket.onopen = () => {
                setIsConnected(true);
                setIsLoading(false);
                toast.success('Voice interface connected');
                
                // Send initial context if provided
                if (context) {
                    socket.send(JSON.stringify({
                        type: 'user_message',
                        message: { role: 'user', content: context }
                    }));
                }
                
                startRecording();
            };

            socket.onmessage = async (event) => {
                const message = JSON.parse(event.data);
                handleMessage(message);
            };

            socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                toast.error('Voice connection error');
                setIsLoading(false);
            };

            socket.onclose = () => {
                setIsConnected(false);
                setIsRecording(false);
                toast('Voice interface disconnected');
            };
        } catch (error) {
            console.error('Connection error:', error);
            toast.error('Failed to connect: ' + error.message);
            setIsLoading(false);
        }
    };

    const disconnect = () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop();
        }
        if (socketRef.current) {
            socketRef.current.close();
        }
        if (audioContextRef.current) {
            audioContextRef.current.close();
        }
        setIsConnected(false);
        setIsRecording(false);
    };

    const handleMessage = async (message) => {
        switch (message.type) {
            case 'user_message':
                setTranscript(prev => [...prev, { role: 'user', content: message.message.content }]);
                break;
            
            case 'assistant_message':
                setTranscript(prev => [...prev, { role: 'assistant', content: message.message.content }]);
                break;
            
            case 'audio_output':
                // Queue audio for playback
                const audioData = base64ToArrayBuffer(message.data);
                audioQueueRef.current.push(audioData);
                if (!isPlayingRef.current) {
                    playNextAudio();
                }
                break;
            
            case 'error':
                console.error('EVI error:', message.message);
                toast.error('Voice error: ' + message.message);
                break;
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm',
                audioBitsPerSecond: 16000
            });
            
            mediaRecorderRef.current = mediaRecorder;

            mediaRecorder.ondataavailable = async (event) => {
                if (event.data.size > 0 && socketRef.current?.readyState === WebSocket.OPEN) {
                    const reader = new FileReader();
                    reader.onload = () => {
                        const base64Audio = reader.result.split(',')[1];
                        socketRef.current.send(JSON.stringify({
                            type: 'audio_input',
                            data: base64Audio
                        }));
                    };
                    reader.readAsDataURL(event.data);
                }
            };

            mediaRecorder.start(100); // Send data every 100ms
            setIsRecording(true);
        } catch (error) {
            console.error('Microphone access error:', error);
            toast.error('Microphone access denied');
        }
    };

    const base64ToArrayBuffer = (base64) => {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    };

    const playNextAudio = async () => {
        if (audioQueueRef.current.length === 0) {
            isPlayingRef.current = false;
            setIsSpeaking(false);
            return;
        }

        isPlayingRef.current = true;
        setIsSpeaking(true);

        const audioData = audioQueueRef.current.shift();

        if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
        }

        try {
            const audioBuffer = await audioContextRef.current.decodeAudioData(audioData);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            
            source.onended = () => {
                playNextAudio();
            };
            
            source.start(0);
        } catch (error) {
            console.error('Audio playback error:', error);
            playNextAudio();
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="fixed bottom-6 right-6 z-50"
            >
                <Card className="bg-slate-900 border-cyan-500/30 shadow-2xl w-96">
                    <CardContent className="pt-6 space-y-4">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
                                <h3 className="text-white font-semibold">Voice Assistant</h3>
                            </div>
                            <Button
                                onClick={onClose}
                                variant="ghost"
                                size="icon"
                                className="text-slate-400 hover:text-white"
                            >
                                <X className="w-4 h-4" />
                            </Button>
                        </div>

                        {!isConnected ? (
                            <Button
                                onClick={connect}
                                disabled={isLoading}
                                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Connecting...
                                    </>
                                ) : (
                                    <>
                                        <Mic className="w-4 h-4 mr-2" />
                                        Start Voice Chat
                                    </>
                                )}
                            </Button>
                        ) : (
                            <>
                                <div className="flex items-center justify-center gap-4">
                                    <div className="text-center">
                                        <div className={`w-20 h-20 rounded-full flex items-center justify-center ${isRecording ? 'bg-red-500/20 border-2 border-red-500' : 'bg-slate-800 border-2 border-slate-700'}`}>
                                            {isRecording ? (
                                                <Mic className="w-8 h-8 text-red-400" />
                                            ) : (
                                                <MicOff className="w-8 h-8 text-slate-500" />
                                            )}
                                        </div>
                                        <p className="text-slate-400 text-xs mt-2">
                                            {isRecording ? 'Listening...' : 'Paused'}
                                        </p>
                                    </div>
                                    
                                    <div className="text-center">
                                        <div className={`w-20 h-20 rounded-full flex items-center justify-center ${isSpeaking ? 'bg-cyan-500/20 border-2 border-cyan-500 animate-pulse' : 'bg-slate-800 border-2 border-slate-700'}`}>
                                            {isSpeaking ? (
                                                <Volume2 className="w-8 h-8 text-cyan-400" />
                                            ) : (
                                                <VolumeX className="w-8 h-8 text-slate-500" />
                                            )}
                                        </div>
                                        <p className="text-slate-400 text-xs mt-2">
                                            {isSpeaking ? 'Speaking...' : 'Silent'}
                                        </p>
                                    </div>
                                </div>

                                <Button
                                    onClick={disconnect}
                                    variant="outline"
                                    className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10"
                                >
                                    End Chat
                                </Button>

                                {transcript.length > 0 && (
                                    <div className="bg-slate-800/50 rounded-lg p-3 max-h-60 overflow-y-auto space-y-2">
                                        {transcript.map((msg, idx) => (
                                            <div
                                                key={idx}
                                                className={`text-sm ${msg.role === 'user' ? 'text-cyan-300' : 'text-slate-300'}`}
                                            >
                                                <strong>{msg.role === 'user' ? 'You:' : 'AI:'}</strong> {msg.content}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </>
                        )}
                    </CardContent>
                </Card>
            </motion.div>
        </AnimatePresence>
    );
}