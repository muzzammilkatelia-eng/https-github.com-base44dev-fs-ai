import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import toast from 'react-hot-toast';

export default function GlobalVoiceAssistant() {
    const [isListening, setIsListening] = useState(false);
    const [transcript, setTranscript] = useState('');
    const [processing, setProcessing] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        // Check for keyboard shortcut (Ctrl/Cmd + K for voice)
        const handleKeyPress = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'm') {
                e.preventDefault();
                toggleVoice();
            }
        };

        window.addEventListener('keydown', handleKeyPress);
        return () => window.removeEventListener('keydown', handleKeyPress);
    }, [isListening]);

    const toggleVoice = () => {
        if (isListening) {
            stopListening();
        } else {
            startListening();
        }
    };

    const startListening = () => {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            toast.error('Voice recognition not supported in this browser');
            return;
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();

        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            setIsListening(true);
            toast.success('Listening... Speak your command');
        };

        recognition.onresult = async (event) => {
            const text = event.results[0][0].transcript;
            setTranscript(text);
            setProcessing(true);
            await processCommand(text);
            setProcessing(false);
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            toast.error('Voice recognition error');
            setIsListening(false);
        };

        recognition.onend = () => {
            setIsListening(false);
        };

        recognition.start();
    };

    const stopListening = () => {
        setIsListening(false);
    };

    const processCommand = async (command) => {
        const lowerCommand = command.toLowerCase();

        // Navigation commands
        if (lowerCommand.includes('dashboard') || lowerCommand.includes('home')) {
            navigate(createPageUrl('Home'));
            toast.success('Navigating to Dashboard');
        } else if (lowerCommand.includes('compare players') || lowerCommand.includes('comparison')) {
            navigate(createPageUrl('PlayerComparison'));
            toast.success('Opening Player Comparison');
        } else if (lowerCommand.includes('scout') && lowerCommand.includes('network')) {
            navigate(createPageUrl('ScoutingNetworkHub'));
            toast.success('Opening Scout Network');
        } else if (lowerCommand.includes('recruitment')) {
            navigate(createPageUrl('RecruitmentHub'));
            toast.success('Opening Recruitment Hub');
        } else if (lowerCommand.includes('ai analysis') || lowerCommand.includes('analyze')) {
            navigate(createPageUrl('AIPlayerAnalysis'));
            toast.success('Opening AI Analysis');
        } else if (lowerCommand.includes('globe') || lowerCommand.includes('map')) {
            navigate(createPageUrl('Globe'));
            toast.success('Opening Globe View');
        } else if (lowerCommand.includes('news')) {
            navigate(createPageUrl('News'));
            toast.success('Opening News');
        } else if (lowerCommand.includes('database')) {
            navigate(createPageUrl('DatabaseExplorer'));
            toast.success('Opening Database');
        } else if (lowerCommand.includes('analytics')) {
            navigate(createPageUrl('PlayerAnalyticsDashboard'));
            toast.success('Opening Analytics');
        } else if (lowerCommand.includes('strategy') || lowerCommand.includes('tactics')) {
            navigate(createPageUrl('TeamStrategy'));
            toast.success('Opening Team Strategy');
        } else if (lowerCommand.includes('rotation')) {
            navigate(createPageUrl('RotationPlanner'));
            toast.success('Opening Rotation Planner');
        } else if (lowerCommand.includes('subscription') || lowerCommand.includes('upgrade')) {
            navigate(createPageUrl('Subscription'));
            toast.success('Opening Subscription');
        }
        // Search commands
        else if (lowerCommand.includes('search for') || lowerCommand.includes('find player')) {
            const playerName = extractPlayerName(command);
            if (playerName) {
                navigate(createPageUrl('PlayerProfile') + `?playerName=${encodeURIComponent(playerName)}`);
                toast.success(`Searching for ${playerName}`);
            } else {
                toast.error('Could not identify player name');
            }
        }
        // AI assistance
        else if (lowerCommand.includes('help') || lowerCommand.includes('what can you do')) {
            toast.success('Try: "Go to dashboard", "Compare players", "Find player Messi", "Open recruitment hub"', {
                duration: 5000
            });
        } else {
            // Use AI to interpret complex commands
            try {
                const response = await base44.integrations.Core.InvokeLLM({
                    prompt: `You are a voice assistant for FS-AI football scouting platform. Interpret this command: "${command}"
                    
Available pages: Home, PlayerComparison, RecruitmentHub, AIPlayerAnalysis, ScoutingNetworkHub, Globe, News, DatabaseExplorer, PlayerAnalyticsDashboard, TeamStrategy, RotationPlanner

Respond with JSON indicating the action:
- If it's navigation: {"action": "navigate", "page": "PageName"}
- If it's a search: {"action": "search", "query": "search term"}
- If unclear: {"action": "unknown", "suggestion": "clarification text"}`,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            action: { type: "string" },
                            page: { type: "string" },
                            query: { type: "string" },
                            suggestion: { type: "string" }
                        }
                    }
                });

                if (response.action === 'navigate' && response.page) {
                    navigate(createPageUrl(response.page));
                    toast.success(`Navigating to ${response.page}`);
                } else if (response.action === 'search' && response.query) {
                    // Trigger global search
                    const event = new CustomEvent('globalSearch', { detail: { query: response.query } });
                    window.dispatchEvent(event);
                    toast.success(`Searching for: ${response.query}`);
                } else {
                    toast.error(response.suggestion || 'Command not recognized. Try "Help" for available commands.');
                }
            } catch (error) {
                toast.error('Could not process command. Try: "Go to dashboard" or "Compare players"');
            }
        }
    };

    const extractPlayerName = (command) => {
        const patterns = [
            /search for (.+)/i,
            /find player (.+)/i,
            /show me (.+)/i,
            /player (.+)/i
        ];

        for (const pattern of patterns) {
            const match = command.match(pattern);
            if (match && match[1]) {
                return match[1].trim();
            }
        }
        return null;
    };

    return (
        <>
            <Button
                onClick={toggleVoice}
                variant="ghost"
                size="icon"
                className={`relative ${isListening ? 'bg-red-500/20 text-red-400' : 'text-slate-400 hover:text-cyan-400'}`}
                title="Voice Assistant (Ctrl/Cmd + M)"
            >
                {processing ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                ) : isListening ? (
                    <MicOff className="w-5 h-5" />
                ) : (
                    <Mic className="w-5 h-5" />
                )}
                {isListening && (
                    <motion.span
                        className="absolute inset-0 rounded-full bg-red-500"
                        animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                    />
                )}
            </Button>

            <AnimatePresence>
                {(isListening || processing) && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        className="fixed bottom-24 left-1/2 transform -translate-x-1/2 z-50"
                    >
                        <div className="bg-slate-900 border border-cyan-500/30 rounded-lg px-6 py-4 shadow-2xl">
                            <div className="flex items-center gap-3">
                                {isListening && (
                                    <motion.div
                                        className="flex gap-1"
                                        animate={{ opacity: [0.5, 1, 0.5] }}
                                        transition={{ duration: 1, repeat: Infinity }}
                                    >
                                        <div className="w-1 h-8 bg-cyan-400 rounded-full" />
                                        <div className="w-1 h-6 bg-cyan-400 rounded-full" />
                                        <div className="w-1 h-10 bg-cyan-400 rounded-full" />
                                        <div className="w-1 h-6 bg-cyan-400 rounded-full" />
                                        <div className="w-1 h-8 bg-cyan-400 rounded-full" />
                                    </motion.div>
                                )}
                                <p className="text-white font-semibold">
                                    {processing ? 'Processing...' : isListening ? 'Listening...' : 'Ready'}
                                </p>
                            </div>
                            {transcript && (
                                <p className="text-slate-400 text-sm mt-2">"{transcript}"</p>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}