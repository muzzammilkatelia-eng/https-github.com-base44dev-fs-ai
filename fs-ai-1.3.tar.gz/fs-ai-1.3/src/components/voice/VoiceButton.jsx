import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Mic } from 'lucide-react';
import EVIVoiceInterface from './EVIVoiceInterface';
import PremiumGate from '@/components/PremiumGate';

export default function VoiceButton({ context = '', label = 'Voice Chat' }) {
    const [showVoice, setShowVoice] = useState(false);

    return (
        <>
            <Button
                onClick={() => setShowVoice(true)}
                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500"
            >
                <Mic className="w-4 h-4 mr-2" />
                {label}
            </Button>

            {showVoice && (
                <PremiumGate>
                    <EVIVoiceInterface
                        onClose={() => setShowVoice(false)}
                        context={context}
                    />
                </PremiumGate>
            )}
        </>
    );
}