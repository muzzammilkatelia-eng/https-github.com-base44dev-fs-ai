import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Target, Clock, Award } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AutomatedSummary({ tasks, commissions }) {
    const completedTasks = tasks.filter(t => t.status === 'Completed');
    const aiFlaggedTasks = tasks.filter(t => t.source === 'AI Flag');
    const avgCompletionTime = completedTasks.length > 0
        ? completedTasks.reduce((sum, task) => {
            if (task.completed_date && task.created_date) {
                const diff = new Date(task.completed_date) - new Date(task.created_date);
                return sum + diff / (1000 * 60 * 60 * 24); // days
            }
            return sum;
        }, 0) / completedTasks.length
        : 0;

    const topPerformers = commissions
        .sort((a, b) => (b.total_commission_earned || 0) - (a.total_commission_earned || 0))
        .slice(0, 5);

    const totalRevenue = commissions.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Total Tasks</p>
                                <p className="text-3xl font-bold text-white">{tasks.length}</p>
                            </div>
                            <Target className="w-8 h-8 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Completion Rate</p>
                                <p className="text-3xl font-bold text-emerald-400">
                                    {tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0}%
                                </p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Avg Completion</p>
                                <p className="text-3xl font-bold text-purple-400">{avgCompletionTime.toFixed(1)}d</p>
                            </div>
                            <Clock className="w-8 h-8 text-purple-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">AI Efficiency</p>
                                <p className="text-3xl font-bold text-amber-400">
                                    {tasks.length > 0 ? Math.round((aiFlaggedTasks.length / tasks.length) * 100) : 0}%
                                </p>
                            </div>
                            <Award className="w-8 h-8 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Top Performing Agents</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {topPerformers.map((agent, idx) => (
                            <motion.div
                                key={agent.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                className="flex items-center justify-between bg-slate-800/50 rounded-lg p-4"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold">
                                        {idx + 1}
                                    </div>
                                    <div>
                                        <p className="text-white font-semibold">{agent.agent_name || agent.agent_email}</p>
                                        <p className="text-slate-400 text-sm">
                                            {commissions.filter(c => c.agent_email === agent.agent_email).length} players signed
                                        </p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-emerald-400 font-bold text-lg">
                                        £{(agent.total_commission_earned || 0).toLocaleString()}
                                    </p>
                                    <p className="text-slate-500 text-xs">Total earned</p>
                                </div>
                            </motion.div>
                        ))}

                        {topPerformers.length === 0 && (
                            <p className="text-slate-500 text-center py-8">No commission data yet</p>
                        )}
                    </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border-purple-500/30">
                    <CardHeader>
                        <CardTitle className="text-white">AI Automation Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">AI Flagged Tasks</span>
                                <Badge className="bg-purple-500/20 text-purple-400">{aiFlaggedTasks.length}</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Manual Tasks</span>
                                <Badge className="bg-slate-500/20 text-slate-400">
                                    {tasks.filter(t => t.source === 'Manual').length}
                                </Badge>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">From Globe</span>
                                <Badge className="bg-cyan-500/20 text-cyan-400">
                                    {tasks.filter(t => t.source === 'Globe Hotspot').length}
                                </Badge>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/30">
                    <CardHeader>
                        <CardTitle className="text-white">Revenue Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Total Revenue</span>
                                <span className="text-emerald-400 font-bold text-xl">
                                    £{totalRevenue.toLocaleString()}
                                </span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Active Players</span>
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    {commissions.filter(c => c.player_active).length}
                                </Badge>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Avg per Player</span>
                                <span className="text-slate-300 font-semibold">
                                    £{commissions.length > 0 ? (totalRevenue / commissions.length).toFixed(0) : 0}
                                </span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}