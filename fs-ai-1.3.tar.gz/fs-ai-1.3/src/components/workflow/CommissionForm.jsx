import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import toast from 'react-hot-toast';

export default function CommissionForm({ user, onClose }) {
    const [formData, setFormData] = useState({
        player_name: '',
        initial_valuation: '',
        signing_date: new Date().toISOString().split('T')[0]
    });

    const queryClient = useQueryClient();

    const createCommissionMutation = useMutation({
        mutationFn: (data) => {
            const initialCommission = (data.initial_valuation * 1000000 * 0.05) / 1.27; // Convert to £, 5%
            return base44.entities.AgentCommission.create({
                ...data,
                agent_email: user.email,
                agent_name: user.full_name,
                initial_commission_amount: initialCommission,
                total_commission_earned: initialCommission,
                career_transfers: []
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agent-commissions'] });
            toast.success('Player signing registered! Commission calculated.');
            onClose();
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        createCommissionMutation.mutate({
            ...formData,
            initial_valuation: parseFloat(formData.initial_valuation)
        });
    };

    const calculatedCommission = formData.initial_valuation 
        ? ((parseFloat(formData.initial_valuation) * 1000000 * 0.05) / 1.27).toFixed(2)
        : 0;

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <Label className="text-slate-400">Player Name *</Label>
                <Input
                    value={formData.player_name}
                    onChange={(e) => setFormData({...formData, player_name: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="e.g., Kylian Mbappé"
                    required
                />
            </div>

            <div>
                <Label className="text-slate-400">Initial Valuation (€ Millions) *</Label>
                <Input
                    type="number"
                    step="0.1"
                    value={formData.initial_valuation}
                    onChange={(e) => setFormData({...formData, initial_valuation: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="25.0"
                    required
                />
            </div>

            <div>
                <Label className="text-slate-400">Signing Date *</Label>
                <Input
                    type="date"
                    value={formData.signing_date}
                    onChange={(e) => setFormData({...formData, signing_date: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    required
                />
            </div>

            {formData.initial_valuation && (
                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                    <p className="text-emerald-400 font-semibold mb-2">Commission Calculation:</p>
                    <p className="text-slate-300 text-sm">
                        Initial Commission (5%): <span className="text-white font-bold">£{parseFloat(calculatedCommission).toLocaleString()}</span>
                    </p>
                    <p className="text-slate-400 text-xs mt-2">
                        + 2.5% on all future transfers for player's career
                    </p>
                </div>
            )}

            <Button 
                type="submit" 
                disabled={createCommissionMutation.isPending}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600"
            >
                Register Signing & Calculate Commission
            </Button>
        </form>
    );
}