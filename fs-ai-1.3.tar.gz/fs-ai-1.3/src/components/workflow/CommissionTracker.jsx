import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DollarSign, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import CommissionForm from './CommissionForm';

export default function CommissionTracker({ commissions, user }) {
    const [showCreateForm, setShowCreateForm] = useState(false);

    const myCommissions = commissions.filter(c => c.agent_email === user?.email);
    const totalEarned = myCommissions.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);
    const pendingPayments = myCommissions.filter(c => c.payment_status === 'Pending');

    const getPaymentStatusColor = (status) => {
        const colors = {
            'Pending': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Processing': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Paid': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Failed': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[status] || '';
    };

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/30">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Total Earned</p>
                                <p className="text-3xl font-bold text-emerald-400">£{totalEarned.toLocaleString()}</p>
                            </div>
                            <DollarSign className="w-10 h-10 text-emerald-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Active Players</p>
                                <p className="text-3xl font-bold text-cyan-400">
                                    {myCommissions.filter(c => c.player_active).length}
                                </p>
                            </div>
                            <TrendingUp className="w-10 h-10 text-cyan-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-slate-400 text-sm">Pending Payments</p>
                                <p className="text-3xl font-bold text-amber-400">{pendingPayments.length}</p>
                            </div>
                            <Clock className="w-10 h-10 text-amber-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-white">Commission Records</h2>
                <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-emerald-500 to-teal-600">
                            + Register Player Signing
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Register Player Signing</DialogTitle>
                        </DialogHeader>
                        <CommissionForm user={user} onClose={() => setShowCreateForm(false)} />
                    </DialogContent>
                </Dialog>
            </div>

            <div className="space-y-4">
                {myCommissions.map((commission) => (
                    <motion.div
                        key={commission.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800 hover:bg-slate-800 transition-colors">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1">{commission.player_name}</h4>
                                        <p className="text-slate-400 text-sm">
                                            Signed: {new Date(commission.signing_date).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <Badge className={getPaymentStatusColor(commission.payment_status)}>
                                        {commission.payment_status}
                                    </Badge>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                    <div>
                                        <p className="text-slate-500 text-xs">Initial Valuation</p>
                                        <p className="text-white font-semibold">€{commission.initial_valuation}M</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs">Initial Commission</p>
                                        <p className="text-emerald-400 font-semibold">
                                            £{commission.initial_commission_amount?.toLocaleString()}
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs">Career Transfers</p>
                                        <p className="text-white font-semibold">{commission.career_transfers?.length || 0}</p>
                                    </div>
                                    <div>
                                        <p className="text-slate-500 text-xs">Total Earned</p>
                                        <p className="text-emerald-400 font-bold">
                                            £{commission.total_commission_earned?.toLocaleString()}
                                        </p>
                                    </div>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-3">
                                    <p className="text-slate-400 text-xs mb-1">Commission Structure:</p>
                                    <p className="text-slate-300 text-sm">
                                        {commission.initial_commission_rate}% initial signing • {commission.transfer_commission_rate}% lifetime transfers
                                    </p>
                                </div>

                                {commission.career_transfers && commission.career_transfers.length > 0 && (
                                    <div className="mt-4">
                                        <p className="text-slate-400 text-sm font-semibold mb-2">Transfer History:</p>
                                        <div className="space-y-2">
                                            {commission.career_transfers.map((transfer, idx) => (
                                                <div key={idx} className="bg-slate-800/30 rounded p-2 text-xs text-slate-400">
                                                    <span className="text-white font-semibold">{transfer.from_club}</span>
                                                    {' → '}
                                                    <span className="text-white font-semibold">{transfer.to_club}</span>
                                                    {' • '}
                                                    €{transfer.transfer_fee}M
                                                    {' • '}
                                                    <span className="text-emerald-400">£{transfer.commission_earned?.toLocaleString()}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}

                {myCommissions.length === 0 && (
                    <div className="text-center py-12">
                        <DollarSign className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400">No commission records yet</p>
                        <p className="text-slate-500 text-sm mt-2">Register player signings to track earnings</p>
                    </div>
                )}
            </div>

            <Card className="bg-cyan-500/10 border-cyan-500/30 mt-8">
                <CardContent className="pt-6">
                    <h3 className="text-cyan-400 font-semibold mb-3">💰 Agent Commission Model</h3>
                    <ul className="space-y-2 text-slate-300 text-sm">
                        <li>• <span className="text-emerald-400 font-bold">5%</span> commission on initial player valuation at signing</li>
                        <li>• <span className="text-emerald-400 font-bold">2.5%</span> commission on all future transfer fees for player's career</li>
                        <li>• Automated payment processing via GoCardless</li>
                        <li>• Real-time tracking of career earnings</li>
                        <li>• Lifetime revenue stream from successful signings</li>
                    </ul>
                </CardContent>
            </Card>
        </div>
    );
}