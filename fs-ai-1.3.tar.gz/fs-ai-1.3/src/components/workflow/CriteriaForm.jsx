import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import toast from 'react-hot-toast';

export default function CriteriaForm({ onClose }) {
    const [formData, setFormData] = useState({
        name: '',
        criteria_type: 'Custom',
        filters: {
            min_potential_rating: '',
            max_age: '',
            positions: [],
            max_valuation: ''
        },
        auto_assign: false,
        default_assignee: '',
        priority_level: 'Medium',
        notification_enabled: true
    });

    const queryClient = useQueryClient();

    const createCriteriaMutation = useMutation({
        mutationFn: (data) => base44.entities.AIScoutingCriteria.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouting-criteria'] });
            toast.success('Criteria created successfully');
            onClose();
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        createCriteriaMutation.mutate(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <Label className="text-slate-400">Criteria Name *</Label>
                <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="e.g., High Potential Under 21"
                    required
                />
            </div>

            <div>
                <Label className="text-slate-400">Type</Label>
                <Select value={formData.criteria_type} onValueChange={(v) => setFormData({...formData, criteria_type: v})}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="High Potential">High Potential</SelectItem>
                        <SelectItem value="Undervalued">Undervalued</SelectItem>
                        <SelectItem value="Urgent">Urgent</SelectItem>
                        <SelectItem value="Position Specific">Position Specific</SelectItem>
                        <SelectItem value="Custom">Custom</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-slate-400">Min Potential Rating</Label>
                    <Input
                        type="number"
                        value={formData.filters.min_potential_rating}
                        onChange={(e) => setFormData({
                            ...formData, 
                            filters: {...formData.filters, min_potential_rating: parseInt(e.target.value) || ''}
                        })}
                        className="bg-slate-800 border-slate-700 text-white"
                        placeholder="85"
                    />
                </div>

                <div>
                    <Label className="text-slate-400">Max Age</Label>
                    <Input
                        type="number"
                        value={formData.filters.max_age}
                        onChange={(e) => setFormData({
                            ...formData, 
                            filters: {...formData.filters, max_age: parseInt(e.target.value) || ''}
                        })}
                        className="bg-slate-800 border-slate-700 text-white"
                        placeholder="23"
                    />
                </div>
            </div>

            <div>
                <Label className="text-slate-400">Max Valuation (€M)</Label>
                <Input
                    type="number"
                    value={formData.filters.max_valuation}
                    onChange={(e) => setFormData({
                        ...formData, 
                        filters: {...formData.filters, max_valuation: parseInt(e.target.value) || ''}
                    })}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="20"
                />
            </div>

            <div className="flex items-center justify-between">
                <Label className="text-slate-400">Auto-assign Tasks</Label>
                <Switch
                    checked={formData.auto_assign}
                    onCheckedChange={(checked) => setFormData({...formData, auto_assign: checked})}
                />
            </div>

            {formData.auto_assign && (
                <div>
                    <Label className="text-slate-400">Default Assignee (Email)</Label>
                    <Input
                        type="email"
                        value={formData.default_assignee}
                        onChange={(e) => setFormData({...formData, default_assignee: e.target.value})}
                        className="bg-slate-800 border-slate-700 text-white"
                    />
                </div>
            )}

            <Button 
                type="submit" 
                disabled={createCriteriaMutation.isPending}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
            >
                Create Criteria
            </Button>
        </form>
    );
}