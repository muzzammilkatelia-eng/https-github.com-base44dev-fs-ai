import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Zap, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import CriteriaForm from './CriteriaForm';
import toast from 'react-hot-toast';

export default function CriteriaManager({ criteria }) {
    const [showCreateForm, setShowCreateForm] = useState(false);
    const queryClient = useQueryClient();

    const toggleCriteriaMutation = useMutation({
        mutationFn: ({ id, active }) => base44.entities.AIScoutingCriteria.update(id, { active }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouting-criteria'] });
            toast.success('Criteria updated');
        }
    });

    const runCriteriaMutation = useMutation({
        mutationFn: async (criteriaId) => {
            const result = await base44.functions.runAIScoutingCriteria({ criteriaId });
            return result;
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: ['scouting-tasks'] });
            toast.success(`${data.tasksCreated || 0} new tasks created from AI flagging`);
        }
    });

    const getCriteriaTypeColor = (type) => {
        const colors = {
            'High Potential': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
            'Undervalued': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Urgent': 'bg-red-500/20 text-red-400 border-red-500/30',
            'Position Specific': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Custom': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[type] || '';
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-xl font-bold text-white">AI Scouting Criteria</h2>
                    <p className="text-slate-400 text-sm">Define rules to automatically flag players</p>
                </div>
                <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-purple-500 to-pink-600">
                            <Plus className="w-4 h-4 mr-2" />
                            Add Criteria
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-3xl">
                        <DialogHeader>
                            <DialogTitle>Create AI Criteria</DialogTitle>
                        </DialogHeader>
                        <CriteriaForm onClose={() => setShowCreateForm(false)} />
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {criteria.map((item) => (
                    <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <CardTitle className="text-white text-lg mb-2">{item.name}</CardTitle>
                                        <Badge className={getCriteriaTypeColor(item.criteria_type)}>
                                            {item.criteria_type}
                                        </Badge>
                                    </div>
                                    <Switch
                                        checked={item.active}
                                        onCheckedChange={(checked) => 
                                            toggleCriteriaMutation.mutate({ id: item.id, active: checked })
                                        }
                                    />
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {item.filters && (
                                        <div className="bg-slate-800/50 rounded-lg p-3">
                                            <p className="text-slate-400 text-sm font-semibold mb-2">Filters:</p>
                                            <div className="space-y-1 text-xs text-slate-500">
                                                {item.filters.min_potential_rating && (
                                                    <p>• Min Potential: {item.filters.min_potential_rating}</p>
                                                )}
                                                {item.filters.max_age && (
                                                    <p>• Max Age: {item.filters.max_age}</p>
                                                )}
                                                {item.filters.positions?.length > 0 && (
                                                    <p>• Positions: {item.filters.positions.join(', ')}</p>
                                                )}
                                                {item.filters.max_valuation && (
                                                    <p>• Max Valuation: €{item.filters.max_valuation}M</p>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            {item.auto_assign && (
                                                <Badge className="bg-cyan-500/20 text-cyan-400 text-xs">
                                                    Auto-assign
                                                </Badge>
                                            )}
                                            {item.notification_enabled && (
                                                <Badge className="bg-amber-500/20 text-amber-400 text-xs">
                                                    Notifications
                                                </Badge>
                                            )}
                                        </div>
                                        <Button
                                            size="sm"
                                            onClick={() => runCriteriaMutation.mutate(item.id)}
                                            disabled={!item.active || runCriteriaMutation.isPending}
                                            className="bg-purple-500 hover:bg-purple-600"
                                        >
                                            <Zap className="w-3 h-3 mr-1" />
                                            Run Now
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}

                {criteria.length === 0 && (
                    <div className="col-span-2 text-center py-12">
                        <Zap className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400">No AI criteria configured yet</p>
                        <p className="text-slate-500 text-sm mt-2">Create criteria to automatically flag players</p>
                    </div>
                )}
            </div>
        </div>
    );
}