import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, Play, CheckCircle2, AlertCircle, Zap, Eye, Edit2, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import TaskForm from './TaskForm';
import TaskDetails from './TaskDetails';
import toast from 'react-hot-toast';

export default function TaskBoard({ tasks, user }) {
    const [selectedTask, setSelectedTask] = useState(null);
    const [showCreateForm, setShowCreateForm] = useState(false);
    const [showDetailsDialog, setShowDetailsDialog] = useState(false);
    const queryClient = useQueryClient();

    const updateTaskMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.ScoutingTask.update(id, data),
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['scouting-tasks'] });
            const newStatus = variables.data.status;
            if (newStatus === 'Completed') {
                toast.success('Task marked as completed!', { icon: '✅' });
            } else if (newStatus === 'In Progress') {
                toast.success('Task started!', { icon: '🚀' });
            }
        }
    });

    const handleStatusChange = (task, newStatus) => {
        const updates = { status: newStatus };
        if (newStatus === 'Completed') {
            updates.completed_date = new Date().toISOString();
        }
        updateTaskMutation.mutate({ id: task.id, data: updates });
    };

    const handleViewDetails = (task) => {
        setSelectedTask(task);
        setShowDetailsDialog(true);
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'Pending': return <Clock className="w-4 h-4" />;
            case 'In Progress': return <Play className="w-4 h-4" />;
            case 'Completed': return <CheckCircle2 className="w-4 h-4" />;
            case 'Blocked': return <AlertCircle className="w-4 h-4" />;
            default: return null;
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            'Pending': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'In Progress': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Completed': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Blocked': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[status] || '';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'Critical': 'bg-red-500/20 text-red-400 border-red-500/30',
            'High': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
            'Medium': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Low': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        };
        return colors[priority] || '';
    };

    const columns = [
        { status: 'Pending', icon: Clock, color: 'text-amber-400' },
        { status: 'In Progress', icon: Play, color: 'text-cyan-400' },
        { status: 'Completed', icon: CheckCircle2, color: 'text-emerald-400' }
    ];

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-white">Scouting Tasks</h2>
                <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
                    <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-indigo-500 to-purple-600">
                            + Create Task
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Create Scouting Task</DialogTitle>
                        </DialogHeader>
                        <TaskForm onClose={() => setShowCreateForm(false)} />
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {columns.map((column) => (
                    <div key={column.status} className="space-y-4">
                        <div className="flex items-center gap-2 mb-4">
                            <column.icon className={`w-5 h-5 ${column.color}`} />
                            <h3 className="text-white font-semibold">{column.status}</h3>
                            <Badge className="bg-slate-700 text-slate-300">
                                {tasks.filter(t => t.status === column.status).length}
                            </Badge>
                        </div>

                        <div className="space-y-3">
                            {tasks.filter(t => t.status === column.status).map((task) => (
                                <motion.div
                                    key={task.id}
                                    layout
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800 transition-colors cursor-pointer">
                                        <CardContent className="p-4">
                                            <div className="flex justify-between items-start mb-3">
                                                <div className="flex-1">
                                                    <h4 className="text-white font-semibold mb-1">{task.player_name}</h4>
                                                    <p className="text-slate-400 text-sm">{task.task_type}</p>
                                                </div>
                                                <Badge className={getPriorityColor(task.priority)}>
                                                    {task.priority}
                                                </Badge>
                                            </div>

                                            {task.source === 'AI Flag' && (
                                                <div className="flex items-center gap-1 mb-2">
                                                    <Zap className="w-3 h-3 text-purple-400" />
                                                    <span className="text-purple-400 text-xs font-semibold">AI Flagged</span>
                                                </div>
                                            )}

                                            {task.player_data && (
                                                <div className="flex gap-2 mb-3 text-xs text-slate-500">
                                                    {task.player_data.position && <span>{task.player_data.position}</span>}
                                                    {task.player_data.age && <span>• {task.player_data.age}y</span>}
                                                    {task.player_data.current_valuation && (
                                                        <span>• €{task.player_data.current_valuation}M</span>
                                                    )}
                                                </div>
                                            )}

                                            {task.assigned_to && (
                                                <p className="text-slate-500 text-xs mb-3">
                                                    Assigned to: {task.assigned_to === user?.email ? 'You' : task.assigned_to}
                                                </p>
                                            )}

                                            {task.due_date && (
                                                <div className="flex items-center gap-1 mb-3">
                                                    <Clock className="w-3 h-3 text-slate-500" />
                                                    <span className="text-slate-500 text-xs">
                                                        Due: {new Date(task.due_date).toLocaleDateString()}
                                                    </span>
                                                </div>
                                            )}

                                            <div className="flex gap-2">
                                                <Button
                                                    size="sm"
                                                    variant="ghost"
                                                    onClick={() => handleViewDetails(task)}
                                                    className="flex-1 bg-slate-700 hover:bg-slate-600 text-white text-xs h-7"
                                                >
                                                    <Eye className="w-3 h-3 mr-1" />
                                                    View
                                                </Button>
                                                <Select
                                                    value={task.status}
                                                    onValueChange={(value) => handleStatusChange(task, value)}
                                                >
                                                    <SelectTrigger className="flex-1 bg-slate-700 border-slate-600 text-white text-xs h-7">
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="Pending">Pending</SelectItem>
                                                        <SelectItem value="In Progress">In Progress</SelectItem>
                                                        <SelectItem value="Completed">Completed</SelectItem>
                                                        <SelectItem value="Blocked">Blocked</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            {/* Task Details Dialog */}
            <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Task Details</DialogTitle>
                    </DialogHeader>
                    {selectedTask && (
                        <TaskDetails 
                            task={selectedTask} 
                            onClose={() => setShowDetailsDialog(false)}
                            onUpdate={(updates) => {
                                updateTaskMutation.mutate({ id: selectedTask.id, data: updates });
                                setShowDetailsDialog(false);
                            }}
                        />
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}