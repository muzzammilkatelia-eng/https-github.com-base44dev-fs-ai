import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
    Calendar, User, Target, FileText, TrendingUp, 
    DollarSign, MapPin, Activity, Link as LinkIcon,
    Save, Plus, MessageSquare
} from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TaskDetails({ task, onClose, onUpdate }) {
    const [notes, setNotes] = useState(task.notes || '');
    const [newNote, setNewNote] = useState('');
    const [taskUpdates, setTaskUpdates] = useState({
        status: task.status,
        priority: task.priority,
        due_date: task.due_date || '',
        assigned_to: task.assigned_to || ''
    });

    const queryClient = useQueryClient();

    // Fetch related player data if available
    const { data: scoutingReport } = useQuery({
        queryKey: ['player-report', task.player_name],
        queryFn: async () => {
            const reports = await base44.entities.ScoutingReport.filter(
                { player_name: task.player_name },
                '-created_date',
                1
            );
            return reports[0];
        },
        enabled: !!task.player_name
    });

    const { data: marketData } = useQuery({
        queryKey: ['market-data', task.player_name],
        queryFn: async () => {
            const feeds = await base44.entities.DataFeed.filter(
                { player_name: task.player_name },
                '-fetched_at',
                1
            );
            return feeds[0];
        },
        enabled: !!task.player_name
    });

    const handleSaveUpdates = () => {
        onUpdate({ ...taskUpdates, notes });
    };

    const handleAddNote = () => {
        if (!newNote.trim()) return;
        const timestamp = new Date().toISOString();
        const updatedNotes = `${notes}\n\n[${new Date(timestamp).toLocaleString()}]\n${newNote}`;
        setNotes(updatedNotes);
        setNewNote('');
        toast.success('Note added');
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-2">{task.player_name}</h2>
                    <div className="flex items-center gap-2 flex-wrap">
                        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                            {task.task_type}
                        </Badge>
                        <Badge className={
                            task.priority === 'Critical' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                            task.priority === 'High' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' :
                            'bg-blue-500/20 text-blue-400 border-blue-500/30'
                        }>
                            {task.priority}
                        </Badge>
                        {task.source === 'AI Flag' && (
                            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                AI Flagged
                            </Badge>
                        )}
                    </div>
                </div>
            </div>

            <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="player">Player Data</TabsTrigger>
                    <TabsTrigger value="notes">Notes</TabsTrigger>
                    <TabsTrigger value="updates">Updates</TabsTrigger>
                </TabsList>

                {/* Details Tab */}
                <TabsContent value="details" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm">Task Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label className="text-slate-400 text-sm flex items-center gap-2">
                                        <Target className="w-4 h-4" />
                                        Status
                                    </Label>
                                    <Select 
                                        value={taskUpdates.status} 
                                        onValueChange={(v) => setTaskUpdates({...taskUpdates, status: v})}
                                    >
                                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Pending">Pending</SelectItem>
                                            <SelectItem value="In Progress">In Progress</SelectItem>
                                            <SelectItem value="Completed">Completed</SelectItem>
                                            <SelectItem value="Blocked">Blocked</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div>
                                    <Label className="text-slate-400 text-sm flex items-center gap-2">
                                        <Activity className="w-4 h-4" />
                                        Priority
                                    </Label>
                                    <Select 
                                        value={taskUpdates.priority} 
                                        onValueChange={(v) => setTaskUpdates({...taskUpdates, priority: v})}
                                    >
                                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Critical">Critical</SelectItem>
                                            <SelectItem value="High">High</SelectItem>
                                            <SelectItem value="Medium">Medium</SelectItem>
                                            <SelectItem value="Low">Low</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div>
                                    <Label className="text-slate-400 text-sm flex items-center gap-2">
                                        <Calendar className="w-4 h-4" />
                                        Due Date
                                    </Label>
                                    <Input
                                        type="date"
                                        value={taskUpdates.due_date}
                                        onChange={(e) => setTaskUpdates({...taskUpdates, due_date: e.target.value})}
                                        className="bg-slate-700 border-slate-600 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400 text-sm flex items-center gap-2">
                                        <User className="w-4 h-4" />
                                        Assigned To
                                    </Label>
                                    <Input
                                        type="email"
                                        value={taskUpdates.assigned_to}
                                        onChange={(e) => setTaskUpdates({...taskUpdates, assigned_to: e.target.value})}
                                        placeholder="agent@example.com"
                                        className="bg-slate-700 border-slate-600 text-white mt-1"
                                    />
                                </div>
                            </div>

                            {task.criteria_met && task.criteria_met.length > 0 && (
                                <div>
                                    <Label className="text-slate-400 text-sm mb-2 block">AI Criteria Met</Label>
                                    <div className="flex flex-wrap gap-2">
                                        {task.criteria_met.map((criteria, idx) => (
                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                                {criteria}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div className="bg-slate-900/50 rounded-lg p-3">
                                    <p className="text-slate-500 text-xs mb-1">Created</p>
                                    <p className="text-white">{new Date(task.created_date).toLocaleString()}</p>
                                </div>
                                {task.completed_date && (
                                    <div className="bg-slate-900/50 rounded-lg p-3">
                                        <p className="text-slate-500 text-xs mb-1">Completed</p>
                                        <p className="text-emerald-400">{new Date(task.completed_date).toLocaleString()}</p>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Player Data Tab */}
                <TabsContent value="player" className="space-y-4">
                    {task.player_data && (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm">Player Profile</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                    {task.player_data.position && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Position</p>
                                            <p className="text-white font-semibold">{task.player_data.position}</p>
                                        </div>
                                    )}
                                    {task.player_data.age && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Age</p>
                                            <p className="text-white font-semibold">{task.player_data.age} years</p>
                                        </div>
                                    )}
                                    {task.player_data.current_valuation && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Valuation</p>
                                            <p className="text-emerald-400 font-semibold">€{task.player_data.current_valuation}M</p>
                                        </div>
                                    )}
                                    {task.player_data.potential_rating && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Potential</p>
                                            <p className="text-cyan-400 font-semibold">{task.player_data.potential_rating}/100</p>
                                        </div>
                                    )}
                                    {task.player_data.region && (
                                        <div className="col-span-2">
                                            <p className="text-slate-500 text-xs mb-1 flex items-center gap-1">
                                                <MapPin className="w-3 h-3" />
                                                Region
                                            </p>
                                            <p className="text-white">{task.player_data.region}</p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {scoutingReport && (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm flex items-center gap-2">
                                    <LinkIcon className="w-4 h-4 text-cyan-400" />
                                    Linked Scouting Report
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="grid grid-cols-4 gap-3">
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-500 text-xs mb-1">Technical</p>
                                        <p className="text-cyan-400 font-bold">{scoutingReport.technical_rating}/100</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-500 text-xs mb-1">Physical</p>
                                        <p className="text-purple-400 font-bold">{scoutingReport.physical_rating}/100</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-500 text-xs mb-1">Tactical</p>
                                        <p className="text-amber-400 font-bold">{scoutingReport.tactical_rating}/100</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-500 text-xs mb-1">Mental</p>
                                        <p className="text-emerald-400 font-bold">{scoutingReport.mental_rating}/100</p>
                                    </div>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs mb-1">Recommendation</p>
                                    <Badge className={
                                        scoutingReport.recommendation === 'Immediate Signing' ? 'bg-emerald-500/20 text-emerald-400' :
                                        scoutingReport.recommendation === 'Monitor Closely' ? 'bg-cyan-500/20 text-cyan-400' :
                                        'bg-slate-500/20 text-slate-400'
                                    }>
                                        {scoutingReport.recommendation}
                                    </Badge>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {marketData && (
                        <Card className="bg-slate-800/50 border-slate-700">
                            <CardHeader>
                                <CardTitle className="text-white text-sm flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4 text-amber-400" />
                                    Market Data
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 gap-3 text-sm">
                                    {marketData.market_value_eur && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">Market Value</p>
                                            <p className="text-amber-400 font-semibold">€{marketData.market_value_eur}M</p>
                                        </div>
                                    )}
                                    {marketData.league && (
                                        <div>
                                            <p className="text-slate-500 text-xs mb-1">League</p>
                                            <p className="text-white">{marketData.league}</p>
                                        </div>
                                    )}
                                    {marketData.trending && (
                                        <div className="col-span-2">
                                            <Badge className="bg-red-500/20 text-red-400">🔥 Trending</Badge>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                {/* Notes Tab */}
                <TabsContent value="notes" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm">Task Notes</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label className="text-slate-400 text-sm">All Notes</Label>
                                <Textarea
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    className="bg-slate-700 border-slate-600 text-white mt-2 min-h-[200px]"
                                    placeholder="Add notes about this scouting task..."
                                />
                            </div>

                            <div className="border-t border-slate-700 pt-4">
                                <Label className="text-slate-400 text-sm mb-2 block">Add Quick Note</Label>
                                <div className="flex gap-2">
                                    <Input
                                        value={newNote}
                                        onChange={(e) => setNewNote(e.target.value)}
                                        placeholder="Quick note..."
                                        className="bg-slate-700 border-slate-600 text-white"
                                        onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
                                    />
                                    <Button 
                                        onClick={handleAddNote}
                                        className="bg-cyan-500 hover:bg-cyan-600"
                                    >
                                        <Plus className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Updates Tab */}
                <TabsContent value="updates" className="space-y-4">
                    <Card className="bg-slate-800/50 border-slate-700">
                        <CardHeader>
                            <CardTitle className="text-white text-sm">Activity Timeline</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="flex gap-3">
                                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                                        <Target className="w-4 h-4 text-cyan-400" />
                                    </div>
                                    <div>
                                        <p className="text-white text-sm font-semibold">Task Created</p>
                                        <p className="text-slate-500 text-xs">{new Date(task.created_date).toLocaleString()}</p>
                                    </div>
                                </div>

                                {task.status === 'In Progress' && (
                                    <div className="flex gap-3">
                                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                                            <Activity className="w-4 h-4 text-purple-400" />
                                        </div>
                                        <div>
                                            <p className="text-white text-sm font-semibold">In Progress</p>
                                            <p className="text-slate-500 text-xs">Currently being worked on</p>
                                        </div>
                                    </div>
                                )}

                                {task.completed_date && (
                                    <div className="flex gap-3">
                                        <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                                            <Target className="w-4 h-4 text-emerald-400" />
                                        </div>
                                        <div>
                                            <p className="text-white text-sm font-semibold">Task Completed</p>
                                            <p className="text-slate-500 text-xs">{new Date(task.completed_date).toLocaleString()}</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex gap-3 justify-end pt-4 border-t border-slate-700">
                <Button 
                    variant="outline" 
                    onClick={onClose}
                    className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700"
                >
                    Cancel
                </Button>
                <Button 
                    onClick={handleSaveUpdates}
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
                >
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                </Button>
            </div>
        </div>
    );
}