import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Search, Link as LinkIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import toast from 'react-hot-toast';

export default function TaskForm({ onClose, linkedPlayer }) {
    const [formData, setFormData] = useState({
        player_name: linkedPlayer?.player_name || '',
        task_type: 'Initial Assessment',
        priority: 'Medium',
        source: 'Manual',
        assigned_to: '',
        due_date: '',
        notes: '',
        player_data: linkedPlayer ? {
            position: linkedPlayer.position,
            age: linkedPlayer.age || linkedPlayer.player_age,
            current_valuation: linkedPlayer.estimated_fee || linkedPlayer.market_value_eur
        } : null
    });

    const queryClient = useQueryClient();

    const createTaskMutation = useMutation({
        mutationFn: (data) => base44.entities.ScoutingTask.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scouting-tasks'] });
            toast.success('Task created successfully');
            onClose();
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        createTaskMutation.mutate(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            {linkedPlayer && (
                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 mb-4">
                    <div className="flex items-center gap-2 mb-2">
                        <LinkIcon className="w-4 h-4 text-cyan-400" />
                        <span className="text-cyan-400 font-semibold text-sm">Linked to Player</span>
                    </div>
                    <p className="text-white text-sm">{linkedPlayer.player_name}</p>
                    <div className="flex gap-2 mt-2 flex-wrap">
                        {linkedPlayer.position && <Badge className="bg-slate-700 text-slate-300">{linkedPlayer.position}</Badge>}
                        {(linkedPlayer.age || linkedPlayer.player_age) && <Badge className="bg-slate-700 text-slate-300">{linkedPlayer.age || linkedPlayer.player_age}y</Badge>}
                    </div>
                </div>
            )}

            <div>
                <Label className="text-slate-400">Player Name *</Label>
                <Input
                    value={formData.player_name}
                    onChange={(e) => setFormData({...formData, player_name: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    required
                    disabled={!!linkedPlayer}
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-slate-400">Task Type *</Label>
                    <Select value={formData.task_type} onValueChange={(v) => setFormData({...formData, task_type: v})}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Initial Assessment">Initial Assessment</SelectItem>
                            <SelectItem value="Deep Dive">Deep Dive</SelectItem>
                            <SelectItem value="Live Match">Live Match</SelectItem>
                            <SelectItem value="Contract Negotiation">Contract Negotiation</SelectItem>
                            <SelectItem value="Medical Check">Medical Check</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                <div>
                    <Label className="text-slate-400">Priority</Label>
                    <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <div>
                <Label className="text-slate-400">Assign To (Email)</Label>
                <Input
                    type="email"
                    value={formData.assigned_to}
                    onChange={(e) => setFormData({...formData, assigned_to: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    placeholder="agent@example.com"
                />
            </div>

            <div>
                <Label className="text-slate-400">Due Date</Label>
                <Input
                    type="date"
                    value={formData.due_date}
                    onChange={(e) => setFormData({...formData, due_date: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                />
            </div>

            <div>
                <Label className="text-slate-400">Notes</Label>
                <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    className="bg-slate-800 border-slate-700 text-white"
                    rows={3}
                />
            </div>

            <Button 
                type="submit" 
                disabled={createTaskMutation.isPending}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-600"
            >
                {createTaskMutation.isPending ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                    </>
                ) : (
                    'Create Task'
                )}
            </Button>
        </form>
    );
}