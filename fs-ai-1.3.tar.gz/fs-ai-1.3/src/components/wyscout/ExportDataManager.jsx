import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, FileJson, FileSpreadsheet, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ExportDataManager({ players = [], dataFeeds = [] }) {
    const [dataType, setDataType] = useState('players');
    const [format, setFormat] = useState('csv');
    const [exporting, setExporting] = useState(false);
    const [selectedFields, setSelectedFields] = useState({
        players: ['name', 'age', 'position', 'current_club', 'nationality', 'market_value'],
        feeds: ['player_name', 'source', 'data_type', 'fetched_at']
    });

    const playerFields = [
        { key: 'name', label: 'Name' },
        { key: 'age', label: 'Age' },
        { key: 'position', label: 'Position' },
        { key: 'current_club', label: 'Current Club' },
        { key: 'league', label: 'League' },
        { key: 'nationality', label: 'Nationality' },
        { key: 'market_value', label: 'Market Value' },
        { key: 'contract_expiry', label: 'Contract Expiry' },
        { key: 'wyscout_data.wyId', label: 'Wyscout ID' },
        { key: 'wyscout_data.height', label: 'Height' },
        { key: 'wyscout_data.weight', label: 'Weight' },
        { key: 'wyscout_data.foot', label: 'Preferred Foot' },
        { key: 'wyscout_data.currentTeam.officialName', label: 'Team Official Name' },
        { key: 'created_date', label: 'Date Added' }
    ];

    const feedFields = [
        { key: 'player_name', label: 'Player Name' },
        { key: 'source', label: 'Source' },
        { key: 'data_type', label: 'Data Type' },
        { key: 'fetched_at', label: 'Fetched At' },
        { key: 'league', label: 'League' },
        { key: 'club', label: 'Club' },
        { key: 'position', label: 'Position' },
        { key: 'age', label: 'Age' },
        { key: 'market_value_eur', label: 'Market Value (EUR)' }
    ];

    const fields = dataType === 'players' ? playerFields : feedFields;
    const currentSelectedFields = selectedFields[dataType];

    const toggleField = (fieldKey) => {
        setSelectedFields(prev => ({
            ...prev,
            [dataType]: prev[dataType].includes(fieldKey)
                ? prev[dataType].filter(f => f !== fieldKey)
                : [...prev[dataType], fieldKey]
        }));
    };

    const getNestedValue = (obj, path) => {
        return path.split('.').reduce((current, key) => current?.[key], obj);
    };

    const exportToCSV = (data, fields) => {
        const headers = fields.map(f => {
            const field = (dataType === 'players' ? playerFields : feedFields).find(pf => pf.key === f);
            return field?.label || f;
        }).join(',');

        const rows = data.map(item => {
            return fields.map(field => {
                const value = getNestedValue(item, field);
                if (value === null || value === undefined) return '';
                if (typeof value === 'object') return JSON.stringify(value).replace(/,/g, ';');
                return String(value).replace(/,/g, ';');
            }).join(',');
        });

        return [headers, ...rows].join('\n');
    };

    const handleExport = () => {
        setExporting(true);
        try {
            const data = dataType === 'players' ? players : dataFeeds;
            
            if (data.length === 0) {
                toast.error('No data available to export');
                setExporting(false);
                return;
            }

            let content, mimeType, filename;

            if (format === 'csv') {
                content = exportToCSV(data, currentSelectedFields);
                mimeType = 'text/csv';
                filename = `${dataType}_export_${new Date().toISOString().split('T')[0]}.csv`;
            } else {
                const exportData = data.map(item => {
                    const filtered = {};
                    currentSelectedFields.forEach(field => {
                        const value = getNestedValue(item, field);
                        filtered[field] = value;
                    });
                    return filtered;
                });
                content = JSON.stringify(exportData, null, 2);
                mimeType = 'application/json';
                filename = `${dataType}_export_${new Date().toISOString().split('T')[0]}.json`;
            }

            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            toast.success(`Exported ${data.length} ${dataType} records!`);
        } catch (error) {
            console.error('Export failed:', error);
            toast.error('Export failed');
        } finally {
            setExporting(false);
        }
    };

    const selectAll = () => {
        setSelectedFields(prev => ({
            ...prev,
            [dataType]: fields.map(f => f.key)
        }));
    };

    const deselectAll = () => {
        setSelectedFields(prev => ({
            ...prev,
            [dataType]: []
        }));
    };

    const dataCount = dataType === 'players' ? players.length : dataFeeds.length;

    return (
        <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <CardTitle className="text-white">Export Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Data Type</label>
                            <Select value={dataType} onValueChange={setDataType}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="players">
                                        Players ({players.length} records)
                                    </SelectItem>
                                    <SelectItem value="feeds">
                                        Data Feeds ({dataFeeds.length} records)
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <label className="text-slate-400 text-sm mb-2 block">Export Format</label>
                            <Select value={format} onValueChange={setFormat}>
                                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="csv">
                                        <div className="flex items-center gap-2">
                                            <FileSpreadsheet className="w-4 h-4" />
                                            CSV (Spreadsheet)
                                        </div>
                                    </SelectItem>
                                    <SelectItem value="json">
                                        <div className="flex items-center gap-2">
                                            <FileJson className="w-4 h-4" />
                                            JSON (Structured)
                                        </div>
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-cyan-400 font-semibold">Ready to Export</p>
                                <p className="text-slate-400 text-sm">
                                    {dataCount} records · {currentSelectedFields.length} fields · {format.toUpperCase()}
                                </p>
                            </div>
                            <Badge className="bg-cyan-500/20 text-cyan-400">
                                {dataCount} records
                            </Badge>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-white">Select Fields to Export</CardTitle>
                        <div className="flex gap-2">
                            <Button onClick={selectAll} size="sm" variant="outline">
                                Select All
                            </Button>
                            <Button onClick={deselectAll} size="sm" variant="outline">
                                Deselect All
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-3">
                        {fields.map((field, idx) => (
                            <motion.div
                                key={field.key}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: idx * 0.02 }}
                                className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                                onClick={() => toggleField(field.key)}
                            >
                                <Checkbox
                                    checked={currentSelectedFields.includes(field.key)}
                                    onCheckedChange={() => toggleField(field.key)}
                                />
                                <label className="text-slate-300 text-sm cursor-pointer flex-1">
                                    {field.label}
                                </label>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-slate-900/50 border-slate-800">
                <CardContent className="pt-6">
                    <Button
                        onClick={handleExport}
                        disabled={exporting || currentSelectedFields.length === 0 || dataCount === 0}
                        className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500"
                        size="lg"
                    >
                        {exporting ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                Exporting...
                            </>
                        ) : (
                            <>
                                <Download className="w-5 h-5 mr-2" />
                                Export {dataCount} Records
                            </>
                        )}
                    </Button>
                    {currentSelectedFields.length === 0 && (
                        <p className="text-amber-400 text-sm text-center mt-3">
                            Please select at least one field to export
                        </p>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}