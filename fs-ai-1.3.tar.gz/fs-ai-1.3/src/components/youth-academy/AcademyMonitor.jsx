import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { School, Loader2, Users, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function AcademyMonitor() {
    const [academies, setAcademies] = useState(null);
    const [loading, setLoading] = useState(false);

    const identifyTopAcademies = async () => {
        setLoading(true);
        toast.loading('AI analyzing youth academies...', { id: 'academies' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a youth football development expert. Identify the top youth academies and development systems worldwide that are currently producing the most promising talents.

Provide a ranked list of the top 15 youth academies/systems to monitor closely in 2024-2025.

For each academy provide:
- academy_name: Full academy/club name
- country: Country
- city: City/location
- tier: "World Class", "Elite", or "Excellent"
- success_rate: How consistently they produce top talent (0-100)
- notable_graduates: Array of 3-4 recent successful graduates
- current_standouts: Array of 2-3 current prospects to watch
- development_philosophy: Their key approach (1 sentence)
- why_monitor: Why scouts should watch this academy (2-3 sentences)
- best_positions: Array of positions they excel at developing
- avg_breakthrough_age: Typical age their players break through

Focus on academies producing talent NOW (2024-2025), not just historical reputation.

Return as JSON array ranked by overall quality and current output.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            academy_name: { type: "string" },
                            country: { type: "string" },
                            city: { type: "string" },
                            tier: { type: "string" },
                            success_rate: { type: "number" },
                            notable_graduates: { type: "array", items: { type: "string" } },
                            current_standouts: { type: "array", items: { type: "string" } },
                            development_philosophy: { type: "string" },
                            why_monitor: { type: "string" },
                            best_positions: { type: "array", items: { type: "string" } },
                            avg_breakthrough_age: { type: "number" }
                        }
                    }
                }
            });

            setAcademies(result);
            toast.success(`${result.length} priority academies identified!`, { id: 'academies' });
        } catch (error) {
            toast.error('Analysis failed', { id: 'academies' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const tierColors = {
        'World Class': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
        'Elite': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Excellent': 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <School className="w-5 h-5 text-purple-400" />
                    Academy Monitor & Rankings
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <Button
                    onClick={identifyTopAcademies}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing Academies...
                        </>
                    ) : (
                        <>
                            <School className="w-4 h-4 mr-2" />
                            Identify Priority Academies
                        </>
                    )}
                </Button>

                {academies && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-3 pt-4"
                    >
                        <h3 className="text-white font-semibold">Top Academies to Monitor ({academies.length})</h3>
                        {academies.map((academy, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.05 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="flex items-start justify-between">
                                    <div>
                                        <div className="flex items-center gap-2 mb-1">
                                            <Badge className="bg-amber-500/20 text-amber-400">#{idx + 1}</Badge>
                                            <h4 className="text-white font-bold">{academy.academy_name}</h4>
                                        </div>
                                        <p className="text-slate-400 text-sm">
                                            {academy.city}, {academy.country}
                                        </p>
                                    </div>
                                    <div className="text-right space-y-1">
                                        <Badge className={tierColors[academy.tier]}>
                                            {academy.tier}
                                        </Badge>
                                        <p className="text-emerald-400 text-xs font-semibold">
                                            Success: {academy.success_rate}/100
                                        </p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-400 text-xs">Breakthrough Age</p>
                                        <p className="text-white font-semibold">{academy.avg_breakthrough_age}y</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-400 text-xs">Best Positions</p>
                                        <p className="text-white font-semibold text-xs">
                                            {academy.best_positions?.slice(0, 2).join(', ')}
                                        </p>
                                    </div>
                                </div>

                                <div className="bg-blue-500/10 border border-blue-500/30 rounded p-2">
                                    <p className="text-blue-300 text-xs">
                                        <strong>Philosophy:</strong> {academy.development_philosophy}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-emerald-400 text-xs font-semibold mb-1 flex items-center gap-1">
                                        <Users className="w-3 h-3" />
                                        Current Standouts:
                                    </p>
                                    <div className="flex flex-wrap gap-1">
                                        {academy.current_standouts?.map((player, i) => (
                                            <Badge key={i} className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                {player}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <p className="text-cyan-400 text-xs font-semibold mb-1 flex items-center gap-1">
                                        <TrendingUp className="w-3 h-3" />
                                        Notable Graduates:
                                    </p>
                                    <div className="flex flex-wrap gap-1">
                                        {academy.notable_graduates?.map((player, i) => (
                                            <span key={i} className="text-xs bg-cyan-500/10 text-cyan-300 px-2 py-1 rounded">
                                                {player}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <p className="text-slate-300 text-sm leading-relaxed">{academy.why_monitor}</p>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}