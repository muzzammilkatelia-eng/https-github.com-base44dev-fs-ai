import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FileText, Loader2, Download } from 'lucide-react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import toast from 'react-hot-toast';

export default function YouthScoutingBrief() {
    const [playerName, setPlayerName] = useState('');
    const [brief, setBrief] = useState(null);
    const [loading, setLoading] = useState(false);

    const generateBrief = async () => {
        if (!playerName) {
            toast.error('Please enter a player name');
            return;
        }

        setLoading(true);
        toast.loading('Generating youth scouting brief...', { id: 'brief' });

        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite youth football scout. Generate a comprehensive scouting brief for academy player: **${playerName}**

Use current football knowledge (2024-2025 season) to create a detailed report.

# Youth Scouting Brief: ${playerName}

## 1. Player Profile
- Full Name & Age
- Current Club/Academy
- Position(s)
- Nationality
- Physical Profile (height, weight if known)

## 2. Current Development Stage
- Current ability level (out of 100)
- Development curve (ahead/on track/behind schedule)
- Academy level (youth team, reserves, etc.)
- Recent achievements or milestones

## 3. Technical Assessment
Evaluate key technical skills:
- Ball control and first touch
- Passing range and accuracy
- Dribbling ability
- Shooting technique
- Weak foot ability

Rate each area and provide specific observations.

## 4. Physical & Athletic Profile
- Pace and acceleration
- Strength and physicality
- Stamina and fitness
- Agility and balance
- Aerial ability

## 5. Tactical Intelligence
- Positioning and awareness
- Decision-making
- Game reading ability
- Defensive work rate
- Adaptability to systems

## 6. Mental & Character Traits
- Attitude and professionalism
- Leadership qualities
- Resilience and mentality
- Coachability
- Handling pressure

## 7. Potential Ceiling & Timeline
- Peak potential rating (0-100)
- Predicted ceiling (World Class/Elite/Very Good/Good Professional)
- Breakthrough timeline
- Development trajectory

## 8. Comparison & Playing Style
- Similar established player comparison
- Playing style description
- Best tactical role
- Ideal formation fit

## 9. Areas for Improvement
Priority development needs:
1. Most critical area
2. Secondary focus
3. Long-term development goal

## 10. Transfer Market Intelligence
- Current estimated value
- Projected value in 2-3 years
- Contract situation
- Interest from other clubs
- Likelihood of moving

## 11. Scout Recommendation
- Overall rating: A+, A, B+, B, C
- Recommendation: "Immediate Target", "Monitor Closely", "Continue Watching", or "Not Priority"
- Scouting action plan
- Urgency level

## 12. Summary & Verdict
Final 2-3 paragraph assessment with clear recommendation.

Be detailed, professional, and realistic. Use markdown formatting.`,
                add_context_from_internet: true
            });

            setBrief(result);
            toast.success('Brief generated!', { id: 'brief' });
        } catch (error) {
            toast.error('Generation failed', { id: 'brief' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const downloadBrief = () => {
        if (!brief) return;
        
        const blob = new Blob([brief], { type: 'text/markdown' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `youth-brief-${playerName.replace(/\s+/g, '-')}-${Date.now()}.md`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success('Brief downloaded!');
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-amber-400" />
                    Youth Scouting Brief Generator
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex gap-3">
                    <div className="flex-1">
                        <Label className="text-slate-300">Academy Player Name</Label>
                        <Input
                            value={playerName}
                            onChange={(e) => setPlayerName(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Lamine Yamal, Warren Zaire-Emery"
                        />
                    </div>
                    <div className="flex items-end">
                        <Button
                            onClick={generateBrief}
                            disabled={loading}
                            className="bg-gradient-to-r from-amber-500 to-orange-600"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Generating...
                                </>
                            ) : (
                                <>
                                    <FileText className="w-4 h-4 mr-2" />
                                    Generate
                                </>
                            )}
                        </Button>
                    </div>
                </div>

                {brief && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4 pt-4"
                    >
                        <div className="flex justify-end">
                            <Button
                                onClick={downloadBrief}
                                variant="outline"
                                className="border-slate-700"
                            >
                                <Download className="w-4 h-4 mr-2" />
                                Download Brief
                            </Button>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-6 max-h-[600px] overflow-y-auto">
                            <ReactMarkdown className="prose prose-invert prose-sm max-w-none text-white">
                                {brief}
                            </ReactMarkdown>
                        </div>
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}