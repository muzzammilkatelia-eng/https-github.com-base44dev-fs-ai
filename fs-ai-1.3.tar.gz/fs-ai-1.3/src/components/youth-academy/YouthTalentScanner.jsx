import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, TrendingUp, Star, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function YouthTalentScanner() {
    const [criteria, setCriteria] = useState({
        max_age: 21,
        min_age: 15,
        positions: [],
        key_attributes: '',
        min_potential: 75,
        regions: ''
    });
    const [talents, setTalents] = useState(null);
    const [loading, setLoading] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-youth'],
        queryFn: () => base44.entities.Player.list('-updated_date', 500)
    });

    const scanForTalents = async () => {
        setLoading(true);
        toast.loading('AI scanning for youth talents...', { id: 'scan' });

        try {
            // Filter youth players from database
            const youthPlayers = players.filter(p => 
                p.age >= criteria.min_age && 
                p.age <= criteria.max_age
            ).slice(0, 50);

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are an elite youth football scout specializing in identifying the next generation of superstars. Analyze the current football youth landscape and identify top emerging talents.

**Search Criteria:**
- Age Range: ${criteria.min_age}-${criteria.max_age} years
- Target Positions: ${criteria.positions.join(', ') || 'All positions'}
- Key Attributes: ${criteria.key_attributes || 'General excellence'}
- Minimum Potential: ${criteria.min_potential}/100
- Focus Regions: ${criteria.regions || 'Global'}

**Current Database Youth Players (for context):**
${youthPlayers.slice(0, 10).map(p => `- ${p.name} (${p.age}y, ${p.position}, ${p.current_club})`).join('\n')}

Based on current football knowledge (2024-2025 season), identify the top 8-10 most promising youth academy talents who match these criteria.

For each talent provide:
- name: Full name
- age: Current age
- position: Primary position
- current_club: Current club/academy
- nationality: Nationality
- potential_rating: Predicted peak rating (0-100)
- current_rating: Current ability (0-100)
- ceiling: "World Class", "Elite", "Very Good", or "Good"
- breakthrough_timeline: When they might break into first team (e.g., "2025-26", "2026-27")
- key_strengths: Array of 3-4 standout attributes
- development_areas: Array of 2-3 areas to improve
- comparison_player: Similar established player they resemble
- market_value_trajectory: "Rapid Rise", "Steady Growth", or "Moderate"
- why_special: 2-3 sentences explaining their unique qualities

Return as JSON array sorted by potential_rating (highest first).`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            name: { type: "string" },
                            age: { type: "number" },
                            position: { type: "string" },
                            current_club: { type: "string" },
                            nationality: { type: "string" },
                            potential_rating: { type: "number" },
                            current_rating: { type: "number" },
                            ceiling: { type: "string" },
                            breakthrough_timeline: { type: "string" },
                            key_strengths: { type: "array", items: { type: "string" } },
                            development_areas: { type: "array", items: { type: "string" } },
                            comparison_player: { type: "string" },
                            market_value_trajectory: { type: "string" },
                            why_special: { type: "string" }
                        }
                    }
                }
            });

            setTalents(result);
            toast.success(`Found ${result.length} exceptional youth talents!`, { id: 'scan' });
        } catch (error) {
            toast.error('Scan failed', { id: 'scan' });
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const ceilingColors = {
        'World Class': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
        'Elite': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        'Very Good': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        'Good': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
    };

    const trajectoryColors = {
        'Rapid Rise': 'bg-red-500/20 text-red-400',
        'Steady Growth': 'bg-amber-500/20 text-amber-400',
        'Moderate': 'bg-slate-500/20 text-slate-400'
    };

    return (
        <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    Youth Talent Scanner
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                    <div>
                        <Label className="text-slate-300">Min Age</Label>
                        <Input
                            type="number"
                            value={criteria.min_age}
                            onChange={(e) => setCriteria({...criteria, min_age: parseInt(e.target.value)})}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Max Age</Label>
                        <Input
                            type="number"
                            value={criteria.max_age}
                            onChange={(e) => setCriteria({...criteria, max_age: parseInt(e.target.value)})}
                            className="bg-slate-800 border-slate-700 text-white"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Min Potential</Label>
                        <Input
                            type="number"
                            value={criteria.min_potential}
                            onChange={(e) => setCriteria({...criteria, min_potential: parseInt(e.target.value)})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., 80"
                        />
                    </div>
                    <div className="md:col-span-2">
                        <Label className="text-slate-300">Key Attributes</Label>
                        <Input
                            value={criteria.key_attributes}
                            onChange={(e) => setCriteria({...criteria, key_attributes: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Technical skills, pace, vision"
                        />
                    </div>
                    <div>
                        <Label className="text-slate-300">Focus Regions</Label>
                        <Input
                            value={criteria.regions}
                            onChange={(e) => setCriteria({...criteria, regions: e.target.value})}
                            className="bg-slate-800 border-slate-700 text-white"
                            placeholder="e.g., Europe, South America"
                        />
                    </div>
                </div>

                <Button
                    onClick={scanForTalents}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                >
                    {loading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Scanning Global Youth Networks...
                        </>
                    ) : (
                        <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Scan for Youth Talents
                        </>
                    )}
                </Button>

                {talents && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-3 pt-4"
                    >
                        <h3 className="text-white font-semibold flex items-center gap-2">
                            <Star className="w-4 h-4 text-amber-400" />
                            Exceptional Youth Talents Identified ({talents.length})
                        </h3>
                        {talents.map((talent, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.05 * idx }}
                                className="bg-slate-800/50 rounded-lg p-4 space-y-3"
                            >
                                <div className="flex items-start justify-between">
                                    <div>
                                        <div className="flex items-center gap-2 mb-1">
                                            <Badge className="bg-amber-500/20 text-amber-400">#{idx + 1}</Badge>
                                            <h4 className="text-white font-bold text-lg">{talent.name}</h4>
                                        </div>
                                        <p className="text-slate-400 text-sm">
                                            {talent.age}y • {talent.position} • {talent.nationality}
                                        </p>
                                        <p className="text-slate-500 text-xs mt-1">
                                            <MapPin className="w-3 h-3 inline mr-1" />
                                            {talent.current_club}
                                        </p>
                                    </div>
                                    <div className="text-right space-y-1">
                                        <Badge className={ceilingColors[talent.ceiling]}>
                                            {talent.ceiling}
                                        </Badge>
                                        <p className="text-emerald-400 text-xs font-semibold">
                                            Potential: {talent.potential_rating}/100
                                        </p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2 text-sm">
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-400 text-xs">Current Rating</p>
                                        <p className="text-white font-semibold">{talent.current_rating}/100</p>
                                    </div>
                                    <div className="bg-slate-900/50 rounded p-2">
                                        <p className="text-slate-400 text-xs">Breakthrough</p>
                                        <p className="text-white font-semibold">{talent.breakthrough_timeline}</p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Badge className={trajectoryColors[talent.market_value_trajectory]}>
                                        {talent.market_value_trajectory}
                                    </Badge>
                                    <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                                        Style: {talent.comparison_player}
                                    </Badge>
                                </div>

                                <div>
                                    <p className="text-emerald-400 text-xs font-semibold mb-1">Key Strengths:</p>
                                    <div className="flex flex-wrap gap-1">
                                        {talent.key_strengths?.map((strength, i) => (
                                            <span key={i} className="text-xs bg-emerald-500/10 text-emerald-300 px-2 py-1 rounded">
                                                {strength}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <p className="text-amber-400 text-xs font-semibold mb-1">Development Areas:</p>
                                    <div className="flex flex-wrap gap-1">
                                        {talent.development_areas?.map((area, i) => (
                                            <span key={i} className="text-xs bg-amber-500/10 text-amber-300 px-2 py-1 rounded">
                                                {area}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded p-3">
                                    <p className="text-cyan-300 text-sm leading-relaxed">
                                        <TrendingUp className="w-3 h-3 inline mr-1" />
                                        {talent.why_special}
                                    </p>
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </CardContent>
        </Card>
    );
}