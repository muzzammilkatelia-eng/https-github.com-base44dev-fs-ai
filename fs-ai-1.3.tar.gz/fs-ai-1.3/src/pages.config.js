import AIAllocation from './pages/AIAllocation';
import AIAssistant from './pages/AIAssistant';
import AIGovernance from './pages/AIGovernance';
import AIPlayerAnalysis from './pages/AIPlayerAnalysis';
import AIScout from './pages/AIScout';
import AIScoutAutomation from './pages/AIScoutAutomation';
import AIScoutingAssistant from './pages/AIScoutingAssistant';
import AITransferMarket from './pages/AITransferMarket';
import About from './pages/About';
import AdvancedAnalytics from './pages/AdvancedAnalytics';
import AgentCommunications from './pages/AgentCommunications';
import AgentFinisher from './pages/AgentFinisher';
import Alerts from './pages/Alerts';
import Analytics from './pages/Analytics';
import ApacheLicense from './pages/ApacheLicense';
import AutomatedDataImport from './pages/AutomatedDataImport';
import BackupManager from './pages/BackupManager';
import ClubMatching from './pages/ClubMatching';
import CompanySafeguardingStatement from './pages/CompanySafeguardingStatement';
import Contracts from './pages/Contracts';
import Cookies from './pages/Cookies';
import Dashboard from './pages/Dashboard';
import DataProcessing from './pages/DataProcessing';
import DatabaseExplorer from './pages/DatabaseExplorer';
import EthicalAI from './pages/EthicalAI';
import FootballAwarenessEngine from './pages/FootballAwarenessEngine';
import GDPRCompliance from './pages/GDPRCompliance';
import Globe from './pages/Globe';
import Home from './pages/Home';
import ImportPlayers from './pages/ImportPlayers';
import IntelligenceEngine from './pages/IntelligenceEngine';
import InvestorDashboard from './pages/InvestorDashboard';
import LegalResources from './pages/LegalResources';
import LiveMatchAnalysis from './pages/LiveMatchAnalysis';
import MatchAnalysis from './pages/MatchAnalysis';
import MatchSimulation from './pages/MatchSimulation';
import MatchStrategyAdvisor from './pages/MatchStrategyAdvisor';
import News from './pages/News';
import PlayerAnalyticsDashboard from './pages/PlayerAnalyticsDashboard';
import PlayerComparison from './pages/PlayerComparison';
import PlayerDevelopment from './pages/PlayerDevelopment';
import PlayerMapExplorer from './pages/PlayerMapExplorer';
import PlayerProfile from './pages/PlayerProfile';
import PlayerProfileDetail from './pages/PlayerProfileDetail';
import PlayerProjection from './pages/PlayerProjection';
import PredictiveAnalytics from './pages/PredictiveAnalytics';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ProactiveScout from './pages/ProactiveScout';
import RecruitmentAnalytics from './pages/RecruitmentAnalytics';
import RecruitmentHub from './pages/RecruitmentHub';
import Reports from './pages/Reports';
import RotationPlanner from './pages/RotationPlanner';
import Safeguarding from './pages/Safeguarding';
import SafeguardingBadge from './pages/SafeguardingBadge';
import Sales from './pages/Sales';
import ScoutNetwork from './pages/ScoutNetwork';
import ScoutPlayer from './pages/ScoutPlayer';
import ScoutProfile from './pages/ScoutProfile';
import ScoutTermsOfUse from './pages/ScoutTermsOfUse';
import ScoutTraining from './pages/ScoutTraining';
import ScoutingDashboard from './pages/ScoutingDashboard';
import ScoutingNetworkHub from './pages/ScoutingNetworkHub';
import ScoutingWorkflow from './pages/ScoutingWorkflow';
import SecurityStandards from './pages/SecurityStandards';
import SquadBuilder from './pages/SquadBuilder';
import StrategicPlanning from './pages/StrategicPlanning';
import StrategicRecruitment from './pages/StrategicRecruitment';
import Subscription from './pages/Subscription';
import TacticalConsole from './pages/TacticalConsole';
import Tasks from './pages/Tasks';
import Team from './pages/Team';
import TeamArchetypeBuilder from './pages/TeamArchetypeBuilder';
import TeamBuilder from './pages/TeamBuilder';
import TeamManagement from './pages/TeamManagement';
import TeamStrategy from './pages/TeamStrategy';
import TermsOfService from './pages/TermsOfService';
import TransferMarket from './pages/TransferMarket';
import TransferSimulator from './pages/TransferSimulator';
import WyscoutAdmin from './pages/WyscoutAdmin';
import YouthAcademyScout from './pages/YouthAcademyScout';
import FIFARegulations from './pages/FIFARegulations';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AIAllocation": AIAllocation,
    "AIAssistant": AIAssistant,
    "AIGovernance": AIGovernance,
    "AIPlayerAnalysis": AIPlayerAnalysis,
    "AIScout": AIScout,
    "AIScoutAutomation": AIScoutAutomation,
    "AIScoutingAssistant": AIScoutingAssistant,
    "AITransferMarket": AITransferMarket,
    "About": About,
    "AdvancedAnalytics": AdvancedAnalytics,
    "AgentCommunications": AgentCommunications,
    "AgentFinisher": AgentFinisher,
    "Alerts": Alerts,
    "Analytics": Analytics,
    "ApacheLicense": ApacheLicense,
    "AutomatedDataImport": AutomatedDataImport,
    "BackupManager": BackupManager,
    "ClubMatching": ClubMatching,
    "CompanySafeguardingStatement": CompanySafeguardingStatement,
    "Contracts": Contracts,
    "Cookies": Cookies,
    "Dashboard": Dashboard,
    "DataProcessing": DataProcessing,
    "DatabaseExplorer": DatabaseExplorer,
    "EthicalAI": EthicalAI,
    "FootballAwarenessEngine": FootballAwarenessEngine,
    "GDPRCompliance": GDPRCompliance,
    "Globe": Globe,
    "Home": Home,
    "ImportPlayers": ImportPlayers,
    "IntelligenceEngine": IntelligenceEngine,
    "InvestorDashboard": InvestorDashboard,
    "LegalResources": LegalResources,
    "LiveMatchAnalysis": LiveMatchAnalysis,
    "MatchAnalysis": MatchAnalysis,
    "MatchSimulation": MatchSimulation,
    "MatchStrategyAdvisor": MatchStrategyAdvisor,
    "News": News,
    "PlayerAnalyticsDashboard": PlayerAnalyticsDashboard,
    "PlayerComparison": PlayerComparison,
    "PlayerDevelopment": PlayerDevelopment,
    "PlayerMapExplorer": PlayerMapExplorer,
    "PlayerProfile": PlayerProfile,
    "PlayerProfileDetail": PlayerProfileDetail,
    "PlayerProjection": PlayerProjection,
    "PredictiveAnalytics": PredictiveAnalytics,
    "PrivacyPolicy": PrivacyPolicy,
    "ProactiveScout": ProactiveScout,
    "RecruitmentAnalytics": RecruitmentAnalytics,
    "RecruitmentHub": RecruitmentHub,
    "Reports": Reports,
    "RotationPlanner": RotationPlanner,
    "Safeguarding": Safeguarding,
    "SafeguardingBadge": SafeguardingBadge,
    "Sales": Sales,
    "ScoutNetwork": ScoutNetwork,
    "ScoutPlayer": ScoutPlayer,
    "ScoutProfile": ScoutProfile,
    "ScoutTermsOfUse": ScoutTermsOfUse,
    "ScoutTraining": ScoutTraining,
    "ScoutingDashboard": ScoutingDashboard,
    "ScoutingNetworkHub": ScoutingNetworkHub,
    "ScoutingWorkflow": ScoutingWorkflow,
    "SecurityStandards": SecurityStandards,
    "SquadBuilder": SquadBuilder,
    "StrategicPlanning": StrategicPlanning,
    "StrategicRecruitment": StrategicRecruitment,
    "Subscription": Subscription,
    "TacticalConsole": TacticalConsole,
    "Tasks": Tasks,
    "Team": Team,
    "TeamArchetypeBuilder": TeamArchetypeBuilder,
    "TeamBuilder": TeamBuilder,
    "TeamManagement": TeamManagement,
    "TeamStrategy": TeamStrategy,
    "TermsOfService": TermsOfService,
    "TransferMarket": TransferMarket,
    "TransferSimulator": TransferSimulator,
    "WyscoutAdmin": WyscoutAdmin,
    "YouthAcademyScout": YouthAcademyScout,
    "FIFARegulations": FIFARegulations,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};