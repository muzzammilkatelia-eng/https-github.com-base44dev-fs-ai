import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Target, UserSearch } from 'lucide-react';
import ReportAnalyzer from '../components/ai/ReportAnalyzer';
import PlayerRecommendations from '../components/ai/PlayerRecommendations';
import AutomatedProfiling from '../components/ai/AutomatedProfiling';

export default function AIAssistant() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent mb-2">
                        AI Scouting Assistant
                    </h1>
                    <p className="text-slate-400">
                        Intelligent analysis, recommendations, and automated player profiling
                    </p>
                </div>

                {/* Main Tabs */}
                <Tabs defaultValue="analyzer" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                        <TabsTrigger value="analyzer" className="data-[state=active]:bg-purple-500/20">
                            <Sparkles className="w-4 h-4 mr-2" />
                            Report Analyzer
                        </TabsTrigger>
                        <TabsTrigger value="recommendations" className="data-[state=active]:bg-cyan-500/20">
                            <Target className="w-4 h-4 mr-2" />
                            Player Recommendations
                        </TabsTrigger>
                        <TabsTrigger value="profiling" className="data-[state=active]:bg-emerald-500/20">
                            <UserSearch className="w-4 h-4 mr-2" />
                            Automated Profiling
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="analyzer">
                        <ReportAnalyzer />
                    </TabsContent>

                    <TabsContent value="recommendations">
                        <PlayerRecommendations />
                    </TabsContent>

                    <TabsContent value="profiling">
                        <AutomatedProfiling />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}