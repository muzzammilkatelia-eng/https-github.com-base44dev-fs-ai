import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Brain, Shield, Eye, Users } from 'lucide-react';

export default function AIGovernance() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center gap-3 mb-6">
                    <Brain className="w-10 h-10 text-cyan-400" />
                    <div>
                        <h1 className="text-4xl font-bold text-white">AI Governance Framework</h1>
                        <p className="text-slate-400">Universal Master Version</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">3.1 Purpose</h2>
                            <p className="text-slate-300 leading-relaxed">
                                To ensure all AI systems deployed across Al Isa platforms are safe, ethical, transparent, and regulator-ready.
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
                                <Shield className="w-6 h-6" />
                                3.2 Governance Pillars
                            </h2>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li><strong className="text-white">Transparency</strong> — clear disclosures of AI use</li>
                                <li><strong className="text-white">Accountability</strong> — human oversight and audit trails</li>
                                <li><strong className="text-white">Safety</strong> — refusal protocols and emotional protection</li>
                                <li><strong className="text-white">Fairness</strong> — bias mitigation and inclusive design</li>
                                <li><strong className="text-white">Explainability</strong> — clear logic behind AI decisions</li>
                                <li><strong className="text-white">Safeguarding-first</strong> — AI educators trained to prioritise user safety</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <Eye className="w-6 h-6" />
                                3.3 Deployment Controls
                            </h2>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>All AI educators undergo ethical and safeguarding calibration</li>
                                <li>No AI system is deployed without risk assessment and refusal testing</li>
                                <li>Feedback loops allow users to report concerns or request human review</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <Users className="w-6 h-6" />
                                3.4 Oversight
                            </h2>
                            <p className="text-slate-300 leading-relaxed">
                                An internal AI Ethics and Safeguarding Board reviews all deployments quarterly.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}