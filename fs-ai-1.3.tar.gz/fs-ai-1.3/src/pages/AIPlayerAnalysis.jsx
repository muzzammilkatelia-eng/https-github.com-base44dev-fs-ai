import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Sparkles, Search, Loader2, Brain, AlertTriangle, Swords, FileText } from 'lucide-react';
import AIScoutingReportGenerator from '../components/ai-analysis/AIScoutingReportGenerator';
import AIPerformanceTrendPredictor from '../components/ai-analysis/AIPerformanceTrendPredictor';
import AIRecommendationEngine from '../components/ai-analysis/AIRecommendationEngine';
import AIAnomalyDetector from '../components/ai-analysis/AIAnomalyDetector';
import AITransferConflictPredictor from '../components/ai-analysis/AITransferConflictPredictor';
import AIScoutProfileGenerator from '../components/ai-analysis/AIScoutProfileGenerator';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function AIPlayerAnalysis() {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players-ai-analysis'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const filteredPlayers = players.filter(p =>
        p.name?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Brain className="w-8 h-8 text-cyan-400" />
                        AI Player Analysis
                        <HelpTooltip content="Generate comprehensive AI-powered scouting reports, predict performance trends, and get data-driven recommendations for player development and transfers." />
                    </h1>
                    <p className="text-slate-400">
                        AI-powered scouting reports, performance predictions, and strategic recommendations
                    </p>
                </div>

                {/* Player Search */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex gap-3">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <Input
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Search for a player..."
                                    className="pl-10 bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                        </div>

                        {searchQuery && (
                            <div className="mt-4 max-h-60 overflow-y-auto space-y-2">
                                {isLoading ? (
                                    <div className="text-center py-8">
                                        <Loader2 className="w-6 h-6 animate-spin text-cyan-400 mx-auto" />
                                    </div>
                                ) : filteredPlayers.length === 0 ? (
                                    <p className="text-slate-400 text-center py-4">No players found</p>
                                ) : (
                                    filteredPlayers.slice(0, 10).map((player) => (
                                        <button
                                            key={player.id}
                                            onClick={() => {
                                                setSelectedPlayer(player);
                                                setSearchQuery('');
                                            }}
                                            className="w-full text-left bg-slate-800/50 hover:bg-slate-800 rounded-lg p-3 transition-colors"
                                        >
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="text-white font-semibold">{player.name}</p>
                                                    <p className="text-slate-400 text-sm">
                                                        {player.position} • {player.age}y • {player.current_club}
                                                    </p>
                                                </div>
                                                <Sparkles className="w-5 h-5 text-cyan-400" />
                                            </div>
                                        </button>
                                    ))
                                )}
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Market Intelligence (No player needed) */}
                <div className="grid md:grid-cols-2 gap-6">
                    <AIAnomalyDetector />
                    <AITransferConflictPredictor />
                </div>

                {/* Selected Player Analysis */}
                {selectedPlayer ? (
                    <div className="space-y-6">
                        <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-2xl font-bold text-white mb-1">{selectedPlayer.name}</h2>
                                        <p className="text-slate-400">
                                            {selectedPlayer.position} • {selectedPlayer.age} years old • {selectedPlayer.current_club}
                                        </p>
                                        <p className="text-cyan-400 font-semibold mt-1">
                                            Market Value: €{selectedPlayer.market_value}M
                                        </p>
                                    </div>
                                    <Button
                                        onClick={() => setSelectedPlayer(null)}
                                        variant="outline"
                                        className="border-slate-700"
                                    >
                                        Change Player
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        <Tabs defaultValue="report" className="space-y-4">
                            <TabsList className="bg-slate-800 border border-slate-700">
                                <TabsTrigger value="report">Scouting Report</TabsTrigger>
                                <TabsTrigger value="trends">Performance Trends</TabsTrigger>
                                <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                                <TabsTrigger value="profile">Scout Profile</TabsTrigger>
                            </TabsList>

                            <TabsContent value="report">
                                <AIScoutingReportGenerator player={selectedPlayer} />
                            </TabsContent>
                            <TabsContent value="trends">
                                <AIPerformanceTrendPredictor player={selectedPlayer} />
                            </TabsContent>
                            <TabsContent value="recommendations">
                                <AIRecommendationEngine player={selectedPlayer} />
                            </TabsContent>
                            <TabsContent value="profile">
                                <AIScoutProfileGenerator player={selectedPlayer} />
                            </TabsContent>
                        </Tabs>
                    </div>
                ) : (
                    <Card className="bg-slate-800/30 border-slate-700">
                        <CardContent className="py-20 text-center">
                            <Brain className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                            <h3 className="text-white font-semibold mb-2">Select a Player to Analyze</h3>
                            <p className="text-slate-400">
                                Search for a player above to generate AI-powered insights
                            </p>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}