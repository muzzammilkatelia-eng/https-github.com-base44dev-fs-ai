import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, TrendingUp, AlertTriangle, Target, Users } from 'lucide-react';
import EmergingTalentScanner from '../components/ai-scouting/EmergingTalentScanner';
import WonderkidAlerts from '../components/ai-scouting/WonderkidAlerts';
import ContractExpiryMonitor from '../components/ai-scouting/ContractExpiryMonitor';
import ScoutingCriteriaManager from '../components/ai-scouting/ScoutingCriteriaManager';

export default function AIScout() {
    const { data: players = [] } = useQuery({
        queryKey: ['all-players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 500)
    });

    const { data: criteria = [] } = useQuery({
        queryKey: ['scouting-criteria'],
        queryFn: () => base44.entities.AIScoutingCriteria.list()
    });

    const scoredPlayers = players.filter(p => p.fsai_proprietary_score);
    const youngPlayers = players.filter(p => p.age <= 21);
    const expiringContracts = players.filter(p => {
        if (!p.contract_expiry) return false;
        const expiryDate = new Date(p.contract_expiry);
        const monthsUntilExpiry = (expiryDate - new Date()) / (1000 * 60 * 60 * 24 * 30);
        return monthsUntilExpiry <= 6 && monthsUntilExpiry > 0;
    });

    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                        AI Scouting Assistant
                    </h1>
                    <p className="text-slate-400">Proactive talent identification, automated alerts, and intelligent recommendations</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Players Tracked</p>
                                    <p className="text-3xl font-bold text-white">{players.length}</p>
                                </div>
                                <Users className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">FS-AI Scored</p>
                                    <p className="text-3xl font-bold text-white">{scoredPlayers.length}</p>
                                </div>
                                <Brain className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Young Talents</p>
                                    <p className="text-3xl font-bold text-white">{youngPlayers.length}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Contract Alerts</p>
                                    <p className="text-3xl font-bold text-white">{expiringContracts.length}</p>
                                </div>
                                <AlertTriangle className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="scanner" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-900/50 border border-slate-800">
                        <TabsTrigger value="scanner">
                            <Brain className="w-4 h-4 mr-2" />
                            Talent Scanner
                        </TabsTrigger>
                        <TabsTrigger value="wonderkids">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Wonderkids
                        </TabsTrigger>
                        <TabsTrigger value="contracts">
                            <AlertTriangle className="w-4 h-4 mr-2" />
                            Contract Expiry
                        </TabsTrigger>
                        <TabsTrigger value="criteria">
                            <Target className="w-4 h-4 mr-2" />
                            Criteria
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="scanner" className="mt-6">
                        <EmergingTalentScanner players={players} criteria={criteria} />
                    </TabsContent>

                    <TabsContent value="wonderkids" className="mt-6">
                        <WonderkidAlerts players={players} />
                    </TabsContent>

                    <TabsContent value="contracts" className="mt-6">
                        <ContractExpiryMonitor players={players} />
                    </TabsContent>

                    <TabsContent value="criteria" className="mt-6">
                        <ScoutingCriteriaManager criteria={criteria} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}