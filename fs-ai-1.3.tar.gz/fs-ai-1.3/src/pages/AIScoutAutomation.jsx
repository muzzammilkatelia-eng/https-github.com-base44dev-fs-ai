import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Target, TrendingUp, Brain } from 'lucide-react';
import ProactiveScoutingAgent from '../components/ai-scouting/ProactiveScoutingAgent';
import CriteriaManager from '../components/workflow/CriteriaManager';
import PredictiveAnalyticsDashboard from '../components/analytics/PredictiveAnalyticsDashboard';
import { Card, CardContent } from '@/components/ui/card';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function AIScoutAutomation() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 200)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list()
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['scoutingTasks'],
        queryFn: () => base44.entities.ScoutingTask.list('-created_date', 100)
    });

    const autoTasks = tasks?.filter(t => t.source === 'AI Flag') || [];
    const autoReports = reports?.filter(r => r.notes?.includes('Auto-generated')) || [];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Sparkles className="w-8 h-8 text-purple-400" />
                        AI Scouting Automation
                        <HelpTooltip content="Automatically scan players, generate reports, and create scouting tasks based on your custom criteria. The AI works 24/7 to identify talent." />
                    </h1>
                    <p className="text-slate-400">
                        Proactive talent identification with automated report generation and predictive analytics
                    </p>
                </div>

                {/* Stats */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Players Tracked</p>
                                    <p className="text-4xl font-bold text-white">{players.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Auto Reports</p>
                                    <p className="text-4xl font-bold text-white">{autoReports.length}</p>
                                </div>
                                <Sparkles className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Auto Tasks</p>
                                    <p className="text-4xl font-bold text-white">{autoTasks.length}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Projections</p>
                                    <p className="text-4xl font-bold text-white">{projections.length}</p>
                                </div>
                                <Brain className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="automation" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800">
                        <TabsTrigger value="automation">Proactive Agent</TabsTrigger>
                        <TabsTrigger value="criteria">Criteria Manager</TabsTrigger>
                        <TabsTrigger value="predictions">Predictive Analytics</TabsTrigger>
                    </TabsList>

                    <TabsContent value="automation">
                        <ProactiveScoutingAgent players={players} />
                    </TabsContent>

                    <TabsContent value="criteria">
                        <CriteriaManager />
                    </TabsContent>

                    <TabsContent value="predictions">
                        <PredictiveAnalyticsDashboard 
                            players={players}
                            reports={reports}
                            projections={projections}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}