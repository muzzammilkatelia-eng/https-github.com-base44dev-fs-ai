import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Target, Bell, Settings } from 'lucide-react';
import TalentScanner from '../components/ai-scout/TalentScanner';
import AutoReports from '../components/ai-scout/AutoReports';
import AlertSystem from '../components/ai-scout/AlertSystem';
import ScoutingCriteria from '../components/ai-scout/ScoutingCriteria';

export default function AIScoutingAssistant() {
    const { data: players = [] } = useQuery({
        queryKey: ['players-ai-scout'],
        queryFn: () => base44.entities.Player.list('-fsai_proprietary_score', 500)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections-ai-scout'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date')
    });

    const { data: criteria = [] } = useQuery({
        queryKey: ['ai-scouting-criteria'],
        queryFn: () => base44.entities.AIScoutingCriteria.list()
    });

    const scoredPlayers = players.filter(p => p.fsai_proprietary_score);
    const activeCriteria = criteria.filter(c => c.active);

    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        AI Scouting Assistant
                    </h1>
                    <p className="text-slate-400">Proactive talent identification, auto-reports, and intelligent alerts</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Available Players</p>
                                    <p className="text-3xl font-bold text-white">{scoredPlayers.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Criteria</p>
                                    <p className="text-3xl font-bold text-white">{activeCriteria.length}</p>
                                </div>
                                <Settings className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Projections</p>
                                    <p className="text-3xl font-bold text-white">{projections.length}</p>
                                </div>
                                <Brain className="w-8 h-8 text-pink-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Wonderkids</p>
                                    <p className="text-3xl font-bold text-white">
                                        {projections.filter(p => p.potential_trajectory?.includes('Elite')).length}
                                    </p>
                                </div>
                                <Bell className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="scanner" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-900/50 border border-slate-800">
                        <TabsTrigger value="scanner">
                            <Brain className="w-4 h-4 mr-2" />
                            Talent Scanner
                        </TabsTrigger>
                        <TabsTrigger value="reports">
                            <Target className="w-4 h-4 mr-2" />
                            Auto Reports
                        </TabsTrigger>
                        <TabsTrigger value="alerts">
                            <Bell className="w-4 h-4 mr-2" />
                            Alerts
                        </TabsTrigger>
                        <TabsTrigger value="criteria">
                            <Settings className="w-4 h-4 mr-2" />
                            Criteria
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="scanner" className="mt-6">
                        <TalentScanner 
                            players={scoredPlayers} 
                            projections={projections}
                            criteria={activeCriteria}
                        />
                    </TabsContent>

                    <TabsContent value="reports" className="mt-6">
                        <AutoReports 
                            players={scoredPlayers} 
                            projections={projections}
                        />
                    </TabsContent>

                    <TabsContent value="alerts" className="mt-6">
                        <AlertSystem 
                            players={scoredPlayers} 
                            projections={projections}
                        />
                    </TabsContent>

                    <TabsContent value="criteria" className="mt-6">
                        <ScoutingCriteria criteria={criteria} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}