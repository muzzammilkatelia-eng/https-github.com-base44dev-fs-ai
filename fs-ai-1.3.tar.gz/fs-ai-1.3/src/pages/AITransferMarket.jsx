import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Sparkles, Target, Handshake } from 'lucide-react';
import MarketValueTrends from '../components/transfer-market/MarketValueTrends';
import AIValuePredictor from '../components/transfer-market/AIValuePredictor';
import UndervaluedScanner from '../components/transfer-market/UndervaluedScanner';
import TransferOfferSimulator from '../components/transfer-market/TransferOfferSimulator';
import ProactiveMarketBrief from '../components/transfer-market/ProactiveMarketBrief';

export default function AITransferMarket() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Sparkles className="w-8 h-8 text-emerald-400" />
                        AI Transfer Market Analysis
                    </h1>
                    <p className="text-slate-400">
                        Real-time market insights, value predictions, bargain hunting, and offer simulation
                    </p>
                </div>

                <ProactiveMarketBrief />

                <Tabs defaultValue="trends" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4">
                        <TabsTrigger value="trends" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Market Trends
                        </TabsTrigger>
                        <TabsTrigger value="predictor" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            Value Predictor
                        </TabsTrigger>
                        <TabsTrigger value="bargains" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Bargain Hunter
                        </TabsTrigger>
                        <TabsTrigger value="simulator" className="flex items-center gap-2">
                            <Handshake className="w-4 h-4" />
                            Offer Simulator
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="trends">
                        <MarketValueTrends />
                    </TabsContent>

                    <TabsContent value="predictor">
                        <AIValuePredictor />
                    </TabsContent>

                    <TabsContent value="bargains">
                        <UndervaluedScanner />
                    </TabsContent>

                    <TabsContent value="simulator">
                        <TransferOfferSimulator />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}