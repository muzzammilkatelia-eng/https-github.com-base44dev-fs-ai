import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, TrendingUp, Users, Zap, Award, BookOpen, CheckCircle } from 'lucide-react';

export default function About() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-6xl mx-auto space-y-8">
                {/* Hero Section */}
                <div className="text-center space-y-4">
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 px-4 py-2 text-sm">
                        <Shield className="w-4 h-4 mr-2 inline" />
                        Safeguarding-First Platform
                    </Badge>
                    <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                        About FS–AI
                    </h1>
                    <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
                        A safeguarding-first football intelligence platform designed for managers, agents, scouts, 
                        and fans who want to explore and close deals in the football business.
                    </p>
                </div>

                {/* Mission Statement */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-6 h-6 text-cyan-400" />
                            Our Mission
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 leading-relaxed text-lg">
                            Built with compliance and transparency at its core, FS–AI provides real-time insights, 
                            talent tracking, and ethical scouting tools to support decision-making across the football ecosystem. 
                            Part of the Minimax Sustainable AI initiative, every feature is designed with sustainability, 
                            ethics, and safeguarding in mind.
                        </p>
                    </CardContent>
                </Card>

                {/* Features Grid */}
                <div>
                    <h2 className="text-3xl font-bold text-white mb-6 text-center">Core Features</h2>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-cyan-500/20 flex items-center justify-center mb-4">
                                    <TrendingUp className="w-6 h-6 text-cyan-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Player & Match Intelligence</h3>
                                <p className="text-slate-400 text-sm">
                                    Real-time intelligence engines for scouts and managers to track talent and analyze match data.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center mb-4">
                                    <CheckCircle className="w-6 h-6 text-green-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Secure Commission Structures</h3>
                                <p className="text-slate-400 text-sm">
                                    Transparent, automated commission tracking for agents and professionals with built-in safeguards.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center mb-4">
                                    <Zap className="w-6 h-6 text-purple-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Automated Workflows</h3>
                                <p className="text-slate-400 text-sm">
                                    Streamlined membership payments and deal-closing workflows to accelerate business operations.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-amber-500/20 flex items-center justify-center mb-4">
                                    <Shield className="w-6 h-6 text-amber-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Compliance-Driven Safeguards</h3>
                                <p className="text-slate-400 text-sm">
                                    Protect your reputation with safeguarding-first compliance tools and transparency measures.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-pink-500/20 flex items-center justify-center mb-4">
                                    <Award className="w-6 h-6 text-pink-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Gamified Recognition</h3>
                                <p className="text-slate-400 text-sm">
                                    Badge competitions and recognition systems to motivate educators and learners.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                            <CardContent className="pt-6">
                                <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center mb-4">
                                    <BookOpen className="w-6 h-6 text-blue-400" />
                                </div>
                                <h3 className="text-white font-semibold text-lg mb-2">Accessible Learning</h3>
                                <p className="text-slate-400 text-sm">
                                    Modules for curious fans to understand scouting and the football business from the inside.
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* Benefits Section */}
                <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-6 h-6 text-cyan-400" />
                            Key Benefits
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-4">
                            <li className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-white font-medium">Close deals faster</p>
                                    <p className="text-slate-400 text-sm">Automated commission and payment systems streamline transactions</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-white font-medium">Protect your reputation</p>
                                    <p className="text-slate-400 text-sm">Safeguarding-first compliance tools ensure transparency</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-white font-medium">Streamline workflows</p>
                                    <p className="text-slate-400 text-sm">Secure commission structures for agents and managers</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-white font-medium">Motivate learners</p>
                                    <p className="text-slate-400 text-sm">Gamified recognition systems drive engagement</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3">
                                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-white font-medium">Gain insider knowledge</p>
                                    <p className="text-slate-400 text-sm">Learn scouting and football business as a fan</p>
                                </div>
                            </li>
                        </ul>
                    </CardContent>
                </Card>

                {/* Footer CTA */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-8 text-center">
                    <h3 className="text-2xl font-bold text-white mb-3">
                        Part of Minimax Sustainable AI
                    </h3>
                    <p className="text-slate-400 max-w-2xl mx-auto">
                        Whether you are a professional in football or a fan eager to learn, FS–AI empowers you 
                        with tools to explore, manage, and innovate responsibly.
                    </p>
                </div>
            </div>
        </div>
    );
}