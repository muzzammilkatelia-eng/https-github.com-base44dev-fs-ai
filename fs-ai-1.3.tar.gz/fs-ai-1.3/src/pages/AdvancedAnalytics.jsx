import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, TrendingUp, DollarSign, Bell, BarChart3, Target, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import CareerTrajectoryPredictor from '../components/predictive/CareerTrajectoryPredictor';
import MarketValuePredictor from '../components/predictive/MarketValuePredictor';
import DevelopmentMilestones from '../components/predictive/DevelopmentMilestones';
import MarketInsightsDashboard from '../components/analytics/MarketInsightsDashboard';
import PlayerKPIDashboard from '../components/analytics/PlayerKPIDashboard';
import AutomatedAlertSystem from '../components/analytics/AutomatedAlertSystem';
import PortfolioAnalytics from '../components/analytics/PortfolioAnalytics';
import PremiumGate from '../components/PremiumGate';

export default function AdvancedAnalytics() {
    return (
        <PremiumGate>
            <AdvancedAnalyticsContent />
        </PremiumGate>
    );
}

function AdvancedAnalyticsContent() {
    const [activeTab, setActiveTab] = useState('overview');

    const { data: players = [], isLoading: playersLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 100)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: alerts = [] } = useQuery({
        queryKey: ['alerts'],
        queryFn: () => base44.entities.Alert.list('-created_date', 50)
    });

    if (playersLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Advanced Analytics Dashboard
                    </h1>
                    <p className="text-slate-400">AI-powered insights for player development and market intelligence</p>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Tracked Players</p>
                                    <p className="text-3xl font-bold text-white">{players.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">AI Projections</p>
                                    <p className="text-3xl font-bold text-white">{projections.length}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Scout Reports</p>
                                    <p className="text-3xl font-bold text-white">{reports.length}</p>
                                </div>
                                <BarChart3 className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Alerts</p>
                                    <p className="text-3xl font-bold text-white">{alerts.filter(a => !a.read).length}</p>
                                </div>
                                <Bell className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="grid w-full grid-cols-6 bg-slate-800 mb-8">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="trajectory">Career Paths</TabsTrigger>
                        <TabsTrigger value="market">Market Value</TabsTrigger>
                        <TabsTrigger value="kpis">Player KPIs</TabsTrigger>
                        <TabsTrigger value="alerts">Smart Alerts</TabsTrigger>
                        <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-6"
                        >
                            <MarketInsightsDashboard players={players} projections={projections} />
                            <PortfolioAnalytics players={players} projections={projections} reports={reports} />
                        </motion.div>
                    </TabsContent>

                    <TabsContent value="trajectory" className="space-y-6">
                        <CareerTrajectoryPredictor players={players} projections={projections} />
                        <DevelopmentMilestones players={players} projections={projections} />
                    </TabsContent>

                    <TabsContent value="market" className="space-y-6">
                        <MarketValuePredictor players={players} projections={projections} />
                    </TabsContent>

                    <TabsContent value="kpis" className="space-y-6">
                        <PlayerKPIDashboard players={players} reports={reports} projections={projections} />
                    </TabsContent>

                    <TabsContent value="alerts" className="space-y-6">
                        <AutomatedAlertSystem 
                            players={players} 
                            projections={projections} 
                            reports={reports}
                            alerts={alerts}
                        />
                    </TabsContent>

                    <TabsContent value="portfolio" className="space-y-6">
                        <PortfolioAnalytics players={players} projections={projections} reports={reports} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}