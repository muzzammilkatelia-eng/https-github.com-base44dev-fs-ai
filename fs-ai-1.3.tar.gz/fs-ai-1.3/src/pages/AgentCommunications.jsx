import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
    Mail, Send, MessageSquare, TrendingUp, Clock, 
    CheckCircle, AlertTriangle, Plus, Eye, BarChart3 
} from 'lucide-react';
import { motion } from 'framer-motion';
import CommunicationForm from '../components/agent-comms/CommunicationForm';
import CommunicationDetails from '../components/agent-comms/CommunicationDetails';
import SentimentDashboard from '../components/agent-comms/SentimentDashboard';
import PremiumGate from '../components/PremiumGate';

export default function AgentCommunications() {
    return (
        <PremiumGate>
            <AgentCommunicationsContent />
        </PremiumGate>
    );
}

function AgentCommunicationsContent() {
    const [activeTab, setActiveTab] = useState('all');
    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [selectedComm, setSelectedComm] = useState(null);
    const [showDetailsDialog, setShowDetailsDialog] = useState(false);

    const queryClient = useQueryClient();

    const { data: communications = [], isLoading } = useQuery({
        queryKey: ['agent-communications'],
        queryFn: () => base44.entities.AgentCommunication.list('-created_date', 100)
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    // Filter communications by status
    const drafts = communications.filter(c => c.status === 'Draft');
    const sent = communications.filter(c => c.status === 'Sent' || c.status === 'Awaiting Response');
    const responded = communications.filter(c => c.status === 'Responded' || c.status === 'Negotiating');
    const closed = communications.filter(c => c.status === 'Closed' || c.status === 'Declined');

    // Stats
    const awaitingResponse = communications.filter(c => c.status === 'Awaiting Response').length;
    const responded_count = communications.filter(c => c.response_received).length;
    const positiveResponses = communications.filter(c => 
        c.ai_sentiment_analysis?.sentiment === 'Very Positive' || 
        c.ai_sentiment_analysis?.sentiment === 'Positive'
    ).length;

    const getStatusColor = (status) => {
        const colors = {
            'Draft': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Sent': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            'Awaiting Response': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Responded': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Negotiating': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
            'Closed': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Declined': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[status] || '';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'Critical': 'bg-red-500/20 text-red-400',
            'High': 'bg-orange-500/20 text-orange-400',
            'Medium': 'bg-blue-500/20 text-blue-400',
            'Low': 'bg-slate-500/20 text-slate-400'
        };
        return colors[priority] || '';
    };

    const CommunicationCard = ({ comm }) => (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 hover:bg-slate-800 transition-colors cursor-pointer"
            onClick={() => {
                setSelectedComm(comm);
                setShowDetailsDialog(true);
            }}
        >
            <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                    <h4 className="text-white font-semibold mb-1">{comm.player_name}</h4>
                    <p className="text-slate-400 text-sm">{comm.agent_name}</p>
                </div>
                <div className="flex gap-2">
                    <Badge className={getPriorityColor(comm.priority)}>
                        {comm.priority}
                    </Badge>
                    <Badge className={getStatusColor(comm.status)}>
                        {comm.status}
                    </Badge>
                </div>
            </div>

            <p className="text-slate-300 text-sm mb-3 line-clamp-2">{comm.subject}</p>

            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                    <MessageSquare className="w-3 h-3" />
                    <span>{comm.communication_type}</span>
                </div>
                {comm.ai_sentiment_analysis && (
                    <Badge className={
                        comm.ai_sentiment_analysis.sentiment === 'Very Positive' || comm.ai_sentiment_analysis.sentiment === 'Positive' 
                        ? 'bg-emerald-500/20 text-emerald-400' 
                        : comm.ai_sentiment_analysis.sentiment === 'Neutral'
                        ? 'bg-slate-500/20 text-slate-400'
                        : 'bg-red-500/20 text-red-400'
                    }>
                        {comm.ai_sentiment_analysis.sentiment}
                    </Badge>
                )}
            </div>

            {comm.follow_up_date && (
                <div className="flex items-center gap-1 mt-2 text-xs text-amber-400">
                    <Clock className="w-3 h-3" />
                    <span>Follow-up: {new Date(comm.follow_up_date).toLocaleDateString()}</span>
                </div>
            )}
        </motion.div>
    );

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8 flex justify-between items-start">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                            Agent Communications
                        </h1>
                        <p className="text-slate-400">AI-powered agent outreach and negotiation tracking</p>
                    </div>
                    <Button 
                        onClick={() => setShowCreateDialog(true)}
                        className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        New Communication
                    </Button>
                </div>

                {/* Stats Dashboard */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Awaiting Response</p>
                                    <p className="text-3xl font-bold text-amber-400">{awaitingResponse}</p>
                                </div>
                                <Clock className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Responded</p>
                                    <p className="text-3xl font-bold text-cyan-400">{responded_count}</p>
                                </div>
                                <Mail className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Positive Sentiment</p>
                                    <p className="text-3xl font-bold text-emerald-400">{positiveResponses}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Comms</p>
                                    <p className="text-3xl font-bold text-white">{communications.length}</p>
                                </div>
                                <MessageSquare className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                        <TabsTrigger value="all">All ({communications.length})</TabsTrigger>
                        <TabsTrigger value="drafts">Drafts ({drafts.length})</TabsTrigger>
                        <TabsTrigger value="sent">Sent ({sent.length})</TabsTrigger>
                        <TabsTrigger value="responded">Responded ({responded.length})</TabsTrigger>
                        <TabsTrigger value="sentiment">
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Analytics
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="all" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {communications.map((comm) => (
                                <CommunicationCard key={comm.id} comm={comm} />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="drafts" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {drafts.map((comm) => (
                                <CommunicationCard key={comm.id} comm={comm} />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="sent" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {sent.map((comm) => (
                                <CommunicationCard key={comm.id} comm={comm} />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="responded" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {responded.map((comm) => (
                                <CommunicationCard key={comm.id} comm={comm} />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="sentiment" className="mt-6">
                        <SentimentDashboard communications={communications} />
                    </TabsContent>
                </Tabs>
            </div>

            {/* Create Communication Dialog */}
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>New Agent Communication</DialogTitle>
                    </DialogHeader>
                    <CommunicationForm onClose={() => setShowCreateDialog(false)} />
                </DialogContent>
            </Dialog>

            {/* Details Dialog */}
            <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-5xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Communication Details</DialogTitle>
                    </DialogHeader>
                    {selectedComm && (
                        <CommunicationDetails 
                            communication={selectedComm}
                            onClose={() => setShowDetailsDialog(false)}
                        />
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}