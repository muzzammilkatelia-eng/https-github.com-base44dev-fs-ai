import React from 'react';
import { Briefcase } from 'lucide-react';
import MultiBrainAnalyzer from '../components/recruitment/MultiBrainAnalyzer';
import AgentFinisherPanel from '../components/recruitment/AgentFinisherPanel';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function AgentFinisher() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Briefcase className="w-8 h-8 text-purple-400" />
                        Agent Finisher Module
                        <HelpTooltip content="Multi-brain scouting intelligence + agent finisher decision layer. Turn scouting data into clear move decisions with fee/wage recommendations." />
                    </h1>
                    <p className="text-slate-400">
                        Smart 5.1 GPT archetype • Four distinct AI perspectives • Clear finisher moves
                    </p>
                </div>

                <div className="space-y-8">
                    <MultiBrainAnalyzer />
                    <AgentFinisherPanel />
                </div>
            </div>
        </div>
    );
}