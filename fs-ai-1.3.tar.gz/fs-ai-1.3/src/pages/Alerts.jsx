import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Bell, Plus, Trash2, Settings, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AlertCriteriaForm from '../components/alerts/AlertCriteriaForm';
import toast from 'react-hot-toast';

export default function Alerts() {
    const [showForm, setShowForm] = useState(false);
    const [editingCriteria, setEditingCriteria] = useState(null);

    const queryClient = useQueryClient();

    const { data: criteria = [] } = useQuery({
        queryKey: ['alert-criteria'],
        queryFn: () => base44.entities.AlertCriteria.list('-created_date')
    });

    const { data: alerts = [] } = useQuery({
        queryKey: ['alerts'],
        queryFn: () => base44.entities.Alert.list('-created_date', 50)
    });

    const createCriteriaMutation = useMutation({
        mutationFn: (data) => base44.entities.AlertCriteria.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alert-criteria'] });
            setShowForm(false);
            toast.success('Alert criteria created');
        }
    });

    const updateCriteriaMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.AlertCriteria.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alert-criteria'] });
            setEditingCriteria(null);
            setShowForm(false);
            toast.success('Alert criteria updated');
        }
    });

    const deleteCriteriaMutation = useMutation({
        mutationFn: (id) => base44.entities.AlertCriteria.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alert-criteria'] });
            toast.success('Alert criteria deleted');
        }
    });

    const markAsReadMutation = useMutation({
        mutationFn: (id) => base44.entities.Alert.update(id, { read: true }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alerts'] });
        }
    });

    const handleSubmit = (data) => {
        if (editingCriteria) {
            updateCriteriaMutation.mutate({ id: editingCriteria.id, data });
        } else {
            createCriteriaMutation.mutate(data);
        }
    };

    const toggleActive = (criteria) => {
        updateCriteriaMutation.mutate({
            id: criteria.id,
            data: { ...criteria, active: !criteria.active }
        });
    };

    const unreadCount = alerts.filter(a => !a.read).length;

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent mb-2">
                            Target Alerts
                        </h1>
                        <p className="text-slate-400">Get notified when players match your criteria</p>
                    </div>
                    <Button
                        onClick={() => {
                            setEditingCriteria(null);
                            setShowForm(true);
                        }}
                        className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        New Alert Criteria
                    </Button>
                </div>

                {showForm && (
                    <div className="mb-8">
                        <AlertCriteriaForm
                            onSubmit={handleSubmit}
                            onCancel={() => {
                                setShowForm(false);
                                setEditingCriteria(null);
                            }}
                            existingCriteria={editingCriteria}
                        />
                    </div>
                )}

                <Tabs defaultValue="alerts">
                    <TabsList className="grid w-full grid-cols-2 bg-slate-800 mb-6">
                        <TabsTrigger value="alerts" className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400">
                            <Bell className="w-4 h-4 mr-2" />
                            Alerts ({unreadCount})
                        </TabsTrigger>
                        <TabsTrigger value="criteria" className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400">
                            <Settings className="w-4 h-4 mr-2" />
                            Criteria ({criteria.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="alerts">
                        {alerts.length === 0 ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center">
                                    <Bell className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                                    <p className="text-slate-400">No alerts yet</p>
                                    <p className="text-slate-500 text-sm mt-2">Create alert criteria to start receiving notifications</p>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="space-y-4">
                                {alerts.map((alert) => (
                                    <motion.div
                                        key={alert.id}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                    >
                                        <Card className={`bg-slate-900/50 border-slate-800 ${
                                            !alert.read ? 'border-l-4 border-l-amber-500' : ''
                                        }`}>
                                            <CardContent className="pt-6">
                                                <div className="flex justify-between items-start">
                                                    <div className="flex-1">
                                                        <div className="flex items-center gap-3 mb-2">
                                                            <h3 className="text-white font-semibold text-lg">
                                                                {alert.player_name}
                                                            </h3>
                                                            {!alert.read && (
                                                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                                    NEW
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <p className="text-slate-400 text-sm mb-3">
                                                            Matched: <span className="text-cyan-400">{alert.criteria_name}</span>
                                                        </p>
                                                        <div className="flex flex-wrap gap-2">
                                                            <Badge className="bg-slate-800 text-slate-300">
                                                                {alert.player_details?.position}
                                                            </Badge>
                                                            <Badge className="bg-slate-800 text-slate-300">
                                                                Age {alert.player_details?.age}
                                                            </Badge>
                                                            {alert.player_details?.recommendation && (
                                                                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                                                    {alert.player_details.recommendation}
                                                                </Badge>
                                                            )}
                                                            {alert.player_details?.trajectory && (
                                                                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                                                    {alert.player_details.trajectory}
                                                                </Badge>
                                                            )}
                                                            {alert.player_details?.potential_rating && (
                                                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                                    Potential: {alert.player_details.potential_rating}
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <p className="text-slate-500 text-xs mt-3">
                                                            {new Date(alert.created_date).toLocaleString()}
                                                        </p>
                                                    </div>
                                                    {!alert.read && (
                                                        <Button
                                                            onClick={() => markAsReadMutation.mutate(alert.id)}
                                                            size="sm"
                                                            variant="outline"
                                                            className="border-slate-700 text-slate-400"
                                                        >
                                                            <Check className="w-4 h-4 mr-1" />
                                                            Mark Read
                                                        </Button>
                                                    )}
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="criteria">
                        {criteria.length === 0 ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center">
                                    <Settings className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                                    <p className="text-slate-400">No alert criteria configured</p>
                                    <p className="text-slate-500 text-sm mt-2">Create your first alert to get started</p>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {criteria.map((item) => (
                                    <Card key={item.id} className="bg-slate-900/50 border-slate-800">
                                        <CardHeader>
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <CardTitle className="text-white">{item.name}</CardTitle>
                                                    <p className="text-slate-400 text-sm mt-1">
                                                        Trigger: {item.trigger_type.replace('_', ' ')}
                                                    </p>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={item.active}
                                                        onCheckedChange={() => toggleActive(item)}
                                                    />
                                                    <Button
                                                        onClick={() => {
                                                            setEditingCriteria(item);
                                                            setShowForm(true);
                                                        }}
                                                        size="sm"
                                                        variant="ghost"
                                                        className="text-cyan-400"
                                                    >
                                                        Edit
                                                    </Button>
                                                    <Button
                                                        onClick={() => {
                                                            if (confirm('Delete this criteria?')) {
                                                                deleteCriteriaMutation.mutate(item.id);
                                                            }
                                                        }}
                                                        size="sm"
                                                        variant="ghost"
                                                        className="text-red-400"
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-3">
                                                {item.criteria?.positions && item.criteria.positions.length > 0 && (
                                                    <div>
                                                        <p className="text-slate-500 text-xs mb-1">Positions</p>
                                                        <div className="flex flex-wrap gap-1">
                                                            {item.criteria.positions.map(pos => (
                                                                <Badge key={pos} className="bg-slate-800 text-slate-300 text-xs">
                                                                    {pos}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                                {(item.criteria?.min_age || item.criteria?.max_age) && (
                                                    <p className="text-slate-400 text-sm">
                                                        Age: {item.criteria.min_age || 0} - {item.criteria.max_age || '∞'}
                                                    </p>
                                                )}
                                                {item.notify_slack && (
                                                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">
                                                        Slack: {item.slack_channel}
                                                    </Badge>
                                                )}
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}