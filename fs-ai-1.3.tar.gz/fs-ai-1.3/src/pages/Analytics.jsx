import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    BarChart3, TrendingUp, Globe2, Brain, Users, Target, 
    Mail, CheckCircle, Clock, AlertCircle, DollarSign 
} from 'lucide-react';
import CommissionTrends from '../components/analytics/CommissionTrends';
import RegionalInsights from '../components/analytics/RegionalInsights';
import MarketPredictions from '../components/analytics/MarketPredictions';
import ClientRoster from '../components/analytics/ClientRoster';
import PerformanceMetrics from '../components/analytics/PerformanceMetrics';
import RecruitmentOverview from '../components/analytics/RecruitmentOverview';

export default function Analytics() {
    const [timeRange, setTimeRange] = useState('monthly');
    
    const { data: commissions = [] } = useQuery({
        queryKey: ['agent-commissions'],
        queryFn: () => base44.entities.AgentCommission.list('-signing_date', 100)
    });

    const { data: scoutReports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 100)
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['scouting-tasks-analytics'],
        queryFn: () => base44.entities.ScoutingTask.list('-created_date', 100)
    });

    const { data: communications = [] } = useQuery({
        queryKey: ['agent-communications-analytics'],
        queryFn: () => base44.entities.AgentCommunication.list('-created_date', 100)
    });

    const { data: marketData = [] } = useQuery({
        queryKey: ['market-data-analytics'],
        queryFn: () => base44.entities.DataFeed.list('-fetched_at', 100)
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const myCommissions = commissions.filter(c => c.agent_email === user?.email);

    // Calculate comprehensive stats
    const totalPlayers = scoutReports.length;
    const completedTasks = tasks.filter(t => t.status === 'Completed').length;
    const totalTasks = tasks.length;
    const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    const sentCommunications = communications.filter(c => c.status === 'Sent' || c.status === 'Awaiting Response').length;
    const respondedCommunications = communications.filter(c => c.response_received).length;
    const responseRate = sentCommunications > 0 ? Math.round((respondedCommunications / sentCommunications) * 100) : 0;

    const positiveSentiment = communications.filter(c => 
        c.ai_sentiment_analysis?.sentiment === 'Very Positive' || 
        c.ai_sentiment_analysis?.sentiment === 'Positive'
    ).length;

    const totalRevenue = commissions.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent mb-2">
                            Comprehensive Analytics
                        </h1>
                        <p className="text-slate-400">Cross-module insights & recruitment performance</p>
                    </div>
                    <Select value={timeRange} onValueChange={setTimeRange}>
                        <SelectTrigger className="w-40 bg-slate-900 border-slate-700 text-white">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="yearly">Yearly</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                {/* Global Overview Stats */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Players</p>
                                    <p className="text-3xl font-bold text-cyan-400">{totalPlayers}</p>
                                    <p className="text-slate-500 text-xs mt-1">Scouted</p>
                                </div>
                                <Target className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Task Completion</p>
                                    <p className="text-3xl font-bold text-emerald-400">{taskCompletionRate}%</p>
                                    <p className="text-slate-500 text-xs mt-1">{completedTasks}/{totalTasks} completed</p>
                                </div>
                                <CheckCircle className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Agent Response</p>
                                    <p className="text-3xl font-bold text-purple-400">{responseRate}%</p>
                                    <p className="text-slate-500 text-xs mt-1">{respondedCommunications} responses</p>
                                </div>
                                <Mail className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Revenue</p>
                                    <p className="text-3xl font-bold text-amber-400">£{totalRevenue.toLocaleString()}</p>
                                    <p className="text-slate-500 text-xs mt-1">Commissions</p>
                                </div>
                                <DollarSign className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="overview" className="mt-8">
                    <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                        <TabsTrigger value="overview" className="data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Overview
                        </TabsTrigger>
                        <TabsTrigger value="trends" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Trends
                        </TabsTrigger>
                        <TabsTrigger value="regions" className="data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400">
                            <Globe2 className="w-4 h-4 mr-2" />
                            Regions
                        </TabsTrigger>
                        <TabsTrigger value="predictions" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            <Brain className="w-4 h-4 mr-2" />
                            AI Predictions
                        </TabsTrigger>
                        <TabsTrigger value="roster" className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400">
                            <Users className="w-4 h-4 mr-2" />
                            Client Roster
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="mt-6">
                        <RecruitmentOverview 
                            reports={scoutReports}
                            tasks={tasks}
                            communications={communications}
                            projections={projections}
                            marketData={marketData}
                            timeRange={timeRange}
                        />
                    </TabsContent>

                    <TabsContent value="trends" className="mt-6">
                        <CommissionTrends commissions={myCommissions} timeRange={timeRange} />
                    </TabsContent>

                    <TabsContent value="regions" className="mt-6">
                        <RegionalInsights reports={scoutReports} commissions={commissions} />
                    </TabsContent>

                    <TabsContent value="predictions" className="mt-6">
                        <MarketPredictions projections={projections} reports={scoutReports} />
                    </TabsContent>

                    <TabsContent value="roster" className="mt-6">
                        <ClientRoster commissions={myCommissions} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}