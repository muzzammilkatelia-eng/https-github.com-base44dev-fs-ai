import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Shield } from 'lucide-react';

export default function ApacheLicense() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-4xl mx-auto">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-3xl flex items-center gap-3">
                            <Shield className="w-8 h-8 text-cyan-400" />
                            Apache License 2.0
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="prose prose-invert max-w-none">
                        <div className="space-y-6 text-slate-300">
                            <section>
                                <h2 className="text-white text-xl font-semibold mb-3">License Information</h2>
                                <p>FS-AI Platform and certain components are licensed under the Apache License, Version 2.0</p>
                            </section>

                            <section className="bg-slate-800/50 text-slate-950 p-6 rounded-lg">
                                <pre className="text-xs text-slate-300 whitespace-pre-wrap">
                  {`Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

"License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.

"Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.

"Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity.

"You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.

"Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.

"Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.

"Work" shall mean the work of authorship, whether in Source or Object form, made available under the License.

"Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work.

2. Grant of Copyright License.

Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

3. Grant of Patent License.

Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work.

4. Redistribution.

You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, provided that You meet the following conditions:

   (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and
   (b) You must cause any modified files to carry prominent notices stating that You changed the files; and
   (c) You must retain all copyright, patent, trademark, and attribution notices from the Source form of the Work; and
   (d) If the Work includes a "NOTICE" text file, then any Derivative Works that You distribute must include a readable copy of the attribution notices.

5. Submission of Contributions.

Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions.

6. Trademarks.

This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for describing the origin of the Work.

7. Disclaimer of Warranty.

Unless required by applicable law or agreed to in writing, Licensor provides the Work on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

8. Limitation of Liability.

In no event shall Licensor be liable for any damages, including any direct, indirect, special, incidental, or consequential damages arising out of use of the Work.

9. Accepting Warranty or Additional Liability.

While redistributing the Work or Derivative Works thereof, You may choose to offer acceptance of support, warranty, indemnity, or other liability obligations consistent with this License.

END OF TERMS AND CONDITIONS`}
                                </pre>
                            </section>

                            <section>
                                <h2 className="text-white text-xl font-semibold mb-3">Copyright Notice</h2>
                                <p className="bg-slate-800/50 rounded-lg p-4">
                                    Copyright © {new Date().getFullYear()} Minimax Sustainable AI Ltd. All Rights Reserved.
                                    <br /><br />
                                    Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License.
                                    <br /><br />
                                    Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
                                </p>
                            </section>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>);

}