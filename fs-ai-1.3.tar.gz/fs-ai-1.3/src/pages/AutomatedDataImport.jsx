import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Database, Clock, TrendingUp, CheckCircle2, AlertCircle } from 'lucide-react';
import APIConnectionManager from '../components/data-import/APIConnectionManager';
import ScheduledRefreshManager from '../components/data-import/ScheduledRefreshManager';
import SyncHistoryViewer from '../components/data-import/SyncHistoryViewer';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function AutomatedDataImport() {
    const { data: integrations = [] } = useQuery({
        queryKey: ['external-integrations'],
        queryFn: () => base44.entities.ExternalIntegration.list('-last_sync', 50)
    });

    const activeIntegrations = integrations.filter(i => i.status === 'Active');
    const totalPlayersSynced = integrations.reduce((sum, i) => sum + (i.players_synced || 0), 0);
    const syncingNow = integrations.filter(i => i.status === 'Syncing').length;

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Database className="w-8 h-8 text-cyan-400" />
                        Automated Data Import
                        <HelpTooltip content="Connect to external sports data APIs like Wyscout and Opta. Set up scheduled refreshes to automatically keep your player and match data up-to-date." />
                    </h1>
                    <p className="text-slate-400">
                        Connect APIs, schedule refreshes, and keep data synchronized
                    </p>
                </div>

                {/* Stats */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active APIs</p>
                                    <p className="text-4xl font-bold text-white">{activeIntegrations.length}</p>
                                </div>
                                <CheckCircle2 className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Syncing Now</p>
                                    <p className="text-4xl font-bold text-white">{syncingNow}</p>
                                </div>
                                <RefreshCw className={`w-8 h-8 text-purple-400 ${syncingNow > 0 ? 'animate-spin' : ''}`} />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Players Synced</p>
                                    <p className="text-4xl font-bold text-white">{totalPlayersSynced.toLocaleString()}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Auto-Refresh</p>
                                    <p className="text-4xl font-bold text-white">
                                        {integrations.filter(i => i.sync_frequency !== 'Manual').length}
                                    </p>
                                </div>
                                <Clock className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Main Content */}
                <Tabs defaultValue="connections" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800">
                        <TabsTrigger value="connections">API Connections</TabsTrigger>
                        <TabsTrigger value="schedule">Scheduled Refreshes</TabsTrigger>
                        <TabsTrigger value="history">Sync History</TabsTrigger>
                    </TabsList>

                    <TabsContent value="connections">
                        <APIConnectionManager integrations={integrations} />
                    </TabsContent>

                    <TabsContent value="schedule">
                        <ScheduledRefreshManager integrations={integrations} />
                    </TabsContent>

                    <TabsContent value="history">
                        <SyncHistoryViewer integrations={integrations} />
                    </TabsContent>
                </Tabs>

                {/* Info Card */}
                <Card className="bg-blue-500/10 border-blue-500/30">
                    <CardContent className="pt-6">
                        <h3 className="text-blue-400 font-semibold mb-3 flex items-center gap-2">
                            <Database className="w-5 h-5" />
                            Supported Data Sources
                        </h3>
                        <div className="grid md:grid-cols-2 gap-4 text-slate-300 text-sm">
                            <div>
                                <p className="font-semibold text-white mb-2">Scouting Databases:</p>
                                <ul className="space-y-1">
                                    <li>• Wyscout - Professional player database</li>
                                    <li>• Transfermarkt - Market values & transfers</li>
                                    <li>• InStat - Performance analytics</li>
                                </ul>
                            </div>
                            <div>
                                <p className="font-semibold text-white mb-2">Analytics Providers:</p>
                                <ul className="space-y-1">
                                    <li>• Opta - Match & player statistics</li>
                                    <li>• StatsBomb - Advanced metrics</li>
                                    <li>• Custom API integrations</li>
                                </ul>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}