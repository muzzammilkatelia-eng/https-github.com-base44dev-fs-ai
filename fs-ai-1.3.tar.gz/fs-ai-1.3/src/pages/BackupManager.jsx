import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Cloud, Shield, Clock } from 'lucide-react';
import GoogleDriveBackup from '../components/backup/GoogleDriveBackup';

export default function BackupManager() {
    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-500 bg-clip-text text-transparent mb-2">
                        Document Backup
                    </h1>
                    <p className="text-slate-400">
                        Securely backup your scouting data to Google Drive
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                    <Card className="bg-slate-900/50 border-blue-500/30">
                        <CardContent className="pt-6 text-center">
                            <Cloud className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                            <p className="text-slate-400 text-sm">Cloud Storage</p>
                            <p className="text-white font-semibold">Google Drive</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-900/50 border-emerald-500/30">
                        <CardContent className="pt-6 text-center">
                            <Shield className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                            <p className="text-slate-400 text-sm">Encryption</p>
                            <p className="text-white font-semibold">End-to-End</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-900/50 border-purple-500/30">
                        <CardContent className="pt-6 text-center">
                            <Clock className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                            <p className="text-slate-400 text-sm">Frequency</p>
                            <p className="text-white font-semibold">On-Demand</p>
                        </CardContent>
                    </Card>
                </div>

                <GoogleDriveBackup />
            </div>
        </div>
    );
}