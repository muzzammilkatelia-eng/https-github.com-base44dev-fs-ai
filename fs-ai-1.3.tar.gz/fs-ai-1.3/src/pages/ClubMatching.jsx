import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Target, Loader2 } from 'lucide-react';
import ClubNeedsInput from '../components/matching/ClubNeedsInput';
import MatchResults from '../components/matching/MatchResults';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';

export default function ClubMatching() {
    const [matches, setMatches] = useState(null);

    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scouting-reports-matching'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections-matching'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 50)
    });

    const matchPlayersMutation = useMutation({
        mutationFn: async (clubNeeds) => {
            const reportsContext = scoutingReports.slice(0, 20).map(r => 
                `${r.player_name} (${r.player_age}y, ${r.position}) - Current club: ${r.current_club}, Technical: ${r.technical_rating}, Physical: ${r.physical_rating}, Tactical: ${r.tactical_rating}, Mental: ${r.mental_rating}, Recommendation: ${r.recommendation}`
            ).join('\n');

            const projectionsContext = projections.slice(0, 10).map(p =>
                `${p.player_name} (${p.current_age}y, ${p.position}) - Potential: ${p.potential_trajectory}, Peak rating: ${p.peak_potential_rating}, Years to peak: ${p.years_to_peak}`
            ).join('\n');

            const prompt = `You are an elite football recruitment AI. Analyze club needs and match with available scouted players.

CLUB REQUIREMENTS:
- Squad Gaps: ${clubNeeds.squadGaps || 'Not specified'}
- Preferred Playing Style: ${clubNeeds.playingStyle || 'Not specified'}
- Budget Range: ${clubNeeds.budget || 'Not specified'}
- Age Profile: ${clubNeeds.ageProfile || 'Not specified'}
- Priority Level: ${clubNeeds.priority || 'Medium'}
- Timeline: ${clubNeeds.timeline || 'Not specified'}
- Additional Requirements: ${clubNeeds.additionalRequirements || 'None'}

AVAILABLE SCOUTING REPORTS:
${reportsContext}

PLAYER PROJECTIONS:
${projectionsContext}

Identify 6-10 best matches and for each provide:
1. Player details and current situation
2. Match score (0-100) based on how well they fit club needs
3. Detailed rationale explaining why they're a good fit
4. Potential concerns or risks
5. Estimated transfer complexity (Easy/Moderate/Difficult)
6. Recommended next steps (specific actions to take)
7. Priority ranking (Critical/High/Medium/Low)

Be specific and actionable. Consider playing style compatibility, budget constraints, age profile, and timeline.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        matches: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    position: { type: "string" },
                                    current_club: { type: "string" },
                                    match_score: { type: "number" },
                                    rationale: { type: "string" },
                                    key_strengths: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    concerns: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    transfer_complexity: { type: "string" },
                                    estimated_fee: { type: "string" },
                                    next_steps: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    priority: { type: "string" },
                                    timeline_fit: { type: "string" }
                                }
                            }
                        },
                        summary: { type: "string" }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setMatches(data);
            toast.success(`Found ${data.matches.length} potential matches`);
        },
        onError: () => {
            toast.error('Failed to generate matches');
        }
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 px-4 py-6 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
                <div className="mb-4 sm:mb-8">
                    <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        AI Club Needs Matching
                    </h1>
                    <p className="text-slate-400 text-sm sm:text-base">
                        Intelligent player recommendations based on your club's requirements
                    </p>
                </div>

                <ClubNeedsInput 
                    onSubmit={(needs) => matchPlayersMutation.mutate(needs)}
                    isLoading={matchPlayersMutation.isPending}
                />

                {matchPlayersMutation.isPending && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 text-center py-12">
                            <Loader2 className="w-12 h-12 text-cyan-400 animate-spin mx-auto mb-4" />
                            <p className="text-white font-semibold mb-2">Analyzing club needs...</p>
                            <p className="text-slate-400 text-sm">Matching with {scoutingReports.length} scouted players</p>
                        </CardContent>
                    </Card>
                )}

                {matches && <MatchResults matches={matches} />}
            </div>
        </div>
    );
}