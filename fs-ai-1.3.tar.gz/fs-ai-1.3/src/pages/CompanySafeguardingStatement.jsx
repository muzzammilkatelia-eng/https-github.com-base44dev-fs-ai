import React from 'react';
import { Shield, CheckCircle, AlertTriangle, FileCheck, Users } from 'lucide-react';

export default function CompanySafeguardingStatement() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/20 mb-4">
                        <Shield className="w-8 h-8 text-emerald-400" />
                    </div>
                    <h1 className="text-4xl font-bold text-white mb-2">
                        Minimax Sustainable AI Ltd
                    </h1>
                    <h2 className="text-2xl font-semibold text-cyan-400 mb-4">
                        Public Facing Safeguarding and Compliance Statement
                    </h2>
                    <p className="text-slate-300 text-lg">
                        Mandatory Requirements Under United Kingdom Law, DBS Regulations and National Safeguarding Standards
                    </p>
                </div>

                {/* Our Commitment */}
                <section className="bg-slate-900/50 border border-emerald-500/30 rounded-lg p-8 mb-8">
                    <h3 className="text-2xl font-bold text-emerald-400 mb-4 flex items-center gap-2">
                        <Shield className="w-6 h-6" />
                        Our Commitment
                    </h3>
                    <p className="text-slate-300 leading-relaxed mb-4">
                        Minimax Sustainable AI Ltd is built on a <strong className="text-white">safeguarding first philosophy</strong>. Every system, workflow and artificial intelligence product we create is designed to protect people, uphold United Kingdom law and ensure ethical, transparent and responsible use of artificial intelligence.
                    </p>
                    <p className="text-slate-300 leading-relaxed mb-4">
                        As an organisation working across education, youth facing environments and regulated sectors, Minimax follows:
                    </p>
                    <ul className="space-y-2 text-slate-300 ml-6">
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            United Kingdom Disclosure and Barring Service legislation
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            The Children Act 1989 and the Children Act 2004
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            Keeping Children Safe in Education
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            Working Together to Safeguard Children
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            The Prevent Duty
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            The General Data Protection Regulation and the Data Protection Act 2018
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                            Sector specific safeguarding requirements for artificial intelligence enabled environments
                        </li>
                    </ul>
                    <p className="text-white font-semibold mt-6 text-lg">
                        Safeguarding is not an optional policy. It is the foundation of our organisation.
                    </p>
                </section>

                {/* Mandatory Requirements */}
                <section className="bg-slate-900/50 border border-cyan-500/30 rounded-lg p-8 mb-8">
                    <h3 className="text-2xl font-bold text-cyan-400 mb-6 flex items-center gap-2">
                        <FileCheck className="w-6 h-6" />
                        Mandatory Requirements for All Minimax Staff, Contractors and Partners
                    </h3>

                    <div className="space-y-6">
                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">1. Enhanced DBS Clearance</h4>
                            <p className="text-slate-300 leading-relaxed mb-2">
                                Any individual working with or around children, young people or sensitive data through Minimax systems must hold a valid Enhanced DBS certificate.
                            </p>
                            <p className="text-red-400 font-bold">
                                No DBS means no access.
                            </p>
                            <p className="text-slate-300 mt-2">
                                This applies to employees, contractors, consultants and external partners.
                            </p>
                        </div>

                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">2. Mandatory Safeguarding Training</h4>
                            <p className="text-slate-300 leading-relaxed mb-3">All personnel must complete:</p>
                            <ul className="space-y-2 text-slate-300 ml-6">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Safeguarding Children Level One
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Annual safeguarding refreshers
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Prevent Duty training
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    The Minimax safeguarding induction
                                </li>
                            </ul>
                            <p className="text-slate-300 mt-3">
                                This ensures every individual understands their legal responsibilities and duty of care.
                            </p>
                        </div>

                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">3. Identity and Eligibility Verification</h4>
                            <p className="text-slate-300 leading-relaxed mb-3">Before access is granted, Minimax requires:</p>
                            <ul className="space-y-2 text-slate-300 ml-6">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Proof of identity
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Proof of DBS status
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Confirmation of the right to work or volunteer
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Evidence of safeguarding qualifications
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                                    Confirmation of professional suitability
                                </li>
                            </ul>
                            <p className="text-white font-semibold mt-3">
                                Verification is mandatory and ongoing.
                            </p>
                        </div>
                    </div>
                </section>

                {/* How Minimax Protects Users */}
                <section className="bg-slate-900/50 border border-purple-500/30 rounded-lg p-8 mb-8">
                    <h3 className="text-2xl font-bold text-purple-400 mb-6 flex items-center gap-2">
                        <Users className="w-6 h-6" />
                        How Minimax Protects Users, Learners and Communities
                    </h3>

                    <div className="space-y-6">
                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">Safeguarding by Design</h4>
                            <p className="text-slate-300 leading-relaxed mb-3">
                                Minimax embeds safeguarding controls into every product and service, including:
                            </p>
                            <ul className="space-y-2 text-slate-300 ml-6">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Restricted access for unverified users
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Automated compliance checks
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Secure data handling and encryption
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Age appropriate artificial intelligence interaction safeguards
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Clear reporting and escalation pathways
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Stateless and role bound artificial intelligence architecture to prevent misuse
                                </li>
                            </ul>
                        </div>

                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">Data Protection and Ethical Artificial Intelligence</h4>
                            <p className="text-slate-300 leading-relaxed mb-3">
                                Minimax systems operate under strict General Data Protection Regulation aligned protocols. We enforce:
                            </p>
                            <ul className="space-y-2 text-slate-300 ml-6">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Minimal data collection
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Zero tolerance for unauthorised data storage
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Transparent data governance
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    Ethical artificial intelligence usage aligned with United Kingdom regulatory expectations
                                </li>
                            </ul>
                        </div>

                        <div>
                            <h4 className="text-xl font-semibold text-white mb-3">Reporting Concerns</h4>
                            <p className="text-slate-300 leading-relaxed mb-3">
                                All personnel have a legal and ethical duty to report:
                            </p>
                            <ul className="space-y-2 text-slate-300 ml-6">
                                <li className="flex items-start gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    Safeguarding concerns
                                </li>
                                <li className="flex items-start gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    Misconduct
                                </li>
                                <li className="flex items-start gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    Data breaches
                                </li>
                                <li className="flex items-start gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    Suspicious behaviour
                                </li>
                                <li className="flex items-start gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                                    Misuse of artificial intelligence systems
                                </li>
                            </ul>
                            <p className="text-slate-300 mt-3">
                                Reports are handled confidentially and in line with statutory guidance.
                            </p>
                        </div>
                    </div>
                </section>

                {/* Zero Tolerance Policy */}
                <section className="bg-gradient-to-r from-red-500/10 to-red-600/10 border border-red-500/30 rounded-lg p-8 mb-8">
                    <h3 className="text-2xl font-bold text-red-400 mb-6 flex items-center gap-2">
                        <AlertTriangle className="w-6 h-6" />
                        Zero Tolerance Policy
                    </h3>
                    <p className="text-slate-300 leading-relaxed mb-4">
                        Minimax Sustainable AI Ltd will immediately suspend or remove any individual who:
                    </p>
                    <ul className="space-y-2 text-slate-300 ml-6 mb-6">
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Lacks valid DBS clearance
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Breaches safeguarding rules
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Misuses data or artificial intelligence systems
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Acts inappropriately toward users or learners
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Fails to report concerns
                        </li>
                        <li className="flex items-start gap-2">
                            <span className="text-red-400 font-bold">✕</span>
                            Attempts to bypass compliance controls
                        </li>
                    </ul>
                    <p className="text-slate-300 leading-relaxed mb-3">
                        Where necessary, Minimax will notify:
                    </p>
                    <ul className="space-y-2 text-slate-300 ml-6">
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            Local Authority Designated Officers
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            Social care
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            Police
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            Relevant safeguarding bodies
                        </li>
                        <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            Sector regulators
                        </li>
                    </ul>
                </section>

                {/* Our Promise */}
                <section className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-lg p-8 text-center">
                    <h3 className="text-2xl font-bold text-emerald-400 mb-4">Our Promise to the Public</h3>
                    <p className="text-slate-300 leading-relaxed mb-4 text-lg">
                        Minimax Sustainable AI Ltd exists to build ethical, compliant and safeguarding first artificial intelligence systems that protect people and empower communities.
                    </p>
                    <p className="text-white font-semibold text-lg mb-4">
                        We believe artificial intelligence must always be safe, transparent and responsible.
                    </p>
                    <div className="inline-block bg-slate-900/50 border border-emerald-500/50 rounded-lg px-8 py-4">
                        <p className="text-emerald-400 font-bold text-xl">
                            Safeguarding is not an afterthought.
                        </p>
                        <p className="text-cyan-400 font-bold text-xl mt-1">
                            It is our architecture.
                        </p>
                    </div>
                </section>

                {/* Footer Note */}
                <div className="mt-8 text-center text-slate-500 text-sm">
                    <p>© Minimax Sustainable AI Ltd — Registered in England and Wales</p>
                    <p className="mt-1">Company No: 16864182</p>
                </div>
            </div>
        </div>
    );
}