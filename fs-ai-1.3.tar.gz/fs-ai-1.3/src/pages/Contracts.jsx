import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Plus, Eye, Download, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import toast from 'react-hot-toast';
import ContractGenerator from '../components/contracts/ContractGenerator';
import TemplateEditor from '../components/contracts/TemplateEditor';

export default function Contracts() {
    const [showGenerator, setShowGenerator] = useState(false);
    const [showTemplateEditor, setShowTemplateEditor] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [viewingContract, setViewingContract] = useState(null);

    const queryClient = useQueryClient();

    const { data: contracts = [] } = useQuery({
        queryKey: ['contracts'],
        queryFn: () => base44.entities.Contract.list('-created_date', 50)
    });

    const { data: templates = [] } = useQuery({
        queryKey: ['contract-templates'],
        queryFn: () => base44.entities.ContractTemplate.list('-created_date')
    });

    const deleteContractMutation = useMutation({
        mutationFn: (id) => base44.entities.Contract.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contracts'] });
            toast.success('Contract deleted');
        }
    });

    const deleteTemplateMutation = useMutation({
        mutationFn: (id) => base44.entities.ContractTemplate.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contract-templates'] });
            toast.success('Template deleted');
        }
    });

    const getStatusColor = (status) => {
        const colors = {
            'Draft': 'bg-slate-500/20 text-slate-400 border-slate-500/30',
            'Pending Review': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'Approved': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            'Signed': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Archived': 'bg-slate-600/20 text-slate-500 border-slate-600/30'
        };
        return colors[status] || colors['Draft'];
    };

    const downloadContract = (contract) => {
        const blob = new Blob([contract.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${contract.title.replace(/\s+/g, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent mb-2">
                            Contract Management
                        </h1>
                        <p className="text-slate-400">Generate contracts from templates</p>
                    </div>
                    <Button
                        onClick={() => setShowGenerator(true)}
                        className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        New Contract
                    </Button>
                </div>

                <Tabs defaultValue="contracts">
                    <TabsList className="grid w-full grid-cols-2 bg-slate-800 mb-6">
                        <TabsTrigger value="contracts" className="data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
                            <FileText className="w-4 h-4 mr-2" />
                            Contracts ({contracts.length})
                        </TabsTrigger>
                        <TabsTrigger value="templates" className="data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
                            <FileText className="w-4 h-4 mr-2" />
                            Templates ({templates.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="contracts">
                        {contracts.length === 0 ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center">
                                    <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                                    <p className="text-slate-400">No contracts yet</p>
                                    <p className="text-slate-500 text-sm mt-2">Generate your first contract from a template</p>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {contracts.map((contract) => (
                                    <motion.div
                                        key={contract.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                    >
                                        <Card className="bg-slate-900/50 border-slate-800 hover:border-indigo-500/30 transition-all">
                                            <CardHeader>
                                                <div className="flex justify-between items-start">
                                                    <div className="flex-1 min-w-0">
                                                        <CardTitle className="text-white truncate">{contract.title}</CardTitle>
                                                        <p className="text-slate-400 text-xs mt-1">{contract.category}</p>
                                                    </div>
                                                    <Badge className={getStatusColor(contract.status)}>
                                                        {contract.status}
                                                    </Badge>
                                                </div>
                                            </CardHeader>
                                            <CardContent>
                                                <div className="space-y-3">
                                                    <div className="text-xs text-slate-500">
                                                        <p>Created: {new Date(contract.created_date).toLocaleDateString()}</p>
                                                        {contract.template_name && (
                                                            <p className="mt-1">Template: {contract.template_name}</p>
                                                        )}
                                                    </div>
                                                    <div className="flex gap-2">
                                                        <Button
                                                            onClick={() => setViewingContract(contract)}
                                                            size="sm"
                                                            variant="outline"
                                                            className="flex-1 border-slate-700 text-slate-400"
                                                        >
                                                            <Eye className="w-3 h-3 mr-1" />
                                                            View
                                                        </Button>
                                                        <Button
                                                            onClick={() => downloadContract(contract)}
                                                            size="sm"
                                                            variant="outline"
                                                            className="flex-1 border-slate-700 text-slate-400"
                                                        >
                                                            <Download className="w-3 h-3 mr-1" />
                                                            Export
                                                        </Button>
                                                        <Button
                                                            onClick={() => {
                                                                if (confirm('Delete this contract?')) {
                                                                    deleteContractMutation.mutate(contract.id);
                                                                }
                                                            }}
                                                            size="sm"
                                                            variant="ghost"
                                                            className="text-red-400"
                                                        >
                                                            <Trash2 className="w-3 h-3" />
                                                        </Button>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="templates">
                        <div className="mb-6">
                            <Button
                                onClick={() => {
                                    setSelectedTemplate(null);
                                    setShowTemplateEditor(true);
                                }}
                                variant="outline"
                                className="border-indigo-500/30 text-indigo-400"
                            >
                                <Plus className="w-4 h-4 mr-2" />
                                New Template
                            </Button>
                        </div>

                        {templates.length === 0 ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center">
                                    <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                                    <p className="text-slate-400">No templates yet</p>
                                    <p className="text-slate-500 text-sm mt-2">Create your first contract template</p>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {templates.map((template) => (
                                    <Card key={template.id} className="bg-slate-900/50 border-slate-800">
                                        <CardHeader>
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <CardTitle className="text-white">{template.name}</CardTitle>
                                                    <p className="text-slate-400 text-sm mt-1">{template.category}</p>
                                                </div>
                                                {!template.active && (
                                                    <Badge className="bg-slate-600/20 text-slate-500">Inactive</Badge>
                                                )}
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-3">
                                                {template.variables && template.variables.length > 0 && (
                                                    <div>
                                                        <p className="text-slate-500 text-xs mb-2">Variables: {template.variables.length}</p>
                                                        <div className="flex flex-wrap gap-1">
                                                            {template.variables.slice(0, 5).map((v, idx) => (
                                                                <Badge key={idx} className="bg-slate-800 text-slate-400 text-xs">
                                                                    {v.label}
                                                                </Badge>
                                                            ))}
                                                            {template.variables.length > 5 && (
                                                                <Badge className="bg-slate-800 text-slate-400 text-xs">
                                                                    +{template.variables.length - 5} more
                                                                </Badge>
                                                            )}
                                                        </div>
                                                    </div>
                                                )}
                                                <div className="flex gap-2">
                                                    <Button
                                                        onClick={() => {
                                                            setSelectedTemplate(template);
                                                            setShowGenerator(true);
                                                        }}
                                                        size="sm"
                                                        className="flex-1 bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30"
                                                    >
                                                        Use Template
                                                    </Button>
                                                    <Button
                                                        onClick={() => {
                                                            setSelectedTemplate(template);
                                                            setShowTemplateEditor(true);
                                                        }}
                                                        size="sm"
                                                        variant="outline"
                                                        className="border-slate-700 text-slate-400"
                                                    >
                                                        Edit
                                                    </Button>
                                                    <Button
                                                        onClick={() => {
                                                            if (confirm('Delete this template?')) {
                                                                deleteTemplateMutation.mutate(template.id);
                                                            }
                                                        }}
                                                        size="sm"
                                                        variant="ghost"
                                                        className="text-red-400"
                                                    >
                                                        <Trash2 className="w-3 h-3" />
                                                    </Button>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </TabsContent>
                </Tabs>

                {/* Contract Generator Dialog */}
                {showGenerator && (
                    <Dialog open={showGenerator} onOpenChange={setShowGenerator}>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800">
                            <DialogHeader>
                                <DialogTitle className="text-white">Generate Contract</DialogTitle>
                            </DialogHeader>
                            <ContractGenerator
                                templates={templates}
                                preselectedTemplate={selectedTemplate}
                                onComplete={() => {
                                    setShowGenerator(false);
                                    setSelectedTemplate(null);
                                }}
                            />
                        </DialogContent>
                    </Dialog>
                )}

                {/* Template Editor Dialog */}
                {showTemplateEditor && (
                    <Dialog open={showTemplateEditor} onOpenChange={setShowTemplateEditor}>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800">
                            <DialogHeader>
                                <DialogTitle className="text-white">
                                    {selectedTemplate ? 'Edit Template' : 'New Template'}
                                </DialogTitle>
                            </DialogHeader>
                            <TemplateEditor
                                template={selectedTemplate}
                                onComplete={() => {
                                    setShowTemplateEditor(false);
                                    setSelectedTemplate(null);
                                }}
                            />
                        </DialogContent>
                    </Dialog>
                )}

                {/* View Contract Dialog */}
                {viewingContract && (
                    <Dialog open={!!viewingContract} onOpenChange={() => setViewingContract(null)}>
                        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800">
                            <DialogHeader>
                                <DialogTitle className="text-white">{viewingContract.title}</DialogTitle>
                            </DialogHeader>
                            <div className="mt-4">
                                <div className="bg-slate-950 rounded-lg p-6 border border-slate-800">
                                    <div className="prose prose-invert max-w-none">
                                        <pre className="whitespace-pre-wrap text-slate-300 text-sm font-mono">
                                            {viewingContract.content}
                                        </pre>
                                    </div>
                                </div>
                            </div>
                        </DialogContent>
                    </Dialog>
                )}
            </div>
        </div>
    );
}