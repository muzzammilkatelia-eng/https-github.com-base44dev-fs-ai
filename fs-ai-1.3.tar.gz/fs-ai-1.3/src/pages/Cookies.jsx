import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export default function Cookies() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-4xl font-bold text-white mb-6">Cookies Policy</h1>
                <p className="text-slate-400 mb-8">Universal Master Version</p>

                <div className="space-y-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">4.1 Purpose</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                This policy explains how cookies and similar technologies are used across all platforms.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">4.2 Types of Cookies</h2>
                            <ul className="text-slate-300 space-y-3 mb-4">
                                <li>
                                    <strong className="text-white">Essential cookies</strong> — required for platform operation
                                </li>
                                <li>
                                    <strong className="text-white">Analytics cookies</strong> — performance and usage insights
                                </li>
                                <li>
                                    <strong className="text-white">Preference cookies</strong> — saving user settings
                                </li>
                                <li>
                                    <strong className="text-white">Security cookies</strong> — safeguarding and fraud prevention
                                </li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">4.3 Consent</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                Users may manage cookie preferences where applicable.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">4.4 Third-Party Cookies</h2>
                            <p className="text-slate-300 leading-relaxed">
                                Used only where necessary and always under strict compliance.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}