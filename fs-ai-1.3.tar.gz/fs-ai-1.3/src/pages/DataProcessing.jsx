import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export default function DataProcessing() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-4xl font-bold text-white mb-6">Data Processing Agreement</h1>
                <p className="text-slate-400 mb-8">Universal Master Version</p>

                <div className="space-y-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">5.1 Roles</h2>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li><strong className="text-white">Minimax Sustainable AI Ltd</strong> acts as Data Controller</li>
                                <li>Third-party vendors act as Data Processors</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">5.2 Processor Obligations</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Processors must:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Follow written instructions only</li>
                                <li>Maintain confidentiality</li>
                                <li>Implement strong security measures</li>
                                <li>Support data subject rights</li>
                                <li>Assist with audits and compliance</li>
                                <li>Notify of breaches immediately</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">5.3 Sub‑processing</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                Only permitted with explicit written approval.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">5.4 International Transfers</h2>
                            <p className="text-slate-300 leading-relaxed">
                                Handled under UK GDPR-compliant mechanisms.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}