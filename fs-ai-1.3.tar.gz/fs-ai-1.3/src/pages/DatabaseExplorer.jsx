import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Database, TrendingUp, Sparkles, AlertTriangle, Brain, LineChart, Target, Briefcase } from 'lucide-react';
import DatabaseStats from '../components/database/DatabaseStats';
import GeographicFilter from '../components/database/GeographicFilter';
import TalentPipeline from '../components/database/TalentPipeline';
import PlayerDataGrid from '../components/database/PlayerDataGrid';
import AIScoutAssistant from '../components/strategic-planning/AIScoutAssistant';
import AIAnomalyDetector from '../components/ai-analysis/AIAnomalyDetector';
import AIPerformanceTrendPredictor from '../components/ai-analysis/AIPerformanceTrendPredictor';
import AIRecommendationEngine from '../components/ai-analysis/AIRecommendationEngine';
import AIScoutProfileGenerator from '../components/ai-analysis/AIScoutProfileGenerator';
import AITransferConflictPredictor from '../components/ai-analysis/AITransferConflictPredictor';

export default function DatabaseExplorer() {
    const [geographicScope, setGeographicScope] = useState('all');

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-white mb-3">
                        FS–AI Database Explorer
                    </h1>
                    <p className="text-slate-400 text-lg">
                        Smart 5.1 Talent Expansion: Local → Regional → National → Worldwide
                    </p>
                </div>

                <DatabaseStats />

                <div className="flex justify-center">
                    <GeographicFilter 
                        selectedScope={geographicScope} 
                        onScopeChange={setGeographicScope} 
                    />
                </div>

                <Tabs defaultValue="players" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4 md:grid-cols-8">
                        <TabsTrigger value="players" className="flex items-center gap-2">
                            <Database className="w-4 h-4" />
                            Database
                        </TabsTrigger>
                        <TabsTrigger value="pipeline" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Pipeline
                        </TabsTrigger>
                        <TabsTrigger value="scout" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            AI Scout
                        </TabsTrigger>
                        <TabsTrigger value="anomaly" className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" />
                            Anomaly
                        </TabsTrigger>
                        <TabsTrigger value="trends" className="flex items-center gap-2">
                            <LineChart className="w-4 h-4" />
                            Trends
                        </TabsTrigger>
                        <TabsTrigger value="recommendations" className="flex items-center gap-2">
                            <Brain className="w-4 h-4" />
                            Recommend
                        </TabsTrigger>
                        <TabsTrigger value="profile" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Profile AI
                        </TabsTrigger>
                        <TabsTrigger value="conflicts" className="flex items-center gap-2">
                            <Briefcase className="w-4 h-4" />
                            Conflicts
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="players">
                        <PlayerDataGrid geographicScope={geographicScope} />
                    </TabsContent>

                    <TabsContent value="pipeline">
                        <TalentPipeline />
                    </TabsContent>

                    <TabsContent value="scout">
                        <AIScoutAssistant context="database" />
                    </TabsContent>

                    <TabsContent value="anomaly">
                        <AIAnomalyDetector />
                    </TabsContent>

                    <TabsContent value="trends">
                        <AIPerformanceTrendPredictor />
                    </TabsContent>

                    <TabsContent value="recommendations">
                        <AIRecommendationEngine />
                    </TabsContent>

                    <TabsContent value="profile">
                        <AIScoutProfileGenerator />
                    </TabsContent>

                    <TabsContent value="conflicts">
                        <AITransferConflictPredictor />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}