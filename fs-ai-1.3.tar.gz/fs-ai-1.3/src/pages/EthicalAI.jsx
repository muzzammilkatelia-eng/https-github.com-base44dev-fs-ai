import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Sparkles, Users, Shield } from 'lucide-react';

export default function EthicalAI() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center gap-3 mb-6">
                    <Heart className="w-10 h-10 text-cyan-400" />
                    <div>
                        <h1 className="text-4xl font-bold text-white">Ethical AI Framework</h1>
                        <p className="text-slate-400">Universal Master Version</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-purple-400 mb-4">4.1 Mission</h2>
                            <p className="text-slate-300 leading-relaxed">
                                To build AI systems that serve neurodiverse minds, protect vulnerable users, and uphold the dignity of every learner.
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
                                <Shield className="w-6 h-6" />
                                4.2 Ethical Principles
                            </h2>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li><strong className="text-white">Do no harm</strong></li>
                                <li><strong className="text-white">Protect emotional safety</strong></li>
                                <li><strong className="text-white">Respect autonomy and consent</strong></li>
                                <li><strong className="text-white">Design for inclusion</strong></li>
                                <li><strong className="text-white">Refuse unsafe prompts</strong></li>
                                <li><strong className="text-white">Support human flourishing</strong></li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <Sparkles className="w-6 h-6" />
                                4.3 Neurodiverse Alignment
                            </h2>
                            <p className="text-slate-300 leading-relaxed mb-2">All AI systems are designed to:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Reduce cognitive overload</li>
                                <li>Offer emotionally safe interactions</li>
                                <li>Support diverse learning styles</li>
                                <li>Avoid manipulative engagement tactics</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">4.4 Faith-Law-Ethics Integration</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                Where applicable, platforms may offer faith-aligned AI educators (e.g., Halal Computing) with ethical overlays respecting religious and cultural values.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <Users className="w-6 h-6" />
                                4.5 Continuous Review
                            </h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Ethical calibration is ongoing, with:</p>
                            <ul className="text-slate-300 space-y-2 mb-6">
                                <li>User feedback loops</li>
                                <li>Safeguarding audits</li>
                                <li>Sector benchmarking</li>
                                <li>Legacy alignment to Maz's vision</li>
                            </ul>

                            <blockquote className="border-l-4 border-purple-500 pl-4 italic text-slate-300 bg-purple-500/10 p-4 rounded-r-lg">
                                "AI was meant for neurodiverse minds."
                                <footer className="text-slate-500 text-sm mt-2 not-italic">— Muzzammil Katelia, December 2025</footer>
                            </blockquote>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}