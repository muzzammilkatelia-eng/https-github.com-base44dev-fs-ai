import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, BookOpen, Users, FileText, ExternalLink, AlertCircle, GraduationCap, Target, Trophy, Clock, CheckCircle2, DollarSign, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function FIFARegulations() {
    const [activeTab, setActiveTab] = useState('overview');

    const strategicObjectives = [
        { number: 1, title: "Revise FIFA Statutes and Improve Regulations", icon: FileText, description: "Ensure football's regulatory framework remains relevant to changing circumstances" },
        { number: 2, title: "Transfer System Reform", icon: Shield, description: "Implement transfer system reform and address governance matters" },
        { number: 3, title: "Digital Technology & AI", icon: Target, description: "Deliver fan engagement through eFootball and invest in AI for next generations" },
        { number: 4, title: "Youth Tournaments", icon: Trophy, description: "Organise more youth tournaments at various age levels" },
        { number: 5, title: "Player & Coach Development", icon: GraduationCap, description: "Focus on player, coach and referee development and FIFA Academies" },
        { number: 6, title: "Social Responsibilities", icon: Users, description: "Focus on human rights and climate-related aspects" },
        { number: 7, title: "International Match Opportunities", icon: Globe, description: "Provide new international match opportunities for national teams and clubs" },
        { number: 8, title: "Women's World Cup Development", icon: Trophy, description: "Drive further development in women's football" },
        { number: 9, title: "FIFA World Cup 2026", icon: Trophy, description: "Ensure the FIFA World Cup will be the greatest show on the planet" },
        { number: 10, title: "FIFA Club World Cup 2025", icon: Trophy, description: "Organise brand-new FIFA Club World Cup with 32 teams" },
        { number: 11, title: "Financial Goals", icon: DollarSign, description: "Achieve minimum 11 billion USD revenues as part of global administration" }
    ];

    const examProcess = [
        { step: 1, title: "Submit Application", description: "Complete licence application via agents.fifa.com" },
        { step: 2, title: "Meet Eligibility", description: "Comply with all eligibility requirements (Art. 5 FFAR)" },
        { step: 3, title: "Pass FIFA Exam", description: "Successfully complete the FIFA Football Agent Exam" },
        { step: 4, title: "Pay Annual Fee", description: "Pay the annual licensing fee to FIFA" }
    ];

    const examDetails = [
        { label: "Format", value: "20 multiple-choice questions", icon: FileText },
        { label: "Duration", value: "60 minutes", icon: Clock },
        { label: "Pass Mark", value: "75% (15/20 correct)", icon: Target },
        { label: "Scoring", value: "5% per correct answer", icon: CheckCircle2 },
        { label: "Type", value: "Open-book (online materials allowed)", icon: BookOpen },
        { label: "Languages", value: "English, Spanish, French, German", icon: Globe }
    ];

    const examSubjects = [
        "FIFA Football Agent Regulations (FFAR)",
        "FIFA Regulations on Status and Transfer of Players",
        "FIFA Clearing House Regulations",
        "FIFA Statutes",
        "FIFA Code of Ethics",
        "FIFA Disciplinary Code",
        "FIFA Guardians Child Safeguarding Toolkit"
    ];

    const eligibilityRequirements = [
        "No formal educational requirements",
        "No professional experience required",
        "Must pass FIFA Football Agent Exam",
        "Must comply with eligibility checks (Art. 5 FFAR)",
        "Must pay annual fee to FIFA",
        "No exemptions for lawyers, accountants, or former players"
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <Shield className="w-8 h-8 text-cyan-400" />
                        <div>
                            <h1 className="text-3xl font-bold text-white">FIFA Regulations & Agent Compliance</h1>
                            <p className="text-slate-400">Official regulatory framework • Strategic Objectives 2023-2027</p>
                        </div>
                    </div>

                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                            <AlertCircle className="w-5 h-5 text-amber-400 mt-0.5" />
                            <div>
                                <h3 className="text-white font-semibold mb-1">Mandatory Compliance</h3>
                                <p className="text-slate-300 text-sm">
                                    All FS-AI users involved in player transfers, scouting, or agent activities must comply with FIFA regulations 
                                    and ethical guidelines. New FFAR regulations came into force on 1 January 2025.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="bg-slate-800/50 mb-6">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="objectives">Strategic Objectives</TabsTrigger>
                        <TabsTrigger value="licensing">Agent Licensing</TabsTrigger>
                        <TabsTrigger value="exam">Exam Details</TabsTrigger>
                        <TabsTrigger value="ethics">Ethics & Compliance</TabsTrigger>
                    </TabsList>

                    {/* Overview Tab */}
                    <TabsContent value="overview">
                        <div className="grid gap-6">
                            <Card className="bg-slate-900/50 border-cyan-500/30">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <Globe className="w-6 h-6 text-cyan-400" />
                                        Football Unites the World
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <p className="text-slate-300">
                                        FIFA's mission: "To bring football back to FIFA, and FIFA back to football." 
                                        The 2023-2027 strategic plan focuses on making football truly global with 211 member associations worldwide.
                                    </p>
                                    
                                    <div className="grid md:grid-cols-3 gap-4">
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="text-cyan-400 text-2xl font-bold">211</div>
                                            <div className="text-slate-400 text-sm">FIFA Member Associations</div>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="text-emerald-400 text-2xl font-bold">$11B</div>
                                            <div className="text-slate-400 text-sm">Projected Revenue 2023-2026</div>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <div className="text-purple-400 text-2xl font-bold">$2.25B</div>
                                            <div className="text-slate-400 text-sm">FIFA Forward 3.0 Investment</div>
                                        </div>
                                    </div>

                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                        <h4 className="text-white font-semibold mb-2">Core FIFA Objectives (Article 2 of FIFA Statutes)</h4>
                                        <ul className="space-y-2 text-slate-300 text-sm">
                                            <li className="flex items-start gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5" />
                                                <span>Promote football globally through youth and development programmes</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5" />
                                                <span>Draw up regulations governing football and ensure enforcement</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5" />
                                                <span>Ensure football is available to all, regardless of gender or age</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5" />
                                                <span>Promote integrity, ethics and fair play to prevent corruption and abuse</span>
                                            </li>
                                        </ul>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Strategic Objectives Tab */}
                    <TabsContent value="objectives">
                        <div className="grid gap-4">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">FIFA's 11 Strategic Objectives (2023-2027)</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        {strategicObjectives.map((objective) => {
                                            const Icon = objective.icon;
                                            return (
                                                <div key={objective.number} className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors">
                                                    <div className="flex items-start gap-3">
                                                        <div className="bg-cyan-500/20 rounded-lg p-2">
                                                            <Icon className="w-5 h-5 text-cyan-400" />
                                                        </div>
                                                        <div className="flex-1">
                                                            <div className="flex items-center gap-2 mb-1">
                                                                <Badge className="bg-cyan-500/20 text-cyan-400">#{objective.number}</Badge>
                                                                <h3 className="text-white font-semibold text-sm">{objective.title}</h3>
                                                            </div>
                                                            <p className="text-slate-400 text-xs">{objective.description}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Agent Licensing Tab */}
                    <TabsContent value="licensing">
                        <div className="space-y-6">
                            <Card className="bg-slate-900/50 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <GraduationCap className="w-6 h-6 text-emerald-400" />
                                        How to Become a Licensed Football Agent
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div className="grid md:grid-cols-4 gap-4">
                                        {examProcess.map((item) => (
                                            <div key={item.step} className="bg-slate-800/50 rounded-lg p-4 text-center">
                                                <div className="bg-emerald-500/20 text-emerald-400 rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-3 text-lg font-bold">
                                                    {item.step}
                                                </div>
                                                <h3 className="text-white font-semibold mb-1 text-sm">{item.title}</h3>
                                                <p className="text-slate-400 text-xs">{item.description}</p>
                                            </div>
                                        ))}
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                            Eligibility Requirements
                                        </h3>
                                        <div className="grid md:grid-cols-2 gap-3">
                                            {eligibilityRequirements.map((req, idx) => (
                                                <div key={idx} className="flex items-center gap-2">
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                    <span className="text-slate-300 text-sm">{req}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-2">Key Information</h3>
                                        <ul className="space-y-2 text-slate-300 text-sm">
                                            <li className="flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                <span>Licensed by FIFA (not national associations)</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                <span>Territory of exam irrelevant - global recognition</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                <span>Exam held annually during specific windows</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                <span>Unlimited attempts allowed (new application required after failure)</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-cyan-400">•</span>
                                                <span>No exemptions based on profession (lawyers, accountants, former players)</span>
                                            </li>
                                        </ul>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Exam Details Tab */}
                    <TabsContent value="exam">
                        <div className="space-y-6">
                            <Card className="bg-slate-900/50 border-purple-500/30">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <GraduationCap className="w-6 h-6 text-purple-400" />
                                        FIFA Football Agent Exam - Complete Guide
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    {/* Exam Format */}
                                    <div>
                                        <h3 className="text-white font-semibold mb-3">Exam Format & Requirements</h3>
                                        <div className="grid md:grid-cols-3 gap-3">
                                            {examDetails.map((detail, idx) => {
                                                const Icon = detail.icon;
                                                return (
                                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-3">
                                                        <div className="flex items-center gap-2 mb-1">
                                                            <Icon className="w-4 h-4 text-purple-400" />
                                                            <span className="text-slate-400 text-xs">{detail.label}</span>
                                                        </div>
                                                        <p className="text-white font-semibold text-sm">{detail.value}</p>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>

                                    {/* Exam Subjects */}
                                    <div>
                                        <h3 className="text-white font-semibold mb-3">Exam Study Materials</h3>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <ul className="space-y-2">
                                                {examSubjects.map((subject, idx) => (
                                                    <li key={idx} className="flex items-center gap-2 text-slate-300 text-sm">
                                                        <FileText className="w-4 h-4 text-purple-400" />
                                                        {subject}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>

                                    {/* Remote Exam Setup */}
                                    <div>
                                        <h3 className="text-white font-semibold mb-3">Remote Exam Setup</h3>
                                        <div className="bg-slate-800/50 rounded-lg p-4 space-y-3">
                                            <div className="flex items-start gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">✓</Badge>
                                                <div>
                                                    <p className="text-white font-semibold text-sm">Location</p>
                                                    <p className="text-slate-400 text-xs">Take exam anywhere worldwide (no travel required)</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">✓</Badge>
                                                <div>
                                                    <p className="text-white font-semibold text-sm">Equipment Required</p>
                                                    <p className="text-slate-400 text-xs">Laptop/desktop with webcam + smartphone with camera (secondary device)</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">✓</Badge>
                                                <div>
                                                    <p className="text-white font-semibold text-sm">Environment</p>
                                                    <p className="text-slate-400 text-xs">Private, quiet room with no other people present</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">✓</Badge>
                                                <div>
                                                    <p className="text-white font-semibold text-sm">Invigilation</p>
                                                    <p className="text-slate-400 text-xs">Live remote invigilation via webcam + mobile app monitoring</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Badge className="bg-cyan-500/20 text-cyan-400">✓</Badge>
                                                <div>
                                                    <p className="text-white font-semibold text-sm">ID Verification</p>
                                                    <p className="text-slate-400 text-xs">Valid government-issued photo ID required</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Important Dates */}
                                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                            <Clock className="w-5 h-5 text-amber-400" />
                                            Important Timelines
                                        </h3>
                                        <ul className="space-y-2 text-slate-300 text-sm">
                                            <li>• Exam held annually during specific windows</li>
                                            <li>• Results released within 14 days of exam date</li>
                                            <li>• 3-day review period for failed attempts</li>
                                            <li>• Medical accommodations require 30-day advance notice</li>
                                        </ul>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Strategic Objectives Tab */}
                    <TabsContent value="objectives">
                        <div className="grid gap-6">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Detailed Strategic Objectives</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    {strategicObjectives.map((objective) => {
                                        const Icon = objective.icon;
                                        return (
                                            <div key={objective.number} className="bg-slate-800/30 rounded-lg p-4 border border-slate-700/50">
                                                <div className="flex items-start gap-4">
                                                    <div className="bg-cyan-500/20 rounded-lg p-3">
                                                        <Icon className="w-6 h-6 text-cyan-400" />
                                                    </div>
                                                    <div className="flex-1">
                                                        <div className="flex items-center gap-2 mb-2">
                                                            <Badge className="bg-cyan-500/20 text-cyan-400">Objective {objective.number}</Badge>
                                                            <h3 className="text-white font-semibold">{objective.title}</h3>
                                                        </div>
                                                        <p className="text-slate-300 text-sm">{objective.description}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </CardContent>
                            </Card>

                            {/* Key Initiatives */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <Target className="w-6 h-6 text-cyan-400" />
                                        Key FIFA Initiatives
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-2">FIFA Forward 3.0</h4>
                                            <p className="text-slate-300 text-sm mb-2">$2.25 billion development investment (2023-2026)</p>
                                            <p className="text-slate-400 text-xs">7x increase from pre-2016 levels • Minimum $8M per member association</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-2">FIFA Talent Development Scheme</h4>
                                            <p className="text-slate-300 text-sm mb-2">$200M funding for talent pathways</p>
                                            <p className="text-slate-400 text-xs">75 FIFA Academies target by 2027 • "Give Every Talent A Chance"</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-2">FIFA Clearing House</h4>
                                            <p className="text-slate-300 text-sm mb-2">Operational since November 2022</p>
                                            <p className="text-slate-400 text-xs">Ensures solidarity payments reach training clubs • Promotes transparency</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <h4 className="text-white font-semibold mb-2">FIFA Guardians™</h4>
                                            <p className="text-slate-300 text-sm mb-2">Safeguarding in Sport Programme</p>
                                            <p className="text-slate-400 text-xs">Child protection framework • Online diploma for safeguarding officers</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Exam Details Tab */}
                    <TabsContent value="exam">
                        <div className="space-y-6">
                            <Card className="bg-slate-900/50 border-purple-500/30">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <FileText className="w-6 h-6 text-purple-400" />
                                        Exam Technical Specifications
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3">Critical Rules & Requirements</h3>
                                        <div className="space-y-3 text-sm text-slate-300">
                                            <div className="flex items-start gap-2">
                                                <AlertCircle className="w-4 h-4 text-purple-400 mt-0.5" />
                                                <div>
                                                    <p className="font-semibold text-white">Prohibited Items</p>
                                                    <p className="text-xs text-slate-400">No phones, smartwatches, notes, or external materials except approved items</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-2">
                                                <AlertCircle className="w-4 h-4 text-purple-400 mt-0.5" />
                                                <div>
                                                    <p className="font-semibold text-white">Communication Ban</p>
                                                    <p className="text-xs text-slate-400">No talking, reading aloud, or communicating with anyone during exam</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-2">
                                                <AlertCircle className="w-4 h-4 text-purple-400 mt-0.5" />
                                                <div>
                                                    <p className="font-semibold text-white">No Breaks</p>
                                                    <p className="text-xs text-slate-400">No toilet breaks or pauses allowed during 60-minute session</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-2">
                                                <AlertCircle className="w-4 h-4 text-purple-400 mt-0.5" />
                                                <div>
                                                    <p className="font-semibold text-white">Recording Prohibited</p>
                                                    <p className="text-xs text-slate-400">No screenshots, photos, or recordings of any kind</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3">Allowed Items</h3>
                                        <div className="grid md:grid-cols-2 gap-2">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-300 text-sm">Prescription glasses</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-300 text-sm">Non-alcoholic beverage</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-300 text-sm">Electronic Study Materials</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-300 text-sm">Blank paper & pen (must destroy after)</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                                <span className="text-slate-300 text-sm">Approved medical aids</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3">Technical Requirements</h3>
                                        <div className="space-y-2 text-slate-300 text-sm">
                                            <p><strong className="text-white">Primary Device:</strong> Laptop/desktop with functional camera, microphone, and Safe Exam Browser installed</p>
                                            <p><strong className="text-white">Secondary Device:</strong> Smartphone with FIFA Agent Exam mobile app for multi-angle monitoring</p>
                                            <p><strong className="text-white">Internet:</strong> Strong and reliable connection (FIFA cannot provide support for connection issues)</p>
                                            <p><strong className="text-white">Room:</strong> Private, quiet, well-lit, no other people allowed</p>
                                            <p><strong className="text-white">ID:</strong> Original government-issued photo ID (same as application)</p>
                                        </div>
                                    </div>

                                    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                            <AlertCircle className="w-5 h-5 text-red-400" />
                                            Disqualification Triggers
                                        </h3>
                                        <ul className="space-y-1 text-slate-300 text-xs">
                                            <li>• Using prohibited items or unauthorized devices</li>
                                            <li>• Communicating with anyone during exam session</li>
                                            <li>• Leaving exam session before instructed</li>
                                            <li>• Impersonation or having someone else take exam</li>
                                            <li>• Recording, screenshotting, or copying exam content</li>
                                            <li>• Using VPN or accessing unauthorized websites/software</li>
                                        </ul>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Ethics & Compliance Tab */}
                    <TabsContent value="ethics">
                        <div className="space-y-6">
                            <Card className="bg-slate-900/50 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-3">
                                        <BookOpen className="w-6 h-6 text-emerald-400" />
                                        Ethical Framework & Code of Conduct
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3">FIFA Football Agent Code of Conduct</h3>
                                        <p className="text-slate-300 text-sm mb-3">
                                            All licensed agents must adhere to FIFA's Ethical Recruitment Guide and professional standards:
                                        </p>
                                        <div className="grid md:grid-cols-2 gap-3">
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Player safeguarding protocols</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Transparent communication</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Fair contract terms</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Anti-trafficking compliance</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Minor protection standards</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className="bg-emerald-500/20 text-emerald-400">✓</Badge>
                                                <span className="text-slate-300 text-sm">Financial transparency</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-slate-800/50 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-3">Key Compliance Documents</h3>
                                        <div className="space-y-2">
                                            {[
                                                "FIFA Football Agent Regulations (FFAR) - 2025 Edition",
                                                "FIFA Code of Ethics",
                                                "FIFA Disciplinary Code",
                                                "Ethical Decision-Making Framework",
                                                "Ethical Recruitment Checklist",
                                                "FIFA Football Agents Ethical Communications Guide",
                                                "FIFA Guardians™ Safeguarding Toolkit"
                                            ].map((doc, idx) => (
                                                <div key={idx} className="flex items-center gap-2 text-slate-300 text-sm">
                                                    <FileText className="w-4 h-4 text-emerald-400" />
                                                    {doc}
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                                        <h3 className="text-white font-semibold mb-2">Anti-Discrimination & Human Rights</h3>
                                        <p className="text-slate-300 text-sm mb-3">
                                            FIFA is committed to respecting all internationally recognized human rights and promoting their protection. 
                                            Key initiatives include:
                                        </p>
                                        <ul className="space-y-2 text-slate-300 text-sm">
                                            <li>• Social Media Protection Service for players</li>
                                            <li>• Task force on combating racism in football</li>
                                            <li>• Partnership with UN agencies on human rights</li>
                                            <li>• FIFA Good Practice Guide on Diversity and Anti-Discrimination</li>
                                            <li>• Whistleblowing system for reporting abuse</li>
                                        </ul>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>

                {/* Footer Actions */}
                <div className="mt-8 grid md:grid-cols-2 gap-4">
                    <Button
                        className="w-full bg-cyan-600 hover:bg-cyan-700"
                        onClick={() => window.open('https://inside.fifa.com/transfer-system/agents', '_blank')}
                    >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        FIFA Official Agents Portal
                    </Button>
                    <Button
                        className="w-full bg-purple-600 hover:bg-purple-700"
                        onClick={() => window.open('https://agents.fifa.com', '_blank')}
                    >
                        <GraduationCap className="w-4 h-4 mr-2" />
                        Apply for Agent License
                    </Button>
                </div>

                {/* Contact Footer */}
                <div className="mt-8 border-t border-slate-800 pt-6">
                    <p className="text-slate-500 text-sm text-center">
                        FS-AI is committed to supporting FIFA's regulatory framework and promoting ethical football recruitment practices.
                        <br />
                        For compliance inquiries: <a href="mailto:regulatory@fifa.org" className="text-cyan-400 hover:text-cyan-300">regulatory@fifa.org</a>
                        <br />
                        <span className="text-slate-600 text-xs mt-2 block">
                            Data sourced from FIFA Strategic Objectives 2023-2027 & FIFA Agent Licensing Process Documentation (March 2025)
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
}