import React from 'react';
import SearchAndLearnEngine from '../components/awareness/SearchAndLearnEngine';
import { Brain } from 'lucide-react';

export default function FootballAwarenessEngine() {
    return (
        <div className="min-h-screen py-12 px-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
                        <Brain className="w-10 h-10 text-purple-400" />
                        Football Awareness Engine
                    </h1>
                    <p className="text-slate-400">
                        Adaptive intelligence system that searches, predicts, evaluates, and learns from live football data
                    </p>
                </div>

                <SearchAndLearnEngine />
            </div>
        </div>
    );
}