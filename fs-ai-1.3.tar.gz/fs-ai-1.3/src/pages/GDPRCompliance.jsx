import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, CheckCircle } from 'lucide-react';

export default function GDPRCompliance() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center gap-3 mb-6">
                    <Shield className="w-10 h-10 text-cyan-400" />
                    <div>
                        <h1 className="text-4xl font-bold text-white">GDPR Compliance</h1>
                        <p className="text-slate-400">Universal Master Version</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">1.1 Commitment</h2>
                            <p className="text-slate-300 leading-relaxed">
                                All platforms operated under the Al Isa ecosystem are fully committed to GDPR compliance, with safeguarding-first design and privacy-by-default embedded in every system.
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">1.2 Lawful Basis</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Data is processed under lawful bases including:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Consent (where applicable)</li>
                                <li>Contractual necessity</li>
                                <li>Legal obligation</li>
                                <li>Legitimate interest (with safeguarding-first balancing tests)</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <CheckCircle className="w-6 h-6" />
                                1.3 Data Subject Rights
                            </h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Users have full rights under GDPR:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Access</li>
                                <li>Rectification</li>
                                <li>Erasure</li>
                                <li>Restriction</li>
                                <li>Objection</li>
                                <li>Portability</li>
                                <li>Right to withdraw consent</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">1.4 Data Protection Officer</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                A designated DPO oversees compliance across all platforms. Contact details available on each platform's footer or privacy centre.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">1.5 Children's Data</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">
                                Platforms follow the UK Children's Code (Age Appropriate Design Code), with:
                            </p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Age gating</li>
                                <li>Parental consent mechanisms</li>
                                <li>Educator AI refusal protocols</li>
                                <li>Emotional safety prioritised over engagement</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">1.6 International Transfers</h2>
                            <p className="text-slate-300 leading-relaxed">
                                Handled under UK GDPR-compliant mechanisms including adequacy decisions and standard contractual clauses.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}