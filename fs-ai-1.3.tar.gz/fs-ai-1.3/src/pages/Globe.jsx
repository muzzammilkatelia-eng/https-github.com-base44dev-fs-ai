import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RotateCcw, Search, Info, RefreshCw, Loader2, Navigation, Users, BarChart3, Filter, GitCompare, TrendingUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TalentGlobe from '../components/globe/TalentGlobe';
import CountryMap from '../components/globe/CountryMap';
import LayerSelector from '../components/globe/LayerSelector';
import HotspotPanel from '../components/globe/HotspotPanel';
import GPSTracker from '../components/globe/GPSTracker';
import PlayerGPSFeed from '../components/globe/PlayerGPSFeed';
import GlobalNetworkPanel from '../components/network/GlobalNetworkPanel';
import NetworkFeed from '../components/network/NetworkFeed';
import MarketTrendsChart from '../components/globe/MarketTrendsChart';
import DataFiltersPanel from '../components/globe/DataFiltersPanel';
import PlayerComparison from '../components/globe/PlayerComparison';
import MarketForecastPanel from '../components/globe/MarketForecastPanel';
import toast from 'react-hot-toast';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function Globe() {
    const [selectedLayer, setSelectedLayer] = useState('wonderkids');
    const [selectedHotspot, setSelectedHotspot] = useState(null);
    const [selectedCountry, setSelectedCountry] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [showInfo, setShowInfo] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [heatmapData, setHeatmapData] = useState([]);
    const [lastUpdated, setLastUpdated] = useState(null);
    const [autoRefresh, setAutoRefresh] = useState(false);
    const [gpsLocation, setGpsLocation] = useState(null);
    const [showGPS, setShowGPS] = useState(false);
    const [playerLocations, setPlayerLocations] = useState([]);
    const [showNetwork, setShowNetwork] = useState(false);
    const [sharedGPSData, setSharedGPSData] = useState(null);
    const [showCharts, setShowCharts] = useState(false);
    const [showFilters, setShowFilters] = useState(false);
    const [showComparison, setShowComparison] = useState(false);
    const [filteredData, setFilteredData] = useState([]);
    const [selectedPlayersForComparison, setSelectedPlayersForComparison] = useState([]);
    const [showForecast, setShowForecast] = useState(false);

    // Initial mock data
    const initialHeatmapData = [
        {
            region: 'São Paulo',
            country: 'Brazil',
            lat: -23.5505,
            lng: -46.6333,
            count: 47,
            avgScore: 78,
            riskLevel: 'Medium',
            valueDelta: 72,
            trajectory: 'Rising - High European Interest',
            topPlayers: [
                { name: 'Lucas Silva', position: 'Winger', age: 19, score: 85, tags: ['Speed', 'Dribbling', 'High Ceiling'] },
                { name: 'Gabriel Santos', position: 'Striker', age: 20, score: 82, tags: ['Finishing', 'Movement', 'Clinical'] },
                { name: 'Rafael Costa', position: 'CAM', age: 18, score: 79, tags: ['Vision', 'Creativity', 'Wonderkid'] }
            ],
            pathway: 'Strong pipeline from São Paulo FC and Santos academies. Recommended 18-month loan to Portuguese league before EPL integration.',
            riskFactors: 'Work permit challenges for under-21s. Cultural adaptation period needed. Agent relationships crucial.'
        },
        {
            region: 'Buenos Aires',
            country: 'Argentina',
            lat: -34.6037,
            lng: -58.3816,
            count: 38,
            avgScore: 81,
            riskLevel: 'Low',
            valueDelta: 85,
            trajectory: 'Stable - Proven European Success Rate',
            topPlayers: [
                { name: 'Mateo Rodriguez', position: 'CM', age: 21, score: 88, tags: ['Technique', 'Vision', 'Elite'] },
                { name: 'Santiago Lopez', position: 'CB', age: 22, score: 83, tags: ['Defensive IQ', 'Passing', 'Leader'] }
            ],
            pathway: 'Direct to top-5 league feasible. River Plate and Boca Juniors provide excellent foundational training.',
            riskFactors: 'Premium pricing. High competition from Spanish clubs.'
        },
        {
            region: 'Lagos',
            country: 'Nigeria',
            lat: 6.5244,
            lng: 3.3792,
            count: 29,
            avgScore: 73,
            riskLevel: 'High',
            valueDelta: 89,
            trajectory: 'Emerging - Undervalued Market',
            topPlayers: [
                { name: 'Chibueze Okafor', position: 'Striker', age: 19, score: 76, tags: ['Athleticism', 'Raw Talent', 'Hidden Gem'] },
                { name: 'Emmanuel Adebayo', position: 'Winger', age: 20, score: 74, tags: ['Pace', 'Potential', 'Physical'] }
            ],
            pathway: 'Belgian or Portuguese league recommended as stepping stone. 2-year development window optimal.',
            riskFactors: 'Limited video data. Work permit complexity. Adaptation to European football culture required.'
        },
        {
            region: 'Paris',
            country: 'France',
            lat: 48.8566,
            lng: 2.3522,
            count: 52,
            avgScore: 84,
            riskLevel: 'Low',
            valueDelta: 45,
            trajectory: 'Mature - Premium Pricing',
            topPlayers: [
                { name: 'Antoine Dubois', position: 'Full-Back', age: 21, score: 87, tags: ['Technical', 'Tactical IQ', 'Modern FB'] },
                { name: 'Kylian Martin', position: 'DM', age: 20, score: 85, tags: ['Ball-Winner', 'Distribution', 'Press-Resistant'] }
            ],
            pathway: 'First-team ready. PSG and academy system produces elite technical foundations.',
            riskFactors: 'High market value. Contract complexity. Agent negotiations challenging.'
        },
        {
            region: 'Amsterdam',
            country: 'Netherlands',
            lat: 52.3676,
            lng: 4.9041,
            count: 31,
            avgScore: 86,
            riskLevel: 'Very Low',
            valueDelta: 52,
            trajectory: 'Stable - Ajax Pipeline Proven',
            topPlayers: [
                { name: 'Lars van der Berg', position: 'CB', age: 20, score: 89, tags: ['Ball-Playing CB', 'Composure', 'Elite Technical'] },
                { name: 'Thijs Bakker', position: 'CM', age: 19, score: 84, tags: ['Positional IQ', 'Passing', 'Ajax DNA'] }
            ],
            pathway: 'Seamless transition to top European leagues. Technical purity exceptional.',
            riskFactors: 'Premium pricing for proven talent. High competition from German clubs.'
        },
        {
            region: 'Doha',
            country: 'Qatar',
            lat: 25.2854,
            lng: 51.5310,
            count: 18,
            avgScore: 68,
            riskLevel: 'High',
            valueDelta: 94,
            trajectory: 'Speculative - Emerging Infrastructure',
            topPlayers: [
                { name: 'Ahmed Al-Rashid', position: 'CAM', age: 19, score: 71, tags: ['Technical', 'Set-Pieces', 'Emerging'] }
            ],
            pathway: 'Loan to European club essential. Academy infrastructure improving rapidly post-World Cup.',
            riskFactors: 'Unproven at elite level. Cultural adjustment significant. Limited competitive match experience.'
        }
    ];

    // Initialize with mock data on mount
    React.useEffect(() => {
        if (heatmapData.length === 0) {
            setHeatmapData(initialHeatmapData);
            setFilteredData(initialHeatmapData);
        }
    }, []);

    // Update filtered data when heatmap changes
    React.useEffect(() => {
        if (!showFilters) {
            setFilteredData(heatmapData);
        }
    }, [heatmapData, showFilters]);

    const handleRefreshData = async () => {
        setIsRefreshing(true);
        toast.loading('Fetching live market data from Transfermarkt & sources...', { id: 'refresh' });

        try {
            // Use backend function if available, otherwise fallback to direct LLM
            let result;
            
            try {
                result = await base44.functions.fetchMarketIntelligence({
                    regions: ['Brazil', 'Argentina', 'France', 'Netherlands', 'Nigeria', 'Portugal', 'Belgium', 'Spain', 'Germany', 'Japan'],
                    includeTopPlayers: true
                });
                
                if (result.success) {
                    setHeatmapData(result.data.hotspots);
                    setLastUpdated(new Date());
                    toast.success(`Live data updated: ${result.data.market_summary}`, { id: 'refresh', duration: 4000 });
                    return;
                }
            } catch (fnError) {
                console.log('Backend function not available, using direct integration');
            }

            // Fallback to direct LLM integration
            const prompt = `Access Transfermarkt, BBC Sport, and transfer news sources for REAL-TIME market intelligence as of ${new Date().toLocaleString()}.

For each of 8-10 major football talent hotspots, provide VERIFIED CURRENT DATA:

1. **Location Data**:
   - Region name and country
   - Exact latitude/longitude coordinates

2. **Live Market Metrics** (use current transfer market data):
   - Number of high-potential players currently monitored
   - Average talent score (0-100, based on recent performance stats and market value)
   - Risk level (Very Low/Low/Medium/High)
   - Value delta % (undervaluation vs current market price)
   - Market trajectory with specific trend indicators

3. **Top Players** (2-4 per region with REAL stats):
   - Full name (real current players or realistic prospects)
   - Position
   - Current age
   - Talent score based on:
     * Recent match performance (goals, assists, key passes, tackles, etc.)
     * Current market value in millions (€)
     * Contract expiry date
     * Transfer rumors/interest level
   - Performance tags (e.g., "23 goals in 25 games", "€45M valuation", "Contract 2026")
   
4. **Intelligence**:
   - Development pathway recommendation
   - Current risk factors with specific examples
   - Recent transfer activity in region

Focus on: Brazil, Argentina, France, Netherlands, Nigeria, Portugal, Belgium, Spain, Germany, and emerging markets (Saudi, USA, Japan).

Use REAL current transfer market intelligence from December 2025, recent match performance data, actual market valuations, and ongoing transfer negotiations.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        last_updated: { type: "string" },
                        market_summary: { type: "string" },
                        hotspots: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    region: { type: "string" },
                                    country: { type: "string" },
                                    lat: { type: "number" },
                                    lng: { type: "number" },
                                    count: { type: "number" },
                                    avgScore: { type: "number" },
                                    riskLevel: { type: "string" },
                                    valueDelta: { type: "number" },
                                    trajectory: { type: "string" },
                                    topPlayers: {
                                        type: "array",
                                        items: {
                                            type: "object",
                                            properties: {
                                                name: { type: "string" },
                                                position: { type: "string" },
                                                age: { type: "number" },
                                                score: { type: "number" },
                                                market_value: { type: "number" },
                                                contract_expiry: { type: "string" },
                                                recent_performance: { type: "string" },
                                                tags: { type: "array", items: { type: "string" } }
                                            }
                                        }
                                    },
                                    pathway: { type: "string" },
                                    riskFactors: { type: "string" }
                                }
                            }
                        }
                    }
                }
            });

            setHeatmapData(response.hotspots || initialHeatmapData);
            setLastUpdated(new Date());
            toast.success(`Live data updated successfully`, { id: 'refresh', duration: 3000 });
        } catch (error) {
            console.error('Failed to refresh data:', error);
            toast.error('Failed to fetch live data. Using cached data.', { id: 'refresh' });
            setHeatmapData(initialHeatmapData);
        } finally {
            setIsRefreshing(false);
        }
    };

    // Auto-refresh every 5 minutes if enabled
    React.useEffect(() => {
        if (!autoRefresh) return;
        
        const interval = setInterval(() => {
            handleRefreshData();
        }, 5 * 60 * 1000); // 5 minutes

        return () => clearInterval(interval);
    }, [autoRefresh]);

    const handleResetGlobe = () => {
        // Reset camera position and rotation
        setSelectedHotspot(null);
        setSelectedCountry(null);
    };

    const handleCountryClick = (country) => {
        setSelectedCountry(country);
        setSelectedHotspot(null);
    };

    const handleGPSUpdate = (location) => {
        setGpsLocation(location);
        
        // Add user location as a special hotspot
        const userHotspot = {
            region: 'Your Location',
            country: 'Current Position',
            lat: location.lat,
            lng: location.lng,
            count: 1,
            avgScore: 100,
            riskLevel: 'GPS',
            valueDelta: 0,
            trajectory: 'Live Tracking',
            topPlayers: [],
            pathway: 'Your current GPS position',
            riskFactors: 'N/A',
            isUserLocation: true
        };
        
        // Update heatmap with user location
        setHeatmapData(prev => {
            const filtered = prev.filter(h => !h.isUserLocation && !h.isPlayerGPS);
            return [userHotspot, ...filtered];
        });
    };

    const handlePlayerLocationUpdate = (locations) => {
        setPlayerLocations(locations);
        
        // Add player GPS locations to heatmap
        const playerHotspots = locations.map(player => ({
            region: player.name,
            country: 'Player GPS',
            lat: player.lat,
            lng: player.lng,
            count: 1,
            avgScore: 95,
            riskLevel: 'Player',
            valueDelta: 0,
            trajectory: 'Live Player Tracking',
            topPlayers: [{
                name: player.name,
                metrics: player.metrics
            }],
            pathway: `Live GPS data: ${player.metrics.distance}km, ${player.metrics.topSpeed}km/h`,
            riskFactors: `Recovery: ${player.metrics.recoveryStatus}`,
            isPlayerGPS: true,
            playerMetrics: player.metrics
        }));
        
        // Update heatmap
        setHeatmapData(prev => {
            const filtered = prev.filter(h => !h.isPlayerGPS);
            return [...filtered, ...playerHotspots];
        });
    };

    return (
        <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 overflow-hidden">
            {/* Quantum Background Grid Effect */}
            <div className="absolute inset-0 opacity-30">
                <div className="absolute inset-0 animate-pulse" style={{
                    backgroundImage: `
                        linear-gradient(rgba(6, 182, 212, 0.15) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(6, 182, 212, 0.15) 1px, transparent 1px)
                    `,
                    backgroundSize: '40px 40px'
                }} />
                <div className="absolute inset-0" style={{
                    backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(6, 182, 212, 0.1) 0%, transparent 50%)'
                }} />
            </div>
            
            {/* Scanning beam effect */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50 animate-scan" 
                     style={{
                         animation: 'scan 8s linear infinite',
                         boxShadow: '0 0 20px rgba(6, 182, 212, 0.8)'
                     }} />
            </div>
            
            <style>{`
                @keyframes scan {
                    0%, 100% { transform: translateY(-100%); }
                    50% { transform: translateY(100vh); }
                }
            `}</style>

            {/* Top Controls */}
            <div className="absolute top-4 sm:top-6 left-1/2 transform -translate-x-1/2 z-10 flex items-center gap-2 sm:gap-4 px-4">
                <div className="bg-slate-900/80 backdrop-blur-xl border border-cyan-500/30 rounded-xl px-3 sm:px-6 py-2 sm:py-3 shadow-lg shadow-cyan-500/20 flex items-center gap-3">
                    <div>
                        <h1 className="text-lg sm:text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent animate-pulse">
                            ⚛️ Quantum Talent Globe
                        </h1>
                        <p className="text-[10px] sm:text-xs text-cyan-400 text-center mt-1">Neural Network • Real-time Intelligence</p>
                    </div>
                    <HelpTooltip content="Explore global talent distribution on an interactive 3D globe. Discover emerging markets, track player movements, and identify talent hotspots worldwide." position="bottom" />
                </div>
            </div>

            {/* Search */}
            <div className="absolute top-4 sm:top-6 right-4 sm:right-6 z-10 flex flex-col sm:flex-row items-end sm:items-center gap-2 sm:gap-3">
                <div className="relative w-full sm:w-auto">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 w-full sm:w-48 md:w-64 bg-slate-900/80 backdrop-blur-xl border-slate-700 text-white text-sm"
                    />
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <Button
                        onClick={() => setShowForecast(!showForecast)}
                        className={`${showForecast ? 'bg-indigo-500 hover:bg-indigo-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        size="icon"
                        title="AI Forecast"
                    >
                        <TrendingUp className="w-4 h-4" />
                    </Button>
                    <Button
                        onClick={() => setShowCharts(!showCharts)}
                        className={`${showCharts ? 'bg-cyan-500 hover:bg-cyan-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        size="icon"
                        title="Market Analytics"
                    >
                        <BarChart3 className="w-4 h-4" />
                    </Button>
                    <Button
                        onClick={() => setShowFilters(!showFilters)}
                        className={`${showFilters ? 'bg-purple-500 hover:bg-purple-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        size="icon"
                        title="Advanced Filters"
                    >
                        <Filter className="w-4 h-4" />
                    </Button>
                    <Button
                        onClick={() => setShowComparison(!showComparison)}
                        className={`${showComparison ? 'bg-amber-500 hover:bg-amber-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        size="icon"
                        title="Compare Players"
                    >
                        <GitCompare className="w-4 h-4" />
                    </Button>
                    <Button
                        onClick={() => setShowGPS(!showGPS)}
                        className={`${showGPS ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                        size="icon"
                        title="GPS Tracker"
                    >
                        <Navigation className="w-4 h-4" />
                    </Button>
                    <Button
                        onClick={handleRefreshData}
                        disabled={isRefreshing}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white"
                        size="icon"
                        title="Refresh with live market data"
                    >
                        {isRefreshing ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <RefreshCw className="w-4 h-4" />
                        )}
                    </Button>
                    {lastUpdated && (
                        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-lg px-3 py-2">
                            <p className="text-slate-400 text-xs">
                                Updated: {lastUpdated.toLocaleTimeString()}
                            </p>
                        </div>
                    )}
                </div>
                <Button
                    onClick={() => setShowInfo(!showInfo)}
                    className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 hover:bg-slate-800"
                    size="icon"
                >
                    <Info className="w-4 h-4" />
                </Button>
            </div>

            {/* Info Panel */}
            <AnimatePresence>
                {showInfo && (
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="absolute top-20 sm:top-24 right-4 sm:right-6 z-10 w-[calc(100vw-2rem)] sm:w-80 max-w-md bg-slate-900/95 backdrop-blur-xl border border-cyan-500/30 rounded-xl p-4 sm:p-6 shadow-xl shadow-cyan-500/10 max-h-[60vh] overflow-y-auto"
                    >
                        <div className="flex items-start justify-between mb-4">
                            <h3 className="text-white font-bold text-lg">How to Use</h3>
                            <button
                                onClick={() => setShowInfo(false)}
                                className="text-slate-400 hover:text-white"
                            >
                                <Info className="w-4 h-4" />
                            </button>
                        </div>
                        <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm text-slate-300">
                            <p>🖱️ <span className="text-cyan-400">Drag/swipe</span> to rotate</p>
                            <p>🔍 <span className="text-cyan-400">Scroll/pinch</span> to zoom</p>
                            <p>📍 <span className="text-cyan-400">Tap hotspots</span> for details</p>
                            <p>🎨 <span className="text-cyan-400">Select layers</span> to filter</p>
                            <p>🌍 <span className="text-amber-400">Hotspot size</span> = player count</p>
                            <p>🔄 <span className="text-cyan-400">Refresh</span> = live market data</p>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Layer Selector - hide when in country view */}
            {!selectedCountry && (
                <LayerSelector 
                    selectedLayer={selectedLayer} 
                    onLayerChange={setSelectedLayer} 
                />
            )}

            {/* Globe or Country Map */}
            <AnimatePresence mode="wait">
                {selectedCountry ? (
                    <CountryMap
                        key="country-map"
                        country={selectedCountry}
                        onBack={() => setSelectedCountry(null)}
                    />
                ) : (
                    <div key="globe" className="absolute inset-0">
                        <TalentGlobe
                            selectedLayer={selectedLayer}
                            onHotspotClick={setSelectedHotspot}
                            onCountryClick={handleCountryClick}
                            heatmapData={heatmapData}
                            gpsLocation={gpsLocation}
                        />
                    </div>
                )}
            </AnimatePresence>

            {/* Reset Button */}
            {!selectedCountry && (
                <div className="absolute bottom-4 sm:bottom-8 left-1/2 transform -translate-x-1/2 z-10">
                    <Button
                        onClick={handleResetGlobe}
                        className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 hover:bg-slate-800 text-white text-sm"
                        size="sm"
                    >
                        <RotateCcw className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                        Reset View
                    </Button>
                </div>
            )}

            {/* Hotspot Detail Panel */}
            {!selectedCountry && (
                <AnimatePresence>
                    {selectedHotspot && (
                        <HotspotPanel
                            hotspot={selectedHotspot}
                            onClose={() => setSelectedHotspot(null)}
                            onAddToComparison={(player) => {
                                if (selectedPlayersForComparison.length < 4) {
                                    setSelectedPlayersForComparison(prev => [...prev, player]);
                                    setShowComparison(true);
                                    toast.success(`${player.name} added to comparison`);
                                } else {
                                    toast.error('Maximum 4 players can be compared');
                                }
                            }}
                        />
                    )}
                </AnimatePresence>
            )}

            {/* Network Toggle */}
            {!selectedCountry && (
                <div className="absolute top-20 left-1/2 -translate-x-1/2 z-10">
                    <Button
                        onClick={() => setShowNetwork(!showNetwork)}
                        className={`${showNetwork ? 'bg-cyan-600' : 'bg-slate-800'} hover:bg-cyan-700`}
                    >
                        <Users className="w-4 h-4 mr-2" />
                        {showNetwork ? 'Hide Network' : 'Show Network'}
                    </Button>
                </div>
            )}

            {!showNetwork && (
                <>
                    {/* GPS Tracker Panel */}
                    {!selectedCountry && showGPS && (
                        <div className="absolute top-24 right-4 sm:right-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                            <GPSTracker onLocationUpdate={handleGPSUpdate} />
                        </div>
                    )}

                    {/* Player GPS Feed - Only show if GPS is enabled */}
                    {!selectedCountry && showGPS && (
                        <div className="absolute top-24 left-4 sm:left-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                            <PlayerGPSFeed onPlayerLocationUpdate={handlePlayerLocationUpdate} />
                        </div>
                    )}
                </>
            )}

            {/* Network Panels */}
            {showNetwork && !selectedCountry && (
                <>
                    <div className="absolute top-24 left-4 sm:left-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                        <GlobalNetworkPanel />
                    </div>
                    <div className="absolute top-24 right-4 sm:right-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                        <NetworkFeed sharedGPSData={sharedGPSData} />
                    </div>
                </>
            )}

            {/* Analytics Panels */}
            {!showNetwork && !selectedCountry && (
                <>
                    {showCharts && (
                        <div className="absolute top-24 right-4 sm:right-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                            <MarketTrendsChart heatmapData={filteredData} />
                        </div>
                    )}
                    {showForecast && (
                        <div className="absolute top-24 right-4 sm:right-6 z-20 w-96 max-w-[calc(100vw-2rem)]">
                            <MarketForecastPanel 
                                regions={Array.from(new Set(filteredData.map(h => h.country))).filter(Boolean).slice(0, 10)}
                                horizon={6}
                                onClose={() => setShowForecast(false)}
                            />
                        </div>
                    )}
                    {showFilters && (
                        <div className="absolute top-24 left-4 sm:left-6 z-10 w-96 max-w-[calc(100vw-2rem)]">
                            <DataFiltersPanel 
                                heatmapData={heatmapData}
                                onFilterChange={setFilteredData}
                                onClose={() => setShowFilters(false)}
                            />
                        </div>
                    )}
                    {showComparison && (
                        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-10 w-96 max-w-[calc(100vw-2rem)]">
                            <PlayerComparison 
                                selectedPlayers={selectedPlayersForComparison}
                                onRemovePlayer={(index) => setSelectedPlayersForComparison(prev => prev.filter((_, i) => i !== index))}
                                onClose={() => setShowComparison(false)}
                            />
                        </div>
                    )}
                </>
            )}

            {/* Legend - hide in country view */}
            {!selectedCountry && (
                <div className="absolute bottom-4 sm:bottom-8 left-4 sm:left-6 z-10 bg-slate-900/90 backdrop-blur-xl border border-cyan-500/30 rounded-xl p-3 sm:p-4 shadow-lg shadow-cyan-500/20 max-w-[calc(100vw-8rem)] sm:max-w-none">
                <h4 className="text-cyan-400 font-semibold text-sm mb-3 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    Quantum Metrics
                </h4>
                <div className="flex items-center gap-3 mb-3">
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-cyan-500"></div>
                        <span className="text-slate-400 text-xs">Low</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-amber-500"></div>
                        <span className="text-slate-400 text-xs">Medium</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-red-500"></div>
                        <span className="text-slate-400 text-xs">High</span>
                    </div>
                </div>
                {heatmapData.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-700">
                        <p className="text-slate-500 text-xs flex items-center gap-1">
                            <RefreshCw className="w-3 h-3" />
                            Live market data
                        </p>
                        <label className="flex items-center gap-2 cursor-pointer">
                            <input
                                type="checkbox"
                                checked={autoRefresh}
                                onChange={(e) => setAutoRefresh(e.target.checked)}
                                className="w-3 h-3 rounded border-slate-600 text-cyan-500 focus:ring-cyan-500"
                            />
                            <span className="text-slate-500 text-xs">Auto-refresh (5 min)</span>
                        </label>
                    </div>
                )}
                </div>
            )}
        </div>
    );
}