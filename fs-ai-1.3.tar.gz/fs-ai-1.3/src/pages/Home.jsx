import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Target, TrendingUp, Users, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Home() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
            {/* Profile Card - Top Right */}
            <div className="absolute top-24 right-6 z-40">
                <Card className="bg-gradient-to-br from-slate-900/95 to-slate-800/95 border-amber-500/30 shadow-xl w-[280px] backdrop-blur-sm">
                    <CardContent className="p-3">
                        <div className="flex items-start gap-2 mb-2">
                            <img
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/0453bcb66_LOGOFS-AI.jpg"
                                alt="Football Scout AI"
                                className="w-14 h-14 rounded-full border-2 border-amber-500/50 shadow-lg"
                            />
                            <div className="flex-1 min-w-0">
                                <h3 className="text-amber-400 text-xs font-bold tracking-wide mb-0.5 truncate">MUZZAMMIL KATELIA</h3>
                                <p className="text-slate-300 text-[10px] leading-tight mb-0.5">FS-AI / MINIMAX-SUSTAINABLE AI</p>
                                <p className="text-slate-400 text-[10px] font-semibold mb-1">CEO / DIRECTOR</p>
                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-[9px] px-1.5 py-0">
                                    ⭐⭐⭐⭐⭐
                                </Badge>
                            </div>
                            <img
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/797c16885_36471e2a-ae12-42a2-a5d1-31181524eab2.png"
                                alt="QR Code"
                                className="w-12 h-12"
                            />
                        </div>
                        <a 
                            href="https://inscoutnetwork.co.uk" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-cyan-400 hover:text-cyan-300 text-[10px] font-semibold transition-colors block"
                        >
                            VIEW PROFILE →
                        </a>
                    </CardContent>
                </Card>
            </div>

            {/* Hero Section */}
            <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                    className="mb-8"
                >
                    <img
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/0453bcb66_LOGOFS-AI.jpg"
                        alt="FS-AI Logo"
                        className="w-32 h-32 mx-auto rounded-3xl shadow-2xl mb-8 ring-4 ring-amber-500/50"
                    />
                    
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 mb-6 px-4 py-1">
                        • Multi-Archetype Intelligence System
                    </Badge>

                    <h1 className="text-6xl md:text-7xl font-bold mb-6">
                        <span className="text-cyan-400">Football Scout </span>
                        <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-purple-600 bg-clip-text text-transparent">
                            AI
                        </span>
                    </h1>

                    <p className="text-slate-300 text-xl md:text-2xl max-w-3xl mx-auto mb-8 leading-relaxed">
                        A safeguarding-first football intelligence platform for managers, agents, scouts, and fans.
                        <br />
                        Close deals faster with real-time insights, talent tracking, and ethical scouting tools.
                    </p>

                    <Link to={createPageUrl('AIPlayerAnalysis')}>
                        <Button 
                            size="lg"
                            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all duration-300"
                        >
                            Start Scouting
                            <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                    </Link>
                </motion.div>
            </div>

            {/* Stats Section */}
            <div className="max-w-6xl mx-auto px-6 pb-20">
                <div className="grid md:grid-cols-3 gap-6">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                    >
                        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                            <CardContent className="pt-6">
                                <div className="flex items-center gap-4">
                                    <div className="p-3 bg-cyan-500/20 rounded-lg">
                                        <Target className="w-8 h-8 text-cyan-400" />
                                    </div>
                                    <div>
                                        <p className="text-4xl font-bold text-white">5</p>
                                        <p className="text-slate-400 text-sm">Scouting Philosophies</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                    >
                        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                            <CardContent className="pt-6">
                                <div className="flex items-center gap-4">
                                    <div className="p-3 bg-emerald-500/20 rounded-lg">
                                        <TrendingUp className="w-8 h-8 text-emerald-400" />
                                    </div>
                                    <div>
                                        <p className="text-4xl font-bold text-white">2</p>
                                        <p className="text-slate-400 text-sm">AI Projection Models</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 }}
                    >
                        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                            <CardContent className="pt-6">
                                <div className="flex items-center gap-4">
                                    <div className="p-3 bg-amber-500/20 rounded-lg">
                                        <BarChart3 className="w-8 h-8 text-amber-400" />
                                    </div>
                                    <div>
                                        <p className="text-4xl font-bold text-white">1</p>
                                        <p className="text-slate-400 text-sm">Unified Intelligence Hub</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </div>
        </div>
    );
}