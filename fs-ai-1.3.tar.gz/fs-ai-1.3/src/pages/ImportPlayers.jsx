import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Download, CheckCircle, AlertTriangle } from 'lucide-react';
import toast from 'react-hot-toast';
import WorldFootballImporter from '../components/import/WorldFootballImporter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function ImportPlayers() {
    const [leagueId, setLeagueId] = useState('39'); // Premier League
    const [season, setSeason] = useState('2024');
    const [teamId, setTeamId] = useState('');
    const [isImporting, setIsImporting] = useState(false);
    const [result, setResult] = useState(null);

    const handleImport = async () => {
        setIsImporting(true);
        toast.loading('Importing real players from API-Football...', { id: 'import' });

        try {
            const response = await base44.functions.importRealPlayers({
                league_id: parseInt(leagueId),
                season: parseInt(season),
                team_id: teamId ? parseInt(teamId) : undefined
            });

            setResult(response);
            if (response.success) {
                toast.success(response.message, { id: 'import' });
            } else {
                toast.error(response.message, { id: 'import' });
            }
        } catch (error) {
            toast.error('Import failed. Enable backend functions first.', { id: 'import' });
            setResult({ success: false, error: error.message });
        } finally {
            setIsImporting(false);
        }
    };

    const popularLeagues = [
        { id: 39, name: 'Premier League', country: 'England' },
        { id: 140, name: 'La Liga', country: 'Spain' },
        { id: 135, name: 'Serie A', country: 'Italy' },
        { id: 78, name: 'Bundesliga', country: 'Germany' },
        { id: 61, name: 'Ligue 1', country: 'France' }
    ];

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-8">
                    Import Real Players
                </h1>

                <Tabs defaultValue="worldfootball" className="mb-6">
                    <TabsList className="grid w-full grid-cols-2 bg-slate-900/50">
                        <TabsTrigger value="worldfootball">WorldFootball.net</TabsTrigger>
                        <TabsTrigger value="api">API-Football</TabsTrigger>
                    </TabsList>

                    <TabsContent value="worldfootball">
                        <WorldFootballImporter />
                    </TabsContent>

                    <TabsContent value="api">
                        <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white">API-Football Data Import</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div>
                            <Label className="text-slate-300 mb-2 block">League ID</Label>
                            <Input
                                value={leagueId}
                                onChange={(e) => setLeagueId(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="e.g., 39 for Premier League"
                            />
                            <div className="mt-2 space-y-1">
                                <p className="text-slate-400 text-sm mb-2">Popular Leagues:</p>
                                <div className="flex flex-wrap gap-2">
                                    {popularLeagues.map(league => (
                                        <Button
                                            key={league.id}
                                            onClick={() => setLeagueId(league.id.toString())}
                                            variant="outline"
                                            size="sm"
                                            className="text-xs"
                                        >
                                            {league.name} ({league.id})
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        </div>

                        <div>
                            <Label className="text-slate-300 mb-2 block">Season</Label>
                            <Input
                                value={season}
                                onChange={(e) => setSeason(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="2024"
                            />
                        </div>

                        <div>
                            <Label className="text-slate-300 mb-2 block">Team ID (Optional - leave blank for multiple teams)</Label>
                            <Input
                                value={teamId}
                                onChange={(e) => setTeamId(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-white"
                                placeholder="Leave blank to import from 5 teams"
                            />
                        </div>

                        <Button
                            onClick={handleImport}
                            disabled={isImporting}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                        >
                            {isImporting ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Importing Players...
                                </>
                            ) : (
                                <>
                                    <Download className="w-4 h-4 mr-2" />
                                    Import Players
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>

                {result && (
                    <Card className={`${result.success ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                        <CardHeader>
                            <CardTitle className={`flex items-center gap-2 ${result.success ? 'text-emerald-400' : 'text-red-400'}`}>
                                {result.success ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                                Import Result
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <p className="text-slate-300">{result.message}</p>
                            {result.imported_count && (
                                <p className="text-slate-400 text-sm">Players imported: {result.imported_count}</p>
                            )}
                            {result.errors && result.errors.length > 0 && (
                                <div>
                                    <p className="text-amber-400 text-sm mb-2">Errors:</p>
                                    <ul className="text-slate-400 text-xs space-y-1 max-h-48 overflow-y-auto">
                                        {result.errors.map((err, i) => (
                                            <li key={i}>• {err}</li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                            {result.error && (
                                <p className="text-red-400 text-sm">{result.error}</p>
                            )}
                        </CardContent>
                    </Card>
                )}

                <Card className="bg-amber-500/10 border-amber-500/30 mt-6">
                    <CardContent className="pt-6">
                        <h3 className="text-amber-400 font-semibold mb-2">Setup Required</h3>
                        <ol className="text-slate-300 text-sm space-y-2 list-decimal list-inside">
                            <li>Enable backend functions in Dashboard → Settings</li>
                            <li>The function will import up to 50 players (10 per team, 5 teams max)</li>
                            <li>Players are automatically deduplicated</li>
                            <li>Uses your API-Football API key: ...cd892962</li>
                        </ol>
                    </CardContent>
                </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}