import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
    Brain, Loader2, Zap, TrendingUp, Globe, 
    Database, BarChart3, Target, Sparkles, DollarSign, FileText, Building2
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import GlobalTalentMap from '../components/intelligence/GlobalTalentMap';
import TransferValuePredictor from '../components/intelligence/TransferValuePredictor';
import ContractExpiryScanner from '../components/intelligence/ContractExpiryScanner';
import ClubStrategyAnalyzer from '../components/intelligence/ClubStrategyAnalyzer';

export default function IntelligenceEngine() {
    const [isProcessing, setIsProcessing] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const queryClient = useQueryClient();

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const filteredPlayers = players.filter(p => 
        p.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.position?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const scoredPlayers = filteredPlayers.filter(p => p.fsai_proprietary_score);
    const unscoredPlayers = filteredPlayers.filter(p => !p.fsai_proprietary_score);

    const processAllPlayers = async () => {
        if (user?.role !== 'admin') {
            toast.error('Admin access required');
            return;
        }

        setIsProcessing(true);
        toast.loading('Processing entire database...', { id: 'process-all' });

        let processed = 0;
        let failed = 0;

        for (const player of unscoredPlayers) {
            try {
                const reports = await base44.entities.ScoutingReport.filter({ player_name: player.name });
                const projections = await base44.entities.PlayerProjection.list();
                const projection = projections.find(p => p.player_name?.toLowerCase() === player.name?.toLowerCase());

                const prompt = `Generate FS-AI proprietary score for: ${player.name} (${player.position}, ${player.age}y, ${player.league})

Physical: ${JSON.stringify(player.physical_attributes || {})}
Reports: ${reports.length} available
${projection ? `Projection: ${projection.potential_trajectory}` : ''}

Return 8-dimensional score + overall (0-100 each) + investment grade.`;

                const response = await base44.integrations.Core.InvokeLLM({
                    prompt,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            technical_mastery: { type: "number" },
                            physical_dominance: { type: "number" },
                            mental_fortitude: { type: "number" },
                            tactical_awareness: { type: "number" },
                            development_velocity: { type: "number" },
                            market_efficiency: { type: "number" },
                            archetype_purity: { type: "number" },
                            injury_resilience: { type: "number" },
                            overall_fsai_score: { type: "number" },
                            investment_grade: { type: "string" }
                        }
                    }
                });

                await base44.entities.Player.update(player.id, {
                    fsai_proprietary_score: response.overall_fsai_score,
                    fsai_score_breakdown: {
                        technical_mastery: response.technical_mastery,
                        physical_dominance: response.physical_dominance,
                        mental_fortitude: response.mental_fortitude,
                        tactical_awareness: response.tactical_awareness,
                        development_velocity: response.development_velocity,
                        market_efficiency: response.market_efficiency,
                        archetype_purity: response.archetype_purity,
                        injury_resilience: response.injury_resilience
                    },
                    fsai_investment_grade: response.investment_grade,
                    fsai_score_timestamp: new Date().toISOString()
                });

                processed++;
            } catch (error) {
                console.error(`Failed to process ${player.name}:`, error);
                failed++;
            }
        }

        queryClient.invalidateQueries(['players']);
        toast.success(`Processed ${processed} players (${failed} failed)`, { id: 'process-all' });
        setIsProcessing(false);
    };

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    const stats = {
        total: players.length,
        scored: scoredPlayers.length,
        coverage: players.length > 0 ? ((scoredPlayers.length / players.length) * 100).toFixed(1) : 0,
        avgScore: scoredPlayers.length > 0 
            ? (scoredPlayers.reduce((acc, p) => acc + (p.fsai_proprietary_score || 0), 0) / scoredPlayers.length).toFixed(1)
            : 0
    };

    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        FS-AI Intelligence Engine
                    </h1>
                    <p className="text-slate-400">Proprietary Data Spine • Cross-League Normalization • Global Talent Mapping</p>
                </div>

                {/* Stats Overview */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <Database className="w-5 h-5 text-cyan-400" />
                                <Badge className="bg-cyan-500/20 text-cyan-400">Total</Badge>
                            </div>
                            <p className="text-3xl font-bold text-white">{stats.total}</p>
                            <p className="text-slate-400 text-sm">Players in Database</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <Brain className="w-5 h-5 text-purple-400" />
                                <Badge className="bg-purple-500/20 text-purple-400">Scored</Badge>
                            </div>
                            <p className="text-3xl font-bold text-white">{stats.scored}</p>
                            <p className="text-slate-400 text-sm">FS-AI Scored</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <Target className="w-5 h-5 text-emerald-400" />
                                <Badge className="bg-emerald-500/20 text-emerald-400">Coverage</Badge>
                            </div>
                            <p className="text-3xl font-bold text-white">{stats.coverage}%</p>
                            <p className="text-slate-400 text-sm">Database Coverage</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between mb-2">
                                <BarChart3 className="w-5 h-5 text-amber-400" />
                                <Badge className="bg-amber-500/20 text-amber-400">Average</Badge>
                            </div>
                            <p className="text-3xl font-bold text-white">{stats.avgScore}</p>
                            <p className="text-slate-400 text-sm">Avg FS-AI Score</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Actions */}
                <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-500/30 mb-8">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-purple-400" />
                            Intelligence Operations
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="flex flex-wrap gap-3">
                            <Button
                                onClick={processAllPlayers}
                                disabled={isProcessing || user?.role !== 'admin'}
                                className="bg-gradient-to-r from-purple-500 to-blue-600"
                            >
                                {isProcessing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Processing {unscoredPlayers.length} Players...
                                    </>
                                ) : (
                                    <>
                                        <Zap className="w-4 h-4 mr-2" />
                                        Score All Players ({unscoredPlayers.length})
                                    </>
                                )}
                            </Button>
                            {user?.role !== 'admin' && (
                                <Badge className="bg-red-500/20 text-red-400">Admin Only</Badge>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Tabs */}
                <Tabs defaultValue="market" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                        <TabsTrigger value="market" className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" /> Transfer Market
                        </TabsTrigger>
                        <TabsTrigger value="map" className="flex items-center gap-1">
                            <Globe className="w-3 h-3" /> Talent Map
                        </TabsTrigger>
                        <TabsTrigger value="contracts" className="flex items-center gap-1">
                            <FileText className="w-3 h-3" /> Contracts
                        </TabsTrigger>
                        <TabsTrigger value="database" className="flex items-center gap-1">
                            <Database className="w-3 h-3" /> Database
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="market" className="mt-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <TransferValuePredictor />
                            <ClubStrategyAnalyzer />
                        </div>
                    </TabsContent>

                    <TabsContent value="map" className="mt-6">
                        <GlobalTalentMap />
                    </TabsContent>

                    <TabsContent value="contracts" className="mt-6">
                        <ContractExpiryScanner />
                    </TabsContent>

                    <TabsContent value="database" className="mt-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <CardTitle className="text-white">Player Intelligence Scores</CardTitle>
                                    <Input
                                        placeholder="Search players..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="max-w-xs bg-slate-800 border-slate-700 text-white"
                                    />
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2 max-h-96 overflow-y-auto">
                                    {filteredPlayers.length === 0 && (
                                        <p className="text-slate-400 text-center py-8">No players found</p>
                                    )}
                                    {filteredPlayers.map((player) => (
                                        <motion.div
                                            key={player.id}
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            className="bg-slate-800/50 rounded-lg p-4 flex items-center justify-between"
                                        >
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-1">
                                                    <h4 className="text-white font-semibold">{player.name}</h4>
                                                    <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                        {player.position}
                                                    </Badge>
                                                    <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                        {player.age}y
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-400 text-sm">{player.current_club} • {player.league}</p>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                {player.fsai_proprietary_score ? (
                                                    <>
                                                        <div className="text-right">
                                                            <p className={`text-2xl font-bold ${
                                                                player.fsai_proprietary_score >= 85 ? 'text-emerald-400' :
                                                                player.fsai_proprietary_score >= 70 ? 'text-cyan-400' :
                                                                player.fsai_proprietary_score >= 50 ? 'text-amber-400' :
                                                                'text-red-400'
                                                            }`}>
                                                                {player.fsai_proprietary_score}
                                                            </p>
                                                            <p className="text-slate-500 text-xs">FS-AI Score</p>
                                                        </div>
                                                        {player.fsai_investment_grade && (
                                                            <Badge className={
                                                                player.fsai_investment_grade?.startsWith('A') ? 'bg-emerald-500/20 text-emerald-400' :
                                                                player.fsai_investment_grade?.startsWith('B') ? 'bg-cyan-500/20 text-cyan-400' :
                                                                'bg-amber-500/20 text-amber-400'
                                                            }>
                                                                {player.fsai_investment_grade}
                                                            </Badge>
                                                        )}
                                                    </>
                                                ) : (
                                                    <Badge className="bg-slate-700 text-slate-400">Not Scored</Badge>
                                                )}
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}