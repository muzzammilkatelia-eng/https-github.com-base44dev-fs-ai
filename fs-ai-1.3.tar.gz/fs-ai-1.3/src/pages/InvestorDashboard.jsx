import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Users, DollarSign, Activity, BarChart3 } from 'lucide-react';
import UserGrowthChart from '../components/investor/UserGrowthChart';
import MRRChart from '../components/investor/MRRChart';
import EngagementMetrics from '../components/investor/EngagementMetrics';
import PartnershipMetrics from '../components/investor/PartnershipMetrics';
import InvestorContactManager from '../components/investor/InvestorContactManager';
import ExportButton from '../components/ExportButton';

export default function InvestorDashboard() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadUser = async () => {
            try {
                const currentUser = await base44.auth.me();
                setUser(currentUser);
            } catch (error) {
                console.error('Failed to load user:', error);
            } finally {
                setIsLoading(false);
            }
        };
        loadUser();
    }, []);

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center animate-pulse">
                        <BarChart3 className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-slate-400">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    if (user?.role !== 'admin') {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Card className="bg-red-500/10 border-red-500/30 max-w-md">
                    <CardContent className="pt-6 text-center">
                        <p className="text-red-400">Access Denied: Admin/Investor access required</p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex justify-between items-start">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-indigo-500 bg-clip-text text-transparent mb-2">
                            Investor Dashboard
                        </h1>
                        <p className="text-slate-400">
                            Real-time metrics for growth, revenue, and engagement
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <ExportButton 
                            entityType="Sale" 
                            title="Revenue Data"
                            label="Export Revenue"
                        />
                        <ExportButton 
                            entityType="Scout" 
                            title="User Data"
                            label="Export Users"
                        />
                    </div>
                </div>

                {/* Key Metrics Summary */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border-purple-500/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-300">Total Users</CardTitle>
                            <Users className="h-5 w-5 text-purple-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold text-white" id="total-users-count">-</div>
                            <p className="text-xs text-slate-400 mt-1">Across all types</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-300">MRR</CardTitle>
                            <DollarSign className="h-5 w-5 text-emerald-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold text-white" id="mrr-count">-</div>
                            <p className="text-xs text-slate-400 mt-1">Monthly recurring</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-300">Reports Generated</CardTitle>
                            <Activity className="h-5 w-5 text-cyan-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold text-white" id="reports-count">-</div>
                            <p className="text-xs text-slate-400 mt-1">This month</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-300">Growth Rate</CardTitle>
                            <TrendingUp className="h-5 w-5 text-amber-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold text-white" id="growth-rate">-</div>
                            <p className="text-xs text-slate-400 mt-1">User growth MoM</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Detailed Analytics Tabs */}
                <Tabs defaultValue="growth" className="space-y-4">
                    <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                        <TabsTrigger value="growth" className="data-[state=active]:bg-purple-500/20">
                            <Users className="w-4 h-4 mr-2" />
                            User Growth
                        </TabsTrigger>
                        <TabsTrigger value="revenue" className="data-[state=active]:bg-emerald-500/20">
                            <DollarSign className="w-4 h-4 mr-2" />
                            Revenue
                        </TabsTrigger>
                        <TabsTrigger value="engagement" className="data-[state=active]:bg-cyan-500/20">
                            <Activity className="w-4 h-4 mr-2" />
                            Engagement
                        </TabsTrigger>
                        <TabsTrigger value="partnerships" className="data-[state=active]:bg-amber-500/20">
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Partnerships
                        </TabsTrigger>
                        <TabsTrigger value="reporting" className="data-[state=active]:bg-indigo-500/20">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Automated Reports
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="growth">
                        <UserGrowthChart />
                    </TabsContent>

                    <TabsContent value="revenue">
                        <MRRChart />
                    </TabsContent>

                    <TabsContent value="engagement">
                        <EngagementMetrics />
                    </TabsContent>

                    <TabsContent value="partnerships">
                        <PartnershipMetrics />
                    </TabsContent>

                    <TabsContent value="reporting">
                        <InvestorContactManager />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}