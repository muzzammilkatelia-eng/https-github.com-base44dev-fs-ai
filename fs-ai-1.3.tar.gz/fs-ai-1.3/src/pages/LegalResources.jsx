import React from 'react';
import { base44 } from '@/api/base44Client';
import LegalResourceUploader from '../components/legal/LegalResourceUploader';
import LegalResourceLibrary from '../components/legal/LegalResourceLibrary';

export default function LegalResources() {
    const [user, setUser] = React.useState(null);

    React.useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
    }, []);

    const isAdmin = user?.role === 'admin';

    return (
        <div className="min-h-screen py-12 px-6">
            <div className="max-w-5xl mx-auto space-y-8">
                <div className="text-center">
                    <h1 className="text-4xl font-bold text-white mb-4">
                        Legal Resources & Compliance
                    </h1>
                    <p className="text-slate-400 max-w-2xl mx-auto">
                        Access FA Handbook, safeguarding guidelines, and other legal resources required for scout compliance.
                    </p>
                </div>

                <LegalResourceLibrary />

                {isAdmin && (
                    <div className="border-t border-slate-800 pt-8">
                        <h2 className="text-2xl font-bold text-white mb-6">Admin: Upload New Resource</h2>
                        <LegalResourceUploader />
                    </div>
                )}
            </div>
        </div>
    );
}