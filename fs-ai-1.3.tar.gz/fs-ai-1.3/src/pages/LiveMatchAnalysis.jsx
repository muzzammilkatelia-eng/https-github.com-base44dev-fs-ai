import React from 'react';
import LiveMatchStream from '../components/live-match/LiveMatchStream';
import { Activity } from 'lucide-react';

export default function LiveMatchAnalysis() {
    return (
        <div className="min-h-screen py-12 px-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
                        <Activity className="w-10 h-10 text-cyan-400" />
                        Live Match Analysis
                    </h1>
                    <p className="text-slate-400">
                        Real-time tactical insights, statistics, and event streaming with AI-powered analysis
                    </p>
                </div>

                <LiveMatchStream />
            </div>
        </div>
    );
}