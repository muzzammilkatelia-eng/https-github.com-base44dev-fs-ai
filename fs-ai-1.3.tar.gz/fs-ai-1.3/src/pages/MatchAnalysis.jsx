import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, TrendingUp, Users, Target, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import MatchInsights from '../components/match-analysis/MatchInsights';
import PlayerContributions from '../components/match-analysis/PlayerContributions';
import TacticalRecommendations from '../components/match-analysis/TacticalRecommendations';
import PremiumGate from '../components/PremiumGate';

export default function MatchAnalysis() {
    return (
        <PremiumGate>
            <MatchAnalysisContent />
        </PremiumGate>
    );
}

function MatchAnalysisContent() {
    const [matchData, setMatchData] = useState({
        home_team: '',
        away_team: '',
        score: '',
        date: '',
        home_formation: '',
        away_formation: '',
        home_tactics: '',
        away_tactics: ''
    });
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const analyzeMatch = async () => {
        if (!matchData.home_team || !matchData.away_team || !matchData.score) {
            toast.error('Please fill in match details');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('AI analyzing match...', { id: 'match-analysis' });

        try {
            const playerDetails = selectedPlayers.map(pid => {
                const player = players.find(p => p.id === pid);
                return player ? {
                    name: player.name,
                    position: player.position,
                    age: player.age,
                    physical: player.physical_attributes,
                    style: player.playing_style
                } : null;
            }).filter(Boolean);

            const prompt = `Analyze this football match comprehensively:

MATCH DETAILS:
${matchData.home_team} ${matchData.score} ${matchData.away_team}
Date: ${matchData.date}
Home Formation: ${matchData.home_formation}
Away Formation: ${matchData.away_formation}

TACTICAL APPROACH:
Home: ${matchData.home_tactics || 'Not specified'}
Away: ${matchData.away_tactics || 'Not specified'}

PLAYERS IN MATCH:
${playerDetails.map(p => `
- ${p.name} (${p.position}, ${p.age}y)
  Physical: ${JSON.stringify(p.physical)}
  Style: ${JSON.stringify(p.style)}
`).join('\n')}

ANALYZE:
1. Match outcome explanation - why did the result happen?
2. Key tactical moments and turning points
3. Individual player contributions and ratings (0-10)
4. Formation effectiveness analysis
5. Tactical mistakes and missed opportunities
6. What worked well for each team
7. What didn't work for each team
8. Detailed tactical adjustments for next match
9. Player-specific recommendations
10. Formation alternatives to consider`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        match_summary: { type: "string" },
                        outcome_explanation: { type: "string" },
                        winning_factors: { type: "array", items: { type: "string" } },
                        key_moments: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    minute: { type: "string" },
                                    event: { type: "string" },
                                    impact: { type: "string" },
                                    tactical_significance: { type: "string" }
                                }
                            }
                        },
                        player_ratings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    rating: { type: "number" },
                                    performance_summary: { type: "string" },
                                    key_contributions: { type: "array", items: { type: "string" } },
                                    areas_to_improve: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        formation_analysis: {
                            type: "object",
                            properties: {
                                home_effectiveness: { type: "number" },
                                away_effectiveness: { type: "number" },
                                home_analysis: { type: "string" },
                                away_analysis: { type: "string" },
                                exploited_weaknesses: { type: "array", items: { type: "string" } }
                            }
                        },
                        tactical_mistakes: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    team: { type: "string" },
                                    mistake: { type: "string" },
                                    consequence: { type: "string" }
                                }
                            }
                        },
                        what_worked: {
                            type: "object",
                            properties: {
                                home: { type: "array", items: { type: "string" } },
                                away: { type: "array", items: { type: "string" } }
                            }
                        },
                        what_didnt_work: {
                            type: "object",
                            properties: {
                                home: { type: "array", items: { type: "string" } },
                                away: { type: "array", items: { type: "string" } }
                            }
                        },
                        tactical_adjustments: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    team: { type: "string" },
                                    adjustment: { type: "string" },
                                    reasoning: { type: "string" },
                                    priority: { type: "string" },
                                    expected_impact: { type: "string" }
                                }
                            }
                        },
                        player_recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    recommendations: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        alternative_formations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    team: { type: "string" },
                                    formation: { type: "string" },
                                    reasoning: { type: "string" },
                                    advantages: { type: "array", items: { type: "string" } }
                                }
                            }
                        }
                    }
                }
            });

            setAnalysis(response);
            toast.success('Analysis complete!', { id: 'match-analysis' });
        } catch (error) {
            console.error('Analysis failed:', error);
            toast.error('Failed to analyze match', { id: 'match-analysis' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        AI Match Analysis
                    </h1>
                    <p className="text-slate-400">Analyze past matches to extract tactical insights and improvement strategies</p>
                </div>

                <div className="grid lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-1">
                        <Card className="bg-slate-900/50 border-slate-800 sticky top-6">
                            <CardHeader>
                                <CardTitle className="text-white">Match Details</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <Label className="text-slate-300">Home Team</Label>
                                        <Input
                                            value={matchData.home_team}
                                            onChange={(e) => setMatchData({...matchData, home_team: e.target.value})}
                                            placeholder="e.g., Arsenal"
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Away Team</Label>
                                        <Input
                                            value={matchData.away_team}
                                            onChange={(e) => setMatchData({...matchData, away_team: e.target.value})}
                                            placeholder="e.g., Liverpool"
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <Label className="text-slate-300">Score</Label>
                                        <Input
                                            value={matchData.score}
                                            onChange={(e) => setMatchData({...matchData, score: e.target.value})}
                                            placeholder="2-1"
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Date</Label>
                                        <Input
                                            type="date"
                                            value={matchData.date}
                                            onChange={(e) => setMatchData({...matchData, date: e.target.value})}
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <Label className="text-slate-300">Home Formation</Label>
                                        <Select value={matchData.home_formation} onValueChange={(v) => setMatchData({...matchData, home_formation: v})}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue placeholder="Select" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="4-3-3">4-3-3</SelectItem>
                                                <SelectItem value="4-4-2">4-4-2</SelectItem>
                                                <SelectItem value="4-2-3-1">4-2-3-1</SelectItem>
                                                <SelectItem value="3-5-2">3-5-2</SelectItem>
                                                <SelectItem value="3-4-3">3-4-3</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label className="text-slate-300">Away Formation</Label>
                                        <Select value={matchData.away_formation} onValueChange={(v) => setMatchData({...matchData, away_formation: v})}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue placeholder="Select" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="4-3-3">4-3-3</SelectItem>
                                                <SelectItem value="4-4-2">4-4-2</SelectItem>
                                                <SelectItem value="4-2-3-1">4-2-3-1</SelectItem>
                                                <SelectItem value="3-5-2">3-5-2</SelectItem>
                                                <SelectItem value="3-4-3">3-4-3</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div>
                                    <Label className="text-slate-300">Home Tactics</Label>
                                    <Textarea
                                        value={matchData.home_tactics}
                                        onChange={(e) => setMatchData({...matchData, home_tactics: e.target.value})}
                                        placeholder="Describe tactical approach..."
                                        className="bg-slate-800 border-slate-700 text-white"
                                        rows={3}
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-300">Away Tactics</Label>
                                    <Textarea
                                        value={matchData.away_tactics}
                                        onChange={(e) => setMatchData({...matchData, away_tactics: e.target.value})}
                                        placeholder="Describe tactical approach..."
                                        className="bg-slate-800 border-slate-700 text-white"
                                        rows={3}
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-300 mb-2 block">Select Players (Optional)</Label>
                                    <Select value={selectedPlayers[selectedPlayers.length - 1] || ''} onValueChange={(v) => {
                                        if (v && !selectedPlayers.includes(v)) {
                                            setSelectedPlayers([...selectedPlayers, v]);
                                        }
                                    }}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue placeholder="Add player..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {players.map(player => (
                                                <SelectItem key={player.id} value={player.id}>
                                                    {player.name} ({player.position})
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        {selectedPlayers.map(pid => {
                                            const player = players.find(p => p.id === pid);
                                            return player ? (
                                                <div key={pid} className="bg-cyan-500/20 text-cyan-400 px-2 py-1 rounded text-xs flex items-center gap-1">
                                                    {player.name}
                                                    <button onClick={() => setSelectedPlayers(selectedPlayers.filter(id => id !== pid))} className="hover:text-cyan-300">×</button>
                                                </div>
                                            ) : null;
                                        })}
                                    </div>
                                </div>

                                <Button
                                    onClick={analyzeMatch}
                                    disabled={isAnalyzing}
                                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600"
                                >
                                    {isAnalyzing ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Analyzing...
                                        </>
                                    ) : (
                                        <>
                                            <Sparkles className="w-4 h-4 mr-2" />
                                            Analyze Match
                                        </>
                                    )}
                                </Button>
                            </CardContent>
                        </Card>
                    </div>

                    <div className="lg:col-span-2">
                        {!analysis && !isAnalyzing && (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-20 text-center">
                                    <BarChart className="w-16 h-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                                    <h3 className="text-white text-xl font-semibold mb-2">Ready to Analyze</h3>
                                    <p className="text-slate-400">
                                        Fill in match details and click Analyze to get AI-powered insights
                                    </p>
                                </CardContent>
                            </Card>
                        )}

                        {analysis && (
                            <Tabs defaultValue="insights" className="w-full">
                                <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                                    <TabsTrigger value="insights">Match Insights</TabsTrigger>
                                    <TabsTrigger value="players">Player Contributions</TabsTrigger>
                                    <TabsTrigger value="tactics">Tactical Adjustments</TabsTrigger>
                                </TabsList>

                                <TabsContent value="insights" className="mt-6">
                                    <MatchInsights analysis={analysis} matchData={matchData} />
                                </TabsContent>

                                <TabsContent value="players" className="mt-6">
                                    <PlayerContributions analysis={analysis} />
                                </TabsContent>

                                <TabsContent value="tactics" className="mt-6">
                                    <TacticalRecommendations analysis={analysis} />
                                </TabsContent>
                            </Tabs>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}