import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import TeamLineupForm from '../components/simulation/TeamLineupForm';
import SimulationResults from '../components/simulation/SimulationResults';
import TacticalAnalysis from '../components/simulation/TacticalAnalysis';
import { Play, Loader2, RotateCcw, History, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import ExportButton from '../components/ExportButton';

export default function MatchSimulation() {
    const [homeTeam, setHomeTeam] = useState({
        name: 'Home Team',
        formation: '4-3-3',
        tactics: '',
        lineup: []
    });

    const [awayTeam, setAwayTeam] = useState({
        name: 'Away Team',
        formation: '4-3-3',
        tactics: '',
        lineup: []
    });

    const [simulationResult, setSimulationResult] = useState(null);
    const [isSimulating, setIsSimulating] = useState(false);
    const [tacticalAnalysis, setTacticalAnalysis] = useState(null);
    const [isAnalyzingTactics, setIsAnalyzingTactics] = useState(false);

    const queryClient = useQueryClient();

    const { data: simulations = [] } = useQuery({
        queryKey: ['simulations'],
        queryFn: () => base44.entities.MatchSimulation.list('-created_date', 10)
    });

    const saveSimulationMutation = useMutation({
        mutationFn: (data) => base44.entities.MatchSimulation.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['simulations'] });
            toast.success('Simulation saved to history');
        }
    });

    const handleSimulate = async () => {
        if (homeTeam.lineup.length < 11 || awayTeam.lineup.length < 11) {
            toast.error('Both teams need 11 players');
            return;
        }

        setIsSimulating(true);
        toast.loading('Simulating match...', { id: 'simulate' });

        try {
            const prompt = `You are an elite football match simulator with deep tactical knowledge. Simulate a realistic match between these two teams:

**${homeTeam.name}** (Home)
Formation: ${homeTeam.formation}
Tactics: ${homeTeam.tactics || 'Standard'}
Lineup: ${homeTeam.lineup.map(p => `${p.name} (${p.position}, Rating: ${p.rating})`).join(', ')}

**${awayTeam.name}** (Away)
Formation: ${awayTeam.formation}
Tactics: ${awayTeam.tactics || 'Standard'}
Lineup: ${awayTeam.lineup.map(p => `${p.name} (${p.position}, Rating: ${p.rating})`).join(', ')}

Simulate a full 90-minute match with:

1. **Realistic Final Score** based on formations, tactics, and player ratings
2. **8-12 Key Match Events** (goals, assists, key saves, tactical changes, yellow cards) with minute timestamps
3. **Player Ratings (7-10 players)** for standout performers from both teams with brief performance summaries
4. **Match Statistics**: possession %, shots, passes for both teams
5. **Tactical Analysis** (2-3 paragraphs): How formations clashed, tactical adjustments, what decided the match
6. **Key Moments Summary** (2-3 paragraphs): Most important moments that shaped the outcome

Make it realistic, detailed, and tactically sound. Consider home advantage, formation matchups, and player quality.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        final_score: { type: "string" },
                        match_events: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    minute: { type: "number" },
                                    event_type: { type: "string" },
                                    player: { type: "string" },
                                    description: { type: "string" }
                                }
                            }
                        },
                        player_ratings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player: { type: "string" },
                                    team: { type: "string" },
                                    rating: { type: "number" },
                                    performance: { type: "string" }
                                }
                            }
                        },
                        match_statistics: {
                            type: "object",
                            properties: {
                                possession: {
                                    type: "object",
                                    properties: {
                                        home: { type: "number" },
                                        away: { type: "number" }
                                    }
                                },
                                shots: {
                                    type: "object",
                                    properties: {
                                        home: { type: "number" },
                                        away: { type: "number" }
                                    }
                                },
                                passes: {
                                    type: "object",
                                    properties: {
                                        home: { type: "number" },
                                        away: { type: "number" }
                                    }
                                }
                            }
                        },
                        tactical_analysis: { type: "string" },
                        key_moments: { type: "string" }
                    }
                }
            });

            const fullResult = {
                home_team: homeTeam.name,
                away_team: awayTeam.name,
                home_formation: homeTeam.formation,
                away_formation: awayTeam.formation,
                home_tactics: homeTeam.tactics,
                away_tactics: awayTeam.tactics,
                home_lineup: homeTeam.lineup,
                away_lineup: awayTeam.lineup,
                ...response
            };

            setSimulationResult(fullResult);
            saveSimulationMutation.mutate(fullResult);
            toast.success('Match simulated successfully!', { id: 'simulate' });
        } catch (error) {
            console.error('Simulation error:', error);
            toast.error('Simulation failed', { id: 'simulate' });
        } finally {
            setIsSimulating(false);
        }
    };

    const handleReset = () => {
        setSimulationResult(null);
        setTacticalAnalysis(null);
        setHomeTeam({ name: 'Home Team', formation: '4-3-3', tactics: '', lineup: [] });
        setAwayTeam({ name: 'Away Team', formation: '4-3-3', tactics: '', lineup: [] });
    };

    const handleTacticalAnalysis = async () => {
        if (!simulationResult) return;

        setIsAnalyzingTactics(true);
        toast.loading('Analyzing tactics...', { id: 'tactics' });

        try {
            const prompt = `You are an elite tactical analyst. Provide a deep tactical analysis of this match:

**${simulationResult.home_team}** vs **${simulationResult.away_team}**
Final Score: ${simulationResult.final_score}

**Formations:**
- Home: ${simulationResult.home_formation}
- Away: ${simulationResult.away_formation}

**Tactics:**
- Home: ${simulationResult.home_tactics || 'Standard'}
- Away: ${simulationResult.away_tactics || 'Standard'}

**Match Statistics:**
${JSON.stringify(simulationResult.match_statistics, null, 2)}

**Match Events:**
${simulationResult.match_events?.map(e => `${e.minute}' - ${e.event_type}: ${e.player} - ${e.description}`).join('\n')}

**Player Ratings:**
${simulationResult.player_ratings?.map(r => `${r.player} (${r.team}): ${r.rating} - ${r.performance}`).join('\n')}

Provide:
1. **Tactical Overview** (2-3 paragraphs): Overall tactical story of the match
2. **Key Tactical Battles** (3-4): Specific areas of the pitch where tactical battles were won/lost
3. **Home Team Successes** (3-5 bullet points): What worked tactically
4. **Home Team Failures** (3-5 bullet points): What didn't work
5. **Away Team Successes** (3-5 bullet points): What worked tactically
6. **Away Team Failures** (3-5 bullet points): What didn't work
7. **Home Team Adjustments** (2 paragraphs): Specific tactical changes for future matches
8. **Away Team Adjustments** (2 paragraphs): Specific tactical changes for future matches
9. **Future Preparation** (2-3 paragraphs): Key insights for both teams' next matches

Be specific, tactical, and reference formations, player roles, and match events.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        tactical_overview: { type: "string" },
                        key_battles: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    winner: { type: "string" },
                                    description: { type: "string" },
                                    impact: { type: "string" }
                                }
                            }
                        },
                        home_team_successes: {
                            type: "array",
                            items: { type: "string" }
                        },
                        home_team_failures: {
                            type: "array",
                            items: { type: "string" }
                        },
                        away_team_successes: {
                            type: "array",
                            items: { type: "string" }
                        },
                        away_team_failures: {
                            type: "array",
                            items: { type: "string" }
                        },
                        home_team_adjustments: { type: "string" },
                        away_team_adjustments: { type: "string" },
                        future_preparation: { type: "string" }
                    }
                }
            });

            setTacticalAnalysis(response);
            toast.success('Tactical analysis complete!', { id: 'tactics' });
        } catch (error) {
            console.error('Tactical analysis error:', error);
            toast.error('Analysis failed', { id: 'tactics' });
        } finally {
            setIsAnalyzingTactics(false);
        }
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                            Match Simulation
                        </h1>
                        <p className="text-slate-400">AI-powered tactical match simulator</p>
                    </div>
                    <ExportButton 
                        entityType="MatchSimulation" 
                        title="FS-AI Match Simulations"
                        label="Export Simulations"
                    />
                </div>

                <Tabs defaultValue="setup">
                    <TabsList className="grid w-full grid-cols-3 bg-slate-800 mb-6">
                        <TabsTrigger value="setup" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            Setup
                        </TabsTrigger>
                        <TabsTrigger 
                            value="tactics" 
                            disabled={!simulationResult}
                            className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
                        >
                            <Target className="w-4 h-4 mr-2" />
                            Tactics
                        </TabsTrigger>
                        <TabsTrigger value="history" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            <History className="w-4 h-4 mr-2" />
                            History
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="setup">
                        <AnimatePresence mode="wait">
                            {!simulationResult ? (
                                <motion.div
                                    key="setup"
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className="space-y-6"
                                >
                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                        <TeamLineupForm team={homeTeam} onUpdate={setHomeTeam} />
                                        <TeamLineupForm team={awayTeam} onUpdate={setAwayTeam} />
                                    </div>

                                    <div className="flex justify-center">
                                        <Button
                                            onClick={handleSimulate}
                                            disabled={isSimulating || homeTeam.lineup.length < 11 || awayTeam.lineup.length < 11}
                                            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white h-14 px-8 text-lg font-semibold"
                                        >
                                            {isSimulating ? (
                                                <>
                                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                    Simulating Match...
                                                </>
                                            ) : (
                                                <>
                                                    <Play className="w-5 h-5 mr-2" />
                                                    Simulate Match
                                                </>
                                            )}
                                        </Button>
                                    </div>
                                </motion.div>
                            ) : (
                                <motion.div
                                    key="results"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-6"
                                >
                                    <div className="flex justify-end">
                                        <Button
                                            onClick={handleReset}
                                            className="bg-slate-800 hover:bg-slate-700 text-white"
                                        >
                                            <RotateCcw className="w-4 h-4 mr-2" />
                                            New Simulation
                                        </Button>
                                    </div>
                                    <SimulationResults simulation={simulationResult} />
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </TabsContent>

                    <TabsContent value="tactics">
                        {!simulationResult ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center">
                                    <p className="text-slate-400">Simulate a match first to analyze tactics</p>
                                </CardContent>
                            </Card>
                        ) : !tacticalAnalysis ? (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-12 text-center space-y-4">
                                    <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                                        <Target className="w-8 h-8 text-white" />
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-bold text-white mb-2">Deep Tactical Analysis</h3>
                                        <p className="text-slate-400 mb-6">Get AI-powered insights on tactical battles, successes, and adjustments</p>
                                        <Button
                                            onClick={handleTacticalAnalysis}
                                            disabled={isAnalyzingTactics}
                                            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white"
                                        >
                                            {isAnalyzingTactics ? (
                                                <>
                                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                    Analyzing...
                                                </>
                                            ) : (
                                                <>
                                                    <Target className="w-5 h-5 mr-2" />
                                                    Generate Tactical Analysis
                                                </>
                                            )}
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ) : (
                            <TacticalAnalysis analysis={tacticalAnalysis} />
                        )}
                    </TabsContent>

                    <TabsContent value="history">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Recent Simulations</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {simulations.length === 0 ? (
                                    <p className="text-slate-400 text-center py-12">No simulations yet</p>
                                ) : (
                                    <div className="space-y-4">
                                        {simulations.map((sim) => (
                                            <div
                                                key={sim.id}
                                                className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors cursor-pointer"
                                                onClick={() => setSimulationResult(sim)}
                                            >
                                                <div className="flex justify-between items-center mb-2">
                                                    <div className="flex items-center gap-4">
                                                        <span className="text-white font-semibold">{sim.home_team}</span>
                                                        <span className="text-2xl font-bold text-cyan-400">{sim.final_score}</span>
                                                        <span className="text-white font-semibold">{sim.away_team}</span>
                                                    </div>
                                                    <span className="text-slate-500 text-sm">
                                                        {new Date(sim.created_date).toLocaleDateString()}
                                                    </span>
                                                </div>
                                                <div className="flex gap-4 text-sm text-slate-400">
                                                    <span>{sim.home_formation} vs {sim.away_formation}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}