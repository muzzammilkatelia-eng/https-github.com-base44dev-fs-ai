import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Target, Users, Zap, Shield, AlertTriangle, TrendingUp, Brain } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import OpponentAnalysis from '../components/strategy/OpponentAnalysis';
import LineupRecommendation from '../components/strategy/LineupRecommendation';
import TacticalPlan from '../components/strategy/TacticalPlan';
import SetPieceStrategy from '../components/strategy/SetPieceStrategy';

export default function MatchStrategyAdvisor() {
    const [opponentData, setOpponentData] = useState({
        match_name: '',
        opponent_name: '',
        match_date: '',
        opponent_context: ''
    });
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [strategy, setStrategy] = useState(null);

    const queryClient = useQueryClient();

    const { data: savedStrategies = [] } = useQuery({
        queryKey: ['match-strategies'],
        queryFn: () => base44.entities.MatchStrategy.list('-created_date', 20)
    });

    const saveStrategyMutation = useMutation({
        mutationFn: (data) => base44.entities.MatchStrategy.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['match-strategies'] });
            toast.success('Strategy saved');
        }
    });

    const handleAnalyze = async () => {
        if (!opponentData.opponent_name) {
            toast.error('Enter opponent name');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing opponent...', { id: 'analyze' });

        try {
            const prompt = `You are an elite football tactical analyst and match strategist. Analyze the opponent and provide comprehensive strategic recommendations.

OPPONENT: ${opponentData.opponent_name}
MATCH: ${opponentData.match_name || 'vs ' + opponentData.opponent_name}
${opponentData.match_date ? `DATE: ${opponentData.match_date}` : ''}
${opponentData.opponent_context ? `ADDITIONAL CONTEXT: ${opponentData.opponent_context}` : ''}

Provide a detailed tactical analysis and strategic plan:

1. OPPONENT ANALYSIS:
- Recent form (last 5-10 matches)
- Key players (3-5 most dangerous players with positions and threats)
- Preferred formation and system
- Tactical tendencies (pressing, possession, counter-attack, etc.)
- Main strengths (3-5 specific tactical or technical strengths)
- Main weaknesses (3-5 exploitable weaknesses)

2. RECOMMENDED LINEUP:
- Best formation to use against this opponent
- Starting XI with specific player roles and positioning
- Clear reasoning for each tactical choice

3. TACTICAL RECOMMENDATIONS:
Provide 5-7 specific recommendations covering:
- Defensive organization
- Pressing strategy
- Build-up play
- Attacking patterns
- Transition moments
- In-game adjustments
Each with priority level (High/Medium/Low)

4. SET PIECE STRATEGY:
- Corners (attacking and defending)
- Free kicks (direct and indirect)
- Throw-ins in dangerous areas

5. KEY BATTLES:
- 3-5 crucial individual or positional battles that will decide the match

6. RISK ASSESSMENT:
- Overall match difficulty: Low/Medium/High

Be specific, tactical, and actionable. Use real football terminology.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        opponent_analysis: {
                            type: "object",
                            properties: {
                                recent_form: { type: "string" },
                                key_players: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            name: { type: "string" },
                                            position: { type: "string" },
                                            threat_level: { type: "string" },
                                            description: { type: "string" }
                                        }
                                    }
                                },
                                preferred_formation: { type: "string" },
                                tactical_tendencies: { type: "string" },
                                strengths: { type: "array", items: { type: "string" } },
                                weaknesses: { type: "array", items: { type: "string" } }
                            }
                        },
                        recommended_lineup: {
                            type: "object",
                            properties: {
                                formation: { type: "string" },
                                starting_xi: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            position: { type: "string" },
                                            role: { type: "string" },
                                            instructions: { type: "string" }
                                        }
                                    }
                                },
                                reasoning: { type: "string" }
                            }
                        },
                        tactical_recommendations: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    category: { type: "string" },
                                    recommendation: { type: "string" },
                                    priority: { type: "string", enum: ["High", "Medium", "Low"] }
                                }
                            }
                        },
                        set_piece_strategy: {
                            type: "object",
                            properties: {
                                corners: { type: "string" },
                                free_kicks: { type: "string" },
                                throw_ins: { type: "string" }
                            }
                        },
                        key_battles: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    battle: { type: "string" },
                                    importance: { type: "string" },
                                    tactical_approach: { type: "string" }
                                }
                            }
                        },
                        risk_assessment: { type: "string", enum: ["Low", "Medium", "High"] }
                    }
                }
            });

            const fullStrategy = {
                match_name: opponentData.match_name || `vs ${opponentData.opponent_name}`,
                opponent_name: opponentData.opponent_name,
                match_date: opponentData.match_date,
                ...result
            };

            setStrategy(fullStrategy);
            toast.success('Analysis complete!', { id: 'analyze' });
        } catch (error) {
            console.error('Analysis error:', error);
            toast.error('Analysis failed', { id: 'analyze' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleSave = () => {
        if (strategy) {
            saveStrategyMutation.mutate(strategy);
        }
    };

    const loadStrategy = (savedStrategy) => {
        setStrategy(savedStrategy);
        setOpponentData({
            match_name: savedStrategy.match_name,
            opponent_name: savedStrategy.opponent_name,
            match_date: savedStrategy.match_date || '',
            opponent_context: ''
        });
    };

    const getRiskColor = (risk) => {
        const colors = {
            'Low': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            'Medium': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            'High': 'bg-red-500/20 text-red-400 border-red-500/30'
        };
        return colors[risk] || colors['Medium'];
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-12">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-3">
                        AI Match Strategy Advisor
                    </h1>
                    <p className="text-slate-400">Get AI-driven tactical recommendations for your next match</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left Column - Input & Saved Strategies */}
                    <div className="space-y-6">
                        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Brain className="w-5 h-5 text-purple-400" />
                                    Match Details
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <Label className="text-slate-400">Opponent Name *</Label>
                                    <Input
                                        value={opponentData.opponent_name}
                                        onChange={(e) => setOpponentData({ ...opponentData, opponent_name: e.target.value })}
                                        placeholder="e.g., Manchester City"
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400">Match Name</Label>
                                    <Input
                                        value={opponentData.match_name}
                                        onChange={(e) => setOpponentData({ ...opponentData, match_name: e.target.value })}
                                        placeholder="e.g., Premier League GW15"
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400">Match Date</Label>
                                    <Input
                                        type="date"
                                        value={opponentData.match_date}
                                        onChange={(e) => setOpponentData({ ...opponentData, match_date: e.target.value })}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400">Additional Context</Label>
                                    <Input
                                        value={opponentData.opponent_context}
                                        onChange={(e) => setOpponentData({ ...opponentData, opponent_context: e.target.value })}
                                        placeholder="e.g., Home game, injury concerns"
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <Button
                                    onClick={handleAnalyze}
                                    disabled={isAnalyzing || !opponentData.opponent_name}
                                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 h-12"
                                >
                                    {isAnalyzing ? (
                                        <>
                                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                            Analyzing...
                                        </>
                                    ) : (
                                        <>
                                            <Target className="w-5 h-5 mr-2" />
                                            Generate Strategy
                                        </>
                                    )}
                                </Button>
                            </CardContent>
                        </Card>

                        {savedStrategies.length > 0 && (
                            <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white text-sm">Recent Strategies</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                    {savedStrategies.slice(0, 5).map((strat) => (
                                        <button
                                            key={strat.id}
                                            onClick={() => loadStrategy(strat)}
                                            className="w-full text-left p-3 bg-slate-800/50 hover:bg-slate-800 rounded-lg transition-all"
                                        >
                                            <p className="text-white text-sm font-medium">{strat.match_name}</p>
                                            <p className="text-slate-400 text-xs mt-1">
                                                {new Date(strat.created_date).toLocaleDateString()}
                                            </p>
                                        </button>
                                    ))}
                                </CardContent>
                            </Card>
                        )}
                    </div>

                    {/* Right Column - Strategy Output */}
                    <div className="lg:col-span-2">
                        {!strategy && !isAnalyzing && (
                            <div className="h-full flex items-center justify-center">
                                <div className="text-center">
                                    <Brain className="w-20 h-20 text-purple-500 mx-auto mb-4" />
                                    <h3 className="text-xl font-bold text-white mb-2">Ready to Analyze</h3>
                                    <p className="text-slate-400">Enter opponent details to get AI tactical recommendations</p>
                                </div>
                            </div>
                        )}

                        {isAnalyzing && (
                            <div className="h-full flex items-center justify-center">
                                <div className="text-center">
                                    <Loader2 className="w-16 h-16 text-purple-500 mx-auto mb-4 animate-spin" />
                                    <h3 className="text-xl font-bold text-white mb-2">Analyzing Match</h3>
                                    <p className="text-slate-400">Generating tactical strategy...</p>
                                </div>
                            </div>
                        )}

                        {strategy && !isAnalyzing && (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-6"
                            >
                                {/* Header Card */}
                                <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                                    <CardContent className="pt-6">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <h2 className="text-2xl font-bold text-white mb-2">{strategy.match_name}</h2>
                                                <p className="text-slate-400">vs {strategy.opponent_name}</p>
                                                {strategy.match_date && (
                                                    <p className="text-slate-500 text-sm mt-1">
                                                        {new Date(strategy.match_date).toLocaleDateString()}
                                                    </p>
                                                )}
                                            </div>
                                            <div className="flex gap-2">
                                                <Badge className={getRiskColor(strategy.risk_assessment)}>
                                                    {strategy.risk_assessment} Risk
                                                </Badge>
                                                <Button
                                                    onClick={handleSave}
                                                    size="sm"
                                                    variant="outline"
                                                    className="border-purple-500/30 text-purple-400"
                                                >
                                                    Save Strategy
                                                </Button>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>

                                <Tabs defaultValue="opponent">
                                    <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                                        <TabsTrigger value="opponent" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                            <Shield className="w-4 h-4 mr-2" />
                                            Opponent
                                        </TabsTrigger>
                                        <TabsTrigger value="lineup" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                            <Users className="w-4 h-4 mr-2" />
                                            Lineup
                                        </TabsTrigger>
                                        <TabsTrigger value="tactics" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                            <Zap className="w-4 h-4 mr-2" />
                                            Tactics
                                        </TabsTrigger>
                                        <TabsTrigger value="setpieces" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                            <Target className="w-4 h-4 mr-2" />
                                            Set Pieces
                                        </TabsTrigger>
                                    </TabsList>

                                    <TabsContent value="opponent" className="mt-6">
                                        <OpponentAnalysis data={strategy.opponent_analysis} keyBattles={strategy.key_battles} />
                                    </TabsContent>

                                    <TabsContent value="lineup" className="mt-6">
                                        <LineupRecommendation data={strategy.recommended_lineup} />
                                    </TabsContent>

                                    <TabsContent value="tactics" className="mt-6">
                                        <TacticalPlan recommendations={strategy.tactical_recommendations} />
                                    </TabsContent>

                                    <TabsContent value="setpieces" className="mt-6">
                                        <SetPieceStrategy data={strategy.set_piece_strategy} />
                                    </TabsContent>
                                </Tabs>
                            </motion.div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}