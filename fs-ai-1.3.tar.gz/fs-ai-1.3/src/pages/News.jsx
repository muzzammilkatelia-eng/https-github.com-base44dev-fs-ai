import React from 'react';
import NewsFeed from '../components/news/NewsFeed';
import SnapshotIngestor from '../components/news/SnapshotIngestor';
import GlobalRankingsPanel from '../components/news/GlobalRankingsPanel';
import LocalFixtures from '../components/news/LocalFixtures';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';

export default function News() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white">News</h1>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/10"
              onClick={async () => {
                const { data } = await base44.functions.invoke('ingestGlobalFDB');
                if (data?.success) {
                  window.alert('Global dataset ingested' + (data.alreadyIngested ? ' (already ingested)' : ''));
                } else {
                  window.alert('Ingestion failed: ' + (data?.error || 'Unknown error'));
                }
              }}
            >
              Load FDB Global Dataset
            </Button>
            <Button
              variant="outline"
              className="border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10"
              onClick={async () => {
                const { data } = await base44.functions.invoke('seedWomensLeagues');
                if (data?.success) {
                  window.alert(`Seeded women's leagues: ${data.players} players, ${data.snapshots} snapshots`);
                } else {
                  window.alert('Seeding failed: ' + (data?.error || 'Unknown error'));
                }
              }}
            >
              Seed Women’s Leagues
            </Button>
          </div>
        </div>
        <LocalFixtures />
        <GlobalRankingsPanel />
        <SnapshotIngestor />
        <NewsFeed />
      </div>
    </div>
  );
}