import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart3, TrendingUp, Users, Sparkles, Target, Activity } from 'lucide-react';
import PerformanceTracker from '../components/analytics/PerformanceTracker';
import PlayerComparisonTool from '../components/analytics/PlayerComparisonTool';
import TrendAnalysis from '../components/analytics/TrendAnalysis';
import AIRiskAssessment from '../components/analytics/AIRiskAssessment';

export default function PlayerAnalyticsDashboard() {
    const [activeTab, setActiveTab] = useState('performance');

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 10000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 1000)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 1000)
    });

    const stats = {
        totalPlayers: players.length,
        reportsGenerated: reports.length,
        projectionsAnalyzed: projections.length,
        avgScore: players.length > 0 
            ? Math.round(players.reduce((sum, p) => sum + (p.fsai_proprietary_score || 0), 0) / players.length)
            : 0
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                            Player Analytics Dashboard
                        </h1>
                        <p className="text-slate-400 mt-2">
                            Comprehensive performance tracking, comparisons, and AI-driven insights
                        </p>
                    </div>
                </div>

                {/* Stats Overview */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-slate-900/50 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Players</p>
                                    <p className="text-3xl font-bold text-white">{stats.totalPlayers}</p>
                                </div>
                                <Users className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-blue-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Reports Generated</p>
                                    <p className="text-3xl font-bold text-white">{stats.reportsGenerated}</p>
                                </div>
                                <BarChart3 className="w-8 h-8 text-blue-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Projections</p>
                                    <p className="text-3xl font-bold text-white">{stats.projectionsAnalyzed}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Avg FS-AI Score</p>
                                    <p className="text-3xl font-bold text-white">{stats.avgScore}</p>
                                </div>
                                <Sparkles className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Main Analytics Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4 w-full">
                        <TabsTrigger value="performance" className="data-[state=active]:bg-cyan-500/20">
                            <Activity className="w-4 h-4 mr-2" />
                            Performance Tracking
                        </TabsTrigger>
                        <TabsTrigger value="comparison" className="data-[state=active]:bg-blue-500/20">
                            <Users className="w-4 h-4 mr-2" />
                            Player Comparison
                        </TabsTrigger>
                        <TabsTrigger value="trends" className="data-[state=active]:bg-purple-500/20">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Trend Analysis
                        </TabsTrigger>
                        <TabsTrigger value="ai-risk" className="data-[state=active]:bg-amber-500/20">
                            <Target className="w-4 h-4 mr-2" />
                            AI Risk Assessment
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="performance" className="space-y-6">
                        <PerformanceTracker players={players} reports={reports} />
                    </TabsContent>

                    <TabsContent value="comparison" className="space-y-6">
                        <PlayerComparisonTool players={players} reports={reports} projections={projections} />
                    </TabsContent>

                    <TabsContent value="trends" className="space-y-6">
                        <TrendAnalysis players={players} projections={projections} />
                    </TabsContent>

                    <TabsContent value="ai-risk" className="space-y-6">
                        <AIRiskAssessment players={players} reports={reports} projections={projections} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}