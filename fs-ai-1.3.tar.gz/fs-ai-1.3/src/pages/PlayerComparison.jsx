import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Users, TrendingUp, AlertTriangle, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import HistoricalTrendChart from '../components/comparison/HistoricalTrendChart';
import StatisticalBreakdown from '../components/comparison/StatisticalBreakdown';
import TacticalSystemAnalysis from '../components/comparison/TacticalSystemAnalysis';
import AIComparisonAnalysis from '../components/comparison/AIComparisonAnalysis';
import HelpTooltip from '../components/onboarding/HelpTooltip';
import FutureValueComparison from '../components/comparison/FutureValueComparison';
import PremiumGate from '../components/PremiumGate';
import AttributesComparison from '../components/comparison/AttributesComparison';
import PerformanceStatsComparison from '../components/comparison/PerformanceStatsComparison';
import MultiPlayerComparison from '../components/comparison/MultiPlayerComparison';
import AdvancedFiltering from '../components/comparison/AdvancedFiltering';
import TeamSynergyAnalysis from '../components/comparison/TeamSynergyAnalysis';
import IdealTargetProfileGenerator from '../components/comparison/IdealTargetProfileGenerator';
import TalentIDScanner from '../components/comparison/TalentIDScanner';
import InjuryTrendPredictor from '../components/comparison/InjuryTrendPredictor';
import PlayerDevelopmentTracker from '../components/comparison/PlayerDevelopmentTracker';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function PlayerComparison() {
    return (
        <PremiumGate>
            <PlayerComparisonContent />
        </PremiumGate>
    );
}

function PlayerComparisonContent() {
    const [selectedPlayers, setSelectedPlayers] = useState([null, null]);
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 10000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 50)
    });

    const handlePlayerSelect = (index, playerId) => {
        const player = players.find(p => p.id === playerId);
        const newSelected = [...selectedPlayers];
        newSelected[index] = player;
        setSelectedPlayers(newSelected);
        setAnalysis(null);
    };

    const addPlayerSlot = () => {
        if (selectedPlayers.length < 4) {
            setSelectedPlayers([...selectedPlayers, null]);
        }
    };

    const removePlayerSlot = (index) => {
        if (selectedPlayers.length > 2) {
            setSelectedPlayers(selectedPlayers.filter((_, i) => i !== index));
            setAnalysis(null);
        }
    };

    const handleCompare = async () => {
        const validPlayers = selectedPlayers.filter(p => p !== null);
        if (validPlayers.length < 2) {
            toast.error('Select at least 2 players to compare');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('AI analyzing players...', { id: 'compare' });

        try {
            const playersData = validPlayers.map(player => {
                const playerReports = reports.filter(r => 
                    r.player_name?.toLowerCase() === player.name?.toLowerCase()
                ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
                
                const playerProjection = projections.find(p => 
                    p.player_name?.toLowerCase() === player.name?.toLowerCase()
                );

                return {
                    name: player.name,
                    age: player.age,
                    position: player.position,
                    secondary_positions: player.secondary_positions,
                    current_club: player.current_club,
                    league: player.league,
                    market_value: player.market_value,
                    physical_attributes: player.physical_attributes,
                    playing_style: player.playing_style,
                    injury_history: player.injury_history,
                    injury_prone_score: player.injury_prone_score,
                    reports: playerReports,
                    latest_report: playerReports[0] ? {
                        overall_rating: playerReports[0].overall_rating,
                        technical_rating: playerReports[0].technical_rating,
                        physical_rating: playerReports[0].physical_rating,
                        mental_rating: playerReports[0].mental_rating,
                        tactical_rating: playerReports[0].tactical_rating,
                        strengths: playerReports[0].strengths,
                        weaknesses: playerReports[0].weaknesses,
                        recommendation: playerReports[0].recommendation
                    } : null,
                    projection: playerProjection ? {
                        trajectory: playerProjection.potential_trajectory,
                        peak_rating: playerProjection.peak_potential_rating,
                        years_to_peak: playerProjection.years_to_peak,
                        risk_factors: playerProjection.risk_factors
                    } : null
                };
            });

            const prompt = `You are an elite football scout AI. Perform a comprehensive comparison of these ${validPlayers.length} players:

${playersData.map((p, i) => `
PLAYER ${i + 1}: ${p.name}
- Age: ${p.age} | Position: ${p.position}${p.secondary_positions ? ` (also ${p.secondary_positions.join(', ')})` : ''}
- Club: ${p.current_club} (${p.league}) | Value: €${p.market_value}M
- Physical: ${JSON.stringify(p.physical_attributes)}
- Style: ${JSON.stringify(p.playing_style)}
- Injury Score: ${p.injury_prone_score}/100
${p.latest_report ? `- Scout Report: ${p.latest_report.overall_rating}/10 overall | Technical: ${p.latest_report.technical_rating}/10 | Physical: ${p.latest_report.physical_rating}/10 | Mental: ${p.latest_report.mental_rating}/10
  Strengths: ${p.latest_report.strengths}
  Weaknesses: ${p.latest_report.weaknesses}
  Recommendation: ${p.latest_report.recommendation}` : '- No scouting report available'}
${p.projection ? `- Projection: ${p.projection.trajectory} | Peak: ${p.projection.peak_rating}/10 in ${p.projection.years_to_peak} years | Risks: ${p.projection.risk_factors?.join(', ')}` : ''}
`).join('\n')}

Provide:
1. **Head-to-Head Comparison**: Detailed statistical and attribute breakdown
2. **Relative Strengths**: What each player does BETTER than the others
3. **Relative Weaknesses**: What each player does WORSE than the others
4. **Tactical System Fit**: 
   - 4-3-3: Which player fits best and why
   - 4-2-3-1: Which player fits best and why
   - 3-5-2: Which player fits best and why
   - 4-4-2: Which player fits best and why
5. **Best Use Case**: Ideal scenario/role for each player
6. **Value Assessment**: Who offers the best value for money
7. **Final Recommendation**: Which player to prioritize and why

Be specific, use data, and provide actionable insights.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        head_to_head: { type: "string" },
                        relative_strengths: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    strengths: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        relative_weaknesses: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    weaknesses: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        tactical_fit: {
                            type: "object",
                            properties: {
                                "4-3-3": { type: "string" },
                                "4-2-3-1": { type: "string" },
                                "3-5-2": { type: "string" },
                                "4-4-2": { type: "string" }
                            }
                        },
                        best_use_cases: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    use_case: { type: "string" }
                                }
                            }
                        },
                        value_assessment: { type: "string" },
                        final_recommendation: { type: "string" }
                    }
                }
            });

            setAnalysis({ players: playersData, ...response });
            toast.success('Analysis complete!', { id: 'compare' });
        } catch (error) {
            console.error('Comparison failed:', error);
            toast.error('Failed to analyze players', { id: 'compare' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2 flex items-center gap-3">
                        AI Player Comparison
                        <HelpTooltip content="Compare multiple players side-by-side with detailed metrics, tactical analysis, and AI-generated insights to find the perfect fit for your squad." />
                    </h1>
                    <p className="text-slate-400">Compare players side-by-side with AI tactical analysis</p>
                </div>

                <Tabs defaultValue="classic" className="mb-8">
                    <TabsList className="bg-slate-800 grid grid-cols-3 lg:grid-cols-6">
                        <TabsTrigger value="classic">Comparison</TabsTrigger>
                        <TabsTrigger value="multibrain">Multi-Brain</TabsTrigger>
                        <TabsTrigger value="profile">Profile Gen</TabsTrigger>
                        <TabsTrigger value="talentid">Talent ID</TabsTrigger>
                        <TabsTrigger value="injury">Injury Risk</TabsTrigger>
                        <TabsTrigger value="development">Dev Tracker</TabsTrigger>
                    </TabsList>

                    <TabsContent value="multibrain">
                        <MultiPlayerComparison />
                    </TabsContent>

                    <TabsContent value="profile">
                        <IdealTargetProfileGenerator />
                    </TabsContent>

                    <TabsContent value="talentid">
                        <TalentIDScanner />
                    </TabsContent>

                    <TabsContent value="injury">
                        <InjuryTrendPredictor />
                    </TabsContent>

                    <TabsContent value="development">
                        <PlayerDevelopmentTracker />
                    </TabsContent>

                    <TabsContent value="classic">
                        <ClassicComparison 
                            players={players}
                            reports={reports}
                            projections={projections}
                            isLoading={isLoading}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}

function ClassicComparison({ players, reports, projections, isLoading }) {
    const [selectedPlayers, setSelectedPlayers] = useState([null, null]);
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [filteredPlayers, setFilteredPlayers] = useState(players);

    const handlePlayerSelect = (index, playerId) => {
        const player = players.find(p => p.id === playerId);
        const newSelected = [...selectedPlayers];
        newSelected[index] = player;
        setSelectedPlayers(newSelected);
        setAnalysis(null);
    };

    const addPlayerSlot = () => {
        if (selectedPlayers.length < 4) {
            setSelectedPlayers([...selectedPlayers, null]);
        }
    };

    const removePlayerSlot = (index) => {
        if (selectedPlayers.length > 2) {
            setSelectedPlayers(selectedPlayers.filter((_, i) => i !== index));
            setAnalysis(null);
        }
    };

    const handleCompare = async () => {
        const validPlayers = selectedPlayers.filter(p => p !== null);
        if (validPlayers.length < 2) {
            toast.error('Select at least 2 players to compare');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('AI analyzing players...', { id: 'compare' });

        try {
            const playersData = validPlayers.map(player => {
                const playerReports = reports.filter(r => 
                    r.player_name?.toLowerCase() === player.name?.toLowerCase()
                ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
                
                const playerProjection = projections.find(p => 
                    p.player_name?.toLowerCase() === player.name?.toLowerCase()
                );

                return {
                    name: player.name,
                    age: player.age,
                    position: player.position,
                    secondary_positions: player.secondary_positions,
                    current_club: player.current_club,
                    league: player.league,
                    market_value: player.market_value,
                    physical_attributes: player.physical_attributes,
                    playing_style: player.playing_style,
                    injury_history: player.injury_history,
                    injury_prone_score: player.injury_prone_score,
                    reports: playerReports,
                    latest_report: playerReports[0] ? {
                        overall_rating: playerReports[0].overall_rating,
                        technical_rating: playerReports[0].technical_rating,
                        physical_rating: playerReports[0].physical_rating,
                        mental_rating: playerReports[0].mental_rating,
                        tactical_rating: playerReports[0].tactical_rating,
                        strengths: playerReports[0].strengths,
                        weaknesses: playerReports[0].weaknesses,
                        recommendation: playerReports[0].recommendation
                    } : null,
                    projection: playerProjection ? {
                        trajectory: playerProjection.potential_trajectory,
                        peak_rating: playerProjection.peak_potential_rating,
                        years_to_peak: playerProjection.years_to_peak,
                        risk_factors: playerProjection.risk_factors
                    } : null
                };
            });

            const prompt = `You are an elite football scout AI. Perform a comprehensive comparison of these ${validPlayers.length} players:

${playersData.map((p, i) => `
PLAYER ${i + 1}: ${p.name}
- Age: ${p.age} | Position: ${p.position}${p.secondary_positions ? ` (also ${p.secondary_positions.join(', ')})` : ''}
- Club: ${p.current_club} (${p.league}) | Value: €${p.market_value}M
- Physical: ${JSON.stringify(p.physical_attributes)}
- Style: ${JSON.stringify(p.playing_style)}
- Injury Score: ${p.injury_prone_score}/100
${p.latest_report ? `- Scout Report: ${p.latest_report.overall_rating}/10 overall | Technical: ${p.latest_report.technical_rating}/10 | Physical: ${p.latest_report.physical_rating}/10 | Mental: ${p.latest_report.mental_rating}/10
  Strengths: ${p.latest_report.strengths}
  Weaknesses: ${p.latest_report.weaknesses}
  Recommendation: ${p.latest_report.recommendation}` : '- No scouting report available'}
${p.projection ? `- Projection: ${p.projection.trajectory} | Peak: ${p.projection.peak_rating}/10 in ${p.projection.years_to_peak} years | Risks: ${p.projection.risk_factors?.join(', ')}` : ''}
`).join('\n')}

Provide:
1. **Head-to-Head Comparison**: Detailed statistical and attribute breakdown
2. **Relative Strengths**: What each player does BETTER than the others
3. **Relative Weaknesses**: What each player does WORSE than the others
4. **Tactical System Fit**: 
   - 4-3-3: Which player fits best and why
   - 4-2-3-1: Which player fits best and why
   - 3-5-2: Which player fits best and why
   - 4-4-2: Which player fits best and why
5. **Best Use Case**: Ideal scenario/role for each player
6. **Value Assessment**: Who offers the best value for money
7. **Final Recommendation**: Which player to prioritize and why

Be specific, use data, and provide actionable insights.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        head_to_head: { type: "string" },
                        relative_strengths: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    strengths: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        relative_weaknesses: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    weaknesses: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        tactical_fit: {
                            type: "object",
                            properties: {
                                "4-3-3": { type: "string" },
                                "4-2-3-1": { type: "string" },
                                "3-5-2": { type: "string" },
                                "4-4-2": { type: "string" }
                            }
                        },
                        best_use_cases: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    use_case: { type: "string" }
                                }
                            }
                        },
                        value_assessment: { type: "string" },
                        final_recommendation: { type: "string" }
                    }
                }
            });

            setAnalysis({ players: playersData, ...response });
            toast.success('Analysis complete!', { id: 'compare' });
        } catch (error) {
            console.error('Comparison failed:', error);
            toast.error('Failed to analyze players', { id: 'compare' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Advanced Filtering */}
            <AdvancedFiltering 
                players={players}
                onFilteredPlayersChange={setFilteredPlayers}
            />

            {/* Player Selection */}
            <Card className="bg-slate-900/50 border-slate-800 mb-8">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-5 h-5 text-cyan-400" />
                            Select Players to Compare
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                            {selectedPlayers.map((player, index) => (
                                <div key={index} className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <label className="text-slate-400 text-sm">Player {index + 1}</label>
                                        {selectedPlayers.length > 2 && (
                                            <Button
                                                onClick={() => removePlayerSlot(index)}
                                                variant="ghost"
                                                size="sm"
                                                className="text-red-400 hover:text-red-300"
                                            >
                                                Remove
                                            </Button>
                                        )}
                                    </div>
                                    <Select value={player?.id || ''} onValueChange={(v) => handlePlayerSelect(index, v)}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                            <SelectValue placeholder="Select player..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {filteredPlayers.map(p => (
                                                <SelectItem key={p.id} value={p.id}>
                                                    {p.name} - {p.position} ({p.age}y)
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    {player && (
                                        <div className="bg-slate-800/50 rounded p-3 space-y-1">
                                            <p className="text-white font-semibold">{player.name}</p>
                                            <p className="text-slate-400 text-xs">
                                                {player.position} • {player.age}y • {player.current_club}
                                            </p>
                                            <p className="text-amber-400 text-sm font-semibold">€{player.market_value}M</p>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>

                        <div className="flex gap-3">
                            {selectedPlayers.length < 4 && (
                                <Button
                                    onClick={addPlayerSlot}
                                    variant="outline"
                                    className="border-slate-700 text-slate-300"
                                >
                                    + Add Player Slot
                                </Button>
                            )}
                            <Button
                                onClick={handleCompare}
                                disabled={selectedPlayers.filter(p => p).length < 2 || isAnalyzing}
                                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                            >
                                {isAnalyzing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Analyzing...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-4 h-4 mr-2" />
                                        Compare Players
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Comparison Components - Even if no analysis generated */}
                {selectedPlayers.filter(p => p).length >= 2 && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Attributes Side-by-Side */}
                        <AttributesComparison players={selectedPlayers.filter(p => p)} />

                        {/* Performance Stats */}
                        <PerformanceStatsComparison players={selectedPlayers.filter(p => p)} />

                        {/* AI Comprehensive Comparison */}
                        <AIComparisonAnalysis 
                            players={selectedPlayers.filter(p => p)} 
                            reports={reports}
                            projections={projections}
                        />

                        {/* Future Value Comparison */}
                        <FutureValueComparison 
                            players={selectedPlayers.filter(p => p)} 
                            projections={projections}
                        />

                        {/* Team Synergy Analysis */}
                        <TeamSynergyAnalysis players={selectedPlayers.filter(p => p)} />

                        {/* Historical Trends */}
                        {analysis && <HistoricalTrendChart playersData={analysis.players} />}

                        {/* Statistical Breakdown */}
                        {analysis && <StatisticalBreakdown playersData={analysis.players} />}

                        {/* Tactical System Analysis */}
                        {analysis && <TacticalSystemAnalysis playersData={analysis.players} />}

                        {analysis && (
                            <>
                                {/* Head to Head */}
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white flex items-center gap-2">
                                            <Users className="w-5 h-5 text-cyan-400" />
                                            Head-to-Head Comparison
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-slate-300 whitespace-pre-line leading-relaxed">
                                            {analysis.head_to_head}
                                        </p>
                                    </CardContent>
                                </Card>

                                {/* Strengths & Weaknesses Grid */}
                                <div className="grid md:grid-cols-2 gap-6">
                                    {/* Relative Strengths */}
                                    <Card className="bg-emerald-500/10 border-emerald-500/30">
                                        <CardHeader>
                                            <CardTitle className="text-emerald-400 flex items-center gap-2">
                                                <TrendingUp className="w-5 h-5" />
                                                Relative Strengths
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-4">
                                            {analysis.relative_strengths?.map((item, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                    <h4 className="text-white font-semibold mb-2">{item.player_name}</h4>
                                                    <ul className="space-y-1">
                                                        {item.strengths?.map((strength, i) => (
                                                            <li key={i} className="text-emerald-300 text-sm flex items-start gap-2">
                                                                <span className="text-emerald-400 mt-0.5">•</span>
                                                                {strength}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            ))}
                                        </CardContent>
                                    </Card>

                                    {/* Relative Weaknesses */}
                                    <Card className="bg-amber-500/10 border-amber-500/30">
                                        <CardHeader>
                                            <CardTitle className="text-amber-400 flex items-center gap-2">
                                                <AlertTriangle className="w-5 h-5" />
                                                Relative Weaknesses
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-4">
                                            {analysis.relative_weaknesses?.map((item, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                    <h4 className="text-white font-semibold mb-2">{item.player_name}</h4>
                                                    <ul className="space-y-1">
                                                        {item.weaknesses?.map((weakness, i) => (
                                                            <li key={i} className="text-amber-300 text-sm flex items-start gap-2">
                                                                <span className="text-amber-400 mt-0.5">•</span>
                                                                {weakness}
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            ))}
                                        </CardContent>
                                    </Card>
                                </div>

                                {/* Tactical Fit */}
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white flex items-center gap-2">
                                            <Target className="w-5 h-5 text-cyan-400" />
                                            Tactical System Fit Analysis
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid md:grid-cols-2 gap-4">
                                            {Object.entries(analysis.tactical_fit || {}).map(([formation, analysis]) => (
                                                <div key={formation} className="bg-slate-800/50 rounded-lg p-4">
                                                    <h4 className="text-cyan-400 font-bold mb-2">{formation}</h4>
                                                    <p className="text-slate-300 text-sm">{analysis}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Best Use Cases */}
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardHeader>
                                        <CardTitle className="text-white">Best Use Cases</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                            {analysis.best_use_cases?.map((item, idx) => (
                                                <div key={idx} className="bg-slate-800/50 rounded-lg p-4">
                                                    <h4 className="text-white font-semibold mb-2">{item.player_name}</h4>
                                                    <p className="text-slate-300 text-sm">{item.use_case}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Value Assessment */}
                                <Card className="bg-blue-500/10 border-blue-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-blue-400">Value for Money Assessment</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-slate-300 whitespace-pre-line leading-relaxed">
                                            {analysis.value_assessment}
                                        </p>
                                    </CardContent>
                                </Card>

                                {/* Final Recommendation */}
                                <Card className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border-cyan-500/30">
                                    <CardHeader>
                                        <CardTitle className="text-cyan-400 flex items-center gap-2">
                                            <Sparkles className="w-5 h-5" />
                                            Final Recommendation
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-white text-lg leading-relaxed whitespace-pre-line">
                                            {analysis.final_recommendation}
                                        </p>
                                    </CardContent>
                                </Card>
                            </>
                        )}
                    </motion.div>
                )}
        </div>
    );
}