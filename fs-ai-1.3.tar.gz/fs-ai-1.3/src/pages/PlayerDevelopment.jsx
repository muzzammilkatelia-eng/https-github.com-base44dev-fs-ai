import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Target, Calendar, Brain, GitBranch } from 'lucide-react';
import DevelopmentAnalyzer from '../components/development/DevelopmentAnalyzer';
import TrainingPlanGenerator from '../components/development/TrainingPlanGenerator';
import ProgressTracker from '../components/development/ProgressTracker';
import DevelopmentSimulator from '../components/development/DevelopmentSimulator';
import PremiumGate from '../components/PremiumGate';

export default function PlayerDevelopment() {
    return (
        <PremiumGate>
            <PlayerDevelopmentContent />
        </PremiumGate>
    );
}

function PlayerDevelopmentContent() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date')
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date')
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['player-projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date')
    });

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Player Development Center
                    </h1>
                    <p className="text-slate-400">AI-powered growth tracking, training plans, and progress monitoring</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Players</p>
                                    <p className="text-3xl font-bold text-white">{players.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Reports Analyzed</p>
                                    <p className="text-3xl font-bold text-white">{reports.length}</p>
                                </div>
                                <Brain className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Growth Projections</p>
                                    <p className="text-3xl font-bold text-white">{projections.length}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-green-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Training Plans</p>
                                    <p className="text-3xl font-bold text-white">
                                        {projections.filter(p => p.development_plan).length}
                                    </p>
                                </div>
                                <Calendar className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="analyzer" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-900/50 border border-slate-800">
                        <TabsTrigger value="analyzer">
                            <Brain className="w-4 h-4 mr-2" />
                            AI Analyzer
                        </TabsTrigger>
                        <TabsTrigger value="training">
                            <Target className="w-4 h-4 mr-2" />
                            Training Plans
                        </TabsTrigger>
                        <TabsTrigger value="progress">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            Progress Tracker
                        </TabsTrigger>
                        <TabsTrigger value="simulator">
                            <GitBranch className="w-4 h-4 mr-2" />
                            Simulator
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="analyzer" className="mt-6">
                        <DevelopmentAnalyzer 
                            players={players} 
                            reports={reports} 
                            projections={projections}
                        />
                    </TabsContent>

                    <TabsContent value="training" className="mt-6">
                        <TrainingPlanGenerator 
                            players={players} 
                            projections={projections}
                            reports={reports}
                        />
                    </TabsContent>

                    <TabsContent value="progress" className="mt-6">
                        <ProgressTracker 
                            players={players} 
                            reports={reports}
                            projections={projections}
                        />
                    </TabsContent>

                    <TabsContent value="simulator" className="mt-6">
                        <DevelopmentSimulator 
                            players={players} 
                            reports={reports}
                            projections={projections}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}