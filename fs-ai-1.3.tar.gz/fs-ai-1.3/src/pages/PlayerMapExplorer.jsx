import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Loader2, Globe, MapPin } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import InteractivePlayerMap from '../components/globe/InteractivePlayerMap';
import UkPlayerExplorer from '../components/map/UkPlayerExplorer';

export default function PlayerMapExplorer() {
    const [activeTab, setActiveTab] = useState('global');

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players-map'],
        queryFn: () => base44.entities.Player.list('-updated_date', 10000)
    });

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 animate-spin text-cyan-400 mx-auto mb-4" />
                    <p className="text-slate-400">Loading player data...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
                <div className="py-6 px-6 border-b border-slate-800 bg-slate-950">
                    <div className="max-w-7xl mx-auto flex items-center justify-between">
                        <div>
                            <h1 className="text-3xl font-bold text-white mb-1">
                                Player Map Explorer
                            </h1>
                            <p className="text-slate-400 text-sm">
                                Interactive visualization of player distribution and scouting data
                            </p>
                        </div>
                        <TabsList className="bg-slate-800 border border-slate-700">
                            <TabsTrigger value="global" className="flex items-center gap-2 data-[state=active]:bg-cyan-500/20">
                                <Globe className="w-4 h-4" />
                                Global
                            </TabsTrigger>
                            <TabsTrigger value="uk" className="flex items-center gap-2 data-[state=active]:bg-cyan-500/20">
                                <MapPin className="w-4 h-4" />
                                England & UK
                            </TabsTrigger>
                        </TabsList>
                    </div>
                </div>

                <TabsContent value="global" className="mt-0 p-6">
                    <div className="max-w-7xl mx-auto">
                        <InteractivePlayerMap players={players} />
                    </div>
                </TabsContent>

                <TabsContent value="uk" className="mt-0 h-[calc(100vh-180px)]">
                    <UkPlayerExplorer />
                </TabsContent>
            </Tabs>
        </div>
    );
}