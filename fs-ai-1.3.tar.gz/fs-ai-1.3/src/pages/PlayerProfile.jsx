import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, User, Activity, Heart, TrendingUp, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AdvancedStatsChart from '../components/player-profile/AdvancedStatsChart';
import InjuryHistoryTimeline from '../components/player-profile/InjuryHistoryTimeline';
import PerformanceMetricsChart from '../components/player-profile/PerformanceMetricsChart';
import ScoutNotesSection from '../components/player-profile/ScoutNotesSection';
import PremiumGate from '../components/PremiumGate';

export default function PlayerProfile() {
    const [playerId, setPlayerId] = useState(new URLSearchParams(window.location.search).get('id'));

    const { data: player, isLoading } = useQuery({
        queryKey: ['player', playerId],
        queryFn: async () => {
            const players = await base44.entities.Player.list();
            return players.find(p => p.id === playerId);
        },
        enabled: !!playerId
    });

    if (!playerId) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-12 pb-12 text-center">
                            <p className="text-slate-400">No player selected. Please select a player from the database.</p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        );
    }

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto text-center">
                    <p className="text-slate-400">Loading player profile...</p>
                </div>
            </div>
        );
    }

    if (!player) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-12 pb-12 text-center">
                            <p className="text-slate-400">Player not found.</p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <Button
                    variant="ghost"
                    onClick={() => window.history.back()}
                    className="text-slate-400 hover:text-white"
                >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                </Button>

                <Card className="bg-slate-900/50 border-slate-800">
                    <CardContent className="pt-6">
                        <div className="flex items-start gap-6">
                            <div className="h-24 w-24 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                                <User className="w-12 h-12 text-white" />
                            </div>
                            <div className="flex-1">
                                <h1 className="text-3xl font-bold text-white mb-2">{player.name}</h1>
                                <div className="flex flex-wrap gap-3 text-slate-300">
                                    <span>{player.position}</span>
                                    <span>•</span>
                                    <span>{player.age} years old</span>
                                    <span>•</span>
                                    <span>{player.current_club}</span>
                                    <span>•</span>
                                    <span>{player.nationality}</span>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Tabs defaultValue="stats" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-2 lg:grid-cols-4">
                        <TabsTrigger value="stats" className="flex items-center gap-2">
                            <Activity className="w-4 h-4" />
                            Advanced Stats
                        </TabsTrigger>
                        <TabsTrigger value="injuries" className="flex items-center gap-2">
                            <Heart className="w-4 h-4" />
                            Injury History
                        </TabsTrigger>
                        <TabsTrigger value="performance" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Performance
                        </TabsTrigger>
                        <TabsTrigger value="notes" className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            Scout Notes
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="stats">
                        <PremiumGate level="Club Pro">
                            <AdvancedStatsChart player={player} />
                        </PremiumGate>
                    </TabsContent>

                    <TabsContent value="injuries">
                        <InjuryHistoryTimeline player={player} />
                    </TabsContent>

                    <TabsContent value="performance">
                        <PremiumGate level="Club Pro">
                            <PerformanceMetricsChart player={player} />
                        </PremiumGate>
                    </TabsContent>

                    <TabsContent value="notes">
                        <ScoutNotesSection player={player} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}