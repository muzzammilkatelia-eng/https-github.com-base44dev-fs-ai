import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, TrendingUp, AlertCircle, FileText, BarChart3, Target, GitCompare } from 'lucide-react';
import { motion } from 'framer-motion';
import QuickComparePanel from '../components/comparison/QuickComparePanel';
import AdvancedStatsSection from '../components/player-profile/AdvancedStatsSection';
import InjuryHistorySection from '../components/player-profile/InjuryHistorySection';
import PerformanceTimelineSection from '../components/player-profile/PerformanceTimelineSection';
import ScoutNotesSection from '../components/player-profile/ScoutNotesSection';
import AIDevPlanGenerator from '../components/player-development/AIDevPlanGenerator';
import DevPlanTracker from '../components/player-development/DevPlanTracker';
import EnrichedPlayerStats from '../components/player-enrichment/EnrichedPlayerStats';
import PlayerDetailedStats from '../components/database/PlayerDetailedStats';

export default function PlayerProfileDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const playerId = urlParams.get('id');
    const [showCompare, setShowCompare] = useState(false);

    const { data: player, isLoading } = useQuery({
        queryKey: ['player', playerId],
        queryFn: async () => {
            const players = await base44.entities.Player.filter({ id: playerId });
            return players[0];
        },
        enabled: !!playerId
    });

    if (!playerId) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto text-center">
                    <p className="text-slate-400">No player ID provided</p>
                </div>
            </div>
        );
    }

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto text-center">
                    <p className="text-slate-400">Loading player...</p>
                </div>
            </div>
        );
    }

    if (!player) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
                <div className="max-w-7xl mx-auto text-center">
                    <p className="text-slate-400">Player not found</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Player Header */}
                <Card className="bg-slate-900/50 border-slate-800 p-6">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <h1 className="text-3xl font-bold text-white mb-2">{player.name}</h1>
                            <div className="flex items-center gap-2 flex-wrap">
                                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                    {player.position}
                                </Badge>
                                <Badge variant="outline" className="border-slate-600 text-slate-300">
                                    {player.age} years
                                </Badge>
                                <Badge variant="outline" className="border-slate-600 text-slate-300">
                                    {player.current_club}
                                </Badge>
                                {player.fsai_proprietary_score && (
                                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                        ⭐ {player.fsai_proprietary_score.toFixed(1)}
                                    </Badge>
                                )}
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <Button
                                onClick={() => setShowCompare(true)}
                                variant="outline"
                                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                            >
                                <GitCompare className="w-4 h-4 mr-2" />
                                Compare Player
                            </Button>
                            <div className="text-right">
                                <p className="text-2xl font-bold text-emerald-400">
                                    €{player.market_value}M
                                </p>
                                <p className="text-slate-400 text-sm">Market Value</p>
                            </div>
                        </div>
                    </div>
                </Card>

                {/* Compare Panel Modal */}
                {showCompare && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
                        onClick={() => setShowCompare(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            className="w-full max-w-5xl max-h-[90vh] overflow-y-auto"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <QuickComparePanel 
                                initialPlayers={[player]}
                                onClose={() => setShowCompare(false)}
                            />
                        </motion.div>
                    </motion.div>
                )}

                {/* Tabs */}
                <Tabs defaultValue="enriched" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-2 md:grid-cols-8">
                        <TabsTrigger value="enriched" className="flex items-center gap-2">
                            <Activity className="w-4 h-4" />
                            Live Data
                        </TabsTrigger>
                        <TabsTrigger value="detailed" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Detailed Stats
                        </TabsTrigger>
                        <TabsTrigger value="stats" className="flex items-center gap-2">
                            <BarChart3 className="w-4 h-4" />
                            Advanced Stats
                        </TabsTrigger>
                        <TabsTrigger value="performance" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Performance
                        </TabsTrigger>
                        <TabsTrigger value="injuries" className="flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Injury History
                        </TabsTrigger>
                        <TabsTrigger value="notes" className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            Scout Notes
                        </TabsTrigger>
                        <TabsTrigger value="devplan" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Development
                        </TabsTrigger>
                        <TabsTrigger value="progress" className="flex items-center gap-2">
                            <Activity className="w-4 h-4" />
                            Progress
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="enriched">
                        <EnrichedPlayerStats player={player} />
                    </TabsContent>

                    <TabsContent value="detailed">
                        <PlayerDetailedStats player={player} />
                    </TabsContent>

                    <TabsContent value="stats">
                        <AdvancedStatsSection player={player} />
                    </TabsContent>

                    <TabsContent value="performance">
                        <PerformanceTimelineSection player={player} />
                    </TabsContent>

                    <TabsContent value="injuries">
                        <InjuryHistorySection player={player} />
                    </TabsContent>

                    <TabsContent value="notes">
                        <ScoutNotesSection player={player} />
                    </TabsContent>

                    <TabsContent value="devplan">
                        <AIDevPlanGenerator player={player} />
                    </TabsContent>

                    <TabsContent value="progress">
                        <DevPlanTracker player={player} />
                    </TabsContent>
                    </Tabs>
            </div>
        </div>
    );
}