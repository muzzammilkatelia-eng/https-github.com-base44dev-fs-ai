import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import ProjectionCard from '../components/projections/ProjectionCard';
import DevelopmentPlan from '../components/projections/DevelopmentPlan';
import { Sparkles, Loader2, TrendingUp, History, Clipboard } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import toast from 'react-hot-toast';

export default function PlayerProjection() {
    const [playerData, setPlayerData] = useState({
        name: '',
        age: '',
        position: '',
        current_rating: '',
        recent_performance: '',
        strengths: '',
        weaknesses: ''
    });

    const [projection, setProjection] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);

    const queryClient = useQueryClient();

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 20)
    });

    const { data: scoutReports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 50)
    });

    const saveProjectionMutation = useMutation({
        mutationFn: (data) => base44.entities.PlayerProjection.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['projections'] });
            toast.success('Projection saved');
        }
    });

    const handleAnalyze = async () => {
        if (!playerData.name || !playerData.age || !playerData.position || !playerData.current_rating) {
            toast.error('Please fill in all required fields');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing player potential...', { id: 'analyze' });

        try {
            // Check if we have a scout report for this player
            const existingReport = scoutReports.find(r => 
                r.player_name.toLowerCase() === playerData.name.toLowerCase()
            );

            const reportContext = existingReport ? `
            
EXISTING SCOUT REPORT DATA:
- Player Age: ${existingReport.player_age}
- Position: ${existingReport.position}
- Recommendation: ${existingReport.recommendation}
- Overall Verdict: ${existingReport.overall_verdict}
- Modules Analysis: ${JSON.stringify({
    calafat: existingReport.calafat_analysis,
    brighton: existingReport.brighton_analysis,
    portuguese: existingReport.portuguese_analysis,
    dortmund: existingReport.dortmund_analysis,
    ajax: existingReport.ajax_analysis
})}

Use this data to inform your projection.` : '';

            const prompt = `You are an elite football development analyst. Analyze this player's potential trajectory and create a detailed development projection:

PLAYER PROFILE:
- Name: ${playerData.name}
- Current Age: ${playerData.age}
- Position: ${playerData.position}
- Current Rating: ${playerData.current_rating}/100
- Recent Performance: ${playerData.recent_performance || 'Not provided'}
- Strengths: ${playerData.strengths || 'Not provided'}
- Weaknesses: ${playerData.weaknesses || 'Not provided'}
${reportContext}

ANALYSIS REQUIREMENTS:

1. **Potential Trajectory**: Classify as one of:
   - Elite Tier Prospect (future world-class, 90+ potential)
   - Top Tier Prospect (future elite player, 85-89 potential)
   - Solid Professional (consistent top-league player, 80-84 potential)
   - Average Professional (reliable professional, 75-79 potential)
   - Late Bloomer (slow development, eventual good level)
   - Potential Decline (past peak or concerning trajectory)
   - Decline Phase (actively declining)

2. **Peak Potential Rating** (50-99): Realistic peak rating based on age, current level, position

3. **Years to Peak**: How many years until reaching peak performance

4. **Development Curve**: Describe the shape (e.g., "Steep early growth, plateau at 27", "Gradual steady improvement")

5. **Ceiling Analysis**: 2-3 paragraphs explaining:
   - Why this trajectory classification
   - Physical/technical/mental factors
   - Position-specific development expectations

6. **Development Priorities** (3-5 items): Specific areas to focus training:
   - Area name
   - Priority level (Critical/High/Medium/Low)
   - Detailed description of what to improve and why

7. **Recommended Pathway**: 2-3 paragraphs describing:
   - Best clubs/leagues for development
   - Playing time requirements
   - Tactical systems that suit their development

8. **Risk Factors** (3-5 items): Potential obstacles to reaching ceiling

9. **Age Milestones** (4-6 milestones): Project ratings at key ages with milestone descriptions

10. **Comparative Trajectory**: Compare to 2-3 similar players' development paths

Be realistic, specific, and tactical. Consider position-specific development curves (e.g., CBs peak later, wingers peak earlier).`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        potential_trajectory: {
                            type: "string",
                            enum: [
                                "Elite Tier Prospect",
                                "Top Tier Prospect",
                                "Solid Professional",
                                "Average Professional",
                                "Late Bloomer",
                                "Potential Decline",
                                "Decline Phase"
                            ]
                        },
                        peak_potential_rating: { type: "number" },
                        years_to_peak: { type: "number" },
                        development_curve: { type: "string" },
                        ceiling_analysis: { type: "string" },
                        development_priorities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    area: { type: "string" },
                                    priority: { type: "string" },
                                    description: { type: "string" }
                                }
                            }
                        },
                        recommended_pathway: { type: "string" },
                        risk_factors: {
                            type: "array",
                            items: { type: "string" }
                        },
                        age_milestones: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    age: { type: "number" },
                                    projected_rating: { type: "number" },
                                    milestone: { type: "string" }
                                }
                            }
                        },
                        comparative_trajectory: { type: "string" }
                    }
                }
            });

            const fullProjection = {
                player_name: playerData.name,
                current_age: parseInt(playerData.age),
                position: playerData.position,
                current_rating: parseInt(playerData.current_rating),
                ...response
            };

            setProjection(fullProjection);
            saveProjectionMutation.mutate(fullProjection);
            toast.success('Projection generated!', { id: 'analyze' });
            
            // Trigger alert check
            try {
                await base44.functions.checkAndTriggerAlerts({
                    playerData: {
                        name: playerData.name,
                        age: parseInt(playerData.age),
                        position: playerData.position,
                        trajectory: fullProjection.potential_trajectory,
                        potential_rating: fullProjection.peak_potential_rating,
                        years_to_peak: fullProjection.years_to_peak
                    },
                    dataType: 'projection'
                });
            } catch (error) {
                console.log('Alert check skipped:', error);
            }
        } catch (error) {
            console.error('Projection error:', error);
            toast.error('Analysis failed', { id: 'analyze' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleReset = () => {
        setProjection(null);
        setPlayerData({
            name: '',
            age: '',
            position: '',
            current_rating: '',
            recent_performance: '',
            strengths: '',
            weaknesses: ''
        });
    };

    const loadProjection = (proj) => {
        setProjection(proj);
    };

    const handleGeneratePlan = async () => {
        if (!projection) return;

        setIsGeneratingPlan(true);
        toast.loading('Generating development plan...', { id: 'plan' });

        try {
            const prompt = `You are an elite football development coach. Create a comprehensive, personalized long-term development plan for this player:

PLAYER PROFILE:
- Name: ${projection.player_name}
- Age: ${projection.current_age}
- Position: ${projection.position}
- Current Rating: ${projection.current_rating}
- Potential: ${projection.peak_potential_rating} (${projection.potential_trajectory})
- Years to Peak: ${projection.years_to_peak}
- Development Priorities: ${JSON.stringify(projection.development_priorities)}

Create a detailed development plan including:

1. TRAINING SCHEDULE:
   - Weekly Focus: 7 days with specific training focus, duration, and 3-4 exercises per day
   - Monthly Objectives: 6 months with 3-4 goals each month

2. SKILL FOCUS AREAS (5-7 key skills):
   - Skill name
   - Current level (1-10)
   - Target level (1-10)
   - Timeline (e.g., "3 months", "6 months")
   - 4-5 specific exercises/drills for each skill

3. MILESTONE TRACKING (4-6 milestones):
   - Milestone description
   - Target date
   - 3-4 measurable metrics
   - Status: "Pending"

4. Additional Development Areas:
   - Tactical Development: 2-3 paragraphs on tactical growth
   - Physical Program: 2-3 paragraphs on conditioning/strength
   - Mental Coaching: 2-3 paragraphs on psychology/mentality

Be extremely specific and actionable. Include real training exercises, drills, and measurable objectives.`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        training_schedule: {
                            type: "object",
                            properties: {
                                weekly_focus: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            day: { type: "string" },
                                            focus: { type: "string" },
                                            duration: { type: "string" },
                                            exercises: { type: "array", items: { type: "string" } }
                                        }
                                    }
                                },
                                monthly_objectives: {
                                    type: "array",
                                    items: {
                                        type: "object",
                                        properties: {
                                            month: { type: "string" },
                                            goals: { type: "array", items: { type: "string" } }
                                        }
                                    }
                                }
                            }
                        },
                        skill_focus_areas: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    skill: { type: "string" },
                                    current_level: { type: "number" },
                                    target_level: { type: "number" },
                                    timeline: { type: "string" },
                                    exercises: { type: "array", items: { type: "string" } }
                                }
                            }
                        },
                        milestone_tracking: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    milestone: { type: "string" },
                                    target_date: { type: "string" },
                                    metrics: { type: "array", items: { type: "string" } },
                                    status: { type: "string", enum: ["Pending", "On Track", "At Risk"] }
                                }
                            }
                        },
                        tactical_development: { type: "string" },
                        physical_program: { type: "string" },
                        mental_coaching: { type: "string" }
                    }
                }
            });

            const updatedProjection = {
                ...projection,
                development_plan: result
            };

            setProjection(updatedProjection);
            
            // Update the database
            await base44.entities.PlayerProjection.update(projection.id, {
                development_plan: result
            });

            queryClient.invalidateQueries({ queryKey: ['projections'] });
            toast.success('Development plan generated!', { id: 'plan' });
        } catch (error) {
            console.error('Plan generation error:', error);
            toast.error('Failed to generate plan', { id: 'plan' });
        } finally {
            setIsGeneratingPlan(false);
        }
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                        Player Potential Projection
                    </h1>
                    <p className="text-slate-400">AI-powered development trajectory analysis</p>
                </div>

                <Tabs defaultValue="analyze">
                    <TabsList className="grid w-full grid-cols-2 bg-slate-800 mb-6">
                        <TabsTrigger value="analyze" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            <Sparkles className="w-4 h-4 mr-2" />
                            Analyze
                        </TabsTrigger>
                        <TabsTrigger value="history" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            <History className="w-4 h-4 mr-2" />
                            History
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="analyze">
                        <AnimatePresence mode="wait">
                            {!projection ? (
                                <motion.div
                                    key="input"
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className="grid grid-cols-1 lg:grid-cols-3 gap-6"
                                >
                                    <div className="lg:col-span-1">
                                        <Card className="bg-slate-900/50 border-slate-800 sticky top-4">
                                            <CardHeader>
                                                <CardTitle className="text-white">Player Information</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div>
                                                    <Label className="text-slate-400">Player Name *</Label>
                                                    <Input
                                                        value={playerData.name}
                                                        onChange={(e) => setPlayerData({...playerData, name: e.target.value})}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        placeholder="e.g., Pedri"
                                                    />
                                                </div>

                                                <div className="grid grid-cols-2 gap-4">
                                                    <div>
                                                        <Label className="text-slate-400">Age *</Label>
                                                        <Input
                                                            type="number"
                                                            value={playerData.age}
                                                            onChange={(e) => setPlayerData({...playerData, age: e.target.value})}
                                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        />
                                                    </div>
                                                    <div>
                                                        <Label className="text-slate-400">Current Rating *</Label>
                                                        <Input
                                                            type="number"
                                                            min="50"
                                                            max="99"
                                                            value={playerData.current_rating}
                                                            onChange={(e) => setPlayerData({...playerData, current_rating: e.target.value})}
                                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                                            placeholder="75"
                                                        />
                                                    </div>
                                                </div>

                                                <div>
                                                    <Label className="text-slate-400">Position *</Label>
                                                    <Select value={playerData.position} onValueChange={(v) => setPlayerData({...playerData, position: v})}>
                                                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                                            <SelectValue />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                                            <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                                            <SelectItem value="Full-Back">Full-Back</SelectItem>
                                                            <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                                            <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                                            <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                                            <SelectItem value="Winger">Winger</SelectItem>
                                                            <SelectItem value="Striker">Striker</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                <div>
                                                    <Label className="text-slate-400">Recent Performance</Label>
                                                    <Textarea
                                                        value={playerData.recent_performance}
                                                        onChange={(e) => setPlayerData({...playerData, recent_performance: e.target.value})}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        placeholder="Last season stats, recent form..."
                                                        rows={3}
                                                    />
                                                </div>

                                                <div>
                                                    <Label className="text-slate-400">Key Strengths</Label>
                                                    <Textarea
                                                        value={playerData.strengths}
                                                        onChange={(e) => setPlayerData({...playerData, strengths: e.target.value})}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        placeholder="Technical skills, physical attributes..."
                                                        rows={2}
                                                    />
                                                </div>

                                                <div>
                                                    <Label className="text-slate-400">Areas to Improve</Label>
                                                    <Textarea
                                                        value={playerData.weaknesses}
                                                        onChange={(e) => setPlayerData({...playerData, weaknesses: e.target.value})}
                                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                                        placeholder="Weaknesses, development needs..."
                                                        rows={2}
                                                    />
                                                </div>

                                                <Button
                                                    onClick={handleAnalyze}
                                                    disabled={isAnalyzing}
                                                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white h-12 text-lg font-semibold"
                                                >
                                                    {isAnalyzing ? (
                                                        <>
                                                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                            Analyzing...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <TrendingUp className="w-5 h-5 mr-2" />
                                                            Generate Projection
                                                        </>
                                                    )}
                                                </Button>
                                            </CardContent>
                                        </Card>
                                    </div>

                                    <div className="lg:col-span-2 flex items-center justify-center">
                                        <div className="text-center">
                                            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                                                <TrendingUp className="w-10 h-10 text-white" />
                                            </div>
                                            <h3 className="text-xl font-bold text-white mb-2">Ready to Project</h3>
                                            <p className="text-slate-400">Enter player details to analyze their development potential</p>
                                        </div>
                                    </div>
                                </motion.div>
                            ) : (
                                <motion.div
                                    key="results"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-6"
                                >
                                    <div className="flex justify-between items-center">
                                        <Button
                                            onClick={handleReset}
                                            className="bg-slate-800 hover:bg-slate-700 text-white"
                                        >
                                            New Analysis
                                        </Button>
                                        {!projection.development_plan && (
                                            <Button
                                                onClick={handleGeneratePlan}
                                                disabled={isGeneratingPlan}
                                                className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
                                            >
                                                {isGeneratingPlan ? (
                                                    <>
                                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                        Generating...
                                                    </>
                                                ) : (
                                                    <>
                                                        <Clipboard className="w-4 h-4 mr-2" />
                                                        Generate Development Plan
                                                    </>
                                                )}
                                            </Button>
                                        )}
                                    </div>

                                    <Tabs defaultValue="projection">
                                        <TabsList className="grid w-full grid-cols-2 bg-slate-800">
                                            <TabsTrigger value="projection" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                                <TrendingUp className="w-4 h-4 mr-2" />
                                                Projection
                                            </TabsTrigger>
                                            <TabsTrigger 
                                                value="plan" 
                                                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
                                                disabled={!projection.development_plan}
                                            >
                                                <Clipboard className="w-4 h-4 mr-2" />
                                                Development Plan
                                            </TabsTrigger>
                                        </TabsList>

                                        <TabsContent value="projection" className="mt-6">
                                            <ProjectionCard projection={projection} />
                                        </TabsContent>

                                        <TabsContent value="plan" className="mt-6">
                                            <DevelopmentPlan plan={projection.development_plan} />
                                        </TabsContent>
                                    </Tabs>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </TabsContent>

                    <TabsContent value="history">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Previous Projections</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {projections.length === 0 ? (
                                    <p className="text-slate-400 text-center py-12">No projections yet</p>
                                ) : (
                                    <div className="space-y-4">
                                        {projections.map((proj) => (
                                            <div
                                                key={proj.id}
                                                className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors cursor-pointer"
                                                onClick={() => loadProjection(proj)}
                                            >
                                                <div className="flex justify-between items-start mb-2">
                                                    <div>
                                                        <h4 className="text-white font-semibold">{proj.player_name}</h4>
                                                        <p className="text-slate-400 text-sm">{proj.position} · {proj.current_age} years</p>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-cyan-400 font-bold">{proj.potential_trajectory}</p>
                                                        <p className="text-slate-500 text-sm">Peak: {proj.peak_potential_rating}</p>
                                                    </div>
                                                </div>
                                                <p className="text-slate-500 text-xs">
                                                    {new Date(proj.created_date).toLocaleDateString()}
                                                </p>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}