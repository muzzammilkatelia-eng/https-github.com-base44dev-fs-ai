import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import PredictiveAnalyticsDashboard from '../components/analytics/PredictiveAnalyticsDashboard';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function PredictiveAnalytics() {
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 200)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list()
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        Predictive Analytics
                        <HelpTooltip content="Forecast player performance, market value trends, and injury risks using advanced AI models. Make data-driven decisions with confidence." />
                    </h1>
                    <p className="text-slate-400">
                        AI-powered forecasting for player performance, value, and career trajectories
                    </p>
                </div>

                <PredictiveAnalyticsDashboard 
                    players={players}
                    reports={reports}
                    projections={projections}
                />
            </div>
        </div>
    );
}