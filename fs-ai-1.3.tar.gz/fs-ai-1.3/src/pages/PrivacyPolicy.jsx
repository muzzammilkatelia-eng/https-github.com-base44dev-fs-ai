import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export default function PrivacyPolicy() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-4xl font-bold text-white mb-6">Privacy Policy</h1>
                <p className="text-slate-400 mb-8">Universal Master Version</p>

                <div className="space-y-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">3.1 Purpose</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                This Privacy Policy explains how data is collected, used, stored, and protected across all platforms.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.2 Data Principles</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">All platforms follow:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Data minimisation</li>
                                <li>Purpose limitation</li>
                                <li>Privacy-by-design</li>
                                <li>Safeguarding-by-design</li>
                                <li>Transparency and user control</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.3 Data Collected</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Depending on the platform, data may include:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Account information</li>
                                <li>Learning progress</li>
                                <li>Interaction logs with AI educators</li>
                                <li>Technical data (device, browser, IP)</li>
                                <li>Parental/guardian verification data (where required)</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.4 Sensitive Data</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                Sensitive data is only collected where strictly necessary for safeguarding or educational delivery.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.5 How Data Is Used</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Data is used to:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Deliver educational content</li>
                                <li>Personalise learning</li>
                                <li>Maintain safety and safeguarding</li>
                                <li>Improve platform performance</li>
                                <li>Comply with legal obligations</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.6 Data Sharing</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">
                                Data is <strong>never sold</strong>.
                            </p>
                            <p className="text-slate-300 leading-relaxed mb-2">Data may be shared with:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Parents/guardians (for safeguarding)</li>
                                <li>Regulatory bodies (where legally required)</li>
                                <li>Service providers under strict contractual controls</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.7 Data Retention</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                Data is retained only as long as necessary for educational, safeguarding, or legal purposes.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">3.8 User Rights</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Users have rights to:</p>
                            <ul className="text-slate-300 space-y-2">
                                <li>Access</li>
                                <li>Rectification</li>
                                <li>Erasure</li>
                                <li>Restriction</li>
                                <li>Objection</li>
                                <li>Data portability</li>
                            </ul>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}