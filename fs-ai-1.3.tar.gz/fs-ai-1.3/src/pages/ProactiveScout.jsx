import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Target, Zap, Activity } from "lucide-react";
import ProactiveScoutingAgent from "../components/ai-automation/ProactiveScoutingAgent";
import AutomationScheduler from "../components/ai-automation/AutomationScheduler";
import CriteriaManager from "../components/workflow/CriteriaManager";

export default function ProactiveScout() {
    const [selectedCriteria, setSelectedCriteria] = useState(null);

    const { data: criteria = [] } = useQuery({
        queryKey: ['ai-criteria'],
        queryFn: () => base44.entities.AIScoutingCriteria.list()
    });

    const { data: players = [] } = useQuery({
        queryKey: ['all-players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 1000)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks'],
        queryFn: () => base44.entities.ScoutingTask.list('-created_date', 100)
    });

    const activeCriteria = criteria.filter(c => c.active);
    const autoReports = reports.filter(r => r.notes?.includes('Auto-generated'));
    const autoTasks = tasks.filter(t => t.source === 'AI Flag');

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Sparkles className="w-8 h-8 text-purple-400" />
                        Proactive AI Scout
                    </h1>
                    <p className="text-slate-400">
                        AI-driven automation for proactive player identification and scouting report generation
                    </p>
                </div>

                {/* Stats Overview */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Criteria</p>
                                    <p className="text-4xl font-bold text-white">{activeCriteria.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Auto Reports</p>
                                    <p className="text-4xl font-bold text-white">{autoReports.length}</p>
                                </div>
                                <Zap className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Auto Tasks</p>
                                    <p className="text-4xl font-bold text-white">{autoTasks.length}</p>
                                </div>
                                <Activity className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Players Pool</p>
                                    <p className="text-4xl font-bold text-white">{players.length}</p>
                                </div>
                                <Sparkles className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="automation" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800">
                        <TabsTrigger value="automation">Automation</TabsTrigger>
                        <TabsTrigger value="criteria">Criteria Manager</TabsTrigger>
                        <TabsTrigger value="schedule">Schedule</TabsTrigger>
                    </TabsList>

                    <TabsContent value="automation" className="space-y-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Select Scouting Criteria</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {criteria.length === 0 ? (
                                    <div className="text-center py-12">
                                        <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                        <p className="text-slate-400 mb-4">No criteria defined yet</p>
                                        <p className="text-slate-500 text-sm">Create criteria in the Criteria Manager tab</p>
                                    </div>
                                ) : (
                                    <div className="grid md:grid-cols-2 gap-4">
                                        {criteria.map(c => (
                                            <button
                                                key={c.id}
                                                onClick={() => setSelectedCriteria(c)}
                                                className={`text-left p-4 rounded-lg border transition-all ${
                                                    selectedCriteria?.id === c.id
                                                        ? 'bg-purple-500/20 border-purple-500/50'
                                                        : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                                                }`}
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <h4 className="text-white font-semibold">{c.name}</h4>
                                                    {c.active && (
                                                        <span className="px-2 py-1 rounded text-xs bg-emerald-500/20 text-emerald-400">
                                                            Active
                                                        </span>
                                                    )}
                                                </div>
                                                <p className="text-slate-400 text-sm">{c.criteria_type}</p>
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {selectedCriteria && (
                            <ProactiveScoutingAgent 
                                criteria={selectedCriteria} 
                                players={players}
                            />
                        )}
                    </TabsContent>

                    <TabsContent value="criteria">
                        <CriteriaManager />
                    </TabsContent>

                    <TabsContent value="schedule">
                        {selectedCriteria ? (
                            <AutomationScheduler 
                                criteria={selectedCriteria}
                                onUpdate={(updated) => setSelectedCriteria(updated)}
                            />
                        ) : (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="py-16 text-center">
                                    <Target className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                    <p className="text-slate-400">Select criteria to configure automation schedule</p>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}