import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    BarChart3, TrendingUp, Target, Users, 
    DollarSign, Clock, CheckCircle, AlertCircle,
    Zap, Mail, FileText, Calendar
} from 'lucide-react';
import { motion } from 'framer-motion';
import ScoutingEfficiencyChart from '../components/analytics-dashboard/ScoutingEfficiencyChart';
import TransferSuccessMetrics from '../components/analytics-dashboard/TransferSuccessMetrics';
import AgentEngagementMetrics from '../components/analytics-dashboard/AgentEngagementMetrics';
import PerformanceOverview from '../components/analytics-dashboard/PerformanceOverview';
import PlayerPipelineChart from '../components/analytics-dashboard/PlayerPipelineChart';
import RecommendationBreakdown from '../components/analytics-dashboard/RecommendationBreakdown';
import PremiumGate from '../components/PremiumGate';

export default function RecruitmentAnalytics() {
    return (
        <PremiumGate>
            <RecruitmentAnalyticsContent />
        </PremiumGate>
    );
}

function RecruitmentAnalyticsContent() {
    const [timeRange, setTimeRange] = useState('30'); // days

    // Fetch all data
    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scouting-reports-analytics'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 500)
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks-analytics'],
        queryFn: () => base44.entities.ScoutingTask.list('-created_date', 500)
    });

    const { data: communications = [] } = useQuery({
        queryKey: ['comms-analytics'],
        queryFn: () => base44.entities.AgentCommunication.list('-created_date', 500)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections-analytics'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 200)
    });

    // Calculate KPIs
    const totalPlayersScoped = scoutingReports.length;
    const completedTasks = tasks.filter(t => t.status === 'Completed').length;
    const totalTasks = tasks.length;
    const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    const immediateSigning = scoutingReports.filter(r => r.recommendation === 'Immediate Signing').length;
    const monitorClosely = scoutingReports.filter(r => r.recommendation === 'Monitor Closely').length;
    const passRecommendation = scoutingReports.filter(r => r.recommendation === 'Pass').length;

    const sentComms = communications.filter(c => c.status === 'Sent' || c.status === 'Awaiting Response' || c.status === 'Responded').length;
    const respondedComms = communications.filter(c => c.response_received).length;
    const responseRate = sentComms > 0 ? Math.round((respondedComms / sentComms) * 100) : 0;

    const positiveResponses = communications.filter(c => 
        c.ai_sentiment_analysis?.sentiment === 'Very Positive' || 
        c.ai_sentiment_analysis?.sentiment === 'Positive'
    ).length;
    const analyzedResponses = communications.filter(c => c.ai_sentiment_analysis).length;
    const positiveRate = analyzedResponses > 0 ? Math.round((positiveResponses / analyzedResponses) * 100) : 0;

    const aiFlaggedTasks = tasks.filter(t => t.source === 'AI Flag').length;
    const highPotentialPlayers = projections.filter(p => 
        p.potential_trajectory === 'Elite Tier Prospect' || 
        p.potential_trajectory === 'Top Tier Prospect'
    ).length;

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Recruitment Analytics
                    </h1>
                    <p className="text-slate-400">Comprehensive insights across all scouting and recruitment operations</p>
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
                        <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">Players Scouted</p>
                                        <p className="text-3xl font-bold text-cyan-400">{totalPlayersScoped}</p>
                                    </div>
                                    <Target className="w-10 h-10 text-cyan-400" />
                                </div>
                                <div className="mt-3 flex items-center gap-2">
                                    <div className="text-xs text-emerald-400 flex items-center gap-1">
                                        <TrendingUp className="w-3 h-3" />
                                        {immediateSigning} priority targets
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">Task Completion</p>
                                        <p className="text-3xl font-bold text-purple-400">{taskCompletionRate}%</p>
                                    </div>
                                    <CheckCircle className="w-10 h-10 text-purple-400" />
                                </div>
                                <div className="mt-3 text-xs text-slate-400">
                                    {completedTasks} of {totalTasks} tasks completed
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                        <Card className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">Agent Response Rate</p>
                                        <p className="text-3xl font-bold text-emerald-400">{responseRate}%</p>
                                    </div>
                                    <Mail className="w-10 h-10 text-emerald-400" />
                                </div>
                                <div className="mt-3 text-xs text-slate-400">
                                    {respondedComms} responses from {sentComms} sent
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                        <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-slate-400 text-sm mb-1">Positive Sentiment</p>
                                        <p className="text-3xl font-bold text-amber-400">{positiveRate}%</p>
                                    </div>
                                    <TrendingUp className="w-10 h-10 text-amber-400" />
                                </div>
                                <div className="mt-3 text-xs text-slate-400">
                                    {positiveResponses} positive of {analyzedResponses} analyzed
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                {/* Secondary Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-4 pb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                                    <Zap className="w-5 h-5 text-purple-400" />
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs">AI Flagged</p>
                                    <p className="text-white text-xl font-bold">{aiFlaggedTasks}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-4 pb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                                    <Target className="w-5 h-5 text-cyan-400" />
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs">High Potential</p>
                                    <p className="text-white text-xl font-bold">{highPotentialPlayers}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-4 pb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs">Sign Priority</p>
                                    <p className="text-white text-xl font-bold">{immediateSigning}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-4 pb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                                    <Clock className="w-5 h-5 text-amber-400" />
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs">Monitor</p>
                                    <p className="text-white text-xl font-bold">{monitorClosely}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-5 bg-slate-800">
                        <TabsTrigger value="overview">
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Overview
                        </TabsTrigger>
                        <TabsTrigger value="scouting">
                            <FileText className="w-4 h-4 mr-2" />
                            Scouting
                        </TabsTrigger>
                        <TabsTrigger value="tasks">
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Tasks
                        </TabsTrigger>
                        <TabsTrigger value="agents">
                            <Mail className="w-4 h-4 mr-2" />
                            Agents
                        </TabsTrigger>
                        <TabsTrigger value="pipeline">
                            <Target className="w-4 h-4 mr-2" />
                            Pipeline
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="mt-6">
                        <PerformanceOverview 
                            scoutingReports={scoutingReports}
                            tasks={tasks}
                            communications={communications}
                            projections={projections}
                        />
                    </TabsContent>

                    <TabsContent value="scouting" className="mt-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <RecommendationBreakdown scoutingReports={scoutingReports} />
                            <ScoutingEfficiencyChart scoutingReports={scoutingReports} />
                        </div>
                    </TabsContent>

                    <TabsContent value="tasks" className="mt-6">
                        <TransferSuccessMetrics tasks={tasks} />
                    </TabsContent>

                    <TabsContent value="agents" className="mt-6">
                        <AgentEngagementMetrics communications={communications} />
                    </TabsContent>

                    <TabsContent value="pipeline" className="mt-6">
                        <PlayerPipelineChart 
                            scoutingReports={scoutingReports}
                            tasks={tasks}
                            communications={communications}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}