import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Target, Users, FileText, Play } from 'lucide-react';
import TransferTargetEngine from '../components/recruitment/TransferTargetEngine';
import SquadDepthAnalyzer from '../components/recruitment/SquadDepthAnalyzer';
import ScoutingBriefGenerator from '../components/recruitment/ScoutingBriefGenerator';
import TransferScenarioSimulator from '../components/recruitment/TransferScenarioSimulator';
import ProactiveAgentPanel from '../components/recruitment/ProactiveAgentPanel';
import AITalentDiscovery from '../components/recruitment/AITalentDiscovery';
import MultiBrainAnalyzer from '../components/recruitment/MultiBrainAnalyzer';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function RecruitmentHub() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Target className="w-8 h-8 text-cyan-400" />
                        AI Recruitment Hub
                        <HelpTooltip content="Comprehensive AI-powered recruitment tools including transfer target recommendations, squad depth analysis, scouting briefs, and scenario simulation." />
                    </h1>
                    <p className="text-slate-400">
                        AI-driven tools for strategic recruitment and squad building
                    </p>
                </div>

                <Tabs defaultValue="targets" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-2 lg:grid-cols-5">
                        <TabsTrigger value="agent" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            AI Agent
                        </TabsTrigger>
                        <TabsTrigger value="targets" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Transfer Targets
                        </TabsTrigger>
                        <TabsTrigger value="depth" className="flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Squad Depth
                        </TabsTrigger>
                        <TabsTrigger value="briefs" className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            Scouting Briefs
                        </TabsTrigger>
                        <TabsTrigger value="simulator" className="flex items-center gap-2">
                            <Play className="w-4 h-4" />
                            Scenario Simulator
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="agent" className="space-y-6">
                        <div className="grid lg:grid-cols-3 gap-6">
                            <div className="lg:col-span-2">
                                <ProactiveAgentPanel />
                            </div>
                            <AITalentDiscovery />
                        </div>
                    </TabsContent>

                    <TabsContent value="targets">
                        <TransferTargetEngine />
                    </TabsContent>

                    <TabsContent value="depth">
                        <SquadDepthAnalyzer />
                    </TabsContent>

                    <TabsContent value="briefs">
                        <ScoutingBriefGenerator />
                    </TabsContent>

                    <TabsContent value="simulator">
                        <TransferScenarioSimulator />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}