import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FileText, Search, Trash2, TrendingUp, Target, Users, Sparkles, FileX, Upload, Loader2, GitCompare, CheckSquare, BarChart3, PieChart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MetricDisplay from "../components/scouting/MetricDisplay";
import CompareReports from "../components/scouting/CompareReports";
import PlayerBenchmarking from "../components/scouting/PlayerBenchmarking";
import ModuleRadarChart from "../components/scouting/ModuleRadarChart";
import RecommendationDistribution from "../components/scouting/RecommendationDistribution";
import ExportButton from "../components/ExportButton";
import AdvancedPlayerAnalytics from "../components/analytics/AdvancedPlayerAnalytics";
import toast from "react-hot-toast";

export default function Reports() {
    const [searchQuery, setSearchQuery] = useState("");
    const [filterRecommendation, setFilterRecommendation] = useState("all");
    const [selectedReport, setSelectedReport] = useState(null);
    const [exportingReportId, setExportingReportId] = useState(null);
    const [compareMode, setCompareMode] = useState(false);
    const [selectedForCompare, setSelectedForCompare] = useState([]);
    const [showComparison, setShowComparison] = useState(false);

    const queryClient = useQueryClient();

    const { data: reports = [], isLoading } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date'),
    });

    const deleteReportMutation = useMutation({
        mutationFn: (id) => base44.entities.ScoutingReport.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['reports'] });
        },
    });

    const handleExportToDrive = async (report) => {
        setExportingReportId(report.id);
        
        try {
            const result = await base44.functions.exportToGoogleDrive({
                reportId: report.id,
                reportData: report
            });

            if (result.success) {
                toast.success("Report exported to Google Drive!");
                window.open(result.documentUrl, '_blank');
            } else {
                if (result.error?.includes("not connected")) {
                    toast.error("Please authorize Google Drive access first");
                } else {
                    toast.error(result.error || "Export failed");
                }
            }
        } catch (error) {
            console.error("Export error:", error);
            toast.error("Failed to export report. Ensure backend functions are enabled.");
        } finally {
            setExportingReportId(null);
        }
    };

    const filteredReports = reports.filter(report => {
        const matchesSearch = report.player_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            report.position.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = filterRecommendation === "all" || report.recommendation === filterRecommendation;
        return matchesSearch && matchesFilter;
    });

    const handleDeleteReport = (id) => {
        if (confirm("Delete this report?")) {
            deleteReportMutation.mutate(id);
            setSelectedReport(null);
        }
    };

    const toggleCompareSelection = (report) => {
        setSelectedForCompare(prev => {
            const isSelected = prev.some(r => r.id === report.id);
            if (isSelected) {
                return prev.filter(r => r.id !== report.id);
            } else if (prev.length < 3) {
                return [...prev, report];
            }
            return prev;
        });
    };

    const handleCompare = () => {
        if (selectedForCompare.length >= 2) {
            setShowComparison(true);
        }
    };

    const exitCompareMode = () => {
        setCompareMode(false);
        setSelectedForCompare([]);
    };

    const getRecommendationColor = (recommendation) => {
        switch (recommendation) {
            case "Strong Recommend": return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
            case "Recommend": return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30";
            case "Monitor": return "bg-amber-500/20 text-amber-400 border-amber-500/30";
            case "Pass": return "bg-slate-500/20 text-slate-400 border-slate-500/30";
            default: return "bg-slate-500/20 text-slate-400 border-slate-500/30";
        }
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-3">
                                Scouting Reports
                            </h1>
                            <p className="text-slate-400">
                                {compareMode ? `Select 2-3 players to compare (${selectedForCompare.length} selected)` : 'View and manage all generated reports'}
                            </p>
                        </div>
                        <div className="flex gap-3">
                            {compareMode ? (
                                <>
                                    <Button
                                        onClick={handleCompare}
                                        disabled={selectedForCompare.length < 2}
                                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                                    >
                                        <GitCompare className="w-4 h-4 mr-2" />
                                        Compare ({selectedForCompare.length})
                                    </Button>
                                    <Button
                                        onClick={exitCompareMode}
                                        variant="outline"
                                        className="border-slate-700 text-slate-400 hover:text-white"
                                    >
                                        Cancel
                                    </Button>
                                </>
                            ) : (
                                <>
                                    <ExportButton 
                                        entityType="ScoutingReport" 
                                        title="FS-AI Scouting Reports"
                                        label="Export to Sheets"
                                    />
                                    <Button
                                        onClick={() => setCompareMode(true)}
                                        disabled={reports.length < 2}
                                        variant="outline"
                                        className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                                    >
                                        <GitCompare className="w-4 h-4 mr-2" />
                                        Compare Players
                                    </Button>
                                </>
                            )}
                        </div>
                    </div>

                    {/* Analytics Overview */}
                    {!compareMode && reports.length > 0 && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-2">
                                        <PieChart className="w-5 h-5 text-cyan-400" />
                                        Recommendation Distribution
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <RecommendationDistribution reports={reports} />
                                </CardContent>
                            </Card>
                            
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Quick Stats</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <p className="text-slate-400 text-sm">Total Reports</p>
                                            <p className="text-3xl font-bold text-cyan-400">{reports.length}</p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <p className="text-slate-400 text-sm">Strong Recommends</p>
                                            <p className="text-3xl font-bold text-emerald-400">
                                                {reports.filter(r => r.recommendation === 'Strong Recommend').length}
                                            </p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <p className="text-slate-400 text-sm">Positions Covered</p>
                                            <p className="text-3xl font-bold text-blue-400">
                                                {new Set(reports.map(r => r.position)).size}
                                            </p>
                                        </div>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <p className="text-slate-400 text-sm">Avg Player Age</p>
                                            <p className="text-3xl font-bold text-amber-400">
                                                {Math.round(reports.reduce((sum, r) => sum + r.player_age, 0) / reports.length)}
                                            </p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    )}
                </div>

                {/* Filters */}
                <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800 mb-8">
                    <CardContent className="pt-6">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="flex-1 relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                                <Input
                                    placeholder="Search by player name or position..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="pl-10 bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <Select value={filterRecommendation} onValueChange={setFilterRecommendation}>
                                <SelectTrigger className="w-full md:w-48 bg-slate-800 border-slate-700 text-white">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Recommendations</SelectItem>
                                    <SelectItem value="Strong Recommend">Strong Recommend</SelectItem>
                                    <SelectItem value="Recommend">Recommend</SelectItem>
                                    <SelectItem value="Monitor">Monitor</SelectItem>
                                    <SelectItem value="Pass">Pass</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </CardContent>
                </Card>

                {/* Reports Grid */}
                {isLoading ? (
                    <div className="text-center py-20">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center animate-pulse">
                            <FileText className="w-8 h-8 text-white" />
                        </div>
                        <p className="text-slate-400">Loading reports...</p>
                    </div>
                ) : filteredReports.length === 0 ? (
                    <div className="text-center py-20">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-slate-800 flex items-center justify-center">
                            <FileX className="w-8 h-8 text-slate-600" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2">No Reports Found</h3>
                        <p className="text-slate-400">
                            {reports.length === 0 ? "Start scouting players to generate reports" : "Try adjusting your filters"}
                        </p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <AnimatePresence>
                            {filteredReports.map((report, index) => (
                                <motion.div
                                    key={report.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    onClick={() => compareMode ? toggleCompareSelection(report) : setSelectedReport(report)}
                                    className="cursor-pointer"
                                >
                                    <Card className={`bg-slate-900/50 backdrop-blur-xl border-slate-800 hover:border-cyan-500/30 transition-all h-full relative ${
                                        compareMode && selectedForCompare.some(r => r.id === report.id) ? 'ring-2 ring-cyan-500 border-cyan-500' : ''
                                    }`}>
                                        <CardHeader>
                                            <div className="flex justify-between items-start mb-3">
                                                <div className="flex-1">
                                                    <CardTitle className="text-white text-lg">{report.player_name}</CardTitle>
                                                    <p className="text-slate-400 text-sm">{report.position} · {report.player_age} years</p>
                                                </div>
                                                {compareMode ? (
                                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                                                        selectedForCompare.some(r => r.id === report.id) 
                                                            ? 'bg-cyan-500 border-cyan-500' 
                                                            : 'border-slate-600'
                                                    }`}>
                                                        {selectedForCompare.some(r => r.id === report.id) && (
                                                            <CheckSquare className="w-4 h-4 text-white" />
                                                        )}
                                                    </div>
                                                ) : (
                                                    <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getRecommendationColor(report.recommendation)}`}>
                                                        {report.recommendation}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="flex flex-wrap gap-2">
                                                {report.modules_activated?.map(module => (
                                                    <span key={module} className="px-2 py-1 bg-slate-800 text-slate-400 text-xs rounded">
                                                        {module}
                                                    </span>
                                                ))}
                                            </div>
                                        </CardHeader>
                                        <CardContent>
                                            <p className="text-slate-400 text-sm line-clamp-3 mb-4">{report.overall_verdict}</p>
                                            {!compareMode && (
                                                <Button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleExportToDrive(report);
                                                    }}
                                                    disabled={exportingReportId === report.id}
                                                    size="sm"
                                                    className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                                                >
                                                    {exportingReportId === report.id ? (
                                                        <>
                                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                            Exporting...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <Upload className="w-4 h-4 mr-2" />
                                                            Export to Drive
                                                        </>
                                                    )}
                                                </Button>
                                            )}
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>
                )}

                {/* Report Detail Dialog */}
                <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-slate-800 text-white">
                        {selectedReport && (
                            <>
                                <DialogHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <DialogTitle className="text-2xl text-white mb-1">{selectedReport.player_name}</DialogTitle>
                                            <p className="text-slate-400">{selectedReport.position} · {selectedReport.player_age} years</p>
                                        </div>
                                        <span className={`px-4 py-2 rounded-full text-sm font-bold border ${getRecommendationColor(selectedReport.recommendation)}`}>
                                            {selectedReport.recommendation}
                                        </span>
                                    </div>
                                </DialogHeader>

                                <Tabs defaultValue="analysis" className="mt-6">
                                    <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                                        <TabsTrigger value="analysis" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                                            <FileText className="w-4 h-4 mr-2" />
                                            Analysis
                                        </TabsTrigger>
                                        <TabsTrigger value="benchmark" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                                            <BarChart3 className="w-4 h-4 mr-2" />
                                            Benchmarking
                                        </TabsTrigger>
                                        <TabsTrigger value="advanced" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                                            <TrendingUp className="w-4 h-4 mr-2" />
                                            Advanced
                                        </TabsTrigger>
                                    </TabsList>

                                    <TabsContent value="analysis" className="space-y-6 mt-6">
                                    {/* Visual Analysis */}
                                    <Card className="bg-slate-800/50 border-slate-700">
                                        <CardHeader>
                                            <CardTitle className="text-white">Module Performance Overview</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <ModuleRadarChart report={selectedReport} />
                                        </CardContent>
                                    </Card>

                                    {/* Verdict */}
                                    <div className="bg-slate-800/50 rounded-xl p-4">
                                        <h4 className="text-cyan-400 font-semibold mb-2">FS–AI Verdict</h4>
                                        <p className="text-slate-300 leading-relaxed">{selectedReport.overall_verdict}</p>
                                    </div>

                                    {selectedReport.notes && (
                                        <div className="bg-slate-800/50 rounded-xl p-4">
                                            <h4 className="text-amber-400 font-semibold mb-2">Additional Notes</h4>
                                            <p className="text-slate-300 leading-relaxed">{selectedReport.notes}</p>
                                        </div>
                                    )}

                                    {/* Module Results */}
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {selectedReport.calafat_analysis && (
                                            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                                                        <Sparkles className="w-4 h-4 text-white" />
                                                    </div>
                                                    <h4 className="text-white font-semibold">Calafat Mode</h4>
                                                </div>
                                                <MetricDisplay label="Ceiling Score" value={selectedReport.calafat_analysis.ceiling_score} color="purple" />
                                                <MetricDisplay label="Risk Score" value={selectedReport.calafat_analysis.risk_score} color="red" />
                                                <div>
                                                    <span className="text-slate-400 text-sm">Development Curve</span>
                                                    <p className="text-white text-sm mt-1">{selectedReport.calafat_analysis.development_curve}</p>
                                                </div>
                                            </div>
                                        )}

                                        {selectedReport.brighton_analysis && (
                                            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                                                        <TrendingUp className="w-4 h-4 text-white" />
                                                    </div>
                                                    <h4 className="text-white font-semibold">Brighton Mode</h4>
                                                </div>
                                                <MetricDisplay label="Hidden Gem" value={selectedReport.brighton_analysis.hidden_gem_score} color="cyan" />
                                                <MetricDisplay label="ROI Score" value={selectedReport.brighton_analysis.roi_score} color="emerald" />
                                                <div>
                                                    <span className="text-slate-400 text-sm">Market Trajectory</span>
                                                    <p className="text-white text-sm mt-1">{selectedReport.brighton_analysis.market_value_trajectory}</p>
                                                </div>
                                            </div>
                                        )}

                                        {selectedReport.portuguese_analysis && (
                                            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                                                        <Target className="w-4 h-4 text-white" />
                                                    </div>
                                                    <h4 className="text-white font-semibold">Portuguese Pipeline</h4>
                                                </div>
                                                <MetricDisplay label="Flip Potential" value={selectedReport.portuguese_analysis.flip_potential} color="emerald" />
                                                <MetricDisplay label="Adaptation" value={selectedReport.portuguese_analysis.adaptation_score} color="cyan" />
                                                <MetricDisplay label="Versatility" value={selectedReport.portuguese_analysis.versatility_index} color="amber" />
                                            </div>
                                        )}

                                        {selectedReport.dortmund_analysis && (
                                            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                                                        <Users className="w-4 h-4 text-white" />
                                                    </div>
                                                    <h4 className="text-white font-semibold">Dortmund Mode</h4>
                                                </div>
                                                <MetricDisplay label="Readiness" value={selectedReport.dortmund_analysis.readiness_score} color="amber" />
                                                <MetricDisplay label="Resilience" value={selectedReport.dortmund_analysis.resilience_index} color="emerald" />
                                                <div>
                                                    <span className="text-slate-400 text-sm">Acceleration Curve</span>
                                                    <p className="text-white text-sm mt-1">{selectedReport.dortmund_analysis.acceleration_curve}</p>
                                                </div>
                                            </div>
                                        )}

                                        {selectedReport.ajax_analysis && (
                                            <div className="bg-slate-800/50 rounded-xl p-4 space-y-3">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center">
                                                        <FileText className="w-4 h-4 text-white" />
                                                    </div>
                                                    <h4 className="text-white font-semibold">Ajax Mode</h4>
                                                </div>
                                                <MetricDisplay label="Technical Purity" value={selectedReport.ajax_analysis.technical_purity} color="red" />
                                                <MetricDisplay label="Positional IQ" value={selectedReport.ajax_analysis.positional_iq} color="purple" />
                                                <MetricDisplay label="Academy Fit" value={selectedReport.ajax_analysis.academy_fit} color="cyan" />
                                            </div>
                                        )}
                                    </div>

                                        {/* Action Buttons */}
                                        <div className="grid grid-cols-2 gap-4">
                                            <Button
                                                onClick={() => handleExportToDrive(selectedReport)}
                                                disabled={exportingReportId === selectedReport.id}
                                                className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30"
                                            >
                                                {exportingReportId === selectedReport.id ? (
                                                    <>
                                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                        Exporting...
                                                    </>
                                                ) : (
                                                    <>
                                                        <Upload className="w-4 h-4 mr-2" />
                                                        Export to Drive
                                                    </>
                                                )}
                                            </Button>
                                            <Button
                                                onClick={() => handleDeleteReport(selectedReport.id)}
                                                variant="destructive"
                                                className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30"
                                            >
                                                <Trash2 className="w-4 h-4 mr-2" />
                                                Delete Report
                                            </Button>
                                        </div>
                                    </TabsContent>

                                    <TabsContent value="benchmark" className="mt-6">
                                        <PlayerBenchmarking 
                                            currentReport={selectedReport} 
                                            allReports={reports}
                                        />
                                    </TabsContent>

                                    <TabsContent value="advanced" className="mt-6">
                                        <AdvancedPlayerAnalytics 
                                            playerName={selectedReport.player_name}
                                        />
                                    </TabsContent>
                                </Tabs>
                            </>
                        )}
                    </DialogContent>
                </Dialog>

                {/* Comparison View */}
                {showComparison && (
                    <CompareReports 
                        reports={selectedForCompare} 
                        onClose={() => {
                            setShowComparison(false);
                            setCompareMode(false);
                            setSelectedForCompare([]);
                        }} 
                    />
                )}
            </div>
        </div>
    );
}