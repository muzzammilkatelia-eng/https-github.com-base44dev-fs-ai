import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Calendar, Sparkles, Activity } from 'lucide-react';
import SquadDepthChart from '../components/rotation/SquadDepthChart';
import FixtureCongestSimulator from '../components/rotation/FixtureCongestSimulator';
import AIRotationSuggester from '../components/rotation/AIRotationSuggester';
import WorkloadTracker from '../components/rotation/WorkloadTracker';

export default function RotationPlanner() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Users className="w-8 h-8 text-cyan-400" />
                        Squad Rotation Planner
                    </h1>
                    <p className="text-slate-400">
                        Optimize squad depth, manage fixture congestion, and track player workload
                    </p>
                </div>

                <Tabs defaultValue="depth" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4">
                        <TabsTrigger value="depth" className="flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Squad Depth
                        </TabsTrigger>
                        <TabsTrigger value="fixtures" className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            Fixture Congestion
                        </TabsTrigger>
                        <TabsTrigger value="ai" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            AI Rotation
                        </TabsTrigger>
                        <TabsTrigger value="workload" className="flex items-center gap-2">
                            <Activity className="w-4 h-4" />
                            Workload
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="depth">
                        <SquadDepthChart />
                    </TabsContent>

                    <TabsContent value="fixtures">
                        <FixtureCongestSimulator />
                    </TabsContent>

                    <TabsContent value="ai">
                        <AIRotationSuggester />
                    </TabsContent>

                    <TabsContent value="workload">
                        <WorkloadTracker />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}