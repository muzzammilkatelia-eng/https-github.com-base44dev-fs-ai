import React from 'react';
import SafeguardingMonitor from '../components/safeguarding/SafeguardingMonitor';
import PayPalSupport from '../components/safeguarding/PayPalSupport';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Shield, AlertTriangle, Users, Lock, FileCheck, Target, Brain, Eye, Scale, UserCheck, Award, Code, Database } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function Safeguarding() {
    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="mb-8 text-center">
                    <Badge className="bg-green-500/20 text-green-400 mb-4">Version 1.0 — Institutional Standard</Badge>
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent mb-3">
                        🛡️ Safeguarding Charter
                    </h1>
                    <h2 className="text-2xl text-white mb-2">Football Scout AI</h2>
                    <p className="text-slate-400 max-w-2xl mx-auto">
                        Sector-ready, regulator-ready framework for protecting players, respecting journeys, and upholding scouting integrity
                    </p>
                    <div className="mt-4 text-slate-500 text-sm">
                        <p><strong>Founder:</strong> Muzzammil Katelia</p>
                        <p className="italic mt-1">"AI was meant for neurodiverse minds."</p>
                    </div>
                </div>

                {/* CODE OF HONOUR TECHNICAL STATUS */}
                <Card className="bg-slate-950 border-cyan-500/30 mb-8 overflow-hidden relative">
                    <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500"></div>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-white flex items-center gap-2 text-lg">
                            <Code className="w-5 h-5 text-cyan-400" />
                            System Safeguards: <span className="text-green-400">Active</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">
                            The <strong>Code of Honour</strong> protocol is hard-coded into the platform's backend kernel.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                            <div className="bg-slate-900 rounded p-3 border border-slate-800 flex items-start gap-3">
                                <Database className="w-4 h-4 text-slate-500 mt-1" />
                                <div>
                                    <h4 className="text-white text-xs font-semibold uppercase tracking-wider">Stateless Processing</h4>
                                    <p className="text-xs text-slate-400">Sensitive contexts are processed in-memory only. No persistence without audit.</p>
                                </div>
                            </div>
                            <div className="bg-slate-900 rounded p-3 border border-slate-800 flex items-start gap-3">
                                <Shield className="w-4 h-4 text-slate-500 mt-1" />
                                <div>
                                    <h4 className="text-white text-xs font-semibold uppercase tracking-wider">Auto-Redaction</h4>
                                    <p className="text-xs text-slate-400">PII fields (Names, Addresses) are automatically stripped before model inference.</p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Section 1: Purpose */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-green-400" />
                            1. Purpose of This Charter
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p>
                            Football Scout AI is built on a safeguarding‑first mission. This charter sets out the standards, 
                            responsibilities, and expectations for everyone who uses, develops, or partners with the platform. 
                            It ensures that every decision — technical or human — protects players, respects their journeys, 
                            and upholds the integrity of the scouting profession.
                        </p>
                    </CardContent>
                </Card>

                {/* Section 2: Core Principles */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <FileCheck className="w-5 h-5 text-cyan-400" />
                            2. Core Principles
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-5">
                        <div>
                            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <Shield className="w-4 h-4 text-green-400" />
                                2.1 Duty of Care
                            </h3>
                            <p className="text-sm mb-2">
                                Every user and developer must act in the best interests of players, especially minors and vulnerable individuals.
                            </p>
                            <p className="text-sm text-slate-400">This includes:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4 mt-1">
                                <li>Respecting welfare and wellbeing</li>
                                <li>Avoiding harmful language or assumptions</li>
                                <li>Ensuring all interactions are professional and appropriate</li>
                            </ul>
                        </div>

                        <div>
                            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <Scale className="w-4 h-4 text-purple-400" />
                                2.2 Fairness & Anti‑Bias
                            </h3>
                            <p className="text-sm mb-2">
                                Scouting decisions must be free from discrimination or prejudice.
                            </p>
                            <p className="text-sm text-slate-400">The system reinforces:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4 mt-1">
                                <li>Transparent criteria</li>
                                <li>Consistent profiling</li>
                                <li>Awareness of unconscious bias</li>
                                <li>Equal opportunities regardless of background, ethnicity, or socioeconomic status</li>
                            </ul>
                        </div>

                        <div>
                            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <Eye className="w-4 h-4 text-blue-400" />
                                2.3 Transparency
                            </h3>
                            <p className="text-sm mb-2">
                                All workflows, reports, and AI‑assisted outputs must be:
                            </p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                                <li>Auditable</li>
                                <li>Explainable</li>
                                <li>Free from hidden logic</li>
                            </ul>
                            <p className="text-sm text-cyan-400 mt-2 italic">AI is an assistant, not a black box.</p>
                        </div>

                        <div>
                            <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                                <UserCheck className="w-4 h-4 text-amber-400" />
                                2.4 Accountability
                            </h3>
                            <p className="text-sm mb-2 text-slate-400">Users are responsible for:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4 mb-3">
                                <li>The accuracy of their observations</li>
                                <li>The ethical use of data</li>
                                <li>The impact of their reports on players' futures</li>
                            </ul>
                            <p className="text-sm mb-2 text-slate-400">Developers are responsible for:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                                <li>Maintaining safe, transparent systems</li>
                                <li>Ensuring no feature undermines safeguarding principles</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                {/* Section 3: Ethical Use of AI */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Brain className="w-5 h-5 text-purple-400" />
                            3. Ethical Use of AI
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">
                            Football Scout AI uses artificial intelligence to <strong>support</strong>, not replace, human judgment.
                        </p>
                        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                            <p className="text-red-400 font-semibold text-sm mb-2">The platform must never:</p>
                            <ul className="text-sm text-slate-300 space-y-1 list-disc list-inside ml-2">
                                <li>Make autonomous decisions about a player's future</li>
                                <li>Rank or label players without human oversight</li>
                                <li>Encourage shortcuts that bypass ethical reflection</li>
                            </ul>
                        </div>
                        <p className="text-sm text-cyan-400 italic">
                            AI is a tool for structure, clarity, and consistency — not authority.
                        </p>
                    </CardContent>
                </Card>

                {/* Section 4: Data Protection */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Lock className="w-5 h-5 text-blue-400" />
                            4. Data Protection & Privacy
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">All data collected through the platform must be:</p>
                        <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                            <li>Stored securely</li>
                            <li>Used only for legitimate scouting purposes</li>
                            <li>Protected from misuse or unauthorised access</li>
                        </ul>
                        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mt-3">
                            <p className="text-amber-400 font-semibold text-sm">
                                Player data is personal data. It must be treated with the highest level of respect.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                {/* Section 5: Safeguarding in Practice */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Users className="w-5 h-5 text-green-400" />
                            5. Safeguarding in Practice
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-4">
                        <div>
                            <h3 className="text-white font-semibold mb-2 text-sm">5.1 When Scouting Live or via Video</h3>
                            <p className="text-sm text-slate-400 mb-1">Scouts must:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                                <li>Maintain professional boundaries</li>
                                <li>Avoid direct contact with minors</li>
                                <li>Report concerns through appropriate safeguarding channels</li>
                            </ul>
                        </div>

                        <div>
                            <h3 className="text-white font-semibold mb-2 text-sm">5.2 When Writing Reports</h3>
                            <p className="text-sm text-slate-400 mb-1">Reports must:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                                <li>Focus on footballing attributes</li>
                                <li>Avoid personal judgments</li>
                                <li>Never include derogatory or harmful language</li>
                            </ul>
                        </div>

                        <div>
                            <h3 className="text-white font-semibold mb-2 text-sm">5.3 When Using the App</h3>
                            <p className="text-sm text-slate-400 mb-1">Users must:</p>
                            <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                                <li>Log events truthfully</li>
                                <li>Avoid speculative or harmful commentary</li>
                                <li>Follow club and national safeguarding policies</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                {/* Section 6: Clubs & Partners */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Award className="w-5 h-5 text-cyan-400" />
                            6. Responsibilities of Clubs & Partners
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">Any organisation using Football Scout AI must:</p>
                        <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                            <li>Provide safeguarding training</li>
                            <li>Appoint a safeguarding lead</li>
                            <li>Ensure all scouts are vetted and compliant</li>
                            <li>Integrate this charter into their internal policies</li>
                        </ul>
                    </CardContent>
                </Card>

                {/* Section 7: Developers */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Brain className="w-5 h-5 text-purple-400" />
                            7. Responsibilities of Developers & Contributors
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">Anyone extending or modifying the codebase must:</p>
                        <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                            <li>Preserve transparency</li>
                            <li>Avoid introducing features that could harm players</li>
                            <li>Document all changes</li>
                            <li>Uphold the safeguarding‑first mission</li>
                        </ul>
                        <p className="text-sm text-slate-500 italic mt-2">
                            This applies to internal teams, external partners, and open‑source contributors.
                        </p>
                    </CardContent>
                </Card>

                {/* Section 8: Reporting */}
                <Card className="bg-amber-500/10 border-amber-500/30 mb-6">
                    <CardHeader>
                        <CardTitle className="text-amber-400 flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5" />
                            8. Reporting Concerns
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">
                            Any safeguarding concern — technical or human — must be escalated immediately through the 
                            appropriate safeguarding authority within the user's organisation.
                        </p>
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <p className="text-white font-semibold mb-2">Safeguarding Contact:</p>
                            <p className="text-slate-400 text-sm">Email: safeguarding@minimax-sustainable-ai.com</p>
                            <p className="text-slate-500 text-xs mt-3">
                                Football Scout AI will always cooperate with safeguarding investigations.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                {/* Section 9: Continuous Improvement */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-green-400" />
                            9. Commitment to Continuous Improvement
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300 space-y-3">
                        <p className="text-sm">Safeguarding is not static.</p>
                        <p className="text-sm">This charter will be reviewed regularly to:</p>
                        <ul className="text-sm text-slate-400 space-y-1 list-disc list-inside ml-4">
                            <li>Reflect new research</li>
                            <li>Respond to emerging risks</li>
                            <li>Strengthen protections for players</li>
                        </ul>
                    </CardContent>
                </Card>

                {/* Section 10: Founder's Statement */}
                <Card className="bg-gradient-to-br from-green-500/20 via-cyan-500/20 to-blue-500/20 border-green-500/30 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-5 h-5 text-green-400" />
                            10. Founder's Statement
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <blockquote className="border-l-4 border-green-400 pl-4 italic text-slate-300">
                            <p className="text-base mb-3">
                                "Football Scout AI exists to protect players, empower scouts, and raise standards across the game.
                            </p>
                            <p className="text-base">
                                Technology must never compromise safeguarding — it must reinforce it."
                            </p>
                            <footer className="text-green-400 font-semibold mt-3 not-italic">
                                — Muzzammil Katelia, Founder
                            </footer>
                        </blockquote>
                    </CardContent>
                </Card>

                {/* Section 11: Support Our Mission */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Award className="w-5 h-5 text-purple-400" />
                            11. Support Our Mission
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-slate-300">
                        <p className="text-sm mb-4">
                            Football Scout AI is committed to maintaining high standards of safeguarding and integrity.
                            Your support helps us continue to develop ethical AI tools for the football community.
                        </p>
                        <PayPalSupport amount={10} tags={['safeguarding_charter_support']} />
                    </CardContent>
                </Card>

                {/* Live Safeguarding Monitor */}
                <SafeguardingMonitor />
            </div>
        </div>
    );
}