import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Award, CheckCircle } from 'lucide-react';

export default function SafeguardingBadge() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-4xl mx-auto">
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white text-3xl flex items-center gap-3">
                            <Shield className="w-8 h-8 text-amber-400" />
                            Safeguarding Excellence Badge
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-8">
                        {/* Badge Display */}
                        <div className="flex justify-center">
                            <img 
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/81b495cce_CreateaSafeguardingBadgeAwardsimilartothed.pdf"
                                alt="Al-Isa Institute Safeguarding Badge"
                                className="w-80 h-80 object-contain"
                            />
                        </div>

                        {/* Badge Information */}
                        <div className="bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border border-amber-500/30 rounded-lg p-6">
                            <h2 className="text-white text-xl font-semibold mb-4 flex items-center gap-2">
                                <Award className="w-6 h-6 text-amber-400" />
                                Al-Isa Institute Safeguarding Certification
                            </h2>
                            <div className="space-y-3 text-slate-300">
                                <div className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5" />
                                    <div>
                                        <p className="font-semibold text-white">Safety First</p>
                                        <p className="text-sm">Comprehensive safeguarding protocols ensuring child and vulnerable adult protection</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5" />
                                    <div>
                                        <p className="font-semibold text-white">Protection Standards</p>
                                        <p className="text-sm">DBS-cleared staff, mandatory training, and continuous monitoring</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5" />
                                    <div>
                                        <p className="font-semibold text-white">Wellbeing Focus</p>
                                        <p className="text-sm">Mental health support, ethical AI practices, and duty of care commitments</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* FS-AI Compliance */}
                        <div className="bg-slate-800/50 rounded-lg p-6">
                            <h3 className="text-white text-lg font-semibold mb-3">FS-AI Safeguarding Commitment</h3>
                            <p className="text-slate-300 mb-4">
                                FS-AI is proud to uphold the Al-Isa Institute's safeguarding standards. Our platform is built with:
                            </p>
                            <div className="grid md:grid-cols-2 gap-3">
                                <Badge className="bg-emerald-500/20 text-emerald-400 justify-center py-2">
                                    ✓ DBS-Cleared Personnel
                                </Badge>
                                <Badge className="bg-emerald-500/20 text-emerald-400 justify-center py-2">
                                    ✓ Safeguarding Training
                                </Badge>
                                <Badge className="bg-emerald-500/20 text-emerald-400 justify-center py-2">
                                    ✓ Child Protection Protocols
                                </Badge>
                                <Badge className="bg-emerald-500/20 text-emerald-400 justify-center py-2">
                                    ✓ Ethical AI Governance
                                </Badge>
                            </div>
                        </div>

                        {/* Contact Information */}
                        <div className="border-t border-slate-800 pt-6">
                            <p className="text-slate-400 text-sm text-center">
                                For safeguarding concerns or inquiries, contact: 
                                <a href="mailto:safeguarding@minimax-sustainable-ai.com" className="text-cyan-400 hover:text-cyan-300 ml-2">
                                    safeguarding@minimax-sustainable-ai.com
                                </a>
                            </p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}