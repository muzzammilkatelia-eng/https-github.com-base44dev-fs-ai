import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Loader2, CheckCircle2, AlertCircle, TrendingUp, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import ExportButton from '../components/ExportButton';

export default function Sales() {
    const [showAddForm, setShowAddForm] = useState(false);
    const [formData, setFormData] = useState({
        product_type: 'Club Basic',
        customer_name: '',
        customer_email: '',
        amount: '',
        subscription_period: 'monthly',
        status: 'pending',
        notes: ''
    });

    const queryClient = useQueryClient();

    const { data: sales = [], isLoading } = useQuery({
        queryKey: ['sales'],
        queryFn: () => base44.entities.Sale.list('-created_date', 50)
    });

    const addSaleMutation = useMutation({
        mutationFn: async (saleData) => {
            const sale = await base44.entities.Sale.create(saleData);
            
            // Send Slack notification
            try {
                const result = await base44.functions.invoke('notifySaleInSlack', { saleId: sale.id });
                if (result.data.success) {
                    toast.success('Sale recorded and Slack notified!');
                } else {
                    toast.error(result.data.error || 'Slack notification failed');
                }
            } catch (error) {
                toast.error('Slack notification failed: ' + error.message);
            }
            
            return sale;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['sales'] });
            setShowAddForm(false);
            setFormData({
                product_type: 'Club Basic',
                customer_name: '',
                customer_email: '',
                amount: '',
                subscription_period: 'monthly',
                status: 'pending',
                notes: ''
            });
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        addSaleMutation.mutate({
            ...formData,
            amount: parseFloat(formData.amount)
        });
    };

    const totalRevenue = sales.reduce((sum, sale) => 
        sale.status === 'completed' ? sum + sale.amount : sum, 0
    );

    const statusColors = {
        pending: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
        completed: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        failed: 'bg-red-500/20 text-red-400 border-red-500/30',
        refunded: 'bg-slate-500/20 text-slate-400 border-slate-500/30'
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                            Sales Dashboard
                        </h1>
                        <p className="text-slate-400">Track and manage your subscription sales</p>
                    </div>
                    <div className="flex gap-3">
                        <ExportButton 
                            entityType="Sale" 
                            title="FS-AI Sales Data"
                            label="Export"
                            variant="outline"
                        />
                        <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
                        <DialogTrigger asChild>
                            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500">
                                <Plus className="w-4 h-4 mr-2" />
                                Record Sale
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-slate-900 border-slate-800 text-white">
                            <DialogHeader>
                                <DialogTitle>Record New Sale</DialogTitle>
                            </DialogHeader>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <Label>Product Type</Label>
                                    <Select value={formData.product_type} onValueChange={(v) => setFormData({...formData, product_type: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Club Basic">Club Basic (£199/mo)</SelectItem>
                                            <SelectItem value="Club Pro">Club Pro (£499/mo)</SelectItem>
                                            <SelectItem value="Elite Club">Elite Club (£999/mo)</SelectItem>
                                            <SelectItem value="Federation Tier">Federation Tier</SelectItem>
                                            <SelectItem value="Academy Pro">Academy Pro (£25/mo)</SelectItem>
                                            <SelectItem value="Verified Academy">Verified Academy (£5/mo)</SelectItem>
                                            <SelectItem value="Education Plan">Education Plan (£10/mo)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div>
                                    <Label>Customer Name</Label>
                                    <Input
                                        value={formData.customer_name}
                                        onChange={(e) => setFormData({...formData, customer_name: e.target.value})}
                                        className="bg-slate-800 border-slate-700"
                                        placeholder="Club or organization name"
                                    />
                                </div>

                                <div>
                                    <Label>Customer Email *</Label>
                                    <Input
                                        type="email"
                                        required
                                        value={formData.customer_email}
                                        onChange={(e) => setFormData({...formData, customer_email: e.target.value})}
                                        className="bg-slate-800 border-slate-700"
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <Label>Amount (£) *</Label>
                                        <Input
                                            type="number"
                                            required
                                            value={formData.amount}
                                            onChange={(e) => setFormData({...formData, amount: e.target.value})}
                                            className="bg-slate-800 border-slate-700"
                                        />
                                    </div>
                                    <div>
                                        <Label>Period</Label>
                                        <Select value={formData.subscription_period} onValueChange={(v) => setFormData({...formData, subscription_period: v})}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="monthly">Monthly</SelectItem>
                                                <SelectItem value="annual">Annual</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div>
                                    <Label>Status</Label>
                                    <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v})}>
                                        <SelectTrigger className="bg-slate-800 border-slate-700">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="pending">Pending</SelectItem>
                                            <SelectItem value="completed">Completed</SelectItem>
                                            <SelectItem value="failed">Failed</SelectItem>
                                            <SelectItem value="refunded">Refunded</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div>
                                    <Label>Notes</Label>
                                    <Textarea
                                        value={formData.notes}
                                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                                        className="bg-slate-800 border-slate-700"
                                        rows={3}
                                    />
                                </div>

                                <Button type="submit" disabled={addSaleMutation.isPending} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600">
                                    {addSaleMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                    Record Sale & Notify Slack
                                </Button>
                            </form>
                        </DialogContent>
                    </Dialog>
                    </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Sales</p>
                                    <p className="text-3xl font-bold text-white">{sales.length}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Revenue</p>
                                    <p className="text-3xl font-bold text-emerald-400">£{totalRevenue.toFixed(2)}</p>
                                </div>
                                <DollarSign className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Completed</p>
                                    <p className="text-3xl font-bold text-white">
                                        {sales.filter(s => s.status === 'completed').length}
                                    </p>
                                </div>
                                <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Pending</p>
                                    <p className="text-3xl font-bold text-white">
                                        {sales.filter(s => s.status === 'pending').length}
                                    </p>
                                </div>
                                <AlertCircle className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Sales List */}
                <Card className="bg-slate-900/50 border-slate-800">
                    <CardHeader>
                        <CardTitle className="text-white">Recent Sales</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isLoading ? (
                            <div className="text-center py-12">
                                <Loader2 className="w-8 h-8 animate-spin text-cyan-400 mx-auto" />
                            </div>
                        ) : sales.length === 0 ? (
                            <div className="text-center py-12">
                                <p className="text-slate-400">No sales recorded yet</p>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {sales.map((sale) => (
                                    <motion.div
                                        key={sale.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                                    >
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h4 className="text-white font-semibold">{sale.customer_name || sale.customer_email}</h4>
                                                    <Badge className={statusColors[sale.status]}>
                                                        {sale.status}
                                                    </Badge>
                                                    {sale.slack_notified && (
                                                        <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                                                            Slack ✓
                                                        </Badge>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-4 text-sm text-slate-400">
                                                    <span>{sale.product_type}</span>
                                                    <span>•</span>
                                                    <span>£{sale.amount}</span>
                                                    <span>•</span>
                                                    <span>{sale.subscription_period}</span>
                                                    <span>•</span>
                                                    <span>{new Date(sale.created_date).toLocaleDateString()}</span>
                                                </div>
                                                {sale.notes && (
                                                    <p className="text-slate-500 text-sm mt-2">{sale.notes}</p>
                                                )}
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Setup Instructions */}
                <Card className="bg-blue-500/10 border-blue-500/30 mt-8">
                    <CardContent className="pt-6">
                        <h3 className="text-blue-400 font-semibold mb-2">Slack Notifications Enabled</h3>
                        <p className="text-slate-300 text-sm">
                            Sales are automatically posted to your Slack channel via webhook. Each sale will include customer details, amount, product type, and status.
                        </p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}