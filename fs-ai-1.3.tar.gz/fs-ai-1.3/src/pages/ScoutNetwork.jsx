import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network, Target, FileText, Users, Activity, MessageSquare } from 'lucide-react';
import NetworkManager from '../components/scout-network/NetworkManager';
import TargetAssignment from '../components/scout-network/TargetAssignment';
import FindingsManager from '../components/scout-network/FindingsManager';
import ScoutAssignment from '../components/scout-network/ScoutAssignment';
import AIScoutAgent from '../components/scout-network/AIScoutAgent';
import TeamChat from '../components/scout-network/TeamChat';
import ScoutDirectory from '../components/scout-network/ScoutDirectory';
import AIScoutAssigner from '../components/scout-network/AIScoutAssigner';
import AIMissionGenerator from '../components/scout-network/AIMissionGenerator';
import AIReportAnalyzer from '../components/scout-network/AIReportAnalyzer';
import ScoutPerformanceTracker from '../components/scout-network/ScoutPerformanceTracker';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function ScoutNetwork() {
    const [selectedNetwork, setSelectedNetwork] = useState(null);

    const { data: networks = [] } = useQuery({
        queryKey: ['scout-networks'],
        queryFn: () => base44.entities.ScoutNetwork.list('-created_date', 100)
    });

    const { data: scouts = [] } = useQuery({
        queryKey: ['scouts'],
        queryFn: () => base44.entities.Scout.list()
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['scout-findings'],
        queryFn: () => base44.entities.ScoutFinding.list('-created_date', 100)
    });

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 10000)
    });

    const totalFindings = findings.length;
    const newFindings = findings.filter(f => f.status === 'New').length;
    const activeNetworks = networks.filter(n => n.status === 'Active').length;

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Network className="w-8 h-8 text-cyan-400" />
                        Global Scouting Network
                        <HelpTooltip content="Create networks of scouts to monitor specific regions, positions, or players. Scouts report findings that automatically integrate with your AI Scout and Dashboard." />
                    </h1>
                    <p className="text-slate-400">
                        Manage scout networks, assign targets, and review findings
                    </p>
                </div>

                {/* Stats */}
                <div className="grid md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Networks</p>
                                    <p className="text-4xl font-bold text-white">{activeNetworks}</p>
                                </div>
                                <Network className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Scouts</p>
                                    <p className="text-4xl font-bold text-white">{scouts.filter(s => s.status === 'Active').length}</p>
                                </div>
                                <Users className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">New Findings</p>
                                    <p className="text-4xl font-bold text-white">{newFindings}</p>
                                </div>
                                <FileText className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Findings</p>
                                    <p className="text-4xl font-bold text-white">{totalFindings}</p>
                                </div>
                                <Activity className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Network Selection / Creation */}
                {!selectedNetwork ? (
                    <Tabs defaultValue="networks" className="space-y-6">
                        <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-2">
                            <TabsTrigger value="networks">Networks</TabsTrigger>
                            <TabsTrigger value="directory">Scout Directory</TabsTrigger>
                        </TabsList>

                        <TabsContent value="networks">
                            <NetworkManager onNetworkSelect={setSelectedNetwork} />
                        </TabsContent>

                        <TabsContent value="directory">
                            <ScoutDirectory />
                        </TabsContent>
                    </Tabs>
                ) : (
                    <div className="space-y-6">
                        <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-2xl font-bold text-white mb-1">
                                            {selectedNetwork.network_name}
                                        </h2>
                                        <p className="text-slate-400">{selectedNetwork.description}</p>
                                    </div>
                                    <Button
                                        onClick={() => setSelectedNetwork(null)}
                                        variant="outline"
                                        className="border-slate-700"
                                    >
                                        Back to Networks
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        <Tabs defaultValue="ai-agent" className="space-y-6">
                            <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-3 lg:grid-cols-9 gap-1">
                                <TabsTrigger value="ai-agent">AI Agent</TabsTrigger>
                                <TabsTrigger value="findings">Findings</TabsTrigger>
                                <TabsTrigger value="targets">Targets</TabsTrigger>
                                <TabsTrigger value="chat">Chat</TabsTrigger>
                                <TabsTrigger value="submit">Submit</TabsTrigger>
                                <TabsTrigger value="ai-assign">AI Assign</TabsTrigger>
                                <TabsTrigger value="missions">Missions</TabsTrigger>
                                <TabsTrigger value="analyze">Analyze</TabsTrigger>
                                <TabsTrigger value="performance">Performance</TabsTrigger>
                            </TabsList>

                            <TabsContent value="ai-agent">
                                <AIScoutAgent network={selectedNetwork} players={players} />
                            </TabsContent>

                            <TabsContent value="findings">
                                <FindingsManager network={selectedNetwork} />
                            </TabsContent>

                            <TabsContent value="targets">
                                <TargetAssignment network={selectedNetwork} />
                            </TabsContent>

                            <TabsContent value="chat">
                                <TeamChat network={selectedNetwork} />
                            </TabsContent>

                            <TabsContent value="submit">
                                <ScoutAssignment network={selectedNetwork} scouts={scouts} />
                            </TabsContent>

                            <TabsContent value="ai-assign">
                                <AIScoutAssigner networkId={selectedNetwork.id} />
                            </TabsContent>

                            <TabsContent value="missions">
                                <AIMissionGenerator />
                            </TabsContent>

                            <TabsContent value="analyze">
                                <AIReportAnalyzer />
                            </TabsContent>

                            <TabsContent value="performance">
                                <ScoutPerformanceTracker />
                            </TabsContent>
                        </Tabs>
                    </div>
                )}
            </div>
        </div>
    );
}