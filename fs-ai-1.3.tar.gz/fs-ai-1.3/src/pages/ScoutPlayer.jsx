import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import ModuleCard from "../components/scouting/ModuleCard";
import MetricDisplay from "../components/scouting/MetricDisplay";
import AIAssistant from "../components/scouting/AIAssistant";
import { Sparkles, TrendingUp, Target, Users, FileText, Loader2, CheckCircle2, Upload, BarChart3, Activity } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import toast from "react-hot-toast";
import PlayerBenchmarking from "../components/scouting/PlayerBenchmarking";
import ModuleRadarChart from "../components/scouting/ModuleRadarChart";

export default function ScoutPlayer() {
    const [playerData, setPlayerData] = useState({
        name: "",
        age: "",
        position: "",
        current_club: "",
        league: "",
        nationality: ""
    });

    const [activeModules, setActiveModules] = useState({
        calafat: false,
        brighton: false,
        portuguese: false,
        dortmund: false,
        ajax: false
    });

    const [analysisResult, setAnalysisResult] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [saved, setSaved] = useState(false);
    const [isExporting, setIsExporting] = useState(false);

    const queryClient = useQueryClient();

    const { data: existingReports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 20),
    });

    const handlePlayerSelect = (suggestedPlayer) => {
        setPlayerData({
            name: suggestedPlayer.name,
            age: suggestedPlayer.age.toString(),
            position: suggestedPlayer.position,
            current_club: suggestedPlayer.current_club || "",
            league: suggestedPlayer.league || "",
            nationality: suggestedPlayer.nationality || ""
        });
        
        // Auto-select relevant modules based on suggestion context
        setActiveModules({
            calafat: true,
            brighton: true,
            portuguese: false,
            dortmund: suggestedPlayer.age < 21,
            ajax: true
        });
    };

    const modules = [
        {
            id: "calafat",
            title: "Calafat Mode",
            description: "Elite talent identifier",
            icon: Sparkles,
            color: "from-purple-500 to-pink-600"
        },
        {
            id: "brighton",
            title: "Brighton Mode",
            description: "Market inefficiency engine",
            icon: TrendingUp,
            color: "from-cyan-500 to-blue-600"
        },
        {
            id: "portuguese",
            title: "Portuguese Pipeline",
            description: "Flip & pathway engine",
            icon: Target,
            color: "from-emerald-500 to-teal-600"
        },
        {
            id: "dortmund",
            title: "Dortmund Mode",
            description: "Youth acceleration engine",
            icon: Users,
            color: "from-amber-500 to-orange-600"
        },
        {
            id: "ajax",
            title: "Ajax Mode",
            description: "Technical DNA assessment",
            icon: FileText,
            color: "from-red-500 to-rose-600"
        }
    ];

    const toggleModule = (moduleId) => {
        setActiveModules(prev => ({ ...prev, [moduleId]: !prev[moduleId] }));
    };

    const handleAnalyze = async () => {
        if (!playerData.name || !playerData.age || !playerData.position) {
            return;
        }

        const selectedModules = Object.keys(activeModules).filter(key => activeModules[key]);
        if (selectedModules.length === 0) {
            return;
        }

        setIsAnalyzing(true);
        setSaved(false);

        // Fetch live player data first
        let livePlayerData = null;
        try {
            const dataResult = await base44.functions.fetchPlayerData({
                playerName: playerData.name,
                position: playerData.position,
                age: parseInt(playerData.age),
                includeMarketValue: true,
                includePerformance: true
            });
            
            if (dataResult.success) {
                livePlayerData = dataResult.data;
            }
        } catch (error) {
            console.log('Live data fetch failed, continuing with base analysis');
        }

        // Build comprehensive prompt with live data
        const liveDataContext = livePlayerData ? `
        
LIVE PLAYER DATA FROM TRANSFERMARKT & SOURCES:
- Current Market Value: €${livePlayerData.market_value}M
- Current Club: ${livePlayerData.current_club}
- League: ${livePlayerData.league}
- Contract Expiry: ${livePlayerData.contract_expiry}
- Season Stats: ${livePlayerData.current_season_stats?.appearances} apps, ${livePlayerData.current_season_stats?.goals || 0} goals, ${livePlayerData.current_season_stats?.assists || 0} assists
- Average Rating: ${livePlayerData.current_season_stats?.average_rating || 'N/A'}
- Market Trend: ${livePlayerData.market_trend}
- Transfer Interest: ${livePlayerData.transfer_interest}
- Recent Form: ${livePlayerData.advanced_metrics?.recent_form}

Use this REAL data to inform your analysis.` : '';

        const moduleDescriptions = {
            calafat: "Analyze as Elite Talent Identifier: technical explosiveness, ball-carrying, decision-making, long-term ceiling (5-7 years). Output ceiling_score (0-100), risk_score (0-100), development_curve.",
            brighton: "Analyze as Market Inefficiency Engine: undervalued potential, statistical anomalies, breakout probability. Output hidden_gem_score (0-100), market_value_trajectory, roi_score (0-100).",
            portuguese: "Analyze as Flip & Pathway Engine: South American adaptability, resale potential, tactical versatility. Output flip_potential (0-100), adaptation_score (0-100), versatility_index (0-100).",
            dortmund: "Analyze as Youth Acceleration Engine: readiness for senior football, psychological resilience, risk vs reward. Output readiness_score (0-100), acceleration_curve, resilience_index (0-100).",
            ajax: "Analyze as Technical DNA & Academy Fit: technical fundamentals, positional intelligence, system compatibility. Output technical_purity (0-100), positional_iq (0-100), academy_fit (0-100)."
        };

        const activePrompts = selectedModules.map(m => moduleDescriptions[m]).join("\n\n");

        const prompt = `You are FS-AI, an elite football scouting system with access to real-time data. Analyze this player using the selected modules:

        Player: ${playerData.name}
        Age: ${playerData.age}
        Position: ${playerData.position}
        Club: ${playerData.current_club || "Unknown"}
        League: ${playerData.league || "Unknown"}
        Nationality: ${playerData.nationality || "Unknown"}
        ${liveDataContext}

        ACTIVATED MODULES:
        ${activePrompts}

Provide a comprehensive scouting analysis. For each activated module, give realistic scores and assessments based on typical player profiles for that age, position, and league context.

Finally, provide:
- Overall Verdict (2-3 sentences summarizing ceiling, value, risk, pathway)
- Recommendation (Strong Recommend / Recommend / Monitor / Pass)
- Additional Notes (key strengths, concerns, tactical fit considerations)`;

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        calafat_analysis: selectedModules.includes("calafat") ? {
                            type: "object",
                            properties: {
                                ceiling_score: { type: "number" },
                                risk_score: { type: "number" },
                                development_curve: { type: "string" }
                            }
                        } : { type: "null" },
                        brighton_analysis: selectedModules.includes("brighton") ? {
                            type: "object",
                            properties: {
                                hidden_gem_score: { type: "number" },
                                market_value_trajectory: { type: "string" },
                                roi_score: { type: "number" }
                            }
                        } : { type: "null" },
                        portuguese_analysis: selectedModules.includes("portuguese") ? {
                            type: "object",
                            properties: {
                                flip_potential: { type: "number" },
                                adaptation_score: { type: "number" },
                                versatility_index: { type: "number" }
                            }
                        } : { type: "null" },
                        dortmund_analysis: selectedModules.includes("dortmund") ? {
                            type: "object",
                            properties: {
                                readiness_score: { type: "number" },
                                acceleration_curve: { type: "string" },
                                resilience_index: { type: "number" }
                            }
                        } : { type: "null" },
                        ajax_analysis: selectedModules.includes("ajax") ? {
                            type: "object",
                            properties: {
                                technical_purity: { type: "number" },
                                positional_iq: { type: "number" },
                                academy_fit: { type: "number" }
                            }
                        } : { type: "null" },
                        overall_verdict: { type: "string" },
                        recommendation: { 
                            type: "string",
                            enum: ["Strong Recommend", "Recommend", "Monitor", "Pass"]
                        },
                        notes: { type: "string" }
                    }
                }
            });

            // Attach live data to result if available
            const enrichedResult = {
                ...response,
                live_data: livePlayerData
            };
            setAnalysisResult(enrichedResult);
            } catch (error) {
            console.error("Analysis failed:", error);
            } finally {
            setIsAnalyzing(false);
            }
    };

    const saveReportMutation = useMutation({
        mutationFn: (reportData) => base44.entities.ScoutingReport.create(reportData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['reports'] });
            setSaved(true);
            setTimeout(() => setSaved(false), 3000);
        },
    });

    const handleSaveReport = async () => {
        if (!analysisResult) return;

        const reportData = {
            player_name: playerData.name,
            player_age: parseInt(playerData.age),
            position: playerData.position,
            modules_activated: Object.keys(activeModules).filter(key => activeModules[key]),
            calafat_analysis: analysisResult.calafat_analysis,
            brighton_analysis: analysisResult.brighton_analysis,
            portuguese_analysis: analysisResult.portuguese_analysis,
            dortmund_analysis: analysisResult.dortmund_analysis,
            ajax_analysis: analysisResult.ajax_analysis,
            overall_verdict: analysisResult.overall_verdict,
            recommendation: analysisResult.recommendation,
            notes: analysisResult.notes
        };

        saveReportMutation.mutate(reportData);

        // Trigger alert check
        try {
            await base44.functions.checkAndTriggerAlerts({
                playerData: {
                    name: playerData.name,
                    age: parseInt(playerData.age),
                    position: playerData.position,
                    recommendation: analysisResult.recommendation
                },
                dataType: 'scouting_report'
            });
        } catch (error) {
            console.log('Alert check skipped:', error);
        }
    };

    const handleExportToDrive = async () => {
        if (!analysisResult) return;

        setIsExporting(true);

        const reportData = {
            player_name: playerData.name,
            player_age: parseInt(playerData.age),
            position: playerData.position,
            modules_activated: Object.keys(activeModules).filter(key => activeModules[key]),
            calafat_analysis: analysisResult.calafat_analysis,
            brighton_analysis: analysisResult.brighton_analysis,
            portuguese_analysis: analysisResult.portuguese_analysis,
            dortmund_analysis: analysisResult.dortmund_analysis,
            ajax_analysis: analysisResult.ajax_analysis,
            overall_verdict: analysisResult.overall_verdict,
            recommendation: analysisResult.recommendation,
            notes: analysisResult.notes,
            created_date: new Date().toISOString()
        };

        try {
            const result = await base44.functions.exportToGoogleDrive({
                reportData: reportData
            });

            if (result.success) {
                toast.success("Report exported to Google Drive!");
                window.open(result.documentUrl, '_blank');
            } else {
                if (result.error?.includes("not connected")) {
                    toast.error("Please authorize Google Drive access first");
                } else {
                    toast.error(result.error || "Export failed");
                }
            }
        } catch (error) {
            console.error("Export error:", error);
            toast.error("Failed to export. Ensure backend functions are enabled.");
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-12">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-3">
                        Scout Player
                    </h1>
                    <p className="text-slate-400">Analyze players using multi-archetype intelligence</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left Column - AI Assistant & Player Input */}
                    <div className="lg:col-span-1 space-y-6">
                        <AIAssistant 
                            onPlayerSelect={handlePlayerSelect}
                            existingReports={existingReports}
                        />
                        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Player Details</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <Label className="text-slate-400">Player Name *</Label>
                                    <Input
                                        value={playerData.name}
                                        onChange={(e) => setPlayerData({...playerData, name: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                        placeholder="e.g. Lionel Messi"
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <Label className="text-slate-400">Age *</Label>
                                        <Input
                                            type="number"
                                            value={playerData.age}
                                            onChange={(e) => setPlayerData({...playerData, age: e.target.value})}
                                            className="bg-slate-800 border-slate-700 text-white mt-1"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-slate-400">Position *</Label>
                                        <Select value={playerData.position} onValueChange={(value) => setPlayerData({...playerData, position: value})}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Striker">Striker</SelectItem>
                                                <SelectItem value="Winger">Winger</SelectItem>
                                                <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                                <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                                <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                                <SelectItem value="Full-Back">Full-Back</SelectItem>
                                                <SelectItem value="Centre-Back">Centre-Back</SelectItem>
                                                <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div>
                                    <Label className="text-slate-400">Current Club</Label>
                                    <Input
                                        value={playerData.current_club}
                                        onChange={(e) => setPlayerData({...playerData, current_club: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400">League</Label>
                                    <Input
                                        value={playerData.league}
                                        onChange={(e) => setPlayerData({...playerData, league: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>

                                <div>
                                    <Label className="text-slate-400">Nationality</Label>
                                    <Input
                                        value={playerData.nationality}
                                        onChange={(e) => setPlayerData({...playerData, nationality: e.target.value})}
                                        className="bg-slate-800 border-slate-700 text-white mt-1"
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-slate-900/50 backdrop-blur-xl border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Select Modules</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {modules.map(module => (
                                    <div
                                        key={module.id}
                                        onClick={() => toggleModule(module.id)}
                                        className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                                            activeModules[module.id]
                                                ? 'bg-cyan-500/20 border border-cyan-500/30'
                                                : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                                        }`}
                                    >
                                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center flex-shrink-0`}>
                                            <module.icon className="w-4 h-4 text-white" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-white text-sm font-medium">{module.title}</p>
                                            <p className="text-slate-400 text-xs truncate">{module.description}</p>
                                        </div>
                                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                                            activeModules[module.id] ? 'border-cyan-500 bg-cyan-500' : 'border-slate-600'
                                        }`}>
                                            {activeModules[module.id] && <div className="w-2 h-2 rounded-full bg-white" />}
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Button
                            onClick={handleAnalyze}
                            disabled={isAnalyzing || !playerData.name || !playerData.age || !playerData.position || Object.values(activeModules).every(v => !v)}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white h-12 text-lg font-semibold shadow-lg shadow-cyan-500/30"
                        >
                            {isAnalyzing ? (
                                <>
                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                    Analyzing...
                                </>
                            ) : (
                                "Generate Analysis"
                            )}
                        </Button>
                    </div>

                    {/* Right Column - Analysis Results */}
                    <div className="lg:col-span-2">
                        <AnimatePresence mode="wait">
                            {!analysisResult && !isAnalyzing && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className="h-full flex items-center justify-center"
                                >
                                    <div className="text-center">
                                        <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                                            <Target className="w-10 h-10 text-white" />
                                        </div>
                                        <h3 className="text-xl font-bold text-white mb-2">Ready to Scout</h3>
                                        <p className="text-slate-400">Enter player details and select modules to begin analysis</p>
                                    </div>
                                </motion.div>
                            )}

                            {isAnalyzing && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className="h-full flex items-center justify-center"
                                >
                                    <div className="text-center">
                                        <Loader2 className="w-16 h-16 mx-auto mb-4 text-cyan-500 animate-spin" />
                                        <h3 className="text-xl font-bold text-white mb-2">Analyzing Player</h3>
                                        <p className="text-slate-400">Running multi-archetype intelligence...</p>
                                    </div>
                                </motion.div>
                            )}

                            {analysisResult && !isAnalyzing && (
                                <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-6"
                                >
                                {/* Live Data Badge */}
                                {analysisResult.live_data && (
                                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                    <p className="text-emerald-400 text-sm font-semibold">
                                        Enriched with live data from Transfermarkt & sources
                                    </p>
                                </div>
                                )}

                                <Tabs defaultValue="analysis">
                                        <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                                            <TabsTrigger value="analysis" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                                                <FileText className="w-4 h-4 mr-2" />
                                                Analysis
                                            </TabsTrigger>
                                            <TabsTrigger value="visual" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                                                <Activity className="w-4 h-4 mr-2" />
                                                Visual
                                            </TabsTrigger>
                                            <TabsTrigger value="benchmark" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                                                <BarChart3 className="w-4 h-4 mr-2" />
                                                Benchmark
                                            </TabsTrigger>
                                        </TabsList>

                                        <TabsContent value="analysis" className="space-y-6 mt-6">
                                            {/* Verdict Card */}
                                                    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/30 shadow-lg shadow-cyan-500/10">
                                                <CardHeader>
                                                    <div className="flex items-start justify-between">
                                                        <div>
                                                            <CardTitle className="text-2xl text-white mb-1">{playerData.name}</CardTitle>
                                                            <p className="text-slate-400">{playerData.position} · {playerData.age} years</p>
                                                            {analysisResult.live_data && (
                                                                <div className="mt-2 space-y-1">
                                                                    <p className="text-amber-400 text-sm font-semibold">
                                                                        €{analysisResult.live_data.market_value}M · {analysisResult.live_data.current_club}
                                                                    </p>
                                                                    <p className="text-slate-500 text-xs">
                                                                        Contract: {analysisResult.live_data.contract_expiry}
                                                                    </p>
                                                                </div>
                                                            )}
                                                        </div>
                                                <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                                                    analysisResult.recommendation === "Strong Recommend" 
                                                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                                                        : analysisResult.recommendation === "Recommend"
                                                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                                                        : analysisResult.recommendation === "Monitor"
                                                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                                        : "bg-slate-500/20 text-slate-400 border border-slate-500/30"
                                                }`}>
                                                    {analysisResult.recommendation}
                                                </span>
                                            </div>
                                        </CardHeader>
                                        <CardContent className="space-y-4">
                                            <div>
                                                <h4 className="text-cyan-400 font-semibold mb-2">FS–AI Verdict</h4>
                                                <p className="text-slate-300 leading-relaxed">{analysisResult.overall_verdict}</p>
                                            </div>
                                            {analysisResult.notes && (
                                                <div>
                                                    <h4 className="text-amber-400 font-semibold mb-2">Additional Notes</h4>
                                                    <p className="text-slate-300 leading-relaxed">{analysisResult.notes}</p>
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>

                                    {/* Module Results */}
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        {analysisResult.calafat_analysis && (
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                                                            <Sparkles className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div>
                                                            <CardTitle className="text-white">Calafat Mode</CardTitle>
                                                            <p className="text-slate-400 text-xs">Elite Talent Identifier</p>
                                                        </div>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    <MetricDisplay label="Ceiling Score" value={analysisResult.calafat_analysis.ceiling_score} color="purple" />
                                                    <MetricDisplay label="Risk Score" value={analysisResult.calafat_analysis.risk_score} color="red" />
                                                    <div>
                                                        <span className="text-slate-400 text-sm">Development Curve</span>
                                                        <p className="text-white mt-1">{analysisResult.calafat_analysis.development_curve}</p>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        )}

                                        {analysisResult.brighton_analysis && (
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                                                            <TrendingUp className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div>
                                                            <CardTitle className="text-white">Brighton Mode</CardTitle>
                                                            <p className="text-slate-400 text-xs">Market Inefficiency Engine</p>
                                                        </div>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    <MetricDisplay label="Hidden Gem Score" value={analysisResult.brighton_analysis.hidden_gem_score} color="cyan" />
                                                    <MetricDisplay label="ROI Score" value={analysisResult.brighton_analysis.roi_score} color="emerald" />
                                                    <div>
                                                        <span className="text-slate-400 text-sm">Market Value Trajectory</span>
                                                        <p className="text-white mt-1">{analysisResult.brighton_analysis.market_value_trajectory}</p>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        )}

                                        {analysisResult.portuguese_analysis && (
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                                                            <Target className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div>
                                                            <CardTitle className="text-white">Portuguese Pipeline</CardTitle>
                                                            <p className="text-slate-400 text-xs">Flip & Pathway Engine</p>
                                                        </div>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    <MetricDisplay label="Flip Potential" value={analysisResult.portuguese_analysis.flip_potential} color="emerald" />
                                                    <MetricDisplay label="Adaptation Score" value={analysisResult.portuguese_analysis.adaptation_score} color="cyan" />
                                                    <MetricDisplay label="Versatility Index" value={analysisResult.portuguese_analysis.versatility_index} color="amber" />
                                                </CardContent>
                                            </Card>
                                        )}

                                        {analysisResult.dortmund_analysis && (
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                                                            <Users className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div>
                                                            <CardTitle className="text-white">Dortmund Mode</CardTitle>
                                                            <p className="text-slate-400 text-xs">Youth Acceleration Engine</p>
                                                        </div>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    <MetricDisplay label="Readiness Score" value={analysisResult.dortmund_analysis.readiness_score} color="amber" />
                                                    <MetricDisplay label="Resilience Index" value={analysisResult.dortmund_analysis.resilience_index} color="emerald" />
                                                    <div>
                                                        <span className="text-slate-400 text-sm">Acceleration Curve</span>
                                                        <p className="text-white mt-1">{analysisResult.dortmund_analysis.acceleration_curve}</p>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        )}

                                        {analysisResult.ajax_analysis && (
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center">
                                                            <FileText className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div>
                                                            <CardTitle className="text-white">Ajax Mode</CardTitle>
                                                            <p className="text-slate-400 text-xs">Technical DNA Assessment</p>
                                                        </div>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-4">
                                                    <MetricDisplay label="Technical Purity" value={analysisResult.ajax_analysis.technical_purity} color="red" />
                                                    <MetricDisplay label="Positional IQ" value={analysisResult.ajax_analysis.positional_iq} color="purple" />
                                                    <MetricDisplay label="Academy Fit" value={analysisResult.ajax_analysis.academy_fit} color="cyan" />
                                                </CardContent>
                                            </Card>
                                        )}
                                    </div>

                                    {/* Action Buttons */}
                                    <div className="grid grid-cols-2 gap-4">
                                        <Button
                                            onClick={handleSaveReport}
                                            disabled={saveReportMutation.isPending || saved}
                                            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white h-12 text-lg font-semibold"
                                        >
                                            {saved ? (
                                                <>
                                                    <CheckCircle2 className="w-5 h-5 mr-2" />
                                                    Saved
                                                </>
                                            ) : saveReportMutation.isPending ? (
                                                <>
                                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                    Saving...
                                                </>
                                            ) : (
                                                "Save Report"
                                            )}
                                        </Button>
                                        <Button
                                            onClick={handleExportToDrive}
                                            disabled={isExporting}
                                            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white h-12 text-lg font-semibold"
                                        >
                                            {isExporting ? (
                                                <>
                                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                    Exporting...
                                                </>
                                            ) : (
                                                <>
                                                    <Upload className="w-5 h-5 mr-2" />
                                                    Export to Drive
                                                </>
                                            )}
                                        </Button>
                                    </div>
                                    </TabsContent>

                                    <TabsContent value="visual" className="mt-6">
                                        <Card className="bg-slate-900/50 border-slate-800">
                                            <CardHeader>
                                                <CardTitle className="text-white">Module Performance Radar</CardTitle>
                                            </CardHeader>
                                            <CardContent>
                                                <ModuleRadarChart 
                                                    report={{
                                                        player_name: playerData.name,
                                                        calafat_analysis: analysisResult.calafat_analysis,
                                                        brighton_analysis: analysisResult.brighton_analysis,
                                                        portuguese_analysis: analysisResult.portuguese_analysis,
                                                        dortmund_analysis: analysisResult.dortmund_analysis,
                                                        ajax_analysis: analysisResult.ajax_analysis
                                                    }}
                                                />
                                            </CardContent>
                                        </Card>
                                    </TabsContent>

                                    <TabsContent value="benchmark" className="mt-6">
                                    <PlayerBenchmarking 
                                        currentReport={{
                                            player_name: playerData.name,
                                            player_age: parseInt(playerData.age),
                                            position: playerData.position,
                                            calafat_analysis: analysisResult.calafat_analysis,
                                            brighton_analysis: analysisResult.brighton_analysis,
                                            portuguese_analysis: analysisResult.portuguese_analysis,
                                            dortmund_analysis: analysisResult.dortmund_analysis,
                                            ajax_analysis: analysisResult.ajax_analysis
                                        }} 
                                        allReports={existingReports}
                                    />
                                    </TabsContent>
                                    </Tabs>
                                    </motion.div>
                                    )}
                        </AnimatePresence>
                    </div>
                </div>
            </div>
        </div>
    );
}