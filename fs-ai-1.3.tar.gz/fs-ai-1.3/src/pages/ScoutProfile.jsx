import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, User, MapPin, Star, FileText, MessageSquare, TrendingUp, Award, Edit2 } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ScoutProfile() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const scoutId = searchParams.get('id');
    const queryClient = useQueryClient();
    const [isEditing, setIsEditing] = useState(false);
    const [user, setUser] = useState(null);

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
    }, []);

    const { data: scout, isLoading } = useQuery({
        queryKey: ['scout', scoutId],
        queryFn: async () => {
            const scouts = await base44.entities.Scout.list();
            return scouts.find(s => s.id === scoutId);
        },
        enabled: !!scoutId
    });

    const { data: findings = [] } = useQuery({
        queryKey: ['scout-findings', scoutId],
        queryFn: () => base44.entities.ScoutFinding.filter({ scout_id: scoutId }),
        enabled: !!scoutId
    });

    const { data: messages = [] } = useQuery({
        queryKey: ['scout-messages', scoutId],
        queryFn: () => base44.entities.ScoutMessage.filter({ scout_id: scoutId }),
        enabled: !!scoutId
    });

    const updateMutation = useMutation({
        mutationFn: (data) => base44.entities.Scout.update(scoutId, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scout', scoutId] });
            setIsEditing(false);
            toast.success('Profile updated!');
        }
    });

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
            </div>
        );
    }

    if (!scout) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <p className="text-slate-400">Scout not found</p>
            </div>
        );
    }

    const canEdit = user?.role === 'admin' || user?.email === scout.email;
    const performance = scout.performance_metrics || {};

    const stats = [
        { label: 'Reports', value: findings.length, icon: FileText, color: 'text-cyan-400' },
        { label: 'Messages', value: messages.length, icon: MessageSquare, color: 'text-purple-400' },
        { label: 'Players Found', value: performance.players_discovered || 0, icon: TrendingUp, color: 'text-emerald-400' },
        { label: 'Success Rate', value: `${performance.accuracy_rating || 0}%`, icon: Award, color: 'text-amber-400' }
    ];

    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-6xl mx-auto">
                <Button
                    variant="ghost"
                    onClick={() => navigate(-1)}
                    className="mb-6 text-slate-400 hover:text-white"
                >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                </Button>

                {/* Header */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/30 mb-6">
                        <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                                <div className="flex items-start gap-6">
                                    <Avatar className="w-24 h-24">
                                        <AvatarFallback className="bg-gradient-to-br from-cyan-500 to-blue-600 text-white text-2xl">
                                            {scout.full_name?.split(' ').map(n => n[0]).join('')}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <h1 className="text-3xl font-bold text-white mb-2">{scout.full_name}</h1>
                                        <div className="flex items-center gap-3 mb-3">
                                            <Badge className={
                                                scout.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400' :
                                                scout.status === 'Vetting' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-slate-500/20 text-slate-400'
                                            }>
                                                {scout.status}
                                            </Badge>
                                            {scout.verification_status === 'Verified' && (
                                                <Badge className="bg-blue-500/20 text-blue-400">
                                                    <Award className="w-3 h-3 mr-1" />
                                                    Verified Scout
                                                </Badge>
                                            )}
                                        </div>
                                        <div className="flex items-center gap-4 text-slate-400 text-sm">
                                            <div className="flex items-center gap-2">
                                                <MapPin className="w-4 h-4" />
                                                <span>{scout.region}</span>
                                            </div>
                                            <span>•</span>
                                            <span>{scout.experience_years} years experience</span>
                                        </div>
                                    </div>
                                </div>
                                {canEdit && (
                                    <Button
                                        onClick={() => setIsEditing(!isEditing)}
                                        variant="outline"
                                        className="border-slate-700"
                                    >
                                        <Edit2 className="w-4 h-4 mr-2" />
                                        Edit Profile
                                    </Button>
                                )}
                            </div>

                            <div className="grid grid-cols-4 gap-4 mt-6">
                                {stats.map((stat, idx) => (
                                    <div key={idx} className="bg-slate-800/50 rounded-lg p-4 text-center">
                                        <stat.icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                                        <p className="text-slate-400 text-xs">{stat.label}</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                <Tabs defaultValue="overview" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="findings">Findings ({findings.length})</TabsTrigger>
                        <TabsTrigger value="messages">Messages ({messages.length})</TabsTrigger>
                        <TabsTrigger value="performance">Performance</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Contact Information</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div>
                                        <span className="text-slate-400 text-sm">Email</span>
                                        <p className="text-white">{scout.email}</p>
                                    </div>
                                    {scout.phone && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Phone</span>
                                            <p className="text-white">{scout.phone}</p>
                                        </div>
                                    )}
                                    {scout.languages && scout.languages.length > 0 && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Languages</span>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {scout.languages.map((lang, idx) => (
                                                    <Badge key={idx} className="bg-cyan-500/20 text-cyan-400">
                                                        {lang}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Coverage Areas</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div>
                                        <span className="text-slate-400 text-sm">Primary Region</span>
                                        <p className="text-white font-semibold">{scout.region}</p>
                                    </div>
                                    {scout.countries && scout.countries.length > 0 && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Countries</span>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {scout.countries.map((country, idx) => (
                                                    <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                                        {country}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    {scout.specializations && scout.specializations.length > 0 && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Specializations</span>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {scout.specializations.map((spec, idx) => (
                                                    <Badge key={idx} className="bg-emerald-500/20 text-emerald-400">
                                                        {spec}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </div>

                        {scout.credentials && (
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Credentials & Experience</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {scout.credentials.licenses && scout.credentials.licenses.length > 0 && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Licenses</span>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {scout.credentials.licenses.map((license, idx) => (
                                                    <Badge key={idx} className="bg-blue-500/20 text-blue-400">
                                                        {license}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    {scout.credentials.previous_clubs && scout.credentials.previous_clubs.length > 0 && (
                                        <div>
                                            <span className="text-slate-400 text-sm">Previous Clubs</span>
                                            <p className="text-white mt-1">{scout.credentials.previous_clubs.join(', ')}</p>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="findings">
                        <div className="grid gap-4">
                            {findings.map(finding => (
                                <Card key={finding.id} className="bg-slate-900/50 border-slate-800">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-3">
                                            <div>
                                                <h4 className="text-white font-bold">{finding.player_name}</h4>
                                                <p className="text-slate-400 text-sm">{finding.position} • {finding.current_club}</p>
                                            </div>
                                            <Badge className={
                                                finding.priority === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                finding.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-blue-500/20 text-blue-400'
                                            }>
                                                {finding.priority}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm">{finding.summary}</p>
                                    </CardContent>
                                </Card>
                            ))}
                            {findings.length === 0 && (
                                <Card className="bg-slate-800/30 border-slate-700">
                                    <CardContent className="py-12 text-center">
                                        <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                        <p className="text-slate-400">No findings yet</p>
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="messages">
                        <div className="space-y-3">
                            {messages.map(message => (
                                <Card key={message.id} className="bg-slate-900/50 border-slate-800">
                                    <CardContent className="pt-6">
                                        <div className="flex items-start justify-between mb-2">
                                            <h4 className="text-white font-semibold">{message.subject}</h4>
                                            <Badge className={
                                                message.priority === 'Urgent' ? 'bg-red-500/20 text-red-400' :
                                                message.priority === 'High' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-slate-500/20 text-slate-400'
                                            }>
                                                {message.priority}
                                            </Badge>
                                        </div>
                                        <p className="text-slate-300 text-sm mb-2">{message.message}</p>
                                        <p className="text-slate-500 text-xs">{new Date(message.created_date).toLocaleDateString()}</p>
                                    </CardContent>
                                </Card>
                            ))}
                            {messages.length === 0 && (
                                <Card className="bg-slate-800/30 border-slate-700">
                                    <CardContent className="py-12 text-center">
                                        <MessageSquare className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                                        <p className="text-slate-400">No messages</p>
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                    </TabsContent>

                    <TabsContent value="performance">
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <Card className="bg-slate-900/50 border-cyan-500/30">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-2">Reports Submitted</p>
                                    <p className="text-4xl font-bold text-white">{performance.reports_submitted || 0}</p>
                                </CardContent>
                            </Card>
                            <Card className="bg-slate-900/50 border-emerald-500/30">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-2">Players Discovered</p>
                                    <p className="text-4xl font-bold text-white">{performance.players_discovered || 0}</p>
                                </CardContent>
                            </Card>
                            <Card className="bg-slate-900/50 border-purple-500/30">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-2">Successful Signings</p>
                                    <p className="text-4xl font-bold text-white">{performance.successful_signings || 0}</p>
                                </CardContent>
                            </Card>
                            <Card className="bg-slate-900/50 border-amber-500/30">
                                <CardContent className="pt-6">
                                    <p className="text-slate-400 text-sm mb-2">Accuracy Rating</p>
                                    <p className="text-4xl font-bold text-white">{performance.accuracy_rating || 0}%</p>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}