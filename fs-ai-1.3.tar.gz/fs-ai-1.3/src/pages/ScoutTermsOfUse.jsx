import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react';

export default function ScoutTermsOfUse() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <Badge className="bg-red-500/20 text-red-400 border-red-500/30 mb-4 px-4 py-2">
                        <Shield className="w-4 h-4 mr-2 inline" />
                        Mandatory Compliance Document
                    </Badge>
                    <h1 className="text-4xl font-bold text-white mb-6">FS–AI Terms of Use for Scouts</h1>
                    <p className="text-slate-400">
                        Mandatory requirements for all scouts, analysts, and affiliated users of FS–AI
                    </p>
                </div>

                <div className="space-y-6">
                    {/* Purpose */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
                                <CheckCircle className="w-6 h-6" />
                                1. Purpose
                            </h2>
                            <p className="text-slate-300 leading-relaxed">
                                These Terms of Use set out the mandatory requirements for all scouts, analysts, and affiliated users of FS–AI. 
                                They ensure compliance with Football Association (FA) regulations, UK law, and safeguarding standards.
                            </p>
                        </CardContent>
                    </Card>

                    {/* Legal Compliance */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">2. Legal Compliance</h2>
                            <ul className="space-y-4 text-slate-300">
                                <li className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        <strong className="text-white">FA Regulations:</strong> All scouting activities must comply with the Football Association's rules, codes of conduct, and safeguarding policies.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        <strong className="text-white">DBS Certification:</strong> A valid Disclosure and Barring Service (DBS) check is required for all scouts before access to FS–AI systems is granted.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        <strong className="text-white">Safeguarding Law:</strong> Users must adhere to statutory safeguarding obligations under UK law, including the Children Act 1989/2004 and Working Together to Safeguard Children guidance.
                                    </div>
                                </li>
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Mandatory Requirements */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">3. Mandatory Requirements</h2>
                            <ul className="space-y-4 text-slate-300">
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        <strong className="text-white">Identity Verification:</strong> Scouts must provide proof of identity and DBS clearance prior to onboarding.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        <strong className="text-white">Safeguarding Training:</strong> Completion of FA-approved safeguarding training is mandatory.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        <strong className="text-white">Data Protection:</strong> All personal data collected through FS–AI must be handled in accordance with GDPR and FS–AI's Privacy Policy.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        <strong className="text-white">Conduct Standards:</strong> Scouts must act with integrity, fairness, and respect, avoiding any behaviour that could endanger players, staff, or other stakeholders.
                                    </div>
                                </li>
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Prohibited Conduct */}
                    <Card className="bg-red-500/10 border-red-500/30">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-red-400 mb-4 flex items-center gap-2">
                                <AlertTriangle className="w-6 h-6" />
                                4. Prohibited Conduct
                            </h2>
                            <ul className="space-y-3 text-slate-300">
                                <li className="flex items-start gap-3">
                                    <span className="text-red-400 font-bold">•</span>
                                    <span>Accessing FS–AI without valid DBS clearance.</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-red-400 font-bold">•</span>
                                    <span>Sharing or misusing player data in violation of GDPR or FA rules.</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-red-400 font-bold">•</span>
                                    <span>Engaging in discriminatory, abusive, or exploitative behaviour.</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <span className="text-red-400 font-bold">•</span>
                                    <span>Circumventing safeguarding protocols or failing to report concerns.</span>
                                </li>
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Reporting Obligations */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">5. Reporting Obligations</h2>
                            <ul className="space-y-4 text-slate-300">
                                <li className="flex items-start gap-3">
                                    <Shield className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        Scouts must immediately report safeguarding concerns to FS–AI's Safeguarding Officer and, where appropriate, to the FA.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        Any breach of these Terms will result in suspension or permanent removal from FS–AI systems.
                                    </div>
                                </li>
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Enforcement */}
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">6. Enforcement</h2>
                            <ul className="space-y-4 text-slate-300">
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-red-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        FS–AI reserves the right to audit compliance, suspend accounts, and notify relevant authorities in cases of breach.
                                    </div>
                                </li>
                                <li className="flex items-start gap-3">
                                    <div className="w-2 h-2 rounded-full bg-red-400 mt-2 flex-shrink-0"></div>
                                    <div>
                                        Non-compliance with FA, DBS, or safeguarding law will result in immediate termination of access.
                                    </div>
                                </li>
                            </ul>
                        </CardContent>
                    </Card>

                    {/* Acceptance */}
                    <Card className="bg-gradient-to-r from-red-500/20 to-amber-500/20 border-red-500/50">
                        <CardContent className="pt-6">
                            <h2 className="text-2xl font-bold text-white mb-4">7. Acceptance</h2>
                            <p className="text-slate-200 leading-relaxed">
                                By registering as a scout with FS–AI, you acknowledge and agree to abide by these Terms of Use. 
                                Compliance with FA regulations, DBS clearance, and safeguarding law is <strong className="text-red-400">mandatory and non-negotiable</strong>.
                            </p>
                        </CardContent>
                    </Card>

                    {/* Footer Notice */}
                    <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 text-center">
                        <Shield className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">
                            Safeguarding First
                        </h3>
                        <p className="text-slate-400 text-sm">
                            FS–AI is committed to maintaining the highest standards of safeguarding and compliance in football scouting.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}