import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GraduationCap, Target, Award, TrendingUp, Shield, Brain } from 'lucide-react';
import TrainingCourseBanner from '../components/training/TrainingCourseBanner';
import PlayerIdentificationSim from '../components/training/PlayerIdentificationSim';
import ReportWritingSim from '../components/training/ReportWritingSim';
import EthicsModule from '../components/training/EthicsModule';
import PerformanceFeedback from '../components/training/PerformanceFeedback';
import TrainingLeaderboard from '../components/training/TrainingLeaderboard';
import BadgeCollection from '../components/training/BadgeCollection';

export default function ScoutTraining() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <GraduationCap className="w-8 h-8 text-cyan-400" />
                        Virtual Scout Training Academy
                    </h1>
                    <p className="text-slate-400">
                        Master scouting skills with AI-powered scenarios, earn badges, and become FA-certified
                    </p>
                </div>

                <TrainingCourseBanner />

                <Tabs defaultValue="scenarios" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-6">
                        <TabsTrigger value="scenarios" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Scenarios
                        </TabsTrigger>
                        <TabsTrigger value="identification" className="flex items-center gap-2">
                            <Brain className="w-4 h-4" />
                            Talent ID
                        </TabsTrigger>
                        <TabsTrigger value="reports" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Reports
                        </TabsTrigger>
                        <TabsTrigger value="ethics" className="flex items-center gap-2">
                            <Shield className="w-4 h-4" />
                            Ethics & FA
                        </TabsTrigger>
                        <TabsTrigger value="badges" className="flex items-center gap-2">
                            <Award className="w-4 h-4" />
                            Badges
                        </TabsTrigger>
                        <TabsTrigger value="leaderboard" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Leaderboard
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="scenarios">
                        <PerformanceFeedback />
                    </TabsContent>

                    <TabsContent value="identification">
                        <PlayerIdentificationSim />
                    </TabsContent>

                    <TabsContent value="reports">
                        <ReportWritingSim />
                    </TabsContent>

                    <TabsContent value="ethics">
                        <EthicsModule />
                    </TabsContent>

                    <TabsContent value="badges">
                        <BadgeCollection />
                    </TabsContent>

                    <TabsContent value="leaderboard">
                        <TrainingLeaderboard />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}