import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Search, TrendingUp, Target, Activity, Filter, ArrowUpDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from 'recharts';
import { useAllSportsWebSocket } from '../components/market/useWebSocket';
import PredictiveInsights from '../components/insights/PredictiveInsights';
import HelpTooltip from '../components/onboarding/HelpTooltip';

export default function ScoutingDashboard() {
    const [searchQuery, setSearchQuery] = useState('');
    const [positionFilter, setPositionFilter] = useState('');
    const [sortBy, setSortBy] = useState('ai_rating');
    const [minRating, setMinRating] = useState(0);
    const [maxValue, setMaxValue] = useState(100);
    const [apiKey, setApiKey] = useState('');
    const [websocketEnabled, setWebsocketEnabled] = useState(false);

    const { liveMatches, isConnected } = useAllSportsWebSocket(
        websocketEnabled ? apiKey : null,
        {}
    );

    const { data: players = [], isLoading: loadingPlayers } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 200)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 100)
    });

    const { data: alerts = [] } = useQuery({
        queryKey: ['alerts'],
        queryFn: () => base44.entities.Alert.filter({ read: false })
    });

    // Consolidate player data
    const consolidatedPlayers = useMemo(() => {
        return players.map(player => {
            const playerReports = reports.filter(r => 
                r.player_name?.toLowerCase() === player.name?.toLowerCase()
            ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

            const projection = projections.find(p => 
                p.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            const playerAlerts = alerts.filter(a => 
                a.player_name?.toLowerCase() === player.name?.toLowerCase()
            );

            const latestReport = playerReports[0];
            const aiRating = latestReport?.overall_rating || 0;
            const growthPotential = projection?.peak_potential_rating 
                ? projection.peak_potential_rating - aiRating 
                : 0;

            return {
                ...player,
                ai_rating: aiRating,
                reports_count: playerReports.length,
                latest_report: latestReport,
                projection: projection,
                growth_potential: growthPotential,
                alerts_count: playerAlerts.length,
                value_score: player.market_value ? (aiRating / player.market_value) * 10 : 0
            };
        });
    }, [players, reports, projections, alerts]);

    // Apply filters and sorting
    const filteredPlayers = useMemo(() => {
        let filtered = consolidatedPlayers.filter(player => {
            const matchesSearch = !searchQuery || 
                player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                player.current_club?.toLowerCase().includes(searchQuery.toLowerCase());
            
            const matchesPosition = !positionFilter || player.position === positionFilter;
            const matchesRating = player.ai_rating >= minRating;
            const matchesValue = !player.market_value || player.market_value <= maxValue;

            return matchesSearch && matchesPosition && matchesRating && matchesValue;
        });

        // Sort
        filtered.sort((a, b) => {
            switch (sortBy) {
                case 'ai_rating':
                    return b.ai_rating - a.ai_rating;
                case 'market_value':
                    return (b.market_value || 0) - (a.market_value || 0);
                case 'growth_potential':
                    return b.growth_potential - a.growth_potential;
                case 'value_score':
                    return b.value_score - a.value_score;
                case 'age':
                    return a.age - b.age;
                default:
                    return 0;
            }
        });

        return filtered;
    }, [consolidatedPlayers, searchQuery, positionFilter, sortBy, minRating, maxValue]);

    // Analytics data
    const analyticsData = useMemo(() => {
        const positionDistribution = {};
        const ratingDistribution = { '0-4': 0, '4-6': 0, '6-8': 0, '8-10': 0 };
        
        filteredPlayers.forEach(player => {
            positionDistribution[player.position] = (positionDistribution[player.position] || 0) + 1;
            
            if (player.ai_rating < 4) ratingDistribution['0-4']++;
            else if (player.ai_rating < 6) ratingDistribution['4-6']++;
            else if (player.ai_rating < 8) ratingDistribution['6-8']++;
            else ratingDistribution['8-10']++;
        });

        return {
            positions: Object.entries(positionDistribution).map(([position, count]) => ({
                position, count
            })),
            ratings: Object.entries(ratingDistribution).map(([range, count]) => ({
                range, count
            }))
        };
    }, [filteredPlayers]);

    const positions = ['Goalkeeper', 'Centre-Back', 'Full-Back', 'Defensive Midfielder', 
                       'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Striker'];

    if (loadingPlayers) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2 flex items-center gap-3">
                        Unified Scouting Dashboard
                        <HelpTooltip content="Your central hub for all scouting operations. Manage players, view AI predictions, analyze data, and track live matches all in one place." />
                    </h1>
                    <p className="text-slate-400">Consolidated intelligence hub for player scouting and market analysis</p>
                </div>

                {/* Stats Overview */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Players</p>
                                    <p className="text-3xl font-bold text-white">{filteredPlayers.length}</p>
                                </div>
                                <Target className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">AI Scouted</p>
                                    <p className="text-3xl font-bold text-purple-400">
                                        {filteredPlayers.filter(p => p.reports_count > 0).length}
                                    </p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Active Alerts</p>
                                    <p className="text-3xl font-bold text-amber-400">{alerts.length}</p>
                                </div>
                                <Activity className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Live Matches</p>
                                    <p className="text-3xl font-bold text-emerald-400">{liveMatches.length}</p>
                                </div>
                                <Activity className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="players" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                        <TabsTrigger value="players">Players</TabsTrigger>
                        <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
                        <TabsTrigger value="analytics">Analytics</TabsTrigger>
                        <TabsTrigger value="live">Live Matches</TabsTrigger>
                    </TabsList>

                    {/* Players Tab */}
                    <TabsContent value="players" className="space-y-6 mt-6">
                        {/* Filters */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Filter className="w-5 h-5 text-cyan-400" />
                                    Filters & Sorting
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Search</label>
                                        <Input
                                            placeholder="Player or club..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Position</label>
                                        <Select value={positionFilter} onValueChange={setPositionFilter}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue placeholder="All Positions" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value={null}>All Positions</SelectItem>
                                                {positions.map(pos => (
                                                    <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Min AI Rating</label>
                                        <Select value={minRating.toString()} onValueChange={(v) => setMinRating(parseInt(v))}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="0">Any</SelectItem>
                                                <SelectItem value="6">6+</SelectItem>
                                                <SelectItem value="7">7+</SelectItem>
                                                <SelectItem value="8">8+</SelectItem>
                                                <SelectItem value="9">9+</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Max Value (€M)</label>
                                        <Select value={maxValue.toString()} onValueChange={(v) => setMaxValue(parseInt(v))}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="100">Any</SelectItem>
                                                <SelectItem value="5">≤5M</SelectItem>
                                                <SelectItem value="10">≤10M</SelectItem>
                                                <SelectItem value="20">≤20M</SelectItem>
                                                <SelectItem value="50">≤50M</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Sort By</label>
                                        <Select value={sortBy} onValueChange={setSortBy}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="ai_rating">AI Rating</SelectItem>
                                                <SelectItem value="growth_potential">Growth Potential</SelectItem>
                                                <SelectItem value="value_score">Value Score</SelectItem>
                                                <SelectItem value="market_value">Market Value</SelectItem>
                                                <SelectItem value="age">Age</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Player List */}
                        <div className="grid gap-4">
                            {filteredPlayers.map((player) => (
                                <motion.div
                                    key={player.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    <Card className="bg-slate-900/50 border-slate-800 hover:border-cyan-500/50 transition-all">
                                        <CardContent className="pt-6">
                                            <div className="flex items-start justify-between mb-4">
                                                <div className="flex-1">
                                                    <h3 className="text-white font-bold text-lg">{player.name}</h3>
                                                    <p className="text-slate-400 text-sm">
                                                        {player.position} • {player.age}y • {player.current_club}
                                                    </p>
                                                    <div className="flex flex-wrap gap-2 mt-2">
                                                        <Badge className="bg-slate-700 text-slate-300">
                                                            {player.league}
                                                        </Badge>
                                                        {player.alerts_count > 0 && (
                                                            <Badge className="bg-amber-500/20 text-amber-400">
                                                                {player.alerts_count} Alerts
                                                            </Badge>
                                                        )}
                                                        {player.reports_count > 0 && (
                                                            <Badge className="bg-purple-500/20 text-purple-400">
                                                                {player.reports_count} Reports
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>

                                                <div className="text-right">
                                                    {player.ai_rating > 0 && (
                                                        <div className="mb-2">
                                                            <p className="text-slate-400 text-xs">AI Rating</p>
                                                            <p className={`text-3xl font-bold ${
                                                                player.ai_rating >= 8 ? 'text-emerald-400' :
                                                                player.ai_rating >= 6 ? 'text-cyan-400' :
                                                                'text-slate-400'
                                                            }`}>
                                                                {player.ai_rating.toFixed(1)}
                                                            </p>
                                                        </div>
                                                    )}
                                                    {player.market_value && (
                                                        <p className="text-amber-400 font-semibold">€{player.market_value}M</p>
                                                    )}
                                                </div>
                                            </div>

                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                                {player.growth_potential > 0 && (
                                                    <div className="bg-slate-800/50 rounded p-2">
                                                        <p className="text-slate-400 text-xs">Growth Potential</p>
                                                        <p className="text-emerald-400 font-semibold">+{player.growth_potential.toFixed(1)}</p>
                                                    </div>
                                                )}
                                                {player.value_score > 0 && (
                                                    <div className="bg-slate-800/50 rounded p-2">
                                                        <p className="text-slate-400 text-xs">Value Score</p>
                                                        <p className="text-cyan-400 font-semibold">{player.value_score.toFixed(1)}/10</p>
                                                    </div>
                                                )}
                                                {player.injury_prone_score && (
                                                    <div className="bg-slate-800/50 rounded p-2">
                                                        <p className="text-slate-400 text-xs">Injury Risk</p>
                                                        <p className={`font-semibold ${
                                                            player.injury_prone_score > 60 ? 'text-red-400' :
                                                            player.injury_prone_score > 30 ? 'text-amber-400' :
                                                            'text-emerald-400'
                                                        }`}>
                                                            {player.injury_prone_score}/100
                                                        </p>
                                                    </div>
                                                )}
                                                {player.projection && (
                                                    <div className="bg-slate-800/50 rounded p-2">
                                                        <p className="text-slate-400 text-xs">Trajectory</p>
                                                        <p className="text-purple-400 font-semibold text-xs">
                                                            {player.projection.potential_trajectory}
                                                        </p>
                                                    </div>
                                                )}
                                            </div>

                                            {player.latest_report && (
                                                <div className="mt-3 pt-3 border-t border-slate-700">
                                                    <p className="text-slate-300 text-xs">
                                                        <span className="text-slate-500">Latest Report: </span>
                                                        {player.latest_report.recommendation}
                                                    </p>
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))}
                        </div>
                    </TabsContent>

                    {/* Analytics Tab */}
                    <TabsContent value="analytics" className="space-y-6 mt-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            {/* Position Distribution */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">Position Distribution</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ResponsiveContainer width="100%" height={300}>
                                        <BarChart data={analyticsData.positions}>
                                            <XAxis dataKey="position" stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
                                            <YAxis stroke="#94a3b8" />
                                            <Tooltip 
                                                contentStyle={{ 
                                                    backgroundColor: '#1e293b', 
                                                    border: '1px solid #334155',
                                                    borderRadius: '8px'
                                                }}
                                            />
                                            <Bar dataKey="count" fill="#06b6d4" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>

                            {/* Rating Distribution */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white">AI Rating Distribution</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ResponsiveContainer width="100%" height={300}>
                                        <BarChart data={analyticsData.ratings}>
                                            <XAxis dataKey="range" stroke="#94a3b8" />
                                            <YAxis stroke="#94a3b8" />
                                            <Tooltip 
                                                contentStyle={{ 
                                                    backgroundColor: '#1e293b', 
                                                    border: '1px solid #334155',
                                                    borderRadius: '8px'
                                                }}
                                            />
                                            <Bar dataKey="count" fill="#10b981" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Top Performers */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Top 10 AI-Rated Players</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {consolidatedPlayers
                                        .filter(p => p.ai_rating > 0)
                                        .sort((a, b) => b.ai_rating - a.ai_rating)
                                        .slice(0, 10)
                                        .map((player, idx) => (
                                            <div key={player.id} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                                                        <span className="text-cyan-400 font-bold">{idx + 1}</span>
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-semibold">{player.name}</p>
                                                        <p className="text-slate-400 text-sm">
                                                            {player.position} • {player.age}y • {player.current_club}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <div className="text-right">
                                                        <p className="text-emerald-400 font-bold text-lg">{player.ai_rating.toFixed(1)}</p>
                                                        <p className="text-slate-500 text-xs">AI Rating</p>
                                                    </div>
                                                    {player.market_value && (
                                                        <div className="text-right">
                                                            <p className="text-amber-400 font-semibold">€{player.market_value}M</p>
                                                            <p className="text-slate-500 text-xs">Value</p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Best Value Players */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Best Value for Money</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {consolidatedPlayers
                                        .filter(p => p.value_score > 0)
                                        .sort((a, b) => b.value_score - a.value_score)
                                        .slice(0, 10)
                                        .map((player, idx) => (
                                            <div key={player.id} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                                                        <span className="text-emerald-400 font-bold">{idx + 1}</span>
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-semibold">{player.name}</p>
                                                        <p className="text-slate-400 text-sm">
                                                            {player.position} • {player.age}y
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <div className="text-right">
                                                        <p className="text-emerald-400 font-bold text-lg">{player.value_score.toFixed(1)}</p>
                                                        <p className="text-slate-500 text-xs">Value Score</p>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-amber-400 font-semibold">€{player.market_value}M</p>
                                                        <p className="text-slate-500 text-xs">Rating: {player.ai_rating.toFixed(1)}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* AI Predictions Tab */}
                    <TabsContent value="predictions" className="mt-6">
                        <PredictiveInsights />
                    </TabsContent>

                    {/* Live Matches Tab */}
                    <TabsContent value="live" className="space-y-6 mt-6">
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Activity className="w-5 h-5 text-emerald-400" />
                                    Live Matches
                                    {isConnected && (
                                        <Badge className="bg-emerald-500/20 text-emerald-400 animate-pulse">
                                            Real-time Updates
                                        </Badge>
                                    )}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {!websocketEnabled && (
                                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4 mb-4">
                                        <p className="text-cyan-400 text-sm mb-2">Enable real-time updates</p>
                                        <Input
                                            type="password"
                                            placeholder="Enter AllSportsAPI key..."
                                            value={apiKey}
                                            onChange={(e) => setApiKey(e.target.value)}
                                            className="bg-slate-900 border-slate-700 text-white mb-2"
                                        />
                                        <Button
                                            onClick={() => setWebsocketEnabled(true)}
                                            disabled={!apiKey}
                                            className="bg-gradient-to-r from-cyan-500 to-blue-600"
                                        >
                                            Connect to Live Data
                                        </Button>
                                    </div>
                                )}

                                {liveMatches.length === 0 ? (
                                    <p className="text-slate-400 text-center py-8">
                                        {isConnected ? 'No live matches at the moment' : 'Enable real-time updates to see live matches'}
                                    </p>
                                ) : (
                                    <div className="space-y-3">
                                        {liveMatches.map((match, idx) => (
                                            <motion.div
                                                key={match.event_key || idx}
                                                initial={{ opacity: 0, scale: 0.95 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-emerald-500"
                                            >
                                                <div className="flex items-center justify-between mb-3">
                                                    <div className="flex items-center gap-2">
                                                        <Badge className="bg-emerald-500/20 text-emerald-400 animate-pulse">
                                                            LIVE {match.event_status}'
                                                        </Badge>
                                                        {match.event_halftime_result && (
                                                            <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                                HT: {match.event_halftime_result}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                    <span className="text-slate-400 text-xs">{match.league_name}</span>
                                                </div>

                                                <div className="flex items-center justify-between mb-3">
                                                    <div className="flex-1">
                                                        <p className="text-white font-semibold">{match.event_home_team}</p>
                                                        <p className="text-slate-400 text-sm">{match.event_away_team}</p>
                                                    </div>
                                                    <div className="text-center px-4">
                                                        <p className="text-3xl font-bold text-cyan-400">
                                                            {match.event_final_result || '0 - 0'}
                                                        </p>
                                                    </div>
                                                </div>

                                                {match.goalscorers && match.goalscorers.length > 0 && (
                                                    <div className="space-y-1 text-xs mb-3">
                                                        <p className="text-slate-500 font-semibold">Recent Goals:</p>
                                                        {match.goalscorers.slice(-3).map((goal, i) => (
                                                            <div key={i} className="flex items-center gap-2 text-slate-300">
                                                                <Badge className="bg-slate-700 text-slate-300 text-xs">
                                                                    {goal.time}'
                                                                </Badge>
                                                                <span>{goal.home_scorer || goal.away_scorer} {goal.score}</span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}

                                                {match.statistics && match.statistics.length > 0 && (
                                                    <div className="pt-3 border-t border-slate-700">
                                                        <div className="grid grid-cols-3 gap-2 text-xs">
                                                            {match.statistics.slice(0, 6).map((stat, i) => (
                                                                <div key={i} className="text-center">
                                                                    <p className="text-slate-500 mb-1">{stat.type}</p>
                                                                    <p className="text-white font-semibold">
                                                                        {stat.home} - {stat.away}
                                                                    </p>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </motion.div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}