import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Network, MapPin, TrendingUp, Target, Brain, MessageSquare, User, Share2, Rss, Shield } from 'lucide-react';
import ScoutDirectory from '../components/scout-network/ScoutDirectory';
import RegionCoverageMap from '../components/scout-network/RegionCoverageMap';
import AIScoutAssignmentEngine from '../components/scout-network/AIScoutAssignmentEngine';
import ScoutEfficiencyTracker from '../components/scout-network/ScoutEfficiencyTracker';
import CollectiveIntelligencePanel from '../components/scout-network/CollectiveIntelligencePanel';
import FindingsFeed from '../components/scout-network/FindingsFeed';
import UserNetworkProfile from '../components/network/UserNetworkProfile';
import NetworkMessaging from '../components/network/NetworkMessaging';
import ReportSharingPanel from '../components/network/ReportSharingPanel';
import NetworkFeedComponent from '../components/network/NetworkFeedComponent';
import { Badge } from '@/components/ui/badge';

export default function ScoutingNetworkHub() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Network className="w-8 h-8 text-cyan-400" />
                        Scouting Network Hub
                        <Badge className="bg-emerald-500/20 text-emerald-400 flex items-center gap-1">
                            <Shield className="w-3 h-3" />
                            InScout Connected
                        </Badge>
                    </h1>
                    <p className="text-slate-400">
                        Connect with scouts, share insights, collaborate on player discovery, and tap into the InScout network
                    </p>
                </div>

                <Tabs defaultValue="profile" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-5">
                        <TabsTrigger value="profile" className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            My Profile
                        </TabsTrigger>
                        <TabsTrigger value="feed" className="flex items-center gap-2">
                            <Rss className="w-4 h-4" />
                            Network Feed
                        </TabsTrigger>
                        <TabsTrigger value="messages" className="flex items-center gap-2">
                            <MessageSquare className="w-4 h-4" />
                            Messages
                        </TabsTrigger>
                        <TabsTrigger value="sharing" className="flex items-center gap-2">
                            <Share2 className="w-4 h-4" />
                            Share Reports
                        </TabsTrigger>
                        <TabsTrigger value="directory" className="flex items-center gap-2">
                            <Network className="w-4 h-4" />
                            Directory
                        </TabsTrigger>
                        <TabsTrigger value="intelligence" className="flex items-center gap-2">
                            <Brain className="w-4 h-4" />
                            Intelligence
                        </TabsTrigger>
                        <TabsTrigger value="findings" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Findings
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="profile">
                        <UserNetworkProfile />
                    </TabsContent>

                    <TabsContent value="feed">
                        <NetworkFeedComponent />
                    </TabsContent>

                    <TabsContent value="messages">
                        <NetworkMessaging />
                    </TabsContent>

                    <TabsContent value="sharing">
                        <ReportSharingPanel />
                    </TabsContent>

                    <TabsContent value="directory">
                        <ScoutDirectory />
                    </TabsContent>

                    <TabsContent value="intelligence">
                        <CollectiveIntelligencePanel />
                    </TabsContent>

                    <TabsContent value="findings">
                        <FindingsFeed />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}