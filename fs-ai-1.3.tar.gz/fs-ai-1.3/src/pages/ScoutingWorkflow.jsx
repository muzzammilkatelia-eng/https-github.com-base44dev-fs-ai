import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ClipboardList, Zap, DollarSign, TrendingUp, CheckCircle2, Clock, AlertCircle, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import TaskBoard from '../components/workflow/TaskBoard';
import CriteriaManager from '../components/workflow/CriteriaManager';
import CommissionTracker from '../components/workflow/CommissionTracker';
import AutomatedSummary from '../components/workflow/AutomatedSummary';
import PremiumGate from '../components/PremiumGate';

export default function ScoutingWorkflow() {
    return (
        <PremiumGate>
            <ScoutingWorkflowContent />
        </PremiumGate>
    );
}

function ScoutingWorkflowContent() {
    const [activeTab, setActiveTab] = useState('tasks');
    const queryClient = useQueryClient();

    const { data: tasks = [], isLoading: tasksLoading } = useQuery({
        queryKey: ['scouting-tasks'],
        queryFn: () => base44.entities.ScoutingTask.list('-created_date', 100)
    });

    const { data: criteria = [] } = useQuery({
        queryKey: ['scouting-criteria'],
        queryFn: () => base44.entities.AIScoutingCriteria.list()
    });

    const { data: commissions = [] } = useQuery({
        queryKey: ['agent-commissions'],
        queryFn: () => base44.entities.AgentCommission.list('-signing_date', 50)
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    // Stats calculations
    const myTasks = tasks.filter(t => t.assigned_to === user?.email);
    const pendingTasks = myTasks.filter(t => t.status === 'Pending').length;
    const inProgressTasks = myTasks.filter(t => t.status === 'In Progress').length;
    const completedTasks = myTasks.filter(t => t.status === 'Completed').length;
    const aiFlaggedTasks = tasks.filter(t => t.source === 'AI Flag').length;

    const totalCommissions = commissions.reduce((sum, c) => sum + (c.total_commission_earned || 0), 0);
    const pendingPayments = commissions.filter(c => c.payment_status === 'Pending').length;

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent mb-2">
                        Automated Scouting Workflow
                    </h1>
                    <p className="text-slate-400">AI-powered task management & agent commission tracking</p>
                </div>

                {/* Stats Dashboard */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Pending Tasks</p>
                                    <p className="text-3xl font-bold text-amber-400">{pendingTasks}</p>
                                </div>
                                <Clock className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">In Progress</p>
                                    <p className="text-3xl font-bold text-cyan-400">{inProgressTasks}</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">AI Flagged</p>
                                    <p className="text-3xl font-bold text-purple-400">{aiFlaggedTasks}</p>
                                </div>
                                <Zap className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Commissions</p>
                                    <p className="text-3xl font-bold text-emerald-400">£{totalCommissions.toLocaleString()}</p>
                                </div>
                                <DollarSign className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                        <TabsTrigger value="tasks" className="data-[state=active]:bg-indigo-500/20 data-[state=active]:text-indigo-400">
                            <ClipboardList className="w-4 h-4 mr-2" />
                            Tasks
                        </TabsTrigger>
                        <TabsTrigger value="criteria" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
                            <Zap className="w-4 h-4 mr-2" />
                            AI Criteria
                        </TabsTrigger>
                        <TabsTrigger value="commissions" className="data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400">
                            <DollarSign className="w-4 h-4 mr-2" />
                            Commissions
                        </TabsTrigger>
                        <TabsTrigger value="summary" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
                            <Users className="w-4 h-4 mr-2" />
                            Summary
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="tasks" className="mt-6">
                        <TaskBoard tasks={tasks} user={user} />
                    </TabsContent>

                    <TabsContent value="criteria" className="mt-6">
                        <CriteriaManager criteria={criteria} />
                    </TabsContent>

                    <TabsContent value="commissions" className="mt-6">
                        <CommissionTracker commissions={commissions} user={user} />
                    </TabsContent>

                    <TabsContent value="summary" className="mt-6">
                        <AutomatedSummary tasks={tasks} commissions={commissions} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}