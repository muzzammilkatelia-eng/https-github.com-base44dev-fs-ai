import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Lock, Shield, AlertTriangle } from 'lucide-react';

export default function SecurityStandards() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center gap-3 mb-6">
                    <Lock className="w-10 h-10 text-cyan-400" />
                    <div>
                        <h1 className="text-4xl font-bold text-white">Security Standards</h1>
                        <p className="text-slate-400">Universal Master Version</p>
                    </div>
                </div>

                <div className="space-y-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">2.1 Core Principles</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Security is built on:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Confidentiality</li>
                                <li>Integrity</li>
                                <li>Availability</li>
                                <li>Safeguarding-first resilience</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <Shield className="w-6 h-6" />
                                2.2 Technical Controls
                            </h2>
                            <p className="text-slate-300 leading-relaxed mb-2">All platforms implement:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>End-to-end encryption</li>
                                <li>Role-based access control</li>
                                <li>Secure authentication</li>
                                <li>Real-time threat detection</li>
                                <li>Regular penetration testing</li>
                                <li>Data minimisation and secure storage</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.3 Organisational Controls</h2>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Staff training on safeguarding and data protection</li>
                                <li>Incident response protocols</li>
                                <li>Vendor risk assessments</li>
                                <li>Regular audits and compliance reviews</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8 flex items-center gap-2">
                                <AlertTriangle className="w-6 h-6" />
                                2.4 Breach Protocol
                            </h2>
                            <p className="text-slate-300 leading-relaxed mb-2">In the event of a breach:</p>
                            <ul className="text-slate-300 space-y-2">
                                <li>Users and regulators are notified within required timeframes</li>
                                <li>Full documentation and root cause analysis is conducted</li>
                                <li>Safeguarding impact is assessed before technical recovery</li>
                            </ul>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}