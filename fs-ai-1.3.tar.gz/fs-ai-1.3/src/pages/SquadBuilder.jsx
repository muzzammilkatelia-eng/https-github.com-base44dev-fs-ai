import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import SquadBuilderInput from '../components/squad/SquadBuilderInput';
import SquadVisualization from '../components/squad/SquadVisualization';

export default function SquadBuilder() {
    const [squadResult, setSquadResult] = useState(null);

    const { data: scoutingReports = [] } = useQuery({
        queryKey: ['scouting-reports-squad'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections-squad'],
        queryFn: () => base44.entities.PlayerProjection.list('-created_date', 50)
    });

    const buildSquadMutation = useMutation({
        mutationFn: async (requirements) => {
            const reportsContext = scoutingReports.slice(0, 30).map(r => 
                `${r.player_name} (${r.player_age}y, ${r.position}) - Club: ${r.current_club}, Tech: ${r.technical_rating}, Phys: ${r.physical_rating}, Tac: ${r.tactical_rating}, Mental: ${r.mental_rating}, Rec: ${r.recommendation}, Strengths: ${r.strengths || 'N/A'}`
            ).join('\n');

            const projectionsContext = projections.slice(0, 15).map(p =>
                `${p.player_name} (${p.current_age}y, ${p.position}) - Trajectory: ${p.potential_trajectory}, Peak: ${p.peak_potential_rating}/100, Years to peak: ${p.years_to_peak}`
            ).join('\n');

            const prompt = `You are an elite football squad building AI. Design an optimal squad based on tactical and financial requirements.

CLUB REQUIREMENTS:
- Formation: ${requirements.formation}
- Playing Style: ${requirements.playingStyle}
- Total Budget: ${requirements.budget}
- Priority Positions: ${requirements.priorityPositions || 'Not specified'}
- Squad Size Target: ${requirements.squadSize || '25 players'}
- Age Balance: ${requirements.ageBalance || 'Balanced'}
- Additional Notes: ${requirements.additionalNotes || 'None'}

AVAILABLE SCOUTED PLAYERS:
${reportsContext}

PLAYER PROJECTIONS:
${projectionsContext}

Design a complete squad (Starting XI + Key Substitutes) that:
1. Fits the formation and playing style perfectly
2. Stays within budget (allocate budget per position)
3. Has tactical cohesion and chemistry
4. Balances experience and potential
5. Covers all positions with adequate depth

For each player provide:
- Name, age, position, current club
- Why they fit this system (tactical role)
- How they contribute to playing style
- Estimated transfer fee
- Alternative options (2-3 backup targets per position)

Also provide:
- Formation visualization data
- Tactical analysis of the squad
- Budget breakdown
- Squad strengths and weaknesses
- Recommended training focus`;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        starting_xi: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    current_club: { type: "string" },
                                    tactical_role: { type: "string" },
                                    style_contribution: { type: "string" },
                                    estimated_fee: { type: "string" },
                                    key_attributes: {
                                        type: "array",
                                        items: { type: "string" }
                                    },
                                    alternatives: {
                                        type: "array",
                                        items: {
                                            type: "object",
                                            properties: {
                                                name: { type: "string" },
                                                fee: { type: "string" },
                                                rationale: { type: "string" }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        key_substitutes: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    position: { type: "string" },
                                    player_name: { type: "string" },
                                    age: { type: "number" },
                                    current_club: { type: "string" },
                                    tactical_role: { type: "string" },
                                    estimated_fee: { type: "string" }
                                }
                            }
                        },
                        tactical_analysis: { type: "string" },
                        budget_breakdown: {
                            type: "object",
                            properties: {
                                goalkeepers: { type: "string" },
                                defenders: { type: "string" },
                                midfielders: { type: "string" },
                                attackers: { type: "string" },
                                total_spent: { type: "string" },
                                remaining: { type: "string" }
                            }
                        },
                        squad_strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        squad_weaknesses: {
                            type: "array",
                            items: { type: "string" }
                        },
                        training_focus: {
                            type: "array",
                            items: { type: "string" }
                        },
                        chemistry_score: { type: "number" },
                        summary: { type: "string" }
                    }
                }
            });

            return result;
        },
        onSuccess: (data) => {
            setSquadResult(data);
            toast.success('Squad built successfully!');
        },
        onError: () => {
            toast.error('Failed to build squad');
        }
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                        AI Squad Builder
                    </h1>
                    <p className="text-slate-400">
                        Design your optimal squad with AI-powered tactical intelligence
                    </p>
                </div>

                <SquadBuilderInput 
                    onSubmit={(reqs) => buildSquadMutation.mutate(reqs)}
                    isLoading={buildSquadMutation.isPending}
                />

                {buildSquadMutation.isPending && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 text-center py-12">
                            <Loader2 className="w-12 h-12 text-purple-400 animate-spin mx-auto mb-4" />
                            <p className="text-white font-semibold mb-2">Building optimal squad...</p>
                            <p className="text-slate-400 text-sm">Analyzing {scoutingReports.length} players for tactical fit</p>
                        </CardContent>
                    </Card>
                )}

                {squadResult && <SquadVisualization squadData={squadResult} />}
            </div>
        </div>
    );
}