import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Target, TrendingUp, Sparkles } from 'lucide-react';
import TacticalConfiguration from '../components/strategic-planning/TacticalConfiguration';
import SeasonGoalsTracker from '../components/strategic-planning/SeasonGoalsTracker';
import AITacticalAdvisor from '../components/strategic-planning/AITacticalAdvisor';

export default function StrategicPlanning() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-white mb-3">
                        Strategic Planning Hub
                    </h1>
                    <p className="text-slate-400 text-lg">
                        Define tactics, set season goals, and get AI-powered recommendations
                    </p>
                </div>

                <Tabs defaultValue="tactics" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-3">
                        <TabsTrigger value="tactics" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Tactical Setup
                        </TabsTrigger>
                        <TabsTrigger value="goals" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Season Goals
                        </TabsTrigger>
                        <TabsTrigger value="advisor" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            AI Advisor
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="tactics">
                        <TacticalConfiguration />
                    </TabsContent>

                    <TabsContent value="goals">
                        <SeasonGoalsTracker />
                    </TabsContent>

                    <TabsContent value="advisor">
                        <AITacticalAdvisor />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}