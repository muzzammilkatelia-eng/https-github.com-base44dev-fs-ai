import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, DollarSign, FileText, GitBranch, Users } from 'lucide-react';
import TransferMarketAnalysis from '../components/strategic-recruitment/TransferMarketAnalysis';
import ResaleValuePredictor from '../components/strategic-recruitment/ResaleValuePredictor';
import ContractNegotiationAdvisor from '../components/strategic-recruitment/ContractNegotiationAdvisor';
import ScenarioPlanner from '../components/strategic-recruitment/ScenarioPlanner';
import DreamXIGenerator from '../components/strategic-recruitment/DreamXIGenerator';

export default function StrategicRecruitment() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Strategic Recruitment AI
                    </h1>
                    <p className="text-slate-400">
                        AI-powered tools for transfer strategy, valuation, negotiation, and squad planning
                    </p>
                </div>

                <Tabs defaultValue="market" className="space-y-6">
                    <TabsList className="bg-slate-900 border-slate-800">
                        <TabsTrigger value="market" className="gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Market Analysis
                        </TabsTrigger>
                        <TabsTrigger value="resale" className="gap-2">
                            <DollarSign className="w-4 h-4" />
                            Resale Value
                        </TabsTrigger>
                        <TabsTrigger value="negotiation" className="gap-2">
                            <FileText className="w-4 h-4" />
                            Negotiation
                        </TabsTrigger>
                        <TabsTrigger value="scenarios" className="gap-2">
                            <GitBranch className="w-4 h-4" />
                            Scenarios
                        </TabsTrigger>
                        <TabsTrigger value="dreamxi" className="gap-2">
                            <Users className="w-4 h-4" />
                            Dream XI
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="market">
                        <TransferMarketAnalysis />
                    </TabsContent>

                    <TabsContent value="resale">
                        <ResaleValuePredictor />
                    </TabsContent>

                    <TabsContent value="negotiation">
                        <ContractNegotiationAdvisor />
                    </TabsContent>

                    <TabsContent value="scenarios">
                        <ScenarioPlanner />
                    </TabsContent>

                    <TabsContent value="dreamxi">
                        <DreamXIGenerator />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}