import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Sparkles, CreditCard, CheckCircle2, XCircle, Calendar, TrendingUp, AlertCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function Subscription() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    base44.auth.me().
    then(setUser).
    catch(() => {}).
    finally(() => setLoading(false));

    // Check for payment success/cancel in URL
    const params = new URLSearchParams(window.location.search);
    const success = params.get('success');
    const cancelled = params.get('cancelled');
    const token = params.get('token');

    if (success === 'true' && token) {
      handlePayPalCapture(token);
    } else if (cancelled === 'true') {
      toast.error('Payment cancelled');
      window.history.replaceState({}, '', '/Subscription');
    }
  }, []);

  const handlePayPalCapture = async (orderId) => {
    try {
      setProcessing(true);
      const response = await base44.functions.invoke('capturePayPalOrder', { orderId });

      if (response.data.success) {
        toast.success('Payment successful! Your premium subscription is now active.');
        // Reload user data
        const updatedUser = await base44.auth.me();
        setUser(updatedUser);
      }
    } catch (error) {
      toast.error('Failed to process payment');
    } finally {
      setProcessing(false);
      window.history.replaceState({}, '', '/Subscription');
    }
  };

  const handlePayPalCheckout = async () => {
    try {
      setProcessing(true);
      toast.loading('Creating PayPal order...', { id: 'paypal' });

      const response = await base44.functions.invoke('createPayPalOrder');

      if (response.data.approvalUrl) {
        toast.success('Redirecting to PayPal...', { id: 'paypal' });
        window.location.href = response.data.approvalUrl;
      } else {
        toast.error('Failed to create PayPal order', { id: 'paypal' });
        setProcessing(false);
      }
    } catch (error) {
      toast.error('Failed to initiate PayPal checkout', { id: 'paypal' });
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
            </div>);

  }

  const isPremium = user?.subscription_tier === 'premium' && user?.subscription_status === 'active';
  const isLegacy = user?.subscription_tier === 'legacy' && user?.subscription_status === 'active';
  const isAdmin = user?.role === 'admin';
  const consoleUsage = user?.console_usage_count || 0;
  const consoleLimit = 5;
  const usagePercentage = consoleUsage / consoleLimit * 100;

  const legacyFeatures = [
  'Full scouting engine with multi brain logic',
  'Unlimited match analysis with advanced tactical modelling',
  'Deep tactical modelling and projection',
  'Enhanced comparison with long term projection',
  'Advanced club DNA modelling',
  'Legacy formatting for export reports',
  'Real time awareness loop',
  'Enhanced legacy intelligence engine',
  'Early access to new modules',
  'Priority support plus direct founder channel',
  'Legacy badge and recognition'];


  const premiumFeatures = [
  'Full scouting engine',
  'Unlimited match analysis',
  'Full tactical breakdowns',
  'Player comparison engine',
  'Club profile builder',
  'Export reports',
  'Development loop and awareness engine',
  'Priority support'];


  const basicTourFeatures = [
  'Limited time access',
  'Basic scouting reports',
  'One match analysis per day',
  'Basic tactical insights',
  'No player comparison',
  'No export or saving',
  'Standard support'];


  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Subscription Management
                    </h1>
                    <p className="text-slate-400">Manage your FS-AI subscription and billing</p>
                </div>

                {/* Current Plan Status */}
                <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6">

                    <Card className={isPremium || isLegacy || isAdmin ? 'bg-gradient-to-br from-purple-500/20 to-blue-500/20 border-purple-500/30' : 'bg-slate-900/50 border-slate-800'}>
                        <CardHeader>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    {isPremium || isLegacy || isAdmin ?
                  <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                                            <Sparkles className="w-6 h-6 text-purple-400" />
                                        </div> :

                  <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center">
                                            <CreditCard className="w-6 h-6 text-slate-400" />
                                        </div>
                  }
                                    <div>
                                        <CardTitle className="text-white mb-1">
                                            {isAdmin ? 'Admin Access' : isLegacy ? 'Legacy Mode' : isPremium ? 'Premium' : 'Basic Tour'}
                                        </CardTitle>
                                        <div className="flex items-center gap-2">
                                            {isPremium || isLegacy || isAdmin ?
                      <Badge className="bg-emerald-500/20 text-emerald-400">
                                                    <CheckCircle2 className="w-3 h-3 mr-1" />
                                                    Active
                                                </Badge> :

                      <Badge className="bg-slate-700 text-slate-300">
                                                    Limited Access
                                                </Badge>
                      }
                                        </div>
                                    </div>
                                </div>
                                {isLegacy &&
                <div className="text-right">
                                        <p className="text-3xl font-bold text-white">£169.99</p>
                                        <p className="text-slate-400 text-sm">per month</p>
                                    </div>
                }
                                {isPremium && !isLegacy &&
                <div className="text-right">
                                        <p className="text-3xl font-bold text-white">£99</p>
                                        <p className="text-slate-400 text-sm">per month</p>
                                    </div>
                }
                            </div>
                        </CardHeader>
                        <CardContent>
                            {user?.subscription_start_date &&
              <div className="flex items-center gap-2 text-sm text-slate-400">
                                    <Calendar className="w-4 h-4" />
                                    <span>Started: {format(new Date(user.subscription_start_date), 'MMM d, yyyy')}</span>
                                </div>
              }
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Usage Stats for Basic Tour Users */}
                {!isPremium && !isLegacy && !isAdmin &&
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6">

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                                    Monthly Usage
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div>
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-slate-400 text-sm">Console Queries</span>
                                            <span className="text-white font-semibold">{consoleUsage} / {consoleLimit}</span>
                                        </div>
                                        <Progress value={usagePercentage} className="h-2" />
                                        {consoleUsage >= consoleLimit &&
                  <div className="mt-2 flex items-start gap-2 text-amber-400 text-sm">
                                                <AlertCircle className="w-4 h-4 mt-0.5" />
                                                <span>You've reached your monthly limit. Upgrade for unlimited access.</span>
                                            </div>
                  }
                                    </div>
                                    {user?.console_usage_reset_date &&
                <p className="text-slate-500 text-xs">
                                            Resets on {format(new Date(user.console_usage_reset_date), 'MMM d, yyyy')}
                                        </p>
                }
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
        }

                {/* Plans Comparison */}
                <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6">

                    <h2 className="text-2xl font-bold text-white mb-4">FS AI Membership Plans</h2>
                    <div className="grid md:grid-cols-3 gap-6">
                        {/* Basic Tour */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white mb-2">Basic Tour</CardTitle>
                                <div className="text-3xl font-bold text-white mb-1">Free</div>
                                <p className="text-slate-400 text-sm">Limited time access</p>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 mb-6">
                                    {basicTourFeatures.map((feature, idx) =>
                  <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                                            {feature}
                                        </li>
                  )}
                                </ul>
                                <p className="text-slate-500 text-xs italic">
                                    A short access introduction to explore FS AI before committing
                                </p>
                            </CardContent>
                        </Card>

                        {/* Premium Plan */}
                        <Card className="bg-gradient-to-br from-purple-500/20 to-blue-500/20 border-purple-500/30 relative overflow-hidden">
                            <div className="absolute top-4 right-4">
                                <Badge className="bg-emerald-500/20 text-emerald-400">
                                    <Sparkles className="w-3 h-3 mr-1" />
                                    Popular
                                </Badge>
                            </div>
                            <CardHeader>
                                <CardTitle className="text-white mb-2">Premium</CardTitle>
                                <div className="space-y-1">
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-2xl font-bold text-white">£999</span>
                                        <span className="text-slate-400 text-sm">per year</span>
                                    </div>
                                    <p className="text-slate-500 text-xs">Quarterly: £255 • Monthly: £87</p>
                                    <p className="text-amber-400 text-xs">💰 Save with annual billing</p>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 mb-6">
                                    {premiumFeatures.map((feature, idx) =>
                  <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                            <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                            {feature}
                                        </li>
                  )}
                                </ul>
                                <p className="text-slate-400 text-xs mb-4 italic">
                                    Complete professional toolkit for clubs, academies and independent analysts
                                </p>
                                {isPremium || isLegacy || isAdmin ?
                <Button className="w-full bg-purple-600" disabled>
                                        <CheckCircle2 className="w-4 h-4 mr-2" />
                                        {isPremium ? 'Current Plan' : 'Active'}
                                    </Button> :

                <div className="space-y-3">
                                        <Button
                    className="w-full bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500"
                    onClick={handlePayPalCheckout}
                    disabled={processing}>

                                            {processing ?
                    <>
                                                   <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                   Processing...
                                               </> :

                    <>
                                                   <CreditCard className="w-4 h-4 mr-2" />
                                                   Annual - £999 (Best Value)
                                               </>
                    }
                                            </Button>
                                            <div className="grid grid-cols-2 gap-2">
                                            <Button
                      variant="outline"
                      className="border-slate-700 hover:bg-slate-800 text-sm"
                      onClick={handlePayPalCheckout}
                      disabled={processing}>

                                               Quarterly - £255
                                            </Button>
                                            <Button
                      variant="outline"
                      className="border-slate-700 hover:bg-slate-800 text-sm"
                      onClick={handlePayPalCheckout}
                      disabled={processing}>

                                               Monthly - £87
                                            </Button>
                                            </div>
                                            <div className="relative">
                                            <div className="absolute inset-0 flex items-center">
                                               <div className="w-full border-t border-slate-700"></div>
                                            </div>
                                            <div className="relative flex justify-center text-xs">
                                               <span className="bg-slate-900 px-2 text-slate-500">Or</span>
                                            </div>
                                            </div>
                                            <Button
                    variant="outline"
                    className="w-full border-slate-700 hover:bg-slate-800"
                    onClick={() => window.open('https://pay.gocardless.com/BRT00048926VJAS', '_blank')}>

                                            <CreditCard className="w-4 h-4 mr-2" />
                                            Pay with GoCardless
                                            </Button>
                                        <div className="bg-slate-800/50 rounded-lg p-4">
                                            <p className="text-slate-400 text-sm text-center mb-3">Or scan QR code:</p>
                                            <img
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69495dba512b8f4310b81e9a/e7023ae01_GoCardless-QRCode.png"
                      alt="GoCardless Payment QR Code"
                      className="w-48 h-48 mx-auto" />

                                        </div>
                                    </div>
                }
                            </CardContent>
                        </Card>

                        {/* Legacy Mode */}
                        <Card className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 border-amber-500/40 relative overflow-hidden">
                            <div className="absolute top-4 right-4">
                                <Badge className="bg-amber-500/20 text-amber-400">
                                    <Sparkles className="w-3 h-3 mr-1" />
                                    Elite
                                </Badge>
                            </div>
                            <CardHeader>
                                <CardTitle className="text-white mb-2">Legacy Mode</CardTitle>
                                <div className="space-y-1">
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-2xl font-bold text-white">£1,699</span>
                                        <span className="text-slate-400 text-sm">per year</span>
                                    </div>
                                    <p className="text-slate-500 text-xs">Quarterly: £434 • Monthly: £147</p>
                                    <p className="text-amber-400 text-xs">💰 Save with annual billing</p>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 mb-6">
                                    {legacyFeatures.map((feature, idx) =>
                  <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                                            <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                                            {feature}
                                        </li>
                  )}
                                </ul>
                                <p className="text-slate-400 text-xs mb-4 italic">Maximum capability for elite users who want to shape the future on the platform

                </p>
                                {isLegacy || isAdmin ?
                <Button className="w-full bg-amber-600" disabled>
                                        <CheckCircle2 className="w-4 h-4 mr-2" />
                                        {isLegacy ? 'Current Plan' : 'Active'}
                                    </Button> :

                <div className="space-y-3">
                                        <Button
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500"
                    onClick={handlePayPalCheckout}
                    disabled={processing}>

                                            {processing ?
                    <>
                                                   <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                   Processing...
                                               </> :

                    <>
                                                   <CreditCard className="w-4 h-4 mr-2" />
                                                   Annual - £1,699 (Best Value)
                                               </>
                    }
                                            </Button>
                                            <div className="grid grid-cols-2 gap-2">
                                            <Button
                      variant="outline"
                      className="border-amber-500/30 hover:bg-amber-500/10 text-sm"
                      onClick={handlePayPalCheckout}
                      disabled={processing}>

                                               Quarterly - £434
                                            </Button>
                                            <Button
                      variant="outline"
                      className="border-amber-500/30 hover:bg-amber-500/10 text-sm"
                      onClick={handlePayPalCheckout}
                      disabled={processing}>

                                               Monthly - £147
                                            </Button>
                                            </div>
                                            <Button
                    variant="outline"
                    className="w-full border-amber-500/30 hover:bg-amber-500/10"
                    onClick={() => window.open('mailto:director@minimax-sustainable-ai.com?subject=Legacy Mode Subscription', '_blank')}>

                                            Contact for Details
                                            </Button>
                                    </div>
                }
                            </CardContent>
                        </Card>
                    </div>
                </motion.div>

                {/* Payment Info */}
                {(isPremium || isLegacy || isAdmin) &&
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}>

                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <CreditCard className="w-5 h-5 text-cyan-400" />
                                    Payment Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <span className="text-slate-400">Payment Method</span>
                                        <Badge className="bg-emerald-500/20 text-emerald-400">
                                            <CreditCard className="w-3 h-3 mr-1" />
                                            GoCardless Direct Debit
                                        </Badge>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-slate-400">Billing Cycle</span>
                                        <span className="text-white font-semibold">Monthly</span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-slate-400">Next Billing Date</span>
                                        <span className="text-white">{user.subscription_end_date ? format(new Date(user.subscription_end_date), 'MMM d, yyyy') : 'N/A'}</span>
                                    </div>
                                    <div className="pt-4 border-t border-slate-800">
                                        <Button
                    variant="outline"
                    className="w-full text-slate-300 hover:text-white"
                    onClick={() => window.open('https://manage.gocardless.com', '_blank')}>

                                            <CreditCard className="w-4 h-4 mr-2" />
                                            Manage Subscription on GoCardless
                                        </Button>
                                        <p className="text-slate-500 text-xs mt-2 text-center">
                                            Cancel or update your payment details
                                        </p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
        }

                {/* Help Section */}
                <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-6">

                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <h3 className="text-white font-semibold mb-2">Need Help?</h3>
                            <p className="text-slate-400 text-sm mb-4">
                                Contact us at <a href="mailto:director@minimax-sustainable-ai.com" className="text-cyan-400 hover:underline">director@minimax-sustainable-ai.com</a> for any subscription or billing questions.
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </div>);

}