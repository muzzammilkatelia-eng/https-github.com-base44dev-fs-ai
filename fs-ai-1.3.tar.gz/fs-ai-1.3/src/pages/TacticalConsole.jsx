import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Send, Loader2, Terminal, Trash2, Database, FileText, TrendingUp, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';

export default function TacticalConsole() {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [contextMode, setContextMode] = useState('enhanced'); // basic, enhanced, full
    const [user, setUser] = useState(null);
    const consoleRef = useRef(null);
    const inputRef = useRef(null);

    // Load user data
    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
    }, []);

    // Load contextual data
    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 30)
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['scouting-reports'],
        queryFn: () => base44.entities.ScoutingReport.list('-created_date', 20)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['player-projections'],
        queryFn: () => base44.entities.PlayerProjection.list('-updated_date', 15)
    });

    const isPremium = user?.subscription_tier === 'premium' && user?.subscription_status === 'active';
    const isAdmin = user?.role === 'admin';
    const hasAccess = isAdmin || isPremium;
    
    // Check if usage needs reset (monthly)
    const checkAndResetUsage = () => {
        if (!user) return;
        
        const now = new Date();
        const resetDate = user.console_usage_reset_date ? new Date(user.console_usage_reset_date) : null;
        
        if (!resetDate || now > resetDate) {
            const nextReset = new Date(now.getFullYear(), now.getMonth() + 1, 1);
            base44.auth.updateMe({
                console_usage_count: 0,
                console_usage_reset_date: nextReset.toISOString()
            }).then(setUser);
        }
    };

    useEffect(() => {
        if (user && !hasAccess) {
            checkAndResetUsage();
        }
    }, [user]);

    const usageCount = user?.console_usage_count || 0;
    const usageLimit = 5;
    const remainingQueries = Math.max(0, usageLimit - usageCount);
    const canQuery = hasAccess || remainingQueries > 0;

    useEffect(() => {
        if (consoleRef.current) {
            consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
        }
    }, [messages]);

    const buildContextData = () => {
        if (contextMode === 'basic') return '';

        let context = '\n\nCONTEXTUAL DATABASE ACCESS:\n';
        
        if (contextMode === 'enhanced' || contextMode === 'full') {
            if (players.length > 0) {
                context += `\n📊 PLAYER DATABASE (${players.length} active):\n`;
                context += players.slice(0, contextMode === 'full' ? 30 : 10).map(p => 
                    `- ${p.name} (${p.position}, ${p.age}y) | ${p.current_club} | €${p.market_value}M | Watch: ${p.watch_status || 'None'}`
                ).join('\n');
            }

            if (reports.length > 0) {
                context += `\n\n📋 RECENT SCOUTING REPORTS (${reports.length} available):\n`;
                context += reports.slice(0, contextMode === 'full' ? 20 : 8).map(r => 
                    `- ${r.player_name}: ${r.overall_rating}/10 | ${r.recommendation} | Technical: ${r.technical_rating}/10 | "${r.strengths?.substring(0, 80)}"`
                ).join('\n');
            }

            if (contextMode === 'full' && projections.length > 0) {
                context += `\n\n📈 PLAYER PROJECTIONS (${projections.length} analyzed):\n`;
                context += projections.slice(0, 10).map(p => 
                    `- ${p.player_name}: ${p.potential_trajectory} | Peak: ${p.peak_potential_rating}/10 in ${p.years_to_peak}y | Risks: ${p.risk_factors?.slice(0, 2).join(', ') || 'None'}`
                ).join('\n');
            }
        }

        return context;
    };

    const handleSend = async () => {
        if (!input.trim() || isLoading || !canQuery) return;

        const userMessage = { role: 'user', content: input.trim() };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            // Increment usage count for free users
            if (!hasAccess && user) {
                const newCount = usageCount + 1;
                await base44.auth.updateMe({
                    console_usage_count: newCount
                });
                setUser({ ...user, console_usage_count: newCount });
            }

            const conversationContext = messages.slice(-6).map(m => 
                `${m.role === 'user' ? 'Coach' : 'Scout AI'}: ${m.content}`
            ).join('\n\n');
            
            const contextData = buildContextData();
            
            const prompt = `You are Football Scout AI, an elite scouting and tactical intelligence engine with direct database access.

CORE RULES:
- Provide direct, concrete scouting insights using available data
- No reflective logic: do NOT describe your reasoning process
- Do NOT say "as an AI", "I think", "my reasoning"
- Output should be concise, tactical, professional
- When relevant data exists, reference specific players, stats, and reports
- If asked about specific players in the database, provide detailed analysis
- Focus on actionable intelligence: players, tactics, metrics, decisions

${contextData}

${conversationContext ? `\nRECENT CONVERSATION:\n${conversationContext}\n\n` : ''}Coach: ${userMessage.content}

Scout AI:`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt
            });

            const aiMessage = { role: 'assistant', content: response };
            setMessages(prev => [...prev, aiMessage]);
        } catch (error) {
            const errorMessage = { role: 'assistant', content: '⚠️ Connection error. Please try again.' };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col overflow-hidden">
            {/* Enhanced header with context controls */}
            <div className="flex-shrink-0 border-b border-slate-800 bg-slate-900/95 backdrop-blur-lg px-4 py-3 sm:px-6 sm:py-4">
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 sm:gap-3">
                        <Terminal className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
                        <div>
                            <h1 className="text-lg sm:text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                                Tactical Console Pro
                            </h1>
                            <p className="hidden sm:block text-slate-400 text-xs">
                                AI-powered insights with live database integration
                            </p>
                        </div>
                    </div>
                    {messages.length > 0 && (
                        <Button
                            onClick={() => setMessages([])}
                            variant="ghost"
                            size="sm"
                            className="text-slate-500 hover:text-slate-300"
                        >
                            <Trash2 className="w-4 h-4" />
                        </Button>
                    )}
                </div>

                {/* Usage counter for free users */}
                {!hasAccess && (
                    <div className="mb-2">
                        <Badge className={remainingQueries > 2 ? 'bg-cyan-500/20 text-cyan-400' : remainingQueries > 0 ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'}>
                            {remainingQueries} of {usageLimit} free queries remaining this month
                        </Badge>
                        {remainingQueries === 0 && (
                            <Button
                                onClick={() => window.open('https://pay.gocardless.com/BRT00048926VJAS', '_blank')}
                                size="sm"
                                className="ml-2 bg-gradient-to-r from-purple-500 to-blue-600"
                            >
                                <Sparkles className="w-3 h-3 mr-1" />
                                Upgrade to Premium
                            </Button>
                        )}
                    </div>
                )}

                {/* Context mode selector */}
                <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-slate-500 text-xs">Context:</span>
                    <Button
                        onClick={() => setContextMode('basic')}
                        size="sm"
                        variant={contextMode === 'basic' ? 'default' : 'ghost'}
                        className={contextMode === 'basic' ? 'bg-slate-700 text-white' : 'text-slate-400'}
                    >
                        <Sparkles className="w-3 h-3 mr-1" />
                        Basic
                    </Button>
                    <Button
                        onClick={() => setContextMode('enhanced')}
                        size="sm"
                        variant={contextMode === 'enhanced' ? 'default' : 'ghost'}
                        className={contextMode === 'enhanced' ? 'bg-green-600 text-white' : 'text-slate-400'}
                    >
                        <Database className="w-3 h-3 mr-1" />
                        Enhanced
                    </Button>
                    <Button
                        onClick={() => setContextMode('full')}
                        size="sm"
                        variant={contextMode === 'full' ? 'default' : 'ghost'}
                        className={contextMode === 'full' ? 'bg-cyan-600 text-white' : 'text-slate-400'}
                    >
                        <TrendingUp className="w-3 h-3 mr-1" />
                        Full
                    </Button>
                    {contextMode !== 'basic' && (
                        <Badge className="bg-green-500/20 text-green-400 text-xs">
                            <Database className="w-3 h-3 mr-1" />
                            {players.length} players • {reports.length} reports
                            {contextMode === 'full' && ` • ${projections.length} projections`}
                        </Badge>
                    )}
                </div>
            </div>

            {/* Console messages */}
            <div 
                ref={consoleRef}
                className="flex-1 overflow-y-auto px-4 py-4 sm:px-6 space-y-3 sm:space-y-4"
                style={{ WebkitOverflowScrolling: 'touch' }}
            >
                {messages.length === 0 && (
                    <div className="h-full flex items-center justify-center">
                        <div className="text-center space-y-4 px-4 max-w-2xl">
                            <Terminal className="w-12 h-12 sm:w-16 sm:h-16 text-green-400 mx-auto opacity-50" />
                            <div>
                                <p className="text-slate-400 text-sm mb-3">Try these advanced queries:</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                                    <button 
                                        onClick={() => setInput("Who are our highest-rated prospects?")}
                                        className="bg-slate-800/30 hover:bg-slate-800/50 rounded p-2 text-slate-400 hover:text-cyan-400 text-xs text-left transition-colors cursor-pointer"
                                    >
                                        <FileText className="w-3 h-3 inline mr-1 text-cyan-400" />
                                        "Who are our highest-rated prospects?"
                                    </button>
                                    <button 
                                        onClick={() => setInput("Analyse the trajectory of the youngest players")}
                                        className="bg-slate-800/30 hover:bg-slate-800/50 rounded p-2 text-slate-400 hover:text-green-400 text-xs text-left transition-colors cursor-pointer"
                                    >
                                        <TrendingUp className="w-3 h-3 inline mr-1 text-green-400" />
                                        "Analyse the trajectory of youngest players"
                                    </button>
                                    <button 
                                        onClick={() => setInput("Compare our wingers' technical ratings")}
                                        className="bg-slate-800/30 hover:bg-slate-800/50 rounded p-2 text-slate-400 hover:text-purple-400 text-xs text-left transition-colors cursor-pointer"
                                    >
                                        <Database className="w-3 h-3 inline mr-1 text-purple-400" />
                                        "Compare our wingers' technical ratings"
                                    </button>
                                    <button 
                                        onClick={() => setInput("Best young strikers under €5M?")}
                                        className="bg-slate-800/30 hover:bg-slate-800/50 rounded p-2 text-slate-400 hover:text-amber-400 text-xs text-left transition-colors cursor-pointer"
                                    >
                                        <Sparkles className="w-3 h-3 inline mr-1 text-amber-400" />
                                        "Best young strikers under €5M?"
                                    </button>
                                </div>
                                <p className="text-slate-500 text-xs mt-4">
                                    {contextMode === 'basic' && '💡 Enable Enhanced/Full context for database access'}
                                    {contextMode === 'enhanced' && '✅ Enhanced mode: Access to players & reports'}
                                    {contextMode === 'full' && '🚀 Full mode: Complete database + projections'}
                                </p>
                            </div>
                        </div>
                    </div>
                )}

                {messages.map((msg, idx) => (
                    <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`${msg.role === 'user' ? 'text-green-400' : 'text-cyan-400'}`}
                    >
                        <div className="font-semibold text-xs mb-1">
                            {msg.role === 'user' ? '→ Coach' : '← Scout AI'}
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 text-slate-200 text-sm sm:text-base whitespace-pre-wrap break-words">
                            {msg.content}
                        </div>
                    </motion.div>
                ))}

                {isLoading && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-cyan-400"
                    >
                        <div className="font-semibold text-xs mb-1">← Scout AI</div>
                        <div className="bg-slate-800/50 rounded-lg p-3 flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span className="text-slate-400 text-sm">Analyzing...</span>
                        </div>
                    </motion.div>
                )}
            </div>

            {/* Mobile-optimized input */}
            <div className="flex-shrink-0 border-t border-slate-800 bg-slate-900/95 backdrop-blur-lg p-3 sm:p-4">
                {!canQuery && (
                    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-3 text-center">
                        <p className="text-red-400 text-sm font-semibold mb-2">Monthly Query Limit Reached</p>
                        <p className="text-slate-400 text-xs mb-3">You've used all 5 free queries this month. Upgrade to Premium for unlimited access.</p>
                        <Button
                            onClick={() => window.open('https://pay.gocardless.com/BRT00048926VJAS', '_blank')}
                            size="sm"
                            className="bg-gradient-to-r from-purple-500 to-blue-600"
                        >
                            <Sparkles className="w-3 h-3 mr-1" />
                            Upgrade Now - £99/month
                        </Button>
                    </div>
                )}
                <div className="flex gap-2">
                    <Textarea
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder={canQuery ? "Ask about tactics, players, formations..." : "Upgrade to Premium for unlimited queries"}
                        disabled={!canQuery}
                        className="bg-slate-800 border-slate-700 text-white resize-none text-sm sm:text-base disabled:opacity-50 disabled:cursor-not-allowed"
                        rows={2}
                    />
                    <Button
                        onClick={handleSend}
                        disabled={!input.trim() || isLoading || !canQuery}
                        className="bg-gradient-to-r from-green-500 to-emerald-600 px-4 sm:px-6 self-end disabled:opacity-50"
                    >
                        {isLoading ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                            <Send className="w-4 h-4 sm:w-5 sm:h-5" />
                        )}
                    </Button>
                </div>
            </div>
        </div>
    );
}