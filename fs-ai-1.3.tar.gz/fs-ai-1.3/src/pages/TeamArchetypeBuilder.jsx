import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Users, Sparkles, Target, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import ArchetypeSelector from '../components/archetype-builder/ArchetypeSelector';
import PlayerSuggestions from '../components/archetype-builder/PlayerSuggestions';
import TeamComposition from '../components/archetype-builder/TeamComposition';

export default function TeamArchetypeBuilder() {
    const [selectedArchetype, setSelectedArchetype] = useState(null);
    const [selectedPlayers, setSelectedPlayers] = useState([]);
    const [suggestions, setSuggestions] = useState(null);
    const [teamFit, setTeamFit] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players-scored'],
        queryFn: () => base44.entities.Player.list('-fsai_proprietary_score', 500)
    });

    const scoredPlayers = players.filter(p => p.fsai_proprietary_score);

    const analyzeTeamFit = async () => {
        if (selectedPlayers.length < 5) {
            toast.error('Select at least 5 players to analyze team fit');
            return;
        }

        setIsAnalyzing(true);
        toast.loading('Analyzing team chemistry...', { id: 'team-fit' });

        try {
            const prompt = `You are the FS-AI Team Chemistry Analyzer. Analyze this squad for tactical cohesion and fit.

SELECTED ARCHETYPE: ${selectedArchetype.name}
Style: ${selectedArchetype.description}
Formation: ${selectedArchetype.formation}

SELECTED PLAYERS (${selectedPlayers.length}):
${selectedPlayers.map((p, i) => `
${i + 1}. ${p.name} - ${p.position} (FS-AI: ${p.fsai_proprietary_score})
   - Age: ${p.age} | Club: ${p.current_club}
   - Style: ${JSON.stringify(p.playing_style || {})}
   - Tactical Roles: ${p.tactical_roles?.join(', ') || 'N/A'}
`).join('\n')}

Analyze:
1. Overall Team Fit Score (0-100): How well does this squad execute the archetype?
2. Positional Balance (0-100): Coverage across all positions
3. Tactical Cohesion (0-100): Do playing styles complement each other?
4. Experience Mix (0-100): Age diversity and leadership
5. Chemistry Potential (0-100): Likelihood of players meshing well

Also provide:
- Key Strengths: What this squad does exceptionally well
- Weak Points: What areas need improvement
- Missing Profiles: What type of players would complete the squad
- Recommended Adjustments: Specific changes to improve fit`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        overall_team_fit: { type: "number" },
                        positional_balance: { type: "number" },
                        tactical_cohesion: { type: "number" },
                        experience_mix: { type: "number" },
                        chemistry_potential: { type: "number" },
                        key_strengths: {
                            type: "array",
                            items: { type: "string" }
                        },
                        weak_points: {
                            type: "array",
                            items: { type: "string" }
                        },
                        missing_profiles: {
                            type: "array",
                            items: { type: "string" }
                        },
                        recommended_adjustments: { type: "string" },
                        tactical_analysis: { type: "string" }
                    }
                }
            });

            setTeamFit(response);
            toast.success('Team analysis complete!', { id: 'team-fit' });
        } catch (error) {
            console.error('Team fit analysis failed:', error);
            toast.error('Failed to analyze team fit', { id: 'team-fit' });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const addPlayer = (player) => {
        if (selectedPlayers.find(p => p.id === player.id)) {
            toast.error('Player already selected');
            return;
        }
        setSelectedPlayers([...selectedPlayers, player]);
        setTeamFit(null);
    };

    const removePlayer = (playerId) => {
        setSelectedPlayers(selectedPlayers.filter(p => p.id !== playerId));
        setTeamFit(null);
    };

    return (
        <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Team Archetype Builder
                    </h1>
                    <p className="text-slate-400">Define playing style, get AI-powered player suggestions, simulate team chemistry</p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2">
                                <Users className="w-5 h-5 text-cyan-400" />
                                <span className="text-slate-400 text-sm">Available Players</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{scoredPlayers.length}</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2">
                                <Target className="w-5 h-5 text-purple-400" />
                                <span className="text-slate-400 text-sm">Selected</span>
                            </div>
                            <p className="text-3xl font-bold text-white">{selectedPlayers.length}</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2">
                                <Sparkles className="w-5 h-5 text-amber-400" />
                                <span className="text-slate-400 text-sm">Archetype</span>
                            </div>
                            <p className="text-lg font-bold text-white truncate">
                                {selectedArchetype?.name || 'Not Selected'}
                            </p>
                        </CardContent>
                    </Card>
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2">
                                <TrendingUp className="w-5 h-5 text-emerald-400" />
                                <span className="text-slate-400 text-sm">Team Fit</span>
                            </div>
                            <p className="text-3xl font-bold text-white">
                                {teamFit ? teamFit.overall_team_fit : '--'}
                            </p>
                        </CardContent>
                    </Card>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left: Archetype Selection */}
                    <div className="lg:col-span-1">
                        <ArchetypeSelector
                            selectedArchetype={selectedArchetype}
                            onSelectArchetype={(archetype) => {
                                setSelectedArchetype(archetype);
                                setTeamFit(null);
                            }}
                            onGenerateSuggestions={(suggestions) => setSuggestions(suggestions)}
                            players={scoredPlayers}
                        />
                    </div>

                    {/* Right: Suggestions & Team */}
                    <div className="lg:col-span-2 space-y-6">
                        {selectedArchetype && (
                            <>
                                <PlayerSuggestions
                                    suggestions={suggestions}
                                    selectedPlayers={selectedPlayers}
                                    onAddPlayer={addPlayer}
                                />

                                <TeamComposition
                                    selectedPlayers={selectedPlayers}
                                    selectedArchetype={selectedArchetype}
                                    teamFit={teamFit}
                                    onRemovePlayer={removePlayer}
                                    onAnalyze={analyzeTeamFit}
                                    isAnalyzing={isAnalyzing}
                                />
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}