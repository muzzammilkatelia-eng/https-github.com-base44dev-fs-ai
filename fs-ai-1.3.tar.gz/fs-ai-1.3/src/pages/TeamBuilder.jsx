import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import PremiumGate from '../components/PremiumGate';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Users, DollarSign, Target, TrendingUp, AlertTriangle, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function TeamBuilder() {
    const [formation, setFormation] = useState('4-3-3');
    const [budget, setBudget] = useState(100);
    const [squad, setSquad] = useState(null);
    const [isBuilding, setIsBuilding] = useState(false);

    const { data: players = [] } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list()
    });

    const { data: reports = [] } = useQuery({
        queryKey: ['reports'],
        queryFn: () => base44.entities.ScoutingReport.list()
    });

    const formations = [
        '4-3-3',
        '4-4-2',
        '4-2-3-1',
        '3-5-2',
        '3-4-3',
        '5-3-2',
        '4-1-4-1'
    ];

    const buildSquad = async () => {
        setIsBuilding(true);
        toast.loading('AI building your squad...', { id: 'squad-builder' });

        try {
            // Prepare player data with reports
            const playerData = players.map(player => {
                const playerReports = reports.filter(r => 
                    r.player_name?.toLowerCase() === player.name?.toLowerCase()
                );
                
                return {
                    name: player.name,
                    age: player.age,
                    position: player.position,
                    secondary_positions: player.secondary_positions || [],
                    current_club: player.current_club,
                    market_value: player.market_value || 0,
                    physical_attributes: player.physical_attributes,
                    playing_style: player.playing_style,
                    latest_rating: playerReports[0]?.overall_rating || 0,
                    injury_prone_score: player.injury_prone_score || 0
                };
            }).filter(p => p.market_value > 0);

            const prompt = `Build an optimal football squad with the following constraints:

FORMATION: ${formation}
BUDGET: €${budget}M total
AVAILABLE PLAYERS: ${playerData.length} players

PLAYER DATABASE (first 50):
${playerData.slice(0, 50).map((p, i) => `
${i + 1}. ${p.name} - ${p.position} (Age: ${p.age})
   Value: €${p.market_value}M | Rating: ${p.latest_rating}/10
   Style: ${JSON.stringify(p.playing_style)}
   Injury Risk: ${p.injury_prone_score}/100
   Secondary Positions: ${p.secondary_positions.join(', ') || 'None'}
`).join('\n')}

BUILD A COMPLETE SQUAD:
1. Starting XI (11 players fitting ${formation})
2. Bench (7 substitutes for tactical flexibility)
3. Stay within €${budget}M budget
4. Balance youth and experience
5. Consider player compatibility and tactical roles
6. Minimize injury risks
7. Ensure proper position coverage

PROVIDE:
- Complete squad list with positions
- Total squad value
- Tactical strengths
- Potential weaknesses
- Chemistry assessment
- Alternative formations that would work`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        starting_xi: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    formation_role: { type: "string" },
                                    market_value: { type: "number" },
                                    age: { type: "number" },
                                    rating: { type: "number" },
                                    key_attributes: { type: "string" }
                                }
                            }
                        },
                        bench: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    player_name: { type: "string" },
                                    position: { type: "string" },
                                    tactical_purpose: { type: "string" },
                                    market_value: { type: "number" }
                                }
                            }
                        },
                        total_squad_value: { type: "number" },
                        remaining_budget: { type: "number" },
                        tactical_analysis: {
                            type: "object",
                            properties: {
                                formation_fit: { type: "number" },
                                team_balance: { type: "number" },
                                chemistry_score: { type: "number" },
                                youth_vs_experience: { type: "string" }
                            }
                        },
                        strengths: { type: "array", items: { type: "string" } },
                        weaknesses: { type: "array", items: { type: "string" } },
                        key_partnerships: { type: "array", items: { type: "string" } },
                        alternative_formations: { type: "array", items: { type: "string" } },
                        tactical_advice: { type: "string" }
                    }
                }
            });

            setSquad(response);
            toast.success('Squad built successfully!', { id: 'squad-builder' });
        } catch (error) {
            console.error('Squad building failed:', error);
            toast.error('Failed to build squad', { id: 'squad-builder' });
        } finally {
            setIsBuilding(false);
        }
    };

    const getScoreColor = (score) => {
        if (score >= 80) return 'text-emerald-400';
        if (score >= 60) return 'text-cyan-400';
        if (score >= 40) return 'text-amber-400';
        return 'text-red-400';
    };

    return (
        <div className="min-h-screen py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Team Builder
                    </h1>
                    <p className="text-slate-400">
                        Build your optimal squad with AI-powered player selection
                    </p>
                </div>

                {/* Configuration */}
                <Card className="bg-slate-900/50 border-slate-800 mb-6">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Target className="w-5 h-5 text-cyan-400" />
                            Squad Configuration
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-3 gap-6">
                            <div>
                                <Label className="text-slate-300 mb-2 block">Formation</Label>
                                <Select value={formation} onValueChange={setFormation}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {formations.map(f => (
                                            <SelectItem key={f} value={f}>{f}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div>
                                <Label className="text-slate-300 mb-2 block">
                                    Budget (€M)
                                </Label>
                                <Input
                                    type="number"
                                    value={budget}
                                    onChange={(e) => setBudget(Number(e.target.value))}
                                    className="bg-slate-800 border-slate-700 text-white"
                                    min={10}
                                    max={1000}
                                />
                            </div>

                            <div className="flex items-end">
                                <Button
                                    onClick={buildSquad}
                                    disabled={isBuilding}
                                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                                >
                                    {isBuilding ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Building Squad...
                                        </>
                                    ) : (
                                        <>
                                            <Sparkles className="w-4 h-4 mr-2" />
                                            Build Squad
                                        </>
                                    )}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {squad && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Squad Overview */}
                        <div className="grid md:grid-cols-4 gap-4">
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-slate-400 text-sm">Total Value</p>
                                            <p className="text-2xl font-bold text-amber-400">
                                                €{squad.total_squad_value}M
                                            </p>
                                        </div>
                                        <DollarSign className="w-8 h-8 text-amber-400" />
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-slate-400 text-sm">Budget Left</p>
                                            <p className="text-2xl font-bold text-emerald-400">
                                                €{squad.remaining_budget}M
                                            </p>
                                        </div>
                                        <TrendingUp className="w-8 h-8 text-emerald-400" />
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-slate-400 text-sm">Chemistry</p>
                                            <p className={`text-2xl font-bold ${getScoreColor(squad.tactical_analysis.chemistry_score)}`}>
                                                {squad.tactical_analysis.chemistry_score}%
                                            </p>
                                        </div>
                                        <Users className="w-8 h-8 text-purple-400" />
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardContent className="pt-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-slate-400 text-sm">Formation Fit</p>
                                            <p className={`text-2xl font-bold ${getScoreColor(squad.tactical_analysis.formation_fit)}`}>
                                                {squad.tactical_analysis.formation_fit}%
                                            </p>
                                        </div>
                                        <Target className="w-8 h-8 text-cyan-400" />
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Starting XI */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Users className="w-5 h-5 text-cyan-400" />
                                    Starting XI - {formation}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {squad.starting_xi?.map((player, idx) => (
                                        <div
                                            key={idx}
                                            className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <div>
                                                    <h4 className="text-white font-semibold">{player.player_name}</h4>
                                                    <p className="text-cyan-400 text-sm">{player.formation_role}</p>
                                                </div>
                                                <Badge className="bg-amber-500/20 text-amber-400">
                                                    €{player.market_value}M
                                                </Badge>
                                            </div>
                                            <div className="space-y-1 text-sm">
                                                <div className="flex justify-between">
                                                    <span className="text-slate-400">Age</span>
                                                    <span className="text-white">{player.age}y</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-slate-400">Rating</span>
                                                    <Badge className="bg-emerald-500/20 text-emerald-400">
                                                        {player.rating}/10
                                                    </Badge>
                                                </div>
                                                <p className="text-slate-300 text-xs mt-2">
                                                    {player.key_attributes}
                                                </p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Bench */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Bench & Substitutes</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                                    {squad.bench?.map((player, idx) => (
                                        <div
                                            key={idx}
                                            className="bg-slate-800/50 rounded-lg p-3"
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <div>
                                                    <h5 className="text-white font-medium text-sm">{player.player_name}</h5>
                                                    <p className="text-slate-400 text-xs">{player.position}</p>
                                                </div>
                                                <span className="text-amber-400 text-xs">€{player.market_value}M</span>
                                            </div>
                                            <p className="text-slate-300 text-xs">{player.tactical_purpose}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Analysis */}
                        <div className="grid md:grid-cols-2 gap-6">
                            {/* Strengths */}
                            <Card className="bg-emerald-500/10 border-emerald-500/30">
                                <CardHeader>
                                    <CardTitle className="text-emerald-400 flex items-center gap-2">
                                        <TrendingUp className="w-5 h-5" />
                                        Squad Strengths
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {squad.strengths?.map((strength, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-emerald-400 mt-0.5">✓</span>
                                                {strength}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>

                            {/* Weaknesses */}
                            <Card className="bg-amber-500/10 border-amber-500/30">
                                <CardHeader>
                                    <CardTitle className="text-amber-400 flex items-center gap-2">
                                        <AlertTriangle className="w-5 h-5" />
                                        Potential Weaknesses
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ul className="space-y-2">
                                        {squad.weaknesses?.map((weakness, idx) => (
                                            <li key={idx} className="text-slate-300 text-sm flex items-start gap-2">
                                                <span className="text-amber-400 mt-0.5">⚠</span>
                                                {weakness}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Tactical Insights */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white">Tactical Insights</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <h4 className="text-cyan-400 font-semibold mb-2">Key Partnerships</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {squad.key_partnerships?.map((partnership, idx) => (
                                            <Badge key={idx} className="bg-purple-500/20 text-purple-400">
                                                {partnership}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <h4 className="text-cyan-400 font-semibold mb-2">Alternative Formations</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {squad.alternative_formations?.map((form, idx) => (
                                            <Badge key={idx} variant="outline" className="text-slate-300">
                                                {form}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <h4 className="text-cyan-400 font-semibold mb-2">Team Balance</h4>
                                    <p className="text-slate-300 text-sm">
                                        {squad.tactical_analysis.youth_vs_experience}
                                    </p>
                                </div>

                                <div className="bg-slate-800/50 rounded-lg p-4">
                                    <h4 className="text-white font-semibold mb-2">Manager's Advice</h4>
                                    <p className="text-slate-300 text-sm leading-relaxed">
                                        {squad.tactical_advice}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}

                {!squad && !isBuilding && (
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="py-12">
                            <div className="text-center">
                                <Users className="w-16 h-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                                <h3 className="text-white text-xl font-semibold mb-2">
                                    Ready to Build Your Squad?
                                </h3>
                                <p className="text-slate-400 mb-6">
                                    Select your formation and budget, then let AI build the perfect team
                                </p>
                                <div className="flex justify-center gap-4 text-sm text-slate-500">
                                    <div className="flex items-center gap-2">
                                        <Target className="w-4 h-4" />
                                        <span>AI-Optimized</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <DollarSign className="w-4 h-4" />
                                        <span>Budget-Aware</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4" />
                                        <span>Tactical Balance</span>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}