import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, TrendingUp, Target, Sparkles } from 'lucide-react';
import PlayerManagementGrid from '../components/team-management/PlayerManagementGrid';
import TeamOverview from '../components/team-management/TeamOverview';
import AIAcquisitionSuggestions from '../components/team-management/AIAcquisitionSuggestions';
import AIScoutAssistant from '../components/strategic-planning/AIScoutAssistant';
import PremiumGate from '../components/PremiumGate';

export default function TeamManagement() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                        <Users className="w-8 h-8 text-cyan-400" />
                        Team Management Hub
                    </h1>
                    <p className="text-slate-400">
                        Comprehensive player database, squad overview, and AI-powered acquisition recommendations
                    </p>
                </div>

                <Tabs defaultValue="players" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4">
                        <TabsTrigger value="players" className="flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            Player Database
                        </TabsTrigger>
                        <TabsTrigger value="team" className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Team Overview
                        </TabsTrigger>
                        <TabsTrigger value="scout" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            AI Scout
                        </TabsTrigger>
                        <TabsTrigger value="ai" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            AI Acquisitions
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="players">
                        <PlayerManagementGrid />
                    </TabsContent>

                    <TabsContent value="team">
                        <PremiumGate level="Club Pro">
                            <TeamOverview />
                        </PremiumGate>
                    </TabsContent>

                    <TabsContent value="scout">
                        <AIScoutAssistant context="team" />
                    </TabsContent>

                    <TabsContent value="ai">
                        <PremiumGate level="Elite Club">
                            <AIAcquisitionSuggestions />
                        </PremiumGate>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}