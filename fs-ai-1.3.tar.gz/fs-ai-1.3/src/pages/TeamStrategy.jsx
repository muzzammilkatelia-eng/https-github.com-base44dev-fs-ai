import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Target, Eye, Save, Trash2, CheckCircle, Plus, Info, Sparkles, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import FormationDiagram from '../components/strategic-planning/FormationDiagram';
import TacticalTooltips, { TACTICAL_INFO } from '../components/strategic-planning/TacticalTooltips';
import StrategyOverview from '../components/strategic-planning/StrategyOverview';
import AITacticalAdvisor from '../components/strategic-planning/AITacticalAdvisor';

const FORMATIONS = ['4-3-3', '4-2-3-1', '3-5-2', '4-4-2', '3-4-3', '5-3-2', '4-1-4-1', '3-4-2-1'];
const PLAYING_STYLES = ['Possession', 'Counter-Attack', 'High Press', 'Direct', 'Balanced', 'Defensive'];
const PRESSING_LEVELS = ['Very High', 'High', 'Medium', 'Low'];
const TEMPOS = ['Very Fast', 'Fast', 'Medium', 'Slow'];
const WIDTHS = ['Very Wide', 'Wide', 'Balanced', 'Narrow'];
const PASSING_STYLES = ['Short', 'Mixed', 'Long'];

const SelectWithTooltip = ({ label, value, options, onChange, category }) => {
    const info = TACTICAL_INFO[category];
    const optionInfo = info?.options[value];

    return (
        <div>
            <div className="flex items-center gap-2 mb-2">
                <label className="text-slate-300 text-sm">{label}</label>
                <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Info className="w-4 h-4 text-slate-500 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent side="right" className="max-w-xs bg-slate-800 border-slate-700">
                            <p className="text-sm">{optionInfo?.description || 'Select an option to see details'}</p>
                        </TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            </div>
            <Select value={value} onValueChange={onChange}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    {options.map(opt => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
    );
};

export default function TeamStrategy() {
    const [isCreating, setIsCreating] = useState(false);
    const [selectedStrategy, setSelectedStrategy] = useState(null);
    const [formData, setFormData] = useState({
        strategy_name: '',
        formation: '4-3-3',
        playing_style: 'Balanced',
        pressing_intensity: 'Medium',
        defensive_line: 'Medium',
        tempo: 'Medium',
        width: 'Balanced',
        passing_style: 'Mixed',
        notes: ''
    });

    const queryClient = useQueryClient();

    const { data: strategies = [], isLoading } = useQuery({
        queryKey: ['strategies'],
        queryFn: () => base44.entities.TeamStrategy.list()
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.TeamStrategy.create({ ...data, active: false }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy created successfully');
            setIsCreating(false);
            resetForm();
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.TeamStrategy.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy updated');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.TeamStrategy.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy deleted');
            setSelectedStrategy(null);
        }
    });

    const activateMutation = useMutation({
        mutationFn: async (id) => {
            // Deactivate all, then activate selected
            for (const s of strategies) {
                if (s.active) {
                    await base44.entities.TeamStrategy.update(s.id, { active: false });
                }
            }
            await base44.entities.TeamStrategy.update(id, { active: true });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['strategies'] });
            toast.success('Strategy activated');
        }
    });

    const resetForm = () => {
        setFormData({
            strategy_name: '',
            formation: '4-3-3',
            playing_style: 'Balanced',
            pressing_intensity: 'Medium',
            defensive_line: 'Medium',
            tempo: 'Medium',
            width: 'Balanced',
            passing_style: 'Mixed',
            notes: ''
        });
    };

    const activeStrategy = strategies.find(s => s.active);

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-6">
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-white mb-3">Team Strategy Hub</h1>
                    <p className="text-slate-400 text-lg">
                        Create, manage, and analyze tactical configurations with visual formations
                    </p>
                </div>

                <Tabs defaultValue="overview" className="space-y-6">
                    <TabsList className="bg-slate-900 border border-slate-800 grid grid-cols-4">
                        <TabsTrigger value="overview" className="flex items-center gap-2">
                            <Eye className="w-4 h-4" />
                            Overview
                        </TabsTrigger>
                        <TabsTrigger value="create" className="flex items-center gap-2">
                            <Plus className="w-4 h-4" />
                            Create Strategy
                        </TabsTrigger>
                        <TabsTrigger value="manage" className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Manage ({strategies.length})
                        </TabsTrigger>
                        <TabsTrigger value="advisor" className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            AI Advisor
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview">
                        <StrategyOverview />
                    </TabsContent>

                    <TabsContent value="create">
                        <div className="grid lg:grid-cols-2 gap-6">
                            {/* Form */}
                            <Card className="bg-slate-900/50 border-slate-800">
                                <CardHeader>
                                    <CardTitle className="text-white flex items-center gap-2">
                                        <Plus className="w-5 h-5 text-cyan-400" />
                                        Create New Strategy
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Strategy Name *</label>
                                        <Input
                                            value={formData.strategy_name}
                                            onChange={(e) => setFormData({ ...formData, strategy_name: e.target.value })}
                                            placeholder="e.g., Home High Press, Away Counter"
                                            className="bg-slate-800 border-slate-700 text-white"
                                        />
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Formation</label>
                                        <Select value={formData.formation} onValueChange={(v) => setFormData({ ...formData, formation: v })}>
                                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {FORMATIONS.map(f => (
                                                    <SelectItem key={f} value={f}>{f}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <SelectWithTooltip
                                            label="Playing Style"
                                            value={formData.playing_style}
                                            options={PLAYING_STYLES}
                                            onChange={(v) => setFormData({ ...formData, playing_style: v })}
                                            category="playing_style"
                                        />
                                        <SelectWithTooltip
                                            label="Pressing Intensity"
                                            value={formData.pressing_intensity}
                                            options={PRESSING_LEVELS}
                                            onChange={(v) => setFormData({ ...formData, pressing_intensity: v })}
                                            category="pressing_intensity"
                                        />
                                        <SelectWithTooltip
                                            label="Tempo"
                                            value={formData.tempo}
                                            options={TEMPOS}
                                            onChange={(v) => setFormData({ ...formData, tempo: v })}
                                            category="tempo"
                                        />
                                        <SelectWithTooltip
                                            label="Width"
                                            value={formData.width}
                                            options={WIDTHS}
                                            onChange={(v) => setFormData({ ...formData, width: v })}
                                            category="width"
                                        />
                                        <SelectWithTooltip
                                            label="Defensive Line"
                                            value={formData.defensive_line}
                                            options={PRESSING_LEVELS}
                                            onChange={(v) => setFormData({ ...formData, defensive_line: v })}
                                            category="defensive_line"
                                        />
                                        <SelectWithTooltip
                                            label="Passing Style"
                                            value={formData.passing_style}
                                            options={PASSING_STYLES}
                                            onChange={(v) => setFormData({ ...formData, passing_style: v })}
                                            category="passing_style"
                                        />
                                    </div>

                                    <div>
                                        <label className="text-slate-300 text-sm mb-2 block">Tactical Notes</label>
                                        <Textarea
                                            value={formData.notes}
                                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                            placeholder="Additional tactical instructions, key player roles, set piece responsibilities..."
                                            className="bg-slate-800 border-slate-700 text-white h-24"
                                        />
                                    </div>

                                    <div className="flex gap-3">
                                        <Button
                                            onClick={() => createMutation.mutate(formData)}
                                            disabled={!formData.strategy_name || createMutation.isPending}
                                            className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                                        >
                                            {createMutation.isPending ? (
                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                                <Save className="w-4 h-4 mr-2" />
                                            )}
                                            Save Strategy
                                        </Button>
                                        <Button
                                            onClick={resetForm}
                                            variant="outline"
                                            className="border-slate-700 text-slate-300"
                                        >
                                            Reset
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Live Formation Preview */}
                            <div className="space-y-4">
                                <FormationDiagram formation={formData.formation} showDetails={true} />
                                
                                {/* Quick Summary */}
                                <Card className="bg-slate-900/50 border-slate-800">
                                    <CardContent className="py-4">
                                        <h4 className="text-white font-semibold mb-3">Configuration Summary</h4>
                                        <div className="flex flex-wrap gap-2">
                                            <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                                                {formData.formation}
                                            </Badge>
                                            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                                {formData.playing_style}
                                            </Badge>
                                            <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                {formData.pressing_intensity} Press
                                            </Badge>
                                            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                                {formData.tempo} Tempo
                                            </Badge>
                                            <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30">
                                                {formData.width}
                                            </Badge>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="manage">
                        <div className="grid lg:grid-cols-3 gap-6">
                            {/* Strategy List */}
                            <Card className="bg-slate-900/50 border-slate-800 lg:col-span-1">
                                <CardHeader>
                                    <CardTitle className="text-white">Saved Strategies</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {isLoading ? (
                                        <div className="text-center py-8 text-slate-500">Loading...</div>
                                    ) : strategies.length === 0 ? (
                                        <div className="text-center py-8 text-slate-500">
                                            No strategies saved yet
                                        </div>
                                    ) : (
                                        strategies.map((strategy, i) => (
                                            <motion.div
                                                key={strategy.id}
                                                initial={{ opacity: 0, x: -20 }}
                                                animate={{ opacity: 1, x: 0 }}
                                                transition={{ delay: i * 0.05 }}
                                                onClick={() => setSelectedStrategy(strategy)}
                                                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                                    selectedStrategy?.id === strategy.id
                                                        ? 'bg-cyan-500/10 border-cyan-500/50'
                                                        : strategy.active
                                                            ? 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-500/50'
                                                            : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                                                }`}
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <h4 className="text-white font-medium">{strategy.strategy_name}</h4>
                                                    {strategy.active && (
                                                        <Badge className="bg-emerald-500/20 text-emerald-400 text-xs">
                                                            <CheckCircle className="w-3 h-3 mr-1" />
                                                            Active
                                                        </Badge>
                                                    )}
                                                </div>
                                                <div className="flex gap-1 flex-wrap">
                                                    <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                                                        {strategy.formation}
                                                    </Badge>
                                                    <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                                                        {strategy.playing_style}
                                                    </Badge>
                                                </div>
                                            </motion.div>
                                        ))
                                    )}
                                </CardContent>
                            </Card>

                            {/* Selected Strategy Details */}
                            <div className="lg:col-span-2 space-y-4">
                                {selectedStrategy ? (
                                    <>
                                        <Card className="bg-slate-900/50 border-slate-800">
                                            <CardHeader>
                                                <div className="flex justify-between items-start">
                                                    <div>
                                                        <CardTitle className="text-white text-xl">
                                                            {selectedStrategy.strategy_name}
                                                        </CardTitle>
                                                        <p className="text-slate-400 text-sm mt-1">
                                                            {selectedStrategy.formation} · {selectedStrategy.playing_style}
                                                        </p>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        {!selectedStrategy.active && (
                                                            <Button
                                                                onClick={() => activateMutation.mutate(selectedStrategy.id)}
                                                                disabled={activateMutation.isPending}
                                                                className="bg-emerald-600 hover:bg-emerald-700"
                                                            >
                                                                <CheckCircle className="w-4 h-4 mr-2" />
                                                                Activate
                                                            </Button>
                                                        )}
                                                        <Button
                                                            onClick={() => deleteMutation.mutate(selectedStrategy.id)}
                                                            variant="ghost"
                                                            className="text-red-400 hover:text-red-300"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </div>
                                            </CardHeader>
                                        </Card>

                                        <div className="grid md:grid-cols-2 gap-4">
                                            <FormationDiagram formation={selectedStrategy.formation} />
                                            <Card className="bg-slate-900/50 border-slate-800">
                                                <CardHeader className="pb-2">
                                                    <CardTitle className="text-white text-lg">Configuration</CardTitle>
                                                </CardHeader>
                                                <CardContent className="space-y-3">
                                                    <div className="grid grid-cols-2 gap-3">
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Playing Style</p>
                                                            <p className="text-white font-medium">{selectedStrategy.playing_style}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Pressing</p>
                                                            <p className="text-white font-medium">{selectedStrategy.pressing_intensity}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Tempo</p>
                                                            <p className="text-white font-medium">{selectedStrategy.tempo}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Width</p>
                                                            <p className="text-white font-medium">{selectedStrategy.width}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Defensive Line</p>
                                                            <p className="text-white font-medium">{selectedStrategy.defensive_line}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-400 text-xs mb-1">Passing</p>
                                                            <p className="text-white font-medium">{selectedStrategy.passing_style}</p>
                                                        </div>
                                                    </div>
                                                    {selectedStrategy.notes && (
                                                        <div className="pt-3 border-t border-slate-700">
                                                            <p className="text-slate-400 text-xs mb-1">Notes</p>
                                                            <p className="text-slate-300 text-sm">{selectedStrategy.notes}</p>
                                                        </div>
                                                    )}
                                                </CardContent>
                                            </Card>
                                        </div>

                                        <TacticalTooltips strategy={selectedStrategy} />
                                    </>
                                ) : (
                                    <Card className="bg-slate-900/50 border-slate-800">
                                        <CardContent className="py-16 text-center">
                                            <Target className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                                            <h3 className="text-white text-xl font-semibold mb-2">Select a Strategy</h3>
                                            <p className="text-slate-400">
                                                Click on a strategy from the list to view details and manage it
                                            </p>
                                        </CardContent>
                                    </Card>
                                )}
                            </div>
                        </div>
                    </TabsContent>

                    <TabsContent value="advisor">
                        <AITacticalAdvisor />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}