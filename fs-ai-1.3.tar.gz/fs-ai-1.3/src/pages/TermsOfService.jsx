import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export default function TermsOfService() {
    return (
        <div className="min-h-screen py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-4xl font-bold text-white mb-6">Terms of Service</h1>
                <p className="text-slate-400 mb-8">Universal Master Version</p>

                <div className="space-y-6">
                    <Card className="bg-slate-900/50 border-slate-800">
                        <CardContent className="pt-6 prose prose-invert max-w-none">
                            <h2 className="text-2xl font-bold text-cyan-400 mb-4">2.1 Acceptance</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                By accessing any platform, users agree to these universal Terms of Service.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.2 Eligibility</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Platforms may be used by:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Children (with parental consent where required)</li>
                                <li>Parents and guardians</li>
                                <li>Educators</li>
                                <li>Institutional partners</li>
                                <li>General users accessing public content</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.3 User Responsibilities</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Users must:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Use platforms lawfully</li>
                                <li>Respect safeguarding rules</li>
                                <li>Not misuse AI educators</li>
                                <li>Not attempt to extract, reverse-engineer, or exploit AI systems</li>
                                <li>Not upload harmful, illegal, or abusive content</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.4 Platform Responsibilities</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">All platforms commit to:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Providing safe, accessible, inclusive digital environments</li>
                                <li>Maintaining safeguarding-first design</li>
                                <li>Ensuring data minimisation and privacy-by-default</li>
                                <li>Providing accurate, ethical, and responsible AI outputs</li>
                                <li>Maintaining uptime and service reliability where reasonably possible</li>
                            </ul>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.5 Prohibited Conduct</h2>
                            <p className="text-slate-300 leading-relaxed mb-2">Users may not:</p>
                            <ul className="text-slate-300 space-y-2 mb-4">
                                <li>Engage in harassment, abuse, or exploitation</li>
                                <li>Attempt to manipulate AI educators into unsafe behaviour</li>
                                <li>Circumvent security or safeguarding controls</li>
                                <li>Use platforms for commercial exploitation without permission</li>
                                <li><strong>Use the platform for gambling or any gambling-related activities</strong></li>
                            </ul>

                            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mt-4">
                                <h3 className="text-lg font-bold text-red-400 mb-2">Gambling Prohibition</h3>
                                <p className="text-slate-300 leading-relaxed">
                                    This application must not be used for gambling or any gambling-related activities. 
                                    Users found to be engaging in gambling through the app will be subject to immediate 
                                    account termination and permanent ban. Due to the commission structure of the platform, 
                                    charges associated with user activity prior to termination may still apply.
                                </p>
                            </div>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.6 Intellectual Property</h2>
                            <p className="text-slate-300 leading-relaxed mb-4">
                                All content, branding, frameworks, AI educator personas, and safeguarding-first systems are the intellectual property of Minimax Sustainable AI Ltd and Al Isa Institute.
                            </p>

                            <h2 className="text-2xl font-bold text-cyan-400 mb-4 mt-8">2.7 Termination</h2>
                            <p className="text-slate-300 leading-relaxed">
                                Platforms may restrict or terminate access where safeguarding or legal risks arise.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}