import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { TrendingUp, TrendingDown, DollarSign, Clock, Target, Search, Loader2, AlertCircle, ClipboardList } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import TaskForm from '../components/workflow/TaskForm';

export default function TransferMarket() {
    const [criteria, setCriteria] = useState({
        budget: '',
        position: '',
        minAge: '',
        maxAge: '',
        contractExpiry: '',
        league: '',
        additionalNotes: ''
    });

    const [analysis, setAnalysis] = useState(null);
    const [showTaskDialog, setShowTaskDialog] = useState(false);
    const [selectedPlayer, setSelectedPlayer] = useState(null);

    const analyzeMutation = useMutation({
        mutationFn: async (searchCriteria) => {
            const prompt = `You are an expert football transfer market analyst. Analyze the current transfer market based on these criteria:

**Budget**: ${searchCriteria.budget ? `€${searchCriteria.budget}M` : 'Not specified'}
**Position**: ${searchCriteria.position || 'Any'}
**Age Range**: ${searchCriteria.minAge || 'Any'} - ${searchCriteria.maxAge || 'Any'} years
**Contract Expiry**: ${searchCriteria.contractExpiry || 'Any'}
**Target League**: ${searchCriteria.league || 'Global'}
**Additional Requirements**: ${searchCriteria.additionalNotes || 'None'}

Provide a comprehensive transfer market analysis including:

1. **Market Trends**: Current state of the transfer market for this profile (supply/demand, pricing trends, competition level)

2. **Undervalued Players**: Identify 3-5 specific undervalued players who fit the criteria with:
   - Name, age, current club, position
   - Current market value and why they're undervalued
   - Key strengths and potential
   - Estimated transfer fee

3. **Transfer Fee Predictions**: Price ranges for different quality tiers (e.g., proven starter, high potential, rotation option)

4. **Contract Opportunities**: Players with contracts expiring soon:
   - Name, age, club, position
   - Contract expiry date
   - Free transfer or Bosman potential
   - Likelihood of renewal vs. departure

5. **Strategic Recommendations**: Best approach for this budget and profile (timing, negotiation strategy, alternative markets)

Use REAL market data, current player situations, and recent transfer precedents. Be specific with names, clubs, and figures.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        market_trends: {
                            type: "object",
                            properties: {
                                overview: { type: "string" },
                                supply_demand: { type: "string" },
                                pricing_trend: { type: "string" },
                                competition_level: { type: "string" }
                            }
                        },
                        undervalued_players: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    name: { type: "string" },
                                    age: { type: "number" },
                                    club: { type: "string" },
                                    position: { type: "string" },
                                    current_value: { type: "number" },
                                    undervalued_reason: { type: "string" },
                                    strengths: { type: "string" },
                                    estimated_fee: { type: "number" },
                                    value_delta: { type: "number" }
                                }
                            }
                        },
                        fee_predictions: {
                            type: "object",
                            properties: {
                                proven_starter: { type: "string" },
                                high_potential: { type: "string" },
                                rotation_option: { type: "string" }
                            }
                        },
                        contract_opportunities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    name: { type: "string" },
                                    age: { type: "number" },
                                    club: { type: "string" },
                                    position: { type: "string" },
                                    contract_expiry: { type: "string" },
                                    transfer_type: { type: "string" },
                                    likelihood: { type: "string" }
                                }
                            }
                        },
                        strategic_recommendations: {
                            type: "object",
                            properties: {
                                timing: { type: "string" },
                                negotiation_strategy: { type: "string" },
                                alternative_markets: { type: "string" },
                                key_insights: { type: "string" }
                            }
                        }
                    }
                }
            });

            return response;
        },
        onSuccess: (data) => {
            setAnalysis(data);
            toast.success('Market analysis complete!');
        },
        onError: (error) => {
            toast.error('Analysis failed. Please try again.');
            console.error(error);
        }
    });

    const handleAnalyze = () => {
        if (!criteria.budget && !criteria.position && !criteria.league) {
            toast.error('Please provide at least budget, position, or league information');
            return;
        }
        analyzeMutation.mutate(criteria);
    };

    return (
        <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Transfer Market Analyzer
                    </h1>
                    <p className="text-slate-400">AI-powered market intelligence for smart recruitment</p>
                </div>

                {/* Search Criteria */}
                <Card className="bg-slate-900/50 border-slate-800 mb-8">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Search className="w-5 h-5 text-cyan-400" />
                            Market Search Criteria
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-slate-300">Budget (€ millions)</Label>
                                <Input
                                    type="number"
                                    placeholder="e.g., 50"
                                    value={criteria.budget}
                                    onChange={(e) => setCriteria({...criteria, budget: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-300">Position</Label>
                                <Select value={criteria.position} onValueChange={(v) => setCriteria({...criteria, position: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Select position" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Striker">Striker</SelectItem>
                                        <SelectItem value="Winger">Winger</SelectItem>
                                        <SelectItem value="Attacking Midfielder">Attacking Midfielder</SelectItem>
                                        <SelectItem value="Central Midfielder">Central Midfielder</SelectItem>
                                        <SelectItem value="Defensive Midfielder">Defensive Midfielder</SelectItem>
                                        <SelectItem value="Full-back">Full-back</SelectItem>
                                        <SelectItem value="Centre-back">Centre-back</SelectItem>
                                        <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label className="text-slate-300">Min Age</Label>
                                <Input
                                    type="number"
                                    placeholder="e.g., 20"
                                    value={criteria.minAge}
                                    onChange={(e) => setCriteria({...criteria, minAge: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-300">Max Age</Label>
                                <Input
                                    type="number"
                                    placeholder="e.g., 28"
                                    value={criteria.maxAge}
                                    onChange={(e) => setCriteria({...criteria, maxAge: e.target.value})}
                                    className="bg-slate-800 border-slate-700 text-white"
                                />
                            </div>
                            <div>
                                <Label className="text-slate-300">Contract Expiry</Label>
                                <Select value={criteria.contractExpiry} onValueChange={(v) => setCriteria({...criteria, contractExpiry: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Any" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="6 months">Within 6 months</SelectItem>
                                        <SelectItem value="1 year">Within 1 year</SelectItem>
                                        <SelectItem value="2 years">Within 2 years</SelectItem>
                                        <SelectItem value="Any">Any</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label className="text-slate-300">Target League</Label>
                                <Select value={criteria.league} onValueChange={(v) => setCriteria({...criteria, league: v})}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                        <SelectValue placeholder="Select league" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Premier League">Premier League</SelectItem>
                                        <SelectItem value="La Liga">La Liga</SelectItem>
                                        <SelectItem value="Serie A">Serie A</SelectItem>
                                        <SelectItem value="Bundesliga">Bundesliga</SelectItem>
                                        <SelectItem value="Ligue 1">Ligue 1</SelectItem>
                                        <SelectItem value="Eredivisie">Eredivisie</SelectItem>
                                        <SelectItem value="Liga Portugal">Liga Portugal</SelectItem>
                                        <SelectItem value="Championship">Championship</SelectItem>
                                        <SelectItem value="Global">Global Search</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <div>
                            <Label className="text-slate-300">Additional Requirements</Label>
                            <Textarea
                                placeholder="e.g., Left-footed, good on the ball, leadership qualities..."
                                value={criteria.additionalNotes}
                                onChange={(e) => setCriteria({...criteria, additionalNotes: e.target.value})}
                                className="bg-slate-800 border-slate-700 text-white"
                                rows={3}
                            />
                        </div>
                        <Button
                            onClick={handleAnalyze}
                            disabled={analyzeMutation.isPending}
                            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500"
                        >
                            {analyzeMutation.isPending ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Analyzing Market...
                                </>
                            ) : (
                                <>
                                    <Target className="w-4 h-4 mr-2" />
                                    Analyze Transfer Market
                                </>
                            )}
                        </Button>
                    </CardContent>
                </Card>

                {/* Analysis Results */}
                {analysis && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                    >
                        {/* Market Trends */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                                    Market Trends
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div>
                                    <h4 className="text-cyan-400 font-semibold text-sm mb-1">Overview</h4>
                                    <p className="text-slate-300 text-sm">{analysis.market_trends?.overview}</p>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Supply & Demand</p>
                                        <p className="text-white text-sm">{analysis.market_trends?.supply_demand}</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Pricing Trend</p>
                                        <p className="text-white text-sm">{analysis.market_trends?.pricing_trend}</p>
                                    </div>
                                    <div className="bg-slate-800/50 rounded-lg p-3">
                                        <p className="text-slate-400 text-xs mb-1">Competition</p>
                                        <p className="text-white text-sm">{analysis.market_trends?.competition_level}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Undervalued Players */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <TrendingDown className="w-5 h-5 text-emerald-400" />
                                    Undervalued Players
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {analysis.undervalued_players?.map((player, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <div>
                                                    <h4 className="text-white font-semibold">{player.name}</h4>
                                                    <p className="text-slate-400 text-sm">{player.age} yrs • {player.club} • {player.position}</p>
                                                </div>
                                                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                                    {player.value_delta}% undervalued
                                                </Badge>
                                            </div>
                                            <div className="grid grid-cols-2 gap-3 mb-3">
                                                <div className="bg-slate-900/50 rounded p-2">
                                                    <p className="text-slate-400 text-xs">Current Value</p>
                                                    <p className="text-amber-400 font-semibold">€{player.current_value}M</p>
                                                </div>
                                                <div className="bg-slate-900/50 rounded p-2">
                                                    <p className="text-slate-400 text-xs">Est. Transfer Fee</p>
                                                    <p className="text-cyan-400 font-semibold">€{player.estimated_fee}M</p>
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Why Undervalued:</p>
                                                    <p className="text-slate-300 text-sm">{player.undervalued_reason}</p>
                                                </div>
                                                <div>
                                                    <p className="text-slate-400 text-xs mb-1">Key Strengths:</p>
                                                    <p className="text-slate-300 text-sm">{player.strengths}</p>
                                                </div>
                                            </div>
                                            <div className="mt-3">
                                                <Button
                                                    size="sm"
                                                    onClick={() => {
                                                        setSelectedPlayer(player);
                                                        setShowTaskDialog(true);
                                                    }}
                                                    className="bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 w-full sm:w-auto"
                                                >
                                                    <ClipboardList className="w-3 h-3 mr-2" />
                                                    Create Scouting Task
                                                </Button>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Fee Predictions */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <DollarSign className="w-5 h-5 text-amber-400" />
                                    Transfer Fee Predictions
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/30 rounded-lg p-4">
                                        <h4 className="text-purple-400 font-semibold mb-2">Proven Starter</h4>
                                        <p className="text-slate-300 text-sm">{analysis.fee_predictions?.proven_starter}</p>
                                    </div>
                                    <div className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border border-cyan-500/30 rounded-lg p-4">
                                        <h4 className="text-cyan-400 font-semibold mb-2">High Potential</h4>
                                        <p className="text-slate-300 text-sm">{analysis.fee_predictions?.high_potential}</p>
                                    </div>
                                    <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/30 rounded-lg p-4">
                                        <h4 className="text-blue-400 font-semibold mb-2">Rotation Option</h4>
                                        <p className="text-slate-300 text-sm">{analysis.fee_predictions?.rotation_option}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Contract Opportunities */}
                        <Card className="bg-slate-900/50 border-slate-800">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <Clock className="w-5 h-5 text-amber-400" />
                                    Contract Opportunities
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {analysis.contract_opportunities?.map((player, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="bg-slate-800/50 rounded-lg p-4 hover:bg-slate-800 transition-colors"
                                        >
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <h4 className="text-white font-semibold">{player.name}</h4>
                                                    <p className="text-slate-400 text-sm">{player.age} yrs • {player.club} • {player.position}</p>
                                                    <div className="flex items-center gap-3 mt-2">
                                                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                                            {player.transfer_type}
                                                        </Badge>
                                                        <span className="text-slate-500 text-xs">Expires: {player.contract_expiry}</span>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-slate-400 text-xs mb-1">Likelihood</p>
                                                    <p className="text-cyan-400 font-semibold text-sm">{player.likelihood}</p>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Strategic Recommendations */}
                        <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center gap-2">
                                    <AlertCircle className="w-5 h-5 text-cyan-400" />
                                    Strategic Recommendations
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div>
                                    <h4 className="text-cyan-400 font-semibold text-sm mb-1">Timing</h4>
                                    <p className="text-slate-300 text-sm">{analysis.strategic_recommendations?.timing}</p>
                                </div>
                                <div>
                                    <h4 className="text-cyan-400 font-semibold text-sm mb-1">Negotiation Strategy</h4>
                                    <p className="text-slate-300 text-sm">{analysis.strategic_recommendations?.negotiation_strategy}</p>
                                </div>
                                <div>
                                    <h4 className="text-cyan-400 font-semibold text-sm mb-1">Alternative Markets</h4>
                                    <p className="text-slate-300 text-sm">{analysis.strategic_recommendations?.alternative_markets}</p>
                                </div>
                                <div>
                                    <h4 className="text-cyan-400 font-semibold text-sm mb-1">Key Insights</h4>
                                    <p className="text-slate-300 text-sm">{analysis.strategic_recommendations?.key_insights}</p>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}

                {/* Create Task Dialog */}
                <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Create Scouting Task</DialogTitle>
                        </DialogHeader>
                        {selectedPlayer && (
                            <TaskForm 
                                onClose={() => setShowTaskDialog(false)} 
                                linkedPlayer={selectedPlayer}
                            />
                        )}
                    </DialogContent>
                </Dialog>
            </div>
        </div>
    );
}