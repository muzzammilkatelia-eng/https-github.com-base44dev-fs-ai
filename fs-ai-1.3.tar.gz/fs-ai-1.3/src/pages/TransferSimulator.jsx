import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, DollarSign, TrendingUp, Calculator, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import TransferScenarioBuilder from '../components/transfer-sim/TransferScenarioBuilder';
import BudgetManagement from '../components/transfer-sim/BudgetManagement';
import ROIAnalysis from '../components/transfer-sim/ROIAnalysis';
import MarketTrendAnalysis from '../components/transfer-sim/MarketTrendAnalysis';
import PremiumGate from '../components/PremiumGate';

export default function TransferSimulator() {
    return (
        <PremiumGate>
            <TransferSimulatorContent />
        </PremiumGate>
    );
}

function TransferSimulatorContent() {
    const [activeSimulation, setActiveSimulation] = useState(null);
    const [budget, setBudget] = useState({
        total: 100,
        remaining: 100,
        currency: 'EUR'
    });

    const { data: players = [], isLoading } = useQuery({
        queryKey: ['players'],
        queryFn: () => base44.entities.Player.list('-updated_date', 100)
    });

    const { data: projections = [] } = useQuery({
        queryKey: ['projections'],
        queryFn: () => base44.entities.PlayerProjection.list()
    });

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
                        Transfer Market Simulator
                    </h1>
                    <p className="text-slate-400">AI-powered transfer scenario planning with budget and ROI analysis</p>
                </div>

                {/* Budget Overview */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Total Budget</p>
                                    <p className="text-3xl font-bold text-emerald-400">€{budget.total}M</p>
                                </div>
                                <DollarSign className="w-8 h-8 text-emerald-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-600/10 border-cyan-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Remaining</p>
                                    <p className="text-3xl font-bold text-cyan-400">€{budget.remaining}M</p>
                                </div>
                                <Calculator className="w-8 h-8 text-cyan-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Spent</p>
                                    <p className="text-3xl font-bold text-purple-400">€{budget.total - budget.remaining}M</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-purple-400" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/30">
                        <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-slate-400 text-sm">Budget Used</p>
                                    <p className="text-3xl font-bold text-amber-400">
                                        {Math.round(((budget.total - budget.remaining) / budget.total) * 100)}%
                                    </p>
                                </div>
                                <Target className="w-8 h-8 text-amber-400" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="simulator" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                        <TabsTrigger value="simulator">Simulator</TabsTrigger>
                        <TabsTrigger value="budget">Budget</TabsTrigger>
                        <TabsTrigger value="roi">ROI Analysis</TabsTrigger>
                        <TabsTrigger value="trends">Market Trends</TabsTrigger>
                    </TabsList>

                    <TabsContent value="simulator" className="mt-6">
                        <TransferScenarioBuilder
                            players={players}
                            projections={projections}
                            budget={budget}
                            setBudget={setBudget}
                            activeSimulation={activeSimulation}
                            setActiveSimulation={setActiveSimulation}
                        />
                    </TabsContent>

                    <TabsContent value="budget" className="mt-6">
                        <BudgetManagement
                            budget={budget}
                            setBudget={setBudget}
                            activeSimulation={activeSimulation}
                        />
                    </TabsContent>

                    <TabsContent value="roi" className="mt-6">
                        <ROIAnalysis
                            players={players}
                            projections={projections}
                            activeSimulation={activeSimulation}
                        />
                    </TabsContent>

                    <TabsContent value="trends" className="mt-6">
                        <MarketTrendAnalysis players={players} projections={projections} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}